# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$StartFlying
# Linear span to next metadata entry; not a complete CFG.
0339ff28: f75bbda9 stp      x23, x22, [sp, #-0x30]!
0339ff2c: f55301a9 stp      x21, x20, [sp, #0x10]
0339ff30: f37b02a9 stp      x19, x30, [sp, #0x20]
0339ff34: 370f01f0 adrp     x23, #0x5586000
0339ff38: d6ef00d0 adrp     x22, #0x5199000
0339ff3c: e8f66639 ldrb     w8, [x23, #0x9bd]
0339ff40: d62246f9 ldr      x22, [x22, #0xc40]
0339ff44: f40302aa mov      x20, x2
0339ff48: f50301aa mov      x21, x1
0339ff4c: f30300aa mov      x19, x0
0339ff50: 88010037 tbnz     w8, #0, #0x339ff80
0339ff54: 00f50090 adrp     x0, #0x523f000
0339ff58: 004441f9 ldr      x0, [x0, #0x288]
0339ff5c: e9447097 bl       #0xfb1300
0339ff60: c0ef00d0 adrp     x0, #0x5199000
0339ff64: 002046f9 ldr      x0, [x0, #0xc40]
0339ff68: e6447097 bl       #0xfb1300
0339ff6c: e0f00090 adrp     x0, #0x51bb000
0339ff70: 00ec47f9 ldr      x0, [x0, #0xfd8]
0339ff74: e3447097 bl       #0xfb1300
0339ff78: 28008052 mov      w8, #1
0339ff7c: e8f62639 strb     w8, [x23, #0x9bd]
0339ff80: c00240f9 ldr      x0, [x22]
0339ff84: 16f50090 adrp     x22, #0x523f000
0339ff88: 08e040b9 ldr      w8, [x0, #0xe0]
0339ff8c: d64641f9 ldr      x22, [x22, #0x288]
0339ff90: 48000035 cbnz     w8, #0x339ff98
0339ff94: 1c457097 bl       #0xfb1404
0339ff98: c10240f9 ldr      x1, [x22]
0339ff9c: e0038052 mov      w0, #0x1f
0339ffa0: 35c6f197 bl       #0x3011874 ; Royal.Scenes.Start.Context.ApplicationContext$$Get<object>
0339ffa4: e10300aa mov      x1, x0
0339ffa8: e00313aa mov      x0, x19
0339ffac: 018c0af8 str      x1, [x0, #0xa8]!
0339ffb0: bf447097 bl       #0xfb12ac
0339ffb4: 350800b4 cbz      x21, #0x33a00b8
0339ffb8: e8f00090 adrp     x8, #0x51bb000
0339ffbc: 08ed47f9 ldr      x8, [x8, #0xfd8]
0339ffc0: a90240f9 ldr      x9, [x21]
0339ffc4: 010140f9 ldr      x1, [x8]
0339ffc8: 2ab14439 ldrb     w10, [x9, #0x12c]
0339ffcc: 28b04439 ldrb     w8, [x1, #0x12c]
0339ffd0: 5f01086b cmp      w10, w8
0339ffd4: e3060054 b.lo     #0x33a00b0
0339ffd8: 2a6540f9 ldr      x10, [x9, #0xc8]
0339ffdc: 090500d1 sub      x9, x8, #1
0339ffe0: 4a7969f8 ldr      x10, [x10, x9, lsl #3]
0339ffe4: 5f0101eb cmp      x10, x1
0339ffe8: 41060054 b.ne     #0x33a00b0
0339ffec: e00313aa mov      x0, x19
0339fff0: 150c05f8 str      x21, [x0, #0x50]!
0339fff4: aa0240f9 ldr      x10, [x21]
0339fff8: 4bb14439 ldrb     w11, [x10, #0x12c]
0339fffc: 7f01086b cmp      w11, w8
033a0000: 83050054 b.lo     #0x33a00b0
033a0004: 486540f9 ldr      x8, [x10, #0xc8]
033a0008: 087969f8 ldr      x8, [x8, x9, lsl #3]
033a000c: 1f0101eb cmp      x8, x1
033a0010: 01050054 b.ne     #0x33a00b0
033a0014: e10315aa mov      x1, x21
033a0018: a5447097 bl       #0xfb12ac
033a001c: e00315aa mov      x0, x21
033a0020: e1031faa mov      x1, xzr
033a0024: 618b2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
033a0028: e10300aa mov      x1, x0
033a002c: f50313aa mov      x21, x19
033a0030: a18e05f8 str      x1, [x21, #0x58]!
033a0034: e00315aa mov      x0, x21
033a0038: 9d447097 bl       #0xfb12ac
033a003c: a00240f9 ldr      x0, [x21]
033a0040: 400400b4 cbz      x0, #0x33a00c8
033a0044: 618a532d ldp      s1, s2, [x19, #0x9c]
033a0048: 609a40bd ldr      s0, [x19, #0x98]
033a004c: e1031faa mov      x1, xzr
033a0050: 9fa72594 bl       #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
033a0054: e00313aa mov      x0, x19
033a0058: 140c06f8 str      x20, [x0, #0x60]!
033a005c: e10314aa mov      x1, x20
033a0060: 93447097 bl       #0xfb12ac
033a0064: 680240f9 ldr      x8, [x19]
033a0068: e00313aa mov      x0, x19
033a006c: 09855fa9 ldp      x9, x1, [x8, #0x1f8]
033a0070: 20013fd6 blr      x9
033a0074: 680240f9 ldr      x8, [x19]
033a0078: 606a00b9 str      w0, [x19, #0x68]
033a007c: 7f7e00b9 str      wzr, [x19, #0x7c]
033a0080: e00313aa mov      x0, x19
033a0084: 091d41f9 ldr      x9, [x8, #0x238]
033a0088: 012141f9 ldr      x1, [x8, #0x240]
033a008c: 20013fd6 blr      x9
033a0090: 680240f9 ldr      x8, [x19]
033a0094: e00313aa mov      x0, x19
033a0098: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a009c: f55341a9 ldp      x21, x20, [sp, #0x10]
033a00a0: 020541f9 ldr      x2, [x8, #0x208]
033a00a4: 010941f9 ldr      x1, [x8, #0x210]
033a00a8: f75bc3a8 ldp      x23, x22, [sp], #0x30
033a00ac: 40001fd6 br       x2
033a00b0: e00315aa mov      x0, x21
033a00b4: c3457097 bl       #0xfb17c0
033a00b8: 750e05f8 str      x21, [x19, #0x50]!
033a00bc: e00313aa mov      x0, x19
033a00c0: e10315aa mov      x1, x21
033a00c4: 7a447097 bl       #0xfb12ac
033a00c8: d8447097 bl       #0xfb1428
