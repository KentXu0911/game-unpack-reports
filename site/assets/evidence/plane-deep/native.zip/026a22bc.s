# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$ExplodeSelf
# Linear span to next metadata entry; not a complete CFG.
026a22bc: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
026a22c0: f30300aa mov      x19, x0
026a22c4: 8d020094 bl       #0x26a2cf8 ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$UnFreezeCells
026a22c8: 606640f9 ldr      x0, [x19, #0xc8]
026a22cc: e00000b4 cbz      x0, #0x26a22e8
026a22d0: 080040f9 ldr      x8, [x0]
026a22d4: e1031f2a mov      w1, wzr
026a22d8: 033542f9 ldr      x3, [x8, #0x468]
026a22dc: 023942f9 ldr      x2, [x8, #0x470]
026a22e0: f37bc1a8 ldp      x19, x30, [sp], #0x10
026a22e4: 60001fd6 br       x3
026a22e8: 503ca497 bl       #0xfb1428
