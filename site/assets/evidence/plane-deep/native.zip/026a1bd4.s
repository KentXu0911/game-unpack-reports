# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$CanExplodeWithNearMatch
# Linear span to next metadata entry; not a complete CFG.
026a1bd4: e0031f2a mov      w0, wzr
026a1bd8: c0035fd6 ret      
