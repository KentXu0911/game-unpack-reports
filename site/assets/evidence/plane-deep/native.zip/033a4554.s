# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$GetNewPilot
# Linear span to next metadata entry; not a complete CFG.
033a4554: f80f1cf8 str      x24, [sp, #-0x40]!
033a4558: f75b01a9 stp      x23, x22, [sp, #0x10]
033a455c: f55302a9 stp      x21, x20, [sp, #0x20]
033a4560: f37b03a9 stp      x19, x30, [sp, #0x30]
033a4564: 130f01d0 adrp     x19, #0x5586000
033a4568: 95f200b0 adrp     x21, #0x51f5000
033a456c: 68626739 ldrb     w8, [x19, #0x9d8]
033a4570: b5e242f9 ldr      x21, [x21, #0x5c0]
033a4574: f40300aa mov      x20, x0
033a4578: c8000037 tbnz     w8, #0, #0x33a4590
033a457c: 80f200b0 adrp     x0, #0x51f5000
033a4580: 00e042f9 ldr      x0, [x0, #0x5c0]
033a4584: 5f337097 bl       #0xfb1300
033a4588: 28008052 mov      w8, #1
033a458c: 68622739 strb     w8, [x19, #0x9d8]
033a4590: a00240f9 ldr      x0, [x21]
033a4594: 931640f9 ldr      x19, [x20, #0x28]
033a4598: 96c24039 ldrb     w22, [x20, #0x30]
033a459c: 97c64039 ldrb     w23, [x20, #0x31]
033a45a0: 98ca4039 ldrb     w24, [x20, #0x32]
033a45a4: 942240f9 ldr      x20, [x20, #0x40]
033a45a8: 9c337097 bl       #0xfb1418
033a45ac: 200200b4 cbz      x0, #0x33a45f0
033a45b0: 1f030071 cmp      w24, #0
033a45b4: e4079f1a cset     w4, ne
033a45b8: ff020071 cmp      w23, #0
033a45bc: e3079f1a cset     w3, ne
033a45c0: df020071 cmp      w22, #0
033a45c4: e2079f1a cset     w2, ne
033a45c8: e10313aa mov      x1, x19
033a45cc: e50314aa mov      x5, x20
033a45d0: f50300aa mov      x21, x0
033a45d4: fadbff97 bl       #0x339b5bc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$.ctor
033a45d8: e00315aa mov      x0, x21
033a45dc: f37b43a9 ldp      x19, x30, [sp, #0x30]
033a45e0: f55342a9 ldp      x21, x20, [sp, #0x20]
033a45e4: f75b41a9 ldp      x23, x22, [sp, #0x10]
033a45e8: f80744f8 ldr      x24, [sp], #0x40
033a45ec: c0035fd6 ret      
033a45f0: 8e337097 bl       #0xfb1428
