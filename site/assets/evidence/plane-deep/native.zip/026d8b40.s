# Royal.Scenes.Game.Mechanics.Items.GummyItem.GummyBarHorizontalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
026d8b40: f40f1ef8 str      x20, [sp, #-0x20]!
026d8b44: f37b01a9 stp      x19, x30, [sp, #0x10]
026d8b48: f403012a mov      w20, w1
026d8b4c: f30300aa mov      x19, x0
026d8b50: e003012a mov      w0, w1
026d8b54: e1031faa mov      x1, xzr
026d8b58: 79af3294 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026d8b5c: 20040036 tbz      w0, #0, #0x26d8be0
026d8b60: 680240f9 ldr      x8, [x19]
026d8b64: e00313aa mov      x0, x19
026d8b68: 096542f9 ldr      x9, [x8, #0x4c8]
026d8b6c: 016942f9 ldr      x1, [x8, #0x4d0]
026d8b70: 20013fd6 blr      x9
026d8b74: 1f040071 cmp      w0, #1
026d8b78: 41030054 b.ne     #0x26d8be0
026d8b7c: 680240f9 ldr      x8, [x19]
026d8b80: e00313aa mov      x0, x19
026d8b84: 09bd41f9 ldr      x9, [x8, #0x378]
026d8b88: 01c141f9 ldr      x1, [x8, #0x380]
026d8b8c: 20013fd6 blr      x9
026d8b90: e1031faa mov      x1, xzr
026d8b94: 7daf3294 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
026d8b98: 680240f9 ldr      x8, [x19]
026d8b9c: f403002a mov      w20, w0
026d8ba0: e00313aa mov      x0, x19
026d8ba4: 09bd41f9 ldr      x9, [x8, #0x378]
026d8ba8: 01c141f9 ldr      x1, [x8, #0x380]
026d8bac: 20013fd6 blr      x9
026d8bb0: e1031faa mov      x1, xzr
026d8bb4: 75af3294 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
026d8bb8: c8aa8a52 mov      w8, #0x5556
026d8bbc: a8aaaa72 movk     w8, #0x5555, lsl #16
026d8bc0: 087c289b smull    x8, w0, w8
026d8bc4: f37b41a9 ldp      x19, x30, [sp, #0x10]
026d8bc8: 09fd7fd3 lsr      x9, x8, #0x3f
026d8bcc: 08fd60d3 lsr      x8, x8, #0x20
026d8bd0: 0801090b add      w8, w8, w9
026d8bd4: 0001140b add      w0, w8, w20
026d8bd8: f40742f8 ldr      x20, [sp], #0x20
026d8bdc: c0035fd6 ret      
026d8be0: e00313aa mov      x0, x19
026d8be4: f37b41a9 ldp      x19, x30, [sp, #0x10]
026d8be8: e103142a mov      w1, w20
026d8bec: e2031faa mov      x2, xzr
026d8bf0: f40742f8 ldr      x20, [sp], #0x20
026d8bf4: 27e43214 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
