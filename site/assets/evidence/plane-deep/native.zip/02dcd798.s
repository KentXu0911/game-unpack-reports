# Royal.Scenes.Game.Mechanics.Items.CupItem.CupItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02dcd798: f553bea9 stp      x21, x20, [sp, #-0x20]!
02dcd79c: f37b01a9 stp      x19, x30, [sp, #0x10]
02dcd7a0: 086840b9 ldr      w8, [x0, #0x68]
02dcd7a4: 68020034 cbz      w8, #0x2dcd7f0
02dcd7a8: 080040f9 ldr      x8, [x0]
02dcd7ac: f403012a mov      w20, w1
02dcd7b0: f30300aa mov      x19, x0
02dcd7b4: 096542f9 ldr      x9, [x8, #0x4c8]
02dcd7b8: 016942f9 ldr      x1, [x8, #0x4d0]
02dcd7bc: 20013fd6 blr      x9
02dcd7c0: 1f040071 cmp      w0, #1
02dcd7c4: 6b010054 b.lt     #0x2dcd7f0
02dcd7c8: e003142a mov      w0, w20
02dcd7cc: e1031faa mov      x1, xzr
02dcd7d0: 77dc1694 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02dcd7d4: 20010036 tbz      w0, #0, #0x2dcd7f8
02dcd7d8: 602a40f9 ldr      x0, [x19, #0x50]
02dcd7dc: 200400b4 cbz      x0, #0x2dcd860
02dcd7e0: 61c242f8 ldur     x1, [x19, #0x2c]
02dcd7e4: e2031faa mov      x2, xzr
02dcd7e8: 4a1be697 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
02dcd7ec: 06000014 b        #0x2dcd804
02dcd7f0: e0031f2a mov      w0, wzr
02dcd7f4: 18000014 b        #0x2dcd854
02dcd7f8: e00313aa mov      x0, x19
02dcd7fc: e1031faa mov      x1, xzr
02dcd800: a5d51694 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02dcd804: f50300aa mov      x21, x0
02dcd808: 605e40f9 ldr      x0, [x19, #0xb8]
02dcd80c: a00200b4 cbz      x0, #0x2dcd860
02dcd810: 613241b9 ldr      w1, [x19, #0x130]
02dcd814: 02fbff97 bl       #0x2dcc41c ; Royal.Scenes.Game.Mechanics.Items.CupItem.CupItemHelper$$GetCupItems
02dcd818: a4608a52 mov      w4, #0x5305
02dcd81c: e10300aa mov      x1, x0
02dcd820: 4400a072 movk     w4, #2, lsl #16
02dcd824: 05008012 mov      w5, #-1
02dcd828: e00313aa mov      x0, x19
02dcd82c: e20315aa mov      x2, x21
02dcd830: e303142a mov      w3, w20
02dcd834: e6031faa mov      x6, xzr
02dcd838: 64dc1694 bl       #0x33849c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetItemExplodeExtraScore
02dcd83c: f503002a mov      w21, w0
02dcd840: e00313aa mov      x0, x19
02dcd844: e103142a mov      w1, w20
02dcd848: e2031faa mov      x2, xzr
02dcd84c: 48dc1694 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02dcd850: 0000150b add      w0, w0, w21
02dcd854: f37b41a9 ldp      x19, x30, [sp, #0x10]
02dcd858: f553c2a8 ldp      x21, x20, [sp], #0x20
02dcd85c: c0035fd6 ret      
02dcd860: f28e8797 bl       #0xfb1428
