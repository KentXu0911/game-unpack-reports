# Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0368ba10: f60f1df8 str      x22, [sp, #-0x30]!
0368ba14: f55301a9 stp      x21, x20, [sp, #0x10]
0368ba18: f37b02a9 stp      x19, x30, [sp, #0x20]
0368ba1c: f5f700b0 adrp     x21, #0x5588000
0368ba20: a8d24e39 ldrb     w8, [x21, #0x3b4]
0368ba24: f303012a mov      w19, w1
0368ba28: f40300aa mov      x20, x0
0368ba2c: 68030037 tbnz     w8, #0, #0x368ba98
0368ba30: a0dc00b0 adrp     x0, #0x5220000
0368ba34: 00d847f9 ldr      x0, [x0, #0xfb0]
0368ba38: 32966497 bl       #0xfb1300
0368ba3c: 60dc0090 adrp     x0, #0x5217000
0368ba40: 000846f9 ldr      x0, [x0, #0xc10]
0368ba44: 2f966497 bl       #0xfb1300
0368ba48: 60db00f0 adrp     x0, #0x51fa000
0368ba4c: 00f840f9 ldr      x0, [x0, #0x1f0]
0368ba50: 2c966497 bl       #0xfb1300
0368ba54: 80dc0090 adrp     x0, #0x521b000
0368ba58: 002847f9 ldr      x0, [x0, #0xe50]
0368ba5c: 29966497 bl       #0xfb1300
0368ba60: e0dc00f0 adrp     x0, #0x522a000
0368ba64: 003440f9 ldr      x0, [x0, #0x68]
0368ba68: 26966497 bl       #0xfb1300
0368ba6c: e0d80090 adrp     x0, #0x51a7000
0368ba70: 009c45f9 ldr      x0, [x0, #0xb38]
0368ba74: 23966497 bl       #0xfb1300
0368ba78: 60d900b0 adrp     x0, #0x51b8000
0368ba7c: 006c45f9 ldr      x0, [x0, #0xad8]
0368ba80: 20966497 bl       #0xfb1300
0368ba84: 60d900d0 adrp     x0, #0x51b9000
0368ba88: 007045f9 ldr      x0, [x0, #0xae0]
0368ba8c: 1d966497 bl       #0xfb1300
0368ba90: 28008052 mov      w8, #1
0368ba94: a8d20e39 strb     w8, [x21, #0x3b4]
0368ba98: ff0f00b9 str      wzr, [sp, #0xc]
0368ba9c: 88ca4239 ldrb     w8, [x20, #0xb2]
0368baa0: 68000034 cbz      w8, #0x368baac
0368baa4: 15008012 mov      w21, #-1
0368baa8: c4000014 b        #0x368bdb8
0368baac: 75d900d0 adrp     x21, #0x51b9000
0368bab0: b57245f9 ldr      x21, [x21, #0xae0]
0368bab4: a00240f9 ldr      x0, [x21]
0368bab8: 08e040b9 ldr      w8, [x0, #0xe0]
0368babc: 48000035 cbnz     w8, #0x368bac4
0368bac0: 51966497 bl       #0xfb1404
0368bac4: 76f70090 adrp     x22, #0x5577000
0368bac8: c84e7d39 ldrb     w8, [x22, #0xf53]
0368bacc: c8000035 cbnz     w8, #0x368bae4
0368bad0: 60d900d0 adrp     x0, #0x51b9000
0368bad4: 007045f9 ldr      x0, [x0, #0xae0]
0368bad8: 0a966497 bl       #0xfb1300
0368badc: 28008052 mov      w8, #1
0368bae0: c84e3d39 strb     w8, [x22, #0xf53]
0368bae4: a00240f9 ldr      x0, [x21]
0368bae8: 08e040b9 ldr      w8, [x0, #0xe0]
0368baec: 68000035 cbnz     w8, #0x368baf8
0368baf0: 45966497 bl       #0xfb1404
0368baf4: a00240f9 ldr      x0, [x21]
0368baf8: 085c40f9 ldr      x8, [x0, #0xb8]
0368bafc: 08514039 ldrb     w8, [x8, #0x14]
0368bb00: a8030034 cbz      w8, #0x368bb74
0368bb04: e00314aa mov      x0, x20
0368bb08: e1031faa mov      x1, xzr
0368bb0c: e2dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bb10: 201500b4 cbz      x0, #0x368bdb4
0368bb14: 68d900b0 adrp     x8, #0x51b8000
0368bb18: 086d45f9 ldr      x8, [x8, #0xad8]
0368bb1c: 60088052 mov      w0, #0x43
0368bb20: 010140f9 ldr      x1, [x8]
0368bb24: d2cbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bb28: f50300aa mov      x21, x0
0368bb2c: e00314aa mov      x0, x20
0368bb30: e1031faa mov      x1, xzr
0368bb34: d8dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bb38: f51400b4 cbz      x21, #0x368bdd4
0368bb3c: e10300aa mov      x1, x0
0368bb40: e00315aa mov      x0, x21
0368bb44: e2031faa mov      x2, xzr
0368bb48: 74e46997 bl       #0x1104d18 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.WaterItem.WaterItemHelper$$IsInBoostingArea
0368bb4c: 40010036 tbz      w0, #0, #0x368bb74
0368bb50: e00314aa mov      x0, x20
0368bb54: e1031faa mov      x1, xzr
0368bb58: cfdcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bb5c: c01300b4 cbz      x0, #0x368bdd4
0368bb60: 006440f9 ldr      x0, [x0, #0xc8]
0368bb64: 801300b4 cbz      x0, #0x368bdd4
0368bb68: e1031faa mov      x1, xzr
0368bb6c: a61fd197 bl       #0x2ad3a04 ; Royal.Scenes.Game.Mechanics.Board.Cell.WaterItemMediator$$HasWaterView
0368bb70: e0120036 tbz      w0, #0, #0x368bdcc
0368bb74: e00314aa mov      x0, x20
0368bb78: e1031faa mov      x1, xzr
0368bb7c: c6dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bb80: a01100b4 cbz      x0, #0x368bdb4
0368bb84: 75158e52 mov      w21, #0x70ab
0368bb88: 20068052 mov      w0, #0x31
0368bb8c: e1031faa mov      x1, xzr
0368bb90: 5500a072 movk     w21, #2, lsl #16
0368bb94: c120c397 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
0368bb98: 80020036 tbz      w0, #0, #0x368bbe8
0368bb9c: 68db00f0 adrp     x8, #0x51fa000
0368bba0: 08f940f9 ldr      x8, [x8, #0x1f0]
0368bba4: 20068052 mov      w0, #0x31
0368bba8: 010140f9 ldr      x1, [x8]
0368bbac: b0cbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bbb0: f60300aa mov      x22, x0
0368bbb4: e00314aa mov      x0, x20
0368bbb8: e1031faa mov      x1, xzr
0368bbbc: b6dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bbc0: b61000b4 cbz      x22, #0x368bdd4
0368bbc4: 84c242f8 ldur     x4, [x20, #0x2c]
0368bbc8: e10300aa mov      x1, x0
0368bbcc: e2330091 add      x2, sp, #0xc
0368bbd0: e00316aa mov      x0, x22
0368bbd4: e303132a mov      w3, w19
0368bbd8: e5031faa mov      x5, xzr
0368bbdc: e750aa97 bl       #0x211ff78 ; Royal.Scenes.Game.Mechanics.Items.IceCubeItem.IceCubeItemHelper$$GetAvailableIceCubeScoreAboveCell
0368bbe0: 1f000071 cmp      w0, #0
0368bbe4: ac0e0054 b.gt     #0x368bdb8
0368bbe8: e0028052 mov      w0, #0x17
0368bbec: e1031faa mov      x1, xzr
0368bbf0: aa20c397 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
0368bbf4: 80020036 tbz      w0, #0, #0x368bc44
0368bbf8: a8dc00b0 adrp     x8, #0x5220000
0368bbfc: 08d947f9 ldr      x8, [x8, #0xfb0]
0368bc00: e0028052 mov      w0, #0x17
0368bc04: 010140f9 ldr      x1, [x8]
0368bc08: 99cbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bc0c: f60300aa mov      x22, x0
0368bc10: e00314aa mov      x0, x20
0368bc14: e1031faa mov      x1, xzr
0368bc18: 9fdcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bc1c: d60d00b4 cbz      x22, #0x368bdd4
0368bc20: 84c242f8 ldur     x4, [x20, #0x2c]
0368bc24: e10300aa mov      x1, x0
0368bc28: e2330091 add      x2, sp, #0xc
0368bc2c: e00316aa mov      x0, x22
0368bc30: e303132a mov      w3, w19
0368bc34: e5031faa mov      x5, xzr
0368bc38: 9794ab97 bl       #0x2170e94 ; Royal.Scenes.Game.Mechanics.Items.BirdItem.BirdItemHelper$$GetAvailableBirdScoreAboveCell
0368bc3c: 1f000071 cmp      w0, #0
0368bc40: cc0b0054 b.gt     #0x368bdb8
0368bc44: 200d8052 mov      w0, #0x69
0368bc48: e1031faa mov      x1, xzr
0368bc4c: 9320c397 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
0368bc50: 80020036 tbz      w0, #0, #0x368bca0
0368bc54: e8d80090 adrp     x8, #0x51a7000
0368bc58: 089d45f9 ldr      x8, [x8, #0xb38]
0368bc5c: 200d8052 mov      w0, #0x69
0368bc60: 010140f9 ldr      x1, [x8]
0368bc64: 82cbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bc68: f60300aa mov      x22, x0
0368bc6c: e00314aa mov      x0, x20
0368bc70: e1031faa mov      x1, xzr
0368bc74: 88dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bc78: f60a00b4 cbz      x22, #0x368bdd4
0368bc7c: 84c242f8 ldur     x4, [x20, #0x2c]
0368bc80: e10300aa mov      x1, x0
0368bc84: e2330091 add      x2, sp, #0xc
0368bc88: e00316aa mov      x0, x22
0368bc8c: e303132a mov      w3, w19
0368bc90: e5031faa mov      x5, xzr
0368bc94: 71481d94 bl       #0x3ddde58 ; Royal.Scenes.Game.Mechanics.Items.TurtleItem.TurtleItemHelper$$GetAvailableTurtleScoreAboveCell
0368bc98: 1f000071 cmp      w0, #0
0368bc9c: ec080054 b.gt     #0x368bdb8
0368bca0: c00b8052 mov      w0, #0x5e
0368bca4: e1031faa mov      x1, xzr
0368bca8: 7c20c397 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
0368bcac: 80020036 tbz      w0, #0, #0x368bcfc
0368bcb0: 88dc0090 adrp     x8, #0x521b000
0368bcb4: 082947f9 ldr      x8, [x8, #0xe50]
0368bcb8: c00b8052 mov      w0, #0x5e
0368bcbc: 010140f9 ldr      x1, [x8]
0368bcc0: 6bcbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bcc4: f60300aa mov      x22, x0
0368bcc8: e00314aa mov      x0, x20
0368bccc: e1031faa mov      x1, xzr
0368bcd0: 71dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bcd4: 160800b4 cbz      x22, #0x368bdd4
0368bcd8: 84c242f8 ldur     x4, [x20, #0x2c]
0368bcdc: e10300aa mov      x1, x0
0368bce0: e2330091 add      x2, sp, #0xc
0368bce4: e00316aa mov      x0, x22
0368bce8: e303132a mov      w3, w19
0368bcec: e5031faa mov      x5, xzr
0368bcf0: 3f0ba197 bl       #0x1ece9ec ; Royal.Scenes.Game.Mechanics.Items.RoyalBotItem.RoyalBotItemHelper$$GetAvailableRoyalBotScoreAboveCell
0368bcf4: 1f000071 cmp      w0, #0
0368bcf8: 0c060054 b.gt     #0x368bdb8
0368bcfc: 40048052 mov      w0, #0x22
0368bd00: e1031faa mov      x1, xzr
0368bd04: 6520c397 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
0368bd08: 80020036 tbz      w0, #0, #0x368bd58
0368bd0c: 68dc0090 adrp     x8, #0x5217000
0368bd10: 080946f9 ldr      x8, [x8, #0xc10]
0368bd14: 40048052 mov      w0, #0x22
0368bd18: 010140f9 ldr      x1, [x8]
0368bd1c: 54cbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bd20: f60300aa mov      x22, x0
0368bd24: e00314aa mov      x0, x20
0368bd28: e1031faa mov      x1, xzr
0368bd2c: 5adcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bd30: 360500b4 cbz      x22, #0x368bdd4
0368bd34: 84c242f8 ldur     x4, [x20, #0x2c]
0368bd38: e10300aa mov      x1, x0
0368bd3c: e2330091 add      x2, sp, #0xc
0368bd40: e00316aa mov      x0, x22
0368bd44: e303132a mov      w3, w19
0368bd48: e5031faa mov      x5, xzr
0368bd4c: cab0db97 bl       #0x2d78074 ; Royal.Scenes.Game.Mechanics.Items.FrogItem.FrogItemHelper$$GetAvailableFrogScoreAboveCell
0368bd50: 1f000071 cmp      w0, #0
0368bd54: 2c030054 b.gt     #0x368bdb8
0368bd58: 200a8052 mov      w0, #0x51
0368bd5c: e1031faa mov      x1, xzr
0368bd60: 4e20c397 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
0368bd64: 80020036 tbz      w0, #0, #0x368bdb4
0368bd68: e8dc00f0 adrp     x8, #0x522a000
0368bd6c: 083540f9 ldr      x8, [x8, #0x68]
0368bd70: 200a8052 mov      w0, #0x51
0368bd74: 010140f9 ldr      x1, [x8]
0368bd78: 3dcbba97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
0368bd7c: f60300aa mov      x22, x0
0368bd80: e00314aa mov      x0, x20
0368bd84: e1031faa mov      x1, xzr
0368bd88: 43dcf397 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0368bd8c: 560200b4 cbz      x22, #0x368bdd4
0368bd90: 84c242f8 ldur     x4, [x20, #0x2c]
0368bd94: e10300aa mov      x1, x0
0368bd98: e2330091 add      x2, sp, #0xc
0368bd9c: e00316aa mov      x0, x22
0368bda0: e303132a mov      w3, w19
0368bda4: e5031faa mov      x5, xzr
0368bda8: 9a7fab97 bl       #0x216bc10 ; Royal.Scenes.Game.Mechanics.Items.ShuttleItem.ShuttleItemHelper$$GetAvailableShuttleScoreAboveCell
0368bdac: 1f000071 cmp      w0, #0
0368bdb0: 4c000054 b.gt     #0x368bdb8
0368bdb4: 153b8212 mov      w21, #-0x11d9
0368bdb8: e003152a mov      w0, w21
0368bdbc: f37b42a9 ldp      x19, x30, [sp, #0x20]
0368bdc0: f55341a9 ldp      x21, x20, [sp, #0x10]
0368bdc4: f60743f8 ldr      x22, [sp], #0x30
0368bdc8: c0035fd6 ret      
0368bdcc: b5009d52 mov      w21, #0xe805
0368bdd0: faffff17 b        #0x368bdb8
0368bdd4: 95956497 bl       #0xfb1428
