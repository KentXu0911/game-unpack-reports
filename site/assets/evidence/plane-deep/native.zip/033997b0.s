# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScale
# Linear span to next metadata entry; not a complete CFG.
033997b0: ee0f1afc str      d14, [sp, #-0x60]!
033997b4: edb3006d stp      d13, d12, [sp, #8]
033997b8: ebab016d stp      d11, d10, [sp, #0x18]
033997bc: e9a3026d stp      d9, d8, [sp, #0x28]
033997c0: f61f00f9 str      x22, [sp, #0x38]
033997c4: f55304a9 stp      x21, x20, [sp, #0x40]
033997c8: f37b05a9 stp      x19, x30, [sp, #0x50]
033997cc: 740f01b0 adrp     x20, #0x5586000
033997d0: 888a6639 ldrb     w8, [x20, #0x9a2]
033997d4: 081ca04e mov      v8.16b, v0.16b
033997d8: f30300aa mov      x19, x0
033997dc: c8000037 tbnz     w8, #0, #0x33997f4
033997e0: 60f00090 adrp     x0, #0x51a5000
033997e4: 006445f9 ldr      x0, [x0, #0xac8]
033997e8: c65e7097 bl       #0xfb1300
033997ec: 28008052 mov      w8, #1
033997f0: 888a2639 strb     w8, [x20, #0x9a2]
033997f4: 689640b9 ldr      w8, [x19, #0x94]
033997f8: 1f050071 cmp      w8, #1
033997fc: 80060054 b.eq     #0x33998cc
03399800: 1f090071 cmp      w8, #2
03399804: c10d0054 b.ne     #0x33999bc
03399808: 608e40bd ldr      s0, [x19, #0x8c]
0339980c: 685600d0 adrp     x8, #0x3e67000
03399810: 013544bd ldr      s1, [x8, #0x434]
03399814: 0238281e fsub     s2, s0, s8
03399818: 4818201e fdiv     s8, s2, s0
0339981c: 0021211e fcmp     s8, s1
03399820: cb030054 b.lt     #0x3399898
03399824: 68924239 ldrb     w8, [x19, #0xa4]
03399828: 88030034 cbz      w8, #0x3399898
0339982c: 68f00090 adrp     x8, #0x51a5000
03399830: 086545f9 ldr      x8, [x8, #0xac8]
03399834: 7f920239 strb     wzr, [x19, #0xa4]
03399838: 743240f9 ldr      x20, [x19, #0x60]
0339983c: 000140f9 ldr      x0, [x8]
03399840: 08e040b9 ldr      w8, [x0, #0xe0]
03399844: 48000035 cbnz     w8, #0x339984c
03399848: ef5e7097 bl       #0xfb1404
0339984c: e0031f2a mov      w0, wzr
03399850: e1031f2a mov      w1, wzr
03399854: e2031faa mov      x2, xzr
03399858: fe667f97 bl       #0x1373450 ; Royal.Scenes.Game.Mechanics.Sortings.Sorting$$GetPropellerScaleDownSorting
0339985c: 680240f9 ldr      x8, [x19]
03399860: f50300aa mov      x21, x0
03399864: f60301aa mov      x22, x1
03399868: e00313aa mov      x0, x19
0339986c: 096d41f9 ldr      x9, [x8, #0x2d8]
03399870: 087141f9 ldr      x8, [x8, #0x2e0]
03399874: e10308aa mov      x1, x8
03399878: 20013fd6 blr      x9
0339987c: 140b00b4 cbz      x20, #0x33999dc
03399880: c27e4092 and      x2, x22, #0xffffffff
03399884: 03000012 and      w3, w0, #1
03399888: e00314aa mov      x0, x20
0339988c: e10315aa mov      x1, x21
03399890: e4031faa mov      x4, xzr
03399894: 0ddbff97 bl       #0x33904c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$UpdateSortingForAnimation
03399898: 680240f9 ldr      x8, [x19]
0339989c: e00313aa mov      x0, x19
033998a0: 001da84e mov      v0.16b, v8.16b
033998a4: f37b45a9 ldp      x19, x30, [sp, #0x50]
033998a8: 028541f9 ldr      x2, [x8, #0x308]
033998ac: 018941f9 ldr      x1, [x8, #0x310]
033998b0: f55344a9 ldp      x21, x20, [sp, #0x40]
033998b4: f61f40f9 ldr      x22, [sp, #0x38]
033998b8: e9a3426d ldp      d9, d8, [sp, #0x28]
033998bc: ebab416d ldp      d11, d10, [sp, #0x18]
033998c0: edb3406d ldp      d13, d12, [sp, #8]
033998c4: ee0746fc ldr      d14, [sp], #0x60
033998c8: 40001fd6 br       x2
033998cc: f40e01b0 adrp     x20, #0x5576000
033998d0: 88a27c39 ldrb     w8, [x20, #0xf28]
033998d4: c8000035 cbnz     w8, #0x33998ec
033998d8: 80f400d0 adrp     x0, #0x522b000
033998dc: 00ac43f9 ldr      x0, [x0, #0x758]
033998e0: 885e7097 bl       #0xfb1300
033998e4: 28008052 mov      w8, #1
033998e8: 88a23c39 strb     w8, [x20, #0xf28]
033998ec: 603640f9 ldr      x0, [x19, #0x68]
033998f0: 600700b4 cbz      x0, #0x33999dc
033998f4: 88f400d0 adrp     x8, #0x522b000
033998f8: 08ad43f9 ldr      x8, [x8, #0x758]
033998fc: 03102f1e fmov     s3, #1.50000000
03399900: e1031faa mov      x1, xzr
03399904: 080140f9 ldr      x8, [x8]
03399908: 085d40f9 ldr      x8, [x8, #0xb8]
0339990c: 0085412d ldp      s0, s1, [x8, #0xc]
03399910: 021540bd ldr      s2, [x8, #0x14]
03399914: 0808231e fmul     s8, s0, s3
03399918: 2908231e fmul     s9, s1, s3
0339991c: 4a08231e fmul     s10, s2, s3
03399920: 99c22594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
03399924: 2c1ca14e mov      v12.16b, v1.16b
03399928: 01103e1e fmov     s1, #-1.00000000
0339992c: 0b1ca04e mov      v11.16b, v0.16b
03399930: 0039201e fsub     s0, s8, s0
03399934: 0129211e fadd     s1, s8, s1
03399938: 0018211e fdiv     s0, s0, s1
0339993c: e0031faa mov      x0, xzr
03399940: 4d1ca24e mov      v13.16b, v2.16b
03399944: f4c0fb97 bl       #0x3289d14 ; Royal.Infrastructure.Utils.Animation.ManualEasing$$Linear
03399948: 680240f9 ldr      x8, [x19]
0339994c: 695600d0 adrp     x9, #0x3e67000
03399950: 223544bd ldr      s2, [x9, #0x434]
03399954: 01102e1e fmov     s1, #1.00000000
03399958: 09855da9 ldp      x9, x1, [x8, #0x1d8]
0339995c: 0158211e fmin     s1, s0, s1
03399960: 0020221e fcmp     s0, s2
03399964: e00313aa mov      x0, x19
03399968: 2e5c221e fcsel    s14, s1, s2, pl
0339996c: 20013fd6 blr      x9
03399970: 680240f9 ldr      x8, [x19]
03399974: c609201e fmul     s6, s14, s0
03399978: e00313aa mov      x0, x19
0339997c: 001da84e mov      v0.16b, v8.16b
03399980: 028d41f9 ldr      x2, [x8, #0x318]
03399984: 019141f9 ldr      x1, [x8, #0x320]
03399988: 211da94e mov      v1.16b, v9.16b
0339998c: 421daa4e mov      v2.16b, v10.16b
03399990: 631dab4e mov      v3.16b, v11.16b
03399994: 841dac4e mov      v4.16b, v12.16b
03399998: a51dad4e mov      v5.16b, v13.16b
0339999c: f37b45a9 ldp      x19, x30, [sp, #0x50]
033999a0: f55344a9 ldp      x21, x20, [sp, #0x40]
033999a4: f61f40f9 ldr      x22, [sp, #0x38]
033999a8: e9a3426d ldp      d9, d8, [sp, #0x28]
033999ac: ebab416d ldp      d11, d10, [sp, #0x18]
033999b0: edb3406d ldp      d13, d12, [sp, #8]
033999b4: ee0746fc ldr      d14, [sp], #0x60
033999b8: 40001fd6 br       x2
033999bc: f37b45a9 ldp      x19, x30, [sp, #0x50]
033999c0: f55344a9 ldp      x21, x20, [sp, #0x40]
033999c4: f61f40f9 ldr      x22, [sp, #0x38]
033999c8: e9a3426d ldp      d9, d8, [sp, #0x28]
033999cc: ebab416d ldp      d11, d10, [sp, #0x18]
033999d0: edb3406d ldp      d13, d12, [sp, #8]
033999d4: ee0746fc ldr      d14, [sp], #0x60
033999d8: c0035fd6 ret      
033999dc: 935e7097 bl       #0xfb1428
