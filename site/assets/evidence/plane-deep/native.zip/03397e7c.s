# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$ClearItemPools
# Linear span to next metadata entry; not a complete CFG.
03397e7c: f75bbda9 stp      x23, x22, [sp, #-0x30]!
03397e80: f55301a9 stp      x21, x20, [sp, #0x10]
03397e84: f37b02a9 stp      x19, x30, [sp, #0x20]
03397e88: 750f01f0 adrp     x21, #0x5586000
03397e8c: a84a6639 ldrb     w8, [x21, #0x992]
03397e90: f30301aa mov      x19, x1
03397e94: f40300aa mov      x20, x0
03397e98: e8010037 tbnz     w8, #0, #0x3397ed4
03397e9c: c0ef0090 adrp     x0, #0x518f000
03397ea0: 003843f9 ldr      x0, [x0, #0x670]
03397ea4: 17657097 bl       #0xfb1300
03397ea8: c0f000b0 adrp     x0, #0x51b0000
03397eac: 00d041f9 ldr      x0, [x0, #0x3a0]
03397eb0: 14657097 bl       #0xfb1300
03397eb4: 60f200f0 adrp     x0, #0x51e6000
03397eb8: 005042f9 ldr      x0, [x0, #0x4a0]
03397ebc: 11657097 bl       #0xfb1300
03397ec0: a0f200b0 adrp     x0, #0x51ec000
03397ec4: 001043f9 ldr      x0, [x0, #0x620]
03397ec8: 0e657097 bl       #0xfb1300
03397ecc: 28008052 mov      w8, #1
03397ed0: a84a2639 strb     w8, [x21, #0x992]
03397ed4: e00314aa mov      x0, x20
03397ed8: e1feff97 bl       #0x3397a5c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetViewPrefab
03397edc: 530400b4 cbz      x19, #0x3397f64
03397ee0: c8f000b0 adrp     x8, #0x51b0000
03397ee4: 08d141f9 ldr      x8, [x8, #0x3a0]
03397ee8: d5ef0090 adrp     x21, #0x518f000
03397eec: b6f200b0 adrp     x22, #0x51ec000
03397ef0: 77f200f0 adrp     x23, #0x51e6000
03397ef4: 020140f9 ldr      x2, [x8]
03397ef8: b53a43f9 ldr      x21, [x21, #0x670]
03397efc: d61243f9 ldr      x22, [x22, #0x620]
03397f00: f75242f9 ldr      x23, [x23, #0x4a0]
03397f04: e10300aa mov      x1, x0
03397f08: e00313aa mov      x0, x19
03397f0c: 089bc697 bl       #0x253eb2c ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$ClearPool<object>
03397f10: e00314aa mov      x0, x20
03397f14: f6feff97 bl       #0x3397aec ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetExplodePrefabs
03397f18: a20240f9 ldr      x2, [x21]
03397f1c: e10300aa mov      x1, x0
03397f20: e00313aa mov      x0, x19
03397f24: 029bc697 bl       #0x253eb2c ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$ClearPool<object>
03397f28: e00314aa mov      x0, x20
03397f2c: 15ffff97 bl       #0x3397b80 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetTargetExplodePrefabs
03397f30: c20240f9 ldr      x2, [x22]
03397f34: e10300aa mov      x1, x0
03397f38: e00313aa mov      x0, x19
03397f3c: fc9ac697 bl       #0x253eb2c ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$ClearPool<object>
03397f40: e00314aa mov      x0, x20
03397f44: 34ffff97 bl       #0x3397c14 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerRocketComboParticlePrefab
03397f48: e20240f9 ldr      x2, [x23]
03397f4c: e10300aa mov      x1, x0
03397f50: e00313aa mov      x0, x19
03397f54: f37b42a9 ldp      x19, x30, [sp, #0x20]
03397f58: f55341a9 ldp      x21, x20, [sp, #0x10]
03397f5c: f75bc3a8 ldp      x23, x22, [sp], #0x30
03397f60: f39ac617 b        #0x253eb2c ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$ClearPool<object>
03397f64: 31657097 bl       #0xfb1428
