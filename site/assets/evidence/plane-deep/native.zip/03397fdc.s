# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemExplodeParticles$$.ctor
# Linear span to next metadata entry; not a complete CFG.
03397fdc: e1031faa mov      x1, xzr
03397fe0: 3cb7ff17 b        #0x3385cd0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemParticles$$.ctor
