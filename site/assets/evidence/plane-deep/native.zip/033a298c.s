# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.FireworksRocketStrategy$$ExplodeNeighbors
# Linear span to next metadata entry; not a complete CFG.
033a298c: e0031f2a mov      w0, wzr
033a2990: c0035fd6 ret      
