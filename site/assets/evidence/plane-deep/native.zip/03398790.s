# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$.ctor
# Linear span to next metadata entry; not a complete CFG.
03398790: e1031faa mov      x1, xzr
03398794: dac50b14 b        #0x3689efc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$.ctor
