# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$ArrangeScale
# Linear span to next metadata entry; not a complete CFG.
033a0c5c: ef3bba6d stp      d15, d14, [sp, #-0x60]!
033a0c60: ed33016d stp      d13, d12, [sp, #0x10]
033a0c64: eb2b026d stp      d11, d10, [sp, #0x20]
033a0c68: e923036d stp      d9, d8, [sp, #0x30]
033a0c6c: f42300f9 str      x20, [sp, #0x40]
033a0c70: f37b05a9 stp      x19, x30, [sp, #0x50]
033a0c74: 340f01d0 adrp     x20, #0x5586000
033a0c78: 880e6739 ldrb     w8, [x20, #0x9c3]
033a0c7c: 081ca04e mov      v8.16b, v0.16b
033a0c80: f30300aa mov      x19, x0
033a0c84: c8000037 tbnz     w8, #0, #0x33a0c9c
033a0c88: 20f000b0 adrp     x0, #0x51a5000
033a0c8c: 006445f9 ldr      x0, [x0, #0xac8]
033a0c90: 9c417097 bl       #0xfb1300
033a0c94: 28008052 mov      w8, #1
033a0c98: 880e2739 strb     w8, [x20, #0x9c3]
033a0c9c: 688640b9 ldr      w8, [x19, #0x84]
033a0ca0: 1f050071 cmp      w8, #1
033a0ca4: 00060054 b.eq     #0x33a0d64
033a0ca8: 1f090071 cmp      w8, #2
033a0cac: c10e0054 b.ne     #0x33a0e84
033a0cb0: 607640bd ldr      s0, [x19, #0x74]
033a0cb4: 285600f0 adrp     x8, #0x3e67000
033a0cb8: 013544bd ldr      s1, [x8, #0x434]
033a0cbc: 0238281e fsub     s2, s0, s8
033a0cc0: 4818201e fdiv     s8, s2, s0
033a0cc4: 0021211e fcmp     s8, s1
033a0cc8: 6b030054 b.lt     #0x33a0d34
033a0ccc: 68524239 ldrb     w8, [x19, #0x94]
033a0cd0: 28030034 cbz      w8, #0x33a0d34
033a0cd4: 28f000b0 adrp     x8, #0x51a5000
033a0cd8: 086545f9 ldr      x8, [x8, #0xac8]
033a0cdc: 7f520239 strb     wzr, [x19, #0x94]
033a0ce0: 742a40f9 ldr      x20, [x19, #0x50]
033a0ce4: 000140f9 ldr      x0, [x8]
033a0ce8: 08e040b9 ldr      w8, [x0, #0xe0]
033a0cec: 48000035 cbnz     w8, #0x33a0cf4
033a0cf0: c5417097 bl       #0xfb1404
033a0cf4: e0031f2a mov      w0, wzr
033a0cf8: e1031f2a mov      w1, wzr
033a0cfc: e2031faa mov      x2, xzr
033a0d00: d4497f97 bl       #0x1373450 ; Royal.Scenes.Game.Mechanics.Sortings.Sorting$$GetPropellerScaleDownSorting
033a0d04: f40c00b4 cbz      x20, #0x33a0ea0
033a0d08: e30300aa mov      x3, x0
033a0d0c: 227c4092 and      x2, x1, #0xffffffff
033a0d10: e00314aa mov      x0, x20
033a0d14: e10303aa mov      x1, x3
033a0d18: e3031f2a mov      w3, wzr
033a0d1c: e4031faa mov      x4, xzr
033a0d20: eabdff97 bl       #0x33904c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$UpdateSortingForAnimation
033a0d24: 602a40f9 ldr      x0, [x19, #0x50]
033a0d28: c00b00b4 cbz      x0, #0x33a0ea0
033a0d2c: e1031faa mov      x1, xzr
033a0d30: 9ebdbf97 bl       #0x23903a8 ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$PlayBoomerangFlyHitAnimation
033a0d34: 680240f9 ldr      x8, [x19]
033a0d38: e00313aa mov      x0, x19
033a0d3c: 001da84e mov      v0.16b, v8.16b
033a0d40: f37b45a9 ldp      x19, x30, [sp, #0x50]
033a0d44: 023541f9 ldr      x2, [x8, #0x268]
033a0d48: 013941f9 ldr      x1, [x8, #0x270]
033a0d4c: f42340f9 ldr      x20, [sp, #0x40]
033a0d50: e923436d ldp      d9, d8, [sp, #0x30]
033a0d54: eb2b426d ldp      d11, d10, [sp, #0x20]
033a0d58: ed33416d ldp      d13, d12, [sp, #0x10]
033a0d5c: ef3bc66c ldp      d15, d14, [sp], #0x60
033a0d60: 40001fd6 br       x2
033a0d64: b40e01d0 adrp     x20, #0x5576000
033a0d68: 88a27c39 ldrb     w8, [x20, #0xf28]
033a0d6c: c8000035 cbnz     w8, #0x33a0d84
033a0d70: 40f400f0 adrp     x0, #0x522b000
033a0d74: 00ac43f9 ldr      x0, [x0, #0x758]
033a0d78: 62417097 bl       #0xfb1300
033a0d7c: 28008052 mov      w8, #1
033a0d80: 88a23c39 strb     w8, [x20, #0xf28]
033a0d84: 602e40f9 ldr      x0, [x19, #0x58]
033a0d88: c00800b4 cbz      x0, #0x33a0ea0
033a0d8c: 48f400f0 adrp     x8, #0x522b000
033a0d90: 08ad43f9 ldr      x8, [x8, #0x758]
033a0d94: 0fd0201e fmov     s15, #2.75000000
033a0d98: e1031faa mov      x1, xzr
033a0d9c: 080140f9 ldr      x8, [x8]
033a0da0: 085d40f9 ldr      x8, [x8, #0xb8]
033a0da4: 0085412d ldp      s0, s1, [x8, #0xc]
033a0da8: e14f00bd str      s1, [sp, #0x4c]
033a0dac: 011540bd ldr      s1, [x8, #0x14]
033a0db0: 09082f1e fmul     s9, s0, s15
033a0db4: e14b00bd str      s1, [sp, #0x48]
033a0db8: 73a52594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
033a0dbc: 2b1ca14e mov      v11.16b, v1.16b
033a0dc0: 01103e1e fmov     s1, #-1.00000000
033a0dc4: 0a1ca04e mov      v10.16b, v0.16b
033a0dc8: 2039201e fsub     s0, s9, s0
033a0dcc: 2129211e fadd     s1, s9, s1
033a0dd0: 0e18211e fdiv     s14, s0, s1
033a0dd4: c01dae4e mov      v0.16b, v14.16b
033a0dd8: e0031faa mov      x0, xzr
033a0ddc: 4c1ca24e mov      v12.16b, v2.16b
033a0de0: cda3fb97 bl       #0x3289d14 ; Royal.Infrastructure.Utils.Animation.ManualEasing$$Linear
033a0de4: 285600f0 adrp     x8, #0x3e67000
033a0de8: 043544bd ldr      s4, [x8, #0x434]
033a0dec: 01102e1e fmov     s1, #1.00000000
033a0df0: 02d0271e fmov     s2, #30.00000000
033a0df4: 0158211e fmin     s1, s0, s1
033a0df8: 0350241e fmov     s3, #9.00000000
033a0dfc: 05102a1e fmov     s5, #0.25000000
033a0e00: 2108221e fmul     s1, s1, s2
033a0e04: 0020241e fcmp     s0, s4
033a0e08: 2d5c231e fcsel    s13, s1, s3, pl
033a0e0c: c021251e fcmp     s14, s5
033a0e10: 25010054 b.pl     #0x33a0e34
033a0e14: 68564239 ldrb     w8, [x19, #0x95]
033a0e18: e8000034 cbz      w8, #0x33a0e34
033a0e1c: 602a40f9 ldr      x0, [x19, #0x50]
033a0e20: 7f560239 strb     wzr, [x19, #0x95]
033a0e24: e00300b4 cbz      x0, #0x33a0ea0
033a0e28: 001da84e mov      v0.16b, v8.16b
033a0e2c: e1031faa mov      x1, xzr
033a0e30: c7bdbf97 bl       #0x239054c ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$PlayBoomerangFlyAnimationAfterHit
033a0e34: e04f40bd ldr      s0, [sp, #0x4c]
033a0e38: 680240f9 ldr      x8, [x19]
033a0e3c: e00313aa mov      x0, x19
033a0e40: 431daa4e mov      v3.16b, v10.16b
033a0e44: 01082f1e fmul     s1, s0, s15
033a0e48: e04b40bd ldr      s0, [sp, #0x48]
033a0e4c: 023d41f9 ldr      x2, [x8, #0x278]
033a0e50: 014141f9 ldr      x1, [x8, #0x280]
033a0e54: 641dab4e mov      v4.16b, v11.16b
033a0e58: 02082f1e fmul     s2, s0, s15
033a0e5c: 201da94e mov      v0.16b, v9.16b
033a0e60: 851dac4e mov      v5.16b, v12.16b
033a0e64: a61dad4e mov      v6.16b, v13.16b
033a0e68: f37b45a9 ldp      x19, x30, [sp, #0x50]
033a0e6c: f42340f9 ldr      x20, [sp, #0x40]
033a0e70: e923436d ldp      d9, d8, [sp, #0x30]
033a0e74: eb2b426d ldp      d11, d10, [sp, #0x20]
033a0e78: ed33416d ldp      d13, d12, [sp, #0x10]
033a0e7c: ef3bc66c ldp      d15, d14, [sp], #0x60
033a0e80: 40001fd6 br       x2
033a0e84: f37b45a9 ldp      x19, x30, [sp, #0x50]
033a0e88: f42340f9 ldr      x20, [sp, #0x40]
033a0e8c: e923436d ldp      d9, d8, [sp, #0x30]
033a0e90: eb2b426d ldp      d11, d10, [sp, #0x20]
033a0e94: ed33416d ldp      d13, d12, [sp, #0x10]
033a0e98: ef3bc66c ldp      d15, d14, [sp], #0x60
033a0e9c: c0035fd6 ret      
033a0ea0: 62417097 bl       #0xfb1428
