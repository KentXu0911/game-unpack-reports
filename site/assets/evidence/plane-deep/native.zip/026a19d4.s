# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$get_LastValidCell
# Linear span to next metadata entry; not a complete CFG.
026a19d4: 006040f9 ldr      x0, [x0, #0xc0]
026a19d8: c0035fd6 ret      
