# Royal.Scenes.Game.Mechanics.Items.PowerCubeItem.PowerCubeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e36bf0: f553bea9 stp      x21, x20, [sp, #-0x20]!
01e36bf4: f37b01a9 stp      x19, x30, [sp, #0x10]
01e36bf8: 080040f9 ldr      x8, [x0]
01e36bfc: f303012a mov      w19, w1
01e36c00: f40300aa mov      x20, x0
01e36c04: 096542f9 ldr      x9, [x8, #0x4c8]
01e36c08: 086942f9 ldr      x8, [x8, #0x4d0]
01e36c0c: e10308aa mov      x1, x8
01e36c10: 20013fd6 blr      x9
01e36c14: f503002a mov      w21, w0
01e36c18: e00314aa mov      x0, x20
01e36c1c: e103132a mov      w1, w19
01e36c20: e2031faa mov      x2, xzr
01e36c24: 52375594 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
01e36c28: bf060071 cmp      w21, #1
01e36c2c: f303002a mov      w19, w0
01e36c30: e1020054 b.ne     #0x1e36c8c
01e36c34: 880240f9 ldr      x8, [x20]
01e36c38: e00314aa mov      x0, x20
01e36c3c: 09bd41f9 ldr      x9, [x8, #0x378]
01e36c40: 01c141f9 ldr      x1, [x8, #0x380]
01e36c44: 20013fd6 blr      x9
01e36c48: e1031faa mov      x1, xzr
01e36c4c: 4f375594 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e36c50: 886640f9 ldr      x8, [x20, #0xc8]
01e36c54: 480200b4 cbz      x8, #0x1e36c9c
01e36c58: 81ba40b9 ldr      w1, [x20, #0xb8]
01e36c5c: f503002a mov      w21, w0
01e36c60: e00308aa mov      x0, x8
01e36c64: 52f0ff97 bl       #0x1e32dac ; Royal.Scenes.Game.Mechanics.Items.PowerCubeItem.PowerCubeItemHelper$$GetGroupLength
01e36c68: 08040051 sub      w8, w0, #1
01e36c6c: c9aa8a52 mov      w9, #0x5556
01e36c70: a9aaaa72 movk     w9, #0x5555, lsl #16
01e36c74: 087d151b mul      w8, w8, w21
01e36c78: 087d299b smull    x8, w8, w9
01e36c7c: 09fd7fd3 lsr      x9, x8, #0x3f
01e36c80: 08fd60d3 lsr      x8, x8, #0x20
01e36c84: 0801090b add      w8, w8, w9
01e36c88: 1301130b add      w19, w8, w19
01e36c8c: e003132a mov      w0, w19
01e36c90: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e36c94: f553c2a8 ldp      x21, x20, [sp], #0x20
01e36c98: c0035fd6 ret      
01e36c9c: e3e9c597 bl       #0xfb1428
