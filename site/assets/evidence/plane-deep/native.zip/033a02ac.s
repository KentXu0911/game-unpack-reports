# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$MoveToTarget
# Linear span to next metadata entry; not a complete CFG.
033a02ac: ff4304d1 sub      sp, sp, #0x110
033a02b0: ef3b076d stp      d15, d14, [sp, #0x70]
033a02b4: ed33086d stp      d13, d12, [sp, #0x80]
033a02b8: eb2b096d stp      d11, d10, [sp, #0x90]
033a02bc: e9230a6d stp      d9, d8, [sp, #0xa0]
033a02c0: fc6f0ba9 stp      x28, x27, [sp, #0xb0]
033a02c4: fa670ca9 stp      x26, x25, [sp, #0xc0]
033a02c8: f85f0da9 stp      x24, x23, [sp, #0xd0]
033a02cc: f6570ea9 stp      x22, x21, [sp, #0xe0]
033a02d0: f44f0fa9 stp      x20, x19, [sp, #0xf0]
033a02d4: fd7b10a9 stp      x29, x30, [sp, #0x100]
033a02d8: 340f01d0 adrp     x20, #0x5586000
033a02dc: 88fe6639 ldrb     w8, [x20, #0x9bf]
033a02e0: f30300aa mov      x19, x0
033a02e4: c8030037 tbnz     w8, #0, #0x33a035c
033a02e8: a0f300d0 adrp     x0, #0x5216000
033a02ec: 001c44f9 ldr      x0, [x0, #0x838]
033a02f0: 04447097 bl       #0xfb1300
033a02f4: 20f200d0 adrp     x0, #0x51e6000
033a02f8: 007840f9 ldr      x0, [x0, #0xf0]
033a02fc: 01447097 bl       #0xfb1300
033a0300: 40f00090 adrp     x0, #0x51a8000
033a0304: 00dc41f9 ldr      x0, [x0, #0x3b8]
033a0308: fe437097 bl       #0xfb1300
033a030c: 60f400f0 adrp     x0, #0x522f000
033a0310: 000445f9 ldr      x0, [x0, #0xa08]
033a0314: fb437097 bl       #0xfb1300
033a0318: 80f400b0 adrp     x0, #0x5231000
033a031c: 003841f9 ldr      x0, [x0, #0x270]
033a0320: f8437097 bl       #0xfb1300
033a0324: c0f20090 adrp     x0, #0x51f8000
033a0328: 000847f9 ldr      x0, [x0, #0xe10]
033a032c: f5437097 bl       #0xfb1300
033a0330: 40f400f0 adrp     x0, #0x522b000
033a0334: 00ac43f9 ldr      x0, [x0, #0x758]
033a0338: f2437097 bl       #0xfb1300
033a033c: 80f300b0 adrp     x0, #0x5211000
033a0340: 00e440f9 ldr      x0, [x0, #0x1c8]
033a0344: ef437097 bl       #0xfb1300
033a0348: c0f10090 adrp     x0, #0x51d8000
033a034c: 004c44f9 ldr      x0, [x0, #0x898]
033a0350: ec437097 bl       #0xfb1300
033a0354: 28008052 mov      w8, #1
033a0358: 88fe2639 strb     w8, [x20, #0x9bf]
033a035c: 602e40f9 ldr      x0, [x19, #0x58]
033a0360: 404700b4 cbz      x0, #0x33a0c48
033a0364: e1031faa mov      x1, xzr
033a0368: 63a62594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a036c: 743240f9 ldr      x20, [x19, #0x60]
033a0370: d44600b4 cbz      x20, #0x33a0c48
033a0374: 77f400f0 adrp     x23, #0x522f000
033a0378: 880240f9 ldr      x8, [x20]
033a037c: f70645f9 ldr      x23, [x23, #0xa08]
033a0380: 0c1ca04e mov      v12.16b, v0.16b
033a0384: 2a1ca14e mov      v10.16b, v1.16b
033a0388: 09554279 ldrh     w9, [x8, #0x12a]
033a038c: e10240f9 ldr      x1, [x23]
033a0390: 4d1ca24e mov      v13.16b, v2.16b
033a0394: 290100b4 cbz      x9, #0x33a03b8
033a0398: 0a5940f9 ldr      x10, [x8, #0xb0]
033a039c: 4a210091 add      x10, x10, #8
033a03a0: 4b815ff8 ldur     x11, [x10, #-8]
033a03a4: 7f0101eb cmp      x11, x1
033a03a8: 00010054 b.eq     #0x33a03c8
033a03ac: 290500f1 subs     x9, x9, #1
033a03b0: 4a410091 add      x10, x10, #0x10
033a03b4: 61ffff54 b.ne     #0x33a03a0
033a03b8: 22008052 mov      w2, #1
033a03bc: e00314aa mov      x0, x20
033a03c0: c5836f97 bl       #0xf812d4
033a03c4: 05000014 b        #0x33a03d8
033a03c8: 490140b9 ldr      w9, [x10]
033a03cc: 29050011 add      w9, w9, #1
033a03d0: 08d1298b add      x8, x8, w9, sxtw #4
033a03d4: 00e10491 add      x0, x8, #0x138
033a03d8: 080440a9 ldp      x8, x1, [x0]
033a03dc: e00314aa mov      x0, x20
033a03e0: 00013fd6 blr      x8
033a03e4: b60e01f0 adrp     x22, #0x5577000
033a03e8: c81a6039 ldrb     w8, [x22, #0x806]
033a03ec: 091ca04e mov      v9.16b, v0.16b
033a03f0: 281ca14e mov      v8.16b, v1.16b
033a03f4: 4e1ca24e mov      v14.16b, v2.16b
033a03f8: c8000035 cbnz     w8, #0x33a0410
033a03fc: 00f30090 adrp     x0, #0x5200000
033a0400: 008c46f9 ldr      x0, [x0, #0xd18]
033a0404: bf437097 bl       #0xfb1300
033a0408: 28008052 mov      w8, #1
033a040c: c81a2039 strb     w8, [x22, #0x806]
033a0410: 18f30090 adrp     x24, #0x5200000
033a0414: 188f46f9 ldr      x24, [x24, #0xd18]
033a0418: 2f392c1e fsub     s15, s9, s12
033a041c: 000340f9 ldr      x0, [x24]
033a0420: 08e040b9 ldr      w8, [x0, #0xe0]
033a0424: e923042d stp      s9, s8, [sp, #0x20]
033a0428: ec2b032d stp      s12, s10, [sp, #0x18]
033a042c: 0a392a1e fsub     s10, s8, s10
033a0430: c9392d1e fsub     s9, s14, s13
033a0434: 48000035 cbnz     w8, #0x33a043c
033a0438: f3437097 bl       #0xfb1404
033a043c: b40e01f0 adrp     x20, #0x5577000
033a0440: 88fa7f39 ldrb     w8, [x20, #0xffe]
033a0444: e0092f1e fmul     s0, s15, s15
033a0448: 41092a1e fmul     s1, s10, s10
033a044c: 0028211e fadd     s0, s0, s1
033a0450: 2109291e fmul     s1, s9, s9
033a0454: 2828201e fadd     s8, s1, s0
033a0458: c8000035 cbnz     w8, #0x33a0470
033a045c: 00f30090 adrp     x0, #0x5200000
033a0460: 008c46f9 ldr      x0, [x0, #0xd18]
033a0464: a7437097 bl       #0xfb1300
033a0468: 28008052 mov      w8, #1
033a046c: 88fa3f39 strb     w8, [x20, #0xffe]
033a0470: 000340f9 ldr      x0, [x24]
033a0474: 08c1211e fsqrt    s8, s8
033a0478: 08e040b9 ldr      w8, [x0, #0xe0]
033a047c: 48000035 cbnz     w8, #0x33a0484
033a0480: e1437097 bl       #0xfb1404
033a0484: 885600f0 adrp     x8, #0x3e73000
033a0488: ed1700bd str      s13, [sp, #0x14]
033a048c: 01894bbd ldr      s1, [x8, #0xb88]
033a0490: 5bf400f0 adrp     x27, #0x522b000
033a0494: 7baf43f9 ldr      x27, [x27, #0x758]
033a0498: 0021211e fcmp     s8, s1
033a049c: ad000054 b.le     #0x33a04b0
033a04a0: eb19281e fdiv     s11, s15, s8
033a04a4: 4c19281e fdiv     s12, s10, s8
033a04a8: 2d19281e fdiv     s13, s9, s8
033a04ac: 0d000014 b        #0x33a04e0
033a04b0: b40e01d0 adrp     x20, #0x5576000
033a04b4: 88b27c39 ldrb     w8, [x20, #0xf2c]
033a04b8: c8000035 cbnz     w8, #0x33a04d0
033a04bc: 40f400f0 adrp     x0, #0x522b000
033a04c0: 00ac43f9 ldr      x0, [x0, #0x758]
033a04c4: 8f437097 bl       #0xfb1300
033a04c8: 28008052 mov      w8, #1
033a04cc: 88b23c39 strb     w8, [x20, #0xf2c]
033a04d0: 680340f9 ldr      x8, [x27]
033a04d4: 085d40f9 ldr      x8, [x8, #0xb8]
033a04d8: 0b31402d ldp      s11, s12, [x8]
033a04dc: 0d0940bd ldr      s13, [x8, #8]
033a04e0: e00313aa mov      x0, x19
033a04e4: 001da84e mov      v0.16b, v8.16b
033a04e8: dd010094 bl       #0x33a0c5c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$ArrangeScale
033a04ec: 680240f9 ldr      x8, [x19]
033a04f0: e00313aa mov      x0, x19
033a04f4: e01daf4e mov      v0.16b, v15.16b
033a04f8: 411daa4e mov      v1.16b, v10.16b
033a04fc: 092541f9 ldr      x9, [x8, #0x248]
033a0500: 012941f9 ldr      x1, [x8, #0x250]
033a0504: 221da94e mov      v2.16b, v9.16b
033a0508: 631dab4e mov      v3.16b, v11.16b
033a050c: 841dac4e mov      v4.16b, v12.16b
033a0510: a51dad4e mov      v5.16b, v13.16b
033a0514: 061da84e mov      v6.16b, v8.16b
033a0518: 0b1da84e mov      v11.16b, v8.16b
033a051c: 20013fd6 blr      x9
033a0520: 60000036 tbz      w0, #0, #0x33a052c
033a0524: 7f1600b9 str      wzr, [x19, #0x14]
033a0528: 6f010014 b        #0x33a0ae4
033a052c: 681640b9 ldr      w8, [x19, #0x14]
033a0530: 08050011 add      w8, w8, #1
033a0534: 1fb50071 cmp      w8, #0x2d
033a0538: 681600b9 str      w8, [x19, #0x14]
033a053c: 4b2d0054 b.lt     #0x33a0ae4
033a0540: 602e40f9 ldr      x0, [x19, #0x58]
033a0544: 203800b4 cbz      x0, #0x33a0c48
033a0548: e1031faa mov      x1, xzr
033a054c: dca72594 bl       #0x3d0a4bc ; UnityEngine.Transform$$get_parent
033a0550: 753240f9 ldr      x21, [x19, #0x60]
033a0554: b53700b4 cbz      x21, #0x33a0c48
033a0558: a80240f9 ldr      x8, [x21]
033a055c: e10240f9 ldr      x1, [x23]
033a0560: ed1740bd ldr      s13, [sp, #0x14]
033a0564: f40300aa mov      x20, x0
033a0568: 09554279 ldrh     w9, [x8, #0x12a]
033a056c: 290100b4 cbz      x9, #0x33a0590
033a0570: 0a5940f9 ldr      x10, [x8, #0xb0]
033a0574: 4a210091 add      x10, x10, #8
033a0578: 4b815ff8 ldur     x11, [x10, #-8]
033a057c: 7f0101eb cmp      x11, x1
033a0580: 00010054 b.eq     #0x33a05a0
033a0584: 290500f1 subs     x9, x9, #1
033a0588: 4a410091 add      x10, x10, #0x10
033a058c: 61ffff54 b.ne     #0x33a0578
033a0590: 22008052 mov      w2, #1
033a0594: e00315aa mov      x0, x21
033a0598: 4f836f97 bl       #0xf812d4
033a059c: 05000014 b        #0x33a05b0
033a05a0: 490140b9 ldr      w9, [x10]
033a05a4: 29050011 add      w9, w9, #1
033a05a8: 08d1298b add      x8, x8, w9, sxtw #4
033a05ac: 00e10491 add      x0, x8, #0x138
033a05b0: 080440a9 ldp      x8, x1, [x0]
033a05b4: e00315aa mov      x0, x21
033a05b8: 00013fd6 blr      x8
033a05bc: 743400b4 cbz      x20, #0x33a0c48
033a05c0: e00314aa mov      x0, x20
033a05c4: e1031faa mov      x1, xzr
033a05c8: efaa2594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
033a05cc: 602e40f9 ldr      x0, [x19, #0x58]
033a05d0: e20f00bd str      s2, [sp, #0xc]
033a05d4: a03300b4 cbz      x0, #0x33a0c48
033a05d8: 95f400b0 adrp     x21, #0x5231000
033a05dc: ddf20090 adrp     x29, #0x51f8000
033a05e0: 5cf00090 adrp     x28, #0x51a8000
033a05e4: baf300d0 adrp     x26, #0x5216000
033a05e8: 39f200d0 adrp     x25, #0x51e6000
033a05ec: b53a41f9 ldr      x21, [x21, #0x270]
033a05f0: bd0b47f9 ldr      x29, [x29, #0xe10]
033a05f4: 9cdf41f9 ldr      x28, [x28, #0x3b8]
033a05f8: 5a1f44f9 ldr      x26, [x26, #0x838]
033a05fc: 397b40f9 ldr      x25, [x25, #0xf0]
033a0600: e1031faa mov      x1, xzr
033a0604: 0c1ca04e mov      v12.16b, v0.16b
033a0608: 281ca14e mov      v8.16b, v1.16b
033a060c: 08a62594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
033a0610: 68424039 ldrb     w8, [x19, #0x10]
033a0614: 091ca04e mov      v9.16b, v0.16b
033a0618: 2f1ca14e mov      v15.16b, v1.16b
033a061c: 4a1ca24e mov      v10.16b, v2.16b
033a0620: ee1300bd str      s14, [sp, #0x10]
033a0624: e80f0034 cbz      w8, #0x33a0820
033a0628: 21008052 mov      w1, #1
033a062c: e00313aa mov      x0, x19
033a0630: 0e1da84e mov      v14.16b, v8.16b
033a0634: 881dac4e mov      v8.16b, v12.16b
033a0638: 1b020094 bl       #0x33a0ea4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TargetReached
033a063c: a00240f9 ldr      x0, [x21]
033a0640: c1008052 mov      w1, #6
033a0644: 4b437097 bl       #0xfb1370
033a0648: f40300aa mov      x20, x0
033a064c: 600340f9 ldr      x0, [x27]
033a0650: e1830191 add      x1, sp, #0x60
033a0654: e93f0c2d stp      s9, s15, [sp, #0x60]
033a0658: ea6b00bd str      s10, [sp, #0x68]
033a065c: 6c437097 bl       #0xfb140c
033a0660: 542f00b4 cbz      x20, #0x33a0c48
033a0664: eaa7432d ldp      s10, s9, [sp, #0x1c]
033a0668: ec1b40bd ldr      s12, [sp, #0x18]
033a066c: f50300aa mov      x21, x0
033a0670: c00000b4 cbz      x0, #0x33a0688
033a0674: 880240f9 ldr      x8, [x20]
033a0678: e00315aa mov      x0, x21
033a067c: 012140f9 ldr      x1, [x8, #0x40]
033a0680: 62437097 bl       #0xfb1408
033a0684: 602e00b4 cbz      x0, #0x33a0c50
033a0688: 881a40b9 ldr      w8, [x20, #0x18]
033a068c: 082e0034 cbz      w8, #0x33a0c4c
033a0690: e00314aa mov      x0, x20
033a0694: 150c02f8 str      x21, [x0, #0x20]!
033a0698: e10315aa mov      x1, x21
033a069c: 04437097 bl       #0xfb12ac
033a06a0: 600340f9 ldr      x0, [x27]
033a06a4: e1430191 add      x1, sp, #0x50
033a06a8: ec2b0a2d stp      s12, s10, [sp, #0x50]
033a06ac: ed5b00bd str      s13, [sp, #0x58]
033a06b0: 57437097 bl       #0xfb140c
033a06b4: f50300aa mov      x21, x0
033a06b8: c00000b4 cbz      x0, #0x33a06d0
033a06bc: 880240f9 ldr      x8, [x20]
033a06c0: e00315aa mov      x0, x21
033a06c4: 012140f9 ldr      x1, [x8, #0x40]
033a06c8: 50437097 bl       #0xfb1408
033a06cc: 202c00b4 cbz      x0, #0x33a0c50
033a06d0: 881a40b9 ldr      w8, [x20, #0x18]
033a06d4: 1f050071 cmp      w8, #1
033a06d8: a92b0054 b.ls     #0x33a0c4c
033a06dc: e00314aa mov      x0, x20
033a06e0: 158c02f8 str      x21, [x0, #0x28]!
033a06e4: e10315aa mov      x1, x21
033a06e8: f1427097 bl       #0xfb12ac
033a06ec: 600340f9 ldr      x0, [x27]
033a06f0: e00f40bd ldr      s0, [sp, #0xc]
033a06f4: e1030191 add      x1, sp, #0x40
033a06f8: e83b082d stp      s8, s14, [sp, #0x40]
033a06fc: e04b00bd str      s0, [sp, #0x48]
033a0700: 43437097 bl       #0xfb140c
033a0704: f50300aa mov      x21, x0
033a0708: c00000b4 cbz      x0, #0x33a0720
033a070c: 880240f9 ldr      x8, [x20]
033a0710: e00315aa mov      x0, x21
033a0714: 012140f9 ldr      x1, [x8, #0x40]
033a0718: 3c437097 bl       #0xfb1408
033a071c: a02900b4 cbz      x0, #0x33a0c50
033a0720: 881a40b9 ldr      w8, [x20, #0x18]
033a0724: ed1340bd ldr      s13, [sp, #0x10]
033a0728: 1f090071 cmp      w8, #2
033a072c: 09290054 b.ls     #0x33a0c4c
033a0730: e00314aa mov      x0, x20
033a0734: 150c03f8 str      x21, [x0, #0x30]!
033a0738: e10315aa mov      x1, x21
033a073c: dc427097 bl       #0xfb12ac
033a0740: 600340f9 ldr      x0, [x27]
033a0744: e02740bd ldr      s0, [sp, #0x24]
033a0748: e1c30091 add      x1, sp, #0x30
033a074c: ed3b00bd str      s13, [sp, #0x38]
033a0750: e903062d stp      s9, s0, [sp, #0x30]
033a0754: 2e437097 bl       #0xfb140c
033a0758: f50300aa mov      x21, x0
033a075c: c00000b4 cbz      x0, #0x33a0774
033a0760: 880240f9 ldr      x8, [x20]
033a0764: e00315aa mov      x0, x21
033a0768: 012140f9 ldr      x1, [x8, #0x40]
033a076c: 27437097 bl       #0xfb1408
033a0770: 002700b4 cbz      x0, #0x33a0c50
033a0774: 881a40b9 ldr      w8, [x20, #0x18]
033a0778: 1f0d0071 cmp      w8, #3
033a077c: 89260054 b.ls     #0x33a0c4c
033a0780: e00314aa mov      x0, x20
033a0784: 158c03f8 str      x21, [x0, #0x38]!
033a0788: e10315aa mov      x1, x21
033a078c: c8427097 bl       #0xfb12ac
033a0790: a00340f9 ldr      x0, [x29]
033a0794: e1b30091 add      x1, sp, #0x2c
033a0798: eb2f00bd str      s11, [sp, #0x2c]
033a079c: 1c437097 bl       #0xfb140c
033a07a0: f50300aa mov      x21, x0
033a07a4: c00000b4 cbz      x0, #0x33a07bc
033a07a8: 880240f9 ldr      x8, [x20]
033a07ac: e00315aa mov      x0, x21
033a07b0: 012140f9 ldr      x1, [x8, #0x40]
033a07b4: 15437097 bl       #0xfb1408
033a07b8: c02400b4 cbz      x0, #0x33a0c50
033a07bc: 881a40b9 ldr      w8, [x20, #0x18]
033a07c0: 1f110071 cmp      w8, #4
033a07c4: 49240054 b.ls     #0x33a0c4c
033a07c8: e00314aa mov      x0, x20
033a07cc: 150c04f8 str      x21, [x0, #0x40]!
033a07d0: e10315aa mov      x1, x21
033a07d4: b6427097 bl       #0xfb12ac
033a07d8: 686a40b9 ldr      w8, [x19, #0x68]
033a07dc: 800340f9 ldr      x0, [x28]
033a07e0: e1a30091 add      x1, sp, #0x28
033a07e4: e82b00b9 str      w8, [sp, #0x28]
033a07e8: 09437097 bl       #0xfb140c
033a07ec: f50300aa mov      x21, x0
033a07f0: c00000b4 cbz      x0, #0x33a0808
033a07f4: 880240f9 ldr      x8, [x20]
033a07f8: e00315aa mov      x0, x21
033a07fc: 012140f9 ldr      x1, [x8, #0x40]
033a0800: 02437097 bl       #0xfb1408
033a0804: 602200b4 cbz      x0, #0x33a0c50
033a0808: 881a40b9 ldr      w8, [x20, #0x18]
033a080c: 1f150071 cmp      w8, #5
033a0810: e9210054 b.ls     #0x33a0c4c
033a0814: 9bf300b0 adrp     x27, #0x5211000
033a0818: 7be740f9 ldr      x27, [x27, #0x1c8]
033a081c: 98000014 b        #0x33a0a7c
033a0820: 743240f9 ldr      x20, [x19, #0x60]
033a0824: 342100b4 cbz      x20, #0x33a0c48
033a0828: 880240f9 ldr      x8, [x20]
033a082c: e10240f9 ldr      x1, [x23]
033a0830: 09554279 ldrh     w9, [x8, #0x12a]
033a0834: 290100b4 cbz      x9, #0x33a0858
033a0838: 0a5940f9 ldr      x10, [x8, #0xb0]
033a083c: 4a210091 add      x10, x10, #8
033a0840: 4b815ff8 ldur     x11, [x10, #-8]
033a0844: 7f0101eb cmp      x11, x1
033a0848: 20010054 b.eq     #0x33a086c
033a084c: 290500f1 subs     x9, x9, #1
033a0850: 4a410091 add      x10, x10, #0x10
033a0854: 61ffff54 b.ne     #0x33a0840
033a0858: 62008052 mov      w2, #3
033a085c: e00314aa mov      x0, x20
033a0860: 0e1da84e mov      v14.16b, v8.16b
033a0864: 9c826f97 bl       #0xf812d4
033a0868: 06000014 b        #0x33a0880
033a086c: 490140b9 ldr      w9, [x10]
033a0870: 0e1da84e mov      v14.16b, v8.16b
033a0874: 290d0011 add      w9, w9, #3
033a0878: 08d1298b add      x8, x8, w9, sxtw #4
033a087c: 00e10491 add      x0, x8, #0x138
033a0880: 080440a9 ldp      x8, x1, [x0]
033a0884: e00314aa mov      x0, x20
033a0888: 881dac4e mov      v8.16b, v12.16b
033a088c: 00013fd6 blr      x8
033a0890: 28008052 mov      w8, #1
033a0894: 68420039 strb     w8, [x19, #0x10]
033a0898: 7f1600b9 str      wzr, [x19, #0x14]
033a089c: a00240f9 ldr      x0, [x21]
033a08a0: c1008052 mov      w1, #6
033a08a4: b3427097 bl       #0xfb1370
033a08a8: f40300aa mov      x20, x0
033a08ac: 600340f9 ldr      x0, [x27]
033a08b0: e1830191 add      x1, sp, #0x60
033a08b4: e93f0c2d stp      s9, s15, [sp, #0x60]
033a08b8: ea6b00bd str      s10, [sp, #0x68]
033a08bc: d4427097 bl       #0xfb140c
033a08c0: 541c00b4 cbz      x20, #0x33a0c48
033a08c4: eaa7432d ldp      s10, s9, [sp, #0x1c]
033a08c8: ec1b40bd ldr      s12, [sp, #0x18]
033a08cc: f50300aa mov      x21, x0
033a08d0: c00000b4 cbz      x0, #0x33a08e8
033a08d4: 880240f9 ldr      x8, [x20]
033a08d8: e00315aa mov      x0, x21
033a08dc: 012140f9 ldr      x1, [x8, #0x40]
033a08e0: ca427097 bl       #0xfb1408
033a08e4: 601b00b4 cbz      x0, #0x33a0c50
033a08e8: 881a40b9 ldr      w8, [x20, #0x18]
033a08ec: 081b0034 cbz      w8, #0x33a0c4c
033a08f0: e00314aa mov      x0, x20
033a08f4: 150c02f8 str      x21, [x0, #0x20]!
033a08f8: e10315aa mov      x1, x21
033a08fc: 6c427097 bl       #0xfb12ac
033a0900: 600340f9 ldr      x0, [x27]
033a0904: e1430191 add      x1, sp, #0x50
033a0908: ec2b0a2d stp      s12, s10, [sp, #0x50]
033a090c: ed5b00bd str      s13, [sp, #0x58]
033a0910: bf427097 bl       #0xfb140c
033a0914: f50300aa mov      x21, x0
033a0918: c00000b4 cbz      x0, #0x33a0930
033a091c: 880240f9 ldr      x8, [x20]
033a0920: e00315aa mov      x0, x21
033a0924: 012140f9 ldr      x1, [x8, #0x40]
033a0928: b8427097 bl       #0xfb1408
033a092c: 201900b4 cbz      x0, #0x33a0c50
033a0930: 881a40b9 ldr      w8, [x20, #0x18]
033a0934: 1f050071 cmp      w8, #1
033a0938: a9180054 b.ls     #0x33a0c4c
033a093c: e00314aa mov      x0, x20
033a0940: 158c02f8 str      x21, [x0, #0x28]!
033a0944: e10315aa mov      x1, x21
033a0948: 59427097 bl       #0xfb12ac
033a094c: 600340f9 ldr      x0, [x27]
033a0950: e00f40bd ldr      s0, [sp, #0xc]
033a0954: e1030191 add      x1, sp, #0x40
033a0958: e83b082d stp      s8, s14, [sp, #0x40]
033a095c: e04b00bd str      s0, [sp, #0x48]
033a0960: ab427097 bl       #0xfb140c
033a0964: f50300aa mov      x21, x0
033a0968: c00000b4 cbz      x0, #0x33a0980
033a096c: 880240f9 ldr      x8, [x20]
033a0970: e00315aa mov      x0, x21
033a0974: 012140f9 ldr      x1, [x8, #0x40]
033a0978: a4427097 bl       #0xfb1408
033a097c: a01600b4 cbz      x0, #0x33a0c50
033a0980: 881a40b9 ldr      w8, [x20, #0x18]
033a0984: e81340bd ldr      s8, [sp, #0x10]
033a0988: 1f090071 cmp      w8, #2
033a098c: 09160054 b.ls     #0x33a0c4c
033a0990: e00314aa mov      x0, x20
033a0994: 150c03f8 str      x21, [x0, #0x30]!
033a0998: e10315aa mov      x1, x21
033a099c: 44427097 bl       #0xfb12ac
033a09a0: 600340f9 ldr      x0, [x27]
033a09a4: e02740bd ldr      s0, [sp, #0x24]
033a09a8: e1c30091 add      x1, sp, #0x30
033a09ac: e83b00bd str      s8, [sp, #0x38]
033a09b0: e903062d stp      s9, s0, [sp, #0x30]
033a09b4: 96427097 bl       #0xfb140c
033a09b8: f50300aa mov      x21, x0
033a09bc: c00000b4 cbz      x0, #0x33a09d4
033a09c0: 880240f9 ldr      x8, [x20]
033a09c4: e00315aa mov      x0, x21
033a09c8: 012140f9 ldr      x1, [x8, #0x40]
033a09cc: 8f427097 bl       #0xfb1408
033a09d0: 001400b4 cbz      x0, #0x33a0c50
033a09d4: 881a40b9 ldr      w8, [x20, #0x18]
033a09d8: 1f0d0071 cmp      w8, #3
033a09dc: 89130054 b.ls     #0x33a0c4c
033a09e0: e00314aa mov      x0, x20
033a09e4: 158c03f8 str      x21, [x0, #0x38]!
033a09e8: e10315aa mov      x1, x21
033a09ec: 30427097 bl       #0xfb12ac
033a09f0: a00340f9 ldr      x0, [x29]
033a09f4: e1b30091 add      x1, sp, #0x2c
033a09f8: eb2f00bd str      s11, [sp, #0x2c]
033a09fc: 84427097 bl       #0xfb140c
033a0a00: f50300aa mov      x21, x0
033a0a04: c00000b4 cbz      x0, #0x33a0a1c
033a0a08: 880240f9 ldr      x8, [x20]
033a0a0c: e00315aa mov      x0, x21
033a0a10: 012140f9 ldr      x1, [x8, #0x40]
033a0a14: 7d427097 bl       #0xfb1408
033a0a18: c01100b4 cbz      x0, #0x33a0c50
033a0a1c: 881a40b9 ldr      w8, [x20, #0x18]
033a0a20: 1f110071 cmp      w8, #4
033a0a24: 49110054 b.ls     #0x33a0c4c
033a0a28: e00314aa mov      x0, x20
033a0a2c: 150c04f8 str      x21, [x0, #0x40]!
033a0a30: e10315aa mov      x1, x21
033a0a34: 1e427097 bl       #0xfb12ac
033a0a38: 686a40b9 ldr      w8, [x19, #0x68]
033a0a3c: 800340f9 ldr      x0, [x28]
033a0a40: e1a30091 add      x1, sp, #0x28
033a0a44: e82b00b9 str      w8, [sp, #0x28]
033a0a48: 71427097 bl       #0xfb140c
033a0a4c: f50300aa mov      x21, x0
033a0a50: c00000b4 cbz      x0, #0x33a0a68
033a0a54: 880240f9 ldr      x8, [x20]
033a0a58: e00315aa mov      x0, x21
033a0a5c: 012140f9 ldr      x1, [x8, #0x40]
033a0a60: 6a427097 bl       #0xfb1408
033a0a64: 600f00b4 cbz      x0, #0x33a0c50
033a0a68: 881a40b9 ldr      w8, [x20, #0x18]
033a0a6c: 1f150071 cmp      w8, #5
033a0a70: e90e0054 b.ls     #0x33a0c4c
033a0a74: dbf10090 adrp     x27, #0x51d8000
033a0a78: 7b4f44f9 ldr      x27, [x27, #0x898]
033a0a7c: e00314aa mov      x0, x20
033a0a80: 158c04f8 str      x21, [x0, #0x48]!
033a0a84: e10315aa mov      x1, x21
033a0a88: 09427097 bl       #0xfb12ac
033a0a8c: 600340f9 ldr      x0, [x27]
033a0a90: e10314aa mov      x1, x20
033a0a94: e2031faa mov      x2, xzr
033a0a98: a69ea597 bl       #0x1d08530 ; System.String$$Format
033a0a9c: 480340f9 ldr      x8, [x26]
033a0aa0: f50300aa mov      x21, x0
033a0aa4: e00308aa mov      x0, x8
033a0aa8: 5c427097 bl       #0xfb1418
033a0aac: e00c00b4 cbz      x0, #0x33a0c48
033a0ab0: e10315aa mov      x1, x21
033a0ab4: e2031faa mov      x2, xzr
033a0ab8: f40300aa mov      x20, x0
033a0abc: 011bbb97 bl       #0x22676c0 ; System.Exception$$.ctor
033a0ac0: 200340f9 ldr      x0, [x25]
033a0ac4: 08e040b9 ldr      w8, [x0, #0xe0]
033a0ac8: 48000035 cbnz     w8, #0x33a0ad0
033a0acc: 4e427097 bl       #0xfb1404
033a0ad0: 61018052 mov      w1, #0xb
033a0ad4: e00314aa mov      x0, x20
033a0ad8: e2031faa mov      x2, xzr
033a0adc: e3031faa mov      x3, xzr
033a0ae0: 41e3ea97 bl       #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
033a0ae4: 602e40f9 ldr      x0, [x19, #0x58]
033a0ae8: 000b00b4 cbz      x0, #0x33a0c48
033a0aec: e1031faa mov      x1, xzr
033a0af0: 81a42594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a0af4: 743240f9 ldr      x20, [x19, #0x60]
033a0af8: 940a00b4 cbz      x20, #0x33a0c48
033a0afc: 880240f9 ldr      x8, [x20]
033a0b00: e10240f9 ldr      x1, [x23]
033a0b04: 081ca04e mov      v8.16b, v0.16b
033a0b08: 291ca14e mov      v9.16b, v1.16b
033a0b0c: 09554279 ldrh     w9, [x8, #0x12a]
033a0b10: 4a1ca24e mov      v10.16b, v2.16b
033a0b14: 290100b4 cbz      x9, #0x33a0b38
033a0b18: 0a5940f9 ldr      x10, [x8, #0xb0]
033a0b1c: 4a210091 add      x10, x10, #8
033a0b20: 4b815ff8 ldur     x11, [x10, #-8]
033a0b24: 7f0101eb cmp      x11, x1
033a0b28: 00010054 b.eq     #0x33a0b48
033a0b2c: 290500f1 subs     x9, x9, #1
033a0b30: 4a410091 add      x10, x10, #0x10
033a0b34: 61ffff54 b.ne     #0x33a0b20
033a0b38: 22008052 mov      w2, #1
033a0b3c: e00314aa mov      x0, x20
033a0b40: e5816f97 bl       #0xf812d4
033a0b44: 05000014 b        #0x33a0b58
033a0b48: 490140b9 ldr      w9, [x10]
033a0b4c: 29050011 add      w9, w9, #1
033a0b50: 08d1298b add      x8, x8, w9, sxtw #4
033a0b54: 00e10491 add      x0, x8, #0x138
033a0b58: 080440a9 ldp      x8, x1, [x0]
033a0b5c: e00314aa mov      x0, x20
033a0b60: 00013fd6 blr      x8
033a0b64: c81a6039 ldrb     w8, [x22, #0x806]
033a0b68: 0b1ca04e mov      v11.16b, v0.16b
033a0b6c: 2c1ca14e mov      v12.16b, v1.16b
033a0b70: 4d1ca24e mov      v13.16b, v2.16b
033a0b74: c8000035 cbnz     w8, #0x33a0b8c
033a0b78: 00f30090 adrp     x0, #0x5200000
033a0b7c: 008c46f9 ldr      x0, [x0, #0xd18]
033a0b80: e0417097 bl       #0xfb1300
033a0b84: 28008052 mov      w8, #1
033a0b88: c81a2039 strb     w8, [x22, #0x806]
033a0b8c: 000340f9 ldr      x0, [x24]
033a0b90: 08e040b9 ldr      w8, [x0, #0xe0]
033a0b94: 48000035 cbnz     w8, #0x33a0b9c
033a0b98: 1b427097 bl       #0xfb1404
033a0b9c: 680240f9 ldr      x8, [x19]
033a0ba0: 6e1e40bd ldr      s14, [x19, #0x1c]
033a0ba4: e00313aa mov      x0, x19
033a0ba8: 091541f9 ldr      x9, [x8, #0x228]
033a0bac: 011941f9 ldr      x1, [x8, #0x230]
033a0bb0: 20013fd6 blr      x9
033a0bb4: c021201e fcmp     s14, s0
033a0bb8: 0b030054 b.lt     #0x33a0c18
033a0bbc: 00392b1e fsub     s0, s8, s11
033a0bc0: 21392c1e fsub     s1, s9, s12
033a0bc4: 42392d1e fsub     s2, s10, s13
033a0bc8: 0008201e fmul     s0, s0, s0
033a0bcc: 2108211e fmul     s1, s1, s1
033a0bd0: 285600f0 adrp     x8, #0x3e67000
033a0bd4: 0028211e fadd     s0, s0, s1
033a0bd8: 4108221e fmul     s1, s2, s2
033a0bdc: 024944bd ldr      s2, [x8, #0x448]
033a0be0: 2028201e fadd     s0, s1, s0
033a0be4: 08c0211e fsqrt    s8, s0
033a0be8: e103271e fmov     s1, wzr
033a0bec: 001da84e mov      v0.16b, v8.16b
033a0bf0: e0031faa mov      x0, xzr
033a0bf4: 5477fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
033a0bf8: 285600f0 adrp     x8, #0x3e67000
033a0bfc: 009544bd ldr      s0, [x8, #0x494]
033a0c00: 0021201e fcmp     s8, s0
033a0c04: 44000054 b.mi     #0x33a0c0c
033a0c08: 80000036 tbz      w0, #0, #0x33a0c18
033a0c0c: e00313aa mov      x0, x19
033a0c10: e1031f2a mov      w1, wzr
033a0c14: a4000094 bl       #0x33a0ea4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TargetReached
033a0c18: fd7b50a9 ldp      x29, x30, [sp, #0x100]
033a0c1c: f44f4fa9 ldp      x20, x19, [sp, #0xf0]
033a0c20: f6574ea9 ldp      x22, x21, [sp, #0xe0]
033a0c24: f85f4da9 ldp      x24, x23, [sp, #0xd0]
033a0c28: fa674ca9 ldp      x26, x25, [sp, #0xc0]
033a0c2c: fc6f4ba9 ldp      x28, x27, [sp, #0xb0]
033a0c30: e9234a6d ldp      d9, d8, [sp, #0xa0]
033a0c34: eb2b496d ldp      d11, d10, [sp, #0x90]
033a0c38: ed33486d ldp      d13, d12, [sp, #0x80]
033a0c3c: ef3b476d ldp      d15, d14, [sp, #0x70]
033a0c40: ff430491 add      sp, sp, #0x110
033a0c44: c0035fd6 ret      
033a0c48: f8417097 bl       #0xfb1428
033a0c4c: f9417097 bl       #0xfb1430
033a0c50: ff417097 bl       #0xfb144c
033a0c54: e1031faa mov      x1, xzr
033a0c58: e6417097 bl       #0xfb13f0
