# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeRotation
# Linear span to next metadata entry; not a complete CFG.
0339a684: ef3bb96d stp      d15, d14, [sp, #-0x70]!
0339a688: ed33016d stp      d13, d12, [sp, #0x10]
0339a68c: eb2b026d stp      d11, d10, [sp, #0x20]
0339a690: e923036d stp      d9, d8, [sp, #0x30]
0339a694: f62300f9 str      x22, [sp, #0x40]
0339a698: f55305a9 stp      x21, x20, [sp, #0x50]
0339a69c: f37b06a9 stp      x19, x30, [sp, #0x60]
0339a6a0: 681ca34e mov      v8.16b, v3.16b
0339a6a4: 038440bd ldr      s3, [x0, #0x84]
0339a6a8: 685600b0 adrp     x8, #0x3e67000
0339a6ac: 024944bd ldr      s2, [x8, #0x448]
0339a6b0: ec7340bd ldr      s12, [sp, #0x70]
0339a6b4: ea8340bd ldr      s10, [sp, #0x80]
0339a6b8: f30300aa mov      x19, x0
0339a6bc: 091ca04e mov      v9.16b, v0.16b
0339a6c0: e103271e fmov     s1, wzr
0339a6c4: 601ca34e mov      v0.16b, v3.16b
0339a6c8: e0031faa mov      x0, xzr
0339a6cc: ed03271e fmov     s13, wzr
0339a6d0: 9d90fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339a6d4: c85600b0 adrp     x8, #0x3e73000
0339a6d8: 02554abd ldr      s2, [x8, #0xa54]
0339a6dc: 1f000072 tst      w0, #1
0339a6e0: 0e102e1e fmov     s14, #1.00000000
0339a6e4: 211d281e fcsel    s1, s9, s8, ne
0339a6e8: 4229221e fadd     s2, s10, s2
0339a6ec: 43582e1e fmin     s3, s2, s14
0339a6f0: 4820201e fcmp     s2, #0.0
0339a6f4: 0090261e fmov     s0, #20.00000000
0339a6f8: 6b5c2d1e fcsel    s11, s3, s13, pl
0339a6fc: 2008201e fmul     s0, s1, s0
0339a700: 62292d1e fadd     s2, s11, s13
0339a704: 4008201e fmul     s0, s2, s0
0339a708: 0f102c1e fmov     s15, #0.50000000
0339a70c: 894bb852 mov      w9, #-0x3da40000
0339a710: 00282e1e fadd     s0, s0, s14
0339a714: 2101271e fmov     s1, w9
0339a718: 699640b9 ldr      w9, [x19, #0x94]
0339a71c: 00082f1e fmul     s0, s0, s15
0339a720: 8841a852 mov      w8, #0x420c0000
0339a724: 0820201e fcmp     s0, #0.0
0339a728: 00582e1e fmin     s0, s0, s14
0339a72c: 0201271e fmov     s2, w8
0339a730: 683240f9 ldr      x8, [x19, #0x60]
0339a734: 0008211e fmul     s0, s0, s1
0339a738: 0028221e fadd     s0, s0, s2
0339a73c: 005c221e fcsel    s0, s0, s2, pl
0339a740: 3f090071 cmp      w9, #2
0339a744: a80d201e fcsel    s8, s13, s0, eq
0339a748: e81000b4 cbz      x8, #0x339a964
0339a74c: 004d40f9 ldr      x0, [x8, #0x98]
0339a750: a01000b4 cbz      x0, #0x339a964
0339a754: e1031faa mov      x1, xzr
0339a758: 03be2594 bl       #0x3d09f64 ; UnityEngine.Transform$$get_eulerAngles
0339a75c: 6a5b00f0 adrp     x10, #0x3f09000
0339a760: 4b5b00f0 adrp     x11, #0x3f05000
0339a764: 437d48bd ldr      s3, [x10, #0x87c]
0339a768: 8876b852 mov      w8, #-0x3c4c0000
0339a76c: 8966a852 mov      w9, #0x43340000
0339a770: 6df14cbd ldr      s13, [x11, #0xcf0]
0339a774: 0001271e fmov     s0, w8
0339a778: 2101271e fmov     s1, w9
0339a77c: 4028201e fadd     s0, s2, s0
0339a780: 4020211e fcmp     s2, s1
0339a784: 09cc221e fcsel    s9, s0, s2, gt
0339a788: 6009231e fmul     s0, s11, s3
0339a78c: e0031faa mov      x0, xzr
0339a790: 0a282d1e fadd     s10, s0, s13
0339a794: 74f20191 add      x20, x19, #0x7c
0339a798: 138e2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339a79c: 08f0af52 mov      w8, #0x7f800000
0339a7a0: 041ca04e mov      v4.16b, v0.16b
0339a7a4: 0301271e fmov     s3, w8
0339a7a8: 201da94e mov      v0.16b, v9.16b
0339a7ac: 011da84e mov      v1.16b, v8.16b
0339a7b0: e00314aa mov      x0, x20
0339a7b4: 421daa4e mov      v2.16b, v10.16b
0339a7b8: e1031faa mov      x1, xzr
0339a7bc: 04c50594 bl       #0x350bbcc ; UnityEngine.Mathf$$SmoothDamp
0339a7c0: 683240f9 ldr      x8, [x19, #0x60]
0339a7c4: 080d00b4 cbz      x8, #0x339a964
0339a7c8: f50e01d0 adrp     x21, #0x5578000
0339a7cc: a96e4539 ldrb     w9, [x21, #0x15b]
0339a7d0: 144d40f9 ldr      x20, [x8, #0x98]
0339a7d4: 081ca04e mov      v8.16b, v0.16b
0339a7d8: c9000035 cbnz     w9, #0x339a7f0
0339a7dc: 80f400b0 adrp     x0, #0x522b000
0339a7e0: 00ac43f9 ldr      x0, [x0, #0x758]
0339a7e4: c75a7097 bl       #0xfb1300
0339a7e8: 28008052 mov      w8, #1
0339a7ec: a86e0539 strb     w8, [x21, #0x15b]
0339a7f0: 96f400b0 adrp     x22, #0x522b000
0339a7f4: d6ae43f9 ldr      x22, [x22, #0x758]
0339a7f8: 001da84e mov      v0.16b, v8.16b
0339a7fc: e0031faa mov      x0, xzr
0339a800: c80240f9 ldr      x8, [x22]
0339a804: 085d40f9 ldr      x8, [x8, #0xb8]
0339a808: 0109492d ldp      s1, s2, [x8, #0x48]
0339a80c: 035140bd ldr      s3, [x8, #0x50]
0339a810: 58ac0594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339a814: 940a00b4 cbz      x20, #0x339a964
0339a818: e00314aa mov      x0, x20
0339a81c: e1031faa mov      x1, xzr
0339a820: ffbd2594 bl       #0x3d0a01c ; UnityEngine.Transform$$set_rotation
0339a824: 80292e1e fadd     s0, s12, s14
0339a828: 00082f1e fmul     s0, s0, s15
0339a82c: 0110261e fmov     s1, #16.00000000
0339a830: 683240f9 ldr      x8, [x19, #0x60]
0339a834: 03582e1e fmin     s3, s0, s14
0339a838: 0210341e fmov     s2, #-8.00000000
0339a83c: 6108211e fmul     s1, s3, s1
0339a840: 2128221e fadd     s1, s1, s2
0339a844: 0820201e fcmp     s0, #0.0
0339a848: 285c221e fcsel    s8, s1, s2, pl
0339a84c: c80800b4 cbz      x8, #0x339a964
0339a850: 006140f9 ldr      x0, [x8, #0xc0]
0339a854: 800800b4 cbz      x0, #0x339a964
0339a858: e1031faa mov      x1, xzr
0339a85c: 11be2594 bl       #0x3d0a0a0 ; UnityEngine.Transform$$get_localRotation
0339a860: e0031faa mov      x0, xzr
0339a864: 50aa0594 bl       #0x35051a4 ; UnityEngine.Quaternion$$Internal_ToEulerRad
0339a868: c85600b0 adrp     x8, #0x3e73000
0339a86c: 03914bbd ldr      s3, [x8, #0xb90]
0339a870: e0031faa mov      x0, xzr
0339a874: 0008231e fmul     s0, s0, s3
0339a878: 2108231e fmul     s1, s1, s3
0339a87c: 4208231e fmul     s2, s2, s3
0339a880: 1caa0594 bl       #0x35050f0 ; UnityEngine.Quaternion$$Internal_MakePositive
0339a884: 689640b9 ldr      w8, [x19, #0x94]
0339a888: 695b00f0 adrp     x9, #0x3f09000
0339a88c: 208148bd ldr      s0, [x9, #0x880]
0339a890: e103271e fmov     s1, wzr
0339a894: 1f090071 cmp      w8, #2
0339a898: 8876b852 mov      w8, #-0x3c4c0000
0339a89c: 210c221e fcsel    s1, s1, s2, eq
0339a8a0: 0201271e fmov     s2, w8
0339a8a4: 8866a852 mov      w8, #0x43340000
0339a8a8: 0301271e fmov     s3, w8
0339a8ac: 6009201e fmul     s0, s11, s0
0339a8b0: 2228221e fadd     s2, s1, s2
0339a8b4: 2020231e fcmp     s1, s3
0339a8b8: e0031faa mov      x0, xzr
0339a8bc: 09282d1e fadd     s9, s0, s13
0339a8c0: 4acc211e fcsel    s10, s2, s1, gt
0339a8c4: 74020291 add      x20, x19, #0x80
0339a8c8: c78d2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339a8cc: 08f0af52 mov      w8, #0x7f800000
0339a8d0: 041ca04e mov      v4.16b, v0.16b
0339a8d4: 0301271e fmov     s3, w8
0339a8d8: 401daa4e mov      v0.16b, v10.16b
0339a8dc: 011da84e mov      v1.16b, v8.16b
0339a8e0: e00314aa mov      x0, x20
0339a8e4: 221da94e mov      v2.16b, v9.16b
0339a8e8: e1031faa mov      x1, xzr
0339a8ec: b8c40594 bl       #0x350bbcc ; UnityEngine.Mathf$$SmoothDamp
0339a8f0: 683240f9 ldr      x8, [x19, #0x60]
0339a8f4: 880300b4 cbz      x8, #0x339a964
0339a8f8: a96e4539 ldrb     w9, [x21, #0x15b]
0339a8fc: 136140f9 ldr      x19, [x8, #0xc0]
0339a900: 081ca04e mov      v8.16b, v0.16b
0339a904: c9000035 cbnz     w9, #0x339a91c
0339a908: 80f400b0 adrp     x0, #0x522b000
0339a90c: 00ac43f9 ldr      x0, [x0, #0x758]
0339a910: 7c5a7097 bl       #0xfb1300
0339a914: 28008052 mov      w8, #1
0339a918: a86e0539 strb     w8, [x21, #0x15b]
0339a91c: c80240f9 ldr      x8, [x22]
0339a920: 001da84e mov      v0.16b, v8.16b
0339a924: e0031faa mov      x0, xzr
0339a928: 085d40f9 ldr      x8, [x8, #0xb8]
0339a92c: 0109492d ldp      s1, s2, [x8, #0x48]
0339a930: 035140bd ldr      s3, [x8, #0x50]
0339a934: 0fac0594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339a938: 730100b4 cbz      x19, #0x339a964
0339a93c: e00313aa mov      x0, x19
0339a940: f37b46a9 ldp      x19, x30, [sp, #0x60]
0339a944: f55345a9 ldp      x21, x20, [sp, #0x50]
0339a948: f62340f9 ldr      x22, [sp, #0x40]
0339a94c: e923436d ldp      d9, d8, [sp, #0x30]
0339a950: eb2b426d ldp      d11, d10, [sp, #0x20]
0339a954: ed33416d ldp      d13, d12, [sp, #0x10]
0339a958: e1031faa mov      x1, xzr
0339a95c: ef3bc76c ldp      d15, d14, [sp], #0x70
0339a960: f2bd2514 b        #0x3d0a128 ; UnityEngine.Transform$$set_localRotation
0339a964: b15a7097 bl       #0xfb1428
