# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_EndFallAltStateId
# Linear span to next metadata entry; not a complete CFG.
0339819c: f40f1ef8 str      x20, [sp, #-0x20]!
033981a0: f37b01a9 stp      x19, x30, [sp, #0x10]
033981a4: 740f01d0 adrp     x20, #0x5586000
033981a8: f3f10090 adrp     x19, #0x51d4000
033981ac: 88666639 ldrb     w8, [x20, #0x999]
033981b0: 73da41f9 ldr      x19, [x19, #0x3b0]
033981b4: c8000037 tbnz     w8, #0, #0x33981cc
033981b8: e0f10090 adrp     x0, #0x51d4000
033981bc: 00d841f9 ldr      x0, [x0, #0x3b0]
033981c0: 50647097 bl       #0xfb1300
033981c4: 28008052 mov      w8, #1
033981c8: 88662639 strb     w8, [x20, #0x999]
033981cc: 600240f9 ldr      x0, [x19]
033981d0: 08e040b9 ldr      w8, [x0, #0xe0]
033981d4: 68000035 cbnz     w8, #0x33981e0
033981d8: 8b647097 bl       #0xfb1404
033981dc: 600240f9 ldr      x0, [x19]
033981e0: 085c40f9 ldr      x8, [x0, #0xb8]
033981e4: f37b41a9 ldp      x19, x30, [sp, #0x10]
033981e8: 001540b9 ldr      w0, [x8, #0x14]
033981ec: f40742f8 ldr      x20, [sp], #0x20
033981f0: c0035fd6 ret      
