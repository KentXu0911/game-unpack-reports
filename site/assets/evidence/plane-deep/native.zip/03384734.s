# Royal.Scenes.Game.Mechanics.Items.ConveyorBeltItem.ConveyorBeltItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03384734: f75bbda9 stp      x23, x22, [sp, #-0x30]!
03384738: f55301a9 stp      x21, x20, [sp, #0x10]
0338473c: f37b02a9 stp      x19, x30, [sp, #0x20]
03384740: 080040f9 ldr      x8, [x0]
03384744: f403012a mov      w20, w1
03384748: f30300aa mov      x19, x0
0338474c: 096542f9 ldr      x9, [x8, #0x4c8]
03384750: 086942f9 ldr      x8, [x8, #0x4d0]
03384754: e10308aa mov      x1, x8
03384758: 20013fd6 blr      x9
0338475c: 686a40b9 ldr      w8, [x19, #0x68]
03384760: c8080034 cbz      w8, #0x3384878
03384764: f503002a mov      w21, w0
03384768: 9f220071 cmp      w20, #8
0338476c: 60000054 b.eq     #0x3384778
03384770: 9f1a0071 cmp      w20, #6
03384774: a1010054 b.ne     #0x33847a8
03384778: 680240f9 ldr      x8, [x19]
0338477c: e00313aa mov      x0, x19
03384780: 095542f9 ldr      x9, [x8, #0x4a8]
03384784: 015942f9 ldr      x1, [x8, #0x4b0]
03384788: 20013fd6 blr      x9
0338478c: e803002a mov      w8, w0
03384790: bf060071 cmp      w21, #1
03384794: e0031f2a mov      w0, wzr
03384798: ab0b0054 b.lt     #0x338490c
0338479c: 1f010071 cmp      w8, #0
033847a0: 8c000054 b.gt     #0x33847b0
033847a4: 5a000014 b        #0x338490c
033847a8: bf060071 cmp      w21, #1
033847ac: 6b060054 b.lt     #0x3384878
033847b0: 9f1e0071 cmp      w20, #7
033847b4: a8060054 b.hi     #0x3384888
033847b8: 28008052 mov      w8, #1
033847bc: 0821d41a lsl      w8, w8, w20
033847c0: 29168052 mov      w9, #0xb1
033847c4: 1f01096a tst      w8, w9
033847c8: c0050054 b.eq     #0x3384880
033847cc: 605e40f9 ldr      x0, [x19, #0xb8]
033847d0: 600a00b4 cbz      x0, #0x338491c
033847d4: 61ca40b9 ldr      w1, [x19, #0xc8]
033847d8: e2031faa mov      x2, xzr
033847dc: beacf497 bl       #0x30afad4 ; Royal.Scenes.Game.Mechanics.Items.ConveyorBeltItem.ConveyorBeltHelper$$SingleBoxOrJarLeft
033847e0: 00050036 tbz      w0, #0, #0x3384880
033847e4: 605e40f9 ldr      x0, [x19, #0xb8]
033847e8: a00900b4 cbz      x0, #0x338491c
033847ec: 61ca40b9 ldr      w1, [x19, #0xc8]
033847f0: e2031faa mov      x2, xzr
033847f4: 30acf497 bl       #0x30af8b4 ; Royal.Scenes.Game.Mechanics.Items.ConveyorBeltItem.ConveyorBeltHelper$$GetTotalRemainingExplodeCount
033847f8: 680240f9 ldr      x8, [x19]
033847fc: f403002a mov      w20, w0
03384800: e00313aa mov      x0, x19
03384804: 09bd41f9 ldr      x9, [x8, #0x378]
03384808: 01c141f9 ldr      x1, [x8, #0x380]
0338480c: 20013fd6 blr      x9
03384810: 680240f9 ldr      x8, [x19]
03384814: f503002a mov      w21, w0
03384818: e00313aa mov      x0, x19
0338481c: 09bd41f9 ldr      x9, [x8, #0x378]
03384820: 01c141f9 ldr      x1, [x8, #0x380]
03384824: 20013fd6 blr      x9
03384828: 765e40f9 ldr      x22, [x19, #0xb8]
0338482c: 960700b4 cbz      x22, #0x338491c
03384830: 73ca40b9 ldr      w19, [x19, #0xc8]
03384834: 55000094 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03384838: f703002a mov      w23, w0
0338483c: e003152a mov      w0, w21
03384840: 52000094 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03384844: f503002a mov      w21, w0
03384848: e00316aa mov      x0, x22
0338484c: e103132a mov      w1, w19
03384850: e2031faa mov      x2, xzr
03384854: 88aef497 bl       #0x30b0274 ; Royal.Scenes.Game.Mechanics.Items.ConveyorBeltItem.ConveyorBeltHelper$$GetShelfTotalSize
03384858: 08040051 sub      w8, w0, #1
0338485c: 9f0a0071 cmp      w20, #2
03384860: 69008052 mov      w9, #3
03384864: 087d171b mul      w8, w8, w23
03384868: 29b5891a cinc     w9, w9, ge
0338486c: 080dc91a sdiv     w8, w8, w9
03384870: 0001150b add      w0, w8, w21
03384874: 26000014 b        #0x338490c
03384878: e0031f2a mov      w0, wzr
0338487c: 24000014 b        #0x338490c
03384880: 9f0e0071 cmp      w20, #3
03384884: 60000054 b.eq     #0x3384890
03384888: 9f1a0071 cmp      w20, #6
0338488c: e1000054 b.ne     #0x33848a8
03384890: 602a40f9 ldr      x0, [x19, #0x50]
03384894: 400400b4 cbz      x0, #0x338491c
03384898: 61c242f8 ldur     x1, [x19, #0x2c]
0338489c: e2031faa mov      x2, xzr
033848a0: 1c3fcf97 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
033848a4: 04000014 b        #0x33848b4
033848a8: 601e40f9 ldr      x0, [x19, #0x38]
033848ac: 800300b4 cbz      x0, #0x338491c
033848b0: f71d0094 bl       #0x338c08c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemMediator$$get_CurrentCell
033848b4: f50300aa mov      x21, x0
033848b8: 605e40f9 ldr      x0, [x19, #0xb8]
033848bc: 000300b4 cbz      x0, #0x338491c
033848c0: 61ca40b9 ldr      w1, [x19, #0xc8]
033848c4: e2031faa mov      x2, xzr
033848c8: 0cadf497 bl       #0x30afcf8 ; Royal.Scenes.Game.Mechanics.Items.ConveyorBeltItem.ConveyorBeltHelper$$GetConveyorBeltItems
033848cc: a4608a52 mov      w4, #0x5305
033848d0: e10300aa mov      x1, x0
033848d4: 4400a072 movk     w4, #2, lsl #16
033848d8: 05008012 mov      w5, #-1
033848dc: e00313aa mov      x0, x19
033848e0: e20315aa mov      x2, x21
033848e4: e303142a mov      w3, w20
033848e8: 38000094 bl       #0x33849c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetItemExplodeExtraScore
033848ec: 680240f9 ldr      x8, [x19]
033848f0: f403002a mov      w20, w0
033848f4: e00313aa mov      x0, x19
033848f8: 09bd41f9 ldr      x9, [x8, #0x378]
033848fc: 01c141f9 ldr      x1, [x8, #0x380]
03384900: 20013fd6 blr      x9
03384904: 21000094 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03384908: 0000140b add      w0, w0, w20
0338490c: f37b42a9 ldp      x19, x30, [sp, #0x20]
03384910: f55341a9 ldp      x21, x20, [sp, #0x10]
03384914: f75bc3a8 ldp      x23, x22, [sp], #0x30
03384918: c0035fd6 ret      
0338491c: c3b27097 bl       #0xfb1428
