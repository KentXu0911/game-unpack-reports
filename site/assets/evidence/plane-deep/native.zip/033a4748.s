# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy.<FinishOperationWithDelay>d__11$$System.Collections.IEnumerator.get_Current
# Linear span to next metadata entry; not a complete CFG.
033a4748: 000c40f9 ldr      x0, [x0, #0x18]
033a474c: c0035fd6 ret      
