# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$HasMasterId
# Linear span to next metadata entry; not a complete CFG.
026a7bb8: f553bea9 stp      x21, x20, [sp, #-0x20]!
026a7bbc: f37b01a9 stp      x19, x30, [sp, #0x10]
026a7bc0: d57601b0 adrp     x21, #0x5580000
026a7bc4: a88e4139 ldrb     w8, [x21, #0x63]
026a7bc8: f303012a mov      w19, w1
026a7bcc: f40300aa mov      x20, x0
026a7bd0: c8000037 tbnz     w8, #0, #0x26a7be8
026a7bd4: 605901b0 adrp     x0, #0x51d4000
026a7bd8: 004845f9 ldr      x0, [x0, #0xa90]
026a7bdc: c925a497 bl       #0xfb1300
026a7be0: 28008052 mov      w8, #1
026a7be4: a88e0139 strb     w8, [x21, #0x63]
026a7be8: 801e40f9 ldr      x0, [x20, #0x38]
026a7bec: 000100b4 cbz      x0, #0x26a7c0c
026a7bf0: 685901b0 adrp     x8, #0x51d4000
026a7bf4: 084945f9 ldr      x8, [x8, #0xa90]
026a7bf8: e103132a mov      w1, w19
026a7bfc: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a7c00: 020140f9 ldr      x2, [x8]
026a7c04: f553c2a8 ldp      x21, x20, [sp], #0x20
026a7c08: 29840e14 b        #0x2a48cac ; System.Collections.Generic.HashSet<int>$$Contains
026a7c0c: 0726a497 bl       #0xfb1428
