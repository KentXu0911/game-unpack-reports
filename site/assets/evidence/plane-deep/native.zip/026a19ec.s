# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$set_ItemView
# Linear span to next metadata entry; not a complete CFG.
026a19ec: 018c0cf8 str      x1, [x0, #0xc8]!
026a19f0: 2f3ea417 b        #0xfb12ac
