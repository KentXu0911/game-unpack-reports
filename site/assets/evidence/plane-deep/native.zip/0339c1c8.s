# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeScaleDown
# Linear span to next metadata entry; not a complete CFG.
0339c1c8: ffc301d1 sub      sp, sp, #0x70
0339c1cc: ed33026d stp      d13, d12, [sp, #0x20]
0339c1d0: eb2b036d stp      d11, d10, [sp, #0x30]
0339c1d4: e923046d stp      d9, d8, [sp, #0x40]
0339c1d8: f42b00f9 str      x20, [sp, #0x50]
0339c1dc: f37b06a9 stp      x19, x30, [sp, #0x60]
0339c1e0: 540f01d0 adrp     x20, #0x5586000
0339c1e4: 88b26639 ldrb     w8, [x20, #0x9ac]
0339c1e8: f30300aa mov      x19, x0
0339c1ec: e00b00fd str      d0, [sp, #0x10]
0339c1f0: c8000037 tbnz     w8, #0, #0x339c208
0339c1f4: c0f200f0 adrp     x0, #0x51f7000
0339c1f8: 00f844f9 ldr      x0, [x0, #0x9f0]
0339c1fc: 41547097 bl       #0xfb1300
0339c200: 28008052 mov      w8, #1
0339c204: 88b22639 strb     w8, [x20, #0x9ac]
0339c208: d40e01d0 adrp     x20, #0x5576000
0339c20c: 694244fc ldur     d9, [x19, #0x44]
0339c210: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339c214: 6a4e40bd ldr      s10, [x19, #0x4c]
0339c218: c8000035 cbnz     w8, #0x339c230
0339c21c: 60f400f0 adrp     x0, #0x522b000
0339c220: 00ac43f9 ldr      x0, [x0, #0x758]
0339c224: 37547097 bl       #0xfb1300
0339c228: 28008052 mov      w8, #1
0339c22c: 88b23c39 strb     w8, [x20, #0xf2c]
0339c230: 68f400f0 adrp     x8, #0x522b000
0339c234: 08ad43f9 ldr      x8, [x8, #0x758]
0339c238: 140f01b0 adrp     x20, #0x557d000
0339c23c: 89ba5f39 ldrb     w9, [x20, #0x7ee]
0339c240: 080140f9 ldr      x8, [x8]
0339c244: 085d40f9 ldr      x8, [x8, #0xb8]
0339c248: 030140fd ldr      d3, [x8]
0339c24c: 080940bd ldr      s8, [x8, #8]
0339c250: 09010035 cbnz     w9, #0x339c270
0339c254: 20f30090 adrp     x0, #0x5200000
0339c258: 008c46f9 ldr      x0, [x0, #0xd18]
0339c25c: e303803d str      q3, [sp]
0339c260: 28547097 bl       #0xfb1300
0339c264: e303c03d ldr      q3, [sp]
0339c268: 28008052 mov      w8, #1
0339c26c: 88ba1f39 strb     w8, [x20, #0x7ee]
0339c270: 6bd4a90e fsub     v11.2s, v3.2s, v9.2s
0339c274: d4f200f0 adrp     x20, #0x51f7000
0339c278: 0c392a1e fsub     s12, s8, s10
0339c27c: 60dd2b2e fmul     v0.2s, v11.2s, v11.2s
0339c280: 94fa44f9 ldr      x20, [x20, #0x9f0]
0339c284: 00d8307e faddp    s0, v0.2s
0339c288: 81092c1e fmul     s1, s12, s12
0339c28c: 2d28201e fadd     s13, s1, s0
0339c290: a821201e fcmp     s13, #0.0
0339c294: e0020054 b.eq     #0x339c2f0
0339c298: e007c03d ldr      q0, [sp, #0x10]
0339c29c: 0820201e fcmp     s0, #0.0
0339c2a0: ab000054 b.lt     #0x339c2b4
0339c2a4: e007c03d ldr      q0, [sp, #0x10]
0339c2a8: 0008201e fmul     s0, s0, s0
0339c2ac: a021201e fcmp     s13, s0
0339c2b0: 09020054 b.ls     #0x339c2f0
0339c2b4: 28f30090 adrp     x8, #0x5200000
0339c2b8: 088d46f9 ldr      x8, [x8, #0xd18]
0339c2bc: 000140f9 ldr      x0, [x8]
0339c2c0: 08e040b9 ldr      w8, [x0, #0xe0]
0339c2c4: 48000035 cbnz     w8, #0x339c2cc
0339c2c8: 4f547097 bl       #0xfb1404
0339c2cc: e207c03d ldr      q2, [sp, #0x10]
0339c2d0: a0c1211e fsqrt    s0, s13
0339c2d4: 0104040e dup      v1.2s, v0.s[0]
0339c2d8: 8019201e fdiv     s0, s12, s0
0339c2dc: 61fd212e fdiv     v1.2s, v11.2s, v1.2s
0339c2e0: 0008221e fmul     s0, s0, s2
0339c2e4: 2190820f fmul     v1.2s, v1.2s, v2.s[0]
0339c2e8: 23d5210e fadd     v3.2s, v9.2s, v1.2s
0339c2ec: 4829201e fadd     s8, s10, s0
0339c2f0: 800240f9 ldr      x0, [x20]
0339c2f4: 08e040b9 ldr      w8, [x0, #0xe0]
0339c2f8: a8000035 cbnz     w8, #0x339c30c
0339c2fc: e303803d str      q3, [sp]
0339c300: 41547097 bl       #0xfb1404
0339c304: e303c03d ldr      q3, [sp]
0339c308: 800240f9 ldr      x0, [x20]
0339c30c: 085c40f9 ldr      x8, [x0, #0xb8]
0339c310: 61040c5e mov      s1, v3.s[1]
0339c314: 0009402d ldp      s0, s2, [x8]
0339c318: 686a40f9 ldr      x8, [x19, #0xd0]
0339c31c: 6020201e fcmp     s3, s0
0339c320: 694c201e fcsel    s9, s3, s0, mi
0339c324: 2020221e fcmp     s1, s2
0339c328: 2acc221e fcsel    s10, s1, s2, gt
0339c32c: 880200b4 cbz      x8, #0x339c37c
0339c330: 004140f9 ldr      x0, [x8, #0x80]
0339c334: 400200b4 cbz      x0, #0x339c37c
0339c338: e1031faa mov      x1, xzr
0339c33c: 9b9a2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339c340: e00100b4 cbz      x0, #0x339c37c
0339c344: 201da94e mov      v0.16b, v9.16b
0339c348: 411daa4e mov      v1.16b, v10.16b
0339c34c: 021da84e mov      v2.16b, v8.16b
0339c350: e1031faa mov      x1, xzr
0339c354: deb62594 bl       #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
0339c358: e00313aa mov      x0, x19
0339c35c: f37b46a9 ldp      x19, x30, [sp, #0x60]
0339c360: f42b40f9 ldr      x20, [sp, #0x50]
0339c364: e923446d ldp      d9, d8, [sp, #0x40]
0339c368: eb2b436d ldp      d11, d10, [sp, #0x30]
0339c36c: ed33426d ldp      d13, d12, [sp, #0x20]
0339c370: e007c03d ldr      q0, [sp, #0x10]
0339c374: ffc30191 add      sp, sp, #0x70
0339c378: 8cf9ff17 b        #0x339a9a8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScaleDown
0339c37c: 2b547097 bl       #0xfb1428
