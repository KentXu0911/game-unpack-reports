# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$get_ShouldPlaySfxInLoop
# Linear span to next metadata entry; not a complete CFG.
0339ff18: 20008052 mov      w0, #1
0339ff1c: c0035fd6 ret      
