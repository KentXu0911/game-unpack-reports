# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ShouldRedirectForIceCube
# Linear span to next metadata entry; not a complete CFG.
033a303c: f60f1df8 str      x22, [sp, #-0x30]!
033a3040: f55301a9 stp      x21, x20, [sp, #0x10]
033a3044: f37b02a9 stp      x19, x30, [sp, #0x20]
033a3048: 160f01f0 adrp     x22, #0x5586000
033a304c: c8326739 ldrb     w8, [x22, #0x9cc]
033a3050: f30302aa mov      x19, x2
033a3054: f40301aa mov      x20, x1
033a3058: f50300aa mov      x21, x0
033a305c: c8000037 tbnz     w8, #0, #0x33a3074
033a3060: a0f200f0 adrp     x0, #0x51fa000
033a3064: 00f840f9 ldr      x0, [x0, #0x1f0]
033a3068: a6387097 bl       #0xfb1300
033a306c: 28008052 mov      w8, #1
033a3070: c8322739 strb     w8, [x22, #0x9cc]
033a3074: b40200b4 cbz      x20, #0x33a30c8
033a3078: a00a40f9 ldr      x0, [x21, #0x10]
033a307c: 000300b4 cbz      x0, #0x33a30dc
033a3080: 61068052 mov      w1, #0x33
033a3084: e2031faa mov      x2, xzr
033a3088: b1deb297 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
033a308c: f30100b4 cbz      x19, #0x33a30c8
033a3090: c0010036 tbz      w0, #0, #0x33a30c8
033a3094: a8f200f0 adrp     x8, #0x51fa000
033a3098: 08f940f9 ldr      x8, [x8, #0x1f0]
033a309c: 20068052 mov      w0, #0x31
033a30a0: 010140f9 ldr      x1, [x8]
033a30a4: 726ec697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a30a8: a00100b4 cbz      x0, #0x33a30dc
033a30ac: e10314aa mov      x1, x20
033a30b0: e20313aa mov      x2, x19
033a30b4: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a30b8: f55341a9 ldp      x21, x20, [sp, #0x10]
033a30bc: e3031faa mov      x3, xzr
033a30c0: f60743f8 ldr      x22, [sp], #0x30
033a30c4: eff8b517 b        #0x2121480 ; Royal.Scenes.Game.Mechanics.Items.IceCubeItem.IceCubeItemHelper$$ShouldRedirectAfterPropellerHit
033a30c8: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a30cc: f55341a9 ldp      x21, x20, [sp, #0x10]
033a30d0: e0031f2a mov      w0, wzr
033a30d4: f60743f8 ldr      x22, [sp], #0x30
033a30d8: c0035fd6 ret      
033a30dc: d3387097 bl       #0xfb1428
