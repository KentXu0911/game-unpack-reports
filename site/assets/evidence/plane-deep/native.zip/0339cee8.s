# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$GetStartState
# Linear span to next metadata entry; not a complete CFG.
0339cee8: 40008052 mov      w0, #2
0339ceec: c0035fd6 ret      
