# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerExtraOneStrategy$$ExplodeNeighbors
# Linear span to next metadata entry; not a complete CFG.
033a3ab0: e0031f2a mov      w0, wzr
033a3ab4: c0035fd6 ret      
