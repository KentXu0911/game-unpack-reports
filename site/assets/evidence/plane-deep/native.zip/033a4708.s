# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy.<FinishOperationWithDelay>d__11$$System.Collections.IEnumerator.Reset
# Linear span to next metadata entry; not a complete CFG.
033a4708: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a470c: 20f10090 adrp     x0, #0x51c8000
033a4710: 003c45f9 ldr      x0, [x0, #0xa78]
033a4714: 00337097 bl       #0xfb1314
033a4718: 40337097 bl       #0xfb1418
033a471c: f30300aa mov      x19, x0
033a4720: 0d906497 bl       #0xcc8754
033a4724: e00313aa mov      x0, x19
033a4728: e1031faa mov      x1, xzr
033a472c: f6d6c797 bl       #0x259a304 ; System.NotSupportedException$$.ctor
033a4730: 00f10090 adrp     x0, #0x51c4000
033a4734: 00a044f9 ldr      x0, [x0, #0x940]
033a4738: f7327097 bl       #0xfb1314
033a473c: e10300aa mov      x1, x0
033a4740: e00313aa mov      x0, x19
033a4744: 2b337097 bl       #0xfb13f0
