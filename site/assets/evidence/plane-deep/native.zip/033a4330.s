# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy.<ExplodeWithDelay>d__4$$System.Collections.IEnumerator.get_Current
# Linear span to next metadata entry; not a complete CFG.
033a4330: 000c40f9 ldr      x0, [x0, #0x18]
033a4334: c0035fd6 ret      
