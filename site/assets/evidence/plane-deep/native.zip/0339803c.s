# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_TapStartFlyStateId
# Linear span to next metadata entry; not a complete CFG.
0339803c: f40f1ef8 str      x20, [sp, #-0x20]!
03398040: f37b01a9 stp      x19, x30, [sp, #0x10]
03398044: 740f01d0 adrp     x20, #0x5586000
03398048: f3f10090 adrp     x19, #0x51d4000
0339804c: 88566639 ldrb     w8, [x20, #0x995]
03398050: 73da41f9 ldr      x19, [x19, #0x3b0]
03398054: c8000037 tbnz     w8, #0, #0x339806c
03398058: e0f10090 adrp     x0, #0x51d4000
0339805c: 00d841f9 ldr      x0, [x0, #0x3b0]
03398060: a8647097 bl       #0xfb1300
03398064: 28008052 mov      w8, #1
03398068: 88562639 strb     w8, [x20, #0x995]
0339806c: 600240f9 ldr      x0, [x19]
03398070: 08e040b9 ldr      w8, [x0, #0xe0]
03398074: 68000035 cbnz     w8, #0x3398080
03398078: e3647097 bl       #0xfb1404
0339807c: 600240f9 ldr      x0, [x19]
03398080: 085c40f9 ldr      x8, [x0, #0xb8]
03398084: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398088: 000540b9 ldr      w0, [x8, #4]
0339808c: f40742f8 ldr      x20, [sp], #0x20
03398090: c0035fd6 ret      
