# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerRocketComboParticles$$GetPoolId
# Linear span to next metadata entry; not a complete CFG.
03398920: a0018052 mov      w0, #0xd
03398924: c0035fd6 ret      
