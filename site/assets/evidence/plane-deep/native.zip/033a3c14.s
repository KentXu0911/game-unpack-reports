# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a3c14: f963bca9 stp      x25, x24, [sp, #-0x40]!
033a3c18: f75b01a9 stp      x23, x22, [sp, #0x10]
033a3c1c: f55302a9 stp      x21, x20, [sp, #0x20]
033a3c20: f37b03a9 stp      x19, x30, [sp, #0x30]
033a3c24: 190f01f0 adrp     x25, #0x5586000
033a3c28: 28476739 ldrb     w8, [x25, #0x9d1]
033a3c2c: f40305aa mov      x20, x5
033a3c30: f503042a mov      w21, w4
033a3c34: f703032a mov      w23, w3
033a3c38: f803022a mov      w24, w2
033a3c3c: f60301aa mov      x22, x1
033a3c40: f30300aa mov      x19, x0
033a3c44: c8000037 tbnz     w8, #0, #0x33a3c5c
033a3c48: 20f10090 adrp     x0, #0x51c7000
033a3c4c: 00f041f9 ldr      x0, [x0, #0x3e0]
033a3c50: ac357097 bl       #0xfb1300
033a3c54: 28008052 mov      w8, #1
033a3c58: 28472739 strb     w8, [x25, #0x9d1]
033a3c5c: 02030012 and      w2, w24, #1
033a3c60: e3020012 and      w3, w23, #1
033a3c64: a4020012 and      w4, w21, #1
033a3c68: e00313aa mov      x0, x19
033a3c6c: e10316aa mov      x1, x22
033a3c70: e50314aa mov      x5, x20
033a3c74: 19000094 bl       #0x33a3cd8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$.ctor
033a3c78: 601640f9 ldr      x0, [x19, #0x28]
033a3c7c: c00200b4 cbz      x0, #0x33a3cd4
033a3c80: 29f10090 adrp     x9, #0x51c7000
033a3c84: 29f141f9 ldr      x9, [x9, #0x3e0]
033a3c88: 080040f9 ldr      x8, [x0]
033a3c8c: 210140f9 ldr      x1, [x9]
033a3c90: 0ab14439 ldrb     w10, [x8, #0x12c]
033a3c94: 29b04439 ldrb     w9, [x1, #0x12c]
033a3c98: 5f01096b cmp      w10, w9
033a3c9c: a3010054 b.lo     #0x33a3cd0
033a3ca0: 086540f9 ldr      x8, [x8, #0xc8]
033a3ca4: 080d098b add      x8, x8, x9, lsl #3
033a3ca8: 08815ff8 ldur     x8, [x8, #-8]
033a3cac: 1f0101eb cmp      x8, x1
033a3cb0: 01010054 b.ne     #0x33a3cd0
033a3cb4: 080041b9 ldr      w8, [x0, #0x100]
033a3cb8: 684a00b9 str      w8, [x19, #0x48]
033a3cbc: f37b43a9 ldp      x19, x30, [sp, #0x30]
033a3cc0: f55342a9 ldp      x21, x20, [sp, #0x20]
033a3cc4: f75b41a9 ldp      x23, x22, [sp, #0x10]
033a3cc8: f963c4a8 ldp      x25, x24, [sp], #0x40
033a3ccc: c0035fd6 ret      
033a3cd0: bc367097 bl       #0xfb17c0
033a3cd4: d5357097 bl       #0xfb1428
