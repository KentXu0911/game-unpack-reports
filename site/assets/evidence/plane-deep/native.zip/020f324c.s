# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$CalculateHighestScoreForRocket
# Linear span to next metadata entry; not a complete CFG.
020f324c: fb6bbba9 stp      x27, x26, [sp, #-0x50]!
020f3250: f96301a9 stp      x25, x24, [sp, #0x10]
020f3254: f75b02a9 stp      x23, x22, [sp, #0x20]
020f3258: f55303a9 stp      x21, x20, [sp, #0x30]
020f325c: f37b04a9 stp      x19, x30, [sp, #0x40]
020f3260: 56a401d0 adrp     x22, #0x557d000
020f3264: c8365539 ldrb     w8, [x22, #0x54d]
020f3268: f40302aa mov      x20, x2
020f326c: f30301aa mov      x19, x1
020f3270: f50300aa mov      x21, x0
020f3274: 88010037 tbnz     w8, #0, #0x20f32a4
020f3278: 008a0190 adrp     x0, #0x5233000
020f327c: 00f043f9 ldr      x0, [x0, #0x7e0]
020f3280: 20f8ba97 bl       #0xfb1300
020f3284: 00890190 adrp     x0, #0x5213000
020f3288: 001045f9 ldr      x0, [x0, #0xa20]
020f328c: 1df8ba97 bl       #0xfb1300
020f3290: 008501b0 adrp     x0, #0x5194000
020f3294: 007842f9 ldr      x0, [x0, #0x4f0]
020f3298: 1af8ba97 bl       #0xfb1300
020f329c: 28008052 mov      w8, #1
020f32a0: c8361539 strb     w8, [x22, #0x54d]
020f32a4: 188501b0 adrp     x24, #0x5194000
020f32a8: 187b42f9 ldr      x24, [x24, #0x4f0]
020f32ac: d40100b4 cbz      x20, #0x20f32e4
020f32b0: 16008012 mov      w22, #-1
020f32b4: 020340f9 ldr      x2, [x24]
020f32b8: d6060011 add      w22, w22, #1
020f32bc: e00314aa mov      x0, x20
020f32c0: e103162a mov      w1, w22
020f32c4: 099bf497 bl       #0x1e19ee8 ; System.Collections.Generic.List<int>$$Contains
020f32c8: 60ff0737 tbnz     w0, #0, #0x20f32b4
020f32cc: 530c00b4 cbz      x19, #0x20f3454
020f32d0: 681a40b9 ldr      w8, [x19, #0x18]
020f32d4: df02086b cmp      w22, w8
020f32d8: 8b000054 b.lt     #0x20f32e8
020f32dc: e0031f2a mov      w0, wzr
020f32e0: 56000014 b        #0x20f3438
020f32e4: f6031f2a mov      w22, wzr
020f32e8: a80a40f9 ldr      x8, [x21, #0x10]
020f32ec: 480b00b4 cbz      x8, #0x20f3454
020f32f0: 091d40b9 ldr      w9, [x8, #0x1c]
020f32f4: 29050011 add      w9, w9, #1
020f32f8: 1f250329 stp      wzr, w9, [x8, #0x18]
020f32fc: d30a00b4 cbz      x19, #0x20f3454
020f3300: 680e40f9 ldr      x8, [x19, #0x18]
020f3304: 1f050071 cmp      w8, #1
020f3308: 087d4092 and      x8, x8, #0xffffffff
020f330c: eb080054 b.lt     #0x20f3428
020f3310: 198a0190 adrp     x25, #0x5233000
020f3314: 39f343f9 ldr      x25, [x25, #0x7e0]
020f3318: f7031faa mov      x23, xzr
020f331c: 7a820091 add      x26, x19, #0x20
020f3320: 3b008052 mov      w27, #1
020f3324: f40000b4 cbz      x20, #0x20f3340
020f3328: 020340f9 ldr      x2, [x24]
020f332c: e00314aa mov      x0, x20
020f3330: e103172a mov      w1, w23
020f3334: ed9af497 bl       #0x1e19ee8 ; System.Collections.Generic.List<int>$$Contains
020f3338: 00070037 tbnz     w0, #0, #0x20f3418
020f333c: 681a40b9 ldr      w8, [x19, #0x18]
020f3340: ff4228eb cmp      x23, w8, uxtw
020f3344: 62080054 b.hs     #0x20f3450
020f3348: df02086b cmp      w22, w8
020f334c: 22080054 b.hs     #0x20f3450
020f3350: 69ca368b add      x9, x19, w22, sxtw #2
020f3354: 487b77b8 ldr      w8, [x26, x23, lsl #2]
020f3358: 292140b9 ldr      w9, [x9, #0x20]
020f335c: 1f01096b cmp      w8, w9
020f3360: 41020054 b.ne     #0x20f33a8
020f3364: a00a40f9 ldr      x0, [x21, #0x10]
020f3368: 600700b4 cbz      x0, #0x20f3454
020f336c: 0a1c40b9 ldr      w10, [x0, #0x1c]
020f3370: 080840f9 ldr      x8, [x0, #0x10]
020f3374: 290340f9 ldr      x9, [x25]
020f3378: 4a050011 add      w10, w10, #1
020f337c: 0a1c00b9 str      w10, [x0, #0x1c]
020f3380: a80600b4 cbz      x8, #0x20f3454
020f3384: 0a1880b9 ldrsw    x10, [x0, #0x18]
020f3388: 0b1940b9 ldr      w11, [x8, #0x18]
020f338c: 5f010b6b cmp      w10, w11
020f3390: 82020054 b.hs     #0x20f33e0
020f3394: 49050011 add      w9, w10, #1
020f3398: 08090a8b add      x8, x8, x10, lsl #2
020f339c: 091800b9 str      w9, [x0, #0x18]
020f33a0: 172100b9 str      w23, [x8, #0x20]
020f33a4: 1d000014 b        #0x20f3418
020f33a8: 8d030054 b.le     #0x20f3418
020f33ac: a00a40f9 ldr      x0, [x21, #0x10]
020f33b0: 200500b4 cbz      x0, #0x20f3454
020f33b4: 0a1c40b9 ldr      w10, [x0, #0x1c]
020f33b8: 080840f9 ldr      x8, [x0, #0x10]
020f33bc: 290340f9 ldr      x9, [x25]
020f33c0: 4a090011 add      w10, w10, #2
020f33c4: 1f280329 stp      wzr, w10, [x0, #0x18]
020f33c8: 680400b4 cbz      x8, #0x20f3454
020f33cc: 0a1940b9 ldr      w10, [x8, #0x18]
020f33d0: 6a010034 cbz      w10, #0x20f33fc
020f33d4: 1b1800b9 str      w27, [x0, #0x18]
020f33d8: 172100b9 str      w23, [x8, #0x20]
020f33dc: 0e000014 b        #0x20f3414
020f33e0: 281140f9 ldr      x8, [x9, #0x20]
020f33e4: e103172a mov      w1, w23
020f33e8: 086140f9 ldr      x8, [x8, #0xc0]
020f33ec: 022d40f9 ldr      x2, [x8, #0x58]
020f33f0: 480440f9 ldr      x8, [x2, #8]
020f33f4: 00013fd6 blr      x8
020f33f8: 08000014 b        #0x20f3418
020f33fc: 281140f9 ldr      x8, [x9, #0x20]
020f3400: e103172a mov      w1, w23
020f3404: 086140f9 ldr      x8, [x8, #0xc0]
020f3408: 022d40f9 ldr      x2, [x8, #0x58]
020f340c: 480440f9 ldr      x8, [x2, #8]
020f3410: 00013fd6 blr      x8
020f3414: f603172a mov      w22, w23
020f3418: 681a40b9 ldr      w8, [x19, #0x18]
020f341c: f7060091 add      x23, x23, #1
020f3420: ffc228eb cmp      x23, w8, sxtw
020f3424: 0bf8ff54 b.lt     #0x20f3324
020f3428: df02086b cmp      w22, w8
020f342c: 22010054 b.hs     #0x20f3450
020f3430: 68ca368b add      x8, x19, w22, sxtw #2
020f3434: 002140b9 ldr      w0, [x8, #0x20]
020f3438: f37b44a9 ldp      x19, x30, [sp, #0x40]
020f343c: f55343a9 ldp      x21, x20, [sp, #0x30]
020f3440: f75b42a9 ldp      x23, x22, [sp, #0x20]
020f3444: f96341a9 ldp      x25, x24, [sp, #0x10]
020f3448: fb6bc5a8 ldp      x27, x26, [sp], #0x50
020f344c: c0035fd6 ret      
020f3450: f8f7ba97 bl       #0xfb1430
020f3454: f5f7ba97 bl       #0xfb1428
