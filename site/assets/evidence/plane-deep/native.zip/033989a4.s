# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_ScaleUpSpeedConst
# Linear span to next metadata entry; not a complete CFG.
033989a4: 0010221e fmov     s0, #4.00000000
033989a8: c0035fd6 ret      
