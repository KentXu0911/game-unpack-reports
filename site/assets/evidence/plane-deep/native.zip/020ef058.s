# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ClearLists
# Linear span to next metadata entry; not a complete CFG.
020ef058: ff4302d1 sub      sp, sp, #0x90
020ef05c: f63300f9 str      x22, [sp, #0x60]
020ef060: f55307a9 stp      x21, x20, [sp, #0x70]
020ef064: f37b08a9 stp      x19, x30, [sp, #0x80]
020ef068: 75a401d0 adrp     x21, #0x557d000
020ef06c: a84e5539 ldrb     w8, [x21, #0x553]
020ef070: f403012a mov      w20, w1
020ef074: f30300aa mov      x19, x0
020ef078: 08030037 tbnz     w8, #0, #0x20ef0d8
020ef07c: 40880190 adrp     x0, #0x51f7000
020ef080: 00ac47f9 ldr      x0, [x0, #0xf58]
020ef084: 9f08bb97 bl       #0xfb1300
020ef088: c08501d0 adrp     x0, #0x51a9000
020ef08c: 004846f9 ldr      x0, [x0, #0xc90]
020ef090: 9c08bb97 bl       #0xfb1300
020ef094: 408a01d0 adrp     x0, #0x5239000
020ef098: 00ac44f9 ldr      x0, [x0, #0x958]
020ef09c: 9908bb97 bl       #0xfb1300
020ef0a0: e08401d0 adrp     x0, #0x518d000
020ef0a4: 00b844f9 ldr      x0, [x0, #0x970]
020ef0a8: 9608bb97 bl       #0xfb1300
020ef0ac: 008a01f0 adrp     x0, #0x5232000
020ef0b0: 001843f9 ldr      x0, [x0, #0x630]
020ef0b4: 9308bb97 bl       #0xfb1300
020ef0b8: e08801b0 adrp     x0, #0x520c000
020ef0bc: 00f840f9 ldr      x0, [x0, #0x1f0]
020ef0c0: 9008bb97 bl       #0xfb1300
020ef0c4: 008801d0 adrp     x0, #0x51f1000
020ef0c8: 00a845f9 ldr      x0, [x0, #0xb50]
020ef0cc: 8d08bb97 bl       #0xfb1300
020ef0d0: 28008052 mov      w8, #1
020ef0d4: a84e1539 strb     w8, [x21, #0x553]
020ef0d8: 00e4006f movi     v0.2d, #0000000000000000
020ef0dc: e00302ad stp      q0, q0, [sp, #0x40]
020ef0e0: e00f803d str      q0, [sp, #0x30]
020ef0e4: 603640f9 ldr      x0, [x19, #0x68]
020ef0e8: 000900b4 cbz      x0, #0x20ef208
020ef0ec: d4000036 tbz      w20, #0, #0x20ef104
020ef0f0: e88801b0 adrp     x8, #0x520c000
020ef0f4: 08f940f9 ldr      x8, [x8, #0x1f0]
020ef0f8: 010140f9 ldr      x1, [x8]
020ef0fc: 6affd097 bl       #0x152eea4 ; System.Collections.Generic.SortedDictionary<int, object>$$Clear
020ef100: 25000014 b        #0x20ef194
020ef104: 088801d0 adrp     x8, #0x51f1000
020ef108: 08a945f9 ldr      x8, [x8, #0xb50]
020ef10c: d58501d0 adrp     x21, #0x51a9000
020ef110: 568a01d0 adrp     x22, #0x5239000
020ef114: 54880190 adrp     x20, #0x51f7000
020ef118: 010140f9 ldr      x1, [x8]
020ef11c: b54a46f9 ldr      x21, [x21, #0xc90]
020ef120: d6ae44f9 ldr      x22, [x22, #0x958]
020ef124: 94ae47f9 ldr      x20, [x20, #0xf58]
020ef128: e8030091 mov      x8, sp
020ef12c: f5ffd097 bl       #0x152f100 ; System.Collections.Generic.SortedDictionary<int, object>$$GetEnumerator
020ef130: e10340ad ldp      q1, q0, [sp]
020ef134: e20bc03d ldr      q2, [sp, #0x20]
020ef138: e18301ad stp      q1, q0, [sp, #0x30]
020ef13c: e217803d str      q2, [sp, #0x50]
020ef140: a10240f9 ldr      x1, [x21]
020ef144: e0c30091 add      x0, sp, #0x30
020ef148: a3a03394 bl       #0x2dd73d4 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$MoveNext
020ef14c: e0010036 tbz      w0, #0, #0x20ef188
020ef150: c10240f9 ldr      x1, [x22]
020ef154: e0c30091 add      x0, sp, #0x30
020ef158: bca03394 bl       #0x2dd7448 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$get_Current
020ef15c: 210500b4 cbz      x1, #0x20ef200
020ef160: 22204329 ldp      w2, w8, [x1, #0x18]
020ef164: 08050011 add      w8, w8, #1
020ef168: 5f040071 cmp      w2, #1
020ef16c: 3f200329 stp      wzr, w8, [x1, #0x18]
020ef170: 8bfeff54 b.lt     #0x20ef140
020ef174: 200840f9 ldr      x0, [x1, #0x10]
020ef178: e1031f2a mov      w1, wzr
020ef17c: e3031faa mov      x3, xzr
020ef180: 35e41194 bl       #0x2568254 ; System.Array$$Clear
020ef184: efffff17 b        #0x20ef140
020ef188: 810240f9 ldr      x1, [x20]
020ef18c: e0c30091 add      x0, sp, #0x30
020ef190: ada03394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020ef194: 603a40f9 ldr      x0, [x19, #0x70]
020ef198: 800300b4 cbz      x0, #0x20ef208
020ef19c: e1031faa mov      x1, xzr
020ef1a0: 19e21694 bl       #0x26a7a04 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ClearGoalData
020ef1a4: 605240f9 ldr      x0, [x19, #0xa0]
020ef1a8: a00000b4 cbz      x0, #0x20ef1bc
020ef1ac: 021840b9 ldr      w2, [x0, #0x18]
020ef1b0: e1031f2a mov      w1, wzr
020ef1b4: e3031faa mov      x3, xzr
020ef1b8: 27e41194 bl       #0x2568254 ; System.Array$$Clear
020ef1bc: 604e40f9 ldr      x0, [x19, #0x98]
020ef1c0: 400200b4 cbz      x0, #0x20ef208
020ef1c4: 021840b9 ldr      w2, [x0, #0x18]
020ef1c8: e1031f2a mov      w1, wzr
020ef1cc: e3031faa mov      x3, xzr
020ef1d0: 21e41194 bl       #0x2568254 ; System.Array$$Clear
020ef1d4: 604a40f9 ldr      x0, [x19, #0x90]
020ef1d8: 800100b4 cbz      x0, #0x20ef208
020ef1dc: 021840b9 ldr      w2, [x0, #0x18]
020ef1e0: e1031f2a mov      w1, wzr
020ef1e4: e3031faa mov      x3, xzr
020ef1e8: 1be41194 bl       #0x2568254 ; System.Array$$Clear
020ef1ec: f37b48a9 ldp      x19, x30, [sp, #0x80]
020ef1f0: f55347a9 ldp      x21, x20, [sp, #0x70]
020ef1f4: f63340f9 ldr      x22, [sp, #0x60]
020ef1f8: ff430291 add      sp, sp, #0x90
020ef1fc: c0035fd6 ret      
020ef200: f60314aa mov      x22, x20
020ef204: 8908bb97 bl       #0xfb1428
020ef208: 8808bb97 bl       #0xfb1428
020ef20c: 04000014 b        #0x20ef21c
020ef210: 02000014 b        #0x20ef218
020ef214: 01000014 b        #0x20ef218
020ef218: f60314aa mov      x22, x20
020ef21c: f40300aa mov      x20, x0
020ef220: 3f040071 cmp      w1, #1
020ef224: 61010054 b.ne     #0x20ef250
020ef228: e00314aa mov      x0, x20
020ef22c: e950af97 bl       #0xcc35d0
020ef230: 150040f9 ldr      x21, [x0]
020ef234: 634faf97 bl       #0xcc2fc0
020ef238: c10240f9 ldr      x1, [x22]
020ef23c: e0c30091 add      x0, sp, #0x30
020ef240: 81a03394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020ef244: 95faffb4 cbz      x21, #0x20ef194
020ef248: e00315aa mov      x0, x21
020ef24c: 63b8ba97 bl       #0xf9d3d8
020ef250: f5031faa mov      x21, xzr
020ef254: 02000014 b        #0x20ef25c
020ef258: f40300aa mov      x20, x0
020ef25c: c10240f9 ldr      x1, [x22]
020ef260: e0c30091 add      x0, sp, #0x30
020ef264: 78a03394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020ef268: 750000b5 cbnz     x21, #0x20ef274
020ef26c: e00314aa mov      x0, x20
020ef270: 244faf97 bl       #0xcc2f00
020ef274: e00315aa mov      x0, x21
020ef278: 58b8ba97 bl       #0xf9d3d8
020ef27c: 3365af97 bl       #0xcc8748
