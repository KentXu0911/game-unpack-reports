# Royal.Scenes.Game.Mechanics.Items.BowlingRackItem.BowlingRackItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02385698: f553bea9 stp      x21, x20, [sp, #-0x20]!
0238569c: f37b01a9 stp      x19, x30, [sp, #0x10]
023856a0: 080040f9 ldr      x8, [x0]
023856a4: f403012a mov      w20, w1
023856a8: f30300aa mov      x19, x0
023856ac: 096542f9 ldr      x9, [x8, #0x4c8]
023856b0: 086942f9 ldr      x8, [x8, #0x4d0]
023856b4: e10308aa mov      x1, x8
023856b8: 20013fd6 blr      x9
023856bc: 686a40b9 ldr      w8, [x19, #0x68]
023856c0: 08070034 cbz      w8, #0x23857a0
023856c4: f503002a mov      w21, w0
023856c8: e003142a mov      w0, w20
023856cc: e1031faa mov      x1, xzr
023856d0: 94fc3f94 bl       #0x3384920 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsMultipleExploder
023856d4: a0010036 tbz      w0, #0, #0x2385708
023856d8: 680240f9 ldr      x8, [x19]
023856dc: e00313aa mov      x0, x19
023856e0: 095542f9 ldr      x9, [x8, #0x4a8]
023856e4: 015942f9 ldr      x1, [x8, #0x4b0]
023856e8: 20013fd6 blr      x9
023856ec: e803002a mov      w8, w0
023856f0: bf060071 cmp      w21, #1
023856f4: e0031f2a mov      w0, wzr
023856f8: 4b090054 b.lt     #0x2385820
023856fc: 1f010071 cmp      w8, #0
02385700: 8c000054 b.gt     #0x2385710
02385704: 47000014 b        #0x2385820
02385708: bf060071 cmp      w21, #1
0238570c: ab040054 b.lt     #0x23857a0
02385710: e003142a mov      w0, w20
02385714: e1031faa mov      x1, xzr
02385718: 89fc3f94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
0238571c: 60040036 tbz      w0, #0, #0x23857a8
02385720: 605e40f9 ldr      x0, [x19, #0xb8]
02385724: 400800b4 cbz      x0, #0x238582c
02385728: e10313aa mov      x1, x19
0238572c: 37f7ff97 bl       #0x2383408 ; Royal.Scenes.Game.Mechanics.Items.BowlingRackItem.BowlingRackItemManager$$IsLastItem
02385730: c0030036 tbz      w0, #0, #0x23857a8
02385734: e00313aa mov      x0, x19
02385738: e103142a mov      w1, w20
0238573c: e2031faa mov      x2, xzr
02385740: 8bfc3f94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02385744: 680240f9 ldr      x8, [x19]
02385748: f403002a mov      w20, w0
0238574c: e00313aa mov      x0, x19
02385750: 09bd41f9 ldr      x9, [x8, #0x378]
02385754: 01c141f9 ldr      x1, [x8, #0x380]
02385758: 20013fd6 blr      x9
0238575c: e1031faa mov      x1, xzr
02385760: 8afc3f94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02385764: 685e40f9 ldr      x8, [x19, #0xb8]
02385768: 280600b4 cbz      x8, #0x238582c
0238576c: 081940f9 ldr      x8, [x8, #0x30]
02385770: e80500b4 cbz      x8, #0x238582c
02385774: 081940b9 ldr      w8, [x8, #0x18]
02385778: c9aa8a52 mov      w9, #0x5556
0238577c: a9aaaa72 movk     w9, #0x5555, lsl #16
02385780: 08050051 sub      w8, w8, #1
02385784: 087d001b mul      w8, w8, w0
02385788: 087d299b smull    x8, w8, w9
0238578c: 09fd7fd3 lsr      x9, x8, #0x3f
02385790: 08fd60d3 lsr      x8, x8, #0x20
02385794: 0801090b add      w8, w8, w9
02385798: 0001140b add      w0, w8, w20
0238579c: 21000014 b        #0x2385820
023857a0: e0031f2a mov      w0, wzr
023857a4: 1f000014 b        #0x2385820
023857a8: e003142a mov      w0, w20
023857ac: e1031faa mov      x1, xzr
023857b0: 7ffc3f94 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
023857b4: e0000036 tbz      w0, #0, #0x23857d0
023857b8: 602a40f9 ldr      x0, [x19, #0x50]
023857bc: 800300b4 cbz      x0, #0x238582c
023857c0: 61c242f8 ldur     x1, [x19, #0x2c]
023857c4: e2031faa mov      x2, xzr
023857c8: 523b0f94 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
023857cc: 04000014 b        #0x23857dc
023857d0: e00313aa mov      x0, x19
023857d4: e1031faa mov      x1, xzr
023857d8: aff53f94 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
023857dc: 685e40f9 ldr      x8, [x19, #0xb8]
023857e0: e20300aa mov      x2, x0
023857e4: 480200b4 cbz      x8, #0x238582c
023857e8: 011940f9 ldr      x1, [x8, #0x30]
023857ec: a4608a52 mov      w4, #0x5305
023857f0: 4400a072 movk     w4, #2, lsl #16
023857f4: 05008012 mov      w5, #-1
023857f8: e00313aa mov      x0, x19
023857fc: e303142a mov      w3, w20
02385800: e6031faa mov      x6, xzr
02385804: 71fc3f94 bl       #0x33849c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetItemExplodeExtraScore
02385808: f503002a mov      w21, w0
0238580c: e00313aa mov      x0, x19
02385810: e103142a mov      w1, w20
02385814: e2031faa mov      x2, xzr
02385818: 55fc3f94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
0238581c: 0000150b add      w0, w0, w21
02385820: f37b41a9 ldp      x19, x30, [sp, #0x10]
02385824: f553c2a8 ldp      x21, x20, [sp], #0x20
02385828: c0035fd6 ret      
0238582c: ffaeb097 bl       #0xfb1428
