# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ExplodeNeighbors
# Linear span to next metadata entry; not a complete CFG.
033a2d54: f80f1cf8 str      x24, [sp, #-0x40]!
033a2d58: f75b01a9 stp      x23, x22, [sp, #0x10]
033a2d5c: f55302a9 stp      x21, x20, [sp, #0x20]
033a2d60: f37b03a9 stp      x19, x30, [sp, #0x30]
033a2d64: 360f0190 adrp     x22, #0x5586000
033a2d68: 98ef00f0 adrp     x24, #0x5195000
033a2d6c: c82e6739 ldrb     w8, [x22, #0x9cb]
033a2d70: 181b43f9 ldr      x24, [x24, #0x630]
033a2d74: f30303aa mov      x19, x3
033a2d78: f40302aa mov      x20, x2
033a2d7c: f50301aa mov      x21, x1
033a2d80: f70300aa mov      x23, x0
033a2d84: c8000037 tbnz     w8, #0, #0x33a2d9c
033a2d88: 80ef00f0 adrp     x0, #0x5195000
033a2d8c: 001843f9 ldr      x0, [x0, #0x630]
033a2d90: 5c397097 bl       #0xfb1300
033a2d94: 28008052 mov      w8, #1
033a2d98: c82e2739 strb     w8, [x22, #0x9cb]
033a2d9c: 000340f9 ldr      x0, [x24]
033a2da0: 9e397097 bl       #0xfb1418
033a2da4: c00300b4 cbz      x0, #0x33a2e1c
033a2da8: e1031faa mov      x1, xzr
033a2dac: f60300aa mov      x22, x0
033a2db0: 1142bb97 bl       #0x22735f4 ; System.Object$$.ctor
033a2db4: e00316aa mov      x0, x22
033a2db8: df1200b9 str      wzr, [x22, #0x10]
033a2dbc: 170c06f8 str      x23, [x0, #0x60]!
033a2dc0: e10317aa mov      x1, x23
033a2dc4: 3a397097 bl       #0xfb12ac
033a2dc8: e00316aa mov      x0, x22
033a2dcc: 150c02f8 str      x21, [x0, #0x20]!
033a2dd0: e10315aa mov      x1, x21
033a2dd4: 36397097 bl       #0xfb12ac
033a2dd8: 881a40f9 ldr      x8, [x20, #0x30]
033a2ddc: 818240ad ldp      q1, q0, [x20, #0x10]
033a2de0: 8202c03d ldr      q2, [x20]
033a2de4: e00316aa mov      x0, x22
033a2de8: c82e00f9 str      x8, [x22, #0x58]
033a2dec: c082843c stur     q0, [x22, #0x48]
033a2df0: c182833c stur     q1, [x22, #0x38]
033a2df4: c282823c stur     q2, [x22, #0x28]
033a2df8: 138c06f8 str      x19, [x0, #0x68]!
033a2dfc: e10313aa mov      x1, x19
033a2e00: 2b397097 bl       #0xfb12ac
033a2e04: e00316aa mov      x0, x22
033a2e08: f37b43a9 ldp      x19, x30, [sp, #0x30]
033a2e0c: f55342a9 ldp      x21, x20, [sp, #0x20]
033a2e10: f75b41a9 ldp      x23, x22, [sp, #0x10]
033a2e14: f80744f8 ldr      x24, [sp], #0x40
033a2e18: c0035fd6 ret      
033a2e1c: 83397097 bl       #0xfb1428
