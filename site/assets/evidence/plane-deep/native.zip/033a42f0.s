# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy.<ExplodeWithDelay>d__4$$System.Collections.IEnumerator.Reset
# Linear span to next metadata entry; not a complete CFG.
033a42f0: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a42f4: 20f10090 adrp     x0, #0x51c8000
033a42f8: 003c45f9 ldr      x0, [x0, #0xa78]
033a42fc: 06347097 bl       #0xfb1314
033a4300: 46347097 bl       #0xfb1418
033a4304: f30300aa mov      x19, x0
033a4308: 13916497 bl       #0xcc8754
033a430c: e00313aa mov      x0, x19
033a4310: e1031faa mov      x1, xzr
033a4314: fcd7c797 bl       #0x259a304 ; System.NotSupportedException$$.ctor
033a4318: 60f30090 adrp     x0, #0x5210000
033a431c: 009446f9 ldr      x0, [x0, #0xd28]
033a4320: fd337097 bl       #0xfb1314
033a4324: e10300aa mov      x1, x0
033a4328: e00313aa mov      x0, x19
033a432c: 31347097 bl       #0xfb13f0
