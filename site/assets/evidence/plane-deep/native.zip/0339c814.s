# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeComboExpandPosition
# Linear span to next metadata entry; not a complete CFG.
0339c814: ff4302d1 sub      sp, sp, #0x90
0339c818: eb2b056d stp      d11, d10, [sp, #0x50]
0339c81c: e923066d stp      d9, d8, [sp, #0x60]
0339c820: f55307a9 stp      x21, x20, [sp, #0x70]
0339c824: f37b08a9 stp      x19, x30, [sp, #0x80]
0339c828: 540f01d0 adrp     x20, #0x5586000
0339c82c: 88c26639 ldrb     w8, [x20, #0x9b0]
0339c830: f30300aa mov      x19, x0
0339c834: c8000037 tbnz     w8, #0, #0x339c84c
0339c838: 80f400b0 adrp     x0, #0x522d000
0339c83c: 008444f9 ldr      x0, [x0, #0x908]
0339c840: b0527097 bl       #0xfb1300
0339c844: 28008052 mov      w8, #1
0339c848: 88c22639 strb     w8, [x20, #0x9b0]
0339c84c: 603640f9 ldr      x0, [x19, #0x68]
0339c850: 401900b4 cbz      x0, #0x339cb78
0339c854: e1031faa mov      x1, xzr
0339c858: 27b52594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339c85c: 662240bd ldr      s6, [x19, #0x20]
0339c860: 485600f0 adrp     x8, #0x3e67000
0339c864: 044144bd ldr      s4, [x8, #0x440]
0339c868: 05102d1e fmov     s5, #0.75000000
0339c86c: 481ca24e mov      v8.16b, v2.16b
0339c870: 02102e1e fmov     s2, #1.00000000
0339c874: 632e40bd ldr      s3, [x19, #0x2c]
0339c878: c618251e fdiv     s6, s6, s5
0339c87c: 653640bd ldr      s5, [x19, #0x34]
0339c880: c658221e fmin     s6, s6, s2
0339c884: c618241e fdiv     s6, s6, s4
0339c888: e403271e fmov     s4, wzr
0339c88c: c258221e fmin     s2, s6, s2
0339c890: c820201e fcmp     s6, #0.0
0339c894: 425c241e fcsel    s2, s2, s4, pl
0339c898: a438231e fsub     s4, s5, s3
0339c89c: 8208221e fmul     s2, s4, s2
0339c8a0: 0690231e fmov     s6, #7.00000000
0339c8a4: 6228221e fadd     s2, s3, s2
0339c8a8: 4208261e fmul     s2, s2, s6
0339c8ac: 621e00bd str      s2, [x19, #0x1c]
0339c8b0: d40e01f0 adrp     x20, #0x5577000
0339c8b4: 69424ffc ldur     d9, [x19, #0xf4]
0339c8b8: 88fa7f39 ldrb     w8, [x20, #0xffe]
0339c8bc: 6bfe40bd ldr      s11, [x19, #0xfc]
0339c8c0: e00701ad stp      q0, q1, [sp, #0x20]
0339c8c4: 20040c6e mov      v0.s[1], v1.s[0]
0339c8c8: 08010035 cbnz     w8, #0x339c8e8
0339c8cc: 20f30090 adrp     x0, #0x5200000
0339c8d0: 008c46f9 ldr      x0, [x0, #0xd18]
0339c8d4: e013803d str      q0, [sp, #0x40]
0339c8d8: 8a527097 bl       #0xfb1300
0339c8dc: e013c03d ldr      q0, [sp, #0x40]
0339c8e0: 28008052 mov      w8, #1
0339c8e4: 88fa3f39 strb     w8, [x20, #0xffe]
0339c8e8: 35f30090 adrp     x21, #0x5200000
0339c8ec: b58e46f9 ldr      x21, [x21, #0xd18]
0339c8f0: 2ad5a00e fsub     v10.2s, v9.2s, v0.2s
0339c8f4: 6939281e fsub     s9, s11, s8
0339c8f8: a00240f9 ldr      x0, [x21]
0339c8fc: 08e040b9 ldr      w8, [x0, #0xe0]
0339c900: 48000035 cbnz     w8, #0x339c908
0339c904: c0527097 bl       #0xfb1404
0339c908: a85600f0 adrp     x8, #0x3e73000
0339c90c: 40dd2a2e fmul     v0.2s, v10.2s, v10.2s
0339c910: 01894bbd ldr      s1, [x8, #0xb88]
0339c914: 00d8307e faddp    s0, v0.2s
0339c918: 2209291e fmul     s2, s9, s9
0339c91c: 4028201e fadd     s0, s2, s0
0339c920: 02c0211e fsqrt    s2, s0
0339c924: 4020211e fcmp     s2, s1
0339c928: e213803d str      q2, [sp, #0x40]
0339c92c: ad000054 b.le     #0x339c940
0339c930: 4004040e dup      v0.2s, v2.s[0]
0339c934: 4afd202e fdiv     v10.2s, v10.2s, v0.2s
0339c938: 2919221e fdiv     s9, s9, s2
0339c93c: 0f000014 b        #0x339c978
0339c940: d40e01d0 adrp     x20, #0x5576000
0339c944: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339c948: c8000035 cbnz     w8, #0x339c960
0339c94c: 60f400f0 adrp     x0, #0x522b000
0339c950: 00ac43f9 ldr      x0, [x0, #0x758]
0339c954: 6b527097 bl       #0xfb1300
0339c958: 28008052 mov      w8, #1
0339c95c: 88b23c39 strb     w8, [x20, #0xf2c]
0339c960: 68f400f0 adrp     x8, #0x522b000
0339c964: 08ad43f9 ldr      x8, [x8, #0x758]
0339c968: 080140f9 ldr      x8, [x8]
0339c96c: 085d40f9 ldr      x8, [x8, #0xb8]
0339c970: 0a0140fd ldr      d10, [x8]
0339c974: 090940bd ldr      s9, [x8, #8]
0339c978: 6b1e40bd ldr      s11, [x19, #0x1c]
0339c97c: e0031faa mov      x0, xzr
0339c980: 14cfce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
0339c984: 743640f9 ldr      x20, [x19, #0x68]
0339c988: 6009201e fmul     s0, s11, s0
0339c98c: 4191800f fmul     v1.2s, v10.2s, v0.s[0]
0339c990: 2009201e fmul     s0, s9, s0
0339c994: 612a00fd str      d1, [x19, #0x50]
0339c998: 605a00bd str      s0, [x19, #0x58]
0339c99c: f40e00b4 cbz      x20, #0x339cb78
0339c9a0: e00314aa mov      x0, x20
0339c9a4: e1031faa mov      x1, xzr
0339c9a8: d3b42594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339c9ac: 63124a2d ldp      s3, s4, [x19, #0x50]
0339c9b0: 655a40bd ldr      s5, [x19, #0x58]
0339c9b4: e00314aa mov      x0, x20
0339c9b8: e1031faa mov      x1, xzr
0339c9bc: 0028231e fadd     s0, s0, s3
0339c9c0: 2128241e fadd     s1, s1, s4
0339c9c4: 4228251e fadd     s2, s2, s5
0339c9c8: f3b42594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
0339c9cc: d40e01f0 adrp     x20, #0x5577000
0339c9d0: 881a6039 ldrb     w8, [x20, #0x806]
0339c9d4: c8000035 cbnz     w8, #0x339c9ec
0339c9d8: 20f30090 adrp     x0, #0x5200000
0339c9dc: 008c46f9 ldr      x0, [x0, #0xd18]
0339c9e0: 48527097 bl       #0xfb1300
0339c9e4: 28008052 mov      w8, #1
0339c9e8: 881a2039 strb     w8, [x20, #0x806]
0339c9ec: a00240f9 ldr      x0, [x21]
0339c9f0: 6b2a4a2d ldp      s11, s10, [x19, #0x50]
0339c9f4: 695a40bd ldr      s9, [x19, #0x58]
0339c9f8: 08e040b9 ldr      w8, [x0, #0xe0]
0339c9fc: 68000034 cbz      w8, #0x339ca08
0339ca00: e8031f2a mov      w8, wzr
0339ca04: 05000014 b        #0x339ca18
0339ca08: 7f527097 bl       #0xfb1404
0339ca0c: 881a6039 ldrb     w8, [x20, #0x806]
0339ca10: 1f010071 cmp      w8, #0
0339ca14: e8179f1a cset     w8, eq
0339ca18: 60092b1e fmul     s0, s11, s11
0339ca1c: 41092a1e fmul     s1, s10, s10
0339ca20: 0028211e fadd     s0, s0, s1
0339ca24: 2109291e fmul     s1, s9, s9
0339ca28: 0928211e fadd     s9, s0, s1
0339ca2c: c8000034 cbz      w8, #0x339ca44
0339ca30: 20f30090 adrp     x0, #0x5200000
0339ca34: 008c46f9 ldr      x0, [x0, #0xd18]
0339ca38: 32527097 bl       #0xfb1300
0339ca3c: 28008052 mov      w8, #1
0339ca40: 881a2039 strb     w8, [x20, #0x806]
0339ca44: a00240f9 ldr      x0, [x21]
0339ca48: e013c03d ldr      q0, [sp, #0x40]
0339ca4c: 29c1211e fsqrt    s9, s9
0339ca50: 08e040b9 ldr      w8, [x0, #0xe0]
0339ca54: 68000035 cbnz     w8, #0x339ca60
0339ca58: 6b527097 bl       #0xfb1404
0339ca5c: e013c03d ldr      q0, [sp, #0x40]
0339ca60: 2021201e fcmp     s9, s0
0339ca64: 0c010054 b.gt     #0x339ca84
0339ca68: 485600f0 adrp     x8, #0x3e67000
0339ca6c: 024944bd ldr      s2, [x8, #0x448]
0339ca70: 201da94e mov      v0.16b, v9.16b
0339ca74: e113c03d ldr      q1, [sp, #0x40]
0339ca78: e0031faa mov      x0, xzr
0339ca7c: b287fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339ca80: 20020036 tbz      w0, #0, #0x339cac4
0339ca84: e0031faa mov      x0, xzr
0339ca88: 68d8ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339ca8c: 4a5600f0 adrp     x10, #0x3e67000
0339ca90: 60ba00bd str      s0, [x19, #0xb8]
0339ca94: 602a40fd ldr      d0, [x19, #0x50]
0339ca98: 615a40bd ldr      s1, [x19, #0x58]
0339ca9c: 42fd44bd ldr      s2, [x10, #0x4fc]
0339caa0: 49339352 mov      w9, #0x999a
0339caa4: 29e3a772 movk     w9, #0x3f19, lsl #16
0339caa8: 230d040e dup      v3.2s, w9
0339caac: 48008052 mov      w8, #2
0339cab0: 00dc232e fmul     v0.2s, v0.2s, v3.2s
0339cab4: 2108221e fmul     s1, s1, s2
0339cab8: 687a00b9 str      w8, [x19, #0x78]
0339cabc: 602a00fd str      d0, [x19, #0x50]
0339cac0: 615a00bd str      s1, [x19, #0x58]
0339cac4: 881a6039 ldrb     w8, [x20, #0x806]
0339cac8: c8000035 cbnz     w8, #0x339cae0
0339cacc: 20f30090 adrp     x0, #0x5200000
0339cad0: 008c46f9 ldr      x0, [x0, #0xd18]
0339cad4: 0b527097 bl       #0xfb1300
0339cad8: 28008052 mov      w8, #1
0339cadc: 881a2039 strb     w8, [x20, #0x806]
0339cae0: a00240f9 ldr      x0, [x21]
0339cae4: 08e040b9 ldr      w8, [x0, #0xe0]
0339cae8: 48000035 cbnz     w8, #0x339caf0
0339caec: 46527097 bl       #0xfb1404
0339caf0: e00313aa mov      x0, x19
0339caf4: e013c03d ldr      q0, [sp, #0x40]
0339caf8: 2ef3ff97 bl       #0x33997b0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScale
0339cafc: 603640f9 ldr      x0, [x19, #0x68]
0339cb00: c00300b4 cbz      x0, #0x339cb78
0339cb04: 93f400b0 adrp     x19, #0x522d000
0339cb08: 738644f9 ldr      x19, [x19, #0x908]
0339cb0c: e1031faa mov      x1, xzr
0339cb10: 79b42594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339cb14: 600240f9 ldr      x0, [x19]
0339cb18: 091ca04e mov      v9.16b, v0.16b
0339cb1c: 2a1ca14e mov      v10.16b, v1.16b
0339cb20: 4b1ca24e mov      v11.16b, v2.16b
0339cb24: 08e040b9 ldr      w8, [x0, #0xe0]
0339cb28: 48000035 cbnz     w8, #0x339cb30
0339cb2c: 36527097 bl       #0xfb1404
0339cb30: 0814a852 mov      w8, #0x40a00000
0339cb34: 09f0e7d2 mov      x9, #0x3f80000000000000
0339cb38: 0af0a752 mov      w10, #0x3f800000
0339cb3c: e00741ad ldp      q0, q1, [sp, #0x20]
0339cb40: 021da84e mov      v2.16b, v8.16b
0339cb44: 231da94e mov      v3.16b, v9.16b
0339cb48: 441daa4e mov      v4.16b, v10.16b
0339cb4c: 651dab4e mov      v5.16b, v11.16b
0339cb50: e0031faa mov      x0, xzr
0339cb54: e81300b9 str      w8, [sp, #0x10]
0339cb58: ea2700a9 stp      x10, x9, [sp]
0339cb5c: 368c2594 bl       #0x3cffc34 ; UnityEngine.Debug$$DrawLine
0339cb60: f37b48a9 ldp      x19, x30, [sp, #0x80]
0339cb64: f55347a9 ldp      x21, x20, [sp, #0x70]
0339cb68: e923466d ldp      d9, d8, [sp, #0x60]
0339cb6c: eb2b456d ldp      d11, d10, [sp, #0x50]
0339cb70: ff430291 add      sp, sp, #0x90
0339cb74: c0035fd6 ret      
0339cb78: 2c527097 bl       #0xfb1428
