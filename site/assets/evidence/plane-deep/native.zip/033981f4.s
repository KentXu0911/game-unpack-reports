# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_FlyAudioClipType
# Linear span to next metadata entry; not a complete CFG.
033981f4: a0248052 mov      w0, #0x125
033981f8: c0035fd6 ret      
