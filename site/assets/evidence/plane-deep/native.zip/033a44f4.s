# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$ForceExplode
# Linear span to next metadata entry; not a complete CFG.
033a44f4: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a44f8: 080040f9 ldr      x8, [x0]
033a44fc: f30300aa mov      x19, x0
033a4500: 094d41f9 ldr      x9, [x8, #0x298]
033a4504: 015141f9 ldr      x1, [x8, #0x2a0]
033a4508: 20013fd6 blr      x9
033a450c: 601640f9 ldr      x0, [x19, #0x28]
033a4510: c00000b4 cbz      x0, #0x33a4528
033a4514: 080040f9 ldr      x8, [x0]
033a4518: 02d542f9 ldr      x2, [x8, #0x5a8]
033a451c: 01d942f9 ldr      x1, [x8, #0x5b0]
033a4520: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a4524: 40001fd6 br       x2
033a4528: c0337097 bl       #0xfb1428
