# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$TargetChanged
# Linear span to next metadata entry; not a complete CFG.
0339d0a8: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
0339d0ac: 001440bd ldr      s0, [x0, #0x14]
0339d0b0: e103271e fmov     s1, wzr
0339d0b4: 48008052 mov      w8, #2
0339d0b8: f30300aa mov      x19, x0
0339d0bc: 0058211e fmin     s0, s0, s1
0339d0c0: 086800b9 str      w8, [x0, #0x68]
0339d0c4: 001400bd str      s0, [x0, #0x14]
0339d0c8: e0031faa mov      x0, xzr
0339d0cc: d7d6ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339d0d0: e00313aa mov      x0, x19
0339d0d4: 601a00bd str      s0, [x19, #0x18]
0339d0d8: 7ff20239 strb     wzr, [x19, #0xbc]
0339d0dc: 08000094 bl       #0x339d0fc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$CalculateRedirectAngleVariables
0339d0e0: 687e40b9 ldr      w8, [x19, #0x7c]
0339d0e4: 1f090071 cmp      w8, #2
0339d0e8: 61000054 b.ne     #0x339d0f4
0339d0ec: 28008052 mov      w8, #1
0339d0f0: 687e00b9 str      w8, [x19, #0x7c]
0339d0f4: f37bc1a8 ldp      x19, x30, [sp], #0x10
0339d0f8: c0035fd6 ret      
