# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$FindHighestScoreForRocket
# Linear span to next metadata entry; not a complete CFG.
020f3174: f80f1cf8 str      x24, [sp, #-0x40]!
020f3178: f75b01a9 stp      x23, x22, [sp, #0x10]
020f317c: f55302a9 stp      x21, x20, [sp, #0x20]
020f3180: f37b03a9 stp      x19, x30, [sp, #0x30]
020f3184: 56a401d0 adrp     x22, #0x557d000
020f3188: c8325539 ldrb     w8, [x22, #0x54c]
020f318c: f50302aa mov      x21, x2
020f3190: f40301aa mov      x20, x1
020f3194: f30300aa mov      x19, x0
020f3198: c8000037 tbnz     w8, #0, #0x20f31b0
020f319c: e0840190 adrp     x0, #0x518f000
020f31a0: 000447f9 ldr      x0, [x0, #0xe08]
020f31a4: 57f8ba97 bl       #0xfb1300
020f31a8: 28008052 mov      w8, #1
020f31ac: c8321539 strb     w8, [x22, #0x54c]
020f31b0: e00313aa mov      x0, x19
020f31b4: e10314aa mov      x1, x20
020f31b8: e20315aa mov      x2, x21
020f31bc: 24000094 bl       #0x20f324c ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$CalculateHighestScoreForRocket
020f31c0: 681e40f9 ldr      x8, [x19, #0x38]
020f31c4: 280400b4 cbz      x8, #0x20f3248
020f31c8: f8840190 adrp     x24, #0x518f000
020f31cc: 180747f9 ldr      x24, [x24, #0xe08]
020f31d0: 610a40f9 ldr      x1, [x19, #0x10]
020f31d4: f703002a mov      w23, w0
020f31d8: e00308aa mov      x0, x8
020f31dc: 020340f9 ldr      x2, [x24]
020f31e0: fc2e1194 bl       #0x253edd0 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromList<int>
020f31e4: f603002a mov      w22, w0
020f31e8: 550200b4 cbz      x21, #0x20f3230
020f31ec: ff020071 cmp      w23, #0
020f31f0: 0c020054 b.gt     #0x20f3230
020f31f4: e00313aa mov      x0, x19
020f31f8: e10314aa mov      x1, x20
020f31fc: e2031faa mov      x2, xzr
020f3200: 13000094 bl       #0x20f324c ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$CalculateHighestScoreForRocket
020f3204: 1f040071 cmp      w0, #1
020f3208: 4b010054 b.lt     #0x20f3230
020f320c: 601e40f9 ldr      x0, [x19, #0x38]
020f3210: c00100b4 cbz      x0, #0x20f3248
020f3214: 610a40f9 ldr      x1, [x19, #0x10]
020f3218: 020340f9 ldr      x2, [x24]
020f321c: f37b43a9 ldp      x19, x30, [sp, #0x30]
020f3220: f55342a9 ldp      x21, x20, [sp, #0x20]
020f3224: f75b41a9 ldp      x23, x22, [sp, #0x10]
020f3228: f80744f8 ldr      x24, [sp], #0x40
020f322c: e92e1114 b        #0x253edd0 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromList<int>
020f3230: e003162a mov      w0, w22
020f3234: f37b43a9 ldp      x19, x30, [sp, #0x30]
020f3238: f55342a9 ldp      x21, x20, [sp, #0x20]
020f323c: f75b41a9 ldp      x23, x22, [sp, #0x10]
020f3240: f80744f8 ldr      x24, [sp], #0x40
020f3244: c0035fd6 ret      
020f3248: 78f8ba97 bl       #0xfb1428
