# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$GetStartState
# Linear span to next metadata entry; not a complete CFG.
033a00cc: 40008052 mov      w0, #2
033a00d0: c0035fd6 ret      
