# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ResetSortingOffset
# Linear span to next metadata entry; not a complete CFG.
020eeca4: f40f1ef8 str      x20, [sp, #-0x20]!
020eeca8: f37b01a9 stp      x19, x30, [sp, #0x10]
020eecac: 73a401f0 adrp     x19, #0x557d000
020eecb0: f48501b0 adrp     x20, #0x51ab000
020eecb4: 680e5539 ldrb     w8, [x19, #0x543]
020eecb8: 94c642f9 ldr      x20, [x20, #0x588]
020eecbc: c8000037 tbnz     w8, #0, #0x20eecd4
020eecc0: e08501b0 adrp     x0, #0x51ab000
020eecc4: 00c442f9 ldr      x0, [x0, #0x588]
020eecc8: 8e09bb97 bl       #0xfb1300
020eeccc: 28008052 mov      w8, #1
020eecd0: 680e1539 strb     w8, [x19, #0x543]
020eecd4: 880240f9 ldr      x8, [x20]
020eecd8: 09e28452 mov      w9, #0x2710
020eecdc: 085d40f9 ldr      x8, [x8, #0xb8]
020eece0: 090100b9 str      w9, [x8]
020eece4: f37b41a9 ldp      x19, x30, [sp, #0x10]
020eece8: f40742f8 ldr      x20, [sp], #0x20
020eecec: c0035fd6 ret      
