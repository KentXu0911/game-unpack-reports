# Royal.Scenes.Game.Mechanics.Items.LogItem.LogItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01c1c448: e0031f2a mov      w0, wzr
01c1c44c: c0035fd6 ret      
