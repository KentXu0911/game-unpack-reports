# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$InitializeCurveVariables
# Linear span to next metadata entry; not a complete CFG.
033999e8: ef3bb96d stp      d15, d14, [sp, #-0x70]!
033999ec: ed33016d stp      d13, d12, [sp, #0x10]
033999f0: eb2b026d stp      d11, d10, [sp, #0x20]
033999f4: e923036d stp      d9, d8, [sp, #0x30]
033999f8: f62300f9 str      x22, [sp, #0x40]
033999fc: f55305a9 stp      x21, x20, [sp, #0x50]
03399a00: f37b06a9 stp      x19, x30, [sp, #0x60]
03399a04: 740f01b0 adrp     x20, #0x5586000
03399a08: 88826639 ldrb     w8, [x20, #0x9a0]
03399a0c: 481ca24e mov      v8.16b, v2.16b
03399a10: 291ca14e mov      v9.16b, v1.16b
03399a14: 0a1ca04e mov      v10.16b, v0.16b
03399a18: f30300aa mov      x19, x0
03399a1c: 28010037 tbnz     w8, #0, #0x3399a40
03399a20: a0f400d0 adrp     x0, #0x522f000
03399a24: 000445f9 ldr      x0, [x0, #0xa08]
03399a28: 365e7097 bl       #0xfb1300
03399a2c: 60f00090 adrp     x0, #0x51a5000
03399a30: 006445f9 ldr      x0, [x0, #0xac8]
03399a34: 335e7097 bl       #0xfb1300
03399a38: 28008052 mov      w8, #1
03399a3c: 88822639 strb     w8, [x20, #0x9a0]
03399a40: 603240f9 ldr      x0, [x19, #0x60]
03399a44: e02300b4 cbz      x0, #0x3399ec0
03399a48: 22008052 mov      w2, #1
03399a4c: e1031f2a mov      w1, wzr
03399a50: e3031faa mov      x3, xzr
03399a54: 34008052 mov      w20, #1
03399a58: c9be0b94 bl       #0x368957c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$PlayStartFlyAnimation
03399a5c: 0859a852 mov      w8, #0x42c80000
03399a60: 00e4002f movi     d0, #0000000000000000
03399a64: 7f8600b9 str      wzr, [x19, #0x84]
03399a68: 749600b9 str      w20, [x19, #0x94]
03399a6c: 681a00b9 str      w8, [x19, #0x18]
03399a70: 60c207fc stur     d0, [x19, #0x7c]
03399a74: 601200fd str      d0, [x19, #0x20]
03399a78: f50e01b0 adrp     x21, #0x5576000
03399a7c: a8b27c39 ldrb     w8, [x21, #0xf2c]
03399a80: a8000035 cbnz     w8, #0x3399a94
03399a84: 80f400d0 adrp     x0, #0x522b000
03399a88: 00ac43f9 ldr      x0, [x0, #0x758]
03399a8c: 1d5e7097 bl       #0xfb1300
03399a90: b4b23c39 strb     w20, [x21, #0xf2c]
03399a94: 94f400d0 adrp     x20, #0x522b000
03399a98: 94ae43f9 ldr      x20, [x20, #0x758]
03399a9c: 6b0240f9 ldr      x11, [x19]
03399aa0: e00313aa mov      x0, x19
03399aa4: 880240f9 ldr      x8, [x20]
03399aa8: 095d40f9 ldr      x9, [x8, #0xb8]
03399aac: 2a0140f9 ldr      x10, [x9]
03399ab0: 290940b9 ldr      w9, [x9, #8]
03399ab4: 6a2a00f9 str      x10, [x19, #0x50]
03399ab8: 695a00b9 str      w9, [x19, #0x58]
03399abc: 085d40f9 ldr      x8, [x8, #0xb8]
03399ac0: a9999952 mov      w9, #0xcccd
03399ac4: 89c9a772 movk     w9, #0x3e4c, lsl #16
03399ac8: 0a0140f9 ldr      x10, [x8]
03399acc: 080940b9 ldr      w8, [x8, #8]
03399ad0: 692e00b9 str      w9, [x19, #0x2c]
03399ad4: 6a4e00f9 str      x10, [x19, #0x98]
03399ad8: 68a200b9 str      w8, [x19, #0xa0]
03399adc: 68855ea9 ldp      x8, x1, [x11, #0x1e8]
03399ae0: 00013fd6 blr      x8
03399ae4: 680240f9 ldr      x8, [x19]
03399ae8: 603200bd str      s0, [x19, #0x30]
03399aec: e00313aa mov      x0, x19
03399af0: 09855fa9 ldp      x9, x1, [x8, #0x1f8]
03399af4: 20013fd6 blr      x9
03399af8: 603640f9 ldr      x0, [x19, #0x68]
03399afc: 603600bd str      s0, [x19, #0x34]
03399b00: 001e00b4 cbz      x0, #0x3399ec0
03399b04: e1031faa mov      x1, xzr
03399b08: c9c02594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
03399b0c: 0b1ca04e mov      v11.16b, v0.16b
03399b10: 0110201e fmov     s1, #2.00000000
03399b14: 0010231e fmov     s0, #6.00000000
03399b18: 603640f9 ldr      x0, [x19, #0x68]
03399b1c: 6021211e fcmp     s11, s1
03399b20: e8579f1a cset     w8, mi
03399b24: 6021201e fcmp     s11, s0
03399b28: e9d79f1a cset     w9, gt
03399b2c: 0801092a orr      w8, w8, w9
03399b30: 68720139 strb     w8, [x19, #0x5c]
03399b34: 601c00b4 cbz      x0, #0x3399ec0
03399b38: e1031faa mov      x1, xzr
03399b3c: 60c22594 bl       #0x3d0a4bc ; UnityEngine.Transform$$get_parent
03399b40: 763a40f9 ldr      x22, [x19, #0x70]
03399b44: f61b00b4 cbz      x22, #0x3399ec0
03399b48: aaf400d0 adrp     x10, #0x522f000
03399b4c: c80240f9 ldr      x8, [x22]
03399b50: 4a0545f9 ldr      x10, [x10, #0xa08]
03399b54: f50300aa mov      x21, x0
03399b58: 09554279 ldrh     w9, [x8, #0x12a]
03399b5c: 410140f9 ldr      x1, [x10]
03399b60: 290100b4 cbz      x9, #0x3399b84
03399b64: 0a5940f9 ldr      x10, [x8, #0xb0]
03399b68: 4a210091 add      x10, x10, #8
03399b6c: 4b815ff8 ldur     x11, [x10, #-8]
03399b70: 7f0101eb cmp      x11, x1
03399b74: 00010054 b.eq     #0x3399b94
03399b78: 290500f1 subs     x9, x9, #1
03399b7c: 4a410091 add      x10, x10, #0x10
03399b80: 61ffff54 b.ne     #0x3399b6c
03399b84: 22008052 mov      w2, #1
03399b88: e00316aa mov      x0, x22
03399b8c: d29d6f97 bl       #0xf812d4
03399b90: 05000014 b        #0x3399ba4
03399b94: 490140b9 ldr      w9, [x10]
03399b98: 29050011 add      w9, w9, #1
03399b9c: 08d1298b add      x8, x8, w9, sxtw #4
03399ba0: 00e10491 add      x0, x8, #0x138
03399ba4: 080440a9 ldp      x8, x1, [x0]
03399ba8: e00316aa mov      x0, x22
03399bac: 00013fd6 blr      x8
03399bb0: 951800b4 cbz      x21, #0x3399ec0
03399bb4: 76f00090 adrp     x22, #0x51a5000
03399bb8: d66645f9 ldr      x22, [x22, #0xac8]
03399bbc: e00315aa mov      x0, x21
03399bc0: e1031faa mov      x1, xzr
03399bc4: 70c52594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
03399bc8: 68724139 ldrb     w8, [x19, #0x5c]
03399bcc: 080b0034 cbz      w8, #0x3399d2c
03399bd0: f50e01b0 adrp     x21, #0x5576000
03399bd4: a8ba7c39 ldrb     w8, [x21, #0xf2e]
03399bd8: c8000035 cbnz     w8, #0x3399bf0
03399bdc: 80f400d0 adrp     x0, #0x522b000
03399be0: 00ac43f9 ldr      x0, [x0, #0x758]
03399be4: c75d7097 bl       #0xfb1300
03399be8: 28008052 mov      w8, #1
03399bec: a8ba3c39 strb     w8, [x21, #0xf2e]
03399bf0: 880240f9 ldr      x8, [x20]
03399bf4: eb4f00bd str      s11, [sp, #0x4c]
03399bf8: 550f01f0 adrp     x21, #0x5584000
03399bfc: a9fe4f39 ldrb     w9, [x21, #0x3ff]
03399c00: 085d40f9 ldr      x8, [x8, #0xb8]
03399c04: 0f39432d ldp      s15, s14, [x8, #0x18]
03399c08: 0c2140bd ldr      s12, [x8, #0x20]
03399c0c: c9000035 cbnz     w9, #0x3399c24
03399c10: 20f300f0 adrp     x0, #0x5200000
03399c14: 008c46f9 ldr      x0, [x0, #0xd18]
03399c18: ba5d7097 bl       #0xfb1300
03399c1c: 28008052 mov      w8, #1
03399c20: a8fe0f39 strb     w8, [x21, #0x3ff]
03399c24: 35f300f0 adrp     x21, #0x5200000
03399c28: b58e46f9 ldr      x21, [x21, #0xd18]
03399c2c: 40092a1e fmul     s0, s10, s10
03399c30: 2109291e fmul     s1, s9, s9
03399c34: 0028211e fadd     s0, s0, s1
03399c38: a00240f9 ldr      x0, [x21]
03399c3c: 0109281e fmul     s1, s8, s8
03399c40: 2d28201e fadd     s13, s1, s0
03399c44: e0092f1e fmul     s0, s15, s15
03399c48: 08e040b9 ldr      w8, [x0, #0xe0]
03399c4c: c1092e1e fmul     s1, s14, s14
03399c50: 0028211e fadd     s0, s0, s1
03399c54: 81092c1e fmul     s1, s12, s12
03399c58: 4b1daa4e mov      v11.16b, v10.16b
03399c5c: 2a1da94e mov      v10.16b, v9.16b
03399c60: 091da84e mov      v9.16b, v8.16b
03399c64: 2828201e fadd     s8, s1, s0
03399c68: 48000035 cbnz     w8, #0x3399c70
03399c6c: e65d7097 bl       #0xfb1404
03399c70: c85600d0 adrp     x8, #0x3e73000
03399c74: 018d4bbd ldr      s1, [x8, #0xb8c]
03399c78: a009281e fmul     s0, s13, s8
03399c7c: 00c0211e fsqrt    s0, s0
03399c80: 0d10201e fmov     s13, #2.00000000
03399c84: 0020211e fcmp     s0, s1
03399c88: e103271e fmov     s1, wzr
03399c8c: c4020054 b.mi     #0x3399ce4
03399c90: a00240f9 ldr      x0, [x21]
03399c94: 61092f1e fmul     s1, s11, s15
03399c98: 42092e1e fmul     s2, s10, s14
03399c9c: 23092c1e fmul     s3, s9, s12
03399ca0: 2128221e fadd     s1, s1, s2
03399ca4: 6128211e fadd     s1, s3, s1
03399ca8: 08e040b9 ldr      w8, [x0, #0xe0]
03399cac: 2018201e fdiv     s0, s1, s0
03399cb0: 01102e1e fmov     s1, #1.00000000
03399cb4: 02103e1e fmov     s2, #-1.00000000
03399cb8: 0158211e fmin     s1, s0, s1
03399cbc: 0020221e fcmp     s0, s2
03399cc0: 285c221e fcsel    s8, s1, s2, pl
03399cc4: 48000035 cbnz     w8, #0x3399ccc
03399cc8: cf5d7097 bl       #0xfb1404
03399ccc: 00c1221e fcvt     d0, s8
03399cd0: 3ca46497 bl       #0xcc2dc0
03399cd4: c85600d0 adrp     x8, #0x3e73000
03399cd8: 01914bbd ldr      s1, [x8, #0xb90]
03399cdc: 0040621e fcvt     s0, d0
03399ce0: 0108211e fmul     s1, s0, s1
03399ce4: e04f40bd ldr      s0, [sp, #0x4c]
03399ce8: 612a00bd str      s1, [x19, #0x28]
03399cec: 00202d1e fcmp     s0, s13
03399cf0: 65080054 b.pl     #0x3399dfc
03399cf4: f50e01f0 adrp     x21, #0x5578000
03399cf8: a86e4539 ldrb     w8, [x21, #0x15b]
03399cfc: c8000035 cbnz     w8, #0x3399d14
03399d00: 80f400d0 adrp     x0, #0x522b000
03399d04: 00ac43f9 ldr      x0, [x0, #0x758]
03399d08: 7e5d7097 bl       #0xfb1300
03399d0c: 28008052 mov      w8, #1
03399d10: a86e0539 strb     w8, [x21, #0x15b]
03399d14: 880240f9 ldr      x8, [x20]
03399d18: 0a5d40f9 ldr      x10, [x8, #0xb8]
03399d1c: 48210191 add      x8, x10, #0x48
03399d20: 49310191 add      x9, x10, #0x4c
03399d24: 4a410191 add      x10, x10, #0x50
03399d28: 42000014 b        #0x3399e30
03399d2c: e0031faa mov      x0, xzr
03399d30: 0c1ca04e mov      v12.16b, v0.16b
03399d34: d7cd0594 bl       #0x350d490 ; UnityEngine.Random$$get_value
03399d38: 0854a852 mov      w8, #0x42a00000
03399d3c: 0201271e fmov     s2, w8
03399d40: 0190261e fmov     s1, #20.00000000
03399d44: 0008221e fmul     s0, s0, s2
03399d48: 0028211e fadd     s0, s0, s1
03399d4c: 602a00bd str      s0, [x19, #0x28]
03399d50: f50e01f0 adrp     x21, #0x5578000
03399d54: a86e4539 ldrb     w8, [x21, #0x15b]
03399d58: c8000035 cbnz     w8, #0x3399d70
03399d5c: 80f400d0 adrp     x0, #0x522b000
03399d60: 00ac43f9 ldr      x0, [x0, #0x758]
03399d64: 675d7097 bl       #0xfb1300
03399d68: 28008052 mov      w8, #1
03399d6c: a86e0539 strb     w8, [x21, #0x15b]
03399d70: 880240f9 ldr      x8, [x20]
03399d74: 00102e1e fmov     s0, #1.00000000
03399d78: 8021201e fcmp     s12, s0
03399d7c: 095d40f9 ldr      x9, [x8, #0xb8]
03399d80: 2a2540f9 ldr      x10, [x9, #0x48]
03399d84: 295140b9 ldr      w9, [x9, #0x50]
03399d88: 6a1e00f9 str      x10, [x19, #0x38]
03399d8c: 694200b9 str      w9, [x19, #0x40]
03399d90: a5000054 b.pl     #0x3399da4
03399d94: 085d40f9 ldr      x8, [x8, #0xb8]
03399d98: 092540f9 ldr      x9, [x8, #0x48]
03399d9c: 085140b9 ldr      w8, [x8, #0x50]
03399da0: 0f000014 b        #0x3399ddc
03399da4: 0090231e fmov     s0, #7.00000000
03399da8: 8021201e fcmp     s12, s0
03399dac: ed010054 b.le     #0x3399de8
03399db0: f50e01d0 adrp     x21, #0x5577000
03399db4: a9627939 ldrb     w9, [x21, #0xe58]
03399db8: c9000035 cbnz     w9, #0x3399dd0
03399dbc: e00314aa mov      x0, x20
03399dc0: 505d7097 bl       #0xfb1300
03399dc4: 880240f9 ldr      x8, [x20]
03399dc8: 29008052 mov      w9, #1
03399dcc: a9623939 strb     w9, [x21, #0xe58]
03399dd0: 085d40f9 ldr      x8, [x8, #0xb8]
03399dd4: 094145f8 ldur     x9, [x8, #0x54]
03399dd8: 085d40b9 ldr      w8, [x8, #0x5c]
03399ddc: 691e00f9 str      x9, [x19, #0x38]
03399de0: 684200b9 str      w8, [x19, #0x40]
03399de4: 18000014 b        #0x3399e44
03399de8: e0031faa mov      x0, xzr
03399dec: a9cd0594 bl       #0x350d490 ; UnityEngine.Random$$get_value
03399df0: 01102c1e fmov     s1, #0.50000000
03399df4: 0020211e fcmp     s0, s1
03399df8: 04f8ff54 b.mi     #0x3399cf8
03399dfc: f50e01d0 adrp     x21, #0x5577000
03399e00: a8627939 ldrb     w8, [x21, #0xe58]
03399e04: c8000035 cbnz     w8, #0x3399e1c
03399e08: 80f400d0 adrp     x0, #0x522b000
03399e0c: 00ac43f9 ldr      x0, [x0, #0x758]
03399e10: 3c5d7097 bl       #0xfb1300
03399e14: 28008052 mov      w8, #1
03399e18: a8623939 strb     w8, [x21, #0xe58]
03399e1c: 880240f9 ldr      x8, [x20]
03399e20: 0a5d40f9 ldr      x10, [x8, #0xb8]
03399e24: 48510191 add      x8, x10, #0x54
03399e28: 49610191 add      x9, x10, #0x58
03399e2c: 4a710191 add      x10, x10, #0x5c
03399e30: 080140b9 ldr      w8, [x8]
03399e34: 290140b9 ldr      w9, [x9]
03399e38: 4a0140b9 ldr      w10, [x10]
03399e3c: 68260729 stp      w8, w9, [x19, #0x38]
03399e40: 6a4200b9 str      w10, [x19, #0x40]
03399e44: c00240f9 ldr      x0, [x22]
03399e48: 743240f9 ldr      x20, [x19, #0x60]
03399e4c: 08e040b9 ldr      w8, [x0, #0xe0]
03399e50: 48000035 cbnz     w8, #0x3399e58
03399e54: 6c5d7097 bl       #0xfb1404
03399e58: e0031f2a mov      w0, wzr
03399e5c: e1031f2a mov      w1, wzr
03399e60: e2031faa mov      x2, xzr
03399e64: 5b657f97 bl       #0x13733d0 ; Royal.Scenes.Game.Mechanics.Sortings.Sorting$$GetPropellerFlyingSorting
03399e68: 680240f9 ldr      x8, [x19]
03399e6c: f50300aa mov      x21, x0
03399e70: f60301aa mov      x22, x1
03399e74: e00313aa mov      x0, x19
03399e78: 096d41f9 ldr      x9, [x8, #0x2d8]
03399e7c: 087141f9 ldr      x8, [x8, #0x2e0]
03399e80: e10308aa mov      x1, x8
03399e84: 20013fd6 blr      x9
03399e88: d40100b4 cbz      x20, #0x3399ec0
03399e8c: c27e4092 and      x2, x22, #0xffffffff
03399e90: 03000012 and      w3, w0, #1
03399e94: e00314aa mov      x0, x20
03399e98: e10315aa mov      x1, x21
03399e9c: f37b46a9 ldp      x19, x30, [sp, #0x60]
03399ea0: f55345a9 ldp      x21, x20, [sp, #0x50]
03399ea4: f62340f9 ldr      x22, [sp, #0x40]
03399ea8: e923436d ldp      d9, d8, [sp, #0x30]
03399eac: eb2b426d ldp      d11, d10, [sp, #0x20]
03399eb0: ed33416d ldp      d13, d12, [sp, #0x10]
03399eb4: e4031faa mov      x4, xzr
03399eb8: ef3bc76c ldp      d15, d14, [sp], #0x70
03399ebc: 83d9ff17 b        #0x33904c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$UpdateSortingForAnimation
03399ec0: 5a5d7097 bl       #0xfb1428
