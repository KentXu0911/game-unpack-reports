# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy.<ExplodeNeighbors>d__13$$System.IDisposable.Dispose
# Linear span to next metadata entry; not a complete CFG.
033a3214: c0035fd6 ret      
