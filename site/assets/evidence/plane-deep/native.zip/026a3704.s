# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryExplode
# Linear span to next metadata entry; not a complete CFG.
026a3704: ff4302d1 sub      sp, sp, #0x90
026a3708: fe4300f9 str      x30, [sp, #0x80]
026a370c: 281840f9 ldr      x8, [x1, #0x30]
026a3710: 218040ad ldp      q1, q0, [x1, #0x10]
026a3714: 2200c03d ldr      q2, [x1]
026a3718: e1030191 add      x1, sp, #0x40
026a371c: e81b00f9 str      x8, [sp, #0x30]
026a3720: e18300ad stp      q1, q0, [sp, #0x10]
026a3724: e203803d str      q2, [sp]
026a3728: 090040f9 ldr      x9, [x0]
026a372c: 2af545f9 ldr      x10, [x9, #0xbe8]
026a3730: e20702ad stp      q2, q1, [sp, #0x40]
026a3734: e01b803d str      q0, [sp, #0x60]
026a3738: e83b00f9 str      x8, [sp, #0x70]
026a373c: 22f945f9 ldr      x2, [x9, #0xbf0]
026a3740: 40013fd6 blr      x10
026a3744: fe4340f9 ldr      x30, [sp, #0x80]
026a3748: ff430291 add      sp, sp, #0x90
026a374c: c0035fd6 ret      
