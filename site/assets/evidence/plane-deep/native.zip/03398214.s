# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$GetPoolId
# Linear span to next metadata entry; not a complete CFG.
03398214: 40018052 mov      w0, #0xa
03398218: c0035fd6 ret      
