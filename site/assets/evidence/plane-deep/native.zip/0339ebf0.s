# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$InitAngleVariables
# Linear span to next metadata entry; not a complete CFG.
0339ebf0: ff8302d1 sub      sp, sp, #0xa0
0339ebf4: ef3b026d stp      d15, d14, [sp, #0x20]
0339ebf8: ed33036d stp      d13, d12, [sp, #0x30]
0339ebfc: eb2b046d stp      d11, d10, [sp, #0x40]
0339ec00: e923056d stp      d9, d8, [sp, #0x50]
0339ec04: f83300f9 str      x24, [sp, #0x60]
0339ec08: f75b07a9 stp      x23, x22, [sp, #0x70]
0339ec0c: f55308a9 stp      x21, x20, [sp, #0x80]
0339ec10: f37b09a9 stp      x19, x30, [sp, #0x90]
0339ec14: 540f0190 adrp     x20, #0x5586000
0339ec18: 88da6639 ldrb     w8, [x20, #0x9b6]
0339ec1c: 481ca24e mov      v8.16b, v2.16b
0339ec20: 291ca14e mov      v9.16b, v1.16b
0339ec24: f30300aa mov      x19, x0
0339ec28: e06f00bd str      s0, [sp, #0x6c]
0339ec2c: c8000037 tbnz     w8, #0, #0x339ec44
0339ec30: 80f400b0 adrp     x0, #0x522f000
0339ec34: 000445f9 ldr      x0, [x0, #0xa08]
0339ec38: b2497097 bl       #0xfb1300
0339ec3c: 28008052 mov      w8, #1
0339ec40: 88da2639 strb     w8, [x20, #0x9b6]
0339ec44: 605a40fd ldr      d0, [x19, #0xb0]
0339ec48: 0c10211e fmov     s12, #3.00000000
0339ec4c: 0d90221e fmov     s13, #5.00000000
0339ec50: 753240f9 ldr      x21, [x19, #0x60]
0339ec54: 00202c1e fcmp     s0, s12
0339ec58: e8579f1a cset     w8, mi
0339ec5c: 00202d1e fcmp     s0, s13
0339ec60: e9d79f1a cset     w9, gt
0339ec64: 0801092a orr      w8, w8, w9
0339ec68: 68320139 strb     w8, [x19, #0x4c]
0339ec6c: 353200b4 cbz      x21, #0x339f2b0
0339ec70: 8af400b0 adrp     x10, #0x522f000
0339ec74: a80240f9 ldr      x8, [x21]
0339ec78: 4a0545f9 ldr      x10, [x10, #0xa08]
0339ec7c: 747240f9 ldr      x20, [x19, #0xe0]
0339ec80: e007803d str      q0, [sp, #0x10]
0339ec84: 09554279 ldrh     w9, [x8, #0x12a]
0339ec88: 410140f9 ldr      x1, [x10]
0339ec8c: 290100b4 cbz      x9, #0x339ecb0
0339ec90: 0a5940f9 ldr      x10, [x8, #0xb0]
0339ec94: 4a210091 add      x10, x10, #8
0339ec98: 4b815ff8 ldur     x11, [x10, #-8]
0339ec9c: 7f0101eb cmp      x11, x1
0339eca0: 00010054 b.eq     #0x339ecc0
0339eca4: 290500f1 subs     x9, x9, #1
0339eca8: 4a410091 add      x10, x10, #0x10
0339ecac: 61ffff54 b.ne     #0x339ec98
0339ecb0: 22008052 mov      w2, #1
0339ecb4: e00315aa mov      x0, x21
0339ecb8: 87896f97 bl       #0xf812d4
0339ecbc: 05000014 b        #0x339ecd0
0339ecc0: 490140b9 ldr      w9, [x10]
0339ecc4: 29050011 add      w9, w9, #1
0339ecc8: 08d1298b add      x8, x8, w9, sxtw #4
0339eccc: 00e10491 add      x0, x8, #0x138
0339ecd0: 080440a9 ldp      x8, x1, [x0]
0339ecd4: e00315aa mov      x0, x21
0339ecd8: 00013fd6 blr      x8
0339ecdc: b42e00b4 cbz      x20, #0x339f2b0
0339ece0: e00314aa mov      x0, x20
0339ece4: e1031faa mov      x1, xzr
0339ece8: 27b12594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
0339ecec: 021ca04e mov      v2.16b, v0.16b
0339ecf0: 22040c6e mov      v2.s[1], v1.s[0]
0339ecf4: e107c03d ldr      q1, [sp, #0x10]
0339ecf8: 74f400b0 adrp     x20, #0x522b000
0339ecfc: 68324139 ldrb     w8, [x19, #0x4c]
0339ed00: d50e01b0 adrp     x21, #0x5577000
0339ed04: 42d4a10e fsub     v2.2s, v2.2s, v1.2s
0339ed08: 62c20efc stur     d2, [x19, #0xec]
0339ed0c: 94ae43f9 ldr      x20, [x20, #0x758]
0339ed10: d60e01d0 adrp     x22, #0x5578000
0339ed14: e003803d str      q0, [sp]
0339ed18: 28020034 cbz      w8, #0x339ed5c
0339ed1c: 20202c1e fcmp     s1, s12
0339ed20: c5030054 b.pl     #0x339ed98
0339ed24: c86e4539 ldrb     w8, [x22, #0x15b]
0339ed28: e8000035 cbnz     w8, #0x339ed44
0339ed2c: 60f400b0 adrp     x0, #0x522b000
0339ed30: 00ac43f9 ldr      x0, [x0, #0x758]
0339ed34: 73497097 bl       #0xfb1300
0339ed38: e00740ad ldp      q0, q1, [sp]
0339ed3c: 28008052 mov      w8, #1
0339ed40: c86e0539 strb     w8, [x22, #0x15b]
0339ed44: 880240f9 ldr      x8, [x20]
0339ed48: 0b5d40f9 ldr      x11, [x8, #0xb8]
0339ed4c: 69210191 add      x9, x11, #0x48
0339ed50: 6a310191 add      x10, x11, #0x4c
0339ed54: 6b410191 add      x11, x11, #0x50
0339ed58: 1d000014 b        #0x339edcc
0339ed5c: 4820201e fcmp     s2, #0.0
0339ed60: c5080054 b.pl     #0x339ee78
0339ed64: a8627939 ldrb     w8, [x21, #0xe58]
0339ed68: c8000035 cbnz     w8, #0x339ed80
0339ed6c: 60f400b0 adrp     x0, #0x522b000
0339ed70: 00ac43f9 ldr      x0, [x0, #0x758]
0339ed74: 63497097 bl       #0xfb1300
0339ed78: 28008052 mov      w8, #1
0339ed7c: a8623939 strb     w8, [x21, #0xe58]
0339ed80: 880240f9 ldr      x8, [x20]
0339ed84: f7031f2a mov      w23, wzr
0339ed88: 095d40f9 ldr      x9, [x8, #0xb8]
0339ed8c: 2a4145f8 ldur     x10, [x9, #0x54]
0339ed90: 295d40b9 ldr      w9, [x9, #0x5c]
0339ed94: 46000014 b        #0x339eeac
0339ed98: a8627939 ldrb     w8, [x21, #0xe58]
0339ed9c: e8000035 cbnz     w8, #0x339edb8
0339eda0: 60f400b0 adrp     x0, #0x522b000
0339eda4: 00ac43f9 ldr      x0, [x0, #0x758]
0339eda8: 56497097 bl       #0xfb1300
0339edac: e00740ad ldp      q0, q1, [sp]
0339edb0: 28008052 mov      w8, #1
0339edb4: a8623939 strb     w8, [x21, #0xe58]
0339edb8: 880240f9 ldr      x8, [x20]
0339edbc: 0b5d40f9 ldr      x11, [x8, #0xb8]
0339edc0: 69510191 add      x9, x11, #0x54
0339edc4: 6a610191 add      x10, x11, #0x58
0339edc8: 6b710191 add      x11, x11, #0x5c
0339edcc: 290140b9 ldr      w9, [x9]
0339edd0: 4a0140b9 ldr      w10, [x10]
0339edd4: 6b0140b9 ldr      w11, [x11]
0339edd8: 20202c1e fcmp     s1, s12
0339eddc: 692a0529 stp      w9, w10, [x19, #0x28]
0339ede0: 6b3200b9 str      w11, [x19, #0x30]
0339ede4: 45010054 b.pl     #0x339ee0c
0339ede8: 0020211e fcmp     s0, s1
0339edec: 08010054 b.hi     #0x339ee0c
0339edf0: 60ee40bd ldr      s0, [x19, #0xec]
0339edf4: 0820201e fcmp     s0, #0.0
0339edf8: 01020054 b.ne     #0x339ee38
0339edfc: 60f240bd ldr      s0, [x19, #0xf0]
0339ee00: 0820201e fcmp     s0, #0.0
0339ee04: a5010054 b.pl     #0x339ee38
0339ee08: 14000014 b        #0x339ee58
0339ee0c: 20202d1e fcmp     s1, s13
0339ee10: f7031f2a mov      w23, wzr
0339ee14: ad090054 b.le     #0x339ef48
0339ee18: 0020211e fcmp     s0, s1
0339ee1c: 6b090054 b.lt     #0x339ef48
0339ee20: 60ee40bd ldr      s0, [x19, #0xec]
0339ee24: 0820201e fcmp     s0, #0.0
0339ee28: 81010054 b.ne     #0x339ee58
0339ee2c: 60f240bd ldr      s0, [x19, #0xf0]
0339ee30: 0820201e fcmp     s0, #0.0
0339ee34: 25010054 b.pl     #0x339ee58
0339ee38: a9627939 ldrb     w9, [x21, #0xe58]
0339ee3c: 29070035 cbnz     w9, #0x339ef20
0339ee40: e00314aa mov      x0, x20
0339ee44: 2f497097 bl       #0xfb1300
0339ee48: 880240f9 ldr      x8, [x20]
0339ee4c: 29008052 mov      w9, #1
0339ee50: a9623939 strb     w9, [x21, #0xe58]
0339ee54: 33000014 b        #0x339ef20
0339ee58: c96e4539 ldrb     w9, [x22, #0x15b]
0339ee5c: 89040035 cbnz     w9, #0x339eeec
0339ee60: e00314aa mov      x0, x20
0339ee64: 27497097 bl       #0xfb1300
0339ee68: 880240f9 ldr      x8, [x20]
0339ee6c: 29008052 mov      w9, #1
0339ee70: c96e0539 strb     w9, [x22, #0x15b]
0339ee74: 1e000014 b        #0x339eeec
0339ee78: 0d020054 b.le     #0x339eeb8
0339ee7c: c86e4539 ldrb     w8, [x22, #0x15b]
0339ee80: c8000035 cbnz     w8, #0x339ee98
0339ee84: 60f400b0 adrp     x0, #0x522b000
0339ee88: 00ac43f9 ldr      x0, [x0, #0x758]
0339ee8c: 1d497097 bl       #0xfb1300
0339ee90: 28008052 mov      w8, #1
0339ee94: c86e0539 strb     w8, [x22, #0x15b]
0339ee98: 880240f9 ldr      x8, [x20]
0339ee9c: f7031f2a mov      w23, wzr
0339eea0: 095d40f9 ldr      x9, [x8, #0xb8]
0339eea4: 2a2540f9 ldr      x10, [x9, #0x48]
0339eea8: 295140b9 ldr      w9, [x9, #0x50]
0339eeac: 6a1600f9 str      x10, [x19, #0x28]
0339eeb0: 693200b9 str      w9, [x19, #0x30]
0339eeb4: 25000014 b        #0x339ef48
0339eeb8: 605640f9 ldr      x0, [x19, #0xa8]
0339eebc: a01f00b4 cbz      x0, #0x339f2b0
0339eec0: e1031faa mov      x1, xzr
0339eec4: e03ccf97 bl       #0x276e244 ; Royal.Infrastructure.Utils.Randoming.RandomManager$$NextBool
0339eec8: c0010036 tbz      w0, #0, #0x339ef00
0339eecc: c86e4539 ldrb     w8, [x22, #0x15b]
0339eed0: c8000035 cbnz     w8, #0x339eee8
0339eed4: 60f400b0 adrp     x0, #0x522b000
0339eed8: 00ac43f9 ldr      x0, [x0, #0x758]
0339eedc: 09497097 bl       #0xfb1300
0339eee0: 28008052 mov      w8, #1
0339eee4: c86e0539 strb     w8, [x22, #0x15b]
0339eee8: 880240f9 ldr      x8, [x20]
0339eeec: 0b5d40f9 ldr      x11, [x8, #0xb8]
0339eef0: 69210191 add      x9, x11, #0x48
0339eef4: 6a310191 add      x10, x11, #0x4c
0339eef8: 6b410191 add      x11, x11, #0x50
0339eefc: 0d000014 b        #0x339ef30
0339ef00: a8627939 ldrb     w8, [x21, #0xe58]
0339ef04: c8000035 cbnz     w8, #0x339ef1c
0339ef08: 60f400b0 adrp     x0, #0x522b000
0339ef0c: 00ac43f9 ldr      x0, [x0, #0x758]
0339ef10: fc487097 bl       #0xfb1300
0339ef14: 28008052 mov      w8, #1
0339ef18: a8623939 strb     w8, [x21, #0xe58]
0339ef1c: 880240f9 ldr      x8, [x20]
0339ef20: 0b5d40f9 ldr      x11, [x8, #0xb8]
0339ef24: 69510191 add      x9, x11, #0x54
0339ef28: 6a610191 add      x10, x11, #0x58
0339ef2c: 6b710191 add      x11, x11, #0x5c
0339ef30: 290140b9 ldr      w9, [x9]
0339ef34: 4a0140b9 ldr      w10, [x10]
0339ef38: 6b0140b9 ldr      w11, [x11]
0339ef3c: 37008052 mov      w23, #1
0339ef40: 692a0529 stp      w9, w10, [x19, #0x28]
0339ef44: 6b3200b9 str      w11, [x19, #0x30]
0339ef48: 692240b9 ldr      w9, [x19, #0x20]
0339ef4c: 36008052 mov      w22, #1
0339ef50: 76f20239 strb     w22, [x19, #0xbc]
0339ef54: d80e0190 adrp     x24, #0x5576000
0339ef58: 691200b9 str      w9, [x19, #0x10]
0339ef5c: 09b37c39 ldrb     w9, [x24, #0xf2c]
0339ef60: a9000035 cbnz     w9, #0x339ef74
0339ef64: e00314aa mov      x0, x20
0339ef68: e6487097 bl       #0xfb1300
0339ef6c: 880240f9 ldr      x8, [x20]
0339ef70: 16b33c39 strb     w22, [x24, #0xf2c]
0339ef74: 085d40f9 ldr      x8, [x8, #0xb8]
0339ef78: 605640f9 ldr      x0, [x19, #0xa8]
0339ef7c: 090140f9 ldr      x9, [x8]
0339ef80: 080940b9 ldr      w8, [x8, #8]
0339ef84: 696200f9 str      x9, [x19, #0xc0]
0339ef88: 68ca00b9 str      w8, [x19, #0xc8]
0339ef8c: 201900b4 cbz      x0, #0x339f2b0
0339ef90: 60ee40bd ldr      s0, [x19, #0xec]
0339ef94: 0110281e fmov     s1, #0.12500000
0339ef98: 0f102e1e fmov     s15, #1.00000000
0339ef9c: 02d0251e fmov     s2, #15.00000000
0339efa0: 0008211e fmul     s0, s0, s1
0339efa4: 01582f1e fmin     s1, s0, s15
0339efa8: 2108221e fmul     s1, s1, s2
0339efac: 21282d1e fadd     s1, s1, s13
0339efb0: 0820201e fcmp     s0, #0.0
0339efb4: 215c2d1e fcsel    s1, s1, s13, pl
0339efb8: e003271e fmov     s0, wzr
0339efbc: e1031faa mov      x1, xzr
0339efc0: ea03271e fmov     s10, wzr
0339efc4: a93ccf97 bl       #0x276e268 ; Royal.Infrastructure.Utils.Randoming.RandomManager$$Next
0339efc8: 68324139 ldrb     w8, [x19, #0x4c]
0339efcc: 0b1ca04e mov      v11.16b, v0.16b
0339efd0: 04103e1e fmov     s4, #-1.00000000
0339efd4: 0e102c1e fmov     s14, #0.50000000
0339efd8: 0510331e fmov     s5, #-6.00000000
0339efdc: 77020034 cbz      w23, #0x339f028
0339efe0: 08060034 cbz      w8, #0x339f0a0
0339efe4: e207c03d ldr      q2, [sp, #0x10]
0339efe8: 40082e1e fmul     s0, s2, s14
0339efec: 4128251e fadd     s1, s2, s5
0339eff0: 40202c1e fcmp     s2, s12
0339eff4: e039201e fsub     s0, s15, s0
0339eff8: 21082e1e fmul     s1, s1, s14
0339effc: 004c211e fcsel    s0, s0, s1, mi
0339f000: 0290241e fmov     s2, #10.00000000
0339f004: 01582f1e fmin     s1, s0, s15
0339f008: 2108221e fmul     s1, s1, s2
0339f00c: 834c2f1e fcsel    s3, s4, s15, mi
0339f010: 21282d1e fadd     s1, s1, s13
0339f014: 0820201e fcmp     s0, #0.0
0339f018: 205c2d1e fcsel    s0, s1, s13, pl
0339f01c: 00282b1e fadd     s0, s0, s11
0339f020: 6a08201e fmul     s10, s3, s0
0339f024: 28000014 b        #0x339f0c4
0339f028: e8040035 cbnz     w8, #0x339f0c4
0339f02c: 6a2a40bd ldr      s10, [x19, #0x28]
0339f030: a8627939 ldrb     w8, [x21, #0xe58]
0339f034: 6dc242fc ldur     d13, [x19, #0x2c]
0339f038: 08010035 cbnz     w8, #0x339f058
0339f03c: 60f40090 adrp     x0, #0x522b000
0339f040: 00ac43f9 ldr      x0, [x0, #0x758]
0339f044: af487097 bl       #0xfb1300
0339f048: 0510331e fmov     s5, #-6.00000000
0339f04c: 04103e1e fmov     s4, #-1.00000000
0339f050: 28008052 mov      w8, #1
0339f054: a8623939 strb     w8, [x21, #0xe58]
0339f058: 880240f9 ldr      x8, [x20]
0339f05c: 085d40f9 ldr      x8, [x8, #0xb8]
0339f060: 005540bd ldr      s0, [x8, #0x54]
0339f064: 012d40fd ldr      d1, [x8, #0x58]
0339f068: a8560090 adrp     x8, #0x3e73000
0339f06c: 02314bbd ldr      s2, [x8, #0xb30]
0339f070: 4039201e fsub     s0, s10, s0
0339f074: a1d5a10e fsub     v1.2s, v13.2s, v1.2s
0339f078: 0008201e fmul     s0, s0, s0
0339f07c: 21dc212e fmul     v1.2s, v1.2s, v1.2s
0339f080: 0028211e fadd     s0, s0, s1
0339f084: 21040c5e mov      s1, v1.s[1]
0339f088: 2028201e fadd     s0, s1, s0
0339f08c: 0020221e fcmp     s0, s2
0339f090: 804c2f1e fcsel    s0, s4, s15, mi
0339f094: 6a09201e fmul     s10, s11, s0
0339f098: 0d90221e fmov     s13, #5.00000000
0339f09c: 0a000014 b        #0x339f0c4
0339f0a0: 605640f9 ldr      x0, [x19, #0xa8]
0339f0a4: 601000b4 cbz      x0, #0x339f2b0
0339f0a8: 0090241e fmov     s0, #10.00000000
0339f0ac: 01d0251e fmov     s1, #15.00000000
0339f0b0: e1031faa mov      x1, xzr
0339f0b4: 6d3ccf97 bl       #0x276e268 ; Royal.Infrastructure.Utils.Randoming.RandomManager$$Next
0339f0b8: 6a29201e fadd     s10, s11, s0
0339f0bc: 04103e1e fmov     s4, #-1.00000000
0339f0c0: 0510331e fmov     s5, #-6.00000000
0339f0c4: 60f240bd ldr      s0, [x19, #0xf0]
0339f0c8: 0020241e fcmp     s0, s4
0339f0cc: e003271e fmov     s0, wzr
0339f0d0: c4020054 b.mi     #0x339f128
0339f0d4: e003c03d ldr      q0, [sp]
0339f0d8: 00202c1e fcmp     s0, s12
0339f0dc: 64000054 b.mi     #0x339f0e8
0339f0e0: 00202d1e fcmp     s0, s13
0339f0e4: 4d020054 b.le     #0x339f12c
0339f0e8: 00202c1e fcmp     s0, s12
0339f0ec: 85000054 b.pl     #0x339f0fc
0339f0f0: e007c03d ldr      q0, [sp, #0x10]
0339f0f4: 00082e1e fmul     s0, s0, s14
0339f0f8: 06000014 b        #0x339f110
0339f0fc: e007c03d ldr      q0, [sp, #0x10]
0339f100: 01103c1e fmov     s1, #-0.50000000
0339f104: 0028251e fadd     s0, s0, s5
0339f108: 0008211e fmul     s0, s0, s1
0339f10c: 00282f1e fadd     s0, s0, s15
0339f110: 01582f1e fmin     s1, s0, s15
0339f114: e203271e fmov     s2, wzr
0339f118: 21082d1e fmul     s1, s1, s13
0339f11c: 2128221e fadd     s1, s1, s2
0339f120: 0820201e fcmp     s0, #0.0
0339f124: 205c221e fcsel    s0, s1, s2, pl
0339f128: 60da00bd str      s0, [x19, #0xd8]
0339f12c: 48560090 adrp     x8, #0x3e67000
0339f130: 005d44bd ldr      s0, [x8, #0x45c]
0339f134: e103271e fmov     s1, wzr
0339f138: e0031faa mov      x0, xzr
0339f13c: 4209201e fmul     s2, s10, s0
0339f140: e003271e fmov     s0, wzr
0339f144: 3a980594 bl       #0x350522c ; UnityEngine.Quaternion$$Internal_FromEulerRad
0339f148: b50e01f0 adrp     x21, #0x5576000
0339f14c: a8ba7c39 ldrb     w8, [x21, #0xf2e]
0339f150: 0b1ca04e mov      v11.16b, v0.16b
0339f154: 2c1ca14e mov      v12.16b, v1.16b
0339f158: 4d1ca24e mov      v13.16b, v2.16b
0339f15c: 6e1ca34e mov      v14.16b, v3.16b
0339f160: c8000035 cbnz     w8, #0x339f178
0339f164: 60f40090 adrp     x0, #0x522b000
0339f168: 00ac43f9 ldr      x0, [x0, #0x758]
0339f16c: 65487097 bl       #0xfb1300
0339f170: 28008052 mov      w8, #1
0339f174: a8ba3c39 strb     w8, [x21, #0xf2e]
0339f178: 880240f9 ldr      x8, [x20]
0339f17c: 601dab4e mov      v0.16b, v11.16b
0339f180: 811dac4e mov      v1.16b, v12.16b
0339f184: a21dad4e mov      v2.16b, v13.16b
0339f188: 085d40f9 ldr      x8, [x8, #0xb8]
0339f18c: c31dae4e mov      v3.16b, v14.16b
0339f190: e0031faa mov      x0, xzr
0339f194: 0415432d ldp      s4, s5, [x8, #0x18]
0339f198: 062140bd ldr      s6, [x8, #0x20]
0339f19c: 87970594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339f1a0: 340f01b0 adrp     x20, #0x5584000
0339f1a4: 88fe4f39 ldrb     w8, [x20, #0x3ff]
0339f1a8: 0c1ca04e mov      v12.16b, v0.16b
0339f1ac: 2d1ca14e mov      v13.16b, v1.16b
0339f1b0: 4b1ca24e mov      v11.16b, v2.16b
0339f1b4: c8000035 cbnz     w8, #0x339f1cc
0339f1b8: 00f300b0 adrp     x0, #0x5200000
0339f1bc: 008c46f9 ldr      x0, [x0, #0xd18]
0339f1c0: 50487097 bl       #0xfb1300
0339f1c4: 28008052 mov      w8, #1
0339f1c8: 88fe0f39 strb     w8, [x20, #0x3ff]
0339f1cc: 14f300b0 adrp     x20, #0x5200000
0339f1d0: e06f40bd ldr      s0, [sp, #0x6c]
0339f1d4: 948e46f9 ldr      x20, [x20, #0xd18]
0339f1d8: 2109291e fmul     s1, s9, s9
0339f1dc: 2e1da94e mov      v14.16b, v9.16b
0339f1e0: 0008201e fmul     s0, s0, s0
0339f1e4: 800240f9 ldr      x0, [x20]
0339f1e8: 0028211e fadd     s0, s0, s1
0339f1ec: 0109281e fmul     s1, s8, s8
0339f1f0: 2928201e fadd     s9, s1, s0
0339f1f4: 08e040b9 ldr      w8, [x0, #0xe0]
0339f1f8: 80092c1e fmul     s0, s12, s12
0339f1fc: a1092d1e fmul     s1, s13, s13
0339f200: 0028211e fadd     s0, s0, s1
0339f204: 61092b1e fmul     s1, s11, s11
0339f208: 2a28201e fadd     s10, s1, s0
0339f20c: 48000035 cbnz     w8, #0x339f214
0339f210: 7d487097 bl       #0xfb1404
0339f214: a8560090 adrp     x8, #0x3e73000
0339f218: 018d4bbd ldr      s1, [x8, #0xb8c]
0339f21c: 20092a1e fmul     s0, s9, s10
0339f220: 00c0211e fsqrt    s0, s0
0339f224: 0020211e fcmp     s0, s1
0339f228: e103271e fmov     s1, wzr
0339f22c: c4020054 b.mi     #0x339f284
0339f230: e16f40bd ldr      s1, [sp, #0x6c]
0339f234: 800240f9 ldr      x0, [x20]
0339f238: c2092d1e fmul     s2, s14, s13
0339f23c: 21082c1e fmul     s1, s1, s12
0339f240: 2128221e fadd     s1, s1, s2
0339f244: 02092b1e fmul     s2, s8, s11
0339f248: 4128211e fadd     s1, s2, s1
0339f24c: 08e040b9 ldr      w8, [x0, #0xe0]
0339f250: 2018201e fdiv     s0, s1, s0
0339f254: 02103e1e fmov     s2, #-1.00000000
0339f258: 01582f1e fmin     s1, s0, s15
0339f25c: 0020221e fcmp     s0, s2
0339f260: 285c221e fcsel    s8, s1, s2, pl
0339f264: 48000035 cbnz     w8, #0x339f26c
0339f268: 67487097 bl       #0xfb1404
0339f26c: 00c1221e fcvt     d0, s8
0339f270: d48e6497 bl       #0xcc2dc0
0339f274: a8560090 adrp     x8, #0x3e73000
0339f278: 01914bbd ldr      s1, [x8, #0xb90]
0339f27c: 0040621e fcvt     s0, d0
0339f280: 0108211e fmul     s1, s0, s1
0339f284: 611e00bd str      s1, [x19, #0x1c]
0339f288: f37b49a9 ldp      x19, x30, [sp, #0x90]
0339f28c: f55348a9 ldp      x21, x20, [sp, #0x80]
0339f290: f75b47a9 ldp      x23, x22, [sp, #0x70]
0339f294: f83340f9 ldr      x24, [sp, #0x60]
0339f298: e923456d ldp      d9, d8, [sp, #0x50]
0339f29c: eb2b446d ldp      d11, d10, [sp, #0x40]
0339f2a0: ed33436d ldp      d13, d12, [sp, #0x30]
0339f2a4: ef3b426d ldp      d15, d14, [sp, #0x20]
0339f2a8: ff830291 add      sp, sp, #0xa0
0339f2ac: c0035fd6 ret      
0339f2b0: 5e487097 bl       #0xfb1428
