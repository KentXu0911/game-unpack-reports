# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$get_ItemView
# Linear span to next metadata entry; not a complete CFG.
026a19e4: 006440f9 ldr      x0, [x0, #0xc8]
026a19e8: c0035fd6 ret      
