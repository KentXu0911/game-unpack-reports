# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$FindTarget
# Linear span to next metadata entry; not a complete CFG.
026a313c: ffc303d1 sub      sp, sp, #0xf0
026a3140: f66300f9 str      x22, [sp, #0xc0]
026a3144: f5530da9 stp      x21, x20, [sp, #0xd0]
026a3148: f37b0ea9 stp      x19, x30, [sp, #0xe0]
026a314c: f57601b0 adrp     x21, #0x5580000
026a3150: a8fa4039 ldrb     w8, [x21, #0x3e]
026a3154: f403012a mov      w20, w1
026a3158: f30300aa mov      x19, x0
026a315c: 88010037 tbnz     w8, #0, #0x26a318c
026a3160: c0580190 adrp     x0, #0x51bb000
026a3164: 009c46f9 ldr      x0, [x0, #0xd38]
026a3168: 6638a497 bl       #0xfb1300
026a316c: a05801b0 adrp     x0, #0x51b8000
026a3170: 002840f9 ldr      x0, [x0, #0x50]
026a3174: 6338a497 bl       #0xfb1300
026a3178: 205c01b0 adrp     x0, #0x5228000
026a317c: 000444f9 ldr      x0, [x0, #0x808]
026a3180: 6038a497 bl       #0xfb1300
026a3184: 28008052 mov      w8, #1
026a3188: a8fa0039 strb     w8, [x21, #0x3e]
026a318c: 606a40f9 ldr      x0, [x19, #0xd0]
026a3190: c01900b4 cbz      x0, #0x26a34c8
026a3194: e10313aa mov      x1, x19
026a3198: e2031faa mov      x2, xzr
026a319c: 5d30e997 bl       #0x20ef310 ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$FindForExploder
026a31a0: 75a640f9 ldr      x21, [x19, #0x148]
026a31a4: 750200b4 cbz      x21, #0x26a31f0
026a31a8: b65801b0 adrp     x22, #0x51b8000
026a31ac: a80240f9 ldr      x8, [x21]
026a31b0: d62a40f9 ldr      x22, [x22, #0x50]
026a31b4: 09554279 ldrh     w9, [x8, #0x12a]
026a31b8: c10240f9 ldr      x1, [x22]
026a31bc: 290100b4 cbz      x9, #0x26a31e0
026a31c0: 0a5940f9 ldr      x10, [x8, #0xb0]
026a31c4: 4a210091 add      x10, x10, #8
026a31c8: 4b815ff8 ldur     x11, [x10, #-8]
026a31cc: 7f0101eb cmp      x11, x1
026a31d0: c0010054 b.eq     #0x26a3208
026a31d4: 290500f1 subs     x9, x9, #1
026a31d8: 4a410091 add      x10, x10, #0x10
026a31dc: 61ffff54 b.ne     #0x26a31c8
026a31e0: c2018052 mov      w2, #0xe
026a31e4: e00315aa mov      x0, x21
026a31e8: 3b78a397 bl       #0xf812d4
026a31ec: 0b000014 b        #0x26a3218
026a31f0: e00313aa mov      x0, x19
026a31f4: f37b4ea9 ldp      x19, x30, [sp, #0xe0]
026a31f8: f5534da9 ldp      x21, x20, [sp, #0xd0]
026a31fc: f66340f9 ldr      x22, [sp, #0xc0]
026a3200: ffc30391 add      sp, sp, #0xf0
026a3204: 2efcff17 b        #0x26a22bc ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$ExplodeSelf
026a3208: 490140b9 ldr      w9, [x10]
026a320c: 29390011 add      w9, w9, #0xe
026a3210: 08d1298b add      x8, x8, w9, sxtw #4
026a3214: 00e10491 add      x0, x8, #0x138
026a3218: 080440a9 ldp      x8, x1, [x0]
026a321c: e00315aa mov      x0, x21
026a3220: 00013fd6 blr      x8
026a3224: 600e0036 tbz      w0, #0, #0x26a33f0
026a3228: 681641b9 ldr      w8, [x19, #0x114]
026a322c: 1f350071 cmp      w8, #0xd
026a3230: 010e0054 b.ne     #0x26a33f0
026a3234: 75a640f9 ldr      x21, [x19, #0x148]
026a3238: 951400b4 cbz      x21, #0x26a34c8
026a323c: a80240f9 ldr      x8, [x21]
026a3240: c10240f9 ldr      x1, [x22]
026a3244: 09554279 ldrh     w9, [x8, #0x12a]
026a3248: 290100b4 cbz      x9, #0x26a326c
026a324c: 0a5940f9 ldr      x10, [x8, #0xb0]
026a3250: 4a210091 add      x10, x10, #8
026a3254: 4b815ff8 ldur     x11, [x10, #-8]
026a3258: 7f0101eb cmp      x11, x1
026a325c: 00010054 b.eq     #0x26a327c
026a3260: 290500f1 subs     x9, x9, #1
026a3264: 4a410091 add      x10, x10, #0x10
026a3268: 61ffff54 b.ne     #0x26a3254
026a326c: 62008052 mov      w2, #3
026a3270: e00315aa mov      x0, x21
026a3274: 1878a397 bl       #0xf812d4
026a3278: 05000014 b        #0x26a328c
026a327c: 490140b9 ldr      w9, [x10]
026a3280: 290d0011 add      w9, w9, #3
026a3284: 08d1298b add      x8, x8, w9, sxtw #4
026a3288: 00e10491 add      x0, x8, #0x138
026a328c: 080440a9 ldp      x8, x1, [x0]
026a3290: e00315aa mov      x0, x21
026a3294: 00013fd6 blr      x8
026a3298: c00a00b4 cbz      x0, #0x26a33f0
026a329c: 68320491 add      x8, x19, #0x10c
026a32a0: 028140ad ldp      q2, q0, [x8, #0x10]
026a32a4: 091940f9 ldr      x9, [x8, #0x30]
026a32a8: 0101c03d ldr      q1, [x8]
026a32ac: 75a640f9 ldr      x21, [x19, #0x148]
026a32b0: e28302ad stp      q2, q0, [sp, #0x50]
026a32b4: e93b00f9 str      x9, [sp, #0x70]
026a32b8: e113803d str      q1, [sp, #0x40]
026a32bc: 751000b4 cbz      x21, #0x26a34c8
026a32c0: e10342ad ldp      q1, q0, [sp, #0x40]
026a32c4: e21bc03d ldr      q2, [sp, #0x60]
026a32c8: e83b40f9 ldr      x8, [sp, #0x70]
026a32cc: c10240f9 ldr      x1, [x22]
026a32d0: e10300ad stp      q1, q0, [sp]
026a32d4: e20b803d str      q2, [sp, #0x20]
026a32d8: e81b00f9 str      x8, [sp, #0x30]
026a32dc: a80240f9 ldr      x8, [x21]
026a32e0: 09554279 ldrh     w9, [x8, #0x12a]
026a32e4: 290100b4 cbz      x9, #0x26a3308
026a32e8: 0a5940f9 ldr      x10, [x8, #0xb0]
026a32ec: 4a210091 add      x10, x10, #8
026a32f0: 4b815ff8 ldur     x11, [x10, #-8]
026a32f4: 7f0101eb cmp      x11, x1
026a32f8: 00010054 b.eq     #0x26a3318
026a32fc: 290500f1 subs     x9, x9, #1
026a3300: 4a410091 add      x10, x10, #0x10
026a3304: 61ffff54 b.ne     #0x26a32f0
026a3308: 02018052 mov      w2, #8
026a330c: e00315aa mov      x0, x21
026a3310: f177a397 bl       #0xf812d4
026a3314: 05000014 b        #0x26a3328
026a3318: 490140b9 ldr      w9, [x10]
026a331c: 29210011 add      w9, w9, #8
026a3320: 08d1298b add      x8, x8, w9, sxtw #4
026a3324: 00e10491 add      x0, x8, #0x138
026a3328: e00b40ad ldp      q0, q2, [sp]
026a332c: e10bc03d ldr      q1, [sp, #0x20]
026a3330: e91b40f9 ldr      x9, [sp, #0x30]
026a3334: 080040f9 ldr      x8, [x0]
026a3338: e00b04ad stp      q0, q2, [sp, #0x80]
026a333c: e12b803d str      q1, [sp, #0xa0]
026a3340: e95b00f9 str      x9, [sp, #0xb0]
026a3344: 020440f9 ldr      x2, [x0, #8]
026a3348: e1030291 add      x1, sp, #0x80
026a334c: e00315aa mov      x0, x21
026a3350: 00013fd6 blr      x8
026a3354: e0040037 tbnz     w0, #0, #0x26a33f0
026a3358: 75a640f9 ldr      x21, [x19, #0x148]
026a335c: 750b00b4 cbz      x21, #0x26a34c8
026a3360: a80240f9 ldr      x8, [x21]
026a3364: c10240f9 ldr      x1, [x22]
026a3368: 09554279 ldrh     w9, [x8, #0x12a]
026a336c: 290100b4 cbz      x9, #0x26a3390
026a3370: 0a5940f9 ldr      x10, [x8, #0xb0]
026a3374: 4a210091 add      x10, x10, #8
026a3378: 4b815ff8 ldur     x11, [x10, #-8]
026a337c: 7f0101eb cmp      x11, x1
026a3380: 00010054 b.eq     #0x26a33a0
026a3384: 290500f1 subs     x9, x9, #1
026a3388: 4a410091 add      x10, x10, #0x10
026a338c: 61ffff54 b.ne     #0x26a3378
026a3390: 62008052 mov      w2, #3
026a3394: e00315aa mov      x0, x21
026a3398: cf77a397 bl       #0xf812d4
026a339c: 05000014 b        #0x26a33b0
026a33a0: 490140b9 ldr      w9, [x10]
026a33a4: 290d0011 add      w9, w9, #3
026a33a8: 08d1298b add      x8, x8, w9, sxtw #4
026a33ac: 00e10491 add      x0, x8, #0x138
026a33b0: 080440a9 ldp      x8, x1, [x0]
026a33b4: e00315aa mov      x0, x21
026a33b8: 00013fd6 blr      x8
026a33bc: f50313aa mov      x21, x19
026a33c0: a00e0cf8 str      x0, [x21, #0xc0]!
026a33c4: e10300aa mov      x1, x0
026a33c8: e00315aa mov      x0, x21
026a33cc: b837a497 bl       #0xfb12ac
026a33d0: a00240f9 ldr      x0, [x21]
026a33d4: a00700b4 cbz      x0, #0x26a34c8
026a33d8: e1031faa mov      x1, xzr
026a33dc: f7a01094 bl       #0x2acb7b8 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetViewPosition
026a33e0: 28008052 mov      w8, #1
026a33e4: 60061d2d stp      s0, s1, [x19, #0xe8]
026a33e8: 62f200bd str      s2, [x19, #0xf0]
026a33ec: 68220439 strb     w8, [x19, #0x108]
026a33f0: 757240f9 ldr      x21, [x19, #0xe0]
026a33f4: b50600b4 cbz      x21, #0x26a34c8
026a33f8: 2a5c01b0 adrp     x10, #0x5228000
026a33fc: a80240f9 ldr      x8, [x21]
026a3400: 4a0544f9 ldr      x10, [x10, #0x808]
026a3404: d6580190 adrp     x22, #0x51bb000
026a3408: 09554279 ldrh     w9, [x8, #0x12a]
026a340c: 410140f9 ldr      x1, [x10]
026a3410: d69e46f9 ldr      x22, [x22, #0xd38]
026a3414: 290100b4 cbz      x9, #0x26a3438
026a3418: 0a5940f9 ldr      x10, [x8, #0xb0]
026a341c: 4a210091 add      x10, x10, #8
026a3420: 4b815ff8 ldur     x11, [x10, #-8]
026a3424: 7f0101eb cmp      x11, x1
026a3428: 00010054 b.eq     #0x26a3448
026a342c: 290500f1 subs     x9, x9, #1
026a3430: 4a410091 add      x10, x10, #0x10
026a3434: 61ffff54 b.ne     #0x26a3420
026a3438: a2008052 mov      w2, #5
026a343c: e00315aa mov      x0, x21
026a3440: a577a397 bl       #0xf812d4
026a3444: 05000014 b        #0x26a3458
026a3448: 490140b9 ldr      w9, [x10]
026a344c: 29150011 add      w9, w9, #5
026a3450: 08d1298b add      x8, x8, w9, sxtw #4
026a3454: 00e10491 add      x0, x8, #0x138
026a3458: 080440a9 ldp      x8, x1, [x0]
026a345c: e00315aa mov      x0, x21
026a3460: 00013fd6 blr      x8
026a3464: c00240f9 ldr      x0, [x22]
026a3468: 756640f9 ldr      x21, [x19, #0xc8]
026a346c: eb37a497 bl       #0xfb1418
026a3470: c00200b4 cbz      x0, #0x26a34c8
026a3474: 680240f9 ldr      x8, [x19]
026a3478: e10313aa mov      x1, x19
026a347c: e3031faa mov      x3, xzr
026a3480: f60300aa mov      x22, x0
026a3484: 020146f9 ldr      x2, [x8, #0xc00]
026a3488: fa85e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a348c: f50100b4 cbz      x21, #0x26a34c8
026a3490: a80240f9 ldr      x8, [x21]
026a3494: 81020012 and      w1, w20, #1
026a3498: e00315aa mov      x0, x21
026a349c: e20316aa mov      x2, x22
026a34a0: 092d42f9 ldr      x9, [x8, #0x458]
026a34a4: 033142f9 ldr      x3, [x8, #0x460]
026a34a8: 20013fd6 blr      x9
026a34ac: e00313aa mov      x0, x19
026a34b0: 07000094 bl       #0x26a34cc ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$FreezeColumn
026a34b4: f37b4ea9 ldp      x19, x30, [sp, #0xe0]
026a34b8: f5534da9 ldp      x21, x20, [sp, #0xd0]
026a34bc: f66340f9 ldr      x22, [sp, #0xc0]
026a34c0: ffc30391 add      sp, sp, #0xf0
026a34c4: c0035fd6 ret      
026a34c8: d837a497 bl       #0xfb1428
