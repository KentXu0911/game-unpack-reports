# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy.<ExplodeNeighbors>d__13$$System.Collections.IEnumerator.Reset
# Linear span to next metadata entry; not a complete CFG.
033a3980: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a3984: 20f100b0 adrp     x0, #0x51c8000
033a3988: 003c45f9 ldr      x0, [x0, #0xa78]
033a398c: 62367097 bl       #0xfb1314
033a3990: a2367097 bl       #0xfb1418
033a3994: f30300aa mov      x19, x0
033a3998: 6f936497 bl       #0xcc8754
033a399c: e00313aa mov      x0, x19
033a39a0: e1031faa mov      x1, xzr
033a39a4: 58dac797 bl       #0x259a304 ; System.NotSupportedException$$.ctor
033a39a8: c0f200b0 adrp     x0, #0x51fc000
033a39ac: 008041f9 ldr      x0, [x0, #0x300]
033a39b0: 59367097 bl       #0xfb1314
033a39b4: e10300aa mov      x1, x0
033a39b8: e00313aa mov      x0, x19
033a39bc: 8d367097 bl       #0xfb13f0
