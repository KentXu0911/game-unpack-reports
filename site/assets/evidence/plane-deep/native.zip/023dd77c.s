# Royal.Scenes.Game.Mechanics.Items.LanternItem.LanternItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
023dd77c: e80f1efc str      d8, [sp, #-0x20]!
023dd780: f40700f9 str      x20, [sp, #8]
023dd784: f37b01a9 stp      x19, x30, [sp, #0x10]
023dd788: f303012a mov      w19, w1
023dd78c: f40300aa mov      x20, x0
023dd790: e003012a mov      w0, w1
023dd794: e1031faa mov      x1, xzr
023dd798: 699c3e94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
023dd79c: e803271e fmov     s8, wzr
023dd7a0: a0030037 tbnz     w0, #0, #0x23dd814
023dd7a4: 880240f9 ldr      x8, [x20]
023dd7a8: e00314aa mov      x0, x20
023dd7ac: 095542f9 ldr      x9, [x8, #0x4a8]
023dd7b0: 015942f9 ldr      x1, [x8, #0x4b0]
023dd7b4: 20013fd6 blr      x9
023dd7b8: 1f080071 cmp      w0, #2
023dd7bc: c1020054 b.ne     #0x23dd814
023dd7c0: 886640f9 ldr      x8, [x20, #0xc8]
023dd7c4: c80400b4 cbz      x8, #0x23dd85c
023dd7c8: 094140b9 ldr      w9, [x8, #0x40]
023dd7cc: 3f010071 cmp      w9, #0
023dd7d0: 8c000054 b.gt     #0x23dd7e0
023dd7d4: 084540b9 ldr      w8, [x8, #0x44]
023dd7d8: 1f050071 cmp      w8, #1
023dd7dc: cb030054 b.lt     #0x23dd854
023dd7e0: 880240f9 ldr      x8, [x20]
023dd7e4: e00314aa mov      x0, x20
023dd7e8: 09bd41f9 ldr      x9, [x8, #0x378]
023dd7ec: 01c141f9 ldr      x1, [x8, #0x380]
023dd7f0: 20013fd6 blr      x9
023dd7f4: e1031faa mov      x1, xzr
023dd7f8: 649c3e94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
023dd7fc: 0000221e scvtf    s0, w0
023dd800: 0028201e fadd     s0, s0, s0
023dd804: 0110211e fmov     s1, #3.00000000
023dd808: 0018211e fdiv     s0, s0, s1
023dd80c: e103271e fmov     s1, wzr
023dd810: 2838201e fsub     s8, s1, s0
023dd814: e00314aa mov      x0, x20
023dd818: e103132a mov      w1, w19
023dd81c: e2031faa mov      x2, xzr
023dd820: 539c3e94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
023dd824: 0000221e scvtf    s0, w0
023dd828: 08f0af52 mov      w8, #0x7f800000
023dd82c: f37b41a9 ldp      x19, x30, [sp, #0x10]
023dd830: f40740f9 ldr      x20, [sp, #8]
023dd834: 0029201e fadd     s0, s8, s0
023dd838: 0101271e fmov     s1, w8
023dd83c: 0800381e fcvtzs   w8, s0
023dd840: 0020211e fcmp     s0, s1
023dd844: 0900b052 mov      w9, #-0x80000000
023dd848: 2001881a csel     w0, w9, w8, eq
023dd84c: e80742fc ldr      d8, [sp], #0x20
023dd850: c0035fd6 ret      
023dd854: e003271e fmov     s0, wzr
023dd858: edffff17 b        #0x23dd80c
023dd85c: f34eaf97 bl       #0xfb1428
