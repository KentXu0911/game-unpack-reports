# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$SwapAnimationStarted
# Linear span to next metadata entry; not a complete CFG.
0339821c: f553bea9 stp      x21, x20, [sp, #-0x20]!
03398220: f37b01a9 stp      x19, x30, [sp, #0x10]
03398224: f403022a mov      w20, w2
03398228: f503012a mov      w21, w1
0339822c: 21000012 and      w1, w1, #1
03398230: e2031f2a mov      w2, wzr
03398234: e3031faa mov      x3, xzr
03398238: f30300aa mov      x19, x0
0339823c: d5e0ff97 bl       #0x3390590 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$SwapAnimationStarted
03398240: b5000036 tbz      w21, #0, #0x3398254
03398244: 9f160071 cmp      w20, #5
03398248: 60000054 b.eq     #0x3398254
0339824c: 9f7e0071 cmp      w20, #0x1f
03398250: 81000054 b.ne     #0x3398260
03398254: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398258: f553c2a8 ldp      x21, x20, [sp], #0x20
0339825c: c0035fd6 ret      
03398260: e00313aa mov      x0, x19
03398264: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398268: 21008052 mov      w1, #1
0339826c: 22008052 mov      w2, #1
03398270: e3031faa mov      x3, xzr
03398274: f553c2a8 ldp      x21, x20, [sp], #0x20
03398278: c1c40b14 b        #0x368957c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$PlayStartFlyAnimation
