# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$.cctor
# Linear span to next metadata entry; not a complete CFG.
0339fe80: f40f1ef8 str      x20, [sp, #-0x20]!
0339fe84: f37b01a9 stp      x19, x30, [sp, #0x10]
0339fe88: 330f01f0 adrp     x19, #0x5586000
0339fe8c: 54f200d0 adrp     x20, #0x51e9000
0339fe90: 68f26639 ldrb     w8, [x19, #0x9bc]
0339fe94: 94ee44f9 ldr      x20, [x20, #0x9d8]
0339fe98: c8000037 tbnz     w8, #0, #0x339feb0
0339fe9c: 40f200d0 adrp     x0, #0x51e9000
0339fea0: 00ec44f9 ldr      x0, [x0, #0x9d8]
0339fea4: 17457097 bl       #0xfb1300
0339fea8: 28008052 mov      w8, #1
0339feac: 68f22639 strb     w8, [x19, #0x9bc]
0339feb0: 880240f9 ldr      x8, [x20]
0339feb4: 495b00d0 adrp     x9, #0x3f09000
0339feb8: 205144fd ldr      d0, [x9, #0x8a0]
0339febc: 085d40f9 ldr      x8, [x8, #0xb8]
0339fec0: 000100fd str      d0, [x8]
0339fec4: 1f0900b9 str      wzr, [x8, #8]
0339fec8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339fecc: f40742f8 ldr      x20, [sp], #0x20
0339fed0: c0035fd6 ret      
