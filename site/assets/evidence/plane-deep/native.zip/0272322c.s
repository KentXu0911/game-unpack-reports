# Royal.Scenes.Game.Mechanics.Items.CaldronItem.CaldronItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0272322c: f553bea9 stp      x21, x20, [sp, #-0x20]!
02723230: f37b01a9 stp      x19, x30, [sp, #0x10]
02723234: 08084339 ldrb     w8, [x0, #0xc2]
02723238: 28020034 cbz      w8, #0x272327c
0272323c: 155c40f9 ldr      x21, [x0, #0xb8]
02723240: f30300aa mov      x19, x0
02723244: 150300b4 cbz      x21, #0x27232a4
02723248: e00315aa mov      x0, x21
0272324c: f403012a mov      w20, w1
02723250: 30f9ff97 bl       #0x2721710 ; Royal.Scenes.Game.Mechanics.Items.CaldronItem.CaldronItemHelper$$GetThrowItemGoal
02723254: a84640b9 ldr      w8, [x21, #0x44]
02723258: 1f01006b cmp      w8, w0
0272325c: 0a010054 b.ge     #0x272327c
02723260: 756a40b9 ldr      w21, [x19, #0x68]
02723264: e00313aa mov      x0, x19
02723268: bffcff97 bl       #0x2722564 ; Royal.Scenes.Game.Mechanics.Items.CaldronItem.CaldronItemModel$$GetTotalIncoming
0272326c: 0800154b sub      w8, w0, w21
02723270: 080d0011 add      w8, w8, #3
02723274: 1f090071 cmp      w8, #2
02723278: ad000054 b.le     #0x272328c
0272327c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02723280: e0031f2a mov      w0, wzr
02723284: f553c2a8 ldp      x21, x20, [sp], #0x20
02723288: c0035fd6 ret      
0272328c: e00313aa mov      x0, x19
02723290: f37b41a9 ldp      x19, x30, [sp, #0x10]
02723294: e103142a mov      w1, w20
02723298: e2031faa mov      x2, xzr
0272329c: f553c2a8 ldp      x21, x20, [sp], #0x20
027232a0: b3853114 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
027232a4: 6138a297 bl       #0xfb1428
