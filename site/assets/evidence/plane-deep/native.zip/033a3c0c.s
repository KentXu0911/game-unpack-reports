# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerPropellerComboStrategy$$IsComboExploder
# Linear span to next metadata entry; not a complete CFG.
033a3c0c: 20008052 mov      w0, #1
033a3c10: c0035fd6 ret      
