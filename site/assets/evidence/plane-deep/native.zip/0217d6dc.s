# Royal.Scenes.Game.Mechanics.Items.AncientVaultItem.AncientVaultItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0217d6dc: f40f1ef8 str      x20, [sp, #-0x20]!
0217d6e0: f37b01a9 stp      x19, x30, [sp, #0x10]
0217d6e4: 080040f9 ldr      x8, [x0]
0217d6e8: f403012a mov      w20, w1
0217d6ec: f30300aa mov      x19, x0
0217d6f0: 096542f9 ldr      x9, [x8, #0x4c8]
0217d6f4: 086942f9 ldr      x8, [x8, #0x4d0]
0217d6f8: e10308aa mov      x1, x8
0217d6fc: 20013fd6 blr      x9
0217d700: e0000034 cbz      w0, #0x217d71c
0217d704: e00313aa mov      x0, x19
0217d708: f37b41a9 ldp      x19, x30, [sp, #0x10]
0217d70c: e103142a mov      w1, w20
0217d710: e2031faa mov      x2, xzr
0217d714: f40742f8 ldr      x20, [sp], #0x20
0217d718: 5e514814 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
0217d71c: f37b41a9 ldp      x19, x30, [sp, #0x10]
0217d720: f40742f8 ldr      x20, [sp], #0x20
0217d724: c0035fd6 ret      
