# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerRocketComboParticles$$Play
# Linear span to next metadata entry; not a complete CFG.
03398914: 011840f9 ldr      x1, [x0, #0x30]
03398918: e2031faa mov      x2, xzr
0339891c: b1b3ff17 b        #0x33857e0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemParticles$$PlayParticles
