# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$FakeTargetReached
# Linear span to next metadata entry; not a complete CFG.
026a22ec: ff8302d1 sub      sp, sp, #0xa0
026a22f0: f44300f9 str      x20, [sp, #0x80]
026a22f4: f37b09a9 stp      x19, x30, [sp, #0x90]
026a22f8: f47601d0 adrp     x20, #0x5580000
026a22fc: 88ee4039 ldrb     w8, [x20, #0x3b]
026a2300: f30300aa mov      x19, x0
026a2304: 28010037 tbnz     w8, #0, #0x26a2328
026a2308: a05801d0 adrp     x0, #0x51b8000
026a230c: 002840f9 ldr      x0, [x0, #0x50]
026a2310: fc3ba497 bl       #0xfb1300
026a2314: 205c01d0 adrp     x0, #0x5228000
026a2318: 000444f9 ldr      x0, [x0, #0x808]
026a231c: f93ba497 bl       #0xfb1300
026a2320: 28008052 mov      w8, #1
026a2324: 88ee0039 strb     w8, [x20, #0x3b]
026a2328: e00313aa mov      x0, x19
026a232c: 55000094 bl       #0x26a2480 ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryDeregisterForTargetChange
026a2330: 74a640f9 ldr      x20, [x19, #0x148]
026a2334: 340500b4 cbz      x20, #0x26a23d8
026a2338: 68320491 add      x8, x19, #0x10c
026a233c: 091940f9 ldr      x9, [x8, #0x30]
026a2340: 018140ad ldp      q1, q0, [x8, #0x10]
026a2344: 0201c03d ldr      q2, [x8]
026a2348: aa5801d0 adrp     x10, #0x51b8000
026a234c: e91b00f9 str      x9, [sp, #0x30]
026a2350: e18300ad stp      q1, q0, [sp, #0x10]
026a2354: e203803d str      q2, [sp]
026a2358: 880240f9 ldr      x8, [x20]
026a235c: 4a2940f9 ldr      x10, [x10, #0x50]
026a2360: 09554279 ldrh     w9, [x8, #0x12a]
026a2364: 410140f9 ldr      x1, [x10]
026a2368: 290100b4 cbz      x9, #0x26a238c
026a236c: 0a5940f9 ldr      x10, [x8, #0xb0]
026a2370: 4a210091 add      x10, x10, #8
026a2374: 4b815ff8 ldur     x11, [x10, #-8]
026a2378: 7f0101eb cmp      x11, x1
026a237c: 00010054 b.eq     #0x26a239c
026a2380: 290500f1 subs     x9, x9, #1
026a2384: 4a410091 add      x10, x10, #0x10
026a2388: 61ffff54 b.ne     #0x26a2374
026a238c: e2008052 mov      w2, #7
026a2390: e00314aa mov      x0, x20
026a2394: d07ba397 bl       #0xf812d4
026a2398: 05000014 b        #0x26a23ac
026a239c: 490140b9 ldr      w9, [x10]
026a23a0: 291d0011 add      w9, w9, #7
026a23a4: 08d1298b add      x8, x8, w9, sxtw #4
026a23a8: 00e10491 add      x0, x8, #0x138
026a23ac: e00b40ad ldp      q0, q2, [sp]
026a23b0: e10bc03d ldr      q1, [sp, #0x20]
026a23b4: e91b40f9 ldr      x9, [sp, #0x30]
026a23b8: 080040f9 ldr      x8, [x0]
026a23bc: e00b02ad stp      q0, q2, [sp, #0x40]
026a23c0: e11b803d str      q1, [sp, #0x60]
026a23c4: e93b00f9 str      x9, [sp, #0x70]
026a23c8: 020440f9 ldr      x2, [x0, #8]
026a23cc: e1030191 add      x1, sp, #0x40
026a23d0: e00314aa mov      x0, x20
026a23d4: 00013fd6 blr      x8
026a23d8: 606e40f9 ldr      x0, [x19, #0xd8]
026a23dc: 7fde0339 strb     wzr, [x19, #0xf7]
026a23e0: e00400b4 cbz      x0, #0x26a247c
026a23e4: 61008052 mov      w1, #3
026a23e8: e2031faa mov      x2, xzr
026a23ec: 1a5d0e94 bl       #0x2a39854 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$OperationFinish
026a23f0: 606e40f9 ldr      x0, [x19, #0xd8]
026a23f4: 400400b4 cbz      x0, #0x26a247c
026a23f8: e1031faa mov      x1, xzr
026a23fc: 856c0e94 bl       #0x2a3d610 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$FinishSpecialOperation
026a2400: 737240f9 ldr      x19, [x19, #0xe0]
026a2404: d30300b4 cbz      x19, #0x26a247c
026a2408: 2a5c01d0 adrp     x10, #0x5228000
026a240c: 680240f9 ldr      x8, [x19]
026a2410: 4a0544f9 ldr      x10, [x10, #0x808]
026a2414: 09554279 ldrh     w9, [x8, #0x12a]
026a2418: 410140f9 ldr      x1, [x10]
026a241c: 290100b4 cbz      x9, #0x26a2440
026a2420: 0a5940f9 ldr      x10, [x8, #0xb0]
026a2424: 4a210091 add      x10, x10, #8
026a2428: 4b815ff8 ldur     x11, [x10, #-8]
026a242c: 7f0101eb cmp      x11, x1
026a2430: 00010054 b.eq     #0x26a2450
026a2434: 290500f1 subs     x9, x9, #1
026a2438: 4a410091 add      x10, x10, #0x10
026a243c: 61ffff54 b.ne     #0x26a2428
026a2440: e2008052 mov      w2, #7
026a2444: e00313aa mov      x0, x19
026a2448: a37ba397 bl       #0xf812d4
026a244c: 05000014 b        #0x26a2460
026a2450: 490140b9 ldr      w9, [x10]
026a2454: 291d0011 add      w9, w9, #7
026a2458: 08d1298b add      x8, x8, w9, sxtw #4
026a245c: 00e10491 add      x0, x8, #0x138
026a2460: 080440a9 ldp      x8, x1, [x0]
026a2464: e00313aa mov      x0, x19
026a2468: 00013fd6 blr      x8
026a246c: f37b49a9 ldp      x19, x30, [sp, #0x90]
026a2470: f44340f9 ldr      x20, [sp, #0x80]
026a2474: ff830291 add      sp, sp, #0xa0
026a2478: c0035fd6 ret      
026a247c: eb3ba497 bl       #0xfb1428
