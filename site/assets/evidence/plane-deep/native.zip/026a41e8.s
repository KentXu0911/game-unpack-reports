# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$Tap
# Linear span to next metadata entry; not a complete CFG.
026a41e8: e0031f2a mov      w0, wzr
026a41ec: c0035fd6 ret      
