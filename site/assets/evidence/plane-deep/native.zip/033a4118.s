# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy.<ExplodeWithDelay>d__4$$MoveNext
# Linear span to next metadata entry; not a complete CFG.
033a4118: ff8302d1 sub      sp, sp, #0xa0
033a411c: f55308a9 stp      x21, x20, [sp, #0x80]
033a4120: f37b09a9 stp      x19, x30, [sp, #0x90]
033a4124: 140f01d0 adrp     x20, #0x5586000
033a4128: 88526739 ldrb     w8, [x20, #0x9d4]
033a412c: f30300aa mov      x19, x0
033a4130: 28010037 tbnz     w8, #0, #0x33a4154
033a4134: c0f20090 adrp     x0, #0x51fc000
033a4138: 002047f9 ldr      x0, [x0, #0xe40]
033a413c: 71347097 bl       #0xfb1300
033a4140: 00f20090 adrp     x0, #0x51e4000
033a4144: 00d440f9 ldr      x0, [x0, #0x1a8]
033a4148: 6e347097 bl       #0xfb1300
033a414c: 28008052 mov      w8, #1
033a4150: 88522739 strb     w8, [x20, #0x9d4]
033a4154: 681240b9 ldr      w8, [x19, #0x10]
033a4158: 742e40f9 ldr      x20, [x19, #0x58]
033a415c: 1f050071 cmp      w8, #1
033a4160: 80030054 b.eq     #0x33a41d0
033a4164: 680b0035 cbnz     w8, #0x33a42d0
033a4168: 68d24039 ldrb     w8, [x19, #0x34]
033a416c: 09008012 mov      w9, #-1
033a4170: 691200b9 str      w9, [x19, #0x10]
033a4174: 68a20139 strb     w8, [x19, #0x68]
033a4178: 740b00b4 cbz      x20, #0x33a42e4
033a417c: 801640f9 ldr      x0, [x20, #0x28]
033a4180: 200b00b4 cbz      x0, #0x33a42e4
033a4184: 14f20090 adrp     x20, #0x51e4000
033a4188: 94d640f9 ldr      x20, [x20, #0x1a8]
033a418c: e1031faa mov      x1, xzr
033a4190: 299f0b94 bl       #0x368be34 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$Hide
033a4194: 800240f9 ldr      x0, [x20]
033a4198: a0347097 bl       #0xfb1418
033a419c: 400a00b4 cbz      x0, #0x33a42e4
033a41a0: 085600f0 adrp     x8, #0x3e67000
033a41a4: 00b945bd ldr      s0, [x8, #0x5b8]
033a41a8: e1031faa mov      x1, xzr
033a41ac: f40300aa mov      x20, x0
033a41b0: 69832594 bl       #0x3d04f54 ; UnityEngine.WaitForSeconds$$.ctor
033a41b4: 748e01f8 str      x20, [x19, #0x18]!
033a41b8: e00313aa mov      x0, x19
033a41bc: e10314aa mov      x1, x20
033a41c0: 3b347097 bl       #0xfb12ac
033a41c4: 20008052 mov      w0, #1
033a41c8: 60821fb8 stur     w0, [x19, #-8]
033a41cc: 42000014 b        #0x33a42d4
033a41d0: 08008012 mov      w8, #-1
033a41d4: 681200b9 str      w8, [x19, #0x10]
033a41d8: 740800b4 cbz      x20, #0x33a42e4
033a41dc: 801640f9 ldr      x0, [x20, #0x28]
033a41e0: 200800b4 cbz      x0, #0x33a42e4
033a41e4: e1031faa mov      x1, xzr
033a41e8: 209f0b94 bl       #0x368be68 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$Show
033a41ec: 880240f9 ldr      x8, [x20]
033a41f0: 613240f9 ldr      x1, [x19, #0x60]
033a41f4: e00314aa mov      x0, x20
033a41f8: 092541f9 ldr      x9, [x8, #0x248]
033a41fc: 022941f9 ldr      x2, [x8, #0x250]
033a4200: e8030091 mov      x8, sp
033a4204: 20013fd6 blr      x9
033a4208: e81b40f9 ldr      x8, [sp, #0x30]
033a420c: e18340ad ldp      q1, q0, [sp, #0x10]
033a4210: e203c03d ldr      q2, [sp]
033a4214: e83b00f9 str      x8, [sp, #0x70]
033a4218: e18302ad stp      q1, q0, [sp, #0x50]
033a421c: e213803d str      q2, [sp, #0x40]
033a4220: 620601ad stp      q2, q1, [x19, #0x20]
033a4224: 69d24039 ldrb     w9, [x19, #0x34]
033a4228: 6aa24139 ldrb     w10, [x19, #0x68]
033a422c: 682a00f9 str      x8, [x19, #0x50]
033a4230: 6012803d str      q0, [x19, #0x40]
033a4234: 5501092a orr      w21, w10, w9
033a4238: 75d20039 strb     w21, [x19, #0x34]
033a423c: 2a010035 cbnz     w10, #0x33a4260
033a4240: 603240f9 ldr      x0, [x19, #0x60]
033a4244: 000500b4 cbz      x0, #0x33a42e4
033a4248: e1031f2a mov      w1, wzr
033a424c: e2031faa mov      x2, xzr
033a4250: d39edc97 bl       #0x2acbd9c ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$HasJellySpreadBlockingItem
033a4254: a802200a bic      w8, w21, w0
033a4258: 08010012 and      w8, w8, #1
033a425c: 68d20039 strb     w8, [x19, #0x34]
033a4260: 68820091 add      x8, x19, #0x20
033a4264: 028140ad ldp      q2, q0, [x8, #0x10]
033a4268: 091940f9 ldr      x9, [x8, #0x30]
033a426c: 0101c03d ldr      q1, [x8]
033a4270: 801640f9 ldr      x0, [x20, #0x28]
033a4274: e28300ad stp      q2, q0, [sp, #0x10]
033a4278: e91b00f9 str      x9, [sp, #0x30]
033a427c: e103803d str      q1, [sp]
033a4280: 200300b4 cbz      x0, #0x33a42e4
033a4284: 080040f9 ldr      x8, [x0]
033a4288: e00b40ad ldp      q0, q2, [sp]
033a428c: e10bc03d ldr      q1, [sp, #0x20]
033a4290: e91b40f9 ldr      x9, [sp, #0x30]
033a4294: 0a8542f9 ldr      x10, [x8, #0x508]
033a4298: e00b02ad stp      q0, q2, [sp, #0x40]
033a429c: e11b803d str      q1, [sp, #0x60]
033a42a0: e93b00f9 str      x9, [sp, #0x70]
033a42a4: 028942f9 ldr      x2, [x8, #0x510]
033a42a8: d3f20090 adrp     x19, #0x51fc000
033a42ac: 732247f9 ldr      x19, [x19, #0xe40]
033a42b0: e1030191 add      x1, sp, #0x40
033a42b4: 40013fd6 blr      x10
033a42b8: 610240f9 ldr      x1, [x19]
033a42bc: e0018052 mov      w0, #0xf
033a42c0: cd69c697 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
033a42c4: 000100b4 cbz      x0, #0x33a42e4
033a42c8: e1031faa mov      x1, xzr
033a42cc: d164da97 bl       #0x2a3d610 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$FinishSpecialOperation
033a42d0: e0031f2a mov      w0, wzr
033a42d4: f37b49a9 ldp      x19, x30, [sp, #0x90]
033a42d8: f55348a9 ldp      x21, x20, [sp, #0x80]
033a42dc: ff830291 add      sp, sp, #0xa0
033a42e0: c0035fd6 ret      
033a42e4: 51347097 bl       #0xfb1428
