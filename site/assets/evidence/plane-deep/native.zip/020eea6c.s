# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$Bind
# Linear span to next metadata entry; not a complete CFG.
020eea6c: f80f1cf8 str      x24, [sp, #-0x40]!
020eea70: f75b01a9 stp      x23, x22, [sp, #0x10]
020eea74: f55302a9 stp      x21, x20, [sp, #0x20]
020eea78: f37b03a9 stp      x19, x30, [sp, #0x30]
020eea7c: 78a401f0 adrp     x24, #0x557d000
020eea80: 76880190 adrp     x22, #0x51fa000
020eea84: b78801f0 adrp     x23, #0x5205000
020eea88: 35850190 adrp     x21, #0x5192000
020eea8c: 348601b0 adrp     x20, #0x51b3000
020eea90: 08035539 ldrb     w8, [x24, #0x540]
020eea94: d6c247f9 ldr      x22, [x22, #0xf80]
020eea98: f76643f9 ldr      x23, [x23, #0x6c8]
020eea9c: b59642f9 ldr      x21, [x21, #0x528]
020eeaa0: 94a241f9 ldr      x20, [x20, #0x340]
020eeaa4: f30300aa mov      x19, x0
020eeaa8: 68030037 tbnz     w8, #0, #0x20eeb14
020eeaac: 608601b0 adrp     x0, #0x51bb000
020eeab0: 009c46f9 ldr      x0, [x0, #0xd38]
020eeab4: 130abb97 bl       #0xfb1300
020eeab8: 208901d0 adrp     x0, #0x5214000
020eeabc: 009441f9 ldr      x0, [x0, #0x328]
020eeac0: 100abb97 bl       #0xfb1300
020eeac4: 60880190 adrp     x0, #0x51fa000
020eeac8: 00c047f9 ldr      x0, [x0, #0xf80]
020eeacc: 0d0abb97 bl       #0xfb1300
020eead0: 20850190 adrp     x0, #0x5192000
020eead4: 009442f9 ldr      x0, [x0, #0x528]
020eead8: 0a0abb97 bl       #0xfb1300
020eeadc: a08801f0 adrp     x0, #0x5205000
020eeae0: 006443f9 ldr      x0, [x0, #0x6c8]
020eeae4: 070abb97 bl       #0xfb1300
020eeae8: 408601f0 adrp     x0, #0x51b9000
020eeaec: 007045f9 ldr      x0, [x0, #0xae0]
020eeaf0: 040abb97 bl       #0xfb1300
020eeaf4: a08601d0 adrp     x0, #0x51c4000
020eeaf8: 001042f9 ldr      x0, [x0, #0x420]
020eeafc: 010abb97 bl       #0xfb1300
020eeb00: 208601b0 adrp     x0, #0x51b3000
020eeb04: 00a041f9 ldr      x0, [x0, #0x340]
020eeb08: fe09bb97 bl       #0xfb1300
020eeb0c: 28008052 mov      w8, #1
020eeb10: 08031539 strb     w8, [x24, #0x540]
020eeb14: c10240f9 ldr      x1, [x22]
020eeb18: b88601d0 adrp     x24, #0x51c4000
020eeb1c: 568601f0 adrp     x22, #0x51b9000
020eeb20: 181342f9 ldr      x24, [x24, #0x420]
020eeb24: d67245f9 ldr      x22, [x22, #0xae0]
020eeb28: 40008052 mov      w0, #2
020eeb2c: b23f1194 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
020eeb30: e10300aa mov      x1, x0
020eeb34: e00313aa mov      x0, x19
020eeb38: 010c03f8 str      x1, [x0, #0x30]!
020eeb3c: dc09bb97 bl       #0xfb12ac
020eeb40: e10240f9 ldr      x1, [x23]
020eeb44: e0031f2a mov      w0, wzr
020eeb48: ab3f1194 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
020eeb4c: e10300aa mov      x1, x0
020eeb50: e00313aa mov      x0, x19
020eeb54: 018c03f8 str      x1, [x0, #0x38]!
020eeb58: d509bb97 bl       #0xfb12ac
020eeb5c: a10240f9 ldr      x1, [x21]
020eeb60: 80018052 mov      w0, #0xc
020eeb64: a43f1194 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
020eeb68: e10300aa mov      x1, x0
020eeb6c: e00313aa mov      x0, x19
020eeb70: 010c04f8 str      x1, [x0, #0x40]!
020eeb74: ce09bb97 bl       #0xfb12ac
020eeb78: 800240f9 ldr      x0, [x20]
020eeb7c: 08e040b9 ldr      w8, [x0, #0xe0]
020eeb80: 48000035 cbnz     w8, #0x20eeb88
020eeb84: 200abb97 bl       #0xfb1404
020eeb88: 010340f9 ldr      x1, [x24]
020eeb8c: 40008052 mov      w0, #2
020eeb90: f59d1d94 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
020eeb94: f50313aa mov      x21, x19
020eeb98: f40300aa mov      x20, x0
020eeb9c: a08e04f8 str      x0, [x21, #0x48]!
020eeba0: e00315aa mov      x0, x21
020eeba4: e10314aa mov      x1, x20
020eeba8: c109bb97 bl       #0xfb12ac
020eebac: e00315aa mov      x0, x21
020eebb0: e10314aa mov      x1, x20
020eebb4: b40200f9 str      x20, [x21]
020eebb8: bd09bb97 bl       #0xfb12ac
020eebbc: c00240f9 ldr      x0, [x22]
020eebc0: 08e040b9 ldr      w8, [x0, #0xe0]
020eebc4: 48000035 cbnz     w8, #0x20eebcc
020eebc8: 0f0abb97 bl       #0xfb1404
020eebcc: 54a401b0 adrp     x20, #0x5577000
020eebd0: 884e7d39 ldrb     w8, [x20, #0xf53]
020eebd4: c8000035 cbnz     w8, #0x20eebec
020eebd8: 408601f0 adrp     x0, #0x51b9000
020eebdc: 007045f9 ldr      x0, [x0, #0xae0]
020eebe0: c809bb97 bl       #0xfb1300
020eebe4: 28008052 mov      w8, #1
020eebe8: 884e3d39 strb     w8, [x20, #0xf53]
020eebec: c00240f9 ldr      x0, [x22]
020eebf0: 758601b0 adrp     x21, #0x51bb000
020eebf4: 08e040b9 ldr      w8, [x0, #0xe0]
020eebf8: b59e46f9 ldr      x21, [x21, #0xd38]
020eebfc: 68000035 cbnz     w8, #0x20eec08
020eec00: 010abb97 bl       #0xfb1404
020eec04: c00240f9 ldr      x0, [x22]
020eec08: 085c40f9 ldr      x8, [x0, #0xb8]
020eec0c: 741a40f9 ldr      x20, [x19, #0x30]
020eec10: 08514039 ldrb     w8, [x8, #0x14]
020eec14: 68e20239 strb     w8, [x19, #0xb8]
020eec18: a00240f9 ldr      x0, [x21]
020eec1c: ff09bb97 bl       #0xfb1418
020eec20: 000400b4 cbz      x0, #0x20eeca0
020eec24: 288901d0 adrp     x8, #0x5214000
020eec28: 089541f9 ldr      x8, [x8, #0x328]
020eec2c: e10313aa mov      x1, x19
020eec30: e3031faa mov      x3, xzr
020eec34: f50300aa mov      x21, x0
020eec38: 020140f9 ldr      x2, [x8]
020eec3c: 0d58fb97 bl       #0x1fc4c70 ; System.Action$$.ctor
020eec40: 140300b4 cbz      x20, #0x20eeca0
020eec44: e00314aa mov      x0, x20
020eec48: e10315aa mov      x1, x21
020eec4c: e2031faa mov      x2, xzr
020eec50: 539f1994 bl       #0x275699c ; Royal.Scenes.Game.Levels.Units.CellGridManager$$add_OnCellGridViewsInitialized
020eec54: 73a401f0 adrp     x19, #0x557d000
020eec58: f48501b0 adrp     x20, #0x51ab000
020eec5c: 680e5539 ldrb     w8, [x19, #0x543]
020eec60: 94c642f9 ldr      x20, [x20, #0x588]
020eec64: c8000037 tbnz     w8, #0, #0x20eec7c
020eec68: e08501b0 adrp     x0, #0x51ab000
020eec6c: 00c442f9 ldr      x0, [x0, #0x588]
020eec70: a409bb97 bl       #0xfb1300
020eec74: 28008052 mov      w8, #1
020eec78: 680e1539 strb     w8, [x19, #0x543]
020eec7c: 880240f9 ldr      x8, [x20]
020eec80: 09e28452 mov      w9, #0x2710
020eec84: 085d40f9 ldr      x8, [x8, #0xb8]
020eec88: 090100b9 str      w9, [x8]
020eec8c: f37b43a9 ldp      x19, x30, [sp, #0x30]
020eec90: f55342a9 ldp      x21, x20, [sp, #0x20]
020eec94: f75b41a9 ldp      x23, x22, [sp, #0x10]
020eec98: f80744f8 ldr      x24, [sp], #0x40
020eec9c: c0035fd6 ret      
020eeca0: e209bb97 bl       #0xfb1428
