# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$UpdateWaterWinCalculationData
# Linear span to next metadata entry; not a complete CFG.
020eefc4: 003c40f9 ldr      x0, [x0, #0x78]
020eefc8: 600000b4 cbz      x0, #0x20eefd4
020eefcc: e1031faa mov      x1, xzr
020eefd0: f5d71614 b        #0x26a4fa4 ; Royal.Scenes.Game.Levels.Units.Explode.WaterWinCalculationData$$OnLevelStart
020eefd4: c0035fd6 ret      
