# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_HitAudioClipType
# Linear span to next metadata entry; not a complete CFG.
033981fc: c0248052 mov      w0, #0x126
03398200: c0035fd6 ret      
