# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$InitializeCurveVariables
# Linear span to next metadata entry; not a complete CFG.
0339cef0: ea0f1cfc str      d10, [sp, #-0x40]!
0339cef4: e923016d stp      d9, d8, [sp, #0x10]
0339cef8: f55302a9 stp      x21, x20, [sp, #0x20]
0339cefc: f37b03a9 stp      x19, x30, [sp, #0x30]
0339cf00: 0859a852 mov      w8, #0x42c80000
0339cf04: 34008052 mov      w20, #1
0339cf08: 1ffc0229 stp      wzr, wzr, [x0, #0x14]
0339cf0c: 086c00b9 str      w8, [x0, #0x6c]
0339cf10: 147c00b9 str      w20, [x0, #0x7c]
0339cf14: d50e01d0 adrp     x21, #0x5576000
0339cf18: a8b27c39 ldrb     w8, [x21, #0xf2c]
0339cf1c: 481ca24e mov      v8.16b, v2.16b
0339cf20: 291ca14e mov      v9.16b, v1.16b
0339cf24: f30300aa mov      x19, x0
0339cf28: 0a1ca04e mov      v10.16b, v0.16b
0339cf2c: a8000035 cbnz     w8, #0x339cf40
0339cf30: 60f400f0 adrp     x0, #0x522b000
0339cf34: 00ac43f9 ldr      x0, [x0, #0x758]
0339cf38: f2507097 bl       #0xfb1300
0339cf3c: b4b23c39 strb     w20, [x21, #0xf2c]
0339cf40: 68f400f0 adrp     x8, #0x522b000
0339cf44: 08ad43f9 ldr      x8, [x8, #0x758]
0339cf48: e00313aa mov      x0, x19
0339cf4c: 211da94e mov      v1.16b, v9.16b
0339cf50: 021da84e mov      v2.16b, v8.16b
0339cf54: 080140f9 ldr      x8, [x8]
0339cf58: 095d40f9 ldr      x9, [x8, #0xb8]
0339cf5c: 2a0140f9 ldr      x10, [x9]
0339cf60: 290940b9 ldr      w9, [x9, #8]
0339cf64: 6a2200f9 str      x10, [x19, #0x40]
0339cf68: 694a00b9 str      w9, [x19, #0x48]
0339cf6c: 085d40f9 ldr      x8, [x8, #0xb8]
0339cf70: 695b00b0 adrp     x9, #0x3f09000
0339cf74: 204944fd ldr      d0, [x9, #0x890]
0339cf78: 092ea852 mov      w9, #0x41700000
0339cf7c: 0a0140f9 ldr      x10, [x8]
0339cf80: 080940b9 ldr      w8, [x8, #8]
0339cf84: 601200fd str      d0, [x19, #0x20]
0339cf88: 69da00b9 str      w9, [x19, #0xd8]
0339cf8c: 6a4200f9 str      x10, [x19, #0x80]
0339cf90: 688a00b9 str      w8, [x19, #0x88]
0339cf94: 7fea00b9 str      wzr, [x19, #0xe8]
0339cf98: f37b43a9 ldp      x19, x30, [sp, #0x30]
0339cf9c: f55342a9 ldp      x21, x20, [sp, #0x20]
0339cfa0: e923416d ldp      d9, d8, [sp, #0x10]
0339cfa4: 401daa4e mov      v0.16b, v10.16b
0339cfa8: ea0744fc ldr      d10, [sp], #0x40
0339cfac: 11070014 b        #0x339ebf0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$InitAngleVariables
