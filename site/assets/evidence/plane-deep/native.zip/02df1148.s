# Royal.Scenes.Game.Mechanics.Items.PairItem.PairItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02df1148: f40f1ef8 str      x20, [sp, #-0x20]!
02df114c: f37b01a9 stp      x19, x30, [sp, #0x10]
02df1150: f303012a mov      w19, w1
02df1154: f40300aa mov      x20, x0
02df1158: e003012a mov      w0, w1
02df115c: e1031faa mov      x1, xzr
02df1160: 134e1694 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02df1164: 80000036 tbz      w0, #0, #0x2df1174
02df1168: 88b20091 add      x8, x20, #0x2c
02df116c: 140100b5 cbnz     x20, #0x2df118c
02df1170: 0d000014 b        #0x2df11a4
02df1174: e00314aa mov      x0, x20
02df1178: e1031faa mov      x1, xzr
02df117c: 46471694 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02df1180: 200100b4 cbz      x0, #0x2df11a4
02df1184: 08600091 add      x8, x0, #0x18
02df1188: f40000b4 cbz      x20, #0x2df11a4
02df118c: 020140f9 ldr      x2, [x8]
02df1190: e103132a mov      w1, w19
02df1194: f37b41a9 ldp      x19, x30, [sp, #0x10]
02df1198: e00314aa mov      x0, x20
02df119c: f40742f8 ldr      x20, [sp], #0x20
02df11a0: eef1ff17 b        #0x2ded958 ; Royal.Scenes.Game.Mechanics.Items.PairItem.PairItemModel$$GetExplodeScoreForHitPoint
02df11a4: a1008797 bl       #0xfb1428
