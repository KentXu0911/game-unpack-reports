# Royal.Scenes.Game.Mechanics.Items.PorcelainItem.PorcelainItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01c141a0: f40f1ef8 str      x20, [sp, #-0x20]!
01c141a4: f37b01a9 stp      x19, x30, [sp, #0x10]
01c141a8: 080040f9 ldr      x8, [x0]
01c141ac: f30300aa mov      x19, x0
01c141b0: 096542f9 ldr      x9, [x8, #0x4c8]
01c141b4: 016942f9 ldr      x1, [x8, #0x4d0]
01c141b8: 20013fd6 blr      x9
01c141bc: 680240f9 ldr      x8, [x19]
01c141c0: 1f040071 cmp      w0, #1
01c141c4: e00313aa mov      x0, x19
01c141c8: 09bd41f9 ldr      x9, [x8, #0x378]
01c141cc: 01c141f9 ldr      x1, [x8, #0x380]
01c141d0: a8608a52 mov      w8, #0x5305
01c141d4: 4800a072 movk     w8, #2, lsl #16
01c141d8: 14019f1a csel     w20, w8, wzr, eq
01c141dc: 20013fd6 blr      x9
01c141e0: e1031faa mov      x1, xzr
01c141e4: e9c15d94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01c141e8: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c141ec: 0000140b add      w0, w0, w20
01c141f0: f40742f8 ldr      x20, [sp], #0x20
01c141f4: c0035fd6 ret      
