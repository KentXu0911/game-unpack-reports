# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$.ctor
# Linear span to next metadata entry; not a complete CFG.
026a4d08: f963bca9 stp      x25, x24, [sp, #-0x40]!
026a4d0c: f75b01a9 stp      x23, x22, [sp, #0x10]
026a4d10: f55302a9 stp      x21, x20, [sp, #0x20]
026a4d14: f37b03a9 stp      x19, x30, [sp, #0x30]
026a4d18: f7760190 adrp     x23, #0x5580000
026a4d1c: b65a01d0 adrp     x22, #0x51fa000
026a4d20: 755701d0 adrp     x21, #0x5192000
026a4d24: 745801f0 adrp     x20, #0x51b3000
026a4d28: e8764139 ldrb     w8, [x23, #0x5d]
026a4d2c: d6c247f9 ldr      x22, [x22, #0xf80]
026a4d30: b59642f9 ldr      x21, [x21, #0x528]
026a4d34: 94a241f9 ldr      x20, [x20, #0x340]
026a4d38: f30300aa mov      x19, x0
026a4d3c: 48050037 tbnz     w8, #0, #0x26a4de4
026a4d40: 605901b0 adrp     x0, #0x51d1000
026a4d44: 00f047f9 ldr      x0, [x0, #0xfe0]
026a4d48: 6e31a497 bl       #0xfb1300
026a4d4c: 805701b0 adrp     x0, #0x5195000
026a4d50: 00e040f9 ldr      x0, [x0, #0x1c0]
026a4d54: 6b31a497 bl       #0xfb1300
026a4d58: e05b0190 adrp     x0, #0x5220000
026a4d5c: 002842f9 ldr      x0, [x0, #0x450]
026a4d60: 6831a497 bl       #0xfb1300
026a4d64: 205801b0 adrp     x0, #0x51a9000
026a4d68: 008c41f9 ldr      x0, [x0, #0x318]
026a4d6c: 6531a497 bl       #0xfb1300
026a4d70: 405b01b0 adrp     x0, #0x520d000
026a4d74: 00f841f9 ldr      x0, [x0, #0x3f0]
026a4d78: 6231a497 bl       #0xfb1300
026a4d7c: 605801d0 adrp     x0, #0x51b2000
026a4d80: 000c44f9 ldr      x0, [x0, #0x818]
026a4d84: 5f31a497 bl       #0xfb1300
026a4d88: 205c0190 adrp     x0, #0x5228000
026a4d8c: 001444f9 ldr      x0, [x0, #0x828]
026a4d90: 5c31a497 bl       #0xfb1300
026a4d94: 405901b0 adrp     x0, #0x51cd000
026a4d98: 007c47f9 ldr      x0, [x0, #0xef8]
026a4d9c: 5931a497 bl       #0xfb1300
026a4da0: a05a01d0 adrp     x0, #0x51fa000
026a4da4: 00c047f9 ldr      x0, [x0, #0xf80]
026a4da8: 5631a497 bl       #0xfb1300
026a4dac: 605701d0 adrp     x0, #0x5192000
026a4db0: 009442f9 ldr      x0, [x0, #0x528]
026a4db4: 5331a497 bl       #0xfb1300
026a4db8: a05801f0 adrp     x0, #0x51bb000
026a4dbc: 008440f9 ldr      x0, [x0, #0x108]
026a4dc0: 5031a497 bl       #0xfb1300
026a4dc4: 00590190 adrp     x0, #0x51c4000
026a4dc8: 001042f9 ldr      x0, [x0, #0x420]
026a4dcc: 4d31a497 bl       #0xfb1300
026a4dd0: 605801f0 adrp     x0, #0x51b3000
026a4dd4: 00a041f9 ldr      x0, [x0, #0x340]
026a4dd8: 4a31a497 bl       #0xfb1300
026a4ddc: 28008052 mov      w8, #1
026a4de0: e8760139 strb     w8, [x23, #0x5d]
026a4de4: 19590190 adrp     x25, #0x51c4000
026a4de8: 575b01b0 adrp     x23, #0x520d000
026a4dec: b85801f0 adrp     x24, #0x51bb000
026a4df0: 391342f9 ldr      x25, [x25, #0x420]
026a4df4: f7fa41f9 ldr      x23, [x23, #0x3f0]
026a4df8: 188740f9 ldr      x24, [x24, #0x108]
026a4dfc: e00313aa mov      x0, x19
026a4e00: e1031faa mov      x1, xzr
026a4e04: fc39ef97 bl       #0x22735f4 ; System.Object$$.ctor
026a4e08: c10240f9 ldr      x1, [x22]
026a4e0c: 40008052 mov      w0, #2
026a4e10: f966fa97 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
026a4e14: e10300aa mov      x1, x0
026a4e18: e00313aa mov      x0, x19
026a4e1c: 018c01f8 str      x1, [x0, #0x18]!
026a4e20: 2331a497 bl       #0xfb12ac
026a4e24: a10240f9 ldr      x1, [x21]
026a4e28: 80018052 mov      w0, #0xc
026a4e2c: f266fa97 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
026a4e30: e10300aa mov      x1, x0
026a4e34: e00313aa mov      x0, x19
026a4e38: 010c02f8 str      x1, [x0, #0x20]!
026a4e3c: 1c31a497 bl       #0xfb12ac
026a4e40: 800240f9 ldr      x0, [x20]
026a4e44: 08e040b9 ldr      w8, [x0, #0xe0]
026a4e48: 48000035 cbnz     w8, #0x26a4e50
026a4e4c: 6e31a497 bl       #0xfb1404
026a4e50: 210340f9 ldr      x1, [x25]
026a4e54: f95b0190 adrp     x25, #0x5220000
026a4e58: 392b42f9 ldr      x25, [x25, #0x450]
026a4e5c: 40008052 mov      w0, #2
026a4e60: 41c50694 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
026a4e64: e10300aa mov      x1, x0
026a4e68: e00313aa mov      x0, x19
026a4e6c: 018c02f8 str      x1, [x0, #0x28]!
026a4e70: 0f31a497 bl       #0xfb12ac
026a4e74: 000340f9 ldr      x0, [x24]
026a4e78: f40240f9 ldr      x20, [x23]
026a4e7c: 08e040b9 ldr      w8, [x0, #0xe0]
026a4e80: 48000035 cbnz     w8, #0x26a4e88
026a4e84: 6031a497 bl       #0xfb1404
026a4e88: 375801b0 adrp     x23, #0x51a9000
026a4e8c: 565901b0 adrp     x22, #0x51cd000
026a4e90: 355c0190 adrp     x21, #0x5228000
026a4e94: f78e41f9 ldr      x23, [x23, #0x318]
026a4e98: d67e47f9 ldr      x22, [x22, #0xef8]
026a4e9c: b51644f9 ldr      x21, [x21, #0x828]
026a4ea0: e00314aa mov      x0, x20
026a4ea4: e1031faa mov      x1, xzr
026a4ea8: b6befa97 bl       #0x2554980 ; System.Type$$GetTypeFromHandle
026a4eac: 280340f9 ldr      x8, [x25]
026a4eb0: f40300aa mov      x20, x0
026a4eb4: 09e140b9 ldr      w9, [x8, #0xe0]
026a4eb8: 69000035 cbnz     w9, #0x26a4ec4
026a4ebc: e00308aa mov      x0, x8
026a4ec0: 5131a497 bl       #0xfb1404
026a4ec4: e00314aa mov      x0, x20
026a4ec8: e1031faa mov      x1, xzr
026a4ecc: 24feee97 bl       #0x226475c ; System.Enum$$GetValues
026a4ed0: e10240f9 ldr      x1, [x23]
026a4ed4: 9724e397 bl       #0x1f6e130 ; System.Linq.Enumerable$$Cast<int>
026a4ed8: e1031faa mov      x1, xzr
026a4edc: ec454e94 bl       #0x3a3668c ; System.Linq.Enumerable$$Max
026a4ee0: c80240f9 ldr      x8, [x22]
026a4ee4: 01040011 add      w1, w0, #1
026a4ee8: e00308aa mov      x0, x8
026a4eec: 2131a497 bl       #0xfb1370
026a4ef0: e10300aa mov      x1, x0
026a4ef4: e00313aa mov      x0, x19
026a4ef8: 010c03f8 str      x1, [x0, #0x30]!
026a4efc: ec30a497 bl       #0xfb12ac
026a4f00: a00240f9 ldr      x0, [x21]
026a4f04: 4531a497 bl       #0xfb1418
026a4f08: c00400b4 cbz      x0, #0x26a4fa0
026a4f0c: 685801d0 adrp     x8, #0x51b2000
026a4f10: 080d44f9 ldr      x8, [x8, #0x818]
026a4f14: 955701b0 adrp     x21, #0x5195000
026a4f18: f40300aa mov      x20, x0
026a4f1c: 010140f9 ldr      x1, [x8]
026a4f20: b5e240f9 ldr      x21, [x21, #0x1c0]
026a4f24: 868d0e94 bl       #0x2a4853c ; System.Collections.Generic.HashSet<int>$$.ctor
026a4f28: e00313aa mov      x0, x19
026a4f2c: 148c03f8 str      x20, [x0, #0x38]!
026a4f30: e10314aa mov      x1, x20
026a4f34: de30a497 bl       #0xfb12ac
026a4f38: a00240f9 ldr      x0, [x21]
026a4f3c: 3731a497 bl       #0xfb1418
026a4f40: 000300b4 cbz      x0, #0x26a4fa0
026a4f44: 765901b0 adrp     x22, #0x51d1000
026a4f48: d6f247f9 ldr      x22, [x22, #0xfe0]
026a4f4c: f40300aa mov      x20, x0
026a4f50: c10240f9 ldr      x1, [x22]
026a4f54: e1294194 bl       #0x36ef6d8 ; System.Collections.Generic.Dictionary<int, int>$$.ctor
026a4f58: e00313aa mov      x0, x19
026a4f5c: 140c04f8 str      x20, [x0, #0x40]!
026a4f60: e10314aa mov      x1, x20
026a4f64: d230a497 bl       #0xfb12ac
026a4f68: a00240f9 ldr      x0, [x21]
026a4f6c: 2b31a497 bl       #0xfb1418
026a4f70: 800100b4 cbz      x0, #0x26a4fa0
026a4f74: c10240f9 ldr      x1, [x22]
026a4f78: f40300aa mov      x20, x0
026a4f7c: d7294194 bl       #0x36ef6d8 ; System.Collections.Generic.Dictionary<int, int>$$.ctor
026a4f80: 748e04f8 str      x20, [x19, #0x48]!
026a4f84: e00313aa mov      x0, x19
026a4f88: e10314aa mov      x1, x20
026a4f8c: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a4f90: f55342a9 ldp      x21, x20, [sp, #0x20]
026a4f94: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a4f98: f963c4a8 ldp      x25, x24, [sp], #0x40
026a4f9c: c430a417 b        #0xfb12ac
026a4fa0: 2231a497 bl       #0xfb1428
