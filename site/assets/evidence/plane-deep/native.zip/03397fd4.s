# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemExplodeParticles$$GetPoolId
# Linear span to next metadata entry; not a complete CFG.
03397fd4: 60018052 mov      w0, #0xb
03397fd8: c0035fd6 ret      
