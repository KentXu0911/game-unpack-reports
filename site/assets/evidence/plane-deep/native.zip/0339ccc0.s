# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$get_ShouldPlaySfxInLoop
# Linear span to next metadata entry; not a complete CFG.
0339ccc0: e0031f2a mov      w0, wzr
0339ccc4: c0035fd6 ret      
