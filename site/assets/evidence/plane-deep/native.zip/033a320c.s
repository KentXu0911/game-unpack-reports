# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$IsTargetAmountReached
# Linear span to next metadata entry; not a complete CFG.
033a320c: 20008052 mov      w0, #1
033a3210: c0035fd6 ret      
