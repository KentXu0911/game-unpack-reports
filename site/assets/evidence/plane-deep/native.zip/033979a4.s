# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$TryCollectRemainingMoveCoins
# Linear span to next metadata entry; not a complete CFG.
033979a4: f40f1ef8 str      x20, [sp, #-0x20]!
033979a8: f37b01a9 stp      x19, x30, [sp, #0x10]
033979ac: 740f01f0 adrp     x20, #0x5586000
033979b0: 88326639 ldrb     w8, [x20, #0x98c]
033979b4: f30300aa mov      x19, x0
033979b8: c8000037 tbnz     w8, #0, #0x33979d0
033979bc: 60f400f0 adrp     x0, #0x5226000
033979c0: 007443f9 ldr      x0, [x0, #0x6e8]
033979c4: 4f667097 bl       #0xfb1300
033979c8: 28008052 mov      w8, #1
033979cc: 88322639 strb     w8, [x20, #0x98c]
033979d0: 20048052 mov      w0, #0x21
033979d4: e1031faa mov      x1, xzr
033979d8: 30f1ce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033979dc: 80020036 tbz      w0, #0, #0x3397a2c
033979e0: 68f400f0 adrp     x8, #0x5226000
033979e4: 087543f9 ldr      x8, [x8, #0x6e8]
033979e8: 20048052 mov      w0, #0x21
033979ec: 010140f9 ldr      x1, [x8]
033979f0: 019cc697 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
033979f4: 681e40f9 ldr      x8, [x19, #0x38]
033979f8: 080200b4 cbz      x8, #0x3397a38
033979fc: f40300aa mov      x20, x0
03397a00: e00308aa mov      x0, x8
03397a04: e1031faa mov      x1, xzr
03397a08: a1d1ff97 bl       #0x338c08c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemMediator$$get_CurrentCell
03397a0c: 740100b4 cbz      x20, #0x3397a38
03397a10: e20313aa mov      x2, x19
03397a14: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397a18: e10300aa mov      x1, x0
03397a1c: e00314aa mov      x0, x20
03397a20: e3031faa mov      x3, xzr
03397a24: f40742f8 ldr      x20, [sp], #0x20
03397a28: a36df417 b        #0x30b30b4 ; Royal.Scenes.Game.Levels.Units.RemainingMoves.RemainingMovesManager$$CollectRemainingMovesCoin
03397a2c: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397a30: f40742f8 ldr      x20, [sp], #0x20
03397a34: c0035fd6 ret      
03397a38: 7c667097 bl       #0xfb1428
