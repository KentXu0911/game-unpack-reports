# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_MaxOutSpeedConst
# Linear span to next metadata entry; not a complete CFG.
033989b8: 00102e1e fmov     s0, #1.00000000
033989bc: c0035fd6 ret      
