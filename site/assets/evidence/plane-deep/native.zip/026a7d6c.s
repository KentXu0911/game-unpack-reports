# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddCumulativeHittableMultiCellItemHit
# Linear span to next metadata entry; not a complete CFG.
026a7d6c: f963bca9 stp      x25, x24, [sp, #-0x40]!
026a7d70: f75b01a9 stp      x23, x22, [sp, #0x10]
026a7d74: f55302a9 stp      x21, x20, [sp, #0x20]
026a7d78: f37b03a9 stp      x19, x30, [sp, #0x30]
026a7d7c: d97601b0 adrp     x25, #0x5580000
026a7d80: 288b4139 ldrb     w8, [x25, #0x62]
026a7d84: f703052a mov      w23, w5
026a7d88: f303042a mov      w19, w4
026a7d8c: f403032a mov      w20, w3
026a7d90: f503022a mov      w21, w2
026a7d94: f803012a mov      w24, w1
026a7d98: f60300aa mov      x22, x0
026a7d9c: c8000037 tbnz     w8, #0, #0x26a7db4
026a7da0: 405a01f0 adrp     x0, #0x51f2000
026a7da4: 000047f9 ldr      x0, [x0, #0xe00]
026a7da8: 5625a497 bl       #0xfb1300
026a7dac: 28008052 mov      w8, #1
026a7db0: 288b0139 strb     w8, [x25, #0x62]
026a7db4: e00316aa mov      x0, x22
026a7db8: e103182a mov      w1, w24
026a7dbc: 1b000094 bl       #0x26a7e28 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$GetCumulativeHittableMultiCellHitCount
026a7dc0: c82640f9 ldr      x8, [x22, #0x48]
026a7dc4: 080300b4 cbz      x8, #0x26a7e24
026a7dc8: 495a01f0 adrp     x9, #0x51f2000
026a7dcc: 290147f9 ldr      x9, [x9, #0xe00]
026a7dd0: 1700170b add      w23, w0, w23
026a7dd4: e00308aa mov      x0, x8
026a7dd8: e103182a mov      w1, w24
026a7ddc: 230140f9 ldr      x3, [x9]
026a7de0: e203172a mov      w2, w23
026a7de4: d3204194 bl       #0x36f0130 ; System.Collections.Generic.Dictionary<int, int>$$set_Item
026a7de8: ff02156b cmp      w23, w21
026a7dec: 21010054 b.ne     #0x26a7e10
026a7df0: e00316aa mov      x0, x22
026a7df4: e103142a mov      w1, w20
026a7df8: e203132a mov      w2, w19
026a7dfc: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a7e00: f55342a9 ldp      x21, x20, [sp, #0x20]
026a7e04: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a7e08: f963c4a8 ldp      x25, x24, [sp], #0x40
026a7e0c: 81ffff17 b        #0x26a7c10 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddGoalHit
026a7e10: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a7e14: f55342a9 ldp      x21, x20, [sp, #0x20]
026a7e18: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a7e1c: f963c4a8 ldp      x25, x24, [sp], #0x40
026a7e20: c0035fd6 ret      
026a7e24: 8125a497 bl       #0xfb1428
