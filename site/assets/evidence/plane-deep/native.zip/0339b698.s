# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$GetStartState
# Linear span to next metadata entry; not a complete CFG.
0339b698: 08684339 ldrb     w8, [x0, #0xda]
0339b69c: 1f010071 cmp      w8, #0
0339b6a0: 28008052 mov      w8, #1
0339b6a4: 0015881a cinc     w0, w8, eq
0339b6a8: c0035fd6 ret      
