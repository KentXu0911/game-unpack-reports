# Royal.Scenes.Game.Mechanics.Items.PaintBucketItem.PaintBucketItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
030800b4: f553bea9 stp      x21, x20, [sp, #-0x20]!
030800b8: f37b01a9 stp      x19, x30, [sp, #0x10]
030800bc: 080040f9 ldr      x8, [x0]
030800c0: f403012a mov      w20, w1
030800c4: f30300aa mov      x19, x0
030800c8: 096542f9 ldr      x9, [x8, #0x4c8]
030800cc: 086942f9 ldr      x8, [x8, #0x4d0]
030800d0: e10308aa mov      x1, x8
030800d4: 20013fd6 blr      x9
030800d8: 1f040071 cmp      w0, #1
030800dc: 01030054 b.ne     #0x308013c
030800e0: 605e40f9 ldr      x0, [x19, #0xb8]
030800e4: 200600b4 cbz      x0, #0x30801a8
030800e8: e1031faa mov      x1, xzr
030800ec: 25c00194 bl       #0x30f0180 ; Royal.Scenes.Game.Mechanics.Items.ColorMixerItem.ColorMixerItemHelper$$OneTargetRemainingOnAnyColorMixerItem
030800f0: 60020036 tbz      w0, #0, #0x308013c
030800f4: e003142a mov      w0, w20
030800f8: e1031faa mov      x1, xzr
030800fc: 10120c94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03080100: 755e40f9 ldr      x21, [x19, #0xb8]
03080104: 80020036 tbz      w0, #0, #0x3080154
03080108: 150500b4 cbz      x21, #0x30801a8
0308010c: e00315aa mov      x0, x21
03080110: e1031faa mov      x1, xzr
03080114: 68c00194 bl       #0x30f02b4 ; Royal.Scenes.Game.Mechanics.Items.ColorMixerItem.ColorMixerItemHelper$$ShouldAddExtraScoreForLastState
03080118: 1f000072 tst      w0, #1
0308011c: 28509652 mov      w8, #0xb281
03080120: e00313aa mov      x0, x19
03080124: e103142a mov      w1, w20
03080128: e2031faa mov      x2, xzr
0308012c: 15119f1a csel     w21, w8, wzr, ne
03080130: 0f120c94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
03080134: a002000b add      w0, w21, w0
03080138: 19000014 b        #0x308019c
0308013c: e00313aa mov      x0, x19
03080140: f37b41a9 ldp      x19, x30, [sp, #0x10]
03080144: e103142a mov      w1, w20
03080148: e2031faa mov      x2, xzr
0308014c: f553c2a8 ldp      x21, x20, [sp], #0x20
03080150: 07120c14 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
03080154: e00313aa mov      x0, x19
03080158: e1031faa mov      x1, xzr
0308015c: 4e0b0c94 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
03080160: 400200b4 cbz      x0, #0x30801a8
03080164: e1031faa mov      x1, xzr
03080168: 2624e997 bl       #0x2ac9200 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetBoardAdjustedPoint
0308016c: f50100b4 cbz      x21, #0x30801a8
03080170: e20300aa mov      x2, x0
03080174: e00315aa mov      x0, x21
03080178: e103142a mov      w1, w20
0308017c: e3031faa mov      x3, xzr
03080180: dfbf0194 bl       #0x30f00fc ; Royal.Scenes.Game.Mechanics.Items.ColorMixerItem.ColorMixerItemHelper$$UpdateExtraScoreCache
03080184: e00313aa mov      x0, x19
03080188: e103142a mov      w1, w20
0308018c: e2031faa mov      x2, xzr
03080190: f7110c94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
03080194: 28509652 mov      w8, #0xb281
03080198: 0000080b add      w0, w0, w8
0308019c: f37b41a9 ldp      x19, x30, [sp, #0x10]
030801a0: f553c2a8 ldp      x21, x20, [sp], #0x20
030801a4: c0035fd6 ret      
030801a8: a0c47c97 bl       #0xfb1428
