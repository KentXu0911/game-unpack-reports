# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeSorting
# Linear span to next metadata entry; not a complete CFG.
0339bb80: f60f1df8 str      x22, [sp, #-0x30]!
0339bb84: f55301a9 stp      x21, x20, [sp, #0x10]
0339bb88: f37b02a9 stp      x19, x30, [sp, #0x20]
0339bb8c: 540f01f0 adrp     x20, #0x5586000
0339bb90: 56f000d0 adrp     x22, #0x51a5000
0339bb94: 88ba6639 ldrb     w8, [x20, #0x9ae]
0339bb98: d66645f9 ldr      x22, [x22, #0xac8]
0339bb9c: f30300aa mov      x19, x0
0339bba0: c8000037 tbnz     w8, #0, #0x339bbb8
0339bba4: 40f000d0 adrp     x0, #0x51a5000
0339bba8: 006445f9 ldr      x0, [x0, #0xac8]
0339bbac: d5557097 bl       #0xfb1300
0339bbb0: 28008052 mov      w8, #1
0339bbb4: 88ba2639 strb     w8, [x20, #0x9ae]
0339bbb8: c00240f9 ldr      x0, [x22]
0339bbbc: 746a4339 ldrb     w20, [x19, #0xda]
0339bbc0: 08e040b9 ldr      w8, [x0, #0xe0]
0339bbc4: 48000035 cbnz     w8, #0x339bbcc
0339bbc8: 0f567097 bl       #0xfb1404
0339bbcc: 9f020071 cmp      w20, #0
0339bbd0: e1079f1a cset     w1, ne
0339bbd4: 20008052 mov      w0, #1
0339bbd8: e2031faa mov      x2, xzr
0339bbdc: fd5d7f97 bl       #0x13733d0 ; Royal.Scenes.Game.Mechanics.Sortings.Sorting$$GetPropellerFlyingSorting
0339bbe0: f40300aa mov      x20, x0
0339bbe4: 603240f9 ldr      x0, [x19, #0x60]
0339bbe8: e00300b4 cbz      x0, #0x339bc64
0339bbec: 357c4092 and      x21, x1, #0xffffffff
0339bbf0: e10314aa mov      x1, x20
0339bbf4: e20315aa mov      x2, x21
0339bbf8: e3031f2a mov      w3, wzr
0339bbfc: e4031faa mov      x4, xzr
0339bc00: 32d2ff97 bl       #0x33904c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$UpdateSortingForAnimation
0339bc04: c00240f9 ldr      x0, [x22]
0339bc08: 68164339 ldrb     w8, [x19, #0xc5]
0339bc0c: 09e040b9 ldr      w9, [x0, #0xe0]
0339bc10: 1f010071 cmp      w8, #0
0339bc14: 48018052 mov      w8, #0xa
0339bc18: 1605885a cneg     w22, w8, ne
0339bc1c: 49000035 cbnz     w9, #0x339bc24
0339bc20: f9557097 bl       #0xfb1404
0339bc24: e00314aa mov      x0, x20
0339bc28: e10315aa mov      x1, x21
0339bc2c: e203162a mov      w2, w22
0339bc30: e3031faa mov      x3, xzr
0339bc34: 8b497f97 bl       #0x136e260 ; Royal.Scenes.Game.Mechanics.Sortings.Sorting$$GetSortingWithOffset
0339bc38: e30300aa mov      x3, x0
0339bc3c: 606a40f9 ldr      x0, [x19, #0xd0]
0339bc40: 200100b4 cbz      x0, #0x339bc64
0339bc44: f37b42a9 ldp      x19, x30, [sp, #0x20]
0339bc48: f55341a9 ldp      x21, x20, [sp, #0x10]
0339bc4c: 227c4092 and      x2, x1, #0xffffffff
0339bc50: e10303aa mov      x1, x3
0339bc54: e3031f2a mov      w3, wzr
0339bc58: e4031faa mov      x4, xzr
0339bc5c: f60743f8 ldr      x22, [sp], #0x30
0339bc60: 1ad2ff17 b        #0x33904c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$UpdateSortingForAnimation
0339bc64: f1557097 bl       #0xfb1428
