# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$GetMinFlyTime
# Linear span to next metadata entry; not a complete CFG.
033999e0: 00102c1e fmov     s0, #0.50000000
033999e4: c0035fd6 ret      
