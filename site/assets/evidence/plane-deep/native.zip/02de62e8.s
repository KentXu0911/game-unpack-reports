# Royal.Scenes.Game.Mechanics.Items.PinItem.PinItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02de62e8: f553bea9 stp      x21, x20, [sp, #-0x20]!
02de62ec: f37b01a9 stp      x19, x30, [sp, #0x10]
02de62f0: 080040f9 ldr      x8, [x0]
02de62f4: f403012a mov      w20, w1
02de62f8: f30300aa mov      x19, x0
02de62fc: 096542f9 ldr      x9, [x8, #0x4c8]
02de6300: 086942f9 ldr      x8, [x8, #0x4d0]
02de6304: e10308aa mov      x1, x8
02de6308: 20013fd6 blr      x9
02de630c: 1f040071 cmp      w0, #1
02de6310: 6b010054 b.lt     #0x2de633c
02de6314: e003142a mov      w0, w20
02de6318: e1031faa mov      x1, xzr
02de631c: a4791694 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02de6320: 20010036 tbz      w0, #0, #0x2de6344
02de6324: 602a40f9 ldr      x0, [x19, #0x50]
02de6328: 400300b4 cbz      x0, #0x2de6390
02de632c: 61c242f8 ldur     x1, [x19, #0x2c]
02de6330: e2031faa mov      x2, xzr
02de6334: 77b8e597 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
02de6338: 06000014 b        #0x2de6350
02de633c: e0031f2a mov      w0, wzr
02de6340: 11000014 b        #0x2de6384
02de6344: e00313aa mov      x0, x19
02de6348: e1031faa mov      x1, xzr
02de634c: d2721694 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02de6350: f50300aa mov      x21, x0
02de6354: 13feff97 bl       #0x2de5ba0 ; Royal.Scenes.Game.Mechanics.Items.PinItem.PinItemModel$$get_ItemHelper
02de6358: c00100b4 cbz      x0, #0x2de6390
02de635c: 61ba40b9 ldr      w1, [x19, #0xb8]
02de6360: e20315aa mov      x2, x21
02de6364: e303142a mov      w3, w20
02de6368: b1faff97 bl       #0x2de4e2c ; Royal.Scenes.Game.Mechanics.Items.PinItem.PinItemHelper$$GetItemExplodeExtraScore
02de636c: f503002a mov      w21, w0
02de6370: e00313aa mov      x0, x19
02de6374: e103142a mov      w1, w20
02de6378: e2031faa mov      x2, xzr
02de637c: 7c791694 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02de6380: 0000150b add      w0, w0, w21
02de6384: f37b41a9 ldp      x19, x30, [sp, #0x10]
02de6388: f553c2a8 ldp      x21, x20, [sp], #0x20
02de638c: c0035fd6 ret      
02de6390: 262c8797 bl       #0xfb1428
