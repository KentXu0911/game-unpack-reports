# Royal.Scenes.Game.Mechanics.Items.MailBoxItem.MailBoxItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
020d1e88: fe0f1ff8 str      x30, [sp, #-0x10]!
020d1e8c: 08204339 ldrb     w8, [x0, #0xc8]
020d1e90: 88010034 cbz      w8, #0x20d1ec0
020d1e94: e2031faa mov      x2, xzr
020d1e98: b5ca4a94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
020d1e9c: e8a39052 mov      w8, #0x851f
020d1ea0: 683daa72 movk     w8, #0x51eb, lsl #16
020d1ea4: 087c289b smull    x8, w0, w8
020d1ea8: 09fd7fd3 lsr      x9, x8, #0x3f
020d1eac: 08fd6593 asr      x8, x8, #0x25
020d1eb0: 0801090b add      w8, w8, w9
020d1eb4: 69098052 mov      w9, #0x4b
020d1eb8: 007d091b mul      w0, w8, w9
020d1ebc: 02000014 b        #0x20d1ec4
020d1ec0: e0031f2a mov      w0, wzr
020d1ec4: fe0741f8 ldr      x30, [sp], #0x10
020d1ec8: c0035fd6 ret      
