# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_MinOutSpeedConst
# Linear span to next metadata entry; not a complete CFG.
0339b57c: 00102c1e fmov     s0, #0.50000000
0339b580: c0035fd6 ret      
