# Royal.Scenes.Game.Mechanics.Items.PairItem.PairFakeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02ded8f4: f553bea9 stp      x21, x20, [sp, #-0x20]!
02ded8f8: f37b01a9 stp      x19, x30, [sp, #0x10]
02ded8fc: 149c40f9 ldr      x20, [x0, #0x138]
02ded900: f50300aa mov      x21, x0
02ded904: f303012a mov      w19, w1
02ded908: e003012a mov      w0, w1
02ded90c: e1031faa mov      x1, xzr
02ded910: 275c1694 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02ded914: 80000036 tbz      w0, #0, #0x2ded924
02ded918: a8b20091 add      x8, x21, #0x2c
02ded91c: 140100b5 cbnz     x20, #0x2ded93c
02ded920: 0d000014 b        #0x2ded954
02ded924: e00315aa mov      x0, x21
02ded928: e1031faa mov      x1, xzr
02ded92c: 5a551694 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02ded930: 200100b4 cbz      x0, #0x2ded954
02ded934: 08600091 add      x8, x0, #0x18
02ded938: f40000b4 cbz      x20, #0x2ded954
02ded93c: 020140f9 ldr      x2, [x8]
02ded940: e103132a mov      w1, w19
02ded944: f37b41a9 ldp      x19, x30, [sp, #0x10]
02ded948: e00314aa mov      x0, x20
02ded94c: f553c2a8 ldp      x21, x20, [sp], #0x20
02ded950: 02000014 b        #0x2ded958 ; Royal.Scenes.Game.Mechanics.Items.PairItem.PairItemModel$$GetExplodeScoreForHitPoint
02ded954: b50e8797 bl       #0xfb1428
