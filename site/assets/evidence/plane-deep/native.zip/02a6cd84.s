# Royal.Scenes.Game.Mechanics.Items.BowTieItem.BowTieItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02a6cd84: 08004339 ldrb     w8, [x0, #0xc0]
02a6cd88: 68000034 cbz      w8, #0x2a6cd94
02a6cd8c: e2031faa mov      x2, xzr
02a6cd90: f75e2414 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02a6cd94: e0031f2a mov      w0, wzr
02a6cd98: c0035fd6 ret      
