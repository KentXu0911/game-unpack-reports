# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$SwapWith
# Linear span to next metadata entry; not a complete CFG.
0339766c: ff4302d1 sub      sp, sp, #0x90
03397670: fe4300f9 str      x30, [sp, #0x80]
03397674: 481840f9 ldr      x8, [x2, #0x30]
03397678: 418040ad ldp      q1, q0, [x2, #0x10]
0339767c: 4200c03d ldr      q2, [x2]
03397680: e1030191 add      x1, sp, #0x40
03397684: e81b00f9 str      x8, [sp, #0x30]
03397688: e18300ad stp      q1, q0, [sp, #0x10]
0339768c: e203803d str      q2, [sp]
03397690: 090040f9 ldr      x9, [x0]
03397694: 2a8542f9 ldr      x10, [x9, #0x508]
03397698: e20702ad stp      q2, q1, [sp, #0x40]
0339769c: e01b803d str      q0, [sp, #0x60]
033976a0: e83b00f9 str      x8, [sp, #0x70]
033976a4: 228942f9 ldr      x2, [x9, #0x510]
033976a8: 40013fd6 blr      x10
033976ac: fe4340f9 ldr      x30, [sp, #0x80]
033976b0: ff430291 add      sp, sp, #0x90
033976b4: c0035fd6 ret      
