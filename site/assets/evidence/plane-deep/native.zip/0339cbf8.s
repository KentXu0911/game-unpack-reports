# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339cbf8: ea0f1cfc str      d10, [sp, #-0x40]!
0339cbfc: e9a3006d stp      d9, d8, [sp, #8]
0339cc00: f60f00f9 str      x22, [sp, #0x18]
0339cc04: f55302a9 stp      x21, x20, [sp, #0x20]
0339cc08: f37b03a9 stp      x19, x30, [sp, #0x30]
0339cc0c: 560f01d0 adrp     x22, #0x5586000
0339cc10: f5ef00b0 adrp     x21, #0x5199000
0339cc14: c8c66639 ldrb     w8, [x22, #0x9b1]
0339cc18: b52246f9 ldr      x21, [x21, #0xc40]
0339cc1c: f30301aa mov      x19, x1
0339cc20: 481ca24e mov      v8.16b, v2.16b
0339cc24: 291ca14e mov      v9.16b, v1.16b
0339cc28: 0a1ca04e mov      v10.16b, v0.16b
0339cc2c: f40300aa mov      x20, x0
0339cc30: 28010037 tbnz     w8, #0, #0x339cc54
0339cc34: e0f40090 adrp     x0, #0x5238000
0339cc38: 00bc45f9 ldr      x0, [x0, #0xb78]
0339cc3c: b1517097 bl       #0xfb1300
0339cc40: e0ef00b0 adrp     x0, #0x5199000
0339cc44: 002046f9 ldr      x0, [x0, #0xc40]
0339cc48: ae517097 bl       #0xfb1300
0339cc4c: 28008052 mov      w8, #1
0339cc50: c8c62639 strb     w8, [x22, #0x9b1]
0339cc54: f6f40090 adrp     x22, #0x5238000
0339cc58: d6be45f9 ldr      x22, [x22, #0xb78]
0339cc5c: e00314aa mov      x0, x20
0339cc60: e1031faa mov      x1, xzr
0339cc64: 645abb97 bl       #0x22735f4 ; System.Object$$.ctor
0339cc68: a00240f9 ldr      x0, [x21]
0339cc6c: 08e040b9 ldr      w8, [x0, #0xe0]
0339cc70: 48000035 cbnz     w8, #0x339cc78
0339cc74: e4517097 bl       #0xfb1404
0339cc78: c10240f9 ldr      x1, [x22]
0339cc7c: a0008052 mov      w0, #5
0339cc80: fdd2f197 bl       #0x3011874 ; Royal.Scenes.Start.Context.ApplicationContext$$Get<object>
0339cc84: e10300aa mov      x1, x0
0339cc88: e00314aa mov      x0, x20
0339cc8c: 018c0af8 str      x1, [x0, #0xa8]!
0339cc90: 87517097 bl       #0xfb12ac
0339cc94: 930e0ef8 str      x19, [x20, #0xe0]!
0339cc98: 8a26362d stp      s10, s9, [x20, #-0x50]
0339cc9c: 88821bbc stur     s8, [x20, #-0x48]
0339cca0: e00314aa mov      x0, x20
0339cca4: e10313aa mov      x1, x19
0339cca8: f37b43a9 ldp      x19, x30, [sp, #0x30]
0339ccac: f55342a9 ldp      x21, x20, [sp, #0x20]
0339ccb0: f60f40f9 ldr      x22, [sp, #0x18]
0339ccb4: e9a3406d ldp      d9, d8, [sp, #8]
0339ccb8: ea0744fc ldr      d10, [sp], #0x40
0339ccbc: 7c517017 b        #0xfb12ac
