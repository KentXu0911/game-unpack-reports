# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_MinDistanceToScaleDown
# Linear span to next metadata entry; not a complete CFG.
033989d4: 00102e1e fmov     s0, #1.00000000
033989d8: c0035fd6 ret      
