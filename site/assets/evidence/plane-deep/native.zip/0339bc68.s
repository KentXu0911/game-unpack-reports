# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$TargetReached
# Linear span to next metadata entry; not a complete CFG.
0339bc68: f60f1df8 str      x22, [sp, #-0x30]!
0339bc6c: f55301a9 stp      x21, x20, [sp, #0x10]
0339bc70: f37b02a9 stp      x19, x30, [sp, #0x20]
0339bc74: 550f01f0 adrp     x21, #0x5586000
0339bc78: d6f400d0 adrp     x22, #0x5235000
0339bc7c: a8ae6639 ldrb     w8, [x21, #0x9ab]
0339bc80: d6d642f9 ldr      x22, [x22, #0x5a8]
0339bc84: f403012a mov      w20, w1
0339bc88: f30300aa mov      x19, x0
0339bc8c: 28010037 tbnz     w8, #0, #0x339bcb0
0339bc90: c0f400d0 adrp     x0, #0x5235000
0339bc94: 00d442f9 ldr      x0, [x0, #0x5a8]
0339bc98: 9a557097 bl       #0xfb1300
0339bc9c: 00f400d0 adrp     x0, #0x521d000
0339bca0: 00a041f9 ldr      x0, [x0, #0x340]
0339bca4: 97557097 bl       #0xfb1300
0339bca8: 28008052 mov      w8, #1
0339bcac: a8ae2639 strb     w8, [x21, #0x9ab]
0339bcb0: c10240f9 ldr      x1, [x22]
0339bcb4: c0028052 mov      w0, #0x16
0339bcb8: 4f8bc697 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
0339bcbc: e00600b4 cbz      x0, #0x339bd98
0339bcc0: 15f400d0 adrp     x21, #0x521d000
0339bcc4: b5a241f9 ldr      x21, [x21, #0x340]
0339bcc8: 01258052 mov      w1, #0x128
0339bccc: e2031faa mov      x2, xzr
0339bcd0: ca92e897 bl       #0x2dc07f8 ; Royal.Scenes.Game.Levels.Units.Sfx.GameSfxManager$$StopSoundInLoop
0339bcd4: a10240f9 ldr      x1, [x21]
0339bcd8: 20008052 mov      w0, #1
0339bcdc: 468bc697 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
0339bce0: 686a40f9 ldr      x8, [x19, #0xd0]
0339bce4: a80500b4 cbz      x8, #0x339bd98
0339bce8: f50300aa mov      x21, x0
0339bcec: e00308aa mov      x0, x8
0339bcf0: e1031faa mov      x1, xzr
0339bcf4: 2d9c2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339bcf8: 150500b4 cbz      x21, #0x339bd98
0339bcfc: e00400b4 cbz      x0, #0x339bd98
0339bd00: a11240f9 ldr      x1, [x21, #0x20]
0339bd04: e2031faa mov      x2, xzr
0339bd08: 5eba2594 bl       #0x3d0a680 ; UnityEngine.Transform$$SetParent
0339bd0c: 686a40f9 ldr      x8, [x19, #0xd0]
0339bd10: 480400b4 cbz      x8, #0x339bd98
0339bd14: 001140f9 ldr      x0, [x8, #0x20]
0339bd18: 000400b4 cbz      x0, #0x339bd98
0339bd1c: e1031faa mov      x1, xzr
0339bd20: 7145f597 bl       #0x30ed2e4 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$Reset
0339bd24: 606a40f9 ldr      x0, [x19, #0xd0]
0339bd28: 800300b4 cbz      x0, #0x339bd98
0339bd2c: e1031faa mov      x1, xzr
0339bd30: 1e9c2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339bd34: d60e01f0 adrp     x22, #0x5576000
0339bd38: c8a27c39 ldrb     w8, [x22, #0xf28]
0339bd3c: f50300aa mov      x21, x0
0339bd40: c8000035 cbnz     w8, #0x339bd58
0339bd44: 80f40090 adrp     x0, #0x522b000
0339bd48: 00ac43f9 ldr      x0, [x0, #0x758]
0339bd4c: 6d557097 bl       #0xfb1300
0339bd50: 28008052 mov      w8, #1
0339bd54: c8a23c39 strb     w8, [x22, #0xf28]
0339bd58: 150200b4 cbz      x21, #0x339bd98
0339bd5c: 88f40090 adrp     x8, #0x522b000
0339bd60: 08ad43f9 ldr      x8, [x8, #0x758]
0339bd64: e00315aa mov      x0, x21
0339bd68: e1031faa mov      x1, xzr
0339bd6c: 080140f9 ldr      x8, [x8]
0339bd70: 085d40f9 ldr      x8, [x8, #0xb8]
0339bd74: 0085412d ldp      s0, s1, [x8, #0xc]
0339bd78: 021540bd ldr      s2, [x8, #0x14]
0339bd7c: aab92594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
0339bd80: 81020012 and      w1, w20, #1
0339bd84: e00313aa mov      x0, x19
0339bd88: f37b42a9 ldp      x19, x30, [sp, #0x20]
0339bd8c: f55341a9 ldp      x21, x20, [sp, #0x10]
0339bd90: f60743f8 ldr      x22, [sp], #0x30
0339bd94: 4cf8ff17 b        #0x3399ec4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$TargetReached
0339bd98: a4557097 bl       #0xfb1428
