# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$.cctor
# Linear span to next metadata entry; not a complete CFG.
0339aefc: f40f1ef8 str      x20, [sp, #-0x20]!
0339af00: f37b01a9 stp      x19, x30, [sp, #0x10]
0339af04: 730f0190 adrp     x19, #0x5586000
0339af08: f4f200b0 adrp     x20, #0x51f7000
0339af0c: 68966639 ldrb     w8, [x19, #0x9a5]
0339af10: 94fa44f9 ldr      x20, [x20, #0x9f0]
0339af14: c8000037 tbnz     w8, #0, #0x339af2c
0339af18: e0f200b0 adrp     x0, #0x51f7000
0339af1c: 00f844f9 ldr      x0, [x0, #0x9f0]
0339af20: f8587097 bl       #0xfb1300
0339af24: 28008052 mov      w8, #1
0339af28: 68962639 strb     w8, [x19, #0x9a5]
0339af2c: 880240f9 ldr      x8, [x20]
0339af30: 695b00f0 adrp     x9, #0x3f09000
0339af34: 204544fd ldr      d0, [x9, #0x888]
0339af38: 085d40f9 ldr      x8, [x8, #0xb8]
0339af3c: 000100fd str      d0, [x8]
0339af40: 1f0900b9 str      wzr, [x8, #8]
0339af44: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339af48: f40742f8 ldr      x20, [sp], #0x20
0339af4c: c0035fd6 ret      
