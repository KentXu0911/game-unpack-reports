# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinConditionForAreaExploder
# Linear span to next metadata entry; not a complete CFG.
026a865c: ff8303d1 sub      sp, sp, #0xe0
026a8660: fc4300f9 str      x28, [sp, #0x80]
026a8664: fb6b09a9 stp      x27, x26, [sp, #0x90]
026a8668: f9630aa9 stp      x25, x24, [sp, #0xa0]
026a866c: f75b0ba9 stp      x23, x22, [sp, #0xb0]
026a8670: f5530ca9 stp      x21, x20, [sp, #0xc0]
026a8674: f37b0da9 stp      x19, x30, [sp, #0xd0]
026a8678: f303032a mov      w19, w3
026a867c: f40302aa mov      x20, x2
026a8680: f60301aa mov      x22, x1
026a8684: f50300aa mov      x21, x0
026a8688: 47000094 bl       #0x26a87a4 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ShouldCalculateSpecificWinConditions
026a868c: a0010036 tbz      w0, #0, #0x26a86c0
026a8690: f903134b neg      w25, w19
026a8694: 3f03136b cmp      w25, w19
026a8698: 8d020054 b.le     #0x26a86e8
026a869c: e00315aa mov      x0, x21
026a86a0: f37b4da9 ldp      x19, x30, [sp, #0xd0]
026a86a4: f5534ca9 ldp      x21, x20, [sp, #0xc0]
026a86a8: f75b4ba9 ldp      x23, x22, [sp, #0xb0]
026a86ac: f9634aa9 ldp      x25, x24, [sp, #0xa0]
026a86b0: fb6b49a9 ldp      x27, x26, [sp, #0x90]
026a86b4: fc4340f9 ldr      x28, [sp, #0x80]
026a86b8: ff830391 add      sp, sp, #0xe0
026a86bc: 84000014 b        #0x26a88cc ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinCondition
026a86c0: f7031f2a mov      w23, wzr
026a86c4: e0020012 and      w0, w23, #1
026a86c8: f37b4da9 ldp      x19, x30, [sp, #0xd0]
026a86cc: f5534ca9 ldp      x21, x20, [sp, #0xc0]
026a86d0: f75b4ba9 ldp      x23, x22, [sp, #0xb0]
026a86d4: f9634aa9 ldp      x25, x24, [sp, #0xa0]
026a86d8: fb6b49a9 ldp      x27, x26, [sp, #0x90]
026a86dc: fc4340f9 ldr      x28, [sp, #0x80]
026a86e0: ff830391 add      sp, sp, #0xe0
026a86e4: c0035fd6 ret      
026a86e8: dafe60d3 lsr      x26, x22, #0x20
026a86ec: f803192a mov      w24, w25
026a86f0: 17031a0b add      w23, w24, w26
026a86f4: fb03192a mov      w27, w25
026a86f8: 881a40f9 ldr      x8, [x20, #0x30]
026a86fc: 818240ad ldp      q1, q0, [x20, #0x10]
026a8700: 8202c03d ldr      q2, [x20]
026a8704: c1021b0b add      w1, w22, w27
026a8708: e3030191 add      x3, sp, #0x40
026a870c: e00315aa mov      x0, x21
026a8710: e203172a mov      w2, w23
026a8714: e83b00f9 str      x8, [sp, #0x70]
026a8718: e18302ad stp      q1, q0, [sp, #0x50]
026a871c: e213803d str      q2, [sp, #0x40]
026a8720: 32000094 bl       #0x26a87e8 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddTemporaryIncomingExploder
026a8724: 7b070011 add      w27, w27, #1
026a8728: 7f03136b cmp      w27, w19
026a872c: 6dfeff54 b.le     #0x26a86f8
026a8730: 18070011 add      w24, w24, #1
026a8734: 1f03136b cmp      w24, w19
026a8738: cdfdff54 b.le     #0x26a86f0
026a873c: e00315aa mov      x0, x21
026a8740: 63000094 bl       #0x26a88cc ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinCondition
026a8744: 3f03136b cmp      w25, w19
026a8748: f703002a mov      w23, w0
026a874c: ccfbff54 b.gt     #0x26a86c4
026a8750: fb03192a mov      w27, w25
026a8754: 78031a0b add      w24, w27, w26
026a8758: fc03192a mov      w28, w25
026a875c: 881a40f9 ldr      x8, [x20, #0x30]
026a8760: 818240ad ldp      q1, q0, [x20, #0x10]
026a8764: 8202c03d ldr      q2, [x20]
026a8768: c1021c0b add      w1, w22, w28
026a876c: e3030091 mov      x3, sp
026a8770: e00315aa mov      x0, x21
026a8774: e203182a mov      w2, w24
026a8778: e81b00f9 str      x8, [sp, #0x30]
026a877c: e18300ad stp      q1, q0, [sp, #0x10]
026a8780: e203803d str      q2, [sp]
026a8784: bb000094 bl       #0x26a8a70 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$RemoveTemporaryIncomingExploder
026a8788: 9c070011 add      w28, w28, #1
026a878c: 9f03136b cmp      w28, w19
026a8790: 6dfeff54 b.le     #0x26a875c
026a8794: 7b070011 add      w27, w27, #1
026a8798: 7f03136b cmp      w27, w19
026a879c: cdfdff54 b.le     #0x26a8754
026a87a0: c9ffff17 b        #0x26a86c4
