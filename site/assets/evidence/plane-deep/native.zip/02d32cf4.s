# Royal.Scenes.Game.Mechanics.Items.CoilItem.CoilItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02d32cf4: f40f1ef8 str      x20, [sp, #-0x20]!
02d32cf8: f37b01a9 stp      x19, x30, [sp, #0x10]
02d32cfc: 080040f9 ldr      x8, [x0]
02d32d00: f303012a mov      w19, w1
02d32d04: f40300aa mov      x20, x0
02d32d08: 096542f9 ldr      x9, [x8, #0x4c8]
02d32d0c: 086942f9 ldr      x8, [x8, #0x4d0]
02d32d10: e10308aa mov      x1, x8
02d32d14: 20013fd6 blr      x9
02d32d18: 00050034 cbz      w0, #0x2d32db8
02d32d1c: 880240f9 ldr      x8, [x20]
02d32d20: e00314aa mov      x0, x20
02d32d24: 096542f9 ldr      x9, [x8, #0x4c8]
02d32d28: 016942f9 ldr      x1, [x8, #0x4d0]
02d32d2c: 20013fd6 blr      x9
02d32d30: f403002a mov      w20, w0
02d32d34: e003132a mov      w0, w19
02d32d38: e1031faa mov      x1, xzr
02d32d3c: 00471994 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02d32d40: e0000036 tbz      w0, #0, #0x2d32d5c
02d32d44: 08229f52 mov      w8, #0xf910
02d32d48: 09989552 mov      w9, #0xacc0
02d32d4c: 9f060071 cmp      w20, #1
02d32d50: c800a072 movk     w8, #6, lsl #16
02d32d54: 690aa072 movk     w9, #0x53, lsl #16
02d32d58: 09000014 b        #0x2d32d7c
02d32d5c: e003132a mov      w0, w19
02d32d60: e1031faa mov      x1, xzr
02d32d64: 885f1994 bl       #0x338ab84 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsVerticalLineExploder
02d32d68: e0000036 tbz      w0, #0, #0x2d32d84
02d32d6c: 48c19452 mov      w8, #0xa60a
02d32d70: 8800a072 movk     w8, #4, lsl #16
02d32d74: 09a10011 add      w9, w8, #0x28
02d32d78: 9f060071 cmp      w20, #1
02d32d7c: 2001881a csel     w0, w9, w8, eq
02d32d80: 0e000014 b        #0x2d32db8
02d32d84: e003132a mov      w0, w19
02d32d88: e1031faa mov      x1, xzr
02d32d8c: 08471994 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02d32d90: 09229f52 mov      w9, #0xf910
02d32d94: 08058052 mov      w8, #0x28
02d32d98: c900a072 movk     w9, #6, lsl #16
02d32d9c: 9f060071 cmp      w20, #1
02d32da0: 2801082a orr      w8, w9, w8
02d32da4: 0801891a csel     w8, w8, w9, eq
02d32da8: a9608a52 mov      w9, #0x5305
02d32dac: 1f000072 tst      w0, #1
02d32db0: 4900a072 movk     w9, #2, lsl #16
02d32db4: 2011881a csel     w0, w9, w8, ne
02d32db8: f37b41a9 ldp      x19, x30, [sp, #0x10]
02d32dbc: f40742f8 ldr      x20, [sp], #0x20
02d32dc0: c0035fd6 ret      
