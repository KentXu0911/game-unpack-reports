# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_ScaleUpSpeedConst
# Linear span to next metadata entry; not a complete CFG.
0339b574: 0010231e fmov     s0, #6.00000000
0339b578: c0035fd6 ret      
