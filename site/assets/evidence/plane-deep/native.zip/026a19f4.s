# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$get_GetMoveType
# Linear span to next metadata entry; not a complete CFG.
026a19f4: 20008052 mov      w0, #1
026a19f8: c0035fd6 ret      
