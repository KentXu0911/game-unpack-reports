# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerTargetExplodeParticles$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339899c: e1031faa mov      x1, xzr
033989a0: ccb4ff17 b        #0x3385cd0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemParticles$$.ctor
