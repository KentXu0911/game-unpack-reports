# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$GetTargetIndex
# Linear span to next metadata entry; not a complete CFG.
033a3200: e0031f2a mov      w0, wzr
033a3204: c0035fd6 ret      
