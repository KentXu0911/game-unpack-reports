# Royal.Scenes.Game.Mechanics.Items.BathtubItem.BathtubItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
021774c0: f60f1df8 str      x22, [sp, #-0x30]!
021774c4: f55301a9 stp      x21, x20, [sp, #0x10]
021774c8: f37b02a9 stp      x19, x30, [sp, #0x20]
021774cc: 35a001d0 adrp     x21, #0x557d000
021774d0: a82e5e39 ldrb     w8, [x21, #0x78b]
021774d4: f403012a mov      w20, w1
021774d8: f30300aa mov      x19, x0
021774dc: c8000037 tbnz     w8, #0, #0x21774f4
021774e0: c0800190 adrp     x0, #0x518f000
021774e4: 00cc45f9 ldr      x0, [x0, #0xb98]
021774e8: 86e7b897 bl       #0xfb1300
021774ec: 28008052 mov      w8, #1
021774f0: a82e1e39 strb     w8, [x21, #0x78b]
021774f4: 68464539 ldrb     w8, [x19, #0x151]
021774f8: 08090034 cbz      w8, #0x2177618
021774fc: e003142a mov      w0, w20
02177500: e1031faa mov      x1, xzr
02177504: 0e354894 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02177508: 40060036 tbz      w0, #0, #0x21775d0
0217750c: 680240f9 ldr      x8, [x19]
02177510: e00313aa mov      x0, x19
02177514: 096542f9 ldr      x9, [x8, #0x4c8]
02177518: 016942f9 ldr      x1, [x8, #0x4d0]
0217751c: 20013fd6 blr      x9
02177520: 680240f9 ldr      x8, [x19]
02177524: f403002a mov      w20, w0
02177528: e00313aa mov      x0, x19
0217752c: 09bd41f9 ldr      x9, [x8, #0x378]
02177530: 01c141f9 ldr      x1, [x8, #0x380]
02177534: 20013fd6 blr      x9
02177538: e1031faa mov      x1, xzr
0217753c: 13354894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02177540: 9f060071 cmp      w20, #1
02177544: f403002a mov      w20, w0
02177548: a1060054 b.ne     #0x217761c
0217754c: 680240f9 ldr      x8, [x19]
02177550: e00313aa mov      x0, x19
02177554: 09bd41f9 ldr      x9, [x8, #0x378]
02177558: 01c141f9 ldr      x1, [x8, #0x380]
0217755c: 20013fd6 blr      x9
02177560: e1031faa mov      x1, xzr
02177564: 09354894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02177568: 680240f9 ldr      x8, [x19]
0217756c: f503002a mov      w21, w0
02177570: e00313aa mov      x0, x19
02177574: 09bd41f9 ldr      x9, [x8, #0x378]
02177578: 01c141f9 ldr      x1, [x8, #0x380]
0217757c: 20013fd6 blr      x9
02177580: e1031faa mov      x1, xzr
02177584: 01354894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02177588: 68a240f9 ldr      x8, [x19, #0x140]
0217758c: c80800b4 cbz      x8, #0x21776a4
02177590: 080940f9 ldr      x8, [x8, #0x10]
02177594: 880800b4 cbz      x8, #0x21776a4
02177598: c9aa8a52 mov      w9, #0x5556
0217759c: 081940b9 ldr      w8, [x8, #0x18]
021775a0: a9aaaa72 movk     w9, #0x5555, lsl #16
021775a4: a97e299b smull    x9, w21, w9
021775a8: 1f000071 cmp      w0, #0
021775ac: 2bfd7fd3 lsr      x11, x9, #0x3f
021775b0: 29fd60d3 lsr      x9, x9, #0x20
021775b4: 0aa4801a cinc     w10, w0, lt
021775b8: 29010b0b add      w9, w9, w11
021775bc: 4a7d0113 asr      w10, w10, #1
021775c0: 2901140b add      w9, w9, w20
021775c4: 08050051 sub      w8, w8, #1
021775c8: 14250a1b madd     w20, w8, w10, w9
021775cc: 14000014 b        #0x217761c
021775d0: e00313aa mov      x0, x19
021775d4: e103142a mov      w1, w20
021775d8: 34000094 bl       #0x21776a8 ; Royal.Scenes.Game.Mechanics.Items.BathtubItem.BathtubItemModel$$IsOneOfWinningCells
021775dc: a0020036 tbz      w0, #0, #0x2177630
021775e0: e00313aa mov      x0, x19
021775e4: 62f7ff97 bl       #0x217536c ; Royal.Scenes.Game.Mechanics.Items.BathtubItem.BathtubItemModel$$RemainingExplodeCountOfThis
021775e8: 1f040071 cmp      w0, #1
021775ec: 61010054 b.ne     #0x2177618
021775f0: 680240f9 ldr      x8, [x19]
021775f4: e00313aa mov      x0, x19
021775f8: 09bd41f9 ldr      x9, [x8, #0x378]
021775fc: 01c141f9 ldr      x1, [x8, #0x380]
02177600: 20013fd6 blr      x9
02177604: f37b42a9 ldp      x19, x30, [sp, #0x20]
02177608: f55341a9 ldp      x21, x20, [sp, #0x10]
0217760c: e1031faa mov      x1, xzr
02177610: f60743f8 ldr      x22, [sp], #0x30
02177614: dd344814 b        #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02177618: f4031f2a mov      w20, wzr
0217761c: e003142a mov      w0, w20
02177620: f37b42a9 ldp      x19, x30, [sp, #0x20]
02177624: f55341a9 ldp      x21, x20, [sp, #0x10]
02177628: f60743f8 ldr      x22, [sp], #0x30
0217762c: c0035fd6 ret      
02177630: e003142a mov      w0, w20
02177634: e1031faa mov      x1, xzr
02177638: dd344894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
0217763c: 68a240f9 ldr      x8, [x19, #0x140]
02177640: 280300b4 cbz      x8, #0x21776a4
02177644: 690240f9 ldr      x9, [x19]
02177648: 16414239 ldrb     w22, [x8, #0x90]
0217764c: f503002a mov      w21, w0
02177650: e00313aa mov      x0, x19
02177654: 28bd41f9 ldr      x8, [x9, #0x378]
02177658: 21c141f9 ldr      x1, [x9, #0x380]
0217765c: 00013fd6 blr      x8
02177660: e1031faa mov      x1, xzr
02177664: c9344894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02177668: f403002a mov      w20, w0
0217766c: d5000036 tbz      w21, #0, #0x2177684
02177670: d6000035 cbnz     w22, #0x2177688
02177674: 9f020071 cmp      w20, #0
02177678: 88a6941a cinc     w8, w20, lt
0217767c: 147d0113 asr      w20, w8, #1
02177680: e7ffff17 b        #0x217761c
02177684: d6fcff34 cbz      w22, #0x217761c
02177688: e8cc8c52 mov      w8, #0x6667
0217768c: c8ccac72 movk     w8, #0x6666, lsl #16
02177690: 887e289b smull    x8, w20, w8
02177694: 09fd7fd3 lsr      x9, x8, #0x3f
02177698: 08fd6293 asr      x8, x8, #0x22
0217769c: 1401090b add      w20, w8, w9
021776a0: dfffff17 b        #0x217761c
021776a4: 61e7b897 bl       #0xfb1428
