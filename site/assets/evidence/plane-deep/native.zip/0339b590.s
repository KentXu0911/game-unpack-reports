# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_GoSpeedMultiplierConst
# Linear span to next metadata entry; not a complete CFG.
0339b590: 00d0251e fmov     s0, #15.00000000
0339b594: c0035fd6 ret      
