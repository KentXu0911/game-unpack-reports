# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$get_ItemType
# Linear span to next metadata entry; not a complete CFG.
03397524: 60008052 mov      w0, #3
03397528: c0035fd6 ret      
