# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeScaleUp
# Linear span to next metadata entry; not a complete CFG.
0339c380: ff4302d1 sub      sp, sp, #0x90
0339c384: ef3b036d stp      d15, d14, [sp, #0x30]
0339c388: ed33046d stp      d13, d12, [sp, #0x40]
0339c38c: eb2b056d stp      d11, d10, [sp, #0x50]
0339c390: e923066d stp      d9, d8, [sp, #0x60]
0339c394: f55307a9 stp      x21, x20, [sp, #0x70]
0339c398: f37b08a9 stp      x19, x30, [sp, #0x80]
0339c39c: 540f01d0 adrp     x20, #0x5586000
0339c3a0: 88b66639 ldrb     w8, [x20, #0x9ad]
0339c3a4: a81ca54e mov      v8.16b, v5.16b
0339c3a8: 891ca44e mov      v9.16b, v4.16b
0339c3ac: 6a1ca34e mov      v10.16b, v3.16b
0339c3b0: 4b1ca24e mov      v11.16b, v2.16b
0339c3b4: 2c1ca14e mov      v12.16b, v1.16b
0339c3b8: 0d1ca04e mov      v13.16b, v0.16b
0339c3bc: f30300aa mov      x19, x0
0339c3c0: e62f00bd str      s6, [sp, #0x2c]
0339c3c4: c8000037 tbnz     w8, #0, #0x339c3dc
0339c3c8: c0f200f0 adrp     x0, #0x51f7000
0339c3cc: 00f844f9 ldr      x0, [x0, #0x9f0]
0339c3d0: cc537097 bl       #0xfb1300
0339c3d4: 28008052 mov      w8, #1
0339c3d8: 88b62639 strb     w8, [x20, #0x9ad]
0339c3dc: 686a40f9 ldr      x8, [x19, #0xd0]
0339c3e0: 680c00b4 cbz      x8, #0x339c56c
0339c3e4: 004140f9 ldr      x0, [x8, #0x80]
0339c3e8: 200c00b4 cbz      x0, #0x339c56c
0339c3ec: e1031faa mov      x1, xzr
0339c3f0: 6e9a2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339c3f4: 686a40f9 ldr      x8, [x19, #0xd0]
0339c3f8: a80b00b4 cbz      x8, #0x339c56c
0339c3fc: f40300aa mov      x20, x0
0339c400: 004140f9 ldr      x0, [x8, #0x80]
0339c404: 400b00b4 cbz      x0, #0x339c56c
0339c408: e1031faa mov      x1, xzr
0339c40c: 679a2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339c410: e00a00b4 cbz      x0, #0x339c56c
0339c414: d5f200f0 adrp     x21, #0x51f7000
0339c418: b5fa44f9 ldr      x21, [x21, #0x9f0]
0339c41c: e1031faa mov      x1, xzr
0339c420: 83b62594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
0339c424: e287042d stp      s2, s1, [sp, #0x24]
0339c428: a00240f9 ldr      x0, [x21]
0339c42c: 0f1ca04e mov      v15.16b, v0.16b
0339c430: 08e040b9 ldr      w8, [x0, #0xe0]
0339c434: e9a3032d stp      s9, s8, [sp, #0x1c]
0339c438: ebab022d stp      s11, s10, [sp, #0x14]
0339c43c: edb3012d stp      s13, s12, [sp, #0xc]
0339c440: 68000035 cbnz     w8, #0x339c44c
0339c444: f0537097 bl       #0xfb1404
0339c448: a00240f9 ldr      x0, [x21]
0339c44c: 085c40f9 ldr      x8, [x0, #0xb8]
0339c450: e0031faa mov      x0, xzr
0339c454: 0b31402d ldp      s11, s12, [x8]
0339c458: 0d0940bd ldr      s13, [x8, #8]
0339c45c: e2862594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339c460: 150f01b0 adrp     x21, #0x557d000
0339c464: a8ba5f39 ldrb     w8, [x21, #0x7ee]
0339c468: 0e1ca04e mov      v14.16b, v0.16b
0339c46c: c8000035 cbnz     w8, #0x339c484
0339c470: 20f30090 adrp     x0, #0x5200000
0339c474: 008c46f9 ldr      x0, [x0, #0xd18]
0339c478: a2537097 bl       #0xfb1300
0339c47c: 28008052 mov      w8, #1
0339c480: a8ba1f39 strb     w8, [x21, #0x7ee]
0339c484: e593442d ldp      s5, s4, [sp, #0x24]
0339c488: 69392f1e fsub     s9, s11, s15
0339c48c: e21daf4e mov      v2.16b, v15.16b
0339c490: 2009291e fmul     s0, s9, s9
0339c494: 8f39241e fsub     s15, s12, s4
0339c498: a839251e fsub     s8, s13, s5
0339c49c: e1092f1e fmul     s1, s15, s15
0339c4a0: 0028211e fadd     s0, s0, s1
0339c4a4: 0109281e fmul     s1, s8, s8
0339c4a8: 2a28201e fadd     s10, s1, s0
0339c4ac: 4821201e fcmp     s10, #0.0
0339c4b0: 60030054 b.eq     #0x339c51c
0339c4b4: e02f40bd ldr      s0, [sp, #0x2c]
0339c4b8: e20b00bd str      s2, [sp, #8]
0339c4bc: ce09201e fmul     s14, s14, s0
0339c4c0: c821201e fcmp     s14, #0.0
0339c4c4: 8b000054 b.lt     #0x339c4d4
0339c4c8: c0092e1e fmul     s0, s14, s14
0339c4cc: 4021201e fcmp     s10, s0
0339c4d0: 69020054 b.ls     #0x339c51c
0339c4d4: 28f30090 adrp     x8, #0x5200000
0339c4d8: 088d46f9 ldr      x8, [x8, #0xd18]
0339c4dc: 000140f9 ldr      x0, [x8]
0339c4e0: 08e040b9 ldr      w8, [x0, #0xe0]
0339c4e4: 68000035 cbnz     w8, #0x339c4f0
0339c4e8: c7537097 bl       #0xfb1404
0339c4ec: e593442d ldp      s5, s4, [sp, #0x24]
0339c4f0: e30b40bd ldr      s3, [sp, #8]
0339c4f4: 40c1211e fsqrt    s0, s10
0339c4f8: 2119201e fdiv     s1, s9, s0
0339c4fc: e219201e fdiv     s2, s15, s0
0339c500: 0019201e fdiv     s0, s8, s0
0339c504: c109211e fmul     s1, s14, s1
0339c508: c209221e fmul     s2, s14, s2
0339c50c: c009201e fmul     s0, s14, s0
0339c510: 6b28211e fadd     s11, s3, s1
0339c514: 8c28221e fadd     s12, s4, s2
0339c518: ad28201e fadd     s13, s5, s0
0339c51c: 940200b4 cbz      x20, #0x339c56c
0339c520: e00314aa mov      x0, x20
0339c524: 601dab4e mov      v0.16b, v11.16b
0339c528: 811dac4e mov      v1.16b, v12.16b
0339c52c: a21dad4e mov      v2.16b, v13.16b
0339c530: e1031faa mov      x1, xzr
0339c534: 66b62594 bl       #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
0339c538: e00313aa mov      x0, x19
0339c53c: e087412d ldp      s0, s1, [sp, #0xc]
0339c540: e28f422d ldp      s2, s3, [sp, #0x14]
0339c544: e497432d ldp      s4, s5, [sp, #0x1c]
0339c548: e62f40bd ldr      s6, [sp, #0x2c]
0339c54c: f37b48a9 ldp      x19, x30, [sp, #0x80]
0339c550: f55347a9 ldp      x21, x20, [sp, #0x70]
0339c554: e923466d ldp      d9, d8, [sp, #0x60]
0339c558: eb2b456d ldp      d11, d10, [sp, #0x50]
0339c55c: ed33446d ldp      d13, d12, [sp, #0x40]
0339c560: ef3b436d ldp      d15, d14, [sp, #0x30]
0339c564: ff430291 add      sp, sp, #0x90
0339c568: a5f9ff17 b        #0x339abfc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScaleUp
0339c56c: af537097 bl       #0xfb1428
