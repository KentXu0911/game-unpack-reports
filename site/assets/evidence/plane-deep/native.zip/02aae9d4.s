# Royal.Scenes.Game.Mechanics.Items.DuckShootingItem.DuckShootingItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02aae9d4: f40f1ef8 str      x20, [sp, #-0x20]!
02aae9d8: f37b01a9 stp      x19, x30, [sp, #0x10]
02aae9dc: 08004539 ldrb     w8, [x0, #0x140]
02aae9e0: 88020034 cbz      w8, #0x2aaea30
02aae9e4: f30300aa mov      x19, x0
02aae9e8: f403012a mov      w20, w1
02aae9ec: e003012a mov      w0, w1
02aae9f0: e1031faa mov      x1, xzr
02aae9f4: ee572394 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02aae9f8: 40020036 tbz      w0, #0, #0x2aaea40
02aae9fc: 603e40f9 ldr      x0, [x19, #0x78]
02aaea00: c00200b4 cbz      x0, #0x2aaea58
02aaea04: 736a40b9 ldr      w19, [x19, #0x68]
02aaea08: e1031faa mov      x1, xzr
02aaea0c: a92e0a94 bl       #0x2d3a4b0 ; Royal.Scenes.Game.Mechanics.Explode.IncomingExploderContainer$$GetIncomingCount
02aaea10: 6802004b sub      w8, w19, w0
02aaea14: 09229f52 mov      w9, #0xf910
02aaea18: 1f1d0071 cmp      w8, #7
02aaea1c: 08918f52 mov      w8, #0x7c88
02aaea20: c900a072 movk     w9, #6, lsl #16
02aaea24: 6800a072 movk     w8, #3, lsl #16
02aaea28: 00b1891a csel     w0, w8, w9, lt
02aaea2c: 02000014 b        #0x2aaea34
02aaea30: e0031f2a mov      w0, wzr
02aaea34: f37b41a9 ldp      x19, x30, [sp, #0x10]
02aaea38: f40742f8 ldr      x20, [sp], #0x20
02aaea3c: c0035fd6 ret      
02aaea40: e00313aa mov      x0, x19
02aaea44: f37b41a9 ldp      x19, x30, [sp, #0x10]
02aaea48: e103142a mov      w1, w20
02aaea4c: e2031faa mov      x2, xzr
02aaea50: f40742f8 ldr      x20, [sp], #0x20
02aaea54: 8f8c2314 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
02aaea58: 740a9497 bl       #0xfb1428
