# Royal.Scenes.Game.Mechanics.Items.ToyBoxVerticalItem.ToyBoxVerticalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03de1718: f40f1ef8 str      x20, [sp, #-0x20]!
03de171c: f37b01a9 stp      x19, x30, [sp, #0x10]
03de1720: f403012a mov      w20, w1
03de1724: f30300aa mov      x19, x0
03de1728: e003012a mov      w0, w1
03de172c: e1031faa mov      x1, xzr
03de1730: 838cd697 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03de1734: 9f0a0071 cmp      w20, #2
03de1738: 40000054 b.eq     #0x3de1740
03de173c: 20040036 tbz      w0, #0, #0x3de17c0
03de1740: 680240f9 ldr      x8, [x19]
03de1744: e00313aa mov      x0, x19
03de1748: 096542f9 ldr      x9, [x8, #0x4c8]
03de174c: 016942f9 ldr      x1, [x8, #0x4d0]
03de1750: 20013fd6 blr      x9
03de1754: 1f040071 cmp      w0, #1
03de1758: 41030054 b.ne     #0x3de17c0
03de175c: 680240f9 ldr      x8, [x19]
03de1760: e00313aa mov      x0, x19
03de1764: 09bd41f9 ldr      x9, [x8, #0x378]
03de1768: 01c141f9 ldr      x1, [x8, #0x380]
03de176c: 20013fd6 blr      x9
03de1770: e1031faa mov      x1, xzr
03de1774: 858cd697 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03de1778: 680240f9 ldr      x8, [x19]
03de177c: f403002a mov      w20, w0
03de1780: e00313aa mov      x0, x19
03de1784: 09bd41f9 ldr      x9, [x8, #0x378]
03de1788: 01c141f9 ldr      x1, [x8, #0x380]
03de178c: 20013fd6 blr      x9
03de1790: e1031faa mov      x1, xzr
03de1794: 7d8cd697 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03de1798: c8aa8a52 mov      w8, #0x5556
03de179c: a8aaaa72 movk     w8, #0x5555, lsl #16
03de17a0: 087c289b smull    x8, w0, w8
03de17a4: f37b41a9 ldp      x19, x30, [sp, #0x10]
03de17a8: 09fd7fd3 lsr      x9, x8, #0x3f
03de17ac: 08fd60d3 lsr      x8, x8, #0x20
03de17b0: 0801090b add      w8, w8, w9
03de17b4: 0001140b add      w0, w8, w20
03de17b8: f40742f8 ldr      x20, [sp], #0x20
03de17bc: c0035fd6 ret      
03de17c0: e00313aa mov      x0, x19
03de17c4: f37b41a9 ldp      x19, x30, [sp, #0x10]
03de17c8: e103142a mov      w1, w20
03de17cc: e2031faa mov      x2, xzr
03de17d0: f40742f8 ldr      x20, [sp], #0x20
03de17d4: 2fc1d617 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
