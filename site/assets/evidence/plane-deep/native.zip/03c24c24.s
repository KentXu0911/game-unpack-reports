# Royal.Scenes.Game.Mechanics.Items.UfoItem.UfoLauncherItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03c24c24: f60f1df8 str      x22, [sp, #-0x30]!
03c24c28: f55301a9 stp      x21, x20, [sp, #0x10]
03c24c2c: f37b02a9 stp      x19, x30, [sp, #0x20]
03c24c30: 08204339 ldrb     w8, [x0, #0xc8]
03c24c34: 28040034 cbz      w8, #0x3c24cb8
03c24c38: f30300aa mov      x19, x0
03c24c3c: f403012a mov      w20, w1
03c24c40: e003012a mov      w0, w1
03c24c44: e1031faa mov      x1, xzr
03c24c48: 3d7fdd97 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03c24c4c: a0030036 tbz      w0, #0, #0x3c24cc0
03c24c50: 680240f9 ldr      x8, [x19]
03c24c54: e00313aa mov      x0, x19
03c24c58: 096542f9 ldr      x9, [x8, #0x4c8]
03c24c5c: 016942f9 ldr      x1, [x8, #0x4d0]
03c24c60: 20013fd6 blr      x9
03c24c64: 1f040071 cmp      w0, #1
03c24c68: c1080054 b.ne     #0x3c24d80
03c24c6c: 680240f9 ldr      x8, [x19]
03c24c70: e00313aa mov      x0, x19
03c24c74: 09bd41f9 ldr      x9, [x8, #0x378]
03c24c78: 01c141f9 ldr      x1, [x8, #0x380]
03c24c7c: 20013fd6 blr      x9
03c24c80: e1031faa mov      x1, xzr
03c24c84: 417fdd97 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03c24c88: 685e40f9 ldr      x8, [x19, #0xb8]
03c24c8c: e80800b4 cbz      x8, #0x3c24da8
03c24c90: f503002a mov      w21, w0
03c24c94: e00308aa mov      x0, x8
03c24c98: 45000094 bl       #0x3c24dac ; Royal.Scenes.Game.Mechanics.Items.UfoItem.View.UfoCollectHelper$$GetUfoCount
03c24c9c: a80e0011 add      w8, w21, #3
03c24ca0: bf020071 cmp      w21, #0
03c24ca4: 08b1951a csel     w8, w8, w21, lt
03c24ca8: 087d0213 asr      w8, w8, #2
03c24cac: 09040051 sub      w9, w0, #1
03c24cb0: 357d081b mul      w21, w9, w8
03c24cb4: 34000014 b        #0x3c24d84
03c24cb8: e0031f2a mov      w0, wzr
03c24cbc: 37000014 b        #0x3c24d98
03c24cc0: e0031faa mov      x0, xzr
03c24cc4: 12650394 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
03c24cc8: 68ce40b9 ldr      w8, [x19, #0xcc]
03c24ccc: 1f00086b cmp      w0, w8
03c24cd0: 00020054 b.eq     #0x3c24d10
03c24cd4: 755e40f9 ldr      x21, [x19, #0xb8]
03c24cd8: e00313aa mov      x0, x19
03c24cdc: e1031faa mov      x1, xzr
03c24ce0: 6d78dd97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
03c24ce4: 200600b4 cbz      x0, #0x3c24da8
03c24ce8: e1031faa mov      x1, xzr
03c24cec: 4591ba97 bl       #0x2ac9200 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetBoardAdjustedPoint
03c24cf0: d50500b4 cbz      x21, #0x3c24da8
03c24cf4: e20300aa mov      x2, x0
03c24cf8: e00315aa mov      x0, x21
03c24cfc: e103142a mov      w1, w20
03c24d00: 3d000094 bl       #0x3c24df4 ; Royal.Scenes.Game.Mechanics.Items.UfoItem.View.UfoCollectHelper$$UpdateExtraScoreCache
03c24d04: e0031faa mov      x0, xzr
03c24d08: 01650394 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
03c24d0c: 60ce00b9 str      w0, [x19, #0xcc]
03c24d10: 605e40f9 ldr      x0, [x19, #0xb8]
03c24d14: a00400b4 cbz      x0, #0x3c24da8
03c24d18: 16a040b9 ldr      w22, [x0, #0xa0]
03c24d1c: 24000094 bl       #0x3c24dac ; Royal.Scenes.Game.Mechanics.Items.UfoItem.View.UfoCollectHelper$$GetUfoCount
03c24d20: 683240f9 ldr      x8, [x19, #0x60]
03c24d24: 280400b4 cbz      x8, #0x3c24da8
03c24d28: f503002a mov      w21, w0
03c24d2c: 01068052 mov      w1, #0x30
03c24d30: e00308aa mov      x0, x8
03c24d34: e2031f2a mov      w2, wzr
03c24d38: e3031faa mov      x3, xzr
03c24d3c: de27b897 bl       #0x2a2ecb4 ; Royal.Scenes.Game.Levels.Units.GoalManager$$GetGoalLeftCount
03c24d40: a802004b sub      w8, w21, w0
03c24d44: 1501162b adds     w21, w8, w22
03c24d48: c4010054 b.mi     #0x3c24d80
03c24d4c: 680240f9 ldr      x8, [x19]
03c24d50: e00313aa mov      x0, x19
03c24d54: 09bd41f9 ldr      x9, [x8, #0x378]
03c24d58: 01c141f9 ldr      x1, [x8, #0x380]
03c24d5c: 20013fd6 blr      x9
03c24d60: e1031faa mov      x1, xzr
03c24d64: 097fdd97 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03c24d68: 080c0011 add      w8, w0, #3
03c24d6c: 1f000071 cmp      w0, #0
03c24d70: 08b1801a csel     w8, w8, w0, lt
03c24d74: 087d0213 asr      w8, w8, #2
03c24d78: 157d151b mul      w21, w8, w21
03c24d7c: 02000014 b        #0x3c24d84
03c24d80: f5031f2a mov      w21, wzr
03c24d84: e00313aa mov      x0, x19
03c24d88: e103142a mov      w1, w20
03c24d8c: e2031faa mov      x2, xzr
03c24d90: f77edd97 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
03c24d94: 0000150b add      w0, w0, w21
03c24d98: f37b42a9 ldp      x19, x30, [sp, #0x20]
03c24d9c: f55341a9 ldp      x21, x20, [sp, #0x10]
03c24da0: f60743f8 ldr      x22, [sp], #0x30
03c24da4: c0035fd6 ret      
03c24da8: a0314e97 bl       #0xfb1428
