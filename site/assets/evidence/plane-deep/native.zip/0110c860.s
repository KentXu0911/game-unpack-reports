# Royal.Scenes.Game.Mechanics.Items.StaticItems.WaterItem.WaterItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0110c860: e0031f2a mov      w0, wzr
0110c864: c0035fd6 ret      
