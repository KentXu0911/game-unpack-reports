# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerTntStrategy$$GetGameOperationType
# Linear span to next metadata entry; not a complete CFG.
033a48f0: 20018052 mov      w0, #9
033a48f4: c0035fd6 ret      
