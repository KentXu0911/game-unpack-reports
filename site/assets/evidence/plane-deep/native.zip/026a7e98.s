# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$MapAreas
# Linear span to next metadata entry; not a complete CFG.
026a7e98: c0035fd6 ret      
