# Royal.Scenes.Game.Mechanics.Items.ShuttleItem.ShuttleItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0216c6bc: e0031f2a mov      w0, wzr
0216c6c0: c0035fd6 ret      
