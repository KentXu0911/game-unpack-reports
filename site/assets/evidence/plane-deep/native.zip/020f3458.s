# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$CalculateHighestNegativeScoreForRocket
# Linear span to next metadata entry; not a complete CFG.
020f3458: fb6bbba9 stp      x27, x26, [sp, #-0x50]!
020f345c: f96301a9 stp      x25, x24, [sp, #0x10]
020f3460: f75b02a9 stp      x23, x22, [sp, #0x20]
020f3464: f55303a9 stp      x21, x20, [sp, #0x30]
020f3468: f37b04a9 stp      x19, x30, [sp, #0x40]
020f346c: 58a401d0 adrp     x24, #0x557d000
020f3470: 083b5539 ldrb     w8, [x24, #0x54e]
020f3474: f30305aa mov      x19, x5
020f3478: f40304aa mov      x20, x4
020f347c: f50303aa mov      x21, x3
020f3480: f60302aa mov      x22, x2
020f3484: f703012a mov      w23, w1
020f3488: c8000037 tbnz     w8, #0, #0x20f34a0
020f348c: 008501b0 adrp     x0, #0x5194000
020f3490: 007842f9 ldr      x0, [x0, #0x4f0]
020f3494: 9bf7ba97 bl       #0xfb1300
020f3498: 28008052 mov      w8, #1
020f349c: 083b1539 strb     w8, [x24, #0x54e]
020f34a0: 0800b052 mov      w8, #-0x80000000
020f34a4: 880200b9 str      w8, [x20]
020f34a8: 760500b4 cbz      x22, #0x20f3554
020f34ac: c80e40f9 ldr      x8, [x22, #0x18]
020f34b0: 1f050071 cmp      w8, #1
020f34b4: 0b040054 b.lt     #0x20f3534
020f34b8: 198501b0 adrp     x25, #0x5194000
020f34bc: 397b42f9 ldr      x25, [x25, #0x4f0]
020f34c0: f8031faa mov      x24, xzr
020f34c4: 087d4092 and      x8, x8, #0xffffffff
020f34c8: da820091 add      x26, x22, #0x20
020f34cc: bb820091 add      x27, x21, #0x20
020f34d0: 350400b4 cbz      x21, #0x20f3554
020f34d4: a91a40b9 ldr      w9, [x21, #0x18]
020f34d8: 1f0309eb cmp      x24, x9
020f34dc: a2030054 b.hs     #0x20f3550
020f34e0: 696b7838 ldrb     w9, [x27, x24]
020f34e4: 09020034 cbz      w9, #0x20f3524
020f34e8: f30000b4 cbz      x19, #0x20f3504
020f34ec: 220340f9 ldr      x2, [x25]
020f34f0: e00313aa mov      x0, x19
020f34f4: e103182a mov      w1, w24
020f34f8: 7c9af497 bl       #0x1e19ee8 ; System.Collections.Generic.List<int>$$Contains
020f34fc: 40010037 tbnz     w0, #0, #0x20f3524
020f3500: c81a40b9 ldr      w8, [x22, #0x18]
020f3504: 1f4328eb cmp      x24, w8, uxtw
020f3508: 42020054 b.hs     #0x20f3550
020f350c: 487b78b8 ldr      w8, [x26, x24, lsl #2]
020f3510: 890240b9 ldr      w9, [x20]
020f3514: 1f01096b cmp      w8, w9
020f3518: 6d000054 b.le     #0x20f3524
020f351c: f703182a mov      w23, w24
020f3520: 880200b9 str      w8, [x20]
020f3524: c81a40b9 ldr      w8, [x22, #0x18]
020f3528: 18070091 add      x24, x24, #1
020f352c: 1fc328eb cmp      x24, w8, sxtw
020f3530: 0bfdff54 b.lt     #0x20f34d0
020f3534: e003172a mov      w0, w23
020f3538: f37b44a9 ldp      x19, x30, [sp, #0x40]
020f353c: f55343a9 ldp      x21, x20, [sp, #0x30]
020f3540: f75b42a9 ldp      x23, x22, [sp, #0x20]
020f3544: f96341a9 ldp      x25, x24, [sp, #0x10]
020f3548: fb6bc5a8 ldp      x27, x26, [sp], #0x50
020f354c: c0035fd6 ret      
020f3550: b8f7ba97 bl       #0xfb1430
020f3554: b5f7ba97 bl       #0xfb1428
