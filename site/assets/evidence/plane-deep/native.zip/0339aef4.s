# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339aef4: e1031faa mov      x1, xzr
0339aef8: bf61bb17 b        #0x22735f4 ; System.Object$$.ctor
