# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$.ctor
# Linear span to next metadata entry; not a complete CFG.
03397f68: e1031faa mov      x1, xzr
03397f6c: eeb8ff17 b        #0x3386324 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemAssets$$.ctor
