# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeScaleDown
# Linear span to next metadata entry; not a complete CFG.
0339fa50: ff4301d1 sub      sp, sp, #0x50
0339fa54: eb2b016d stp      d11, d10, [sp, #0x10]
0339fa58: e923026d stp      d9, d8, [sp, #0x20]
0339fa5c: f55303a9 stp      x21, x20, [sp, #0x30]
0339fa60: f37b04a9 stp      x19, x30, [sp, #0x40]
0339fa64: b50e01f0 adrp     x21, #0x5576000
0339fa68: 142c40f9 ldr      x20, [x0, #0x58]
0339fa6c: a8a27c39 ldrb     w8, [x21, #0xf28]
0339fa70: 087040bd ldr      s8, [x0, #0x70]
0339fa74: 01102e1e fmov     s1, #1.00000000
0339fa78: 0158211e fmin     s1, s0, s1
0339fa7c: 0820201e fcmp     s0, #0.0
0339fa80: e903271e fmov     s9, wzr
0339fa84: f30300aa mov      x19, x0
0339fa88: 2a5c291e fcsel    s10, s1, s9, pl
0339fa8c: c8000035 cbnz     w8, #0x339faa4
0339fa90: 60f40090 adrp     x0, #0x522b000
0339fa94: 00ac43f9 ldr      x0, [x0, #0x758]
0339fa98: 1a467097 bl       #0xfb1300
0339fa9c: 28008052 mov      w8, #1
0339faa0: a8a23c39 strb     w8, [x21, #0xf28]
0339faa4: b40900b4 cbz      x20, #0x339fbd8
0339faa8: 75f40090 adrp     x21, #0x522b000
0339faac: b5ae43f9 ldr      x21, [x21, #0x758]
0339fab0: a9560090 adrp     x9, #0x3e73000
0339fab4: 20ed48bd ldr      s0, [x9, #0x8ec]
0339fab8: 4749291e fmax     s7, s10, s9
0339fabc: a80240f9 ldr      x8, [x21]
0339fac0: e00314aa mov      x0, x20
0339fac4: e1031faa mov      x1, xzr
0339fac8: 085d40f9 ldr      x8, [x8, #0xb8]
0339facc: 018d412d ldp      s1, s3, [x8, #0xc]
0339fad0: 0291412d ldp      s2, s4, [x8, #0xc]
0339fad4: 061540bd ldr      s6, [x8, #0x14]
0339fad8: 051540bd ldr      s5, [x8, #0x14]
0339fadc: 0109211e fmul     s1, s8, s1
0339fae0: 4208201e fmul     s2, s2, s0
0339fae4: 8408201e fmul     s4, s4, s0
0339fae8: c608201e fmul     s6, s6, s0
0339faec: 4038211e fsub     s0, s2, s1
0339faf0: 0309231e fmul     s3, s8, s3
0339faf4: 0509251e fmul     s5, s8, s5
0339faf8: e008201e fmul     s0, s7, s0
0339fafc: 2028201e fadd     s0, s1, s0
0339fb00: 8138231e fsub     s1, s4, s3
0339fb04: c238251e fsub     s2, s6, s5
0339fb08: e108211e fmul     s1, s7, s1
0339fb0c: e208221e fmul     s2, s7, s2
0339fb10: 6128211e fadd     s1, s3, s1
0339fb14: a228221e fadd     s2, s5, s2
0339fb18: e703803d str      q7, [sp]
0339fb1c: 42aa2594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
0339fb20: b40e01f0 adrp     x20, #0x5576000
0339fb24: 684243fc ldur     d8, [x19, #0x34]
0339fb28: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339fb2c: 693e40bd ldr      s9, [x19, #0x3c]
0339fb30: c8000035 cbnz     w8, #0x339fb48
0339fb34: 60f40090 adrp     x0, #0x522b000
0339fb38: 00ac43f9 ldr      x0, [x0, #0x758]
0339fb3c: f1457097 bl       #0xfb1300
0339fb40: 28008052 mov      w8, #1
0339fb44: 88b23c39 strb     w8, [x20, #0xf2c]
0339fb48: 682a40f9 ldr      x8, [x19, #0x50]
0339fb4c: 680400b4 cbz      x8, #0x339fbd8
0339fb50: 004140f9 ldr      x0, [x8, #0x80]
0339fb54: 200400b4 cbz      x0, #0x339fbd8
0339fb58: a80240f9 ldr      x8, [x21]
0339fb5c: e1031faa mov      x1, xzr
0339fb60: 085d40f9 ldr      x8, [x8, #0xb8]
0339fb64: 0b0140fd ldr      d11, [x8]
0339fb68: 0a0940bd ldr      s10, [x8, #8]
0339fb6c: 8f8c2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339fb70: 682e40f9 ldr      x8, [x19, #0x58]
0339fb74: 280300b4 cbz      x8, #0x339fbd8
0339fb78: f30300aa mov      x19, x0
0339fb7c: e00308aa mov      x0, x8
0339fb80: e1031faa mov      x1, xzr
0339fb84: 5ca82594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339fb88: 930200b4 cbz      x19, #0x339fbd8
0339fb8c: e503c03d ldr      q5, [sp]
0339fb90: 63d5a80e fsub     v3.2s, v11.2s, v8.2s
0339fb94: 4439291e fsub     s4, s10, s9
0339fb98: 20040c6e mov      v0.s[1], v1.s[0]
0339fb9c: 6190850f fmul     v1.2s, v3.2s, v5.s[0]
0339fba0: a308241e fmul     s3, s5, s4
0339fba4: 01d5210e fadd     v1.2s, v8.2s, v1.2s
0339fba8: 2329231e fadd     s3, s9, s3
0339fbac: e00313aa mov      x0, x19
0339fbb0: f37b44a9 ldp      x19, x30, [sp, #0x40]
0339fbb4: f55343a9 ldp      x21, x20, [sp, #0x30]
0339fbb8: e923426d ldp      d9, d8, [sp, #0x20]
0339fbbc: eb2b416d ldp      d11, d10, [sp, #0x10]
0339fbc0: 20d4200e fadd     v0.2s, v1.2s, v0.2s
0339fbc4: 6228221e fadd     s2, s3, s2
0339fbc8: 01040c5e mov      s1, v0.s[1]
0339fbcc: e1031faa mov      x1, xzr
0339fbd0: ff430191 add      sp, sp, #0x50
0339fbd4: 70a82514 b        #0x3d09d94 ; UnityEngine.Transform$$set_position
0339fbd8: 14467097 bl       #0xfb1428
