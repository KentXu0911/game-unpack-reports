# Royal.Scenes.Game.Mechanics.Items.RoyalCapsuleHorizontalItem.RoyalCapsuleHorizontalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01ecd21c: f553bea9 stp      x21, x20, [sp, #-0x20]!
01ecd220: f37b01a9 stp      x19, x30, [sp, #0x10]
01ecd224: 75b501f0 adrp     x21, #0x557c000
01ecd228: 74970190 adrp     x20, #0x51b9000
01ecd22c: a8f65539 ldrb     w8, [x21, #0x57d]
01ecd230: 947245f9 ldr      x20, [x20, #0xae0]
01ecd234: f30300aa mov      x19, x0
01ecd238: c8000037 tbnz     w8, #0, #0x1ecd250
01ecd23c: 60970190 adrp     x0, #0x51b9000
01ecd240: 007045f9 ldr      x0, [x0, #0xae0]
01ecd244: 2f90c397 bl       #0xfb1300
01ecd248: 28008052 mov      w8, #1
01ecd24c: a8f61539 strb     w8, [x21, #0x57d]
01ecd250: 800240f9 ldr      x0, [x20]
01ecd254: 08e040b9 ldr      w8, [x0, #0xe0]
01ecd258: 48000035 cbnz     w8, #0x1ecd260
01ecd25c: 6a90c397 bl       #0xfb1404
01ecd260: 55b501d0 adrp     x21, #0x5577000
01ecd264: a84e7d39 ldrb     w8, [x21, #0xf53]
01ecd268: c8000035 cbnz     w8, #0x1ecd280
01ecd26c: 60970190 adrp     x0, #0x51b9000
01ecd270: 007045f9 ldr      x0, [x0, #0xae0]
01ecd274: 2390c397 bl       #0xfb1300
01ecd278: 28008052 mov      w8, #1
01ecd27c: a84e3d39 strb     w8, [x21, #0xf53]
01ecd280: 800240f9 ldr      x0, [x20]
01ecd284: 08e040b9 ldr      w8, [x0, #0xe0]
01ecd288: 68000035 cbnz     w8, #0x1ecd294
01ecd28c: 5e90c397 bl       #0xfb1404
01ecd290: 800240f9 ldr      x0, [x20]
01ecd294: 085c40f9 ldr      x8, [x0, #0xb8]
01ecd298: 00229f52 mov      w0, #0xf910
01ecd29c: c000a072 movk     w0, #6, lsl #16
01ecd2a0: 08514039 ldrb     w8, [x8, #0x14]
01ecd2a4: 48020035 cbnz     w8, #0x1ecd2ec
01ecd2a8: 686a40b9 ldr      w8, [x19, #0x68]
01ecd2ac: 1f050071 cmp      w8, #1
01ecd2b0: a1010054 b.ne     #0x1ecd2e4
01ecd2b4: 68ae40f9 ldr      x8, [x19, #0x158]
01ecd2b8: 280200b4 cbz      x8, #0x1ecd2fc
01ecd2bc: 091940b9 ldr      w9, [x8, #0x18]
01ecd2c0: c9010034 cbz      w9, #0x1ecd2f8
01ecd2c4: 0a2140b9 ldr      w10, [x8, #0x20]
01ecd2c8: 5fc90071 cmp      w10, #0x32
01ecd2cc: 00010054 b.eq     #0x1ecd2ec
01ecd2d0: 3f050071 cmp      w9, #1
01ecd2d4: 29010054 b.ls     #0x1ecd2f8
01ecd2d8: 082540b9 ldr      w8, [x8, #0x24]
01ecd2dc: 1fc90071 cmp      w8, #0x32
01ecd2e0: 60000054 b.eq     #0x1ecd2ec
01ecd2e4: 209f8952 mov      w0, #0x4cf9
01ecd2e8: 4000a072 movk     w0, #2, lsl #16
01ecd2ec: f37b41a9 ldp      x19, x30, [sp, #0x10]
01ecd2f0: f553c2a8 ldp      x21, x20, [sp], #0x20
01ecd2f4: c0035fd6 ret      
01ecd2f8: 4e90c397 bl       #0xfb1430
01ecd2fc: 4b90c397 bl       #0xfb1428
