# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$TryRedirectForPowerCubeWinCondition
# Linear span to next metadata entry; not a complete CFG.
033a30e0: f40f1ef8 str      x20, [sp, #-0x20]!
033a30e4: f37b01a9 stp      x19, x30, [sp, #0x10]
033a30e8: 140f01f0 adrp     x20, #0x5586000
033a30ec: 88366739 ldrb     w8, [x20, #0x9cd]
033a30f0: f30300aa mov      x19, x0
033a30f4: 28010037 tbnz     w8, #0, #0x33a3118
033a30f8: c0f100f0 adrp     x0, #0x51de000
033a30fc: 005440f9 ldr      x0, [x0, #0xa8]
033a3100: 80387097 bl       #0xfb1300
033a3104: 00f100f0 adrp     x0, #0x51c6000
033a3108: 00f045f9 ldr      x0, [x0, #0xbe0]
033a310c: 7d387097 bl       #0xfb1300
033a3110: 28008052 mov      w8, #1
033a3114: 88362739 strb     w8, [x20, #0x9cd]
033a3118: 600a40f9 ldr      x0, [x19, #0x10]
033a311c: 800200b4 cbz      x0, #0x33a316c
033a3120: a10a8052 mov      w1, #0x55
033a3124: e2031faa mov      x2, xzr
033a3128: 89deb297 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
033a312c: 80010036 tbz      w0, #0, #0x33a315c
033a3130: c8f100f0 adrp     x8, #0x51de000
033a3134: 085540f9 ldr      x8, [x8, #0xa8]
033a3138: a00a8052 mov      w0, #0x55
033a313c: 010140f9 ldr      x1, [x8]
033a3140: 4b6ec697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a3144: 400100b4 cbz      x0, #0x33a316c
033a3148: e1031faa mov      x1, xzr
033a314c: bf43aa97 bl       #0x1e34048 ; Royal.Scenes.Game.Mechanics.Items.PowerCubeItem.PowerCubeItemHelper$$TryGetLastGroupsPowerCubeCellPointWithOneLayer
033a3150: 1f1c0072 tst      w0, #0xff
033a3154: e0079f1a cset     w0, ne
033a3158: 02000014 b        #0x33a3160
033a315c: e0031f2a mov      w0, wzr
033a3160: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a3164: f40742f8 ldr      x20, [sp], #0x20
033a3168: c0035fd6 ret      
033a316c: af387097 bl       #0xfb1428
