# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerRocketComboParticlePrefab
# Linear span to next metadata entry; not a complete CFG.
03397c14: f40f1ef8 str      x20, [sp, #-0x20]!
03397c18: f37b01a9 stp      x19, x30, [sp, #0x10]
03397c1c: 740f01f0 adrp     x20, #0x5586000
03397c20: 88426639 ldrb     w8, [x20, #0x990]
03397c24: f30300aa mov      x19, x0
03397c28: c8000037 tbnz     w8, #0, #0x3397c40
03397c2c: 20f200f0 adrp     x0, #0x51de000
03397c30: 005c40f9 ldr      x0, [x0, #0xb8]
03397c34: b3657097 bl       #0xfb1300
03397c38: 28008052 mov      w8, #1
03397c3c: 88422639 strb     w8, [x20, #0x990]
03397c40: 680e40f9 ldr      x8, [x19, #0x18]
03397c44: e80200b4 cbz      x8, #0x3397ca0
03397c48: 091940b9 ldr      w9, [x8, #0x18]
03397c4c: 3f0d0071 cmp      w9, #3
03397c50: a9020054 b.ls     #0x3397ca4
03397c54: 001d40f9 ldr      x0, [x8, #0x38]
03397c58: c00100b4 cbz      x0, #0x3397c90
03397c5c: 29f200f0 adrp     x9, #0x51de000
03397c60: 295d40f9 ldr      x9, [x9, #0xb8]
03397c64: 080040f9 ldr      x8, [x0]
03397c68: 210140f9 ldr      x1, [x9]
03397c6c: 0ab14439 ldrb     w10, [x8, #0x12c]
03397c70: 29b04439 ldrb     w9, [x1, #0x12c]
03397c74: 5f01096b cmp      w10, w9
03397c78: 23010054 b.lo     #0x3397c9c
03397c7c: 086540f9 ldr      x8, [x8, #0xc8]
03397c80: 080d098b add      x8, x8, x9, lsl #3
03397c84: 08815ff8 ldur     x8, [x8, #-8]
03397c88: 1f0101eb cmp      x8, x1
03397c8c: 81000054 b.ne     #0x3397c9c
03397c90: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397c94: f40742f8 ldr      x20, [sp], #0x20
03397c98: c0035fd6 ret      
03397c9c: c9667097 bl       #0xfb17c0
03397ca0: e2657097 bl       #0xfb1428
03397ca4: e3657097 bl       #0xfb1430
