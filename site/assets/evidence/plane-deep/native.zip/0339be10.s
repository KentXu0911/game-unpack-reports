# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeRootPositions
# Linear span to next metadata entry; not a complete CFG.
0339be10: ff4302d1 sub      sp, sp, #0x90
0339be14: ef3b026d stp      d15, d14, [sp, #0x20]
0339be18: ed33036d stp      d13, d12, [sp, #0x30]
0339be1c: eb2b046d stp      d11, d10, [sp, #0x40]
0339be20: e923056d stp      d9, d8, [sp, #0x50]
0339be24: f75b06a9 stp      x23, x22, [sp, #0x60]
0339be28: f55307a9 stp      x21, x20, [sp, #0x70]
0339be2c: f37b08a9 stp      x19, x30, [sp, #0x80]
0339be30: f30300aa mov      x19, x0
0339be34: c1000036 tbz      w1, #0, #0x339be4c
0339be38: 68aa40b9 ldr      w8, [x19, #0xa8]
0339be3c: 09050011 add      w9, w8, #1
0339be40: 1f290071 cmp      w8, #0xa
0339be44: 69aa00b9 str      w9, [x19, #0xa8]
0339be48: cb1a0054 b.lt     #0x339c1a0
0339be4c: 693240f9 ldr      x9, [x19, #0x60]
0339be50: a91b00b4 cbz      x9, #0x339c1c4
0339be54: 686a40f9 ldr      x8, [x19, #0xd0]
0339be58: 681b00b4 cbz      x8, #0x339c1c4
0339be5c: 351140f9 ldr      x21, [x9, #0x20]
0339be60: 351b00b4 cbz      x21, #0x339c1c4
0339be64: 141140f9 ldr      x20, [x8, #0x20]
0339be68: e00315aa mov      x0, x21
0339be6c: e1031faa mov      x1, xzr
0339be70: 7145f597 bl       #0x30ed434 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$GetPosition
0339be74: e287012d stp      s2, s1, [sp, #0xc]
0339be78: 741a00b4 cbz      x20, #0x339c1c4
0339be7c: e00314aa mov      x0, x20
0339be80: e1031faa mov      x1, xzr
0339be84: 0a1ca04e mov      v10.16b, v0.16b
0339be88: 6b45f597 bl       #0x30ed434 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$GetPosition
0339be8c: 0b1ca04e mov      v11.16b, v0.16b
0339be90: 40c1201e fabs     s0, s10
0339be94: 0028201e fadd     s0, s0, s0
0339be98: e0031faa mov      x0, xzr
0339be9c: 281ca14e mov      v8.16b, v1.16b
0339bea0: 491ca24e mov      v9.16b, v2.16b
0339bea4: b5b9fb97 bl       #0x328a578 ; Royal.Infrastructure.Utils.Animation.ManualEasing.Quintic$$In
0339bea8: 01102e1e fmov     s1, #1.00000000
0339beac: 0820201e fcmp     s0, #0.0
0339beb0: e203271e fmov     s2, wzr
0339beb4: 285900d0 adrp     x8, #0x3ec1000
0339beb8: 0058211e fmin     s0, s0, s1
0339bebc: 034140bd ldr      s3, [x8, #0x40]
0339bec0: 68560090 adrp     x8, #0x3e67000
0339bec4: 0590311e fmov     s5, #-3.50000000
0339bec8: 005c221e fcsel    s0, s0, s2, pl
0339becc: 049144bd ldr      s4, [x8, #0x490]
0339bed0: 68560090 adrp     x8, #0x3e67000
0339bed4: 0210221e fmov     s2, #4.00000000
0339bed8: 0508251e fmul     s5, s0, s5
0339bedc: ae28221e fadd     s14, s5, s2
0339bee0: 028d44bd ldr      s2, [x8, #0x48c]
0339bee4: 68124339 ldrb     w8, [x19, #0xc4]
0339bee8: 0008231e fmul     s0, s0, s3
0339beec: 8c38201e fsub     s12, s4, s0
0339bef0: 0d28221e fadd     s13, s0, s2
0339bef4: 00103e1e fmov     s0, #-1.00000000
0339bef8: 1f010071 cmp      w8, #0
0339befc: e0031faa mov      x0, xzr
0339bf00: 6ec200bd str      s14, [x19, #0xc0]
0339bf04: 0f0c211e fcsel    s15, s0, s1, eq
0339bf08: 37882594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339bf0c: d70e01f0 adrp     x23, #0x5576000
0339bf10: e8a27c39 ldrb     w8, [x23, #0xf28]
0339bf14: 76164339 ldrb     w22, [x19, #0xc5]
0339bf18: 00082e1e fmul     s0, s0, s14
0339bf1c: e009201e fmul     s0, s15, s0
0339bf20: 4a29201e fadd     s10, s10, s0
0339bf24: 6b39201e fsub     s11, s11, s0
0339bf28: c8000035 cbnz     w8, #0x339bf40
0339bf2c: 80f40090 adrp     x0, #0x522b000
0339bf30: 00ac43f9 ldr      x0, [x0, #0x758]
0339bf34: f3547097 bl       #0xfb1300
0339bf38: 28008052 mov      w8, #1
0339bf3c: e8a23c39 strb     w8, [x23, #0xf28]
0339bf40: 88f40090 adrp     x8, #0x522b000
0339bf44: 08ad43f9 ldr      x8, [x8, #0x758]
0339bf48: df020071 cmp      w22, #0
0339bf4c: 800d2d1e fcsel    s0, s12, s13, eq
0339bf50: a40d2c1e fcsel    s4, s13, s12, eq
0339bf54: 080140f9 ldr      x8, [x8]
0339bf58: e00315aa mov      x0, x21
0339bf5c: e1031faa mov      x1, xzr
0339bf60: 085d40f9 ldr      x8, [x8, #0xb8]
0339bf64: 0189412d ldp      s1, s2, [x8, #0xc]
0339bf68: 031540bd ldr      s3, [x8, #0x14]
0339bf6c: ea1f00bd str      s10, [sp, #0x1c]
0339bf70: 0c08211e fmul     s12, s0, s1
0339bf74: 0508221e fmul     s5, s0, s2
0339bf78: 2f08241e fmul     s15, s1, s4
0339bf7c: 4e08241e fmul     s14, s2, s4
0339bf80: e287412d ldp      s2, s1, [sp, #0xc]
0339bf84: 0008231e fmul     s0, s0, s3
0339bf88: e097022d stp      s0, s5, [sp, #0x14]
0339bf8c: 401daa4e mov      v0.16b, v10.16b
0339bf90: 6d08241e fmul     s13, s3, s4
0339bf94: 2f45f597 bl       #0x30ed450 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$SetPosition
0339bf98: e00314aa mov      x0, x20
0339bf9c: 601dab4e mov      v0.16b, v11.16b
0339bfa0: 011da84e mov      v1.16b, v8.16b
0339bfa4: 221da94e mov      v2.16b, v9.16b
0339bfa8: e1031faa mov      x1, xzr
0339bfac: 2945f597 bl       #0x30ed450 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$SetPosition
0339bfb0: 686e4339 ldrb     w8, [x19, #0xdb]
0339bfb4: a8060034 cbz      w8, #0x339c088
0339bfb8: e00315aa mov      x0, x21
0339bfbc: e1031faa mov      x1, xzr
0339bfc0: 2b45f597 bl       #0x30ed46c ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$GetScale
0339bfc4: e0031faa mov      x0, xzr
0339bfc8: 081ca04e mov      v8.16b, v0.16b
0339bfcc: 291ca14e mov      v9.16b, v1.16b
0339bfd0: 4a1ca24e mov      v10.16b, v2.16b
0339bfd4: 76720391 add      x22, x19, #0xdc
0339bfd8: 03882594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339bfdc: 08f0af52 mov      w8, #0x7f800000
0339bfe0: eb1300bd str      s11, [sp, #0x10]
0339bfe4: 0b01271e fmov     s11, w8
0339bfe8: 06102c1e fmov     s6, #0.50000000
0339bfec: e00300bd str      s0, [sp]
0339bff0: 001da84e mov      v0.16b, v8.16b
0339bff4: 211da94e mov      v1.16b, v9.16b
0339bff8: 421daa4e mov      v2.16b, v10.16b
0339bffc: e31daf4e mov      v3.16b, v15.16b
0339c000: c41dae4e mov      v4.16b, v14.16b
0339c004: a51dad4e mov      v5.16b, v13.16b
0339c008: e00316aa mov      x0, x22
0339c00c: 671dab4e mov      v7.16b, v11.16b
0339c010: e1031faa mov      x1, xzr
0339c014: 74b40594 bl       #0x35091e4 ; UnityEngine.Vector3$$SmoothDamp
0339c018: e00314aa mov      x0, x20
0339c01c: e1031faa mov      x1, xzr
0339c020: 0f1ca04e mov      v15.16b, v0.16b
0339c024: 2e1ca14e mov      v14.16b, v1.16b
0339c028: 4d1ca24e mov      v13.16b, v2.16b
0339c02c: 1045f597 bl       #0x30ed46c ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$GetScale
0339c030: e0031faa mov      x0, xzr
0339c034: 081ca04e mov      v8.16b, v0.16b
0339c038: 291ca14e mov      v9.16b, v1.16b
0339c03c: 4a1ca24e mov      v10.16b, v2.16b
0339c040: 76a20391 add      x22, x19, #0xe8
0339c044: e8872594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339c048: e593422d ldp      s5, s4, [sp, #0x14]
0339c04c: 671dab4e mov      v7.16b, v11.16b
0339c050: eb1340bd ldr      s11, [sp, #0x10]
0339c054: e00300bd str      s0, [sp]
0339c058: 001da84e mov      v0.16b, v8.16b
0339c05c: 211da94e mov      v1.16b, v9.16b
0339c060: 421daa4e mov      v2.16b, v10.16b
0339c064: 831dac4e mov      v3.16b, v12.16b
0339c068: e00316aa mov      x0, x22
0339c06c: 06102c1e fmov     s6, #0.50000000
0339c070: e1031faa mov      x1, xzr
0339c074: 5cb40594 bl       #0x35091e4 ; UnityEngine.Vector3$$SmoothDamp
0339c078: 0c1ca04e mov      v12.16b, v0.16b
0339c07c: 291ca14e mov      v9.16b, v1.16b
0339c080: 481ca24e mov      v8.16b, v2.16b
0339c084: 02000014 b        #0x339c08c
0339c088: e8a7422d ldp      s8, s9, [sp, #0x14]
0339c08c: e00315aa mov      x0, x21
0339c090: e01daf4e mov      v0.16b, v15.16b
0339c094: c11dae4e mov      v1.16b, v14.16b
0339c098: a21dad4e mov      v2.16b, v13.16b
0339c09c: e1031faa mov      x1, xzr
0339c0a0: fa44f597 bl       #0x30ed488 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$SetScale
0339c0a4: e00314aa mov      x0, x20
0339c0a8: 801dac4e mov      v0.16b, v12.16b
0339c0ac: 211da94e mov      v1.16b, v9.16b
0339c0b0: 021da84e mov      v2.16b, v8.16b
0339c0b4: e1031faa mov      x1, xzr
0339c0b8: f444f597 bl       #0x30ed488 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$SetScale
0339c0bc: 88580090 adrp     x8, #0x3eac000
0339c0c0: 60be40bd ldr      s0, [x19, #0xbc]
0339c0c4: 019941bd ldr      s1, [x8, #0x198]
0339c0c8: 02102c1e fmov     s2, #0.50000000
0339c0cc: 4d1ca24e mov      v13.16b, v2.16b
0339c0d0: 6c29221e fadd     s12, s11, s2
0339c0d4: 0208211e fmul     s2, s0, s1
0339c0d8: e003271e fmov     s0, wzr
0339c0dc: e103271e fmov     s1, wzr
0339c0e0: e0031faa mov      x0, xzr
0339c0e4: 52a40594 bl       #0x350522c ; UnityEngine.Quaternion$$Internal_FromEulerRad
0339c0e8: 485600f0 adrp     x8, #0x3e67000
0339c0ec: 081ca04e mov      v8.16b, v0.16b
0339c0f0: 291ca14e mov      v9.16b, v1.16b
0339c0f4: 60be40bd ldr      s0, [x19, #0xbc]
0339c0f8: 015d44bd ldr      s1, [x8, #0x45c]
0339c0fc: 4a1ca24e mov      v10.16b, v2.16b
0339c100: e0031faa mov      x0, xzr
0339c104: 6b1ca34e mov      v11.16b, v3.16b
0339c108: 0208211e fmul     s2, s0, s1
0339c10c: e003271e fmov     s0, wzr
0339c110: e103271e fmov     s1, wzr
0339c114: 46a40594 bl       #0x350522c ; UnityEngine.Quaternion$$Internal_FromEulerRad
0339c118: 041ca04e mov      v4.16b, v0.16b
0339c11c: 251ca14e mov      v5.16b, v1.16b
0339c120: 461ca24e mov      v6.16b, v2.16b
0339c124: 671ca34e mov      v7.16b, v3.16b
0339c128: 001da84e mov      v0.16b, v8.16b
0339c12c: 211da94e mov      v1.16b, v9.16b
0339c130: 421daa4e mov      v2.16b, v10.16b
0339c134: 631dab4e mov      v3.16b, v11.16b
0339c138: e0031faa mov      x0, xzr
0339c13c: ec0300bd str      s12, [sp]
0339c140: b5a50594 bl       #0x3505814 ; UnityEngine.Quaternion$$Lerp
0339c144: e00314aa mov      x0, x20
0339c148: e1031faa mov      x1, xzr
0339c14c: d644f597 bl       #0x30ed4a4 ; Royal.Scenes.Game.Mechanics.Items.Config.RootTransform$$SetRotation
0339c150: e11f40bd ldr      s1, [sp, #0x1c]
0339c154: 68124339 ldrb     w8, [x19, #0xc4]
0339c158: 20202d1e fcmp     s1, s13
0339c15c: ab000054 b.lt     #0x339c170
0339c160: 88000034 cbz      w8, #0x339c170
0339c164: 68164339 ldrb     w8, [x19, #0xc5]
0339c168: 7f120339 strb     wzr, [x19, #0xc4]
0339c16c: 08000014 b        #0x339c18c
0339c170: 00103c1e fmov     s0, #-0.50000000
0339c174: 2020201e fcmp     s1, s0
0339c178: 48010054 b.hi     #0x339c1a0
0339c17c: 28010035 cbnz     w8, #0x339c1a0
0339c180: 68164339 ldrb     w8, [x19, #0xc5]
0339c184: 29008052 mov      w9, #1
0339c188: 69120339 strb     w9, [x19, #0xc4]
0339c18c: 08010052 eor      w8, w8, #1
0339c190: e00313aa mov      x0, x19
0339c194: 68160339 strb     w8, [x19, #0xc5]
0339c198: 7afeff97 bl       #0x339bb80 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeSorting
0339c19c: 7f6e0339 strb     wzr, [x19, #0xdb]
0339c1a0: f37b48a9 ldp      x19, x30, [sp, #0x80]
0339c1a4: f55347a9 ldp      x21, x20, [sp, #0x70]
0339c1a8: f75b46a9 ldp      x23, x22, [sp, #0x60]
0339c1ac: e923456d ldp      d9, d8, [sp, #0x50]
0339c1b0: eb2b446d ldp      d11, d10, [sp, #0x40]
0339c1b4: ed33436d ldp      d13, d12, [sp, #0x30]
0339c1b8: ef3b426d ldp      d15, d14, [sp, #0x20]
0339c1bc: ff430291 add      sp, sp, #0x90
0339c1c0: c0035fd6 ret      
0339c1c4: 99547097 bl       #0xfb1428
