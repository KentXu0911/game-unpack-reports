# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$StartFlying
# Linear span to next metadata entry; not a complete CFG.
033989ec: ed33ba6d stp      d13, d12, [sp, #-0x60]!
033989f0: eb2b016d stp      d11, d10, [sp, #0x10]
033989f4: e923026d stp      d9, d8, [sp, #0x20]
033989f8: f61b00f9 str      x22, [sp, #0x30]
033989fc: f55304a9 stp      x21, x20, [sp, #0x40]
03398a00: f37b05a9 stp      x19, x30, [sp, #0x50]
03398a04: 760f01d0 adrp     x22, #0x5586000
03398a08: c8766639 ldrb     w8, [x22, #0x99d]
03398a0c: f40302aa mov      x20, x2
03398a10: f50301aa mov      x21, x1
03398a14: f30300aa mov      x19, x0
03398a18: 28010037 tbnz     w8, #0, #0x3398a3c
03398a1c: a0f400f0 adrp     x0, #0x522f000
03398a20: 000445f9 ldr      x0, [x0, #0xa08]
03398a24: 37627097 bl       #0xfb1300
03398a28: e0f10090 adrp     x0, #0x51d4000
03398a2c: 00d841f9 ldr      x0, [x0, #0x3b0]
03398a30: 34627097 bl       #0xfb1300
03398a34: 28008052 mov      w8, #1
03398a38: c8762639 strb     w8, [x22, #0x99d]
03398a3c: 151200b4 cbz      x21, #0x3398c7c
03398a40: e8f10090 adrp     x8, #0x51d4000
03398a44: 08d941f9 ldr      x8, [x8, #0x3b0]
03398a48: a90240f9 ldr      x9, [x21]
03398a4c: 010140f9 ldr      x1, [x8]
03398a50: 2ab14439 ldrb     w10, [x9, #0x12c]
03398a54: 28b04439 ldrb     w8, [x1, #0x12c]
03398a58: 5f01086b cmp      w10, w8
03398a5c: c3100054 b.lo     #0x3398c74
03398a60: 2a6540f9 ldr      x10, [x9, #0xc8]
03398a64: 090500d1 sub      x9, x8, #1
03398a68: 4a7969f8 ldr      x10, [x10, x9, lsl #3]
03398a6c: 5f0101eb cmp      x10, x1
03398a70: 21100054 b.ne     #0x3398c74
03398a74: e00313aa mov      x0, x19
03398a78: 150c06f8 str      x21, [x0, #0x60]!
03398a7c: aa0240f9 ldr      x10, [x21]
03398a80: 4bb14439 ldrb     w11, [x10, #0x12c]
03398a84: 7f01086b cmp      w11, w8
03398a88: 630f0054 b.lo     #0x3398c74
03398a8c: 486540f9 ldr      x8, [x10, #0xc8]
03398a90: 087969f8 ldr      x8, [x8, x9, lsl #3]
03398a94: 1f0101eb cmp      x8, x1
03398a98: e10e0054 b.ne     #0x3398c74
03398a9c: e10315aa mov      x1, x21
03398aa0: 03627097 bl       #0xfb12ac
03398aa4: e00315aa mov      x0, x21
03398aa8: e1031faa mov      x1, xzr
03398aac: bfa82594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
03398ab0: e10300aa mov      x1, x0
03398ab4: f50313aa mov      x21, x19
03398ab8: a18e06f8 str      x1, [x21, #0x68]!
03398abc: e00315aa mov      x0, x21
03398ac0: fb617097 bl       #0xfb12ac
03398ac4: e00313aa mov      x0, x19
03398ac8: 140c07f8 str      x20, [x0, #0x70]!
03398acc: e10314aa mov      x1, x20
03398ad0: f7617097 bl       #0xfb12ac
03398ad4: 680240f9 ldr      x8, [x19]
03398ad8: e00313aa mov      x0, x19
03398adc: 092d41f9 ldr      x9, [x8, #0x258]
03398ae0: 013141f9 ldr      x1, [x8, #0x260]
03398ae4: 20013fd6 blr      x9
03398ae8: 607a00b9 str      w0, [x19, #0x78]
03398aec: 7f9200b9 str      wzr, [x19, #0x90]
03398af0: f40c00b4 cbz      x20, #0x3398c8c
03398af4: aaf400f0 adrp     x10, #0x522f000
03398af8: 880240f9 ldr      x8, [x20]
03398afc: 4a0545f9 ldr      x10, [x10, #0xa08]
03398b00: 09554279 ldrh     w9, [x8, #0x12a]
03398b04: 410140f9 ldr      x1, [x10]
03398b08: 290100b4 cbz      x9, #0x3398b2c
03398b0c: 0a5940f9 ldr      x10, [x8, #0xb0]
03398b10: 4a210091 add      x10, x10, #8
03398b14: 4b815ff8 ldur     x11, [x10, #-8]
03398b18: 7f0101eb cmp      x11, x1
03398b1c: 00010054 b.eq     #0x3398b3c
03398b20: 290500f1 subs     x9, x9, #1
03398b24: 4a410091 add      x10, x10, #0x10
03398b28: 61ffff54 b.ne     #0x3398b14
03398b2c: 22008052 mov      w2, #1
03398b30: e00314aa mov      x0, x20
03398b34: e8a16f97 bl       #0xf812d4
03398b38: 05000014 b        #0x3398b4c
03398b3c: 490140b9 ldr      w9, [x10]
03398b40: 29050011 add      w9, w9, #1
03398b44: 08d1298b add      x8, x8, w9, sxtw #4
03398b48: 00e10491 add      x0, x8, #0x138
03398b4c: 080440a9 ldp      x8, x1, [x0]
03398b50: e00314aa mov      x0, x20
03398b54: 00013fd6 blr      x8
03398b58: a00240f9 ldr      x0, [x21]
03398b5c: 800900b4 cbz      x0, #0x3398c8c
03398b60: e1031faa mov      x1, xzr
03398b64: 081ca04e mov      v8.16b, v0.16b
03398b68: 291ca14e mov      v9.16b, v1.16b
03398b6c: 4a1ca24e mov      v10.16b, v2.16b
03398b70: 61c42594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
03398b74: f40e01f0 adrp     x20, #0x5577000
03398b78: 88fa7f39 ldrb     w8, [x20, #0xffe]
03398b7c: 0b1ca04e mov      v11.16b, v0.16b
03398b80: 2c1ca14e mov      v12.16b, v1.16b
03398b84: 4d1ca24e mov      v13.16b, v2.16b
03398b88: c8000035 cbnz     w8, #0x3398ba0
03398b8c: 40f30090 adrp     x0, #0x5200000
03398b90: 008c46f9 ldr      x0, [x0, #0xd18]
03398b94: db617097 bl       #0xfb1300
03398b98: 28008052 mov      w8, #1
03398b9c: 88fa3f39 strb     w8, [x20, #0xffe]
03398ba0: 48f30090 adrp     x8, #0x5200000
03398ba4: 088d46f9 ldr      x8, [x8, #0xd18]
03398ba8: 0b392b1e fsub     s11, s8, s11
03398bac: 29392c1e fsub     s9, s9, s12
03398bb0: 48392d1e fsub     s8, s10, s13
03398bb4: 000140f9 ldr      x0, [x8]
03398bb8: 08e040b9 ldr      w8, [x0, #0xe0]
03398bbc: 48000035 cbnz     w8, #0x3398bc4
03398bc0: 11627097 bl       #0xfb1404
03398bc4: 60092b1e fmul     s0, s11, s11
03398bc8: 2109291e fmul     s1, s9, s9
03398bcc: c85600f0 adrp     x8, #0x3e73000
03398bd0: 0028211e fadd     s0, s0, s1
03398bd4: 01894bbd ldr      s1, [x8, #0xb88]
03398bd8: 0209281e fmul     s2, s8, s8
03398bdc: 4028201e fadd     s0, s2, s0
03398be0: 02c0211e fsqrt    s2, s0
03398be4: 4020211e fcmp     s2, s1
03398be8: ad000054 b.le     #0x3398bfc
03398bec: 6019221e fdiv     s0, s11, s2
03398bf0: 2119221e fdiv     s1, s9, s2
03398bf4: 0219221e fdiv     s2, s8, s2
03398bf8: 0f000014 b        #0x3398c34
03398bfc: f40e01d0 adrp     x20, #0x5576000
03398c00: 88b27c39 ldrb     w8, [x20, #0xf2c]
03398c04: c8000035 cbnz     w8, #0x3398c1c
03398c08: 80f400f0 adrp     x0, #0x522b000
03398c0c: 00ac43f9 ldr      x0, [x0, #0x758]
03398c10: bc617097 bl       #0xfb1300
03398c14: 28008052 mov      w8, #1
03398c18: 88b23c39 strb     w8, [x20, #0xf2c]
03398c1c: 88f400f0 adrp     x8, #0x522b000
03398c20: 08ad43f9 ldr      x8, [x8, #0x758]
03398c24: 080140f9 ldr      x8, [x8]
03398c28: 085d40f9 ldr      x8, [x8, #0xb8]
03398c2c: 0005402d ldp      s0, s1, [x8]
03398c30: 020940bd ldr      s2, [x8, #8]
03398c34: 680240f9 ldr      x8, [x19]
03398c38: e00313aa mov      x0, x19
03398c3c: 095541f9 ldr      x9, [x8, #0x2a8]
03398c40: 015941f9 ldr      x1, [x8, #0x2b0]
03398c44: 20013fd6 blr      x9
03398c48: 680240f9 ldr      x8, [x19]
03398c4c: e00313aa mov      x0, x19
03398c50: f37b45a9 ldp      x19, x30, [sp, #0x50]
03398c54: f55344a9 ldp      x21, x20, [sp, #0x40]
03398c58: 023d41f9 ldr      x2, [x8, #0x278]
03398c5c: 014141f9 ldr      x1, [x8, #0x280]
03398c60: f61b40f9 ldr      x22, [sp, #0x30]
03398c64: e923426d ldp      d9, d8, [sp, #0x20]
03398c68: eb2b416d ldp      d11, d10, [sp, #0x10]
03398c6c: ed33c66c ldp      d13, d12, [sp], #0x60
03398c70: 40001fd6 br       x2
03398c74: e00315aa mov      x0, x21
03398c78: d2627097 bl       #0xfb17c0
03398c7c: 750e06f8 str      x21, [x19, #0x60]!
03398c80: e00313aa mov      x0, x19
03398c84: e10315aa mov      x1, x21
03398c88: 89617097 bl       #0xfb12ac
03398c8c: e7617097 bl       #0xfb1428
