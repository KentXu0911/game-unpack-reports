# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_ShouldPlaySfxInLoop
# Linear span to next metadata entry; not a complete CFG.
0339b5ac: e0031f2a mov      w0, wzr
0339b5b0: c0035fd6 ret      
