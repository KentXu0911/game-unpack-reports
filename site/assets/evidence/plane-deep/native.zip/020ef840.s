# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$EndProfile
# Linear span to next metadata entry; not a complete CFG.
020ef840: c0035fd6 ret      
