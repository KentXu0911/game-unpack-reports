# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerPropellerComboStrategy$$GetNewPilot
# Linear span to next metadata entry; not a complete CFG.
033a3ba0: e80f1dfc str      d8, [sp, #-0x30]!
033a3ba4: f55301a9 stp      x21, x20, [sp, #0x10]
033a3ba8: f37b02a9 stp      x19, x30, [sp, #0x20]
033a3bac: 150f01f0 adrp     x21, #0x5586000
033a3bb0: 34f200f0 adrp     x20, #0x51ea000
033a3bb4: a8426739 ldrb     w8, [x21, #0x9d0]
033a3bb8: 947247f9 ldr      x20, [x20, #0xee0]
033a3bbc: f30300aa mov      x19, x0
033a3bc0: c8000037 tbnz     w8, #0, #0x33a3bd8
033a3bc4: 20f200f0 adrp     x0, #0x51ea000
033a3bc8: 007047f9 ldr      x0, [x0, #0xee0]
033a3bcc: cd357097 bl       #0xfb1300
033a3bd0: 28008052 mov      w8, #1
033a3bd4: a8422739 strb     w8, [x21, #0x9d0]
033a3bd8: 800240f9 ldr      x0, [x20]
033a3bdc: 682640bd ldr      s8, [x19, #0x24]
033a3be0: 0e367097 bl       #0xfb1418
033a3be4: 200100b4 cbz      x0, #0x33a3c08
033a3be8: 001da84e mov      v0.16b, v8.16b
033a3bec: f30300aa mov      x19, x0
033a3bf0: d9dcff97 bl       #0x339af54 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$.ctor
033a3bf4: e00313aa mov      x0, x19
033a3bf8: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a3bfc: f55341a9 ldp      x21, x20, [sp, #0x10]
033a3c00: e80743fc ldr      d8, [sp], #0x30
033a3c04: c0035fd6 ret      
033a3c08: 08367097 bl       #0xfb1428
