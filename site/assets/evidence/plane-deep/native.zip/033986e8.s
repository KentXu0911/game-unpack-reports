# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$PlayEndFallAltAnimation
# Linear span to next metadata entry; not a complete CFG.
033986e8: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033986ec: 080040f9 ldr      x8, [x0]
033986f0: 133c40f9 ldr      x19, [x0, #0x78]
033986f4: 095542f9 ldr      x9, [x8, #0x4a8]
033986f8: 015942f9 ldr      x1, [x8, #0x4b0]
033986fc: 20013fd6 blr      x9
03398700: 130100b4 cbz      x19, #0x3398720
03398704: e103002a mov      w1, w0
03398708: e003271e fmov     s0, wzr
0339870c: e00313aa mov      x0, x19
03398710: e2031f2a mov      w2, wzr
03398714: e3031faa mov      x3, xzr
03398718: f37bc1a8 ldp      x19, x30, [sp], #0x10
0339871c: 85caa817 b        #0x1dcb130 ; UnityEngine.Animator$$Play
03398720: 42637097 bl       #0xfb1428
