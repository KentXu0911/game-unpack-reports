# Royal.Scenes.Game.Mechanics.Items.OtterItem.OtterItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03089314: f60f1df8 str      x22, [sp, #-0x30]!
03089318: f55301a9 stp      x21, x20, [sp, #0x10]
0308931c: f37b02a9 stp      x19, x30, [sp, #0x20]
03089320: f5270190 adrp     x21, #0x5585000
03089324: a82e5239 ldrb     w8, [x21, #0x48b]
03089328: f303012a mov      w19, w1
0308932c: f40300aa mov      x20, x0
03089330: c8000037 tbnz     w8, #0, #0x3089348
03089334: 600901b0 adrp     x0, #0x51b6000
03089338: 002c47f9 ldr      x0, [x0, #0xe58]
0308933c: f19f7c97 bl       #0xfb1300
03089340: 28008052 mov      w8, #1
03089344: a82e1239 strb     w8, [x21, #0x48b]
03089348: 88464339 ldrb     w8, [x20, #0xd1]
0308934c: 28040034 cbz      w8, #0x30893d0
03089350: 88424339 ldrb     w8, [x20, #0xd0]
03089354: e8030034 cbz      w8, #0x30893d0
03089358: e003132a mov      w0, w19
0308935c: e1031faa mov      x1, xzr
03089360: 77ed0b94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03089364: a0030036 tbz      w0, #0, #0x30893d8
03089368: 880240f9 ldr      x8, [x20]
0308936c: e00314aa mov      x0, x20
03089370: 096542f9 ldr      x9, [x8, #0x4c8]
03089374: 016942f9 ldr      x1, [x8, #0x4d0]
03089378: 20013fd6 blr      x9
0308937c: 1f040071 cmp      w0, #1
03089380: c1080054 b.ne     #0x3089498
03089384: 880240f9 ldr      x8, [x20]
03089388: e00314aa mov      x0, x20
0308938c: 09bd41f9 ldr      x9, [x8, #0x378]
03089390: 01c141f9 ldr      x1, [x8, #0x380]
03089394: 20013fd6 blr      x9
03089398: e1031faa mov      x1, xzr
0308939c: 7bed0b94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
030893a0: 886240f9 ldr      x8, [x20, #0xc0]
030893a4: e80800b4 cbz      x8, #0x30894c0
030893a8: 082140f9 ldr      x8, [x8, #0x40]
030893ac: a80800b4 cbz      x8, #0x30894c0
030893b0: 081940b9 ldr      w8, [x8, #0x18]
030893b4: 090c0011 add      w9, w0, #3
030893b8: 1f000071 cmp      w0, #0
030893bc: 29b1801a csel     w9, w9, w0, lt
030893c0: 297d0213 asr      w9, w9, #2
030893c4: 08050051 sub      w8, w8, #1
030893c8: 157d091b mul      w21, w8, w9
030893cc: 34000014 b        #0x308949c
030893d0: e0031f2a mov      w0, wzr
030893d4: 37000014 b        #0x30894b0
030893d8: e0031faa mov      x0, xzr
030893dc: 4cd33194 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
030893e0: 88d640b9 ldr      w8, [x20, #0xd4]
030893e4: 1f00086b cmp      w0, w8
030893e8: 00020054 b.eq     #0x3089428
030893ec: 956240f9 ldr      x21, [x20, #0xc0]
030893f0: e00314aa mov      x0, x20
030893f4: e1031faa mov      x1, xzr
030893f8: a7e60b94 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
030893fc: 200600b4 cbz      x0, #0x30894c0
03089400: e1031faa mov      x1, xzr
03089404: 7fffe897 bl       #0x2ac9200 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetBoardAdjustedPoint
03089408: d50500b4 cbz      x21, #0x30894c0
0308940c: e20300aa mov      x2, x0
03089410: e00315aa mov      x0, x21
03089414: e103132a mov      w1, w19
03089418: 3cfaff97 bl       #0x3087d08 ; Royal.Scenes.Game.Mechanics.Items.OtterItem.OtterCollectHelper$$UpdateExtraScoreCache
0308941c: e0031faa mov      x0, xzr
03089420: 3bd33194 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
03089424: 80d600b9 str      w0, [x20, #0xd4]
03089428: 886240f9 ldr      x8, [x20, #0xc0]
0308942c: a80400b4 cbz      x8, #0x30894c0
03089430: 092140f9 ldr      x9, [x8, #0x40]
03089434: 690400b4 cbz      x9, #0x30894c0
03089438: 803240f9 ldr      x0, [x20, #0x60]
0308943c: 200400b4 cbz      x0, #0x30894c0
03089440: 15a540b9 ldr      w21, [x8, #0xa4]
03089444: 361940b9 ldr      w22, [x9, #0x18]
03089448: 210d8052 mov      w1, #0x69
0308944c: e2031f2a mov      w2, wzr
03089450: e3031faa mov      x3, xzr
03089454: 1896e697 bl       #0x2a2ecb4 ; Royal.Scenes.Game.Levels.Units.GoalManager$$GetGoalLeftCount
03089458: c802004b sub      w8, w22, w0
0308945c: 1501152b adds     w21, w8, w21
03089460: c4010054 b.mi     #0x3089498
03089464: 880240f9 ldr      x8, [x20]
03089468: e00314aa mov      x0, x20
0308946c: 09bd41f9 ldr      x9, [x8, #0x378]
03089470: 01c141f9 ldr      x1, [x8, #0x380]
03089474: 20013fd6 blr      x9
03089478: e1031faa mov      x1, xzr
0308947c: 43ed0b94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03089480: 080c0011 add      w8, w0, #3
03089484: 1f000071 cmp      w0, #0
03089488: 08b1801a csel     w8, w8, w0, lt
0308948c: 087d0213 asr      w8, w8, #2
03089490: 157d151b mul      w21, w8, w21
03089494: 02000014 b        #0x308949c
03089498: f5031f2a mov      w21, wzr
0308949c: e00314aa mov      x0, x20
030894a0: e103132a mov      w1, w19
030894a4: e2031faa mov      x2, xzr
030894a8: 31ed0b94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
030894ac: 0000150b add      w0, w0, w21
030894b0: f37b42a9 ldp      x19, x30, [sp, #0x20]
030894b4: f55341a9 ldp      x21, x20, [sp, #0x10]
030894b8: f60743f8 ldr      x22, [sp], #0x30
030894bc: c0035fd6 ret      
030894c0: da9f7c97 bl       #0xfb1428
