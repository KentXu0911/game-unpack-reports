# Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$HasIncomingExploder
# Linear span to next metadata entry; not a complete CFG.
02acfcec: f60f1df8 str      x22, [sp, #-0x30]!
02acfcf0: f55301a9 stp      x21, x20, [sp, #0x10]
02acfcf4: f37b02a9 stp      x19, x30, [sp, #0x20]
02acfcf8: 945501f0 adrp     x20, #0x5582000
02acfcfc: 88ce4639 ldrb     w8, [x20, #0x1b3]
02acfd00: f30300aa mov      x19, x0
02acfd04: 28010037 tbnz     w8, #0, #0x2acfd28
02acfd08: 60370190 adrp     x0, #0x51bb000
02acfd0c: 000844f9 ldr      x0, [x0, #0x810]
02acfd10: 7c859397 bl       #0xfb1300
02acfd14: 203901b0 adrp     x0, #0x51f4000
02acfd18: 00e841f9 ldr      x0, [x0, #0x3d0]
02acfd1c: 79859397 bl       #0xfb1300
02acfd20: 28008052 mov      w8, #1
02acfd24: 88ce0639 strb     w8, [x20, #0x1b3]
02acfd28: 681240f9 ldr      x8, [x19, #0x20]
02acfd2c: 680700b4 cbz      x8, #0x2acfe18
02acfd30: 086140f9 ldr      x8, [x8, #0xc0]
02acfd34: 280700b4 cbz      x8, #0x2acfe18
02acfd38: 141940f9 ldr      x20, [x8, #0x30]
02acfd3c: f40600b4 cbz      x20, #0x2acfe18
02acfd40: 881a40b9 ldr      w8, [x20, #0x18]
02acfd44: 363901b0 adrp     x22, #0x51f4000
02acfd48: d6ea41f9 ldr      x22, [x22, #0x3d0]
02acfd4c: 15050051 sub      w21, w8, #1
02acfd50: 7501f837 tbnz     w21, #0x1f, #0x2acfd7c
02acfd54: c20240f9 ldr      x2, [x22]
02acfd58: e00314aa mov      x0, x20
02acfd5c: e103152a mov      w1, w21
02acfd60: a3f9fb97 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
02acfd64: a00500b4 cbz      x0, #0x2acfe18
02acfd68: e1031faa mov      x1, xzr
02acfd6c: 88781894 bl       #0x30edf8c ; Royal.Scenes.Game.Mechanics.Items.Config.StaticItemModel$$HasIncomingExploder
02acfd70: b5060051 sub      w21, w21, #1
02acfd74: e0fe0736 tbz      w0, #0, #0x2acfd50
02acfd78: 23000014 b        #0x2acfe04
02acfd7c: 681240f9 ldr      x8, [x19, #0x20]
02acfd80: c80400b4 cbz      x8, #0x2acfe18
02acfd84: 000940f9 ldr      x0, [x8, #0x10]
02acfd88: 800400b4 cbz      x0, #0x2acfe18
02acfd8c: e1031faa mov      x1, xzr
02acfd90: 34d8f197 bl       #0x2745e60 ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$get_CurrentItem
02acfd94: 800000b4 cbz      x0, #0x2acfda4
02acfd98: e1031faa mov      x1, xzr
02acfd9c: f9f72294 bl       #0x338dd80 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$HasIncomingExploder
02acfda0: 20030037 tbnz     w0, #0, #0x2acfe04
02acfda4: 681240f9 ldr      x8, [x19, #0x20]
02acfda8: 880300b4 cbz      x8, #0x2acfe18
02acfdac: 086140f9 ldr      x8, [x8, #0xc0]
02acfdb0: 480300b4 cbz      x8, #0x2acfe18
02acfdb4: 131d40f9 ldr      x19, [x8, #0x38]
02acfdb8: 130300b4 cbz      x19, #0x2acfe18
02acfdbc: 681a40b9 ldr      w8, [x19, #0x18]
02acfdc0: 1f050071 cmp      w8, #1
02acfdc4: cb010054 b.lt     #0x2acfdfc
02acfdc8: f4031f2a mov      w20, wzr
02acfdcc: c20240f9 ldr      x2, [x22]
02acfdd0: e00313aa mov      x0, x19
02acfdd4: e103142a mov      w1, w20
02acfdd8: 85f9fb97 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
02acfddc: e00100b4 cbz      x0, #0x2acfe18
02acfde0: e1031faa mov      x1, xzr
02acfde4: 6a781894 bl       #0x30edf8c ; Royal.Scenes.Game.Mechanics.Items.Config.StaticItemModel$$HasIncomingExploder
02acfde8: e0000037 tbnz     w0, #0, #0x2acfe04
02acfdec: 681a40b9 ldr      w8, [x19, #0x18]
02acfdf0: 94060011 add      w20, w20, #1
02acfdf4: 9f02086b cmp      w20, w8
02acfdf8: abfeff54 b.lt     #0x2acfdcc
02acfdfc: e0031f2a mov      w0, wzr
02acfe00: 02000014 b        #0x2acfe08
02acfe04: 20008052 mov      w0, #1
02acfe08: f37b42a9 ldp      x19, x30, [sp, #0x20]
02acfe0c: f55341a9 ldp      x21, x20, [sp, #0x10]
02acfe10: f60743f8 ldr      x22, [sp], #0x30
02acfe14: c0035fd6 ret      
02acfe18: 84859397 bl       #0xfb1428
