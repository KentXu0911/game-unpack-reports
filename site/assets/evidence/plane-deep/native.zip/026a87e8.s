# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddTemporaryIncomingExploder
# Linear span to next metadata entry; not a complete CFG.
026a87e8: ff8303d1 sub      sp, sp, #0xe0
026a87ec: f46300f9 str      x20, [sp, #0xc0]
026a87f0: f37b0da9 stp      x19, x30, [sp, #0xd0]
026a87f4: 140c40f9 ldr      x20, [x0, #0x18]
026a87f8: f30303aa mov      x19, x3
026a87fc: e0030291 add      x0, sp, #0x80
026a8800: e3031faa mov      x3, xzr
026a8804: ff4300f9 str      xzr, [sp, #0x80]
026a8808: 1b7e1094 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
026a880c: f40500b4 cbz      x20, #0x26a88c8
026a8810: e14340f9 ldr      x1, [sp, #0x80]
026a8814: e00314aa mov      x0, x20
026a8818: e2031faa mov      x2, xzr
026a881c: 3daf0294 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
026a8820: c00400b4 cbz      x0, #0x26a88b8
026a8824: f40300aa mov      x20, x0
026a8828: 006040f9 ldr      x0, [x0, #0xc0]
026a882c: e00400b4 cbz      x0, #0x26a88c8
026a8830: e1031faa mov      x1, xzr
026a8834: 5c861094 bl       #0x2aca1a4 ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$GetTopMostAboveItem
026a8838: c00100b4 cbz      x0, #0x26a8870
026a883c: 681a40f9 ldr      x8, [x19, #0x30]
026a8840: 618240ad ldp      q1, q0, [x19, #0x10]
026a8844: 6202c03d ldr      q2, [x19]
026a8848: e83b00f9 str      x8, [sp, #0x70]
026a884c: e18302ad stp      q1, q0, [sp, #0x50]
026a8850: e213803d str      q2, [sp, #0x40]
026a8854: 090040f9 ldr      x9, [x0]
026a8858: 2a7d42f9 ldr      x10, [x9, #0x4f8]
026a885c: e20704ad stp      q2, q1, [sp, #0x80]
026a8860: e02b803d str      q0, [sp, #0xa0]
026a8864: e85b00f9 str      x8, [sp, #0xb0]
026a8868: 228142f9 ldr      x2, [x9, #0x500]
026a886c: 11000014 b        #0x26a88b0
026a8870: e00314aa mov      x0, x20
026a8874: e1031faa mov      x1, xzr
026a8878: 88801094 bl       #0x2ac8a98 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_TargetItem
026a887c: e00100b4 cbz      x0, #0x26a88b8
026a8880: 681a40f9 ldr      x8, [x19, #0x30]
026a8884: 618240ad ldp      q1, q0, [x19, #0x10]
026a8888: 6202c03d ldr      q2, [x19]
026a888c: e81b00f9 str      x8, [sp, #0x30]
026a8890: e18300ad stp      q1, q0, [sp, #0x10]
026a8894: e203803d str      q2, [sp]
026a8898: 090040f9 ldr      x9, [x0]
026a889c: 2a7542f9 ldr      x10, [x9, #0x4e8]
026a88a0: e20704ad stp      q2, q1, [sp, #0x80]
026a88a4: e02b803d str      q0, [sp, #0xa0]
026a88a8: e85b00f9 str      x8, [sp, #0xb0]
026a88ac: 227942f9 ldr      x2, [x9, #0x4f0]
026a88b0: e1030291 add      x1, sp, #0x80
026a88b4: 40013fd6 blr      x10
026a88b8: f37b4da9 ldp      x19, x30, [sp, #0xd0]
026a88bc: f46340f9 ldr      x20, [sp, #0xc0]
026a88c0: ff830391 add      sp, sp, #0xe0
026a88c4: c0035fd6 ret      
026a88c8: d822a497 bl       #0xfb1428
