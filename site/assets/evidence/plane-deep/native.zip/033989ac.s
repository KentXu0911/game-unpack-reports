# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_MinOutSpeedConst
# Linear span to next metadata entry; not a complete CFG.
033989ac: 685600f0 adrp     x8, #0x3e67000
033989b0: 002146bd ldr      s0, [x8, #0x620]
033989b4: c0035fd6 ret      
