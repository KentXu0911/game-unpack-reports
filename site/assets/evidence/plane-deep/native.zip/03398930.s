# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerTargetExplodeParticles$$Play
# Linear span to next metadata entry; not a complete CFG.
03398930: f40f1ef8 str      x20, [sp, #-0x20]!
03398934: f37b01a9 stp      x19, x30, [sp, #0x10]
03398938: 740f01d0 adrp     x20, #0x5586000
0339893c: 88726639 ldrb     w8, [x20, #0x99c]
03398940: f30300aa mov      x19, x0
03398944: c8000037 tbnz     w8, #0, #0x339895c
03398948: 40f100f0 adrp     x0, #0x51c3000
0339894c: 007843f9 ldr      x0, [x0, #0x6f0]
03398950: 6c627097 bl       #0xfb1300
03398954: 28008052 mov      w8, #1
03398958: 88722639 strb     w8, [x20, #0x99c]
0339895c: 601a40f9 ldr      x0, [x19, #0x30]
03398960: 800100b4 cbz      x0, #0x3398990
03398964: 54f100f0 adrp     x20, #0x51c3000
03398968: 947a43f9 ldr      x20, [x20, #0x6f0]
0339896c: e1031faa mov      x1, xzr
03398970: 50891094 bl       #0x37baeb0 ; UnityEngine.ParticleSystem$$Play
03398974: 810240f9 ldr      x1, [x20]
03398978: e00313aa mov      x0, x19
0339897c: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398980: 00102e1e fmov     s0, #1.00000000
03398984: e2031faa mov      x2, xzr
03398988: f40742f8 ldr      x20, [sp], #0x20
0339898c: f6bb2514 b        #0x3d07964 ; UnityEngine.MonoBehaviour$$Invoke
03398990: a6627097 bl       #0xfb1428
