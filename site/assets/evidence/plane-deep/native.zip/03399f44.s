# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangePosition
# Linear span to next metadata entry; not a complete CFG.
03399f44: ff0303d1 sub      sp, sp, #0xc0
03399f48: ef3b056d stp      d15, d14, [sp, #0x50]
03399f4c: ed33066d stp      d13, d12, [sp, #0x60]
03399f50: eb2b076d stp      d11, d10, [sp, #0x70]
03399f54: e923086d stp      d9, d8, [sp, #0x80]
03399f58: f75b09a9 stp      x23, x22, [sp, #0x90]
03399f5c: f5530aa9 stp      x21, x20, [sp, #0xa0]
03399f60: f37b0ba9 stp      x19, x30, [sp, #0xb0]
03399f64: 740f01b0 adrp     x20, #0x5586000
03399f68: 88866639 ldrb     w8, [x20, #0x9a1]
03399f6c: 8d1ca44e mov      v13.16b, v4.16b
03399f70: 4e1ca24e mov      v14.16b, v2.16b
03399f74: 291ca14e mov      v9.16b, v1.16b
03399f78: 0a1ca04e mov      v10.16b, v0.16b
03399f7c: f30300aa mov      x19, x0
03399f80: e39b082d stp      s3, s6, [sp, #0x44]
03399f84: e54300bd str      s5, [sp, #0x40]
03399f88: 88010037 tbnz     w8, #0, #0x3399fb8
03399f8c: c0f40090 adrp     x0, #0x5231000
03399f90: 003841f9 ldr      x0, [x0, #0x270]
03399f94: db5c7097 bl       #0xfb1300
03399f98: e0f200f0 adrp     x0, #0x51f8000
03399f9c: 000847f9 ldr      x0, [x0, #0xe10]
03399fa0: d85c7097 bl       #0xfb1300
03399fa4: c0f200d0 adrp     x0, #0x51f3000
03399fa8: 003045f9 ldr      x0, [x0, #0xa60]
03399fac: d55c7097 bl       #0xfb1300
03399fb0: 28008052 mov      w8, #1
03399fb4: 88862639 strb     w8, [x20, #0x9a1]
03399fb8: e0031faa mov      x0, xzr
03399fbc: 0a902594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
03399fc0: 08102c1e fmov     s8, #0.50000000
03399fc4: 0c1ca04e mov      v12.16b, v0.16b
03399fc8: 0020281e fcmp     s0, s8
03399fcc: 8d040054 b.le     #0x339a05c
03399fd0: c8f40090 adrp     x8, #0x5231000
03399fd4: 083941f9 ldr      x8, [x8, #0x270]
03399fd8: f5f200f0 adrp     x21, #0x51f8000
03399fdc: 21008052 mov      w1, #1
03399fe0: 000140f9 ldr      x0, [x8]
03399fe4: b50a47f9 ldr      x21, [x21, #0xe10]
03399fe8: e25c7097 bl       #0xfb1370
03399fec: f40300aa mov      x20, x0
03399ff0: a00240f9 ldr      x0, [x21]
03399ff4: e1330191 add      x1, sp, #0x4c
03399ff8: ec4f00bd str      s12, [sp, #0x4c]
03399ffc: 045d7097 bl       #0xfb140c
0339a000: 943300b4 cbz      x20, #0x339a670
0339a004: f50300aa mov      x21, x0
0339a008: c00000b4 cbz      x0, #0x339a020
0339a00c: 880240f9 ldr      x8, [x20]
0339a010: e00315aa mov      x0, x21
0339a014: 012140f9 ldr      x1, [x8, #0x40]
0339a018: fc5c7097 bl       #0xfb1408
0339a01c: e03200b4 cbz      x0, #0x339a678
0339a020: 881a40b9 ldr      w8, [x20, #0x18]
0339a024: 88320034 cbz      w8, #0x339a674
0339a028: d6f200b0 adrp     x22, #0x51f3000
0339a02c: d63245f9 ldr      x22, [x22, #0xa60]
0339a030: e00314aa mov      x0, x20
0339a034: 150c02f8 str      x21, [x0, #0x20]!
0339a038: e10315aa mov      x1, x21
0339a03c: 9c5c7097 bl       #0xfb12ac
0339a040: c20240f9 ldr      x2, [x22]
0339a044: 61018052 mov      w1, #0xb
0339a048: e00313aa mov      x0, x19
0339a04c: e30314aa mov      x3, x20
0339a050: e4031faa mov      x4, xzr
0339a054: 2a9cd197 bl       #0x28010fc ; Royal.Infrastructure.Services.Logs.Log$$Error
0339a058: 0c1da84e mov      v12.16b, v8.16b
0339a05c: 602240bd ldr      s0, [x19, #0x20]
0339a060: 685600b0 adrp     x8, #0x3e67000
0339a064: 014144bd ldr      s1, [x8, #0x440]
0339a068: 02102d1e fmov     s2, #0.75000000
0339a06c: 0018221e fdiv     s0, s0, s2
0339a070: 06102e1e fmov     s6, #1.00000000
0339a074: 0058261e fmin     s0, s0, s6
0339a078: 0020211e fcmp     s0, s1
0339a07c: 45010054 b.pl     #0x339a0a4
0339a080: 642e40bd ldr      s4, [x19, #0x2c]
0339a084: 623640bd ldr      s2, [x19, #0x34]
0339a088: 0118211e fdiv     s1, s0, s1
0339a08c: 2358261e fmin     s3, s1, s6
0339a090: 2820201e fcmp     s1, #0.0
0339a094: e103271e fmov     s1, wzr
0339a098: 615c211e fcsel    s1, s3, s1, pl
0339a09c: 4238241e fsub     s2, s2, s4
0339a0a0: 0d000014 b        #0x339a0d4
0339a0a4: 685600b0 adrp     x8, #0x3e67000
0339a0a8: 695600b0 adrp     x9, #0x3e67000
0339a0ac: 018945bd ldr      s1, [x8, #0x588]
0339a0b0: 223544bd ldr      s2, [x9, #0x434]
0339a0b4: 6312462d ldp      s3, s4, [x19, #0x30]
0339a0b8: e503271e fmov     s5, wzr
0339a0bc: 0128211e fadd     s1, s0, s1
0339a0c0: 2118221e fdiv     s1, s1, s2
0339a0c4: 2258261e fmin     s2, s1, s6
0339a0c8: 2820201e fcmp     s1, #0.0
0339a0cc: 415c251e fcsel    s1, s2, s5, pl
0339a0d0: 6238241e fsub     s2, s3, s4
0339a0d4: 662a40bd ldr      s6, [x19, #0x28]
0339a0d8: 2508221e fmul     s5, s1, s2
0339a0dc: e703271e fmov     s7, wzr
0339a0e0: 1090261e fmov     s16, #20.00000000
0339a0e4: 610a472d ldp      s1, s2, [x19, #0x38]
0339a0e8: 634240bd ldr      s3, [x19, #0x40]
0339a0ec: 8428251e fadd     s4, s4, s5
0339a0f0: 0048271e fmax     s0, s0, s7
0339a0f4: 053a261e fsub     s5, s16, s6
0339a0f8: 0008251e fmul     s0, s0, s5
0339a0fc: c028201e fadd     s0, s6, s0
0339a100: e0031faa mov      x0, xzr
0339a104: 6012032d stp      s0, s4, [x19, #0x18]
0339a108: 1aae0594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339a10c: 441daa4e mov      v4.16b, v10.16b
0339a110: 251da94e mov      v5.16b, v9.16b
0339a114: c61dae4e mov      v6.16b, v14.16b
0339a118: e0031faa mov      x0, xzr
0339a11c: ea27072d stp      s10, s9, [sp, #0x38]
0339a120: a6ab0594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339a124: f50e0190 adrp     x21, #0x5576000
0339a128: a8b27c39 ldrb     w8, [x21, #0xf2c]
0339a12c: 691e40bd ldr      s9, [x19, #0x1c]
0339a130: 0a1ca04e mov      v10.16b, v0.16b
0339a134: 2b1ca14e mov      v11.16b, v1.16b
0339a138: 4f1ca24e mov      v15.16b, v2.16b
0339a13c: c8000035 cbnz     w8, #0x339a154
0339a140: 80f400b0 adrp     x0, #0x522b000
0339a144: 00ac43f9 ldr      x0, [x0, #0x758]
0339a148: 6e5c7097 bl       #0xfb1300
0339a14c: 28008052 mov      w8, #1
0339a150: a8b23c39 strb     w8, [x21, #0xf2c]
0339a154: 485b00d0 adrp     x8, #0x3f04000
0339a158: 602240bd ldr      s0, [x19, #0x20]
0339a15c: 015946bd ldr      s1, [x8, #0x658]
0339a160: 96f400b0 adrp     x22, #0x522b000
0339a164: 34f300d0 adrp     x20, #0x5200000
0339a168: d6ae43f9 ldr      x22, [x22, #0x758]
0339a16c: 948e46f9 ldr      x20, [x20, #0xd18]
0339a170: 8909291e fmul     s9, s12, s9
0339a174: 0020211e fcmp     s0, s1
0339a178: 0d070054 b.le     #0x339a258
0339a17c: 680240f9 ldr      x8, [x19]
0339a180: ee3700bd str      s14, [sp, #0x34]
0339a184: 6e8640bd ldr      s14, [x19, #0x84]
0339a188: e00313aa mov      x0, x19
0339a18c: 090541f9 ldr      x9, [x8, #0x208]
0339a190: 010941f9 ldr      x1, [x8, #0x210]
0339a194: a81dad4e mov      v8.16b, v13.16b
0339a198: 20013fd6 blr      x9
0339a19c: 680240f9 ldr      x8, [x19]
0339a1a0: e00313aa mov      x0, x19
0339a1a4: 0d1ca04e mov      v13.16b, v0.16b
0339a1a8: 090d41f9 ldr      x9, [x8, #0x218]
0339a1ac: 011141f9 ldr      x1, [x8, #0x220]
0339a1b0: 20013fd6 blr      x9
0339a1b4: 81092d1e fmul     s1, s12, s13
0339a1b8: c129211e fadd     s1, s14, s1
0339a1bc: 2020201e fcmp     s1, s0
0339a1c0: e203271e fmov     s2, wzr
0339a1c4: 00cc211e fcsel    s0, s0, s1, gt
0339a1c8: 2820201e fcmp     s1, #0.0
0339a1cc: 005c221e fcsel    s0, s0, s2, pl
0339a1d0: 608600bd str      s0, [x19, #0x84]
0339a1d4: f70e01b0 adrp     x23, #0x5577000
0339a1d8: e81a6039 ldrb     w8, [x23, #0x806]
0339a1dc: 8c09201e fmul     s12, s12, s0
0339a1e0: c8000035 cbnz     w8, #0x339a1f8
0339a1e4: 20f300d0 adrp     x0, #0x5200000
0339a1e8: 008c46f9 ldr      x0, [x0, #0xd18]
0339a1ec: 455c7097 bl       #0xfb1300
0339a1f0: 28008052 mov      w8, #1
0339a1f4: e81a2039 strb     w8, [x23, #0x806]
0339a1f8: e04740bd ldr      s0, [sp, #0x44]
0339a1fc: 800240f9 ldr      x0, [x20]
0339a200: 0d1da84e mov      v13.16b, v8.16b
0339a204: 02092c1e fmul     s2, s8, s12
0339a208: 0e082c1e fmul     s14, s0, s12
0339a20c: e04340bd ldr      s0, [sp, #0x40]
0339a210: 08e040b9 ldr      w8, [x0, #0xe0]
0339a214: 0c082c1e fmul     s12, s0, s12
0339a218: 88000035 cbnz     w8, #0x339a228
0339a21c: 481ca24e mov      v8.16b, v2.16b
0339a220: 795c7097 bl       #0xfb1404
0339a224: 021da84e mov      v2.16b, v8.16b
0339a228: c0092e1e fmul     s0, s14, s14
0339a22c: 4108221e fmul     s1, s2, s2
0339a230: 0028211e fadd     s0, s0, s1
0339a234: 81092c1e fmul     s1, s12, s12
0339a238: 2028201e fadd     s0, s1, s0
0339a23c: e14b40bd ldr      s1, [sp, #0x48]
0339a240: 00c0211e fsqrt    s0, s0
0339a244: 0020211e fcmp     s0, s1
0339a248: 0d010054 b.le     #0x339a268
0339a24c: ee0b472d ldp      s14, s2, [sp, #0x38]
0339a250: ec3740bd ldr      s12, [sp, #0x34]
0339a254: 05000014 b        #0x339a268
0339a258: c80240f9 ldr      x8, [x22]
0339a25c: 085d40f9 ldr      x8, [x8, #0xb8]
0339a260: 0e09402d ldp      s14, s2, [x8]
0339a264: 0c0940bd ldr      s12, [x8, #8]
0339a268: ec3f00bd str      s12, [sp, #0x3c]
0339a26c: 685240bd ldr      s8, [x19, #0x50]
0339a270: a8b27c39 ldrb     w8, [x21, #0xf2c]
0339a274: 6c4245fc ldur     d12, [x19, #0x54]
0339a278: 4109291e fmul     s1, s10, s9
0339a27c: 6009291e fmul     s0, s11, s9
0339a280: e909291e fmul     s9, s15, s9
0339a284: c8010035 cbnz     w8, #0x339a2bc
0339a288: 80f400b0 adrp     x0, #0x522b000
0339a28c: 00ac43f9 ldr      x0, [x0, #0x758]
0339a290: 2a1da94e mov      v10.16b, v9.16b
0339a294: 491ca24e mov      v9.16b, v2.16b
0339a298: 0b1ca04e mov      v11.16b, v0.16b
0339a29c: 2f1ca14e mov      v15.16b, v1.16b
0339a2a0: 185c7097 bl       #0xfb1300
0339a2a4: e11daf4e mov      v1.16b, v15.16b
0339a2a8: 601dab4e mov      v0.16b, v11.16b
0339a2ac: 221da94e mov      v2.16b, v9.16b
0339a2b0: 491daa4e mov      v9.16b, v10.16b
0339a2b4: 28008052 mov      w8, #1
0339a2b8: a8b23c39 strb     w8, [x21, #0xf2c]
0339a2bc: c80240f9 ldr      x8, [x22]
0339a2c0: 2b282e1e fadd     s11, s1, s14
0339a2c4: 0a28221e fadd     s10, s0, s2
0339a2c8: e23b00bd str      s2, [sp, #0x38]
0339a2cc: 085d40f9 ldr      x8, [x8, #0xb8]
0339a2d0: e103062d stp      s1, s0, [sp, #0x30]
0339a2d4: 000140bd ldr      s0, [x8]
0339a2d8: 014140fc ldur     d1, [x8, #4]
0339a2dc: c85600b0 adrp     x8, #0x3e73000
0339a2e0: 02314bbd ldr      s2, [x8, #0xb30]
0339a2e4: 0039201e fsub     s0, s8, s0
0339a2e8: 81d5a10e fsub     v1.2s, v12.2s, v1.2s
0339a2ec: e83f40bd ldr      s8, [sp, #0x3c]
0339a2f0: 0008201e fmul     s0, s0, s0
0339a2f4: 21dc212e fmul     v1.2s, v1.2s, v1.2s
0339a2f8: 0028211e fadd     s0, s0, s1
0339a2fc: 21040c5e mov      s1, v1.s[1]
0339a300: 2028201e fadd     s0, s1, s0
0339a304: 0020221e fcmp     s0, s2
0339a308: 2f29281e fadd     s15, s9, s8
0339a30c: 84000054 b.mi     #0x339a31c
0339a310: 689640b9 ldr      w8, [x19, #0x94]
0339a314: 1f090071 cmp      w8, #2
0339a318: a1070054 b.ne     #0x339a40c
0339a31c: 6b2a0a2d stp      s11, s10, [x19, #0x50]
0339a320: 6f5a00bd str      s15, [x19, #0x58]
0339a324: 603640f9 ldr      x0, [x19, #0x68]
0339a328: 401a00b4 cbz      x0, #0x339a670
0339a32c: e1031faa mov      x1, xzr
0339a330: 71be2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339a334: 743640f9 ldr      x20, [x19, #0x68]
0339a338: d41900b4 cbz      x20, #0x339a670
0339a33c: e00314aa mov      x0, x20
0339a340: e1031faa mov      x1, xzr
0339a344: 0a1ca04e mov      v10.16b, v0.16b
0339a348: 2b1ca14e mov      v11.16b, v1.16b
0339a34c: 4f1ca24e mov      v15.16b, v2.16b
0339a350: 69be2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339a354: 63124a2d ldp      s3, s4, [x19, #0x50]
0339a358: 655a40bd ldr      s5, [x19, #0x58]
0339a35c: e00314aa mov      x0, x20
0339a360: e1031faa mov      x1, xzr
0339a364: 0028231e fadd     s0, s0, s3
0339a368: 2128241e fadd     s1, s1, s4
0339a36c: 4228251e fadd     s2, s2, s5
0339a370: 89be2594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
0339a374: e04b40bd ldr      s0, [sp, #0x48]
0339a378: e43b40bd ldr      s4, [sp, #0x38]
0339a37c: e00313aa mov      x0, x19
0339a380: 221da94e mov      v2.16b, v9.16b
0339a384: e01300bd str      s0, [sp, #0x10]
0339a388: e04340bd ldr      s0, [sp, #0x40]
0339a38c: c31dae4e mov      v3.16b, v14.16b
0339a390: 051da84e mov      v5.16b, v8.16b
0339a394: ed83002d stp      s13, s0, [sp, #4]
0339a398: e04740bd ldr      s0, [sp, #0x44]
0339a39c: e00300bd str      s0, [sp]
0339a3a0: e007462d ldp      s0, s1, [sp, #0x30]
0339a3a4: b8000094 bl       #0x339a684 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeRotation
0339a3a8: 603640f9 ldr      x0, [x19, #0x68]
0339a3ac: 201600b4 cbz      x0, #0x339a670
0339a3b0: e1031faa mov      x1, xzr
0339a3b4: 50be2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339a3b8: 685600b0 adrp     x8, #0x3e67000
0339a3bc: 064944bd ldr      s6, [x8, #0x448]
0339a3c0: 031ca04e mov      v3.16b, v0.16b
0339a3c4: 241ca14e mov      v4.16b, v1.16b
0339a3c8: 451ca24e mov      v5.16b, v2.16b
0339a3cc: 401daa4e mov      v0.16b, v10.16b
0339a3d0: 611dab4e mov      v1.16b, v11.16b
0339a3d4: e21daf4e mov      v2.16b, v15.16b
0339a3d8: e0031faa mov      x0, xzr
0339a3dc: 9ca8fb97 bl       #0x328464c ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339a3e0: f37b4ba9 ldp      x19, x30, [sp, #0xb0]
0339a3e4: f5534aa9 ldp      x21, x20, [sp, #0xa0]
0339a3e8: f75b49a9 ldp      x23, x22, [sp, #0x90]
0339a3ec: e923486d ldp      d9, d8, [sp, #0x80]
0339a3f0: eb2b476d ldp      d11, d10, [sp, #0x70]
0339a3f4: ed33466d ldp      d13, d12, [sp, #0x60]
0339a3f8: ef3b456d ldp      d15, d14, [sp, #0x50]
0339a3fc: e803202a mvn      w8, w0
0339a400: 00010012 and      w0, w8, #1
0339a404: ff030391 add      sp, sp, #0xc0
0339a408: c0035fd6 ret      
0339a40c: 680240f9 ldr      x8, [x19]
0339a410: e00313aa mov      x0, x19
0339a414: e92700bd str      s9, [sp, #0x24]
0339a418: ed2f00bd str      s13, [sp, #0x2c]
0339a41c: 097d41f9 ldr      x9, [x8, #0x2f8]
0339a420: 018141f9 ldr      x1, [x8, #0x300]
0339a424: 20013fd6 blr      x9
0339a428: 550f01d0 adrp     x21, #0x5584000
0339a42c: 69324a2d ldp      s9, s12, [x19, #0x50]
0339a430: a8fe4f39 ldrb     w8, [x21, #0x3ff]
0339a434: 635a40bd ldr      s3, [x19, #0x58]
0339a438: e02300bd str      s0, [sp, #0x20]
0339a43c: 08010035 cbnz     w8, #0x339a45c
0339a440: 20f300d0 adrp     x0, #0x5200000
0339a444: 008c46f9 ldr      x0, [x0, #0xd18]
0339a448: 681ca34e mov      v8.16b, v3.16b
0339a44c: ad5b7097 bl       #0xfb1300
0339a450: 031da84e mov      v3.16b, v8.16b
0339a454: 28008052 mov      w8, #1
0339a458: a8fe0f39 strb     w8, [x21, #0x3ff]
0339a45c: 800240f9 ldr      x0, [x20]
0339a460: 60092b1e fmul     s0, s11, s11
0339a464: 41092a1e fmul     s1, s10, s10
0339a468: 0028211e fadd     s0, s0, s1
0339a46c: e1092f1e fmul     s1, s15, s15
0339a470: 08e040b9 ldr      w8, [x0, #0xe0]
0339a474: 2d28201e fadd     s13, s1, s0
0339a478: 2009291e fmul     s0, s9, s9
0339a47c: 81092c1e fmul     s1, s12, s12
0339a480: 0028211e fadd     s0, s0, s1
0339a484: 6108231e fmul     s1, s3, s3
0339a488: 2828201e fadd     s8, s1, s0
0339a48c: 88000035 cbnz     w8, #0x339a49c
0339a490: e32b00bd str      s3, [sp, #0x28]
0339a494: dc5b7097 bl       #0xfb1404
0339a498: e32b40bd ldr      s3, [sp, #0x28]
0339a49c: c85600b0 adrp     x8, #0x3e73000
0339a4a0: 008d4bbd ldr      s0, [x8, #0xb8c]
0339a4a4: a109281e fmul     s1, s13, s8
0339a4a8: 21c0211e fsqrt    s1, s1
0339a4ac: ed03271e fmov     s13, wzr
0339a4b0: 2020201e fcmp     s1, s0
0339a4b4: e003271e fmov     s0, wzr
0339a4b8: ee2b00bd str      s14, [sp, #0x28]
0339a4bc: c4020054 b.mi     #0x339a514
0339a4c0: 800240f9 ldr      x0, [x20]
0339a4c4: 6009291e fmul     s0, s11, s9
0339a4c8: 42092c1e fmul     s2, s10, s12
0339a4cc: 0028221e fadd     s0, s0, s2
0339a4d0: e209231e fmul     s2, s15, s3
0339a4d4: 4028201e fadd     s0, s2, s0
0339a4d8: 08e040b9 ldr      w8, [x0, #0xe0]
0339a4dc: 0018211e fdiv     s0, s0, s1
0339a4e0: 01102e1e fmov     s1, #1.00000000
0339a4e4: 02103e1e fmov     s2, #-1.00000000
0339a4e8: 0158211e fmin     s1, s0, s1
0339a4ec: 0020221e fcmp     s0, s2
0339a4f0: 285c221e fcsel    s8, s1, s2, pl
0339a4f4: 48000035 cbnz     w8, #0x339a4fc
0339a4f8: c35b7097 bl       #0xfb1404
0339a4fc: 00c1221e fcvt     d0, s8
0339a500: 30a26497 bl       #0xcc2dc0
0339a504: c85600b0 adrp     x8, #0x3e73000
0339a508: 01914bbd ldr      s1, [x8, #0xb90]
0339a50c: 0040621e fcvt     s0, d0
0339a510: 0008211e fmul     s0, s0, s1
0339a514: 8856a852 mov      w8, #0x42b40000
0339a518: 0101271e fmov     s1, w8
0339a51c: 685600b0 adrp     x8, #0x3e67000
0339a520: ee4b40bd ldr      s14, [sp, #0x48]
0339a524: 0018211e fdiv     s0, s0, s1
0339a528: 013146bd ldr      s1, [x8, #0x630]
0339a52c: 0210301e fmov     s2, #-2.00000000
0339a530: 04102e1e fmov     s4, #1.00000000
0339a534: 685600b0 adrp     x8, #0x3e67000
0339a538: c229221e fadd     s2, s14, s2
0339a53c: 03102c1e fmov     s3, #0.50000000
0339a540: 0820201e fcmp     s0, #0.0
0339a544: 0058241e fmin     s0, s0, s4
0339a548: 4208231e fmul     s2, s2, s3
0339a54c: 039544bd ldr      s3, [x8, #0x494]
0339a550: 0008211e fmul     s0, s0, s1
0339a554: 00282d1e fadd     s0, s0, s13
0339a558: 4458241e fmin     s4, s2, s4
0339a55c: 005c2d1e fcsel    s0, s0, s13, pl
0339a560: 4820201e fcmp     s2, #0.0
0339a564: e22340bd ldr      s2, [sp, #0x20]
0339a568: 8108231e fmul     s1, s4, s3
0339a56c: 68264a2d ldp      s8, s9, [x19, #0x50]
0339a570: 6c5a40bd ldr      s12, [x19, #0x58]
0339a574: 21282d1e fadd     s1, s1, s13
0339a578: 4008201e fmul     s0, s2, s0
0339a57c: 215c2d1e fcsel    s1, s1, s13, pl
0339a580: e0031faa mov      x0, xzr
0339a584: 2d28201e fadd     s13, s1, s0
0339a588: 74620291 add      x20, x19, #0x98
0339a58c: 968e2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339a590: 08f0af52 mov      w8, #0x7f800000
0339a594: e00300bd str      s0, [sp]
0339a598: 0701271e fmov     s7, w8
0339a59c: 001da84e mov      v0.16b, v8.16b
0339a5a0: 211da94e mov      v1.16b, v9.16b
0339a5a4: 821dac4e mov      v2.16b, v12.16b
0339a5a8: 631dab4e mov      v3.16b, v11.16b
0339a5ac: 441daa4e mov      v4.16b, v10.16b
0339a5b0: e51daf4e mov      v5.16b, v15.16b
0339a5b4: e00314aa mov      x0, x20
0339a5b8: a61dad4e mov      v6.16b, v13.16b
0339a5bc: e1031faa mov      x1, xzr
0339a5c0: 09bb0594 bl       #0x35091e4 ; UnityEngine.Vector3$$SmoothDamp
0339a5c4: 680240f9 ldr      x8, [x19]
0339a5c8: 60060a2d stp      s0, s1, [x19, #0x50]
0339a5cc: 625a00bd str      s2, [x19, #0x58]
0339a5d0: e00313aa mov      x0, x19
0339a5d4: 091541f9 ldr      x9, [x8, #0x228]
0339a5d8: 011941f9 ldr      x1, [x8, #0x230]
0339a5dc: 20013fd6 blr      x9
0339a5e0: 00202e1e fcmp     s0, s14
0339a5e4: ee37452d ldp      s14, s13, [sp, #0x28]
0339a5e8: e83f40bd ldr      s8, [sp, #0x3c]
0339a5ec: e92740bd ldr      s9, [sp, #0x24]
0339a5f0: ade9ff54 b.le     #0x339a324
0339a5f4: 689640b9 ldr      w8, [x19, #0x94]
0339a5f8: 68e9ff35 cbnz     w8, #0x339a324
0339a5fc: 603640f9 ldr      x0, [x19, #0x68]
0339a600: e04b40bd ldr      s0, [sp, #0x48]
0339a604: 608e00bd str      s0, [x19, #0x8c]
0339a608: 400300b4 cbz      x0, #0x339a670
0339a60c: e1031faa mov      x1, xzr
0339a610: 5dbf2594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
0339a614: 683240f9 ldr      x8, [x19, #0x60]
0339a618: 608a00bd str      s0, [x19, #0x88]
0339a61c: a80200b4 cbz      x8, #0x339a670
0339a620: 004140f9 ldr      x0, [x8, #0x80]
0339a624: 600200b4 cbz      x0, #0x339a670
0339a628: e1031faa mov      x1, xzr
0339a62c: dfa12594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339a630: 000200b4 cbz      x0, #0x339a670
0339a634: e1031faa mov      x1, xzr
0339a638: fdbd2594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
0339a63c: 680240f9 ldr      x8, [x19]
0339a640: 49008052 mov      w9, #2
0339a644: 6086082d stp      s0, s1, [x19, #0x44]
0339a648: 624e00bd str      s2, [x19, #0x4c]
0339a64c: 699600b9 str      w9, [x19, #0x94]
0339a650: 096d41f9 ldr      x9, [x8, #0x2d8]
0339a654: 017141f9 ldr      x1, [x8, #0x2e0]
0339a658: e00313aa mov      x0, x19
0339a65c: 20013fd6 blr      x9
0339a660: 20e60737 tbnz     w0, #0, #0x339a324
0339a664: 28008052 mov      w8, #1
0339a668: 68920239 strb     w8, [x19, #0xa4]
0339a66c: 2effff17 b        #0x339a324
0339a670: 6e5b7097 bl       #0xfb1428
0339a674: 6f5b7097 bl       #0xfb1430
0339a678: 755b7097 bl       #0xfb144c
0339a67c: e1031faa mov      x1, xzr
0339a680: 5c5b7097 bl       #0xfb13f0
