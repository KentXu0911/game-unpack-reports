# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$AddExploderMetrics
# Linear span to next metadata entry; not a complete CFG.
020f7738: c0035fd6 ret      
