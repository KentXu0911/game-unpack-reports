# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerTntStrategy$$IsTntOrRocketCombo
# Linear span to next metadata entry; not a complete CFG.
033a48e8: 20008052 mov      w0, #1
033a48ec: c0035fd6 ret      
