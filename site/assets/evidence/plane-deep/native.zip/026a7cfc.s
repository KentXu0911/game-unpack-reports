# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$GetMultipleHittableMultiCellHitCount
# Linear span to next metadata entry; not a complete CFG.
026a7cfc: ffc300d1 sub      sp, sp, #0x30
026a7d00: f55301a9 stp      x21, x20, [sp, #0x10]
026a7d04: f37b02a9 stp      x19, x30, [sp, #0x20]
026a7d08: d57601b0 adrp     x21, #0x5580000
026a7d0c: a8924139 ldrb     w8, [x21, #0x64]
026a7d10: f303012a mov      w19, w1
026a7d14: f40300aa mov      x20, x0
026a7d18: c8000037 tbnz     w8, #0, #0x26a7d30
026a7d1c: e05b01f0 adrp     x0, #0x5226000
026a7d20: 00bc44f9 ldr      x0, [x0, #0x978]
026a7d24: 7725a497 bl       #0xfb1300
026a7d28: 28008052 mov      w8, #1
026a7d2c: a8920139 strb     w8, [x21, #0x64]
026a7d30: ff0f00b9 str      wzr, [sp, #0xc]
026a7d34: 802240f9 ldr      x0, [x20, #0x40]
026a7d38: 800100b4 cbz      x0, #0x26a7d68
026a7d3c: e85b01f0 adrp     x8, #0x5226000
026a7d40: 08bd44f9 ldr      x8, [x8, #0x978]
026a7d44: e2330091 add      x2, sp, #0xc
026a7d48: e103132a mov      w1, w19
026a7d4c: 030140f9 ldr      x3, [x8]
026a7d50: a1274194 bl       #0x36f1bd4 ; System.Collections.Generic.Dictionary<int, int>$$TryGetValue
026a7d54: e00f40b9 ldr      w0, [sp, #0xc]
026a7d58: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a7d5c: f55341a9 ldp      x21, x20, [sp, #0x10]
026a7d60: ffc30091 add      sp, sp, #0x30
026a7d64: c0035fd6 ret      
026a7d68: b025a497 bl       #0xfb1428
