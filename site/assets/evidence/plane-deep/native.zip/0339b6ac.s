# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$TargetChanged
# Linear span to next metadata entry; not a complete CFG.
0339b6ac: 08684339 ldrb     w8, [x0, #0xda]
0339b6b0: a8000034 cbz      w8, #0x339b6c4
0339b6b4: 087840b9 ldr      w8, [x0, #0x78]
0339b6b8: 1f050071 cmp      w8, #1
0339b6bc: 41000054 b.ne     #0x339b6c4
0339b6c0: c0035fd6 ret      
0339b6c4: 75f5ff17 b        #0x3398c98 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$TargetChanged
