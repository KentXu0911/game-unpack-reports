# Royal.Scenes.Game.Mechanics.Items.MetalCrusherItem.MetalCrusherItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e8c510: f40f1ef8 str      x20, [sp, #-0x20]!
01e8c514: f37b01a9 stp      x19, x30, [sp, #0x10]
01e8c518: 080040f9 ldr      x8, [x0]
01e8c51c: f30300aa mov      x19, x0
01e8c520: 096542f9 ldr      x9, [x8, #0x4c8]
01e8c524: 016942f9 ldr      x1, [x8, #0x4d0]
01e8c528: 20013fd6 blr      x9
01e8c52c: 680240f9 ldr      x8, [x19]
01e8c530: 1f040071 cmp      w0, #1
01e8c534: e00313aa mov      x0, x19
01e8c538: 09bd41f9 ldr      x9, [x8, #0x378]
01e8c53c: 01c141f9 ldr      x1, [x8, #0x380]
01e8c540: a8608a52 mov      w8, #0x5305
01e8c544: 4800a072 movk     w8, #2, lsl #16
01e8c548: 14019f1a csel     w20, w8, wzr, eq
01e8c54c: 20013fd6 blr      x9
01e8c550: e1031faa mov      x1, xzr
01e8c554: 0de15394 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e8c558: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e8c55c: 0000140b add      w0, w0, w20
01e8c560: f40742f8 ldr      x20, [sp], #0x20
01e8c564: c0035fd6 ret      
