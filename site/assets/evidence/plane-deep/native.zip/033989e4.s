# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_FlyState
# Linear span to next metadata entry; not a complete CFG.
033989e4: 007840b9 ldr      w0, [x0, #0x78]
033989e8: c0035fd6 ret      
