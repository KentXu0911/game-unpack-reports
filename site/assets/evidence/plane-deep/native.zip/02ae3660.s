# Royal.Scenes.Game.Mechanics.Items.ChocoMakerItem.ChocoMakerItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02ae3660: f553bea9 stp      x21, x20, [sp, #-0x20]!
02ae3664: f37b01a9 stp      x19, x30, [sp, #0x10]
02ae3668: f55401f0 adrp     x21, #0x5582000
02ae366c: a8b24939 ldrb     w8, [x21, #0x26c]
02ae3670: f303012a mov      w19, w1
02ae3674: f40300aa mov      x20, x0
02ae3678: c8000037 tbnz     w8, #0, #0x2ae3690
02ae367c: e0350190 adrp     x0, #0x519f000
02ae3680: 00f043f9 ldr      x0, [x0, #0x7e0]
02ae3684: 1f379397 bl       #0xfb1300
02ae3688: 28008052 mov      w8, #1
02ae368c: a8b20939 strb     w8, [x21, #0x26c]
02ae3690: 880a4339 ldrb     w8, [x20, #0xc2]
02ae3694: 88080034 cbz      w8, #0x2ae37a4
02ae3698: e003132a mov      w0, w19
02ae369c: e1031faa mov      x1, xzr
02ae36a0: a7842294 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02ae36a4: 60030036 tbz      w0, #0, #0x2ae3710
02ae36a8: 880240f9 ldr      x8, [x20]
02ae36ac: e00314aa mov      x0, x20
02ae36b0: 096542f9 ldr      x9, [x8, #0x4c8]
02ae36b4: 016942f9 ldr      x1, [x8, #0x4d0]
02ae36b8: 20013fd6 blr      x9
02ae36bc: 1f040071 cmp      w0, #1
02ae36c0: 41090054 b.ne     #0x2ae37e8
02ae36c4: 880240f9 ldr      x8, [x20]
02ae36c8: e00314aa mov      x0, x20
02ae36cc: 09bd41f9 ldr      x9, [x8, #0x378]
02ae36d0: 01c141f9 ldr      x1, [x8, #0x380]
02ae36d4: 20013fd6 blr      x9
02ae36d8: e1031faa mov      x1, xzr
02ae36dc: ab842294 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02ae36e0: 885a40f9 ldr      x8, [x20, #0xb0]
02ae36e4: 480900b4 cbz      x8, #0x2ae380c
02ae36e8: 080940f9 ldr      x8, [x8, #0x10]
02ae36ec: 080900b4 cbz      x8, #0x2ae380c
02ae36f0: 081940b9 ldr      w8, [x8, #0x18]
02ae36f4: 090c0011 add      w9, w0, #3
02ae36f8: 1f000071 cmp      w0, #0
02ae36fc: 29b1801a csel     w9, w9, w0, lt
02ae3700: 297d0213 asr      w9, w9, #2
02ae3704: 08050051 sub      w8, w8, #1
02ae3708: 157d091b mul      w21, w8, w9
02ae370c: 38000014 b        #0x2ae37ec
02ae3710: e003132a mov      w0, w19
02ae3714: e1031faa mov      x1, xzr
02ae3718: a5842294 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02ae371c: 40010036 tbz      w0, #0, #0x2ae3744
02ae3720: 955a40f9 ldr      x21, [x20, #0xb0]
02ae3724: e00314aa mov      x0, x20
02ae3728: e1031faa mov      x1, xzr
02ae372c: da7d2294 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02ae3730: f50600b4 cbz      x21, #0x2ae380c
02ae3734: e10300aa mov      x1, x0
02ae3738: e00315aa mov      x0, x21
02ae373c: 2afbff97 bl       #0x2ae23e4 ; Royal.Scenes.Game.Mechanics.Items.ChocoMakerItem.ChocoMakerItemHelper$$IsOneOfWiningPoints
02ae3740: e0010037 tbnz     w0, #0, #0x2ae377c
02ae3744: e003132a mov      w0, w19
02ae3748: e1031faa mov      x1, xzr
02ae374c: 069d2294 bl       #0x338ab64 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsLineExploderStrategy
02ae3750: e0020036 tbz      w0, #0, #0x2ae37ac
02ae3754: 955a40f9 ldr      x21, [x20, #0xb0]
02ae3758: e00314aa mov      x0, x20
02ae375c: e1031faa mov      x1, xzr
02ae3760: cd7d2294 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02ae3764: 550500b4 cbz      x21, #0x2ae380c
02ae3768: e20300aa mov      x2, x0
02ae376c: e00315aa mov      x0, x21
02ae3770: e103132a mov      w1, w19
02ae3774: 70faff97 bl       #0x2ae2134 ; Royal.Scenes.Game.Mechanics.Items.ChocoMakerItem.ChocoMakerItemHelper$$isOneOfWiningColumns
02ae3778: a0010036 tbz      w0, #0, #0x2ae37ac
02ae377c: e00314aa mov      x0, x20
02ae3780: b6f7ff97 bl       #0x2ae1658 ; Royal.Scenes.Game.Mechanics.Items.ChocoMakerItem.ChocoMakerItemModel$$RemainingExplodeCountOfThis
02ae3784: 1f040071 cmp      w0, #1
02ae3788: e1000054 b.ne     #0x2ae37a4
02ae378c: e103132a mov      w1, w19
02ae3790: f37b41a9 ldp      x19, x30, [sp, #0x10]
02ae3794: e00314aa mov      x0, x20
02ae3798: e2031faa mov      x2, xzr
02ae379c: f553c2a8 ldp      x21, x20, [sp], #0x20
02ae37a0: 73842214 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02ae37a4: e0031f2a mov      w0, wzr
02ae37a8: 16000014 b        #0x2ae3800
02ae37ac: 885a40f9 ldr      x8, [x20, #0xb0]
02ae37b0: e80200b4 cbz      x8, #0x2ae380c
02ae37b4: 15314239 ldrb     w21, [x8, #0x8c]
02ae37b8: e00314aa mov      x0, x20
02ae37bc: e103132a mov      w1, w19
02ae37c0: e2031faa mov      x2, xzr
02ae37c4: 6a842294 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02ae37c8: d5010034 cbz      w21, #0x2ae3800
02ae37cc: e8cc8c52 mov      w8, #0x6667
02ae37d0: c8ccac72 movk     w8, #0x6666, lsl #16
02ae37d4: 087c289b smull    x8, w0, w8
02ae37d8: 09fd7fd3 lsr      x9, x8, #0x3f
02ae37dc: 08fd6293 asr      x8, x8, #0x22
02ae37e0: 0001090b add      w0, w8, w9
02ae37e4: 07000014 b        #0x2ae3800
02ae37e8: f5031f2a mov      w21, wzr
02ae37ec: e00314aa mov      x0, x20
02ae37f0: e103132a mov      w1, w19
02ae37f4: e2031faa mov      x2, xzr
02ae37f8: 5d842294 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02ae37fc: 0000150b add      w0, w0, w21
02ae3800: f37b41a9 ldp      x19, x30, [sp, #0x10]
02ae3804: f553c2a8 ldp      x21, x20, [sp], #0x20
02ae3808: c0035fd6 ret      
02ae380c: 07379397 bl       #0xfb1428
