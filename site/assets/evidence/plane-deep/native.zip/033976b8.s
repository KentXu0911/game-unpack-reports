# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$Tap
# Linear span to next metadata entry; not a complete CFG.
033976b8: ff4302d1 sub      sp, sp, #0x90
033976bc: fe4300f9 str      x30, [sp, #0x80]
033976c0: 086440f9 ldr      x8, [x0, #0xc8]
033976c4: e80200b4 cbz      x8, #0x3397720
033976c8: 08654039 ldrb     w8, [x8, #0x19]
033976cc: 68000034 cbz      w8, #0x33976d8
033976d0: e0031f2a mov      w0, wzr
033976d4: 10000014 b        #0x3397714
033976d8: 281840f9 ldr      x8, [x1, #0x30]
033976dc: 218040ad ldp      q1, q0, [x1, #0x10]
033976e0: 2200c03d ldr      q2, [x1]
033976e4: e1030191 add      x1, sp, #0x40
033976e8: e81b00f9 str      x8, [sp, #0x30]
033976ec: e18300ad stp      q1, q0, [sp, #0x10]
033976f0: e203803d str      q2, [sp]
033976f4: 090040f9 ldr      x9, [x0]
033976f8: 2a8542f9 ldr      x10, [x9, #0x508]
033976fc: e20702ad stp      q2, q1, [sp, #0x40]
03397700: e01b803d str      q0, [sp, #0x60]
03397704: e83b00f9 str      x8, [sp, #0x70]
03397708: 228942f9 ldr      x2, [x9, #0x510]
0339770c: 40013fd6 blr      x10
03397710: 20008052 mov      w0, #1
03397714: fe4340f9 ldr      x30, [sp, #0x80]
03397718: ff430291 add      sp, sp, #0x90
0339771c: c0035fd6 ret      
03397720: 42677097 bl       #0xfb1428
