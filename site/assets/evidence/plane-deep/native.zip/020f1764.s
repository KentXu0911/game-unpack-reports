# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$HasTargetableBelowItemUnderLightball
# Linear span to next metadata entry; not a complete CFG.
020f1764: f40f1ef8 str      x20, [sp, #-0x20]!
020f1768: f37b01a9 stp      x19, x30, [sp, #0x10]
020f176c: 74a40190 adrp     x20, #0x557d000
020f1770: 88665539 ldrb     w8, [x20, #0x559]
020f1774: f30301aa mov      x19, x1
020f1778: c8000037 tbnz     w8, #0, #0x20f1790
020f177c: 208901d0 adrp     x0, #0x5217000
020f1780: 00d041f9 ldr      x0, [x0, #0x3a0]
020f1784: dffeba97 bl       #0xfb1300
020f1788: 28008052 mov      w8, #1
020f178c: 88661539 strb     w8, [x20, #0x559]
020f1790: 330700b4 cbz      x19, #0x20f1874
020f1794: 606240f9 ldr      x0, [x19, #0xc0]
020f1798: e00600b4 cbz      x0, #0x20f1874
020f179c: e1031faa mov      x1, xzr
020f17a0: ab602794 bl       #0x2ac9a4c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasAboveItem
020f17a4: 60050037 tbnz     w0, #0, #0x20f1850
020f17a8: 600a40f9 ldr      x0, [x19, #0x10]
020f17ac: 400600b4 cbz      x0, #0x20f1874
020f17b0: e1031faa mov      x1, xzr
020f17b4: b2511994 bl       #0x2745e7c ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$HasCurrentItem
020f17b8: c0040036 tbz      w0, #0, #0x20f1850
020f17bc: 600a40f9 ldr      x0, [x19, #0x10]
020f17c0: a00500b4 cbz      x0, #0x20f1874
020f17c4: e1031faa mov      x1, xzr
020f17c8: a6511994 bl       #0x2745e60 ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$get_CurrentItem
020f17cc: 400500b4 cbz      x0, #0x20f1874
020f17d0: 080040f9 ldr      x8, [x0]
020f17d4: 09bd41f9 ldr      x9, [x8, #0x378]
020f17d8: 01c141f9 ldr      x1, [x8, #0x380]
020f17dc: 20013fd6 blr      x9
020f17e0: 1f140071 cmp      w0, #5
020f17e4: 61030054 b.ne     #0x20f1850
020f17e8: 606240f9 ldr      x0, [x19, #0xc0]
020f17ec: 400400b4 cbz      x0, #0x20f1874
020f17f0: e1031faa mov      x1, xzr
020f17f4: aa602794 bl       #0x2ac9a9c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasBelowItem
020f17f8: c0020036 tbz      w0, #0, #0x20f1850
020f17fc: 606240f9 ldr      x0, [x19, #0xc0]
020f1800: a00300b4 cbz      x0, #0x20f1874
020f1804: e1031faa mov      x1, xzr
020f1808: b9602794 bl       #0x2ac9aec ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$GetTopMostBelowItem
020f180c: e00100b4 cbz      x0, #0x20f1848
020f1810: 288901d0 adrp     x8, #0x5217000
020f1814: 08d141f9 ldr      x8, [x8, #0x3a0]
020f1818: 090040f9 ldr      x9, [x0]
020f181c: 080140f9 ldr      x8, [x8]
020f1820: 2bb14439 ldrb     w11, [x9, #0x12c]
020f1824: 0ab14439 ldrb     w10, [x8, #0x12c]
020f1828: 7f010a6b cmp      w11, w10
020f182c: e3000054 b.lo     #0x20f1848
020f1830: 296540f9 ldr      x9, [x9, #0xc8]
020f1834: 290d0a8b add      x9, x9, x10, lsl #3
020f1838: 29815ff8 ldur     x9, [x9, #-8]
020f183c: 3f0108eb cmp      x9, x8
020f1840: 00009f9a csel     x0, x0, xzr, eq
020f1844: e0000054 b.eq     #0x20f1860
020f1848: 20008052 mov      w0, #1
020f184c: 02000014 b        #0x20f1854
020f1850: e0031f2a mov      w0, wzr
020f1854: f37b41a9 ldp      x19, x30, [sp, #0x10]
020f1858: f40742f8 ldr      x20, [sp], #0x20
020f185c: c0035fd6 ret      
020f1860: a00000b4 cbz      x0, #0x20f1874
020f1864: f37b41a9 ldp      x19, x30, [sp, #0x10]
020f1868: e1031faa mov      x1, xzr
020f186c: f40742f8 ldr      x20, [sp], #0x20
020f1870: 7fabc917 b        #0x135c66c ; Royal.Scenes.Game.Mechanics.Items.StaticItems.JellyItem.JellyItemModel$$IsLogicActive
020f1874: edfeba97 bl       #0xfb1428
