# Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$IsThereAnyExplodeCacheInvalidatingOperation
# Linear span to next metadata entry; not a complete CFG.
02acf114: f40f1ef8 str      x20, [sp, #-0x20]!
02acf118: f37b01a9 stp      x19, x30, [sp, #0x10]
02acf11c: 945501f0 adrp     x20, #0x5582000
02acf120: 88ba4639 ldrb     w8, [x20, #0x1ae]
02acf124: f30300aa mov      x19, x0
02acf128: 28010037 tbnz     w8, #0, #0x2acf14c
02acf12c: c03a0190 adrp     x0, #0x5227000
02acf130: 008c44f9 ldr      x0, [x0, #0x918]
02acf134: 73889397 bl       #0xfb1300
02acf138: e03801d0 adrp     x0, #0x51ed000
02acf13c: 006c44f9 ldr      x0, [x0, #0x8d8]
02acf140: 70889397 bl       #0xfb1300
02acf144: 28008052 mov      w8, #1
02acf148: 88ba0639 strb     w8, [x20, #0x1ae]
02acf14c: 601640f9 ldr      x0, [x19, #0x28]
02acf150: 800400b4 cbz      x0, #0x2acf1e0
02acf154: 01098052 mov      w1, #0x48
02acf158: e2031faa mov      x2, xzr
02acf15c: 7c2ed697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
02acf160: 80010036 tbz      w0, #0, #0x2acf190
02acf164: c83a0190 adrp     x8, #0x5227000
02acf168: 088d44f9 ldr      x8, [x8, #0x918]
02acf16c: 60098052 mov      w0, #0x4b
02acf170: 010140f9 ldr      x1, [x8]
02acf174: 3ebee997 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
02acf178: 400300b4 cbz      x0, #0x2acf1e0
02acf17c: e1031faa mov      x1, xzr
02acf180: a2840a94 bl       #0x2d70408 ; Royal.Scenes.Game.Mechanics.Items.FurnaceItem.FurnaceItemHelper$$get_IsAnyFurnaceThrowing
02acf184: 60000036 tbz      w0, #0, #0x2acf190
02acf188: 20008052 mov      w0, #1
02acf18c: 12000014 b        #0x2acf1d4
02acf190: 601640f9 ldr      x0, [x19, #0x28]
02acf194: 600200b4 cbz      x0, #0x2acf1e0
02acf198: e10c8052 mov      w1, #0x67
02acf19c: e2031faa mov      x2, xzr
02acf1a0: 6b2ed697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
02acf1a4: 60010036 tbz      w0, #0, #0x2acf1d0
02acf1a8: e83801d0 adrp     x8, #0x51ed000
02acf1ac: 086d44f9 ldr      x8, [x8, #0x8d8]
02acf1b0: 600c8052 mov      w0, #0x63
02acf1b4: 010140f9 ldr      x1, [x8]
02acf1b8: 2dbee997 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
02acf1bc: 200100b4 cbz      x0, #0x2acf1e0
02acf1c0: f37b41a9 ldp      x19, x30, [sp, #0x10]
02acf1c4: e1031faa mov      x1, xzr
02acf1c8: f40742f8 ldr      x20, [sp], #0x20
02acf1cc: a80cd717 b        #0x209246c ; Royal.Scenes.Game.Mechanics.Items.RadarItem.RadarItemHelper$$get_IsAnyRadarThrowing
02acf1d0: e0031f2a mov      w0, wzr
02acf1d4: f37b41a9 ldp      x19, x30, [sp, #0x10]
02acf1d8: f40742f8 ldr      x20, [sp], #0x20
02acf1dc: c0035fd6 ret      
02acf1e0: 92889397 bl       #0xfb1428
