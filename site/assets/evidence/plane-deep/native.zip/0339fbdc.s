# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeScaleUp
# Linear span to next metadata entry; not a complete CFG.
0339fbdc: ff4302d1 sub      sp, sp, #0x90
0339fbe0: ef3b036d stp      d15, d14, [sp, #0x30]
0339fbe4: ed33046d stp      d13, d12, [sp, #0x40]
0339fbe8: eb2b056d stp      d11, d10, [sp, #0x50]
0339fbec: e923066d stp      d9, d8, [sp, #0x60]
0339fbf0: f55307a9 stp      x21, x20, [sp, #0x70]
0339fbf4: f37b08a9 stp      x19, x30, [sp, #0x80]
0339fbf8: 340f01f0 adrp     x20, #0x5586000
0339fbfc: 88ee6639 ldrb     w8, [x20, #0x9bb]
0339fc00: ab1ca54e mov      v11.16b, v5.16b
0339fc04: 8a1ca44e mov      v10.16b, v4.16b
0339fc08: 681ca34e mov      v8.16b, v3.16b
0339fc0c: 4c1ca24e mov      v12.16b, v2.16b
0339fc10: 2d1ca14e mov      v13.16b, v1.16b
0339fc14: 091ca04e mov      v9.16b, v0.16b
0339fc18: f30300aa mov      x19, x0
0339fc1c: e61300bd str      s6, [sp, #0x10]
0339fc20: c8000037 tbnz     w8, #0, #0x339fc38
0339fc24: 40f200d0 adrp     x0, #0x51e9000
0339fc28: 00ec44f9 ldr      x0, [x0, #0x9d8]
0339fc2c: b5457097 bl       #0xfb1300
0339fc30: 28008052 mov      w8, #1
0339fc34: 88ee2639 strb     w8, [x20, #0x9bb]
0339fc38: 742e40f9 ldr      x20, [x19, #0x58]
0339fc3c: e0031faa mov      x0, xzr
0339fc40: e9782594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339fc44: f50e01d0 adrp     x21, #0x557d000
0339fc48: a8ba5f39 ldrb     w8, [x21, #0x7ee]
0339fc4c: 0f1ca04e mov      v15.16b, v0.16b
0339fc50: c8000035 cbnz     w8, #0x339fc68
0339fc54: 00f300b0 adrp     x0, #0x5200000
0339fc58: 008c46f9 ldr      x0, [x0, #0xd18]
0339fc5c: a9457097 bl       #0xfb1300
0339fc60: 28008052 mov      w8, #1
0339fc64: a8ba1f39 strb     w8, [x21, #0x7ee]
0339fc68: e82f00bd str      s8, [sp, #0x2c]
0339fc6c: 2839281e fsub     s8, s9, s8
0339fc70: 431daa4e mov      v3.16b, v10.16b
0339fc74: aa392a1e fsub     s10, s13, s10
0339fc78: 8e392b1e fsub     s14, s12, s11
0339fc7c: 0009281e fmul     s0, s8, s8
0339fc80: 41092a1e fmul     s1, s10, s10
0339fc84: 0028211e fadd     s0, s0, s1
0339fc88: c1092e1e fmul     s1, s14, s14
0339fc8c: 621dab4e mov      v2.16b, v11.16b
0339fc90: 2b28201e fadd     s11, s1, s0
0339fc94: 6821201e fcmp     s11, #0.0
0339fc98: 81000054 b.ne     #0x339fca8
0339fc9c: 201da94e mov      v0.16b, v9.16b
0339fca0: f40300b5 cbnz     x20, #0x339fd1c
0339fca4: 76000014 b        #0x339fe7c
0339fca8: e01340bd ldr      s0, [sp, #0x10]
0339fcac: e30b012d stp      s3, s2, [sp, #8]
0339fcb0: ef09201e fmul     s15, s15, s0
0339fcb4: e821201e fcmp     s15, #0.0
0339fcb8: ab000054 b.lt     #0x339fccc
0339fcbc: e0092f1e fmul     s0, s15, s15
0339fcc0: 6021201e fcmp     s11, s0
0339fcc4: 201da94e mov      v0.16b, v9.16b
0339fcc8: 89020054 b.ls     #0x339fd18
0339fccc: 08f300b0 adrp     x8, #0x5200000
0339fcd0: 088d46f9 ldr      x8, [x8, #0xd18]
0339fcd4: 000140f9 ldr      x0, [x8]
0339fcd8: 08e040b9 ldr      w8, [x0, #0xe0]
0339fcdc: 48000035 cbnz     w8, #0x339fce4
0339fce0: c9457097 bl       #0xfb1404
0339fce4: 60c1211e fsqrt    s0, s11
0339fce8: 0119201e fdiv     s1, s8, s0
0339fcec: 4219201e fdiv     s2, s10, s0
0339fcf0: c019201e fdiv     s0, s14, s0
0339fcf4: 03082f1e fmul     s3, s0, s15
0339fcf8: e02f40bd ldr      s0, [sp, #0x2c]
0339fcfc: 21082f1e fmul     s1, s1, s15
0339fd00: 42082f1e fmul     s2, s2, s15
0339fd04: 0028211e fadd     s0, s0, s1
0339fd08: e10b40bd ldr      s1, [sp, #8]
0339fd0c: 2d28221e fadd     s13, s1, s2
0339fd10: e10f40bd ldr      s1, [sp, #0xc]
0339fd14: 2c28231e fadd     s12, s1, s3
0339fd18: 340b00b4 cbz      x20, #0x339fe7c
0339fd1c: 55f200d0 adrp     x21, #0x51e9000
0339fd20: b5ee44f9 ldr      x21, [x21, #0x9d8]
0339fd24: e00314aa mov      x0, x20
0339fd28: a11dad4e mov      v1.16b, v13.16b
0339fd2c: 821dac4e mov      v2.16b, v12.16b
0339fd30: e1031faa mov      x1, xzr
0339fd34: bca92594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
0339fd38: b40e01f0 adrp     x20, #0x5576000
0339fd3c: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339fd40: c8000035 cbnz     w8, #0x339fd58
0339fd44: 60f40090 adrp     x0, #0x522b000
0339fd48: 00ac43f9 ldr      x0, [x0, #0x758]
0339fd4c: 6d457097 bl       #0xfb1300
0339fd50: 28008052 mov      w8, #1
0339fd54: 88b23c39 strb     w8, [x20, #0xf2c]
0339fd58: 68f40090 adrp     x8, #0x522b000
0339fd5c: 08ad43f9 ldr      x8, [x8, #0x758]
0339fd60: a00240f9 ldr      x0, [x21]
0339fd64: 080140f9 ldr      x8, [x8]
0339fd68: 09e040b9 ldr      w9, [x0, #0xe0]
0339fd6c: 085d40f9 ldr      x8, [x8, #0xb8]
0339fd70: 0b0140fd ldr      d11, [x8]
0339fd74: 0a0940bd ldr      s10, [x8, #8]
0339fd78: 69000035 cbnz     w9, #0x339fd84
0339fd7c: a2457097 bl       #0xfb1404
0339fd80: a00240f9 ldr      x0, [x21]
0339fd84: 00103e1e fmov     s0, #-1.00000000
0339fd88: 2029201e fadd     s0, s9, s0
0339fd8c: 01102e1e fmov     s1, #1.00000000
0339fd90: 682a40f9 ldr      x8, [x19, #0x50]
0339fd94: 0019201e fdiv     s0, s8, s0
0339fd98: 2038201e fsub     s0, s1, s0
0339fd9c: 0158211e fmin     s1, s0, s1
0339fda0: 0820201e fcmp     s0, #0.0
0339fda4: e003271e fmov     s0, wzr
0339fda8: 205c201e fcsel    s0, s1, s0, pl
0339fdac: 880600b4 cbz      x8, #0x339fe7c
0339fdb0: 084140f9 ldr      x8, [x8, #0x80]
0339fdb4: e007803d str      q0, [sp, #0x10]
0339fdb8: 280600b4 cbz      x8, #0x339fe7c
0339fdbc: 095c40f9 ldr      x9, [x0, #0xb8]
0339fdc0: e00308aa mov      x0, x8
0339fdc4: e1031faa mov      x1, xzr
0339fdc8: 290140fd ldr      d9, [x9]
0339fdcc: 280940bd ldr      s8, [x9, #8]
0339fdd0: f68b2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339fdd4: 682e40f9 ldr      x8, [x19, #0x58]
0339fdd8: 280500b4 cbz      x8, #0x339fe7c
0339fddc: f40300aa mov      x20, x0
0339fde0: e00308aa mov      x0, x8
0339fde4: e1031faa mov      x1, xzr
0339fde8: c3a72594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339fdec: 940400b4 cbz      x20, #0x339fe7c
0339fdf0: e507c03d ldr      q5, [sp, #0x10]
0339fdf4: 23d5ab0e fsub     v3.2s, v9.2s, v11.2s
0339fdf8: 04392a1e fsub     s4, s8, s10
0339fdfc: 20040c6e mov      v0.s[1], v1.s[0]
0339fe00: 6190850f fmul     v1.2s, v3.2s, v5.s[0]
0339fe04: a308241e fmul     s3, s5, s4
0339fe08: 61d5210e fadd     v1.2s, v11.2s, v1.2s
0339fe0c: 4329231e fadd     s3, s10, s3
0339fe10: 20d4200e fadd     v0.2s, v1.2s, v0.2s
0339fe14: 6228221e fadd     s2, s3, s2
0339fe18: 01040c5e mov      s1, v0.s[1]
0339fe1c: e00314aa mov      x0, x20
0339fe20: e1031faa mov      x1, xzr
0339fe24: dca72594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
0339fe28: a8560090 adrp     x8, #0x3e73000
0339fe2c: 49560090 adrp     x9, #0x3e67000
0339fe30: 09a548bd ldr      s9, [x8, #0x8a4]
0339fe34: e82f40bd ldr      s8, [sp, #0x2c]
0339fe38: 224944bd ldr      s2, [x9, #0x448]
0339fe3c: e0031faa mov      x0, xzr
0339fe40: 211da94e mov      v1.16b, v9.16b
0339fe44: 001da84e mov      v0.16b, v8.16b
0339fe48: bf7afb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339fe4c: 0021291e fcmp     s8, s9
0339fe50: 4c000054 b.gt     #0x339fe58
0339fe54: 40000036 tbz      w0, #0, #0x339fe5c
0339fe58: 7f7e00b9 str      wzr, [x19, #0x7c]
0339fe5c: f37b48a9 ldp      x19, x30, [sp, #0x80]
0339fe60: f55347a9 ldp      x21, x20, [sp, #0x70]
0339fe64: e923466d ldp      d9, d8, [sp, #0x60]
0339fe68: eb2b456d ldp      d11, d10, [sp, #0x50]
0339fe6c: ed33446d ldp      d13, d12, [sp, #0x40]
0339fe70: ef3b436d ldp      d15, d14, [sp, #0x30]
0339fe74: ff430291 add      sp, sp, #0x90
0339fe78: c0035fd6 ret      
0339fe7c: 6b457097 bl       #0xfb1428
