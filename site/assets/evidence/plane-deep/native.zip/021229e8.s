# Royal.Scenes.Game.Mechanics.Items.IceCubeItem.IceCubeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
021229e8: f553bea9 stp      x21, x20, [sp, #-0x20]!
021229ec: f37b01a9 stp      x19, x30, [sp, #0x10]
021229f0: 080040f9 ldr      x8, [x0]
021229f4: f403012a mov      w20, w1
021229f8: f30300aa mov      x19, x0
021229fc: 096542f9 ldr      x9, [x8, #0x4c8]
02122a00: 086942f9 ldr      x8, [x8, #0x4d0]
02122a04: e10308aa mov      x1, x8
02122a08: 20013fd6 blr      x9
02122a0c: f503002a mov      w21, w0
02122a10: e003142a mov      w0, w20
02122a14: e1031faa mov      x1, xzr
02122a18: e5874994 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02122a1c: c0000036 tbz      w0, #0, #0x2122a34
02122a20: 08918f52 mov      w8, #0x7c88
02122a24: bf020071 cmp      w21, #0
02122a28: 6800a072 movk     w8, #3, lsl #16
02122a2c: 00c19f1a csel     w0, w8, wzr, gt
02122a30: 10000014 b        #0x2122a70
02122a34: bf060071 cmp      w21, #1
02122a38: ab010054 b.lt     #0x2122a6c
02122a3c: e00313aa mov      x0, x19
02122a40: e1031faa mov      x1, xzr
02122a44: 14814994 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02122a48: c00200b4 cbz      x0, #0x2122aa0
02122a4c: 08004239 ldrb     w8, [x0, #0x80]
02122a50: 68010034 cbz      w8, #0x2122a7c
02122a54: e00313aa mov      x0, x19
02122a58: f37b41a9 ldp      x19, x30, [sp, #0x10]
02122a5c: e103142a mov      w1, w20
02122a60: e2031faa mov      x2, xzr
02122a64: f553c2a8 ldp      x21, x20, [sp], #0x20
02122a68: 8abc4914 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
02122a6c: e0031f2a mov      w0, wzr
02122a70: f37b41a9 ldp      x19, x30, [sp, #0x10]
02122a74: f553c2a8 ldp      x21, x20, [sp], #0x20
02122a78: c0035fd6 ret      
02122a7c: 680240f9 ldr      x8, [x19]
02122a80: e00313aa mov      x0, x19
02122a84: 09bd41f9 ldr      x9, [x8, #0x378]
02122a88: 01c141f9 ldr      x1, [x8, #0x380]
02122a8c: 20013fd6 blr      x9
02122a90: f37b41a9 ldp      x19, x30, [sp, #0x10]
02122a94: e1031faa mov      x1, xzr
02122a98: f553c2a8 ldp      x21, x20, [sp], #0x20
02122a9c: bb874914 b        #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02122aa0: 623aba97 bl       #0xfb1428
