# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$.cctor
# Linear span to next metadata entry; not a complete CFG.
03398798: fa0f1bf8 str      x26, [sp, #-0x50]!
0339879c: f96301a9 stp      x25, x24, [sp, #0x10]
033987a0: f75b02a9 stp      x23, x22, [sp, #0x20]
033987a4: f55303a9 stp      x21, x20, [sp, #0x30]
033987a8: f37b04a9 stp      x19, x30, [sp, #0x40]
033987ac: 790f01d0 adrp     x25, #0x5586000
033987b0: daf200b0 adrp     x26, #0x51f1000
033987b4: f3f10090 adrp     x19, #0x51d4000
033987b8: 38f30090 adrp     x24, #0x51fc000
033987bc: d7f400b0 adrp     x23, #0x5231000
033987c0: d6ef0090 adrp     x22, #0x5190000
033987c4: 75f100b0 adrp     x21, #0x51c5000
033987c8: 14f300b0 adrp     x20, #0x51f9000
033987cc: 5a1b46f9 ldr      x26, [x26, #0xc30]
033987d0: 73da41f9 ldr      x19, [x19, #0x3b0]
033987d4: 286f6639 ldrb     w8, [x25, #0x99b]
033987d8: 18ff45f9 ldr      x24, [x24, #0xbf8]
033987dc: f72645f9 ldr      x23, [x23, #0xa48]
033987e0: d69240f9 ldr      x22, [x22, #0x120]
033987e4: b51a40f9 ldr      x21, [x21, #0x30]
033987e8: 94fe40f9 ldr      x20, [x20, #0x1f8]
033987ec: 08030037 tbnz     w8, #0, #0x339884c
033987f0: e0f10090 adrp     x0, #0x51d4000
033987f4: 00d841f9 ldr      x0, [x0, #0x3b0]
033987f8: c2627097 bl       #0xfb1300
033987fc: 20f30090 adrp     x0, #0x51fc000
03398800: 00fc45f9 ldr      x0, [x0, #0xbf8]
03398804: bf627097 bl       #0xfb1300
03398808: 00f300b0 adrp     x0, #0x51f9000
0339880c: 00fc40f9 ldr      x0, [x0, #0x1f8]
03398810: bc627097 bl       #0xfb1300
03398814: c0f200b0 adrp     x0, #0x51f1000
03398818: 001846f9 ldr      x0, [x0, #0xc30]
0339881c: b9627097 bl       #0xfb1300
03398820: 60f100b0 adrp     x0, #0x51c5000
03398824: 001840f9 ldr      x0, [x0, #0x30]
03398828: b6627097 bl       #0xfb1300
0339882c: c0ef0090 adrp     x0, #0x5190000
03398830: 009040f9 ldr      x0, [x0, #0x120]
03398834: b3627097 bl       #0xfb1300
03398838: c0f400b0 adrp     x0, #0x5231000
0339883c: 002445f9 ldr      x0, [x0, #0xa48]
03398840: b0627097 bl       #0xfb1300
03398844: 28008052 mov      w8, #1
03398848: 286f2639 strb     w8, [x25, #0x99b]
0339884c: 400340f9 ldr      x0, [x26]
03398850: e1031faa mov      x1, xzr
03398854: e6c5a897 bl       #0x1dc9fec ; UnityEngine.Animator$$StringToHash
03398858: 680240f9 ldr      x8, [x19]
0339885c: e1031faa mov      x1, xzr
03398860: 085d40f9 ldr      x8, [x8, #0xb8]
03398864: 000100b9 str      w0, [x8]
03398868: 000340f9 ldr      x0, [x24]
0339886c: e0c5a897 bl       #0x1dc9fec ; UnityEngine.Animator$$StringToHash
03398870: 680240f9 ldr      x8, [x19]
03398874: e1031faa mov      x1, xzr
03398878: 085d40f9 ldr      x8, [x8, #0xb8]
0339887c: 000500b9 str      w0, [x8, #4]
03398880: e00240f9 ldr      x0, [x23]
03398884: dac5a897 bl       #0x1dc9fec ; UnityEngine.Animator$$StringToHash
03398888: 680240f9 ldr      x8, [x19]
0339888c: e1031faa mov      x1, xzr
03398890: 085d40f9 ldr      x8, [x8, #0xb8]
03398894: 000900b9 str      w0, [x8, #8]
03398898: c00240f9 ldr      x0, [x22]
0339889c: d4c5a897 bl       #0x1dc9fec ; UnityEngine.Animator$$StringToHash
033988a0: 680240f9 ldr      x8, [x19]
033988a4: e1031faa mov      x1, xzr
033988a8: 085d40f9 ldr      x8, [x8, #0xb8]
033988ac: 000d00b9 str      w0, [x8, #0xc]
033988b0: a00240f9 ldr      x0, [x21]
033988b4: cec5a897 bl       #0x1dc9fec ; UnityEngine.Animator$$StringToHash
033988b8: 680240f9 ldr      x8, [x19]
033988bc: e1031faa mov      x1, xzr
033988c0: 085d40f9 ldr      x8, [x8, #0xb8]
033988c4: 001100b9 str      w0, [x8, #0x10]
033988c8: 800240f9 ldr      x0, [x20]
033988cc: c8c5a897 bl       #0x1dc9fec ; UnityEngine.Animator$$StringToHash
033988d0: 680240f9 ldr      x8, [x19]
033988d4: 085d40f9 ldr      x8, [x8, #0xb8]
033988d8: 001500b9 str      w0, [x8, #0x14]
033988dc: f37b44a9 ldp      x19, x30, [sp, #0x40]
033988e0: f55343a9 ldp      x21, x20, [sp, #0x30]
033988e4: f75b42a9 ldp      x23, x22, [sp, #0x20]
033988e8: f96341a9 ldp      x25, x24, [sp, #0x10]
033988ec: fa0745f8 ldr      x26, [sp], #0x50
033988f0: c0035fd6 ret      
