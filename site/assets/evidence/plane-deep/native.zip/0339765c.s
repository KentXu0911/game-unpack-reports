# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$CanReceiveAboveStaticItem
# Linear span to next metadata entry; not a complete CFG.
0339765c: 08f04239 ldrb     w8, [x0, #0xbc]
03397660: 1f010071 cmp      w8, #0
03397664: e0179f1a cset     w0, eq
03397668: c0035fd6 ret      
