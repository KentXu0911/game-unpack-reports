# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScaleUp
# Linear span to next metadata entry; not a complete CFG.
0339abfc: ff4302d1 sub      sp, sp, #0x90
0339ac00: ef3b026d stp      d15, d14, [sp, #0x20]
0339ac04: ed33036d stp      d13, d12, [sp, #0x30]
0339ac08: eb2b046d stp      d11, d10, [sp, #0x40]
0339ac0c: e923056d stp      d9, d8, [sp, #0x50]
0339ac10: f75b06a9 stp      x23, x22, [sp, #0x60]
0339ac14: f55307a9 stp      x21, x20, [sp, #0x70]
0339ac18: f37b08a9 stp      x19, x30, [sp, #0x80]
0339ac1c: 740f0190 adrp     x20, #0x5586000
0339ac20: 88926639 ldrb     w8, [x20, #0x9a4]
0339ac24: a91ca54e mov      v9.16b, v5.16b
0339ac28: 8b1ca44e mov      v11.16b, v4.16b
0339ac2c: 681ca34e mov      v8.16b, v3.16b
0339ac30: 4c1ca24e mov      v12.16b, v2.16b
0339ac34: 2d1ca14e mov      v13.16b, v1.16b
0339ac38: 0e1ca04e mov      v14.16b, v0.16b
0339ac3c: f30300aa mov      x19, x0
0339ac40: e61b00bd str      s6, [sp, #0x18]
0339ac44: c8000037 tbnz     w8, #0, #0x339ac5c
0339ac48: e0f200b0 adrp     x0, #0x51f7000
0339ac4c: 00f844f9 ldr      x0, [x0, #0x9f0]
0339ac50: ac597097 bl       #0xfb1300
0339ac54: 28008052 mov      w8, #1
0339ac58: 88922639 strb     w8, [x20, #0x9a4]
0339ac5c: 743640f9 ldr      x20, [x19, #0x68]
0339ac60: e0031faa mov      x0, xzr
0339ac64: e08c2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339ac68: 160f01f0 adrp     x22, #0x557d000
0339ac6c: c8ba5f39 ldrb     w8, [x22, #0x7ee]
0339ac70: 0f1ca04e mov      v15.16b, v0.16b
0339ac74: c8000035 cbnz     w8, #0x339ac8c
0339ac78: 20f300d0 adrp     x0, #0x5200000
0339ac7c: 008c46f9 ldr      x0, [x0, #0xd18]
0339ac80: a0597097 bl       #0xfb1300
0339ac84: 28008052 mov      w8, #1
0339ac88: c8ba1f39 strb     w8, [x22, #0x7ee]
0339ac8c: e81f00bd str      s8, [sp, #0x1c]
0339ac90: ca39281e fsub     s10, s14, s8
0339ac94: a8392b1e fsub     s8, s13, s11
0339ac98: 35f300d0 adrp     x21, #0x5200000
0339ac9c: 221da94e mov      v2.16b, v9.16b
0339aca0: 8939291e fsub     s9, s12, s9
0339aca4: 40092a1e fmul     s0, s10, s10
0339aca8: 0109281e fmul     s1, s8, s8
0339acac: b58e46f9 ldr      x21, [x21, #0xd18]
0339acb0: 0028211e fadd     s0, s0, s1
0339acb4: 2109291e fmul     s1, s9, s9
0339acb8: 631dab4e mov      v3.16b, v11.16b
0339acbc: 2b28201e fadd     s11, s1, s0
0339acc0: 6821201e fcmp     s11, #0.0
0339acc4: 40030054 b.eq     #0x339ad2c
0339acc8: e01b40bd ldr      s0, [sp, #0x18]
0339accc: e30b022d stp      s3, s2, [sp, #0x10]
0339acd0: ef09201e fmul     s15, s15, s0
0339acd4: e821201e fcmp     s15, #0.0
0339acd8: 8b000054 b.lt     #0x339ace8
0339acdc: e0092f1e fmul     s0, s15, s15
0339ace0: 6021201e fcmp     s11, s0
0339ace4: 49020054 b.ls     #0x339ad2c
0339ace8: a00240f9 ldr      x0, [x21]
0339acec: 08e040b9 ldr      w8, [x0, #0xe0]
0339acf0: 48000035 cbnz     w8, #0x339acf8
0339acf4: c4597097 bl       #0xfb1404
0339acf8: e31f40bd ldr      s3, [sp, #0x1c]
0339acfc: 60c1211e fsqrt    s0, s11
0339ad00: 4119201e fdiv     s1, s10, s0
0339ad04: 21082f1e fmul     s1, s1, s15
0339ad08: 6e28211e fadd     s14, s3, s1
0339ad0c: e11340bd ldr      s1, [sp, #0x10]
0339ad10: 0219201e fdiv     s2, s8, s0
0339ad14: 42082f1e fmul     s2, s2, s15
0339ad18: 2019201e fdiv     s0, s9, s0
0339ad1c: 2d28221e fadd     s13, s1, s2
0339ad20: e11740bd ldr      s1, [sp, #0x14]
0339ad24: 00082f1e fmul     s0, s0, s15
0339ad28: 2c28201e fadd     s12, s1, s0
0339ad2c: 340e00b4 cbz      x20, #0x339aef0
0339ad30: e00314aa mov      x0, x20
0339ad34: c01dae4e mov      v0.16b, v14.16b
0339ad38: a11dad4e mov      v1.16b, v13.16b
0339ad3c: 821dac4e mov      v2.16b, v12.16b
0339ad40: e1031faa mov      x1, xzr
0339ad44: b8bd2594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
0339ad48: 683240f9 ldr      x8, [x19, #0x60]
0339ad4c: 280d00b4 cbz      x8, #0x339aef0
0339ad50: 004140f9 ldr      x0, [x8, #0x80]
0339ad54: e00c00b4 cbz      x0, #0x339aef0
0339ad58: e1031faa mov      x1, xzr
0339ad5c: 13a02594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339ad60: 683240f9 ldr      x8, [x19, #0x60]
0339ad64: 680c00b4 cbz      x8, #0x339aef0
0339ad68: f40300aa mov      x20, x0
0339ad6c: 004140f9 ldr      x0, [x8, #0x80]
0339ad70: 000c00b4 cbz      x0, #0x339aef0
0339ad74: e1031faa mov      x1, xzr
0339ad78: 0ca02594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339ad7c: a00b00b4 cbz      x0, #0x339aef0
0339ad80: f7f200b0 adrp     x23, #0x51f7000
0339ad84: f7fa44f9 ldr      x23, [x23, #0x9f0]
0339ad88: e1031faa mov      x1, xzr
0339ad8c: 28bc2594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
0339ad90: e00240f9 ldr      x0, [x23]
0339ad94: 081ca04e mov      v8.16b, v0.16b
0339ad98: 2a1ca14e mov      v10.16b, v1.16b
0339ad9c: 4c1ca24e mov      v12.16b, v2.16b
0339ada0: 08e040b9 ldr      w8, [x0, #0xe0]
0339ada4: 68000035 cbnz     w8, #0x339adb0
0339ada8: 97597097 bl       #0xfb1404
0339adac: e00240f9 ldr      x0, [x23]
0339adb0: 085c40f9 ldr      x8, [x0, #0xb8]
0339adb4: e0031faa mov      x0, xzr
0339adb8: 0d39402d ldp      s13, s14, [x8]
0339adbc: 0f0940bd ldr      s15, [x8, #8]
0339adc0: 898c2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339adc4: c8ba5f39 ldrb     w8, [x22, #0x7ee]
0339adc8: 091ca04e mov      v9.16b, v0.16b
0339adcc: c8000035 cbnz     w8, #0x339ade4
0339add0: 20f300d0 adrp     x0, #0x5200000
0339add4: 008c46f9 ldr      x0, [x0, #0xd18]
0339add8: 4a597097 bl       #0xfb1300
0339addc: 28008052 mov      w8, #1
0339ade0: c8ba1f39 strb     w8, [x22, #0x7ee]
0339ade4: ab39281e fsub     s11, s13, s8
0339ade8: 431daa4e mov      v3.16b, v10.16b
0339adec: ca392a1e fsub     s10, s14, s10
0339adf0: 021da84e mov      v2.16b, v8.16b
0339adf4: e8392c1e fsub     s8, s15, s12
0339adf8: 60092b1e fmul     s0, s11, s11
0339adfc: 41092a1e fmul     s1, s10, s10
0339ae00: 0028211e fadd     s0, s0, s1
0339ae04: 0109281e fmul     s1, s8, s8
0339ae08: 841dac4e mov      v4.16b, v12.16b
0339ae0c: 2c28201e fadd     s12, s1, s0
0339ae10: 8821201e fcmp     s12, #0.0
0339ae14: 60030054 b.eq     #0x339ae80
0339ae18: e01b40bd ldr      s0, [sp, #0x18]
0339ae1c: e48f012d stp      s4, s3, [sp, #0xc]
0339ae20: e21700bd str      s2, [sp, #0x14]
0339ae24: 2909201e fmul     s9, s9, s0
0339ae28: 2821201e fcmp     s9, #0.0
0339ae2c: 8b000054 b.lt     #0x339ae3c
0339ae30: 2009291e fmul     s0, s9, s9
0339ae34: 8021201e fcmp     s12, s0
0339ae38: 49020054 b.ls     #0x339ae80
0339ae3c: a00240f9 ldr      x0, [x21]
0339ae40: 08e040b9 ldr      w8, [x0, #0xe0]
0339ae44: 48000035 cbnz     w8, #0x339ae4c
0339ae48: 6f597097 bl       #0xfb1404
0339ae4c: e31740bd ldr      s3, [sp, #0x14]
0339ae50: 80c1211e fsqrt    s0, s12
0339ae54: 6119201e fdiv     s1, s11, s0
0339ae58: 2109211e fmul     s1, s9, s1
0339ae5c: 6d28211e fadd     s13, s3, s1
0339ae60: e11340bd ldr      s1, [sp, #0x10]
0339ae64: 4219201e fdiv     s2, s10, s0
0339ae68: 2209221e fmul     s2, s9, s2
0339ae6c: 0019201e fdiv     s0, s8, s0
0339ae70: 2e28221e fadd     s14, s1, s2
0339ae74: e10f40bd ldr      s1, [sp, #0xc]
0339ae78: 2009201e fmul     s0, s9, s0
0339ae7c: 2f28201e fadd     s15, s1, s0
0339ae80: 940300b4 cbz      x20, #0x339aef0
0339ae84: e00314aa mov      x0, x20
0339ae88: a01dad4e mov      v0.16b, v13.16b
0339ae8c: c11dae4e mov      v1.16b, v14.16b
0339ae90: e21daf4e mov      v2.16b, v15.16b
0339ae94: e1031faa mov      x1, xzr
0339ae98: 0dbc2594 bl       #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
0339ae9c: 685600b0 adrp     x8, #0x3e67000
0339aea0: e81f40bd ldr      s8, [sp, #0x1c]
0339aea4: 024944bd ldr      s2, [x8, #0x448]
0339aea8: 09102f1e fmov     s9, #1.50000000
0339aeac: 211da94e mov      v1.16b, v9.16b
0339aeb0: 001da84e mov      v0.16b, v8.16b
0339aeb4: e0031faa mov      x0, xzr
0339aeb8: a38efb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339aebc: 0021291e fcmp     s8, s9
0339aec0: 4c000054 b.gt     #0x339aec8
0339aec4: 40000036 tbz      w0, #0, #0x339aecc
0339aec8: 7f9600b9 str      wzr, [x19, #0x94]
0339aecc: f37b48a9 ldp      x19, x30, [sp, #0x80]
0339aed0: f55347a9 ldp      x21, x20, [sp, #0x70]
0339aed4: f75b46a9 ldp      x23, x22, [sp, #0x60]
0339aed8: e923456d ldp      d9, d8, [sp, #0x50]
0339aedc: eb2b446d ldp      d11, d10, [sp, #0x40]
0339aee0: ed33436d ldp      d13, d12, [sp, #0x30]
0339aee4: ef3b426d ldp      d15, d14, [sp, #0x20]
0339aee8: ff430291 add      sp, sp, #0x90
0339aeec: c0035fd6 ret      
0339aef0: 4e597097 bl       #0xfb1428
