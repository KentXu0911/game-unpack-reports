# Royal.Scenes.Game.Mechanics.Items.DynamiteBoxItem.DynamiteBoxItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02aaa240: f553bea9 stp      x21, x20, [sp, #-0x20]!
02aaa244: f37b01a9 stp      x19, x30, [sp, #0x10]
02aaa248: f503012a mov      w21, w1
02aaa24c: f40300aa mov      x20, x0
02aaa250: e003012a mov      w0, w1
02aaa254: e1031faa mov      x1, xzr
02aaa258: d5692394 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02aaa25c: 80000036 tbz      w0, #0, #0x2aaa26c
02aaa260: 13918f52 mov      w19, #0x7c88
02aaa264: 7300a072 movk     w19, #3, lsl #16
02aaa268: 07000014 b        #0x2aaa284
02aaa26c: 13229f52 mov      w19, #0xf910
02aaa270: e003152a mov      w0, w21
02aaa274: e1031faa mov      x1, xzr
02aaa278: d300a072 movk     w19, #6, lsl #16
02aaa27c: 3a822394 bl       #0x338ab64 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsLineExploderStrategy
02aaa280: 60000036 tbz      w0, #0, #0x2aaa28c
02aaa284: e003132a mov      w0, w19
02aaa288: 0a000014 b        #0x2aaa2b0
02aaa28c: 880240f9 ldr      x8, [x20]
02aaa290: e00314aa mov      x0, x20
02aaa294: 096542f9 ldr      x9, [x8, #0x4c8]
02aaa298: 016942f9 ldr      x1, [x8, #0x4d0]
02aaa29c: 20013fd6 blr      x9
02aaa2a0: 08769652 mov      w8, #0xb3b0
02aaa2a4: 1f040071 cmp      w0, #1
02aaa2a8: 8809a072 movk     w8, #0x4c, lsl #16
02aaa2ac: 0001931a csel     w0, w8, w19, eq
02aaa2b0: f37b41a9 ldp      x19, x30, [sp, #0x10]
02aaa2b4: f553c2a8 ldp      x21, x20, [sp], #0x20
02aaa2b8: c0035fd6 ret      
