# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddGoalHit
# Linear span to next metadata entry; not a complete CFG.
026a7c10: fe0f1ff8 str      x30, [sp, #-0x10]!
026a7c14: 081840f9 ldr      x8, [x0, #0x30]
026a7c18: 480100b4 cbz      x8, #0x26a7c40
026a7c1c: 091940b9 ldr      w9, [x8, #0x18]
026a7c20: 3f01016b cmp      w9, w1
026a7c24: 09010054 b.ls     #0x26a7c44
026a7c28: 08c9218b add      x8, x8, w1, sxtw #2
026a7c2c: 092140b9 ldr      w9, [x8, #0x20]
026a7c30: 2901020b add      w9, w9, w2
026a7c34: 092100b9 str      w9, [x8, #0x20]
026a7c38: fe0741f8 ldr      x30, [sp], #0x10
026a7c3c: c0035fd6 ret      
026a7c40: fa25a497 bl       #0xfb1428
026a7c44: fb25a497 bl       #0xfb1430
