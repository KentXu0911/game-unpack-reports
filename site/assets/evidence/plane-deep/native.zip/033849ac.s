# Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
# Linear span to next metadata entry; not a complete CFG.
033849ac: 1f0c0071 cmp      w0, #3
033849b0: 61000054 b.ne     #0x33849bc
033849b4: 20008052 mov      w0, #1
033849b8: c0035fd6 ret      
033849bc: 1f180071 cmp      w0, #6
033849c0: e0179f1a cset     w0, eq
033849c4: c0035fd6 ret      
