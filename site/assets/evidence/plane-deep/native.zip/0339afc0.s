# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$GetStartState
# Linear span to next metadata entry; not a complete CFG.
0339afc0: 20008052 mov      w0, #1
0339afc4: c0035fd6 ret      
