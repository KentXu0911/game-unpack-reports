# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$MoveToTarget
# Linear span to next metadata entry; not a complete CFG.
0339b198: 087840b9 ldr      w8, [x0, #0x78]
0339b19c: 1f050071 cmp      w8, #1
0339b1a0: 41000054 b.ne     #0x339b1a8
0339b1a4: 02000014 b        #0x339b1ac ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$ArrangeComboExpandPosition
0339b1a8: 10f7ff17 b        #0x3398de8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$MoveToTarget
