# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339b5bc: fa0f1bf8 str      x26, [sp, #-0x50]!
0339b5c0: f96301a9 stp      x25, x24, [sp, #0x10]
0339b5c4: f75b02a9 stp      x23, x22, [sp, #0x20]
0339b5c8: f55303a9 stp      x21, x20, [sp, #0x30]
0339b5cc: f37b04a9 stp      x19, x30, [sp, #0x40]
0339b5d0: 590f01f0 adrp     x25, #0x5586000
0339b5d4: faf20090 adrp     x26, #0x51f7000
0339b5d8: 28a76639 ldrb     w8, [x25, #0x9a9]
0339b5dc: 5afb44f9 ldr      x26, [x26, #0x9f0]
0339b5e0: f30305aa mov      x19, x5
0339b5e4: f403042a mov      w20, w4
0339b5e8: f503032a mov      w21, w3
0339b5ec: f803022a mov      w24, w2
0339b5f0: f70301aa mov      x23, x1
0339b5f4: f60300aa mov      x22, x0
0339b5f8: c8000037 tbnz     w8, #0, #0x339b610
0339b5fc: e0f20090 adrp     x0, #0x51f7000
0339b600: 00f844f9 ldr      x0, [x0, #0x9f0]
0339b604: 3f577097 bl       #0xfb1300
0339b608: 28008052 mov      w8, #1
0339b60c: 28a72639 strb     w8, [x25, #0x9a9]
0339b610: 400340f9 ldr      x0, [x26]
0339b614: 08e040b9 ldr      w8, [x0, #0xe0]
0339b618: 48000035 cbnz     w8, #0x339b620
0339b61c: 7a577097 bl       #0xfb1404
0339b620: e00316aa mov      x0, x22
0339b624: e1031faa mov      x1, xzr
0339b628: f35fbb97 bl       #0x22735f4 ; System.Object$$.ctor
0339b62c: e00316aa mov      x0, x22
0339b630: 178c0cf8 str      x23, [x0, #0xc8]!
0339b634: e10317aa mov      x1, x23
0339b638: 1d577097 bl       #0xfb12ac
0339b63c: d70200b4 cbz      x23, #0x339b694
0339b640: e00317aa mov      x0, x23
0339b644: e1031faa mov      x1, xzr
0339b648: 18030012 and      w24, w24, #1
0339b64c: 99020012 and      w25, w20, #1
0339b650: 04c00b94 bl       #0x368b660 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$GetSpecialItemView
0339b654: c00e0df8 str      x0, [x22, #0xd0]!
0339b658: e10300aa mov      x1, x0
0339b65c: e00316aa mov      x0, x22
0339b660: 13577097 bl       #0xfb12ac
0339b664: a802142a orr      w8, w21, w20
0339b668: 08010012 and      w8, w8, #1
0339b66c: d8220039 strb     w24, [x22, #8]
0339b670: d92a0039 strb     w25, [x22, #0xa]
0339b674: c8260039 strb     w8, [x22, #9]
0339b678: d3c21df8 stur     x19, [x22, #-0x24]
0339b67c: f37b44a9 ldp      x19, x30, [sp, #0x40]
0339b680: f55343a9 ldp      x21, x20, [sp, #0x30]
0339b684: f75b42a9 ldp      x23, x22, [sp, #0x20]
0339b688: f96341a9 ldp      x25, x24, [sp, #0x10]
0339b68c: fa0745f8 ldr      x26, [sp], #0x50
0339b690: c0035fd6 ret      
0339b694: 65577097 bl       #0xfb1428
