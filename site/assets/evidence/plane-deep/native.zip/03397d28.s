# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerTakeOffSfx
# Linear span to next metadata entry; not a complete CFG.
03397d28: fe0f1ff8 str      x30, [sp, #-0x10]!
03397d2c: 081440f9 ldr      x8, [x0, #0x28]
03397d30: e80000b4 cbz      x8, #0x3397d4c
03397d34: 091940b9 ldr      w9, [x8, #0x18]
03397d38: 3f0d0071 cmp      w9, #3
03397d3c: a9000054 b.ls     #0x3397d50
03397d40: 001d40f9 ldr      x0, [x8, #0x38]
03397d44: fe0741f8 ldr      x30, [sp], #0x10
03397d48: c0035fd6 ret      
03397d4c: b7657097 bl       #0xfb1428
03397d50: b8657097 bl       #0xfb1430
