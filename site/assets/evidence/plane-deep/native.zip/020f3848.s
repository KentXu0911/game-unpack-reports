# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ShouldAddDueToBelowItem
# Linear span to next metadata entry; not a complete CFG.
020f3848: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
020f384c: 010400b4 cbz      x1, #0x20f38cc
020f3850: 206040f9 ldr      x0, [x1, #0xc0]
020f3854: f30301aa mov      x19, x1
020f3858: a00300b4 cbz      x0, #0x20f38cc
020f385c: e1031faa mov      x1, xzr
020f3860: 8f582794 bl       #0x2ac9a9c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasBelowItem
020f3864: 60020036 tbz      w0, #0, #0x20f38b0
020f3868: 600a40f9 ldr      x0, [x19, #0x10]
020f386c: 000300b4 cbz      x0, #0x20f38cc
020f3870: e1031faa mov      x1, xzr
020f3874: 7b491994 bl       #0x2745e60 ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$get_CurrentItem
020f3878: a00200b4 cbz      x0, #0x20f38cc
020f387c: 080040f9 ldr      x8, [x0]
020f3880: 09bd41f9 ldr      x9, [x8, #0x378]
020f3884: 01c141f9 ldr      x1, [x8, #0x380]
020f3888: 20013fd6 blr      x9
020f388c: 08840051 sub      w8, w0, #0x21
020f3890: 1ff10071 cmp      w8, #0x3c
020f3894: 48010054 b.hi     #0x20f38bc
020f3898: 29008052 mov      w9, #1
020f389c: 2821c89a lsl      x8, x9, x8
020f38a0: 290082d2 mov      x9, #0x1001
020f38a4: 0900e2f2 movk     x9, #0x1000, lsl #48
020f38a8: 1f0109ea tst      x8, x9
020f38ac: 80000054 b.eq     #0x20f38bc
020f38b0: e0031f2a mov      w0, wzr
020f38b4: f37bc1a8 ldp      x19, x30, [sp], #0x10
020f38b8: c0035fd6 ret      
020f38bc: 08000032 orr      w8, w0, #1
020f38c0: 1fcd0171 cmp      w8, #0x73
020f38c4: e0079f1a cset     w0, ne
020f38c8: fbffff17 b        #0x20f38b4
020f38cc: d7f6ba97 bl       #0xfb1428
