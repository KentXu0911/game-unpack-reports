# Royal.Scenes.Game.Mechanics.Items.IglooItem.IglooItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0211b868: f553bea9 stp      x21, x20, [sp, #-0x20]!
0211b86c: f37b01a9 stp      x19, x30, [sp, #0x10]
0211b870: 08444539 ldrb     w8, [x0, #0x151]
0211b874: 28020034 cbz      w8, #0x211b8b8
0211b878: 15b040f9 ldr      x21, [x0, #0x160]
0211b87c: f30300aa mov      x19, x0
0211b880: 150300b4 cbz      x21, #0x211b8e0
0211b884: e00315aa mov      x0, x21
0211b888: f403012a mov      w20, w1
0211b88c: 69f5ff97 bl       #0x2118e30 ; Royal.Scenes.Game.Mechanics.Items.IglooItem.IglooItemHelper$$GetThrowItemGoal
0211b890: a84640b9 ldr      w8, [x21, #0x44]
0211b894: 1f01006b cmp      w8, w0
0211b898: 0a010054 b.ge     #0x211b8b8
0211b89c: 756a40b9 ldr      w21, [x19, #0x68]
0211b8a0: e00313aa mov      x0, x19
0211b8a4: 4df9ff97 bl       #0x2119dd8 ; Royal.Scenes.Game.Mechanics.Items.IglooItem.IglooItemModel$$GetTotalIncoming
0211b8a8: 0800154b sub      w8, w0, w21
0211b8ac: 08110011 add      w8, w8, #4
0211b8b0: 1f0d0071 cmp      w8, #3
0211b8b4: ad000054 b.le     #0x211b8c8
0211b8b8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0211b8bc: e0031f2a mov      w0, wzr
0211b8c0: f553c2a8 ldp      x21, x20, [sp], #0x20
0211b8c4: c0035fd6 ret      
0211b8c8: e00313aa mov      x0, x19
0211b8cc: f37b41a9 ldp      x19, x30, [sp, #0x10]
0211b8d0: e103142a mov      w1, w20
0211b8d4: e2031faa mov      x2, xzr
0211b8d8: f553c2a8 ldp      x21, x20, [sp], #0x20
0211b8dc: edd84914 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
0211b8e0: d256ba97 bl       #0xfb1428
