# Royal.Scenes.Game.Mechanics.Items.CuckooItem.CuckooItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0309b6cc: f60f1df8 str      x22, [sp, #-0x30]!
0309b6d0: f55301a9 stp      x21, x20, [sp, #0x10]
0309b6d4: f37b02a9 stp      x19, x30, [sp, #0x20]
0309b6d8: 080040f9 ldr      x8, [x0]
0309b6dc: f403012a mov      w20, w1
0309b6e0: f30300aa mov      x19, x0
0309b6e4: 096542f9 ldr      x9, [x8, #0x4c8]
0309b6e8: 086942f9 ldr      x8, [x8, #0x4d0]
0309b6ec: e10308aa mov      x1, x8
0309b6f0: 20013fd6 blr      x9
0309b6f4: 1f040071 cmp      w0, #1
0309b6f8: 6b010054 b.lt     #0x309b724
0309b6fc: e003142a mov      w0, w20
0309b700: e1031faa mov      x1, xzr
0309b704: aaa40b94 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
0309b708: 20010036 tbz      w0, #0, #0x309b72c
0309b70c: 602a40f9 ldr      x0, [x19, #0x50]
0309b710: 600400b4 cbz      x0, #0x309b79c
0309b714: 61c242f8 ldur     x1, [x19, #0x2c]
0309b718: e2031faa mov      x2, xzr
0309b71c: 7de3da97 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
0309b720: 06000014 b        #0x309b738
0309b724: e0031f2a mov      w0, wzr
0309b728: 19000014 b        #0x309b78c
0309b72c: e00313aa mov      x0, x19
0309b730: e1031faa mov      x1, xzr
0309b734: d89d0b94 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0309b738: 765e40f9 ldr      x22, [x19, #0xb8]
0309b73c: f50300aa mov      x21, x0
0309b740: f60200b4 cbz      x22, #0x309b79c
0309b744: 61ce40b9 ldr      w1, [x19, #0xcc]
0309b748: e00316aa mov      x0, x22
0309b74c: e2031faa mov      x2, xzr
0309b750: 5be6f497 bl       #0x2dd50bc ; Royal.Scenes.Game.Mechanics.Items.CuckooItem.CuckooItemHelper$$GetCuckooItems
0309b754: a4608a52 mov      w4, #0x5305
0309b758: e10300aa mov      x1, x0
0309b75c: 4400a072 movk     w4, #2, lsl #16
0309b760: e00316aa mov      x0, x22
0309b764: e20315aa mov      x2, x21
0309b768: e303142a mov      w3, w20
0309b76c: e5031faa mov      x5, xzr
0309b770: 39e4f497 bl       #0x2dd4854 ; Royal.Scenes.Game.Mechanics.Items.CuckooItem.CuckooItemHelper$$GetItemExplodeExtraScore
0309b774: f503002a mov      w21, w0
0309b778: e00313aa mov      x0, x19
0309b77c: e103142a mov      w1, w20
0309b780: e2031faa mov      x2, xzr
0309b784: 7aa40b94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
0309b788: 0000150b add      w0, w0, w21
0309b78c: f37b42a9 ldp      x19, x30, [sp, #0x20]
0309b790: f55341a9 ldp      x21, x20, [sp, #0x10]
0309b794: f60743f8 ldr      x22, [sp], #0x30
0309b798: c0035fd6 ret      
0309b79c: 23577c97 bl       #0xfb1428
