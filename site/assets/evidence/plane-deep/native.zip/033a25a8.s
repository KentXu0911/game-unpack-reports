# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$ArrangeScaleUp
# Linear span to next metadata entry; not a complete CFG.
033a25a8: ff4302d1 sub      sp, sp, #0x90
033a25ac: ef3b026d stp      d15, d14, [sp, #0x20]
033a25b0: ed33036d stp      d13, d12, [sp, #0x30]
033a25b4: eb2b046d stp      d11, d10, [sp, #0x40]
033a25b8: e923056d stp      d9, d8, [sp, #0x50]
033a25bc: f75b06a9 stp      x23, x22, [sp, #0x60]
033a25c0: f55307a9 stp      x21, x20, [sp, #0x70]
033a25c4: f37b08a9 stp      x19, x30, [sp, #0x80]
033a25c8: 340f0190 adrp     x20, #0x5586000
033a25cc: 88166739 ldrb     w8, [x20, #0x9c5]
033a25d0: a91ca54e mov      v9.16b, v5.16b
033a25d4: 8b1ca44e mov      v11.16b, v4.16b
033a25d8: 681ca34e mov      v8.16b, v3.16b
033a25dc: 4c1ca24e mov      v12.16b, v2.16b
033a25e0: 2d1ca14e mov      v13.16b, v1.16b
033a25e4: 0e1ca04e mov      v14.16b, v0.16b
033a25e8: f30300aa mov      x19, x0
033a25ec: e61b00bd str      s6, [sp, #0x18]
033a25f0: c8000037 tbnz     w8, #0, #0x33a2608
033a25f4: 40f200b0 adrp     x0, #0x51eb000
033a25f8: 009c40f9 ldr      x0, [x0, #0x138]
033a25fc: 413b7097 bl       #0xfb1300
033a2600: 28008052 mov      w8, #1
033a2604: 88162739 strb     w8, [x20, #0x9c5]
033a2608: 742e40f9 ldr      x20, [x19, #0x58]
033a260c: e0031faa mov      x0, xzr
033a2610: 756e2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
033a2614: d60e01f0 adrp     x22, #0x557d000
033a2618: c8ba5f39 ldrb     w8, [x22, #0x7ee]
033a261c: 0f1ca04e mov      v15.16b, v0.16b
033a2620: c8000035 cbnz     w8, #0x33a2638
033a2624: e0f200d0 adrp     x0, #0x5200000
033a2628: 008c46f9 ldr      x0, [x0, #0xd18]
033a262c: 353b7097 bl       #0xfb1300
033a2630: 28008052 mov      w8, #1
033a2634: c8ba1f39 strb     w8, [x22, #0x7ee]
033a2638: e81f00bd str      s8, [sp, #0x1c]
033a263c: ca39281e fsub     s10, s14, s8
033a2640: a8392b1e fsub     s8, s13, s11
033a2644: f5f200d0 adrp     x21, #0x5200000
033a2648: 221da94e mov      v2.16b, v9.16b
033a264c: 8939291e fsub     s9, s12, s9
033a2650: 40092a1e fmul     s0, s10, s10
033a2654: 0109281e fmul     s1, s8, s8
033a2658: b58e46f9 ldr      x21, [x21, #0xd18]
033a265c: 0028211e fadd     s0, s0, s1
033a2660: 2109291e fmul     s1, s9, s9
033a2664: 631dab4e mov      v3.16b, v11.16b
033a2668: 2b28201e fadd     s11, s1, s0
033a266c: 6821201e fcmp     s11, #0.0
033a2670: 40030054 b.eq     #0x33a26d8
033a2674: e01b40bd ldr      s0, [sp, #0x18]
033a2678: e30b022d stp      s3, s2, [sp, #0x10]
033a267c: ef09201e fmul     s15, s15, s0
033a2680: e821201e fcmp     s15, #0.0
033a2684: 8b000054 b.lt     #0x33a2694
033a2688: e0092f1e fmul     s0, s15, s15
033a268c: 6021201e fcmp     s11, s0
033a2690: 49020054 b.ls     #0x33a26d8
033a2694: a00240f9 ldr      x0, [x21]
033a2698: 08e040b9 ldr      w8, [x0, #0xe0]
033a269c: 48000035 cbnz     w8, #0x33a26a4
033a26a0: 593b7097 bl       #0xfb1404
033a26a4: e31f40bd ldr      s3, [sp, #0x1c]
033a26a8: 60c1211e fsqrt    s0, s11
033a26ac: 4119201e fdiv     s1, s10, s0
033a26b0: 21082f1e fmul     s1, s1, s15
033a26b4: 6e28211e fadd     s14, s3, s1
033a26b8: e11340bd ldr      s1, [sp, #0x10]
033a26bc: 0219201e fdiv     s2, s8, s0
033a26c0: 42082f1e fmul     s2, s2, s15
033a26c4: 2019201e fdiv     s0, s9, s0
033a26c8: 2d28221e fadd     s13, s1, s2
033a26cc: e11740bd ldr      s1, [sp, #0x14]
033a26d0: 00082f1e fmul     s0, s0, s15
033a26d4: 2c28201e fadd     s12, s1, s0
033a26d8: 340e00b4 cbz      x20, #0x33a289c
033a26dc: e00314aa mov      x0, x20
033a26e0: c01dae4e mov      v0.16b, v14.16b
033a26e4: a11dad4e mov      v1.16b, v13.16b
033a26e8: 821dac4e mov      v2.16b, v12.16b
033a26ec: e1031faa mov      x1, xzr
033a26f0: 4d9f2594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
033a26f4: 682a40f9 ldr      x8, [x19, #0x50]
033a26f8: 280d00b4 cbz      x8, #0x33a289c
033a26fc: 004140f9 ldr      x0, [x8, #0x80]
033a2700: e00c00b4 cbz      x0, #0x33a289c
033a2704: e1031faa mov      x1, xzr
033a2708: a8812594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
033a270c: 682a40f9 ldr      x8, [x19, #0x50]
033a2710: 680c00b4 cbz      x8, #0x33a289c
033a2714: f40300aa mov      x20, x0
033a2718: 004140f9 ldr      x0, [x8, #0x80]
033a271c: 000c00b4 cbz      x0, #0x33a289c
033a2720: e1031faa mov      x1, xzr
033a2724: a1812594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
033a2728: a00b00b4 cbz      x0, #0x33a289c
033a272c: 57f200b0 adrp     x23, #0x51eb000
033a2730: f79e40f9 ldr      x23, [x23, #0x138]
033a2734: e1031faa mov      x1, xzr
033a2738: bd9d2594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
033a273c: e00240f9 ldr      x0, [x23]
033a2740: 081ca04e mov      v8.16b, v0.16b
033a2744: 2a1ca14e mov      v10.16b, v1.16b
033a2748: 4c1ca24e mov      v12.16b, v2.16b
033a274c: 08e040b9 ldr      w8, [x0, #0xe0]
033a2750: 68000035 cbnz     w8, #0x33a275c
033a2754: 2c3b7097 bl       #0xfb1404
033a2758: e00240f9 ldr      x0, [x23]
033a275c: 085c40f9 ldr      x8, [x0, #0xb8]
033a2760: e0031faa mov      x0, xzr
033a2764: 0d39402d ldp      s13, s14, [x8]
033a2768: 0f0940bd ldr      s15, [x8, #8]
033a276c: 1e6e2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
033a2770: c8ba5f39 ldrb     w8, [x22, #0x7ee]
033a2774: 091ca04e mov      v9.16b, v0.16b
033a2778: c8000035 cbnz     w8, #0x33a2790
033a277c: e0f200d0 adrp     x0, #0x5200000
033a2780: 008c46f9 ldr      x0, [x0, #0xd18]
033a2784: df3a7097 bl       #0xfb1300
033a2788: 28008052 mov      w8, #1
033a278c: c8ba1f39 strb     w8, [x22, #0x7ee]
033a2790: ab39281e fsub     s11, s13, s8
033a2794: 431daa4e mov      v3.16b, v10.16b
033a2798: ca392a1e fsub     s10, s14, s10
033a279c: 021da84e mov      v2.16b, v8.16b
033a27a0: e8392c1e fsub     s8, s15, s12
033a27a4: 60092b1e fmul     s0, s11, s11
033a27a8: 41092a1e fmul     s1, s10, s10
033a27ac: 0028211e fadd     s0, s0, s1
033a27b0: 0109281e fmul     s1, s8, s8
033a27b4: 841dac4e mov      v4.16b, v12.16b
033a27b8: 2c28201e fadd     s12, s1, s0
033a27bc: 8821201e fcmp     s12, #0.0
033a27c0: 60030054 b.eq     #0x33a282c
033a27c4: e01b40bd ldr      s0, [sp, #0x18]
033a27c8: e48f012d stp      s4, s3, [sp, #0xc]
033a27cc: e21700bd str      s2, [sp, #0x14]
033a27d0: 2909201e fmul     s9, s9, s0
033a27d4: 2821201e fcmp     s9, #0.0
033a27d8: 8b000054 b.lt     #0x33a27e8
033a27dc: 2009291e fmul     s0, s9, s9
033a27e0: 8021201e fcmp     s12, s0
033a27e4: 49020054 b.ls     #0x33a282c
033a27e8: a00240f9 ldr      x0, [x21]
033a27ec: 08e040b9 ldr      w8, [x0, #0xe0]
033a27f0: 48000035 cbnz     w8, #0x33a27f8
033a27f4: 043b7097 bl       #0xfb1404
033a27f8: e31740bd ldr      s3, [sp, #0x14]
033a27fc: 80c1211e fsqrt    s0, s12
033a2800: 6119201e fdiv     s1, s11, s0
033a2804: 2109211e fmul     s1, s9, s1
033a2808: 6d28211e fadd     s13, s3, s1
033a280c: e11340bd ldr      s1, [sp, #0x10]
033a2810: 4219201e fdiv     s2, s10, s0
033a2814: 2209221e fmul     s2, s9, s2
033a2818: 0019201e fdiv     s0, s8, s0
033a281c: 2e28221e fadd     s14, s1, s2
033a2820: e10f40bd ldr      s1, [sp, #0xc]
033a2824: 2009201e fmul     s0, s9, s0
033a2828: 2f28201e fadd     s15, s1, s0
033a282c: 940300b4 cbz      x20, #0x33a289c
033a2830: e00314aa mov      x0, x20
033a2834: a01dad4e mov      v0.16b, v13.16b
033a2838: c11dae4e mov      v1.16b, v14.16b
033a283c: e21daf4e mov      v2.16b, v15.16b
033a2840: e1031faa mov      x1, xzr
033a2844: a29d2594 bl       #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
033a2848: 285600b0 adrp     x8, #0x3e67000
033a284c: e81f40bd ldr      s8, [sp, #0x1c]
033a2850: 024944bd ldr      s2, [x8, #0x448]
033a2854: 09d0201e fmov     s9, #2.75000000
033a2858: 211da94e mov      v1.16b, v9.16b
033a285c: 001da84e mov      v0.16b, v8.16b
033a2860: e0031faa mov      x0, xzr
033a2864: 3870fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
033a2868: 0021291e fcmp     s8, s9
033a286c: 4c000054 b.gt     #0x33a2874
033a2870: 40000036 tbz      w0, #0, #0x33a2878
033a2874: 7f8600b9 str      wzr, [x19, #0x84]
033a2878: f37b48a9 ldp      x19, x30, [sp, #0x80]
033a287c: f55347a9 ldp      x21, x20, [sp, #0x70]
033a2880: f75b46a9 ldp      x23, x22, [sp, #0x60]
033a2884: e923456d ldp      d9, d8, [sp, #0x50]
033a2888: eb2b446d ldp      d11, d10, [sp, #0x40]
033a288c: ed33436d ldp      d13, d12, [sp, #0x30]
033a2890: ef3b426d ldp      d15, d14, [sp, #0x20]
033a2894: ff430291 add      sp, sp, #0x90
033a2898: c0035fd6 ret      
033a289c: e33a7097 bl       #0xfb1428
