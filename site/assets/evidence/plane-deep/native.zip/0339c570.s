# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$MoveToTarget
# Linear span to next metadata entry; not a complete CFG.
0339c570: ef3bba6d stp      d15, d14, [sp, #-0x60]!
0339c574: ed33016d stp      d13, d12, [sp, #0x10]
0339c578: eb2b026d stp      d11, d10, [sp, #0x20]
0339c57c: e923036d stp      d9, d8, [sp, #0x30]
0339c580: f42300f9 str      x20, [sp, #0x40]
0339c584: f37b05a9 stp      x19, x30, [sp, #0x50]
0339c588: 540f01d0 adrp     x20, #0x5586000
0339c58c: 88be6639 ldrb     w8, [x20, #0x9af]
0339c590: f30300aa mov      x19, x0
0339c594: c8000037 tbnz     w8, #0, #0x339c5ac
0339c598: 80f400f0 adrp     x0, #0x522f000
0339c59c: 000445f9 ldr      x0, [x0, #0xa08]
0339c5a0: 58537097 bl       #0xfb1300
0339c5a4: 28008052 mov      w8, #1
0339c5a8: 88be2639 strb     w8, [x20, #0x9af]
0339c5ac: 686a4339 ldrb     w8, [x19, #0xda]
0339c5b0: e8010034 cbz      w8, #0x339c5ec
0339c5b4: 687a40b9 ldr      w8, [x19, #0x78]
0339c5b8: 1f050071 cmp      w8, #1
0339c5bc: a1110054 b.ne     #0x339c7f0
0339c5c0: 21008052 mov      w1, #1
0339c5c4: e00313aa mov      x0, x19
0339c5c8: 12feff97 bl       #0x339be10 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeRootPositions
0339c5cc: e00313aa mov      x0, x19
0339c5d0: f37b45a9 ldp      x19, x30, [sp, #0x50]
0339c5d4: f42340f9 ldr      x20, [sp, #0x40]
0339c5d8: e923436d ldp      d9, d8, [sp, #0x30]
0339c5dc: eb2b426d ldp      d11, d10, [sp, #0x20]
0339c5e0: ed33416d ldp      d13, d12, [sp, #0x10]
0339c5e4: ef3bc66c ldp      d15, d14, [sp], #0x60
0339c5e8: 8b000014 b        #0x339c814 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeComboExpandPosition
0339c5ec: 60b640bd ldr      s0, [x19, #0xb4]
0339c5f0: 0820201e fcmp     s0, #0.0
0339c5f4: e10f0054 b.ne     #0x339c7f0
0339c5f8: 743a40f9 ldr      x20, [x19, #0x70]
0339c5fc: b41000b4 cbz      x20, #0x339c810
0339c600: 8af400f0 adrp     x10, #0x522f000
0339c604: 880240f9 ldr      x8, [x20]
0339c608: 4a0545f9 ldr      x10, [x10, #0xa08]
0339c60c: 09554279 ldrh     w9, [x8, #0x12a]
0339c610: 410140f9 ldr      x1, [x10]
0339c614: 290100b4 cbz      x9, #0x339c638
0339c618: 0a5940f9 ldr      x10, [x8, #0xb0]
0339c61c: 4a210091 add      x10, x10, #8
0339c620: 4b815ff8 ldur     x11, [x10, #-8]
0339c624: 7f0101eb cmp      x11, x1
0339c628: 00010054 b.eq     #0x339c648
0339c62c: 290500f1 subs     x9, x9, #1
0339c630: 4a410091 add      x10, x10, #0x10
0339c634: 61ffff54 b.ne     #0x339c620
0339c638: 22008052 mov      w2, #1
0339c63c: e00314aa mov      x0, x20
0339c640: 25936f97 bl       #0xf812d4
0339c644: 05000014 b        #0x339c658
0339c648: 490140b9 ldr      w9, [x10]
0339c64c: 29050011 add      w9, w9, #1
0339c650: 08d1298b add      x8, x8, w9, sxtw #4
0339c654: 00e10491 add      x0, x8, #0x138
0339c658: 080440a9 ldp      x8, x1, [x0]
0339c65c: e00314aa mov      x0, x20
0339c660: 00013fd6 blr      x8
0339c664: 603640f9 ldr      x0, [x19, #0x68]
0339c668: 400d00b4 cbz      x0, #0x339c810
0339c66c: e1031faa mov      x1, xzr
0339c670: 081ca04e mov      v8.16b, v0.16b
0339c674: 291ca14e mov      v9.16b, v1.16b
0339c678: 4b1ca24e mov      v11.16b, v2.16b
0339c67c: 9eb52594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339c680: d40e01d0 adrp     x20, #0x5576000
0339c684: 88ba7c39 ldrb     w8, [x20, #0xf2e]
0339c688: 0a39201e fsub     s10, s8, s0
0339c68c: 2839211e fsub     s8, s9, s1
0339c690: 6939221e fsub     s9, s11, s2
0339c694: c8000035 cbnz     w8, #0x339c6ac
0339c698: 60f400f0 adrp     x0, #0x522b000
0339c69c: 00ac43f9 ldr      x0, [x0, #0x758]
0339c6a0: 18537097 bl       #0xfb1300
0339c6a4: 28008052 mov      w8, #1
0339c6a8: 88ba3c39 strb     w8, [x20, #0xf2e]
0339c6ac: 68f400f0 adrp     x8, #0x522b000
0339c6b0: 08ad43f9 ldr      x8, [x8, #0x758]
0339c6b4: 601a40bd ldr      s0, [x19, #0x18]
0339c6b8: 610a472d ldp      s1, s2, [x19, #0x38]
0339c6bc: 634240bd ldr      s3, [x19, #0x40]
0339c6c0: 080140f9 ldr      x8, [x8]
0339c6c4: e0031faa mov      x0, xzr
0339c6c8: 085d40f9 ldr      x8, [x8, #0xb8]
0339c6cc: 0e35432d ldp      s14, s13, [x8, #0x18]
0339c6d0: 0c2140bd ldr      s12, [x8, #0x20]
0339c6d4: a7a40594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339c6d8: 441daa4e mov      v4.16b, v10.16b
0339c6dc: 051da84e mov      v5.16b, v8.16b
0339c6e0: 261da94e mov      v6.16b, v9.16b
0339c6e4: e0031faa mov      x0, xzr
0339c6e8: e84f00bd str      s8, [sp, #0x4c]
0339c6ec: 33a20594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339c6f0: 540f0190 adrp     x20, #0x5584000
0339c6f4: 88fe4f39 ldrb     w8, [x20, #0x3ff]
0339c6f8: 0a1ca04e mov      v10.16b, v0.16b
0339c6fc: 2b1ca14e mov      v11.16b, v1.16b
0339c700: 491ca24e mov      v9.16b, v2.16b
0339c704: c8000035 cbnz     w8, #0x339c71c
0339c708: 20f30090 adrp     x0, #0x5200000
0339c70c: 008c46f9 ldr      x0, [x0, #0xd18]
0339c710: fc527097 bl       #0xfb1300
0339c714: 28008052 mov      w8, #1
0339c718: 88fe0f39 strb     w8, [x20, #0x3ff]
0339c71c: 34f30090 adrp     x20, #0x5200000
0339c720: 948e46f9 ldr      x20, [x20, #0xd18]
0339c724: c0092e1e fmul     s0, s14, s14
0339c728: a1092d1e fmul     s1, s13, s13
0339c72c: 0028211e fadd     s0, s0, s1
0339c730: 800240f9 ldr      x0, [x20]
0339c734: 81092c1e fmul     s1, s12, s12
0339c738: 2f28201e fadd     s15, s1, s0
0339c73c: 40092a1e fmul     s0, s10, s10
0339c740: 08e040b9 ldr      w8, [x0, #0xe0]
0339c744: 61092b1e fmul     s1, s11, s11
0339c748: 0028211e fadd     s0, s0, s1
0339c74c: 2109291e fmul     s1, s9, s9
0339c750: 2828201e fadd     s8, s1, s0
0339c754: 48000035 cbnz     w8, #0x339c75c
0339c758: 2b537097 bl       #0xfb1404
0339c75c: a85600f0 adrp     x8, #0x3e73000
0339c760: 028d4bbd ldr      s2, [x8, #0xb8c]
0339c764: e009281e fmul     s0, s15, s8
0339c768: 00c0211e fsqrt    s0, s0
0339c76c: e103271e fmov     s1, wzr
0339c770: 0020221e fcmp     s0, s2
0339c774: 03102e1e fmov     s3, #1.00000000
0339c778: 0f103e1e fmov     s15, #-1.00000000
0339c77c: c4020054 b.mi     #0x339c7d4
0339c780: 800240f9 ldr      x0, [x20]
0339c784: c1092a1e fmul     s1, s14, s10
0339c788: a2092b1e fmul     s2, s13, s11
0339c78c: 2128221e fadd     s1, s1, s2
0339c790: 8209291e fmul     s2, s12, s9
0339c794: 4128211e fadd     s1, s2, s1
0339c798: 08e040b9 ldr      w8, [x0, #0xe0]
0339c79c: 2018201e fdiv     s0, s1, s0
0339c7a0: 0158231e fmin     s1, s0, s3
0339c7a4: 00202f1e fcmp     s0, s15
0339c7a8: 691ca34e mov      v9.16b, v3.16b
0339c7ac: 285c2f1e fcsel    s8, s1, s15, pl
0339c7b0: 48000035 cbnz     w8, #0x339c7b8
0339c7b4: 14537097 bl       #0xfb1404
0339c7b8: 00c1221e fcvt     d0, s8
0339c7bc: 81996497 bl       #0xcc2dc0
0339c7c0: a85600f0 adrp     x8, #0x3e73000
0339c7c4: 01914bbd ldr      s1, [x8, #0xb90]
0339c7c8: 0040621e fcvt     s0, d0
0339c7cc: 231da94e mov      v3.16b, v9.16b
0339c7d0: 0108211e fmul     s1, s0, s1
0339c7d4: e24f40bd ldr      s2, [sp, #0x4c]
0339c7d8: 604240bd ldr      s0, [x19, #0x40]
0339c7dc: 4820201e fcmp     s2, #0.0
0339c7e0: 62cc2f1e fcsel    s2, s3, s15, gt
0339c7e4: 2008201e fmul     s0, s1, s0
0339c7e8: 4008201e fmul     s0, s2, s0
0339c7ec: 60b600bd str      s0, [x19, #0xb4]
0339c7f0: e00313aa mov      x0, x19
0339c7f4: f37b45a9 ldp      x19, x30, [sp, #0x50]
0339c7f8: f42340f9 ldr      x20, [sp, #0x40]
0339c7fc: e923436d ldp      d9, d8, [sp, #0x30]
0339c800: eb2b426d ldp      d11, d10, [sp, #0x20]
0339c804: ed33416d ldp      d13, d12, [sp, #0x10]
0339c808: ef3bc66c ldp      d15, d14, [sp], #0x60
0339c80c: 77f1ff17 b        #0x3398de8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$MoveToTarget
0339c810: 06537097 bl       #0xfb1428
