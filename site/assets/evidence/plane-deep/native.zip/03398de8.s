# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$MoveToTarget
# Linear span to next metadata entry; not a complete CFG.
03398de8: ff4304d1 sub      sp, sp, #0x110
03398dec: ef3b076d stp      d15, d14, [sp, #0x70]
03398df0: ed33086d stp      d13, d12, [sp, #0x80]
03398df4: eb2b096d stp      d11, d10, [sp, #0x90]
03398df8: e9230a6d stp      d9, d8, [sp, #0xa0]
03398dfc: fc6f0ba9 stp      x28, x27, [sp, #0xb0]
03398e00: fa670ca9 stp      x26, x25, [sp, #0xc0]
03398e04: f85f0da9 stp      x24, x23, [sp, #0xd0]
03398e08: f6570ea9 stp      x22, x21, [sp, #0xe0]
03398e0c: f44f0fa9 stp      x20, x19, [sp, #0xf0]
03398e10: fd7b10a9 stp      x29, x30, [sp, #0x100]
03398e14: 740f01d0 adrp     x20, #0x5586000
03398e18: 887e6639 ldrb     w8, [x20, #0x99f]
03398e1c: f30300aa mov      x19, x0
03398e20: c8030037 tbnz     w8, #0, #0x3398e98
03398e24: e0f300d0 adrp     x0, #0x5216000
03398e28: 001c44f9 ldr      x0, [x0, #0x838]
03398e2c: 35617097 bl       #0xfb1300
03398e30: 60f200d0 adrp     x0, #0x51e6000
03398e34: 007840f9 ldr      x0, [x0, #0xf0]
03398e38: 32617097 bl       #0xfb1300
03398e3c: 80f00090 adrp     x0, #0x51a8000
03398e40: 00dc41f9 ldr      x0, [x0, #0x3b8]
03398e44: 2f617097 bl       #0xfb1300
03398e48: a0f400f0 adrp     x0, #0x522f000
03398e4c: 000445f9 ldr      x0, [x0, #0xa08]
03398e50: 2c617097 bl       #0xfb1300
03398e54: c0f400b0 adrp     x0, #0x5231000
03398e58: 003841f9 ldr      x0, [x0, #0x270]
03398e5c: 29617097 bl       #0xfb1300
03398e60: 00f30090 adrp     x0, #0x51f8000
03398e64: 000847f9 ldr      x0, [x0, #0xe10]
03398e68: 26617097 bl       #0xfb1300
03398e6c: 80f400f0 adrp     x0, #0x522b000
03398e70: 00ac43f9 ldr      x0, [x0, #0x758]
03398e74: 23617097 bl       #0xfb1300
03398e78: c0f300b0 adrp     x0, #0x5211000
03398e7c: 00e440f9 ldr      x0, [x0, #0x1c8]
03398e80: 20617097 bl       #0xfb1300
03398e84: 00f20090 adrp     x0, #0x51d8000
03398e88: 004c44f9 ldr      x0, [x0, #0x898]
03398e8c: 1d617097 bl       #0xfb1300
03398e90: 28008052 mov      w8, #1
03398e94: 887e2639 strb     w8, [x20, #0x99f]
03398e98: 603640f9 ldr      x0, [x19, #0x68]
03398e9c: 004800b4 cbz      x0, #0x339979c
03398ea0: e1031faa mov      x1, xzr
03398ea4: 94c32594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
03398ea8: 743a40f9 ldr      x20, [x19, #0x70]
03398eac: 944700b4 cbz      x20, #0x339979c
03398eb0: b7f400f0 adrp     x23, #0x522f000
03398eb4: 880240f9 ldr      x8, [x20]
03398eb8: f70645f9 ldr      x23, [x23, #0xa08]
03398ebc: 0c1ca04e mov      v12.16b, v0.16b
03398ec0: 2a1ca14e mov      v10.16b, v1.16b
03398ec4: 09554279 ldrh     w9, [x8, #0x12a]
03398ec8: e10240f9 ldr      x1, [x23]
03398ecc: 4d1ca24e mov      v13.16b, v2.16b
03398ed0: 290100b4 cbz      x9, #0x3398ef4
03398ed4: 0a5940f9 ldr      x10, [x8, #0xb0]
03398ed8: 4a210091 add      x10, x10, #8
03398edc: 4b815ff8 ldur     x11, [x10, #-8]
03398ee0: 7f0101eb cmp      x11, x1
03398ee4: 00010054 b.eq     #0x3398f04
03398ee8: 290500f1 subs     x9, x9, #1
03398eec: 4a410091 add      x10, x10, #0x10
03398ef0: 61ffff54 b.ne     #0x3398edc
03398ef4: 22008052 mov      w2, #1
03398ef8: e00314aa mov      x0, x20
03398efc: f6a06f97 bl       #0xf812d4
03398f00: 05000014 b        #0x3398f14
03398f04: 490140b9 ldr      w9, [x10]
03398f08: 29050011 add      w9, w9, #1
03398f0c: 08d1298b add      x8, x8, w9, sxtw #4
03398f10: 00e10491 add      x0, x8, #0x138
03398f14: 080440a9 ldp      x8, x1, [x0]
03398f18: e00314aa mov      x0, x20
03398f1c: 00013fd6 blr      x8
03398f20: f60e01f0 adrp     x22, #0x5577000
03398f24: c81a6039 ldrb     w8, [x22, #0x806]
03398f28: 091ca04e mov      v9.16b, v0.16b
03398f2c: 281ca14e mov      v8.16b, v1.16b
03398f30: 4e1ca24e mov      v14.16b, v2.16b
03398f34: c8000035 cbnz     w8, #0x3398f4c
03398f38: 40f30090 adrp     x0, #0x5200000
03398f3c: 008c46f9 ldr      x0, [x0, #0xd18]
03398f40: f0607097 bl       #0xfb1300
03398f44: 28008052 mov      w8, #1
03398f48: c81a2039 strb     w8, [x22, #0x806]
03398f4c: 58f30090 adrp     x24, #0x5200000
03398f50: 188f46f9 ldr      x24, [x24, #0xd18]
03398f54: 2f392c1e fsub     s15, s9, s12
03398f58: 000340f9 ldr      x0, [x24]
03398f5c: 08e040b9 ldr      w8, [x0, #0xe0]
03398f60: e923042d stp      s9, s8, [sp, #0x20]
03398f64: ec2b032d stp      s12, s10, [sp, #0x18]
03398f68: 0a392a1e fsub     s10, s8, s10
03398f6c: c9392d1e fsub     s9, s14, s13
03398f70: 48000035 cbnz     w8, #0x3398f78
03398f74: 24617097 bl       #0xfb1404
03398f78: f40e01f0 adrp     x20, #0x5577000
03398f7c: 88fa7f39 ldrb     w8, [x20, #0xffe]
03398f80: e0092f1e fmul     s0, s15, s15
03398f84: 41092a1e fmul     s1, s10, s10
03398f88: 0028211e fadd     s0, s0, s1
03398f8c: 2109291e fmul     s1, s9, s9
03398f90: 2828201e fadd     s8, s1, s0
03398f94: c8000035 cbnz     w8, #0x3398fac
03398f98: 40f30090 adrp     x0, #0x5200000
03398f9c: 008c46f9 ldr      x0, [x0, #0xd18]
03398fa0: d8607097 bl       #0xfb1300
03398fa4: 28008052 mov      w8, #1
03398fa8: 88fa3f39 strb     w8, [x20, #0xffe]
03398fac: 000340f9 ldr      x0, [x24]
03398fb0: 08c1211e fsqrt    s8, s8
03398fb4: 08e040b9 ldr      w8, [x0, #0xe0]
03398fb8: 48000035 cbnz     w8, #0x3398fc0
03398fbc: 12617097 bl       #0xfb1404
03398fc0: c85600f0 adrp     x8, #0x3e73000
03398fc4: ed1700bd str      s13, [sp, #0x14]
03398fc8: 01894bbd ldr      s1, [x8, #0xb88]
03398fcc: 9bf400f0 adrp     x27, #0x522b000
03398fd0: 7baf43f9 ldr      x27, [x27, #0x758]
03398fd4: 0021211e fcmp     s8, s1
03398fd8: ad000054 b.le     #0x3398fec
03398fdc: eb19281e fdiv     s11, s15, s8
03398fe0: 4c19281e fdiv     s12, s10, s8
03398fe4: 2d19281e fdiv     s13, s9, s8
03398fe8: 0d000014 b        #0x339901c
03398fec: f40e01d0 adrp     x20, #0x5576000
03398ff0: 88b27c39 ldrb     w8, [x20, #0xf2c]
03398ff4: c8000035 cbnz     w8, #0x339900c
03398ff8: 80f400f0 adrp     x0, #0x522b000
03398ffc: 00ac43f9 ldr      x0, [x0, #0x758]
03399000: c0607097 bl       #0xfb1300
03399004: 28008052 mov      w8, #1
03399008: 88b23c39 strb     w8, [x20, #0xf2c]
0339900c: 680340f9 ldr      x8, [x27]
03399010: 085d40f9 ldr      x8, [x8, #0xb8]
03399014: 0b31402d ldp      s11, s12, [x8]
03399018: 0d0940bd ldr      s13, [x8, #8]
0339901c: e00313aa mov      x0, x19
03399020: 001da84e mov      v0.16b, v8.16b
03399024: e3010094 bl       #0x33997b0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScale
03399028: 680240f9 ldr      x8, [x19]
0339902c: e00313aa mov      x0, x19
03399030: e01daf4e mov      v0.16b, v15.16b
03399034: 411daa4e mov      v1.16b, v10.16b
03399038: 097541f9 ldr      x9, [x8, #0x2e8]
0339903c: 017941f9 ldr      x1, [x8, #0x2f0]
03399040: 221da94e mov      v2.16b, v9.16b
03399044: 631dab4e mov      v3.16b, v11.16b
03399048: 841dac4e mov      v4.16b, v12.16b
0339904c: a51dad4e mov      v5.16b, v13.16b
03399050: 061da84e mov      v6.16b, v8.16b
03399054: 0b1da84e mov      v11.16b, v8.16b
03399058: 20013fd6 blr      x9
0339905c: 60000036 tbz      w0, #0, #0x3399068
03399060: 7f1600b9 str      wzr, [x19, #0x14]
03399064: 72010014 b        #0x339962c
03399068: 681640b9 ldr      w8, [x19, #0x14]
0339906c: 08050011 add      w8, w8, #1
03399070: 1fb50071 cmp      w8, #0x2d
03399074: 681600b9 str      w8, [x19, #0x14]
03399078: ab2d0054 b.lt     #0x339962c
0339907c: 603640f9 ldr      x0, [x19, #0x68]
03399080: e03800b4 cbz      x0, #0x339979c
03399084: e1031faa mov      x1, xzr
03399088: 0dc52594 bl       #0x3d0a4bc ; UnityEngine.Transform$$get_parent
0339908c: 753a40f9 ldr      x21, [x19, #0x70]
03399090: 753800b4 cbz      x21, #0x339979c
03399094: a80240f9 ldr      x8, [x21]
03399098: e10240f9 ldr      x1, [x23]
0339909c: ed1740bd ldr      s13, [sp, #0x14]
033990a0: f40300aa mov      x20, x0
033990a4: 09554279 ldrh     w9, [x8, #0x12a]
033990a8: 290100b4 cbz      x9, #0x33990cc
033990ac: 0a5940f9 ldr      x10, [x8, #0xb0]
033990b0: 4a210091 add      x10, x10, #8
033990b4: 4b815ff8 ldur     x11, [x10, #-8]
033990b8: 7f0101eb cmp      x11, x1
033990bc: 00010054 b.eq     #0x33990dc
033990c0: 290500f1 subs     x9, x9, #1
033990c4: 4a410091 add      x10, x10, #0x10
033990c8: 61ffff54 b.ne     #0x33990b4
033990cc: 22008052 mov      w2, #1
033990d0: e00315aa mov      x0, x21
033990d4: 80a06f97 bl       #0xf812d4
033990d8: 05000014 b        #0x33990ec
033990dc: 490140b9 ldr      w9, [x10]
033990e0: 29050011 add      w9, w9, #1
033990e4: 08d1298b add      x8, x8, w9, sxtw #4
033990e8: 00e10491 add      x0, x8, #0x138
033990ec: 080440a9 ldp      x8, x1, [x0]
033990f0: e00315aa mov      x0, x21
033990f4: 00013fd6 blr      x8
033990f8: 343500b4 cbz      x20, #0x339979c
033990fc: e00314aa mov      x0, x20
03399100: e1031faa mov      x1, xzr
03399104: 20c82594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
03399108: 603640f9 ldr      x0, [x19, #0x68]
0339910c: e20f00bd str      s2, [sp, #0xc]
03399110: 603400b4 cbz      x0, #0x339979c
03399114: d5f40090 adrp     x21, #0x5231000
03399118: fdf200f0 adrp     x29, #0x51f8000
0339911c: 7cf000f0 adrp     x28, #0x51a8000
03399120: faf300b0 adrp     x26, #0x5216000
03399124: 79f200b0 adrp     x25, #0x51e6000
03399128: b53a41f9 ldr      x21, [x21, #0x270]
0339912c: bd0b47f9 ldr      x29, [x29, #0xe10]
03399130: 9cdf41f9 ldr      x28, [x28, #0x3b8]
03399134: 5a1f44f9 ldr      x26, [x26, #0x838]
03399138: 397b40f9 ldr      x25, [x25, #0xf0]
0339913c: e1031faa mov      x1, xzr
03399140: 0c1ca04e mov      v12.16b, v0.16b
03399144: 281ca14e mov      v8.16b, v1.16b
03399148: 39c32594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
0339914c: 68424039 ldrb     w8, [x19, #0x10]
03399150: 091ca04e mov      v9.16b, v0.16b
03399154: 2f1ca14e mov      v15.16b, v1.16b
03399158: 4a1ca24e mov      v10.16b, v2.16b
0339915c: ee1300bd str      s14, [sp, #0x10]
03399160: 48100034 cbz      w8, #0x3399368
03399164: 680240f9 ldr      x8, [x19]
03399168: 21008052 mov      w1, #1
0339916c: e00313aa mov      x0, x19
03399170: 0e1da84e mov      v14.16b, v8.16b
03399174: 095d41f9 ldr      x9, [x8, #0x2b8]
03399178: 026141f9 ldr      x2, [x8, #0x2c0]
0339917c: 881dac4e mov      v8.16b, v12.16b
03399180: 20013fd6 blr      x9
03399184: a00240f9 ldr      x0, [x21]
03399188: c1008052 mov      w1, #6
0339918c: 79607097 bl       #0xfb1370
03399190: f40300aa mov      x20, x0
03399194: 600340f9 ldr      x0, [x27]
03399198: e1830191 add      x1, sp, #0x60
0339919c: e93f0c2d stp      s9, s15, [sp, #0x60]
033991a0: ea6b00bd str      s10, [sp, #0x68]
033991a4: 9a607097 bl       #0xfb140c
033991a8: b42f00b4 cbz      x20, #0x339979c
033991ac: eaa7432d ldp      s10, s9, [sp, #0x1c]
033991b0: ec1b40bd ldr      s12, [sp, #0x18]
033991b4: f50300aa mov      x21, x0
033991b8: c00000b4 cbz      x0, #0x33991d0
033991bc: 880240f9 ldr      x8, [x20]
033991c0: e00315aa mov      x0, x21
033991c4: 012140f9 ldr      x1, [x8, #0x40]
033991c8: 90607097 bl       #0xfb1408
033991cc: c02e00b4 cbz      x0, #0x33997a4
033991d0: 881a40b9 ldr      w8, [x20, #0x18]
033991d4: 682e0034 cbz      w8, #0x33997a0
033991d8: e00314aa mov      x0, x20
033991dc: 150c02f8 str      x21, [x0, #0x20]!
033991e0: e10315aa mov      x1, x21
033991e4: 32607097 bl       #0xfb12ac
033991e8: 600340f9 ldr      x0, [x27]
033991ec: e1430191 add      x1, sp, #0x50
033991f0: ec2b0a2d stp      s12, s10, [sp, #0x50]
033991f4: ed5b00bd str      s13, [sp, #0x58]
033991f8: 85607097 bl       #0xfb140c
033991fc: f50300aa mov      x21, x0
03399200: c00000b4 cbz      x0, #0x3399218
03399204: 880240f9 ldr      x8, [x20]
03399208: e00315aa mov      x0, x21
0339920c: 012140f9 ldr      x1, [x8, #0x40]
03399210: 7e607097 bl       #0xfb1408
03399214: 802c00b4 cbz      x0, #0x33997a4
03399218: 881a40b9 ldr      w8, [x20, #0x18]
0339921c: 1f050071 cmp      w8, #1
03399220: 092c0054 b.ls     #0x33997a0
03399224: e00314aa mov      x0, x20
03399228: 158c02f8 str      x21, [x0, #0x28]!
0339922c: e10315aa mov      x1, x21
03399230: 1f607097 bl       #0xfb12ac
03399234: 600340f9 ldr      x0, [x27]
03399238: e00f40bd ldr      s0, [sp, #0xc]
0339923c: e1030191 add      x1, sp, #0x40
03399240: e83b082d stp      s8, s14, [sp, #0x40]
03399244: e04b00bd str      s0, [sp, #0x48]
03399248: 71607097 bl       #0xfb140c
0339924c: f50300aa mov      x21, x0
03399250: c00000b4 cbz      x0, #0x3399268
03399254: 880240f9 ldr      x8, [x20]
03399258: e00315aa mov      x0, x21
0339925c: 012140f9 ldr      x1, [x8, #0x40]
03399260: 6a607097 bl       #0xfb1408
03399264: 002a00b4 cbz      x0, #0x33997a4
03399268: 881a40b9 ldr      w8, [x20, #0x18]
0339926c: ed1340bd ldr      s13, [sp, #0x10]
03399270: 1f090071 cmp      w8, #2
03399274: 69290054 b.ls     #0x33997a0
03399278: e00314aa mov      x0, x20
0339927c: 150c03f8 str      x21, [x0, #0x30]!
03399280: e10315aa mov      x1, x21
03399284: 0a607097 bl       #0xfb12ac
03399288: 600340f9 ldr      x0, [x27]
0339928c: e02740bd ldr      s0, [sp, #0x24]
03399290: e1c30091 add      x1, sp, #0x30
03399294: ed3b00bd str      s13, [sp, #0x38]
03399298: e903062d stp      s9, s0, [sp, #0x30]
0339929c: 5c607097 bl       #0xfb140c
033992a0: f50300aa mov      x21, x0
033992a4: c00000b4 cbz      x0, #0x33992bc
033992a8: 880240f9 ldr      x8, [x20]
033992ac: e00315aa mov      x0, x21
033992b0: 012140f9 ldr      x1, [x8, #0x40]
033992b4: 55607097 bl       #0xfb1408
033992b8: 602700b4 cbz      x0, #0x33997a4
033992bc: 881a40b9 ldr      w8, [x20, #0x18]
033992c0: 1f0d0071 cmp      w8, #3
033992c4: e9260054 b.ls     #0x33997a0
033992c8: e00314aa mov      x0, x20
033992cc: 158c03f8 str      x21, [x0, #0x38]!
033992d0: e10315aa mov      x1, x21
033992d4: f65f7097 bl       #0xfb12ac
033992d8: a00340f9 ldr      x0, [x29]
033992dc: e1b30091 add      x1, sp, #0x2c
033992e0: eb2f00bd str      s11, [sp, #0x2c]
033992e4: 4a607097 bl       #0xfb140c
033992e8: f50300aa mov      x21, x0
033992ec: c00000b4 cbz      x0, #0x3399304
033992f0: 880240f9 ldr      x8, [x20]
033992f4: e00315aa mov      x0, x21
033992f8: 012140f9 ldr      x1, [x8, #0x40]
033992fc: 43607097 bl       #0xfb1408
03399300: 202500b4 cbz      x0, #0x33997a4
03399304: 881a40b9 ldr      w8, [x20, #0x18]
03399308: 1f110071 cmp      w8, #4
0339930c: a9240054 b.ls     #0x33997a0
03399310: e00314aa mov      x0, x20
03399314: 150c04f8 str      x21, [x0, #0x40]!
03399318: e10315aa mov      x1, x21
0339931c: e45f7097 bl       #0xfb12ac
03399320: 687a40b9 ldr      w8, [x19, #0x78]
03399324: 800340f9 ldr      x0, [x28]
03399328: e1a30091 add      x1, sp, #0x28
0339932c: e82b00b9 str      w8, [sp, #0x28]
03399330: 37607097 bl       #0xfb140c
03399334: f50300aa mov      x21, x0
03399338: c00000b4 cbz      x0, #0x3399350
0339933c: 880240f9 ldr      x8, [x20]
03399340: e00315aa mov      x0, x21
03399344: 012140f9 ldr      x1, [x8, #0x40]
03399348: 30607097 bl       #0xfb1408
0339934c: c02200b4 cbz      x0, #0x33997a4
03399350: 881a40b9 ldr      w8, [x20, #0x18]
03399354: 1f150071 cmp      w8, #5
03399358: 49220054 b.ls     #0x33997a0
0339935c: dbf30090 adrp     x27, #0x5211000
03399360: 7be740f9 ldr      x27, [x27, #0x1c8]
03399364: 98000014 b        #0x33995c4
03399368: 743a40f9 ldr      x20, [x19, #0x70]
0339936c: 942100b4 cbz      x20, #0x339979c
03399370: 880240f9 ldr      x8, [x20]
03399374: e10240f9 ldr      x1, [x23]
03399378: 09554279 ldrh     w9, [x8, #0x12a]
0339937c: 290100b4 cbz      x9, #0x33993a0
03399380: 0a5940f9 ldr      x10, [x8, #0xb0]
03399384: 4a210091 add      x10, x10, #8
03399388: 4b815ff8 ldur     x11, [x10, #-8]
0339938c: 7f0101eb cmp      x11, x1
03399390: 20010054 b.eq     #0x33993b4
03399394: 290500f1 subs     x9, x9, #1
03399398: 4a410091 add      x10, x10, #0x10
0339939c: 61ffff54 b.ne     #0x3399388
033993a0: 62008052 mov      w2, #3
033993a4: e00314aa mov      x0, x20
033993a8: 0e1da84e mov      v14.16b, v8.16b
033993ac: ca9f6f97 bl       #0xf812d4
033993b0: 06000014 b        #0x33993c8
033993b4: 490140b9 ldr      w9, [x10]
033993b8: 0e1da84e mov      v14.16b, v8.16b
033993bc: 290d0011 add      w9, w9, #3
033993c0: 08d1298b add      x8, x8, w9, sxtw #4
033993c4: 00e10491 add      x0, x8, #0x138
033993c8: 080440a9 ldp      x8, x1, [x0]
033993cc: e00314aa mov      x0, x20
033993d0: 881dac4e mov      v8.16b, v12.16b
033993d4: 00013fd6 blr      x8
033993d8: 28008052 mov      w8, #1
033993dc: 68420039 strb     w8, [x19, #0x10]
033993e0: 7f1600b9 str      wzr, [x19, #0x14]
033993e4: a00240f9 ldr      x0, [x21]
033993e8: c1008052 mov      w1, #6
033993ec: e15f7097 bl       #0xfb1370
033993f0: f40300aa mov      x20, x0
033993f4: 600340f9 ldr      x0, [x27]
033993f8: e1830191 add      x1, sp, #0x60
033993fc: e93f0c2d stp      s9, s15, [sp, #0x60]
03399400: ea6b00bd str      s10, [sp, #0x68]
03399404: 02607097 bl       #0xfb140c
03399408: b41c00b4 cbz      x20, #0x339979c
0339940c: eaa7432d ldp      s10, s9, [sp, #0x1c]
03399410: ec1b40bd ldr      s12, [sp, #0x18]
03399414: f50300aa mov      x21, x0
03399418: c00000b4 cbz      x0, #0x3399430
0339941c: 880240f9 ldr      x8, [x20]
03399420: e00315aa mov      x0, x21
03399424: 012140f9 ldr      x1, [x8, #0x40]
03399428: f85f7097 bl       #0xfb1408
0339942c: c01b00b4 cbz      x0, #0x33997a4
03399430: 881a40b9 ldr      w8, [x20, #0x18]
03399434: 681b0034 cbz      w8, #0x33997a0
03399438: e00314aa mov      x0, x20
0339943c: 150c02f8 str      x21, [x0, #0x20]!
03399440: e10315aa mov      x1, x21
03399444: 9a5f7097 bl       #0xfb12ac
03399448: 600340f9 ldr      x0, [x27]
0339944c: e1430191 add      x1, sp, #0x50
03399450: ec2b0a2d stp      s12, s10, [sp, #0x50]
03399454: ed5b00bd str      s13, [sp, #0x58]
03399458: ed5f7097 bl       #0xfb140c
0339945c: f50300aa mov      x21, x0
03399460: c00000b4 cbz      x0, #0x3399478
03399464: 880240f9 ldr      x8, [x20]
03399468: e00315aa mov      x0, x21
0339946c: 012140f9 ldr      x1, [x8, #0x40]
03399470: e65f7097 bl       #0xfb1408
03399474: 801900b4 cbz      x0, #0x33997a4
03399478: 881a40b9 ldr      w8, [x20, #0x18]
0339947c: 1f050071 cmp      w8, #1
03399480: 09190054 b.ls     #0x33997a0
03399484: e00314aa mov      x0, x20
03399488: 158c02f8 str      x21, [x0, #0x28]!
0339948c: e10315aa mov      x1, x21
03399490: 875f7097 bl       #0xfb12ac
03399494: 600340f9 ldr      x0, [x27]
03399498: e00f40bd ldr      s0, [sp, #0xc]
0339949c: e1030191 add      x1, sp, #0x40
033994a0: e83b082d stp      s8, s14, [sp, #0x40]
033994a4: e04b00bd str      s0, [sp, #0x48]
033994a8: d95f7097 bl       #0xfb140c
033994ac: f50300aa mov      x21, x0
033994b0: c00000b4 cbz      x0, #0x33994c8
033994b4: 880240f9 ldr      x8, [x20]
033994b8: e00315aa mov      x0, x21
033994bc: 012140f9 ldr      x1, [x8, #0x40]
033994c0: d25f7097 bl       #0xfb1408
033994c4: 001700b4 cbz      x0, #0x33997a4
033994c8: 881a40b9 ldr      w8, [x20, #0x18]
033994cc: e81340bd ldr      s8, [sp, #0x10]
033994d0: 1f090071 cmp      w8, #2
033994d4: 69160054 b.ls     #0x33997a0
033994d8: e00314aa mov      x0, x20
033994dc: 150c03f8 str      x21, [x0, #0x30]!
033994e0: e10315aa mov      x1, x21
033994e4: 725f7097 bl       #0xfb12ac
033994e8: 600340f9 ldr      x0, [x27]
033994ec: e02740bd ldr      s0, [sp, #0x24]
033994f0: e1c30091 add      x1, sp, #0x30
033994f4: e83b00bd str      s8, [sp, #0x38]
033994f8: e903062d stp      s9, s0, [sp, #0x30]
033994fc: c45f7097 bl       #0xfb140c
03399500: f50300aa mov      x21, x0
03399504: c00000b4 cbz      x0, #0x339951c
03399508: 880240f9 ldr      x8, [x20]
0339950c: e00315aa mov      x0, x21
03399510: 012140f9 ldr      x1, [x8, #0x40]
03399514: bd5f7097 bl       #0xfb1408
03399518: 601400b4 cbz      x0, #0x33997a4
0339951c: 881a40b9 ldr      w8, [x20, #0x18]
03399520: 1f0d0071 cmp      w8, #3
03399524: e9130054 b.ls     #0x33997a0
03399528: e00314aa mov      x0, x20
0339952c: 158c03f8 str      x21, [x0, #0x38]!
03399530: e10315aa mov      x1, x21
03399534: 5e5f7097 bl       #0xfb12ac
03399538: a00340f9 ldr      x0, [x29]
0339953c: e1b30091 add      x1, sp, #0x2c
03399540: eb2f00bd str      s11, [sp, #0x2c]
03399544: b25f7097 bl       #0xfb140c
03399548: f50300aa mov      x21, x0
0339954c: c00000b4 cbz      x0, #0x3399564
03399550: 880240f9 ldr      x8, [x20]
03399554: e00315aa mov      x0, x21
03399558: 012140f9 ldr      x1, [x8, #0x40]
0339955c: ab5f7097 bl       #0xfb1408
03399560: 201200b4 cbz      x0, #0x33997a4
03399564: 881a40b9 ldr      w8, [x20, #0x18]
03399568: 1f110071 cmp      w8, #4
0339956c: a9110054 b.ls     #0x33997a0
03399570: e00314aa mov      x0, x20
03399574: 150c04f8 str      x21, [x0, #0x40]!
03399578: e10315aa mov      x1, x21
0339957c: 4c5f7097 bl       #0xfb12ac
03399580: 687a40b9 ldr      w8, [x19, #0x78]
03399584: 800340f9 ldr      x0, [x28]
03399588: e1a30091 add      x1, sp, #0x28
0339958c: e82b00b9 str      w8, [sp, #0x28]
03399590: 9f5f7097 bl       #0xfb140c
03399594: f50300aa mov      x21, x0
03399598: c00000b4 cbz      x0, #0x33995b0
0339959c: 880240f9 ldr      x8, [x20]
033995a0: e00315aa mov      x0, x21
033995a4: 012140f9 ldr      x1, [x8, #0x40]
033995a8: 985f7097 bl       #0xfb1408
033995ac: c00f00b4 cbz      x0, #0x33997a4
033995b0: 881a40b9 ldr      w8, [x20, #0x18]
033995b4: 1f150071 cmp      w8, #5
033995b8: 490f0054 b.ls     #0x33997a0
033995bc: fbf100f0 adrp     x27, #0x51d8000
033995c0: 7b4f44f9 ldr      x27, [x27, #0x898]
033995c4: e00314aa mov      x0, x20
033995c8: 158c04f8 str      x21, [x0, #0x48]!
033995cc: e10315aa mov      x1, x21
033995d0: 375f7097 bl       #0xfb12ac
033995d4: 600340f9 ldr      x0, [x27]
033995d8: e10314aa mov      x1, x20
033995dc: e2031faa mov      x2, xzr
033995e0: d4bba597 bl       #0x1d08530 ; System.String$$Format
033995e4: 480340f9 ldr      x8, [x26]
033995e8: f50300aa mov      x21, x0
033995ec: e00308aa mov      x0, x8
033995f0: 8a5f7097 bl       #0xfb1418
033995f4: 400d00b4 cbz      x0, #0x339979c
033995f8: e10315aa mov      x1, x21
033995fc: e2031faa mov      x2, xzr
03399600: f40300aa mov      x20, x0
03399604: 2f38bb97 bl       #0x22676c0 ; System.Exception$$.ctor
03399608: 200340f9 ldr      x0, [x25]
0339960c: 08e040b9 ldr      w8, [x0, #0xe0]
03399610: 48000035 cbnz     w8, #0x3399618
03399614: 7c5f7097 bl       #0xfb1404
03399618: 61018052 mov      w1, #0xb
0339961c: e00314aa mov      x0, x20
03399620: e2031faa mov      x2, xzr
03399624: e3031faa mov      x3, xzr
03399628: 6f00eb97 bl       #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
0339962c: 603640f9 ldr      x0, [x19, #0x68]
03399630: 600b00b4 cbz      x0, #0x339979c
03399634: e1031faa mov      x1, xzr
03399638: afc12594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339963c: 743a40f9 ldr      x20, [x19, #0x70]
03399640: f40a00b4 cbz      x20, #0x339979c
03399644: 880240f9 ldr      x8, [x20]
03399648: e10240f9 ldr      x1, [x23]
0339964c: 081ca04e mov      v8.16b, v0.16b
03399650: 291ca14e mov      v9.16b, v1.16b
03399654: 09554279 ldrh     w9, [x8, #0x12a]
03399658: 4a1ca24e mov      v10.16b, v2.16b
0339965c: 290100b4 cbz      x9, #0x3399680
03399660: 0a5940f9 ldr      x10, [x8, #0xb0]
03399664: 4a210091 add      x10, x10, #8
03399668: 4b815ff8 ldur     x11, [x10, #-8]
0339966c: 7f0101eb cmp      x11, x1
03399670: 00010054 b.eq     #0x3399690
03399674: 290500f1 subs     x9, x9, #1
03399678: 4a410091 add      x10, x10, #0x10
0339967c: 61ffff54 b.ne     #0x3399668
03399680: 22008052 mov      w2, #1
03399684: e00314aa mov      x0, x20
03399688: 139f6f97 bl       #0xf812d4
0339968c: 05000014 b        #0x33996a0
03399690: 490140b9 ldr      w9, [x10]
03399694: 29050011 add      w9, w9, #1
03399698: 08d1298b add      x8, x8, w9, sxtw #4
0339969c: 00e10491 add      x0, x8, #0x138
033996a0: 080440a9 ldp      x8, x1, [x0]
033996a4: e00314aa mov      x0, x20
033996a8: 00013fd6 blr      x8
033996ac: c81a6039 ldrb     w8, [x22, #0x806]
033996b0: 0b1ca04e mov      v11.16b, v0.16b
033996b4: 2c1ca14e mov      v12.16b, v1.16b
033996b8: 4d1ca24e mov      v13.16b, v2.16b
033996bc: c8000035 cbnz     w8, #0x33996d4
033996c0: 20f300f0 adrp     x0, #0x5200000
033996c4: 008c46f9 ldr      x0, [x0, #0xd18]
033996c8: 0e5f7097 bl       #0xfb1300
033996cc: 28008052 mov      w8, #1
033996d0: c81a2039 strb     w8, [x22, #0x806]
033996d4: 000340f9 ldr      x0, [x24]
033996d8: 08e040b9 ldr      w8, [x0, #0xe0]
033996dc: 48000035 cbnz     w8, #0x33996e4
033996e0: 495f7097 bl       #0xfb1404
033996e4: 680240f9 ldr      x8, [x19]
033996e8: 6e2240bd ldr      s14, [x19, #0x20]
033996ec: e00313aa mov      x0, x19
033996f0: 094d41f9 ldr      x9, [x8, #0x298]
033996f4: 015141f9 ldr      x1, [x8, #0x2a0]
033996f8: 20013fd6 blr      x9
033996fc: c021201e fcmp     s14, s0
03399700: 6b030054 b.lt     #0x339976c
03399704: 00392b1e fsub     s0, s8, s11
03399708: 21392c1e fsub     s1, s9, s12
0339970c: 42392d1e fsub     s2, s10, s13
03399710: 0008201e fmul     s0, s0, s0
03399714: 2108211e fmul     s1, s1, s1
03399718: 685600d0 adrp     x8, #0x3e67000
0339971c: 0028211e fadd     s0, s0, s1
03399720: 4108221e fmul     s1, s2, s2
03399724: 024944bd ldr      s2, [x8, #0x448]
03399728: 2028201e fadd     s0, s1, s0
0339972c: 08c0211e fsqrt    s8, s0
03399730: e103271e fmov     s1, wzr
03399734: 001da84e mov      v0.16b, v8.16b
03399738: e0031faa mov      x0, xzr
0339973c: 8294fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
03399740: 685600d0 adrp     x8, #0x3e67000
03399744: 009544bd ldr      s0, [x8, #0x494]
03399748: 0021201e fcmp     s8, s0
0339974c: 44000054 b.mi     #0x3399754
03399750: e0000036 tbz      w0, #0, #0x339976c
03399754: 680240f9 ldr      x8, [x19]
03399758: e00313aa mov      x0, x19
0339975c: e1031f2a mov      w1, wzr
03399760: 095d41f9 ldr      x9, [x8, #0x2b8]
03399764: 026141f9 ldr      x2, [x8, #0x2c0]
03399768: 20013fd6 blr      x9
0339976c: fd7b50a9 ldp      x29, x30, [sp, #0x100]
03399770: f44f4fa9 ldp      x20, x19, [sp, #0xf0]
03399774: f6574ea9 ldp      x22, x21, [sp, #0xe0]
03399778: f85f4da9 ldp      x24, x23, [sp, #0xd0]
0339977c: fa674ca9 ldp      x26, x25, [sp, #0xc0]
03399780: fc6f4ba9 ldp      x28, x27, [sp, #0xb0]
03399784: e9234a6d ldp      d9, d8, [sp, #0xa0]
03399788: eb2b496d ldp      d11, d10, [sp, #0x90]
0339978c: ed33486d ldp      d13, d12, [sp, #0x80]
03399790: ef3b476d ldp      d15, d14, [sp, #0x70]
03399794: ff430491 add      sp, sp, #0x110
03399798: c0035fd6 ret      
0339979c: 235f7097 bl       #0xfb1428
033997a0: 245f7097 bl       #0xfb1430
033997a4: 2a5f7097 bl       #0xfb144c
033997a8: e1031faa mov      x1, xzr
033997ac: 115f7097 bl       #0xfb13f0
