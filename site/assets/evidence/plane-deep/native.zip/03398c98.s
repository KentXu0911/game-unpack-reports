# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$TargetChanged
# Linear span to next metadata entry; not a complete CFG.
03398c98: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
03398c9c: 002040bd ldr      s0, [x0, #0x20]
03398ca0: 01102c1e fmov     s1, #0.50000000
03398ca4: 48008052 mov      w8, #2
03398ca8: f30300aa mov      x19, x0
03398cac: 0058211e fmin     s0, s0, s1
03398cb0: 087800b9 str      w8, [x0, #0x78]
03398cb4: 1f8400b9 str      wzr, [x0, #0x84]
03398cb8: 002000bd str      s0, [x0, #0x20]
03398cbc: e0031faa mov      x0, xzr
03398cc0: dae7ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
03398cc4: 689640b9 ldr      w8, [x19, #0x94]
03398cc8: 602600bd str      s0, [x19, #0x24]
03398ccc: 1f090071 cmp      w8, #2
03398cd0: 61000054 b.ne     #0x3398cdc
03398cd4: 28008052 mov      w8, #1
03398cd8: 689600b9 str      w8, [x19, #0x94]
03398cdc: f37bc1a8 ldp      x19, x30, [sp], #0x10
03398ce0: c0035fd6 ret      
