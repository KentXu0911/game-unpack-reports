# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$.cctor
# Linear span to next metadata entry; not a complete CFG.
033a28a0: f40f1ef8 str      x20, [sp, #-0x20]!
033a28a4: f37b01a9 stp      x19, x30, [sp, #0x10]
033a28a8: 330f0190 adrp     x19, #0x5586000
033a28ac: 54f200b0 adrp     x20, #0x51eb000
033a28b0: 681a6739 ldrb     w8, [x19, #0x9c6]
033a28b4: 949e40f9 ldr      x20, [x20, #0x138]
033a28b8: c8000037 tbnz     w8, #0, #0x33a28d0
033a28bc: 40f200b0 adrp     x0, #0x51eb000
033a28c0: 009c40f9 ldr      x0, [x0, #0x138]
033a28c4: 8f3a7097 bl       #0xfb1300
033a28c8: 28008052 mov      w8, #1
033a28cc: 681a2739 strb     w8, [x19, #0x9c6]
033a28d0: 880240f9 ldr      x8, [x20]
033a28d4: 295b00f0 adrp     x9, #0x3f09000
033a28d8: 205544fd ldr      d0, [x9, #0x8a8]
033a28dc: 085d40f9 ldr      x8, [x8, #0xb8]
033a28e0: 000100fd str      d0, [x8]
033a28e4: 1f0900b9 str      wzr, [x8, #8]
033a28e8: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a28ec: f40742f8 ldr      x20, [sp], #0x20
033a28f0: c0035fd6 ret      
