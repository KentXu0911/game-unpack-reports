# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_CreationStateId
# Linear span to next metadata entry; not a complete CFG.
03397fe4: f40f1ef8 str      x20, [sp, #-0x20]!
03397fe8: f37b01a9 stp      x19, x30, [sp, #0x10]
03397fec: 740f01f0 adrp     x20, #0x5586000
03397ff0: f3f100b0 adrp     x19, #0x51d4000
03397ff4: 88526639 ldrb     w8, [x20, #0x994]
03397ff8: 73da41f9 ldr      x19, [x19, #0x3b0]
03397ffc: c8000037 tbnz     w8, #0, #0x3398014
03398000: e0f10090 adrp     x0, #0x51d4000
03398004: 00d841f9 ldr      x0, [x0, #0x3b0]
03398008: be647097 bl       #0xfb1300
0339800c: 28008052 mov      w8, #1
03398010: 88522639 strb     w8, [x20, #0x994]
03398014: 600240f9 ldr      x0, [x19]
03398018: 08e040b9 ldr      w8, [x0, #0xe0]
0339801c: 68000035 cbnz     w8, #0x3398028
03398020: f9647097 bl       #0xfb1404
03398024: 600240f9 ldr      x0, [x19]
03398028: 085c40f9 ldr      x8, [x0, #0xb8]
0339802c: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398030: 000140b9 ldr      w0, [x8]
03398034: f40742f8 ldr      x20, [sp], #0x20
03398038: c0035fd6 ret      
