# Royal.Scenes.Game.Mechanics.Items.SquirrelItem.SquirrelVerticalItem.SquirrelVerticalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03688768: f75bbda9 stp      x23, x22, [sp, #-0x30]!
0368876c: f55301a9 stp      x21, x20, [sp, #0x10]
03688770: f37b02a9 stp      x19, x30, [sp, #0x20]
03688774: 080040f9 ldr      x8, [x0]
03688778: f303012a mov      w19, w1
0368877c: f40300aa mov      x20, x0
03688780: 096542f9 ldr      x9, [x8, #0x4c8]
03688784: 086942f9 ldr      x8, [x8, #0x4d0]
03688788: e10308aa mov      x1, x8
0368878c: 20013fd6 blr      x9
03688790: f603002a mov      w22, w0
03688794: e003132a mov      w0, w19
03688798: e1031faa mov      x1, xzr
0368879c: 84f0f397 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
036887a0: c0000036 tbz      w0, #0, #0x36887b8
036887a4: df0a0071 cmp      w22, #2
036887a8: ed020054 b.le     #0x3688804
036887ac: 15168b52 mov      w21, #0x58b0
036887b0: 7500a072 movk     w21, #3, lsl #16
036887b4: 23000014 b        #0x3688840
036887b8: 17229f52 mov      w23, #0xf910
036887bc: df0e0071 cmp      w22, #3
036887c0: d700a072 movk     w23, #6, lsl #16
036887c4: e0020054 b.eq     #0x3688820
036887c8: 15229f52 mov      w21, #0xf910
036887cc: df0a0071 cmp      w22, #2
036887d0: d500a072 movk     w21, #6, lsl #16
036887d4: 60030054 b.eq     #0x3688840
036887d8: df060071 cmp      w22, #1
036887dc: 41010054 b.ne     #0x3688804
036887e0: 15449e52 mov      w21, #0xf220
036887e4: e003132a mov      w0, w19
036887e8: e1031faa mov      x1, xzr
036887ec: b501a072 movk     w21, #0xd, lsl #16
036887f0: 53f0f397 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
036887f4: 60020037 tbnz     w0, #0, #0x3688840
036887f8: 7f0a0071 cmp      w19, #2
036887fc: a002971a csel     w0, w21, w23, eq
03688800: 11000014 b        #0x3688844
03688804: e00314aa mov      x0, x20
03688808: e103132a mov      w1, w19
0368880c: f37b42a9 ldp      x19, x30, [sp, #0x20]
03688810: f55341a9 ldp      x21, x20, [sp, #0x10]
03688814: e2031faa mov      x2, xzr
03688818: f75bc3a8 ldp      x23, x22, [sp], #0x30
0368881c: 1d25f417 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
03688820: 68021f32 orr      w8, w19, #2
03688824: 1f1d0071 cmp      w8, #7
03688828: 81000054 b.ne     #0x3688838
0368882c: 15229f52 mov      w21, #0xf910
03688830: d500a072 movk     w21, #6, lsl #16
03688834: 03000014 b        #0x3688840
03688838: 15819252 mov      w21, #0x9408
0368883c: b500a072 movk     w21, #5, lsl #16
03688840: e003152a mov      w0, w21
03688844: f37b42a9 ldp      x19, x30, [sp, #0x20]
03688848: f55341a9 ldp      x21, x20, [sp, #0x10]
0368884c: f75bc3a8 ldp      x23, x22, [sp], #0x30
03688850: c0035fd6 ret      
