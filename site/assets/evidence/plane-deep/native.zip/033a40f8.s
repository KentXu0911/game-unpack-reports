# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy$$IsTntOrRocketCombo
# Linear span to next metadata entry; not a complete CFG.
033a40f8: 20008052 mov      w0, #1
033a40fc: c0035fd6 ret      
