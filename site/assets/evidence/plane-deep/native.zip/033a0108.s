# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TargetStepUpdated
# Linear span to next metadata entry; not a complete CFG.
033a0108: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a010c: 001c40bd ldr      s0, [x0, #0x1c]
033a0110: 01102c1e fmov     s1, #0.50000000
033a0114: 48008052 mov      w8, #2
033a0118: f30300aa mov      x19, x0
033a011c: 0058211e fmin     s0, s0, s1
033a0120: 083400f9 str      x8, [x0, #0x68]
033a0124: 001c00bd str      s0, [x0, #0x1c]
033a0128: e0031faa mov      x0, xzr
033a012c: bfcace97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a0130: 688640b9 ldr      w8, [x19, #0x84]
033a0134: 602600bd str      s0, [x19, #0x24]
033a0138: 1f090071 cmp      w8, #2
033a013c: 81000054 b.ne     #0x33a014c
033a0140: 28008052 mov      w8, #1
033a0144: 688600b9 str      w8, [x19, #0x84]
033a0148: 68560239 strb     w8, [x19, #0x95]
033a014c: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a0150: c0035fd6 ret      
