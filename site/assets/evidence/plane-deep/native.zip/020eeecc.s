# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ArrangeWinCalculationData
# Linear span to next metadata entry; not a complete CFG.
020eeecc: f553bea9 stp      x21, x20, [sp, #-0x20]!
020eeed0: f37b01a9 stp      x19, x30, [sp, #0x10]
020eeed4: 74a401f0 adrp     x20, #0x557d000
020eeed8: 15850190 adrp     x21, #0x518e000
020eeedc: 880a5539 ldrb     w8, [x20, #0x542]
020eeee0: b5aa42f9 ldr      x21, [x21, #0x550]
020eeee4: f30300aa mov      x19, x0
020eeee8: c8000037 tbnz     w8, #0, #0x20eef00
020eeeec: 00850190 adrp     x0, #0x518e000
020eeef0: 00a842f9 ldr      x0, [x0, #0x550]
020eeef4: 0309bb97 bl       #0xfb1300
020eeef8: 28008052 mov      w8, #1
020eeefc: 880a1539 strb     w8, [x20, #0x542]
020eef00: f40313aa mov      x20, x19
020eef04: 880e47f8 ldr      x8, [x20, #0x70]!
020eef08: a00240f9 ldr      x0, [x21]
020eef0c: c80000b4 cbz      x8, #0x20eef24
020eef10: 080140f9 ldr      x8, [x8]
020eef14: 09b04439 ldrb     w9, [x0, #0x12c]
020eef18: 0ab14439 ldrb     w10, [x8, #0x12c]
020eef1c: 5f01096b cmp      w10, w9
020eef20: 82000054 b.hs     #0x20eef30
020eef24: 68e24239 ldrb     w8, [x19, #0xb8]
020eef28: 28010035 cbnz     w8, #0x20eef4c
020eef2c: 1a000014 b        #0x20eef94
020eef30: 086540f9 ldr      x8, [x8, #0xc8]
020eef34: 080d098b add      x8, x8, x9, lsl #3
020eef38: 09815ff8 ldur     x9, [x8, #-8]
020eef3c: 68e24239 ldrb     w8, [x19, #0xb8]
020eef40: 3f0100eb cmp      x9, x0
020eef44: 60020054 b.eq     #0x20eef90
020eef48: 68020034 cbz      w8, #0x20eef94
020eef4c: 618e47f8 ldr      x1, [x19, #0x78]!
020eef50: 610100b5 cbnz     x1, #0x20eef7c
020eef54: 3109bb97 bl       #0xfb1418
020eef58: 400300b4 cbz      x0, #0x20eefc0
020eef5c: e1031faa mov      x1, xzr
020eef60: f50300aa mov      x21, x0
020eef64: d7d61694 bl       #0x26a4ac0 ; Royal.Scenes.Game.Levels.Units.Explode.WaterWinCalculationData$$.ctor
020eef68: e00313aa mov      x0, x19
020eef6c: e10315aa mov      x1, x21
020eef70: 750200f9 str      x21, [x19]
020eef74: ce08bb97 bl       #0xfb12ac
020eef78: 610240f9 ldr      x1, [x19]
020eef7c: 810200f9 str      x1, [x20]
020eef80: e00314aa mov      x0, x20
020eef84: f37b41a9 ldp      x19, x30, [sp, #0x10]
020eef88: f553c2a8 ldp      x21, x20, [sp], #0x20
020eef8c: c808bb17 b        #0xfb12ac
020eef90: 88000034 cbz      w8, #0x20eefa0
020eef94: f37b41a9 ldp      x19, x30, [sp, #0x10]
020eef98: f553c2a8 ldp      x21, x20, [sp], #0x20
020eef9c: c0035fd6 ret      
020eefa0: 614240f9 ldr      x1, [x19, #0x80]
020eefa4: e00314aa mov      x0, x20
020eefa8: 613a00f9 str      x1, [x19, #0x70]
020eefac: c008bb97 bl       #0xfb12ac
020eefb0: 7f8e07f8 str      xzr, [x19, #0x78]!
020eefb4: e00313aa mov      x0, x19
020eefb8: e1031faa mov      x1, xzr
020eefbc: f2ffff17 b        #0x20eef84
020eefc0: 1a09bb97 bl       #0xfb1428
