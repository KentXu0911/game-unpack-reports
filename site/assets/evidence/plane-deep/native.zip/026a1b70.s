# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TargetFound
# Linear span to next metadata entry; not a complete CFG.
026a1b70: f40f1ef8 str      x20, [sp, #-0x20]!
026a1b74: f37b01a9 stp      x19, x30, [sp, #0x10]
026a1b78: f30300aa mov      x19, x0
026a1b7c: 00200591 add      x0, x0, #0x148
026a1b80: f40301aa mov      x20, x1
026a1b84: 61a600f9 str      x1, [x19, #0x148]
026a1b88: c93da497 bl       #0xfb12ac
026a1b8c: d40100b4 cbz      x20, #0x26a1bc4
026a1b90: 606e40f9 ldr      x0, [x19, #0xd8]
026a1b94: 28008052 mov      w8, #1
026a1b98: 68de0339 strb     w8, [x19, #0xf7]
026a1b9c: a00100b4 cbz      x0, #0x26a1bd0
026a1ba0: 61008052 mov      w1, #3
026a1ba4: e2031faa mov      x2, xzr
026a1ba8: 7a290e94 bl       #0x2a2c190 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$OperationStart
026a1bac: 606e40f9 ldr      x0, [x19, #0xd8]
026a1bb0: 000100b4 cbz      x0, #0x26a1bd0
026a1bb4: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a1bb8: e1031faa mov      x1, xzr
026a1bbc: f40742f8 ldr      x20, [sp], #0x20
026a1bc0: 906e0e14 b        #0x2a3d600 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$StartSpecialOperation
026a1bc4: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a1bc8: f40742f8 ldr      x20, [sp], #0x20
026a1bcc: c0035fd6 ret      
026a1bd0: 163ea497 bl       #0xfb1428
