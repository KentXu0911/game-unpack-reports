# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerExtraOneStrategy$$NextExploder
# Linear span to next metadata entry; not a complete CFG.
033a3a00: ffc302d1 sub      sp, sp, #0xb0
033a3a04: f55309a9 stp      x21, x20, [sp, #0x90]
033a3a08: f37b0aa9 stp      x19, x30, [sp, #0xa0]
033a3a0c: 55d03bd5 mrs      x21, tpidr_el0
033a3a10: f40308aa mov      x20, x8
033a3a14: a81640f9 ldr      x8, [x21, #0x28]
033a3a18: f30300aa mov      x19, x0
033a3a1c: 00e4006f movi     v0.2d, #0000000000000000
033a3a20: 00018052 mov      w0, #8
033a3a24: e84700f9 str      x8, [sp, #0x88]
033a3a28: e8230091 add      x8, sp, #8
033a3a2c: e1031faa mov      x1, xzr
033a3a30: ff7f04a9 stp      xzr, xzr, [sp, #0x40]
033a3a34: ff5300b9 str      wzr, [sp, #0x50]
033a3a38: e00303ad stp      q0, q0, [sp, #0x60]
033a3a3c: fff307b8 stur     wzr, [sp, #0x7f]
033a3a40: 9a58e697 bl       #0x2d39ca8 ; Royal.Scenes.Game.Mechanics.Explode.Exploder$$Next
033a3a44: e81b40b9 ldr      w8, [sp, #0x18]
033a3a48: e083c03c ldur     q0, [sp, #8]
033a3a4c: e1d3c13c ldur     q1, [sp, #0x1d]
033a3a50: e2d3c23c ldur     q2, [sp, #0x2d]
033a3a54: e93f40b9 ldr      w9, [sp, #0x3c]
033a3a58: e85300b9 str      w8, [sp, #0x50]
033a3a5c: e013803d str      q0, [sp, #0x40]
033a3a60: e10b03ad stp      q1, q2, [sp, #0x60]
033a3a64: e9f307b8 stur     w9, [sp, #0x7f]
033a3a68: 69a24039 ldrb     w9, [x19, #0x28]
033a3a6c: 881200b9 str      w8, [x20, #0x10]
033a3a70: 8002803d str      q0, [x20]
033a3a74: e8f347b8 ldur     w8, [sp, #0x7f]
033a3a78: e10343ad ldp      q1, q0, [sp, #0x60]
033a3a7c: 89520039 strb     w9, [x20, #0x14]
033a3a80: 883600b9 str      w8, [x20, #0x34]
033a3a84: 8052823c stur     q0, [x20, #0x25]
033a3a88: 8152813c stur     q1, [x20, #0x15]
033a3a8c: a81640f9 ldr      x8, [x21, #0x28]
033a3a90: e94740f9 ldr      x9, [sp, #0x88]
033a3a94: 1f0109eb cmp      x8, x9
033a3a98: a1000054 b.ne     #0x33a3aac
033a3a9c: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
033a3aa0: f55349a9 ldp      x21, x20, [sp, #0x90]
033a3aa4: ffc30291 add      sp, sp, #0xb0
033a3aa8: c0035fd6 ret      
033a3aac: a97d6497 bl       #0xcc3150
