# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$GetItemView
# Linear span to next metadata entry; not a complete CFG.
026a1b68: 006440f9 ldr      x0, [x0, #0xc8]
026a1b6c: c0035fd6 ret      
