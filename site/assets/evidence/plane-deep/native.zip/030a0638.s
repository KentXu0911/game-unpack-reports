# Royal.Scenes.Game.Mechanics.Items.CrystalItem.CrystalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
030a0638: f40f1ef8 str      x20, [sp, #-0x20]!
030a063c: f37b01a9 stp      x19, x30, [sp, #0x10]
030a0640: 080040f9 ldr      x8, [x0]
030a0644: f403012a mov      w20, w1
030a0648: f30300aa mov      x19, x0
030a064c: 096542f9 ldr      x9, [x8, #0x4c8]
030a0650: 086942f9 ldr      x8, [x8, #0x4d0]
030a0654: e10308aa mov      x1, x8
030a0658: 20013fd6 blr      x9
030a065c: 1f040071 cmp      w0, #1
030a0660: eb000054 b.lt     #0x30a067c
030a0664: e00313aa mov      x0, x19
030a0668: f37b41a9 ldp      x19, x30, [sp, #0x10]
030a066c: e103142a mov      w1, w20
030a0670: e2031faa mov      x2, xzr
030a0674: f40742f8 ldr      x20, [sp], #0x20
030a0678: 86c50b14 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
030a067c: f37b41a9 ldp      x19, x30, [sp, #0x10]
030a0680: e0031f2a mov      w0, wzr
030a0684: f40742f8 ldr      x20, [sp], #0x20
030a0688: c0035fd6 ret      
