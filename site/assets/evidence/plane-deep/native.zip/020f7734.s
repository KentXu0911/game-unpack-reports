# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ResetPerformanceData
# Linear span to next metadata entry; not a complete CFG.
020f7734: c0035fd6 ret      
