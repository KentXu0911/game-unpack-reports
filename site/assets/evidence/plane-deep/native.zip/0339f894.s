# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$CalculateAngleSmoothCoefficient
# Linear span to next metadata entry; not a complete CFG.
0339f894: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
0339f898: f30300aa mov      x19, x0
0339f89c: e0031faa mov      x0, xzr
0339f8a0: e2ccce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339f8a4: 611a40bd ldr      s1, [x19, #0x18]
0339f8a8: 48560090 adrp     x8, #0x3e67000
0339f8ac: 027d44bd ldr      s2, [x8, #0x47c]
0339f8b0: 03102e1e fmov     s3, #1.00000000
0339f8b4: 0038211e fsub     s0, s0, s1
0339f8b8: 0018221e fdiv     s0, s0, s2
0339f8bc: 0158231e fmin     s1, s0, s3
0339f8c0: 6138211e fsub     s1, s3, s1
0339f8c4: 0820201e fcmp     s0, #0.0
0339f8c8: 205c231e fcsel    s0, s1, s3, pl
0339f8cc: f37bc1a8 ldp      x19, x30, [sp], #0x10
0339f8d0: c0035fd6 ret      
