# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$IsPropSpecialCombo
# Linear span to next metadata entry; not a complete CFG.
03399f3c: e0031f2a mov      w0, wzr
03399f40: c0035fd6 ret      
