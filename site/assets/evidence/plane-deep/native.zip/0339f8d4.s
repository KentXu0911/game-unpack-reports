# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeRotation
# Linear span to next metadata entry; not a complete CFG.
0339f8d4: ea0f1cfc str      d10, [sp, #-0x40]!
0339f8d8: e923016d stp      d9, d8, [sp, #0x10]
0339f8dc: f55302a9 stp      x21, x20, [sp, #0x20]
0339f8e0: f37b03a9 stp      x19, x30, [sp, #0x30]
0339f8e4: 340f01f0 adrp     x20, #0x5586000
0339f8e8: 88ea6639 ldrb     w8, [x20, #0x9ba]
0339f8ec: 281ca14e mov      v8.16b, v1.16b
0339f8f0: 091ca04e mov      v9.16b, v0.16b
0339f8f4: f30300aa mov      x19, x0
0339f8f8: c8000037 tbnz     w8, #0, #0x339f910
0339f8fc: 40f200d0 adrp     x0, #0x51e9000
0339f900: 00ec44f9 ldr      x0, [x0, #0x9d8]
0339f904: 7f467097 bl       #0xfb1300
0339f908: 28008052 mov      w8, #1
0339f90c: 88ea2639 strb     w8, [x20, #0x9ba]
0339f910: 602e40f9 ldr      x0, [x19, #0x58]
0339f914: c00900b4 cbz      x0, #0x339fa4c
0339f918: e1031faa mov      x1, xzr
0339f91c: f6a82594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339f920: 0238291e fsub     s2, s0, s9
0339f924: 2038281e fsub     s0, s1, s8
0339f928: 411ca24e mov      v1.16b, v2.16b
0339f92c: c18e6497 bl       #0xcc3430
0339f930: a8560090 adrp     x8, #0x3e73000
0339f934: 01914bbd ldr      s1, [x8, #0xb90]
0339f938: d50e01b0 adrp     x21, #0x5578000
0339f93c: a86e4539 ldrb     w8, [x21, #0x15b]
0339f940: 742e40f9 ldr      x20, [x19, #0x58]
0339f944: 8956b852 mov      w9, #-0x3d4c0000
0339f948: 0008211e fmul     s0, s0, s1
0339f94c: 2101271e fmov     s1, w9
0339f950: 0828211e fadd     s8, s0, s1
0339f954: c8000035 cbnz     w8, #0x339f96c
0339f958: 60f40090 adrp     x0, #0x522b000
0339f95c: 00ac43f9 ldr      x0, [x0, #0x758]
0339f960: 68467097 bl       #0xfb1300
0339f964: 28008052 mov      w8, #1
0339f968: a86e0539 strb     w8, [x21, #0x15b]
0339f96c: 68f40090 adrp     x8, #0x522b000
0339f970: 08ad43f9 ldr      x8, [x8, #0x758]
0339f974: 001da84e mov      v0.16b, v8.16b
0339f978: e0031faa mov      x0, xzr
0339f97c: 080140f9 ldr      x8, [x8]
0339f980: 085d40f9 ldr      x8, [x8, #0xb8]
0339f984: 0109492d ldp      s1, s2, [x8, #0x48]
0339f988: 035140bd ldr      s3, [x8, #0x50]
0339f98c: f9970594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339f990: f40500b4 cbz      x20, #0x339fa4c
0339f994: e00314aa mov      x0, x20
0339f998: e1031faa mov      x1, xzr
0339f99c: a0a92594 bl       #0x3d0a01c ; UnityEngine.Transform$$set_rotation
0339f9a0: 687e40b9 ldr      w8, [x19, #0x7c]
0339f9a4: c8000034 cbz      w8, #0x339f9bc
0339f9a8: f37b43a9 ldp      x19, x30, [sp, #0x30]
0339f9ac: f55342a9 ldp      x21, x20, [sp, #0x20]
0339f9b0: e923416d ldp      d9, d8, [sp, #0x10]
0339f9b4: ea0744fc ldr      d10, [sp], #0x40
0339f9b8: c0035fd6 ret      
0339f9bc: 682a40f9 ldr      x8, [x19, #0x50]
0339f9c0: 680400b4 cbz      x8, #0x339fa4c
0339f9c4: 004140f9 ldr      x0, [x8, #0x80]
0339f9c8: 200400b4 cbz      x0, #0x339fa4c
0339f9cc: e1031faa mov      x1, xzr
0339f9d0: f68c2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339f9d4: 682e40f9 ldr      x8, [x19, #0x58]
0339f9d8: a80300b4 cbz      x8, #0x339fa4c
0339f9dc: 54f200d0 adrp     x20, #0x51e9000
0339f9e0: 94ee44f9 ldr      x20, [x20, #0x9d8]
0339f9e4: f30300aa mov      x19, x0
0339f9e8: e00308aa mov      x0, x8
0339f9ec: e1031faa mov      x1, xzr
0339f9f0: c1a82594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339f9f4: 800240f9 ldr      x0, [x20]
0339f9f8: 081ca04e mov      v8.16b, v0.16b
0339f9fc: 291ca14e mov      v9.16b, v1.16b
0339fa00: 4a1ca24e mov      v10.16b, v2.16b
0339fa04: 08e040b9 ldr      w8, [x0, #0xe0]
0339fa08: 68000035 cbnz     w8, #0x339fa14
0339fa0c: 7e467097 bl       #0xfb1404
0339fa10: 800240f9 ldr      x0, [x20]
0339fa14: d30100b4 cbz      x19, #0x339fa4c
0339fa18: 085c40f9 ldr      x8, [x0, #0xb8]
0339fa1c: e00313aa mov      x0, x19
0339fa20: f37b43a9 ldp      x19, x30, [sp, #0x30]
0339fa24: f55342a9 ldp      x21, x20, [sp, #0x20]
0339fa28: 0005402d ldp      s0, s1, [x8]
0339fa2c: 020940bd ldr      s2, [x8, #8]
0339fa30: e1031faa mov      x1, xzr
0339fa34: 0029201e fadd     s0, s8, s0
0339fa38: 2129211e fadd     s1, s9, s1
0339fa3c: e923416d ldp      d9, d8, [sp, #0x10]
0339fa40: 4229221e fadd     s2, s10, s2
0339fa44: ea0744fc ldr      d10, [sp], #0x40
0339fa48: d3a82514 b        #0x3d09d94 ; UnityEngine.Transform$$set_position
0339fa4c: 77467097 bl       #0xfb1428
