# Royal.Scenes.Game.Mechanics.Items.CandyCaneItem.CandyCaneItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0271c084: fb6bbba9 stp      x27, x26, [sp, #-0x50]!
0271c088: f96301a9 stp      x25, x24, [sp, #0x10]
0271c08c: f75b02a9 stp      x23, x22, [sp, #0x20]
0271c090: f55303a9 stp      x21, x20, [sp, #0x30]
0271c094: f37b04a9 stp      x19, x30, [sp, #0x40]
0271c098: 35730190 adrp     x21, #0x5580000
0271c09c: a8125239 ldrb     w8, [x21, #0x484]
0271c0a0: f403012a mov      w20, w1
0271c0a4: f30300aa mov      x19, x0
0271c0a8: 28010037 tbnz     w8, #0, #0x271c0cc
0271c0ac: a0580190 adrp     x0, #0x5230000
0271c0b0: 002043f9 ldr      x0, [x0, #0x640]
0271c0b4: 9354a297 bl       #0xfb1300
0271c0b8: a05501d0 adrp     x0, #0x51d2000
0271c0bc: 008c42f9 ldr      x0, [x0, #0x518]
0271c0c0: 9054a297 bl       #0xfb1300
0271c0c4: 28008052 mov      w8, #1
0271c0c8: a8121239 strb     w8, [x21, #0x484]
0271c0cc: e003142a mov      w0, w20
0271c0d0: e1031faa mov      x1, xzr
0271c0d4: 1aa23194 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
0271c0d8: 60000036 tbz      w0, #0, #0x271c0e4
0271c0dc: 68d24339 ldrb     w8, [x19, #0xf4]
0271c0e0: c80c0035 cbnz     w8, #0x271c278
0271c0e4: 1ffcff97 bl       #0x271b160 ; Royal.Scenes.Game.Mechanics.Items.CandyCaneItem.CandyCaneItemModel$$GetItemHelper
0271c0e8: 200f00b4 cbz      x0, #0x271c2cc
0271c0ec: 21008052 mov      w1, #1
0271c0f0: 02008012 mov      w2, #-1
0271c0f4: f50300aa mov      x21, x0
0271c0f8: 9ef2ff97 bl       #0x2718b70 ; Royal.Scenes.Game.Mechanics.Items.CandyCaneItem.CandyCaneItemHelper$$GetRemainingExplodeCount
0271c0fc: f703002a mov      w23, w0
0271c100: e00315aa mov      x0, x21
0271c104: c4f5ff97 bl       #0x2719814 ; Royal.Scenes.Game.Mechanics.Items.CandyCaneItem.CandyCaneItemHelper$$GetCenterIncomingExploderCount
0271c108: f803002a mov      w24, w0
0271c10c: e003142a mov      w0, w20
0271c110: e1031faa mov      x1, xzr
0271c114: 26a23194 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
0271c118: e0000036 tbz      w0, #0, #0x271c134
0271c11c: 602a40f9 ldr      x0, [x19, #0x50]
0271c120: 600d00b4 cbz      x0, #0x271c2cc
0271c124: 61c242f8 ldur     x1, [x19, #0x2c]
0271c128: e2031faa mov      x2, xzr
0271c12c: f9e00094 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
0271c130: 04000014 b        #0x271c140
0271c134: e00313aa mov      x0, x19
0271c138: e1031faa mov      x1, xzr
0271c13c: 569b3194 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0271c140: f60300aa mov      x22, x0
0271c144: e003142a mov      w0, w20
0271c148: e1031faa mov      x1, xzr
0271c14c: f902184b sub      w25, w23, w24
0271c150: fba13194 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
0271c154: 3f0b0071 cmp      w25, #2
0271c158: fa031f2a mov      w26, wzr
0271c15c: ab050054 b.lt     #0x271c210
0271c160: 80050037 tbnz     w0, #0, #0x271c210
0271c164: e00315aa mov      x0, x21
0271c168: 08f5ff97 bl       #0x2719588 ; Royal.Scenes.Game.Mechanics.Items.CandyCaneItem.CandyCaneItemHelper$$GetAllArmEnds
0271c16c: 000b00b4 cbz      x0, #0x271c2cc
0271c170: 081840b9 ldr      w8, [x0, #0x18]
0271c174: f70300aa mov      x23, x0
0271c178: 1f050071 cmp      w8, #1
0271c17c: 8b040054 b.lt     #0x271c20c
0271c180: bb5501d0 adrp     x27, #0x51d2000
0271c184: 7b8f42f9 ldr      x27, [x27, #0x518]
0271c188: f8031f2a mov      w24, wzr
0271c18c: fa031f2a mov      w26, wzr
0271c190: 620340f9 ldr      x2, [x27]
0271c194: e00317aa mov      x0, x23
0271c198: e103182a mov      w1, w24
0271c19c: 94c80a94 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
0271c1a0: 600900b4 cbz      x0, #0x271c2cc
0271c1a4: 080040f9 ldr      x8, [x0]
0271c1a8: 096542f9 ldr      x9, [x8, #0x4c8]
0271c1ac: 016942f9 ldr      x1, [x8, #0x4d0]
0271c1b0: 20013fd6 blr      x9
0271c1b4: 1f040071 cmp      w0, #1
0271c1b8: 01020054 b.ne     #0x271c1f8
0271c1bc: 620340f9 ldr      x2, [x27]
0271c1c0: e00317aa mov      x0, x23
0271c1c4: e103182a mov      w1, w24
0271c1c8: 89c80a94 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
0271c1cc: 000800b4 cbz      x0, #0x271c2cc
0271c1d0: e1031faa mov      x1, xzr
0271c1d4: 309b3194 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
0271c1d8: b60700b4 cbz      x22, #0x271c2cc
0271c1dc: 800700b4 cbz      x0, #0x271c2cc
0271c1e0: c20e40f9 ldr      x2, [x22, #0x18]
0271c1e4: e103142a mov      w1, w20
0271c1e8: e3031faa mov      x3, xzr
0271c1ec: 8bb70e94 bl       #0x2aca018 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$WillGuidedExploderHitCell
0271c1f0: 08000012 and      w8, w0, #1
0271c1f4: 5a03080b add      w26, w26, w8
0271c1f8: e81a40b9 ldr      w8, [x23, #0x18]
0271c1fc: 18070011 add      w24, w24, #1
0271c200: 1f03086b cmp      w24, w8
0271c204: 6bfcff54 b.lt     #0x271c190
0271c208: 02000014 b        #0x271c210
0271c20c: fa031f2a mov      w26, wzr
0271c210: 3f070071 cmp      w25, #1
0271c214: a0000054 b.eq     #0x271c228
0271c218: f6031f2a mov      w22, wzr
0271c21c: 0b010054 b.lt     #0x271c23c
0271c220: 3f031a6b cmp      w25, w26
0271c224: cc000054 b.gt     #0x271c23c
0271c228: 5f030071 cmp      w26, #0
0271c22c: 299f8952 mov      w9, #0x4cf9
0271c230: 48179f1a csinc    w8, w26, wzr, ne
0271c234: 4900a072 movk     w9, #2, lsl #16
0271c238: 360dc81a sdiv     w22, w9, w8
0271c23c: e003142a mov      w0, w20
0271c240: e1031faa mov      x1, xzr
0271c244: 48ba3194 bl       #0x338ab64 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsLineExploderStrategy
0271c248: c0010036 tbz      w0, #0, #0x271c280
0271c24c: e003142a mov      w0, w20
0271c250: e1031faa mov      x1, xzr
0271c254: 4cba3194 bl       #0x338ab84 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsVerticalLineExploder
0271c258: 68d24339 ldrb     w8, [x19, #0xf4]
0271c25c: 28010034 cbz      w8, #0x271c280
0271c260: e803202a mvn      w8, w0
0271c264: 01010012 and      w1, w8, #1
0271c268: 02008012 mov      w2, #-1
0271c26c: e00315aa mov      x0, x21
0271c270: 06efff97 bl       #0x2717e88 ; Royal.Scenes.Game.Mechanics.Items.CandyCaneItem.CandyCaneItemHelper$$ArmExistsInDirection
0271c274: 20020036 tbz      w0, #0, #0x271c2b8
0271c278: e0031f2a mov      w0, wzr
0271c27c: 09000014 b        #0x271c2a0
0271c280: 680240f9 ldr      x8, [x19]
0271c284: e00313aa mov      x0, x19
0271c288: 09bd41f9 ldr      x9, [x8, #0x378]
0271c28c: 01c141f9 ldr      x1, [x8, #0x380]
0271c290: 20013fd6 blr      x9
0271c294: e1031faa mov      x1, xzr
0271c298: bca13194 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
0271c29c: 0000160b add      w0, w0, w22
0271c2a0: f37b44a9 ldp      x19, x30, [sp, #0x40]
0271c2a4: f55343a9 ldp      x21, x20, [sp, #0x30]
0271c2a8: f75b42a9 ldp      x23, x22, [sp, #0x20]
0271c2ac: f96341a9 ldp      x25, x24, [sp, #0x10]
0271c2b0: fb6bc5a8 ldp      x27, x26, [sp], #0x50
0271c2b4: c0035fd6 ret      
0271c2b8: e00313aa mov      x0, x19
0271c2bc: e103142a mov      w1, w20
0271c2c0: e2031faa mov      x2, xzr
0271c2c4: aaa13194 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
0271c2c8: f5ffff17 b        #0x271c29c
0271c2cc: 5754a297 bl       #0xfb1428
