# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerHitSfx
# Linear span to next metadata entry; not a complete CFG.
03397cfc: fe0f1ff8 str      x30, [sp, #-0x10]!
03397d00: 081440f9 ldr      x8, [x0, #0x28]
03397d04: e80000b4 cbz      x8, #0x3397d20
03397d08: 091940b9 ldr      w9, [x8, #0x18]
03397d0c: 3f090071 cmp      w9, #2
03397d10: a9000054 b.ls     #0x3397d24
03397d14: 001940f9 ldr      x0, [x8, #0x30]
03397d18: fe0741f8 ldr      x30, [sp], #0x10
03397d1c: c0035fd6 ret      
03397d20: c2657097 bl       #0xfb1428
03397d24: c3657097 bl       #0xfb1430
