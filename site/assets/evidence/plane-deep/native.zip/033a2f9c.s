# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$GetNewPilot
# Linear span to next metadata entry; not a complete CFG.
033a2f9c: f40f1ef8 str      x20, [sp, #-0x20]!
033a2fa0: f37b01a9 stp      x19, x30, [sp, #0x10]
033a2fa4: 330f0190 adrp     x19, #0x5586000
033a2fa8: b4f200b0 adrp     x20, #0x51f7000
033a2fac: 682a6739 ldrb     w8, [x19, #0x9ca]
033a2fb0: 94fa44f9 ldr      x20, [x20, #0x9f0]
033a2fb4: c8000037 tbnz     w8, #0, #0x33a2fcc
033a2fb8: a0f200b0 adrp     x0, #0x51f7000
033a2fbc: 00f844f9 ldr      x0, [x0, #0x9f0]
033a2fc0: d0387097 bl       #0xfb1300
033a2fc4: 28008052 mov      w8, #1
033a2fc8: 682a2739 strb     w8, [x19, #0x9ca]
033a2fcc: 800240f9 ldr      x0, [x20]
033a2fd0: 12397097 bl       #0xfb1418
033a2fd4: 000100b4 cbz      x0, #0x33a2ff4
033a2fd8: e1031faa mov      x1, xzr
033a2fdc: f30300aa mov      x19, x0
033a2fe0: 8541bb97 bl       #0x22735f4 ; System.Object$$.ctor
033a2fe4: e00313aa mov      x0, x19
033a2fe8: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a2fec: f40742f8 ldr      x20, [sp], #0x20
033a2ff0: c0035fd6 ret      
033a2ff4: 0d397097 bl       #0xfb1428
