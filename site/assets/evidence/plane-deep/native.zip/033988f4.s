# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerRocketComboParticles$$Awake
# Linear span to next metadata entry; not a complete CFG.
033988f4: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033988f8: e1031faa mov      x1, xzr
033988fc: f30300aa mov      x19, x0
03398900: 5fb3ff97 bl       #0x338567c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemParticles$$Awake
03398904: 601a40f9 ldr      x0, [x19, #0x30]
03398908: e1031faa mov      x1, xzr
0339890c: f37bc1a8 ldp      x19, x30, [sp], #0x10
03398910: 7fb3ff17 b        #0x338570c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemParticles$$InitShadows
