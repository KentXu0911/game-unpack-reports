# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerTntStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a4750: 42000012 and      w2, w2, #1
033a4754: 63000012 and      w3, w3, #1
033a4758: 84000012 and      w4, w4, #1
033a475c: 5ffdff17 b        #0x33a3cd8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$.ctor
