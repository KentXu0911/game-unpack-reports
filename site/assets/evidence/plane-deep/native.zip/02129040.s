# Royal.Scenes.Game.Mechanics.Items.IceCrusherItem.IceCrusherItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02129040: f40f1ef8 str      x20, [sp, #-0x20]!
02129044: f37b01a9 stp      x19, x30, [sp, #0x10]
02129048: 080040f9 ldr      x8, [x0]
0212904c: f30300aa mov      x19, x0
02129050: 096542f9 ldr      x9, [x8, #0x4c8]
02129054: 016942f9 ldr      x1, [x8, #0x4d0]
02129058: 20013fd6 blr      x9
0212905c: 680240f9 ldr      x8, [x19]
02129060: 1f040071 cmp      w0, #1
02129064: e00313aa mov      x0, x19
02129068: 09bd41f9 ldr      x9, [x8, #0x378]
0212906c: 01c141f9 ldr      x1, [x8, #0x380]
02129070: a8608a52 mov      w8, #0x5305
02129074: 4800a072 movk     w8, #2, lsl #16
02129078: 14019f1a csel     w20, w8, wzr, eq
0212907c: 20013fd6 blr      x9
02129080: e1031faa mov      x1, xzr
02129084: 416e4994 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02129088: f37b41a9 ldp      x19, x30, [sp, #0x10]
0212908c: 0000140b add      w0, w0, w20
02129090: f40742f8 ldr      x20, [sp], #0x20
02129094: c0035fd6 ret      
