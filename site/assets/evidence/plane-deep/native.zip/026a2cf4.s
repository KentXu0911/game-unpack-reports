# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$FinishGuidedExplodeOperation
# Linear span to next metadata entry; not a complete CFG.
026a2cf4: c0035fd6 ret      
