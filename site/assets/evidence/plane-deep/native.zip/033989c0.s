# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_GoSpeedMultiplierConst
# Linear span to next metadata entry; not a complete CFG.
033989c0: 0090261e fmov     s0, #20.00000000
033989c4: c0035fd6 ret      
