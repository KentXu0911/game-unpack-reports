# Royal.Scenes.Game.Mechanics.Items.VendingMachineItem.VendingMachineItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03c1b760: f75bbda9 stp      x23, x22, [sp, #-0x30]!
03c1b764: f55301a9 stp      x21, x20, [sp, #0x10]
03c1b768: f37b02a9 stp      x19, x30, [sp, #0x20]
03c1b76c: 08404539 ldrb     w8, [x0, #0x150]
03c1b770: 48030034 cbz      w8, #0x3c1b7d8
03c1b774: f30300aa mov      x19, x0
03c1b778: f503012a mov      w21, w1
03c1b77c: e003012a mov      w0, w1
03c1b780: e1031faa mov      x1, xzr
03c1b784: 00bddd97 bl       #0x338ab84 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsVerticalLineExploder
03c1b788: a0000037 tbnz     w0, #0, #0x3c1b79c
03c1b78c: e003152a mov      w0, w21
03c1b790: e1031faa mov      x1, xzr
03c1b794: 86a4dd97 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03c1b798: 40020036 tbz      w0, #0, #0x3c1b7e0
03c1b79c: 680240f9 ldr      x8, [x19]
03c1b7a0: e00313aa mov      x0, x19
03c1b7a4: 09bd41f9 ldr      x9, [x8, #0x378]
03c1b7a8: 01c141f9 ldr      x1, [x8, #0x380]
03c1b7ac: 20013fd6 blr      x9
03c1b7b0: e1031faa mov      x1, xzr
03c1b7b4: 75a4dd97 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03c1b7b8: c9aa8a52 mov      w9, #0x5556
03c1b7bc: 08781f53 lsl      w8, w0, #1
03c1b7c0: a9aaaa72 movk     w9, #0x5555, lsl #16
03c1b7c4: 087d299b smull    x8, w8, w9
03c1b7c8: 09fd7fd3 lsr      x9, x8, #0x3f
03c1b7cc: 08fd60d3 lsr      x8, x8, #0x20
03c1b7d0: 1401090b add      w20, w8, w9
03c1b7d4: 0b000014 b        #0x3c1b800
03c1b7d8: f4031f2a mov      w20, wzr
03c1b7dc: 60000014 b        #0x3c1b95c
03c1b7e0: 680240f9 ldr      x8, [x19]
03c1b7e4: e00313aa mov      x0, x19
03c1b7e8: 09bd41f9 ldr      x9, [x8, #0x378]
03c1b7ec: 01c141f9 ldr      x1, [x8, #0x380]
03c1b7f0: 20013fd6 blr      x9
03c1b7f4: e1031faa mov      x1, xzr
03c1b7f8: 64a4dd97 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03c1b7fc: f403002a mov      w20, w0
03c1b800: e003152a mov      w0, w21
03c1b804: e1031faa mov      x1, xzr
03c1b808: 69a4dd97 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03c1b80c: e0000036 tbz      w0, #0, #0x3c1b828
03c1b810: 602a40f9 ldr      x0, [x19, #0x50]
03c1b814: e00a00b4 cbz      x0, #0x3c1b970
03c1b818: 61c242f8 ldur     x1, [x19, #0x2c]
03c1b81c: e2031faa mov      x2, xzr
03c1b820: 3ce3ac97 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
03c1b824: 04000014 b        #0x3c1b834
03c1b828: e00313aa mov      x0, x19
03c1b82c: e1031faa mov      x1, xzr
03c1b830: 999ddd97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
03c1b834: 680240f9 ldr      x8, [x19]
03c1b838: f70300aa mov      x23, x0
03c1b83c: e00313aa mov      x0, x19
03c1b840: 096542f9 ldr      x9, [x8, #0x4c8]
03c1b844: 016942f9 ldr      x1, [x8, #0x4d0]
03c1b848: 20013fd6 blr      x9
03c1b84c: 1f100071 cmp      w0, #4
03c1b850: 6c080054 b.gt     #0x3c1b95c
03c1b854: f603002a mov      w22, w0
03c1b858: e003152a mov      w0, w21
03c1b85c: e1031faa mov      x1, xzr
03c1b860: 37a4dd97 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03c1b864: 00020036 tbz      w0, #0, #0x3c1b8a4
03c1b868: df060071 cmp      w22, #1
03c1b86c: 41070054 b.ne     #0x3c1b954
03c1b870: 680240f9 ldr      x8, [x19]
03c1b874: e00313aa mov      x0, x19
03c1b878: 09bd41f9 ldr      x9, [x8, #0x378]
03c1b87c: 01c141f9 ldr      x1, [x8, #0x380]
03c1b880: 20013fd6 blr      x9
03c1b884: e1031faa mov      x1, xzr
03c1b888: 8ac0dd97 bl       #0x338bab0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$CellsFreedAfterExplode
03c1b88c: a8608a52 mov      w8, #0x5305
03c1b890: 49649352 mov      w9, #0x9b22
03c1b894: 4800a072 movk     w8, #2, lsl #16
03c1b898: a9ffbf72 movk     w9, #0xfffd, lsl #16
03c1b89c: 0824081b madd     w8, w0, w8, w9
03c1b8a0: 2e000014 b        #0x3c1b958
03c1b8a4: 770600b4 cbz      x23, #0x3c1b970
03c1b8a8: e20e40f9 ldr      x2, [x23, #0x18]
03c1b8ac: e00313aa mov      x0, x19
03c1b8b0: e103152a mov      w1, w21
03c1b8b4: e3031faa mov      x3, xzr
03c1b8b8: 26d8dd97 bl       #0x3391950 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetAmountOfHitsFromPropellerCombo
03c1b8bc: f703002a mov      w23, w0
03c1b8c0: e003152a mov      w0, w21
03c1b8c4: e1031faa mov      x1, xzr
03c1b8c8: 39a4dd97 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03c1b8cc: 1f000072 tst      w0, #1
03c1b8d0: 48008052 mov      w8, #2
03c1b8d4: 89008052 mov      w9, #4
03c1b8d8: 2811881a csel     w8, w9, w8, ne
03c1b8dc: ff02086b cmp      w23, w8
03c1b8e0: e8b2881a csel     w8, w23, w8, lt
03c1b8e4: ff060071 cmp      w23, #1
03c1b8e8: ab030054 b.lt     #0x3c1b95c
03c1b8ec: df02086b cmp      w22, w8
03c1b8f0: 6c030054 b.gt     #0x3c1b95c
03c1b8f4: 680240f9 ldr      x8, [x19]
03c1b8f8: e00313aa mov      x0, x19
03c1b8fc: 09bd41f9 ldr      x9, [x8, #0x378]
03c1b900: 01c141f9 ldr      x1, [x8, #0x380]
03c1b904: 20013fd6 blr      x9
03c1b908: e1031faa mov      x1, xzr
03c1b90c: 69c0dd97 bl       #0x338bab0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$CellsFreedAfterExplode
03c1b910: 680240f9 ldr      x8, [x19]
03c1b914: f403002a mov      w20, w0
03c1b918: e00313aa mov      x0, x19
03c1b91c: 096542f9 ldr      x9, [x8, #0x4c8]
03c1b920: 016942f9 ldr      x1, [x8, #0x4d0]
03c1b924: 20013fd6 blr      x9
03c1b928: 08229f52 mov      w8, #0xf910
03c1b92c: aa608a52 mov      w10, #0x5305
03c1b930: c800a072 movk     w8, #6, lsl #16
03c1b934: 8902004b sub      w9, w20, w0
03c1b938: 4a00a072 movk     w10, #2, lsl #16
03c1b93c: c87e081b mul      w8, w22, w8
03c1b940: 297d0a1b mul      w9, w9, w10
03c1b944: 080dd71a sdiv     w8, w8, w23
03c1b948: 290dd71a sdiv     w9, w9, w23
03c1b94c: 3401080b add      w20, w9, w8
03c1b950: 03000014 b        #0x3c1b95c
03c1b954: e8031f2a mov      w8, wzr
03c1b958: 1401140b add      w20, w8, w20
03c1b95c: e003142a mov      w0, w20
03c1b960: f37b42a9 ldp      x19, x30, [sp, #0x20]
03c1b964: f55341a9 ldp      x21, x20, [sp, #0x10]
03c1b968: f75bc3a8 ldp      x23, x22, [sp], #0x30
03c1b96c: c0035fd6 ret      
03c1b970: ae564e97 bl       #0xfb1428
