# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$SwapWith
# Linear span to next metadata entry; not a complete CFG.
026a41e4: c0035fd6 ret      
