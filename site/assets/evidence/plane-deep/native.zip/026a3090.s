# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$GetNewPilot
# Linear span to next metadata entry; not a complete CFG.
026a3090: f40f1ef8 str      x20, [sp, #-0x20]!
026a3094: f37b01a9 stp      x19, x30, [sp, #0x10]
026a3098: f47601b0 adrp     x20, #0x5580000
026a309c: 88f64039 ldrb     w8, [x20, #0x3d]
026a30a0: f30300aa mov      x19, x0
026a30a4: c8000037 tbnz     w8, #0, #0x26a30bc
026a30a8: 205c01b0 adrp     x0, #0x5228000
026a30ac: 000444f9 ldr      x0, [x0, #0x808]
026a30b0: 9438a497 bl       #0xfb1300
026a30b4: 28008052 mov      w8, #1
026a30b8: 88f60039 strb     w8, [x20, #0x3d]
026a30bc: 737240f9 ldr      x19, [x19, #0xe0]
026a30c0: 930300b4 cbz      x19, #0x26a3130
026a30c4: 2a5c01b0 adrp     x10, #0x5228000
026a30c8: 680240f9 ldr      x8, [x19]
026a30cc: 4a0544f9 ldr      x10, [x10, #0x808]
026a30d0: 09554279 ldrh     w9, [x8, #0x12a]
026a30d4: 410140f9 ldr      x1, [x10]
026a30d8: 290100b4 cbz      x9, #0x26a30fc
026a30dc: 0a5940f9 ldr      x10, [x8, #0xb0]
026a30e0: 4a210091 add      x10, x10, #8
026a30e4: 4b815ff8 ldur     x11, [x10, #-8]
026a30e8: 7f0101eb cmp      x11, x1
026a30ec: 00010054 b.eq     #0x26a310c
026a30f0: 290500f1 subs     x9, x9, #1
026a30f4: 4a410091 add      x10, x10, #0x10
026a30f8: 61ffff54 b.ne     #0x26a30e4
026a30fc: 62008052 mov      w2, #3
026a3100: e00313aa mov      x0, x19
026a3104: 7478a397 bl       #0xf812d4
026a3108: 05000014 b        #0x26a311c
026a310c: 490140b9 ldr      w9, [x10]
026a3110: 290d0011 add      w9, w9, #3
026a3114: 08d1298b add      x8, x8, w9, sxtw #4
026a3118: 00e10491 add      x0, x8, #0x138
026a311c: 020440a9 ldp      x2, x1, [x0]
026a3120: e00313aa mov      x0, x19
026a3124: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a3128: f40742f8 ldr      x20, [sp], #0x20
026a312c: 40001fd6 br       x2
026a3130: be38a497 bl       #0xfb1428
