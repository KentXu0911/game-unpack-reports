# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$set_TargetExplodeData
# Linear span to next metadata entry; not a complete CFG.
026a1b30: 291840f9 ldr      x9, [x1, #0x30]
026a1b34: 228040ad ldp      q2, q0, [x1, #0x10]
026a1b38: 2100c03d ldr      q1, [x1]
026a1b3c: 08300491 add      x8, x0, #0x10c
026a1b40: 091900f9 str      x9, [x8, #0x30]
026a1b44: 028100ad stp      q2, q0, [x8, #0x10]
026a1b48: 0101803d str      q1, [x8]
026a1b4c: c0035fd6 ret      
