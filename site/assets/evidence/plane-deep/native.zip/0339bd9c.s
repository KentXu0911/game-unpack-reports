# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangePosition
# Linear span to next metadata entry; not a complete CFG.
0339bd9c: ee0f1bfc str      d14, [sp, #-0x50]!
0339bda0: ed33016d stp      d13, d12, [sp, #0x10]
0339bda4: eb2b026d stp      d11, d10, [sp, #0x20]
0339bda8: e923036d stp      d9, d8, [sp, #0x30]
0339bdac: f37b04a9 stp      x19, x30, [sp, #0x40]
0339bdb0: e1031f2a mov      w1, wzr
0339bdb4: c81ca64e mov      v8.16b, v6.16b
0339bdb8: a91ca54e mov      v9.16b, v5.16b
0339bdbc: 8a1ca44e mov      v10.16b, v4.16b
0339bdc0: 6b1ca34e mov      v11.16b, v3.16b
0339bdc4: 4c1ca24e mov      v12.16b, v2.16b
0339bdc8: 2d1ca14e mov      v13.16b, v1.16b
0339bdcc: 0e1ca04e mov      v14.16b, v0.16b
0339bdd0: f30300aa mov      x19, x0
0339bdd4: 0f000094 bl       #0x339be10 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeRootPositions
0339bdd8: e00313aa mov      x0, x19
0339bddc: a11dad4e mov      v1.16b, v13.16b
0339bde0: 821dac4e mov      v2.16b, v12.16b
0339bde4: 631dab4e mov      v3.16b, v11.16b
0339bde8: 441daa4e mov      v4.16b, v10.16b
0339bdec: 251da94e mov      v5.16b, v9.16b
0339bdf0: 061da84e mov      v6.16b, v8.16b
0339bdf4: f37b44a9 ldp      x19, x30, [sp, #0x40]
0339bdf8: e923436d ldp      d9, d8, [sp, #0x30]
0339bdfc: eb2b426d ldp      d11, d10, [sp, #0x20]
0339be00: ed33416d ldp      d13, d12, [sp, #0x10]
0339be04: c01dae4e mov      v0.16b, v14.16b
0339be08: ee0745fc ldr      d14, [sp], #0x50
0339be0c: 4ef8ff17 b        #0x3399f44 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangePosition
