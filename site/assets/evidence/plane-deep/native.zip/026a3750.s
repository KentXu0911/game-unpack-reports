# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryExplodeItem
# Linear span to next metadata entry; not a complete CFG.
026a3750: ffc302d1 sub      sp, sp, #0xb0
026a3754: f75b08a9 stp      x23, x22, [sp, #0x80]
026a3758: f55309a9 stp      x21, x20, [sp, #0x90]
026a375c: f37b0aa9 stp      x19, x30, [sp, #0xa0]
026a3760: f47601b0 adrp     x20, #0x5580000
026a3764: 88fe4039 ldrb     w8, [x20, #0x3f]
026a3768: f60301aa mov      x22, x1
026a376c: f30300aa mov      x19, x0
026a3770: c8000037 tbnz     w8, #0, #0x26a3788
026a3774: 205c01b0 adrp     x0, #0x5228000
026a3778: 000444f9 ldr      x0, [x0, #0x808]
026a377c: e136a497 bl       #0xfb1300
026a3780: 28008052 mov      w8, #1
026a3784: 88fe0039 strb     w8, [x20, #0x3f]
026a3788: 00e4006f movi     v0.2d, #0000000000000000
026a378c: ff3b00f9 str      xzr, [sp, #0x70]
026a3790: e08302ad stp      q0, q0, [sp, #0x50]
026a3794: e013803d str      q0, [sp, #0x40]
026a3798: 601e40f9 ldr      x0, [x19, #0x38]
026a379c: c00e00b4 cbz      x0, #0x26a3974
026a37a0: e1031faa mov      x1, xzr
026a37a4: 3aa23394 bl       #0x338c08c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemMediator$$get_CurrentCell
026a37a8: 757240f9 ldr      x21, [x19, #0xe0]
026a37ac: 550e00b4 cbz      x21, #0x26a3974
026a37b0: 375c01b0 adrp     x23, #0x5228000
026a37b4: a80240f9 ldr      x8, [x21]
026a37b8: f70644f9 ldr      x23, [x23, #0x808]
026a37bc: d60a40b9 ldr      w22, [x22, #8]
026a37c0: f40300aa mov      x20, x0
026a37c4: 09554279 ldrh     w9, [x8, #0x12a]
026a37c8: e10240f9 ldr      x1, [x23]
026a37cc: 290100b4 cbz      x9, #0x26a37f0
026a37d0: 0a5940f9 ldr      x10, [x8, #0xb0]
026a37d4: 4a210091 add      x10, x10, #8
026a37d8: 4b815ff8 ldur     x11, [x10, #-8]
026a37dc: 7f0101eb cmp      x11, x1
026a37e0: 00010054 b.eq     #0x26a3800
026a37e4: 290500f1 subs     x9, x9, #1
026a37e8: 4a410091 add      x10, x10, #0x10
026a37ec: 61ffff54 b.ne     #0x26a37d8
026a37f0: e00315aa mov      x0, x21
026a37f4: e2031f2a mov      w2, wzr
026a37f8: b776a397 bl       #0xf812d4
026a37fc: 04000014 b        #0x26a380c
026a3800: 490180b9 ldrsw    x9, [x10]
026a3804: 0811098b add      x8, x8, x9, lsl #4
026a3808: 00e10491 add      x0, x8, #0x138
026a380c: 081040a9 ldp      x8, x4, [x0]
026a3810: e00315aa mov      x0, x21
026a3814: e10314aa mov      x1, x20
026a3818: e203162a mov      w2, w22
026a381c: e30313aa mov      x3, x19
026a3820: 00013fd6 blr      x8
026a3824: 767240f9 ldr      x22, [x19, #0xe0]
026a3828: 760a00b4 cbz      x22, #0x26a3974
026a382c: c80240f9 ldr      x8, [x22]
026a3830: e10240f9 ldr      x1, [x23]
026a3834: f503002a mov      w21, w0
026a3838: 09554279 ldrh     w9, [x8, #0x12a]
026a383c: 290100b4 cbz      x9, #0x26a3860
026a3840: 0a5940f9 ldr      x10, [x8, #0xb0]
026a3844: 4a210091 add      x10, x10, #8
026a3848: 4b815ff8 ldur     x11, [x10, #-8]
026a384c: 7f0101eb cmp      x11, x1
026a3850: 00010054 b.eq     #0x26a3870
026a3854: 290500f1 subs     x9, x9, #1
026a3858: 4a410091 add      x10, x10, #0x10
026a385c: 61ffff54 b.ne     #0x26a3848
026a3860: 22008052 mov      w2, #1
026a3864: e00316aa mov      x0, x22
026a3868: 9b76a397 bl       #0xf812d4
026a386c: 05000014 b        #0x26a3880
026a3870: 490140b9 ldr      w9, [x10]
026a3874: 29050011 add      w9, w9, #1
026a3878: 08d1298b add      x8, x8, w9, sxtw #4
026a387c: 00e10491 add      x0, x8, #0x138
026a3880: 090840a9 ldp      x9, x2, [x0]
026a3884: e8230091 add      x8, sp, #8
026a3888: e00316aa mov      x0, x22
026a388c: e10314aa mov      x1, x20
026a3890: 20013fd6 blr      x9
026a3894: e81f40f9 ldr      x8, [sp, #0x38]
026a3898: e083c23c ldur     q0, [sp, #0x28]
026a389c: e183c13c ldur     q1, [sp, #0x18]
026a38a0: e283c03c ldur     q2, [sp, #8]
026a38a4: 69320491 add      x9, x19, #0x10c
026a38a8: e83b00f9 str      x8, [sp, #0x70]
026a38ac: e18302ad stp      q1, q0, [sp, #0x50]
026a38b0: e213803d str      q2, [sp, #0x40]
026a38b4: 281900f9 str      x8, [x9, #0x30]
026a38b8: 218100ad stp      q1, q0, [x9, #0x10]
026a38bc: 2201803d str      q2, [x9]
026a38c0: 947601f0 adrp     x20, #0x5576000
026a38c4: 88ae7c39 ldrb     w8, [x20, #0xf2b]
026a38c8: c8000035 cbnz     w8, #0x26a38e0
026a38cc: 205b01b0 adrp     x0, #0x5208000
026a38d0: 00c041f9 ldr      x0, [x0, #0x380]
026a38d4: 8b36a497 bl       #0xfb1300
026a38d8: 28008052 mov      w8, #1
026a38dc: 88ae3c39 strb     w8, [x20, #0xf2b]
026a38e0: 285b01b0 adrp     x8, #0x5208000
026a38e4: 08c141f9 ldr      x8, [x8, #0x380]
026a38e8: 080140f9 ldr      x8, [x8]
026a38ec: 085d40f9 ldr      x8, [x8, #0xb8]
026a38f0: 080140f9 ldr      x8, [x8]
026a38f4: 080400b4 cbz      x8, #0x26a3974
026a38f8: 081d40f9 ldr      x8, [x8, #0x38]
026a38fc: c80300b4 cbz      x8, #0x26a3974
026a3900: 000d40f9 ldr      x0, [x8, #0x18]
026a3904: 800300b4 cbz      x0, #0x26a3974
026a3908: e1031faa mov      x1, xzr
026a390c: 6beff697 bl       #0x245f6b8 ; Royal.Player.Context.Data.Session.UserActiveLevelData$$UsefulMoveMade
026a3910: e00313aa mov      x0, x19
026a3914: 19000094 bl       #0x26a3978 ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryRegisterForTargetChange
026a3918: 680240f9 ldr      x8, [x19]
026a391c: a1020012 and      w1, w21, #1
026a3920: e00313aa mov      x0, x19
026a3924: 09ed45f9 ldr      x9, [x8, #0xbd8]
026a3928: 02f145f9 ldr      x2, [x8, #0xbe0]
026a392c: 20013fd6 blr      x9
026a3930: 601e40f9 ldr      x0, [x19, #0x38]
026a3934: 000200b4 cbz      x0, #0x26a3974
026a3938: e1031faa mov      x1, xzr
026a393c: d4a13394 bl       #0x338c08c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemMediator$$get_CurrentCell
026a3940: 000100b4 cbz      x0, #0x26a3960
026a3944: 680240f9 ldr      x8, [x19]
026a3948: e00313aa mov      x0, x19
026a394c: 099542f9 ldr      x9, [x8, #0x528]
026a3950: 019942f9 ldr      x1, [x8, #0x530]
026a3954: 28be0090 adrp     x8, #0x3e67000
026a3958: 00ad44bd ldr      s0, [x8, #0x4ac]
026a395c: 20013fd6 blr      x9
026a3960: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
026a3964: f55349a9 ldp      x21, x20, [sp, #0x90]
026a3968: f75b48a9 ldp      x23, x22, [sp, #0x80]
026a396c: ffc30291 add      sp, sp, #0xb0
026a3970: c0035fd6 ret      
026a3974: ad36a497 bl       #0xfb1428
