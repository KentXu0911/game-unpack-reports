# Royal.Scenes.Game.Mechanics.Items.LightBulbItem.LightBulbItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01c23750: f40f1ef8 str      x20, [sp, #-0x20]!
01c23754: f37b01a9 stp      x19, x30, [sp, #0x10]
01c23758: f303012a mov      w19, w1
01c2375c: f40300aa mov      x20, x0
01c23760: e003012a mov      w0, w1
01c23764: e1031faa mov      x1, xzr
01c23768: 91845d94 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
01c2376c: c0000036 tbz      w0, #0, #0x1c23784
01c23770: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c23774: 00918f52 mov      w0, #0x7c88
01c23778: 6000a072 movk     w0, #3, lsl #16
01c2377c: f40742f8 ldr      x20, [sp], #0x20
01c23780: c0035fd6 ret      
01c23784: e103132a mov      w1, w19
01c23788: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c2378c: e00314aa mov      x0, x20
01c23790: e2031faa mov      x2, xzr
01c23794: f40742f8 ldr      x20, [sp], #0x20
01c23798: 3eb95d14 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
