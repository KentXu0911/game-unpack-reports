# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$StartFlying
# Linear span to next metadata entry; not a complete CFG.
0339ccd0: ed33ba6d stp      d13, d12, [sp, #-0x60]!
0339ccd4: eb2b016d stp      d11, d10, [sp, #0x10]
0339ccd8: e923026d stp      d9, d8, [sp, #0x20]
0339ccdc: f61b00f9 str      x22, [sp, #0x30]
0339cce0: f55304a9 stp      x21, x20, [sp, #0x40]
0339cce4: f37b05a9 stp      x19, x30, [sp, #0x50]
0339cce8: 560f01d0 adrp     x22, #0x5586000
0339ccec: c8ca6639 ldrb     w8, [x22, #0x9b2]
0339ccf0: f40302aa mov      x20, x2
0339ccf4: f50301aa mov      x21, x1
0339ccf8: f30300aa mov      x19, x0
0339ccfc: c8000037 tbnz     w8, #0, #0x339cd14
0339cd00: 80f400f0 adrp     x0, #0x522f000
0339cd04: 000445f9 ldr      x0, [x0, #0xa08]
0339cd08: 7e517097 bl       #0xfb1300
0339cd0c: 28008052 mov      w8, #1
0339cd10: c8ca2639 strb     w8, [x22, #0x9b2]
0339cd14: e00313aa mov      x0, x19
0339cd18: 150c05f8 str      x21, [x0, #0x50]!
0339cd1c: e10315aa mov      x1, x21
0339cd20: 63517097 bl       #0xfb12ac
0339cd24: 150e00b4 cbz      x21, #0x339cee4
0339cd28: e00315aa mov      x0, x21
0339cd2c: e1031faa mov      x1, xzr
0339cd30: 1e982594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339cd34: f50313aa mov      x21, x19
0339cd38: a08e05f8 str      x0, [x21, #0x58]!
0339cd3c: e10300aa mov      x1, x0
0339cd40: e00315aa mov      x0, x21
0339cd44: 5a517097 bl       #0xfb12ac
0339cd48: f60313aa mov      x22, x19
0339cd4c: d40e06f8 str      x20, [x22, #0x60]!
0339cd50: c81a40f9 ldr      x8, [x22, #0x30]
0339cd54: c93a40b9 ldr      w9, [x22, #0x38]
0339cd58: e00316aa mov      x0, x22
0339cd5c: e10314aa mov      x1, x20
0339cd60: c82a00f9 str      x8, [x22, #0x50]
0339cd64: c95a00b9 str      w9, [x22, #0x58]
0339cd68: 51517097 bl       #0xfb12ac
0339cd6c: 48008052 mov      w8, #2
0339cd70: c80a00b9 str      w8, [x22, #8]
0339cd74: df1a00b9 str      wzr, [x22, #0x18]
0339cd78: 740b00b4 cbz      x20, #0x339cee4
0339cd7c: 8af400f0 adrp     x10, #0x522f000
0339cd80: 880240f9 ldr      x8, [x20]
0339cd84: 4a0545f9 ldr      x10, [x10, #0xa08]
0339cd88: 09554279 ldrh     w9, [x8, #0x12a]
0339cd8c: 410140f9 ldr      x1, [x10]
0339cd90: 290100b4 cbz      x9, #0x339cdb4
0339cd94: 0a5940f9 ldr      x10, [x8, #0xb0]
0339cd98: 4a210091 add      x10, x10, #8
0339cd9c: 4b815ff8 ldur     x11, [x10, #-8]
0339cda0: 7f0101eb cmp      x11, x1
0339cda4: 00010054 b.eq     #0x339cdc4
0339cda8: 290500f1 subs     x9, x9, #1
0339cdac: 4a410091 add      x10, x10, #0x10
0339cdb0: 61ffff54 b.ne     #0x339cd9c
0339cdb4: 22008052 mov      w2, #1
0339cdb8: e00314aa mov      x0, x20
0339cdbc: 46916f97 bl       #0xf812d4
0339cdc0: 05000014 b        #0x339cdd4
0339cdc4: 490140b9 ldr      w9, [x10]
0339cdc8: 29050011 add      w9, w9, #1
0339cdcc: 08d1298b add      x8, x8, w9, sxtw #4
0339cdd0: 00e10491 add      x0, x8, #0x138
0339cdd4: 080440a9 ldp      x8, x1, [x0]
0339cdd8: e00314aa mov      x0, x20
0339cddc: 00013fd6 blr      x8
0339cde0: a00240f9 ldr      x0, [x21]
0339cde4: 000800b4 cbz      x0, #0x339cee4
0339cde8: e1031faa mov      x1, xzr
0339cdec: 081ca04e mov      v8.16b, v0.16b
0339cdf0: 291ca14e mov      v9.16b, v1.16b
0339cdf4: 4a1ca24e mov      v10.16b, v2.16b
0339cdf8: bfb32594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339cdfc: d40e01f0 adrp     x20, #0x5577000
0339ce00: 88fa7f39 ldrb     w8, [x20, #0xffe]
0339ce04: 0b1ca04e mov      v11.16b, v0.16b
0339ce08: 2c1ca14e mov      v12.16b, v1.16b
0339ce0c: 4d1ca24e mov      v13.16b, v2.16b
0339ce10: c8000035 cbnz     w8, #0x339ce28
0339ce14: 20f30090 adrp     x0, #0x5200000
0339ce18: 008c46f9 ldr      x0, [x0, #0xd18]
0339ce1c: 39517097 bl       #0xfb1300
0339ce20: 28008052 mov      w8, #1
0339ce24: 88fa3f39 strb     w8, [x20, #0xffe]
0339ce28: 28f30090 adrp     x8, #0x5200000
0339ce2c: 088d46f9 ldr      x8, [x8, #0xd18]
0339ce30: 0b392b1e fsub     s11, s8, s11
0339ce34: 29392c1e fsub     s9, s9, s12
0339ce38: 48392d1e fsub     s8, s10, s13
0339ce3c: 000140f9 ldr      x0, [x8]
0339ce40: 08e040b9 ldr      w8, [x0, #0xe0]
0339ce44: 48000035 cbnz     w8, #0x339ce4c
0339ce48: 6f517097 bl       #0xfb1404
0339ce4c: 60092b1e fmul     s0, s11, s11
0339ce50: 2109291e fmul     s1, s9, s9
0339ce54: a85600f0 adrp     x8, #0x3e73000
0339ce58: 0028211e fadd     s0, s0, s1
0339ce5c: 01894bbd ldr      s1, [x8, #0xb88]
0339ce60: 0209281e fmul     s2, s8, s8
0339ce64: 4028201e fadd     s0, s2, s0
0339ce68: 02c0211e fsqrt    s2, s0
0339ce6c: 4020211e fcmp     s2, s1
0339ce70: ad000054 b.le     #0x339ce84
0339ce74: 6019221e fdiv     s0, s11, s2
0339ce78: 2119221e fdiv     s1, s9, s2
0339ce7c: 0219221e fdiv     s2, s8, s2
0339ce80: 0f000014 b        #0x339cebc
0339ce84: d40e01d0 adrp     x20, #0x5576000
0339ce88: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339ce8c: c8000035 cbnz     w8, #0x339cea4
0339ce90: 60f400f0 adrp     x0, #0x522b000
0339ce94: 00ac43f9 ldr      x0, [x0, #0x758]
0339ce98: 1a517097 bl       #0xfb1300
0339ce9c: 28008052 mov      w8, #1
0339cea0: 88b23c39 strb     w8, [x20, #0xf2c]
0339cea4: 68f400f0 adrp     x8, #0x522b000
0339cea8: 08ad43f9 ldr      x8, [x8, #0x758]
0339ceac: 080140f9 ldr      x8, [x8]
0339ceb0: 085d40f9 ldr      x8, [x8, #0xb8]
0339ceb4: 0005402d ldp      s0, s1, [x8]
0339ceb8: 020940bd ldr      s2, [x8, #8]
0339cebc: e00313aa mov      x0, x19
0339cec0: 0c000094 bl       #0x339cef0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$InitializeCurveVariables
0339cec4: e00313aa mov      x0, x19
0339cec8: f37b45a9 ldp      x19, x30, [sp, #0x50]
0339cecc: f55344a9 ldp      x21, x20, [sp, #0x40]
0339ced0: f61b40f9 ldr      x22, [sp, #0x30]
0339ced4: e923426d ldp      d9, d8, [sp, #0x20]
0339ced8: eb2b416d ldp      d11, d10, [sp, #0x10]
0339cedc: ed33c66c ldp      d13, d12, [sp], #0x60
0339cee0: 34000014 b        #0x339cfb0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$Move
0339cee4: 51517097 bl       #0xfb1428
