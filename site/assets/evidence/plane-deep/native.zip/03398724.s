# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$OnRecycle
# Linear span to next metadata entry; not a complete CFG.
03398724: f40f1ef8 str      x20, [sp, #-0x20]!
03398728: f37b01a9 stp      x19, x30, [sp, #0x10]
0339872c: e1031faa mov      x1, xzr
03398730: f30300aa mov      x19, x0
03398734: 34c30b94 bl       #0x3689404 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$OnRecycle
03398738: f40e01d0 adrp     x20, #0x5576000
0339873c: 88c67c39 ldrb     w8, [x20, #0xf31]
03398740: 736240f9 ldr      x19, [x19, #0xc0]
03398744: c8000035 cbnz     w8, #0x339875c
03398748: 20f40090 adrp     x0, #0x521c000
0339874c: 00e841f9 ldr      x0, [x0, #0x3d0]
03398750: ec627097 bl       #0xfb1300
03398754: 28008052 mov      w8, #1
03398758: 88c63c39 strb     w8, [x20, #0xf31]
0339875c: 930100b4 cbz      x19, #0x339878c
03398760: 28f40090 adrp     x8, #0x521c000
03398764: 08e941f9 ldr      x8, [x8, #0x3d0]
03398768: e00313aa mov      x0, x19
0339876c: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398770: e1031faa mov      x1, xzr
03398774: 080140f9 ldr      x8, [x8]
03398778: 085d40f9 ldr      x8, [x8, #0xb8]
0339877c: 0005402d ldp      s0, s1, [x8]
03398780: 020d412d ldp      s2, s3, [x8, #8]
03398784: f40742f8 ldr      x20, [sp], #0x20
03398788: 68c62514 b        #0x3d0a128 ; UnityEngine.Transform$$set_localRotation
0339878c: 27637097 bl       #0xfb1428
