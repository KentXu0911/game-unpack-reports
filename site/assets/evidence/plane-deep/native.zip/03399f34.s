# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$IsPropRocketCombo
# Linear span to next metadata entry; not a complete CFG.
03399f34: e0031f2a mov      w0, wzr
03399f38: c0035fd6 ret      
