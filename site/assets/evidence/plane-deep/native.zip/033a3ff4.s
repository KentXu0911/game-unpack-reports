# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy.<ExplodeWithDelay>d__4$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a3ff4: f40f1ef8 str      x20, [sp, #-0x20]!
033a3ff8: f37b01a9 stp      x19, x30, [sp, #0x10]
033a3ffc: f303012a mov      w19, w1
033a4000: e1031faa mov      x1, xzr
033a4004: f40300aa mov      x20, x0
033a4008: 7b3dbb97 bl       #0x22735f4 ; System.Object$$.ctor
033a400c: 931200b9 str      w19, [x20, #0x10]
033a4010: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a4014: f40742f8 ldr      x20, [sp], #0x20
033a4018: c0035fd6 ret      
