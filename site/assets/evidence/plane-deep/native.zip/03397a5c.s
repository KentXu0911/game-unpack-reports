# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetViewPrefab
# Linear span to next metadata entry; not a complete CFG.
03397a5c: f40f1ef8 str      x20, [sp, #-0x20]!
03397a60: f37b01a9 stp      x19, x30, [sp, #0x10]
03397a64: 740f01f0 adrp     x20, #0x5586000
03397a68: 88366639 ldrb     w8, [x20, #0x98d]
03397a6c: f30300aa mov      x19, x0
03397a70: c8000037 tbnz     w8, #0, #0x3397a88
03397a74: e0f100b0 adrp     x0, #0x51d4000
03397a78: 00d841f9 ldr      x0, [x0, #0x3b0]
03397a7c: 21667097 bl       #0xfb1300
03397a80: 28008052 mov      w8, #1
03397a84: 88362639 strb     w8, [x20, #0x98d]
03397a88: 680e40f9 ldr      x8, [x19, #0x18]
03397a8c: c80200b4 cbz      x8, #0x3397ae4
03397a90: 091940b9 ldr      w9, [x8, #0x18]
03397a94: a9020034 cbz      w9, #0x3397ae8
03397a98: 001140f9 ldr      x0, [x8, #0x20]
03397a9c: c00100b4 cbz      x0, #0x3397ad4
03397aa0: e9f100b0 adrp     x9, #0x51d4000
03397aa4: 29d941f9 ldr      x9, [x9, #0x3b0]
03397aa8: 080040f9 ldr      x8, [x0]
03397aac: 210140f9 ldr      x1, [x9]
03397ab0: 0ab14439 ldrb     w10, [x8, #0x12c]
03397ab4: 29b04439 ldrb     w9, [x1, #0x12c]
03397ab8: 5f01096b cmp      w10, w9
03397abc: 23010054 b.lo     #0x3397ae0
03397ac0: 086540f9 ldr      x8, [x8, #0xc8]
03397ac4: 080d098b add      x8, x8, x9, lsl #3
03397ac8: 08815ff8 ldur     x8, [x8, #-8]
03397acc: 1f0101eb cmp      x8, x1
03397ad0: 81000054 b.ne     #0x3397ae0
03397ad4: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397ad8: f40742f8 ldr      x20, [sp], #0x20
03397adc: c0035fd6 ret      
03397ae0: 38677097 bl       #0xfb17c0
03397ae4: 51667097 bl       #0xfb1428
03397ae8: 52667097 bl       #0xfb1430
