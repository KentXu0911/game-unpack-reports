# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetTargetExplodePrefabs
# Linear span to next metadata entry; not a complete CFG.
03397b80: f40f1ef8 str      x20, [sp, #-0x20]!
03397b84: f37b01a9 stp      x19, x30, [sp, #0x10]
03397b88: 740f01f0 adrp     x20, #0x5586000
03397b8c: 883e6639 ldrb     w8, [x20, #0x98f]
03397b90: f30300aa mov      x19, x0
03397b94: c8000037 tbnz     w8, #0, #0x3397bac
03397b98: 80f200d0 adrp     x0, #0x51e9000
03397b9c: 00dc47f9 ldr      x0, [x0, #0xfb8]
03397ba0: d8657097 bl       #0xfb1300
03397ba4: 28008052 mov      w8, #1
03397ba8: 883e2639 strb     w8, [x20, #0x98f]
03397bac: 680e40f9 ldr      x8, [x19, #0x18]
03397bb0: e80200b4 cbz      x8, #0x3397c0c
03397bb4: 091940b9 ldr      w9, [x8, #0x18]
03397bb8: 3f090071 cmp      w9, #2
03397bbc: a9020054 b.ls     #0x3397c10
03397bc0: 001940f9 ldr      x0, [x8, #0x30]
03397bc4: c00100b4 cbz      x0, #0x3397bfc
03397bc8: 89f200d0 adrp     x9, #0x51e9000
03397bcc: 29dd47f9 ldr      x9, [x9, #0xfb8]
03397bd0: 080040f9 ldr      x8, [x0]
03397bd4: 210140f9 ldr      x1, [x9]
03397bd8: 0ab14439 ldrb     w10, [x8, #0x12c]
03397bdc: 29b04439 ldrb     w9, [x1, #0x12c]
03397be0: 5f01096b cmp      w10, w9
03397be4: 23010054 b.lo     #0x3397c08
03397be8: 086540f9 ldr      x8, [x8, #0xc8]
03397bec: 080d098b add      x8, x8, x9, lsl #3
03397bf0: 08815ff8 ldur     x8, [x8, #-8]
03397bf4: 1f0101eb cmp      x8, x1
03397bf8: 81000054 b.ne     #0x3397c08
03397bfc: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397c00: f40742f8 ldr      x20, [sp], #0x20
03397c04: c0035fd6 ret      
03397c08: ee667097 bl       #0xfb17c0
03397c0c: 07667097 bl       #0xfb1428
03397c10: 08667097 bl       #0xfb1430
