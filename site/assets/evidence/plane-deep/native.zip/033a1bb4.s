# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TryResetForNextTarget
# Linear span to next metadata entry; not a complete CFG.
033a1bb4: ff8302d1 sub      sp, sp, #0xa0
033a1bb8: ef3b026d stp      d15, d14, [sp, #0x20]
033a1bbc: ed33036d stp      d13, d12, [sp, #0x30]
033a1bc0: eb2b046d stp      d11, d10, [sp, #0x40]
033a1bc4: e923056d stp      d9, d8, [sp, #0x50]
033a1bc8: f96306a9 stp      x25, x24, [sp, #0x60]
033a1bcc: f75b07a9 stp      x23, x22, [sp, #0x70]
033a1bd0: f55308a9 stp      x21, x20, [sp, #0x80]
033a1bd4: f37b09a9 stp      x19, x30, [sp, #0x90]
033a1bd8: 08004239 ldrb     w8, [x0, #0x80]
033a1bdc: 68010034 cbz      w8, #0x33a1c08
033a1be0: f37b49a9 ldp      x19, x30, [sp, #0x90]
033a1be4: f55348a9 ldp      x21, x20, [sp, #0x80]
033a1be8: f75b47a9 ldp      x23, x22, [sp, #0x70]
033a1bec: f96346a9 ldp      x25, x24, [sp, #0x60]
033a1bf0: e923456d ldp      d9, d8, [sp, #0x50]
033a1bf4: eb2b446d ldp      d11, d10, [sp, #0x40]
033a1bf8: ed33436d ldp      d13, d12, [sp, #0x30]
033a1bfc: ef3b426d ldp      d15, d14, [sp, #0x20]
033a1c00: ff830291 add      sp, sp, #0xa0
033a1c04: c0035fd6 ret      
033a1c08: 091ca04e mov      v9.16b, v0.16b
033a1c0c: 006c40bd ldr      s0, [x0, #0x6c]
033a1c10: 281ca14e mov      v8.16b, v1.16b
033a1c14: 0190241e fmov     s1, #10.00000000
033a1c18: 34008052 mov      w20, #1
033a1c1c: 0078211e fminnm   s0, s0, s1
033a1c20: 14000239 strb     w20, [x0, #0x80]
033a1c24: 006c00bd str      s0, [x0, #0x6c]
033a1c28: b70e01d0 adrp     x23, #0x5577000
033a1c2c: e81a6039 ldrb     w8, [x23, #0x806]
033a1c30: 4a1ca24e mov      v10.16b, v2.16b
033a1c34: f30300aa mov      x19, x0
033a1c38: a8000035 cbnz     w8, #0x33a1c4c
033a1c3c: e0f200f0 adrp     x0, #0x5200000
033a1c40: 008c46f9 ldr      x0, [x0, #0xd18]
033a1c44: af3d7097 bl       #0xfb1300
033a1c48: f41a2039 strb     w20, [x23, #0x806]
033a1c4c: f4f200f0 adrp     x20, #0x5200000
033a1c50: 948e46f9 ldr      x20, [x20, #0xd18]
033a1c54: 800240f9 ldr      x0, [x20]
033a1c58: 08e040b9 ldr      w8, [x0, #0xe0]
033a1c5c: 48000035 cbnz     w8, #0x33a1c64
033a1c60: e93d7097 bl       #0xfb1404
033a1c64: 2009291e fmul     s0, s9, s9
033a1c68: 0109281e fmul     s1, s8, s8
033a1c6c: 285600d0 adrp     x8, #0x3e67000
033a1c70: 0d28211e fadd     s13, s0, s1
033a1c74: 40092a1e fmul     s0, s10, s10
033a1c78: 02ad44bd ldr      s2, [x8, #0x4ac]
033a1c7c: 0c282d1e fadd     s12, s0, s13
033a1c80: 8bc1211e fsqrt    s11, s12
033a1c84: e103271e fmov     s1, wzr
033a1c88: 601dab4e mov      v0.16b, v11.16b
033a1c8c: e0031faa mov      x0, xzr
033a1c90: 2d73fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
033a1c94: 965600d0 adrp     x22, #0x3e73000
033a1c98: 955600d0 adrp     x21, #0x3e73000
033a1c9c: ed1f00bd str      s13, [sp, #0x1c]
033a1ca0: 40090036 tbz      w0, #0, #0x33a1dc8
033a1ca4: b80e01b0 adrp     x24, #0x5576000
033a1ca8: 08bb7c39 ldrb     w8, [x24, #0xf2e]
033a1cac: c8000035 cbnz     w8, #0x33a1cc4
033a1cb0: 40f400d0 adrp     x0, #0x522b000
033a1cb4: 00ac43f9 ldr      x0, [x0, #0x758]
033a1cb8: 923d7097 bl       #0xfb1300
033a1cbc: 28008052 mov      w8, #1
033a1cc0: 08bb3c39 strb     w8, [x24, #0xf2e]
033a1cc4: 57f400d0 adrp     x23, #0x522b000
033a1cc8: f7ae43f9 ldr      x23, [x23, #0x758]
033a1ccc: 190f01f0 adrp     x25, #0x5584000
033a1cd0: 29ff4f39 ldrb     w9, [x25, #0x3ff]
033a1cd4: e80240f9 ldr      x8, [x23]
033a1cd8: 085d40f9 ldr      x8, [x8, #0xb8]
033a1cdc: 0f35432d ldp      s15, s13, [x8, #0x18]
033a1ce0: 0b2140bd ldr      s11, [x8, #0x20]
033a1ce4: c9000035 cbnz     w9, #0x33a1cfc
033a1ce8: e0f200f0 adrp     x0, #0x5200000
033a1cec: 008c46f9 ldr      x0, [x0, #0xd18]
033a1cf0: 843d7097 bl       #0xfb1300
033a1cf4: 28008052 mov      w8, #1
033a1cf8: 28ff0f39 strb     w8, [x25, #0x3ff]
033a1cfc: 800240f9 ldr      x0, [x20]
033a1d00: e0092f1e fmul     s0, s15, s15
033a1d04: a1092d1e fmul     s1, s13, s13
033a1d08: 0028211e fadd     s0, s0, s1
033a1d0c: 08e040b9 ldr      w8, [x0, #0xe0]
033a1d10: 61092b1e fmul     s1, s11, s11
033a1d14: 2e28201e fadd     s14, s1, s0
033a1d18: 48000035 cbnz     w8, #0x33a1d20
033a1d1c: ba3d7097 bl       #0xfb1404
033a1d20: c18e4bbd ldr      s1, [x22, #0xb8c]
033a1d24: 80092e1e fmul     s0, s12, s14
033a1d28: 00c0211e fsqrt    s0, s0
033a1d2c: 0e102e1e fmov     s14, #1.00000000
033a1d30: 0020211e fcmp     s0, s1
033a1d34: 24070054 b.mi     #0x33a1e18
033a1d38: 800240f9 ldr      x0, [x20]
033a1d3c: 21092f1e fmul     s1, s9, s15
033a1d40: 02092d1e fmul     s2, s8, s13
033a1d44: 2128221e fadd     s1, s1, s2
033a1d48: 42092b1e fmul     s2, s10, s11
033a1d4c: 4128211e fadd     s1, s2, s1
033a1d50: 08e040b9 ldr      w8, [x0, #0xe0]
033a1d54: 2018201e fdiv     s0, s1, s0
033a1d58: 02103e1e fmov     s2, #-1.00000000
033a1d5c: 01582e1e fmin     s1, s0, s14
033a1d60: 0020221e fcmp     s0, s2
033a1d64: 2a5c221e fcsel    s10, s1, s2, pl
033a1d68: 48000035 cbnz     w8, #0x33a1d70
033a1d6c: a63d7097 bl       #0xfb1404
033a1d70: 40c1221e fcvt     d0, s10
033a1d74: 13846497 bl       #0xcc2dc0
033a1d78: a1924bbd ldr      s1, [x21, #0xb90]
033a1d7c: 0040621e fcvt     s0, d0
033a1d80: 0854a852 mov      w8, #0x42a00000
033a1d84: 0008211e fmul     s0, s0, s1
033a1d88: 0101271e fmov     s1, w8
033a1d8c: 0020211e fcmp     s0, s1
033a1d90: 4d040054 b.le     #0x33a1e18
033a1d94: 08bb7c39 ldrb     w8, [x24, #0xf2e]
033a1d98: c8000035 cbnz     w8, #0x33a1db0
033a1d9c: 40f400d0 adrp     x0, #0x522b000
033a1da0: 00ac43f9 ldr      x0, [x0, #0x758]
033a1da4: 573d7097 bl       #0xfb1300
033a1da8: 28008052 mov      w8, #1
033a1dac: 08bb3c39 strb     w8, [x24, #0xf2e]
033a1db0: e80240f9 ldr      x8, [x23]
033a1db4: 0a5d40f9 ldr      x10, [x8, #0xb8]
033a1db8: 49610091 add      x9, x10, #0x18
033a1dbc: 48710091 add      x8, x10, #0x1c
033a1dc0: 4a810091 add      x10, x10, #0x20
033a1dc4: 22000014 b        #0x33a1e4c
033a1dc8: b80e01d0 adrp     x24, #0x5577000
033a1dcc: 08fb7f39 ldrb     w8, [x24, #0xffe]
033a1dd0: c8000035 cbnz     w8, #0x33a1de8
033a1dd4: e0f200f0 adrp     x0, #0x5200000
033a1dd8: 008c46f9 ldr      x0, [x0, #0xd18]
033a1ddc: 493d7097 bl       #0xfb1300
033a1de0: 28008052 mov      w8, #1
033a1de4: 08fb3f39 strb     w8, [x24, #0xffe]
033a1de8: 800240f9 ldr      x0, [x20]
033a1dec: 08e040b9 ldr      w8, [x0, #0xe0]
033a1df0: 48000035 cbnz     w8, #0x33a1df8
033a1df4: 843d7097 bl       #0xfb1404
033a1df8: 885600d0 adrp     x8, #0x3e73000
033a1dfc: 00894bbd ldr      s0, [x8, #0xb88]
033a1e00: 6021201e fcmp     s11, s0
033a1e04: 8d060054 b.le     #0x33a1ed4
033a1e08: 2c192b1e fdiv     s12, s9, s11
033a1e0c: 0d192b1e fdiv     s13, s8, s11
033a1e10: 4a192b1e fdiv     s10, s10, s11
033a1e14: 3e000014 b        #0x33a1f0c
033a1e18: b80e01b0 adrp     x24, #0x5576000
033a1e1c: 08c37c39 ldrb     w8, [x24, #0xf30]
033a1e20: c8000035 cbnz     w8, #0x33a1e38
033a1e24: 40f400d0 adrp     x0, #0x522b000
033a1e28: 00ac43f9 ldr      x0, [x0, #0x758]
033a1e2c: 353d7097 bl       #0xfb1300
033a1e30: 28008052 mov      w8, #1
033a1e34: 08c33c39 strb     w8, [x24, #0xf30]
033a1e38: e80240f9 ldr      x8, [x23]
033a1e3c: 0a5d40f9 ldr      x10, [x8, #0xb8]
033a1e40: 49910091 add      x9, x10, #0x24
033a1e44: 48a10091 add      x8, x10, #0x28
033a1e48: 4ab10091 add      x10, x10, #0x2c
033a1e4c: 200140bd ldr      s0, [x9]
033a1e50: 4a0140bd ldr      s10, [x10]
033a1e54: e0031faa mov      x0, xzr
033a1e58: 0d103e1e fmov     s13, #-1.00000000
033a1e5c: 0091400d ld1      {v0.s}[1], [x8]
033a1e60: e003803d str      q0, [sp]
033a1e64: dbb9ce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
033a1e68: e303c03d ldr      q3, [sp]
033a1e6c: 81f4010f fmov     v1.2s, #10.00000000
033a1e70: 0290241e fmov     s2, #10.00000000
033a1e74: 4209221e fmul     s2, s10, s2
033a1e78: a8999952 mov      w8, #0xcccd
033a1e7c: 61dc212e fmul     v1.2s, v3.2s, v1.2s
033a1e80: 88c9a772 movk     w8, #0x3e4c, lsl #16
033a1e84: 4208201e fmul     s2, s2, s0
033a1e88: 2090800f fmul     v0.2s, v1.2s, v0.s[0]
033a1e8c: 687a00b9 str      w8, [x19, #0x78]
033a1e90: 624a00bd str      s2, [x19, #0x48]
033a1e94: 602200fd str      d0, [x19, #0x40]
033a1e98: b80e01b0 adrp     x24, #0x5576000
033a1e9c: 08b37c39 ldrb     w8, [x24, #0xf2c]
033a1ea0: c8000035 cbnz     w8, #0x33a1eb8
033a1ea4: 40f400d0 adrp     x0, #0x522b000
033a1ea8: 00ac43f9 ldr      x0, [x0, #0x758]
033a1eac: 153d7097 bl       #0xfb1300
033a1eb0: 28008052 mov      w8, #1
033a1eb4: 08b33c39 strb     w8, [x24, #0xf2c]
033a1eb8: e80240f9 ldr      x8, [x23]
033a1ebc: 085d40f9 ldr      x8, [x8, #0xb8]
033a1ec0: 090140f9 ldr      x9, [x8]
033a1ec4: 080940b9 ldr      w8, [x8, #8]
033a1ec8: 694600f9 str      x9, [x19, #0x88]
033a1ecc: 689200b9 str      w8, [x19, #0x90]
033a1ed0: 36000014 b        #0x33a1fa8
033a1ed4: b80e01b0 adrp     x24, #0x5576000
033a1ed8: 08b37c39 ldrb     w8, [x24, #0xf2c]
033a1edc: c8000035 cbnz     w8, #0x33a1ef4
033a1ee0: 40f400d0 adrp     x0, #0x522b000
033a1ee4: 00ac43f9 ldr      x0, [x0, #0x758]
033a1ee8: 063d7097 bl       #0xfb1300
033a1eec: 28008052 mov      w8, #1
033a1ef0: 08b33c39 strb     w8, [x24, #0xf2c]
033a1ef4: 48f400d0 adrp     x8, #0x522b000
033a1ef8: 08ad43f9 ldr      x8, [x8, #0x758]
033a1efc: 080140f9 ldr      x8, [x8]
033a1f00: 085d40f9 ldr      x8, [x8, #0xb8]
033a1f04: 0c35402d ldp      s12, s13, [x8]
033a1f08: 0a0940bd ldr      s10, [x8, #8]
033a1f0c: e81a6039 ldrb     w8, [x23, #0x806]
033a1f10: c8000035 cbnz     w8, #0x33a1f28
033a1f14: e0f200f0 adrp     x0, #0x5200000
033a1f18: 008c46f9 ldr      x0, [x0, #0xd18]
033a1f1c: f93c7097 bl       #0xfb1300
033a1f20: 28008052 mov      w8, #1
033a1f24: e81a2039 strb     w8, [x23, #0x806]
033a1f28: 800240f9 ldr      x0, [x20]
033a1f2c: 6e3e482d ldp      s14, s15, [x19, #0x40]
033a1f30: 6b4a40bd ldr      s11, [x19, #0x48]
033a1f34: 08e040b9 ldr      w8, [x0, #0xe0]
033a1f38: 48000035 cbnz     w8, #0x33a1f40
033a1f3c: 323d7097 bl       #0xfb1404
033a1f40: c0092e1e fmul     s0, s14, s14
033a1f44: e1092f1e fmul     s1, s15, s15
033a1f48: 0028211e fadd     s0, s0, s1
033a1f4c: 61092b1e fmul     s1, s11, s11
033a1f50: 0028211e fadd     s0, s0, s1
033a1f54: e0031faa mov      x0, xzr
033a1f58: 0bc0211e fsqrt    s11, s0
033a1f5c: 9db9ce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
033a1f60: 0190241e fmov     s1, #10.00000000
033a1f64: 0008211e fmul     s0, s0, s1
033a1f68: 6021201e fcmp     s11, s0
033a1f6c: 60cd201e fcsel    s0, s11, s0, gt
033a1f70: 8b09201e fmul     s11, s12, s0
033a1f74: ac09201e fmul     s12, s13, s0
033a1f78: 4a09201e fmul     s10, s10, s0
033a1f7c: e0031faa mov      x0, xzr
033a1f80: 6b32082d stp      s11, s12, [x19, #0x40]
033a1f84: 6a4a00bd str      s10, [x19, #0x48]
033a1f88: 92b9ce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
033a1f8c: 6109201e fmul     s1, s11, s0
033a1f90: 8209201e fmul     s2, s12, s0
033a1f94: 4009201e fmul     s0, s10, s0
033a1f98: 0e102e1e fmov     s14, #1.00000000
033a1f9c: 0d103e1e fmov     s13, #-1.00000000
033a1fa0: 610a112d stp      s1, s2, [x19, #0x88]
033a1fa4: 609200bd str      s0, [x19, #0x90]
033a1fa8: b70e01b0 adrp     x23, #0x5576000
033a1fac: e8d27c39 ldrb     w8, [x23, #0xf34]
033a1fb0: c8000035 cbnz     w8, #0x33a1fc8
033a1fb4: 40f40090 adrp     x0, #0x5229000
033a1fb8: 001840f9 ldr      x0, [x0, #0x30]
033a1fbc: d13c7097 bl       #0xfb1300
033a1fc0: 28008052 mov      w8, #1
033a1fc4: e8d23c39 strb     w8, [x23, #0xf34]
033a1fc8: 48f40090 adrp     x8, #0x5229000
033a1fcc: 081940f9 ldr      x8, [x8, #0x30]
033a1fd0: b70e01d0 adrp     x23, #0x5577000
033a1fd4: e9665d39 ldrb     w9, [x23, #0x759]
033a1fd8: 080140f9 ldr      x8, [x8]
033a1fdc: 085d40f9 ldr      x8, [x8, #0xb8]
033a1fe0: 0b29422d ldp      s11, s10, [x8, #0x10]
033a1fe4: c9000035 cbnz     w9, #0x33a1ffc
033a1fe8: e0f200f0 adrp     x0, #0x5200000
033a1fec: 008c46f9 ldr      x0, [x0, #0xd18]
033a1ff0: c43c7097 bl       #0xfb1300
033a1ff4: 28008052 mov      w8, #1
033a1ff8: e8661d39 strb     w8, [x23, #0x759]
033a1ffc: 800240f9 ldr      x0, [x20]
033a2000: 60092b1e fmul     s0, s11, s11
033a2004: 41092a1e fmul     s1, s10, s10
033a2008: 0c28211e fadd     s12, s0, s1
033a200c: 08e040b9 ldr      w8, [x0, #0xe0]
033a2010: 48000035 cbnz     w8, #0x33a2018
033a2014: fc3c7097 bl       #0xfb1404
033a2018: e11f40bd ldr      s1, [sp, #0x1c]
033a201c: c08e4bbd ldr      s0, [x22, #0xb8c]
033a2020: 21082c1e fmul     s1, s1, s12
033a2024: 21c0211e fsqrt    s1, s1
033a2028: 2020201e fcmp     s1, s0
033a202c: e003271e fmov     s0, wzr
033a2030: 24020054 b.mi     #0x33a2074
033a2034: 800240f9 ldr      x0, [x20]
033a2038: 20092b1e fmul     s0, s9, s11
033a203c: 02092a1e fmul     s2, s8, s10
033a2040: 0028221e fadd     s0, s0, s2
033a2044: 08e040b9 ldr      w8, [x0, #0xe0]
033a2048: 0018211e fdiv     s0, s0, s1
033a204c: 01582e1e fmin     s1, s0, s14
033a2050: 00202d1e fcmp     s0, s13
033a2054: 2c5c2d1e fcsel    s12, s1, s13, pl
033a2058: 48000035 cbnz     w8, #0x33a2060
033a205c: ea3c7097 bl       #0xfb1404
033a2060: 80c1221e fcvt     d0, s12
033a2064: 57836497 bl       #0xcc2dc0
033a2068: a1924bbd ldr      s1, [x21, #0xb90]
033a206c: 0040621e fcvt     s0, d0
033a2070: 0008211e fmul     s0, s0, s1
033a2074: 01092b1e fmul     s1, s8, s11
033a2078: 22092a1e fmul     s2, s9, s10
033a207c: 2138221e fsub     s1, s1, s2
033a2080: 2820201e fcmp     s1, #0.0
033a2084: c1ad2d1e fcsel    s1, s14, s13, ge
033a2088: 602a40f9 ldr      x0, [x19, #0x50]
033a208c: 2008201e fmul     s0, s1, s0
033a2090: 0820201e fcmp     s0, #0.0
033a2094: e8d79f1a cset     w8, gt
033a2098: 68c20239 strb     w8, [x19, #0xb0]
033a209c: c00100b4 cbz      x0, #0x33a20d4
033a20a0: f37b49a9 ldp      x19, x30, [sp, #0x90]
033a20a4: f55348a9 ldp      x21, x20, [sp, #0x80]
033a20a8: f75b47a9 ldp      x23, x22, [sp, #0x70]
033a20ac: f96346a9 ldp      x25, x24, [sp, #0x60]
033a20b0: e923456d ldp      d9, d8, [sp, #0x50]
033a20b4: eb2b446d ldp      d11, d10, [sp, #0x40]
033a20b8: ed33436d ldp      d13, d12, [sp, #0x30]
033a20bc: ef3b426d ldp      d15, d14, [sp, #0x20]
033a20c0: 0820201e fcmp     s0, #0.0
033a20c4: e1d79f1a cset     w1, gt
033a20c8: e2031faa mov      x2, xzr
033a20cc: ff830291 add      sp, sp, #0xa0
033a20d0: 73b9bf17 b        #0x239069c ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$UpdateRotateDirection
033a20d4: d53c7097 bl       #0xfb1428
