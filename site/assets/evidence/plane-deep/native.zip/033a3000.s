# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$OnTargetFound
# Linear span to next metadata entry; not a complete CFG.
033a3000: c0035fd6 ret      
