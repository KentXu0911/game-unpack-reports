# Royal.Scenes.Game.Mechanics.Items.PortalDoorItem.PortalDoorItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01c0ba30: e0031f2a mov      w0, wzr
01c0ba34: c0035fd6 ret      
