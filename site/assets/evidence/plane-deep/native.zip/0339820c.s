# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$ChangeAlpha
# Linear span to next metadata entry; not a complete CFG.
0339820c: c0035fd6 ret      
