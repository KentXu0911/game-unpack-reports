# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerTargetExplodeParticles$$GetPoolId
# Linear span to next metadata entry; not a complete CFG.
03398994: 80018052 mov      w0, #0xc
03398998: c0035fd6 ret      
