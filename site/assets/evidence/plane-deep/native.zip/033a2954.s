# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerPropellerComboStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a2954: e80f1efc str      d8, [sp, #-0x20]!
033a2958: f40700f9 str      x20, [sp, #8]
033a295c: f37b01a9 stp      x19, x30, [sp, #0x10]
033a2960: 34000012 and      w20, w1, #1
033a2964: e1031f2a mov      w1, wzr
033a2968: 081ca04e mov      v8.16b, v0.16b
033a296c: f30300aa mov      x19, x0
033a2970: 57000094 bl       #0x33a2acc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$.ctor
033a2974: 682600bd str      s8, [x19, #0x24]
033a2978: 74a20039 strb     w20, [x19, #0x28]
033a297c: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a2980: f40740f9 ldr      x20, [sp, #8]
033a2984: e80742fc ldr      d8, [sp], #0x20
033a2988: c0035fd6 ret      
