# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_MaxGoSpeedConst
# Linear span to next metadata entry; not a complete CFG.
033989c8: 0849a852 mov      w8, #0x42480000
033989cc: 0001271e fmov     s0, w8
033989d0: c0035fd6 ret      
