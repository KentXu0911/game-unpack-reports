# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$GetMinFlyTime
# Linear span to next metadata entry; not a complete CFG.
033a1070: 285600d0 adrp     x8, #0x3e67000
033a1074: 009544bd ldr      s0, [x8, #0x494]
033a1078: c0035fd6 ret      
