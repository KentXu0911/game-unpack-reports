# Royal.Scenes.Game.Mechanics.Items.TabletItem.TabletItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03debf8c: e80f1dfc str      d8, [sp, #-0x30]!
03debf90: f60700f9 str      x22, [sp, #8]
03debf94: f55301a9 stp      x21, x20, [sp, #0x10]
03debf98: f37b02a9 stp      x19, x30, [sp, #0x20]
03debf9c: f403012a mov      w20, w1
03debfa0: f30300aa mov      x19, x0
03debfa4: e003012a mov      w0, w1
03debfa8: e1031faa mov      x1, xzr
03debfac: 5d62d697 bl       #0x3384920 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsMultipleExploder
03debfb0: 00010036 tbz      w0, #0, #0x3debfd0
03debfb4: 680240f9 ldr      x8, [x19]
03debfb8: e00313aa mov      x0, x19
03debfbc: 095542f9 ldr      x9, [x8, #0x4a8]
03debfc0: 015942f9 ldr      x1, [x8, #0x4b0]
03debfc4: 20013fd6 blr      x9
03debfc8: 1f040071 cmp      w0, #1
03debfcc: ab060054 b.lt     #0x3dec0a0
03debfd0: 680240f9 ldr      x8, [x19]
03debfd4: e00313aa mov      x0, x19
03debfd8: 096542f9 ldr      x9, [x8, #0x4c8]
03debfdc: 016942f9 ldr      x1, [x8, #0x4d0]
03debfe0: 20013fd6 blr      x9
03debfe4: 1f040071 cmp      w0, #1
03debfe8: cb050054 b.lt     #0x3dec0a0
03debfec: e00313aa mov      x0, x19
03debff0: ddfeff97 bl       #0x3debb64 ; Royal.Scenes.Game.Mechanics.Items.TabletItem.TabletItemModel$$GetItemManager
03debff4: c00900b4 cbz      x0, #0x3dec12c
03debff8: f60300aa mov      x22, x0
03debffc: 95feff97 bl       #0x3deba50 ; Royal.Scenes.Game.Mechanics.Items.TabletItem.TabletItemManager$$GetGroupRemainingExplodeCount
03dec000: f503002a mov      w21, w0
03dec004: e003142a mov      w0, w20
03dec008: e1031faa mov      x1, xzr
03dec00c: 4c62d697 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03dec010: c0040036 tbz      w0, #0, #0x3dec0a8
03dec014: 680240f9 ldr      x8, [x19]
03dec018: e00313aa mov      x0, x19
03dec01c: 096542f9 ldr      x9, [x8, #0x4c8]
03dec020: 016942f9 ldr      x1, [x8, #0x4d0]
03dec024: 20013fd6 blr      x9
03dec028: bf02006b cmp      w21, w0
03dec02c: e1030054 b.ne     #0x3dec0a8
03dec030: c006432d ldp      s0, s1, [x22, #0x18]
03dec034: e00313aa mov      x0, x19
03dec038: e103142a mov      w1, w20
03dec03c: e2031faa mov      x2, xzr
03dec040: 0808211e fmul     s8, s0, s1
03dec044: 1601381e fcvtzs   w22, s8
03dec048: 4962d697 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
03dec04c: 680240f9 ldr      x8, [x19]
03dec050: f403002a mov      w20, w0
03dec054: e00313aa mov      x0, x19
03dec058: 09bd41f9 ldr      x9, [x8, #0x378]
03dec05c: 01c141f9 ldr      x1, [x8, #0x380]
03dec060: 20013fd6 blr      x9
03dec064: e1031faa mov      x1, xzr
03dec068: 4862d697 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03dec06c: 09f0af52 mov      w9, #0x7f800000
03dec070: 2001271e fmov     s0, w9
03dec074: c8060051 sub      w8, w22, #1
03dec078: 0a00b012 mov      w10, #0x7fffffff
03dec07c: 0021201e fcmp     s8, s0
03dec080: 6b008052 mov      w11, #3
03dec084: 4801881a csel     w8, w10, w8, eq
03dec088: bf060071 cmp      w21, #1
03dec08c: 087c081b mul      w8, w0, w8
03dec090: 69058b1a cinc     w9, w11, ne
03dec094: 080dc91a sdiv     w8, w8, w9
03dec098: 0001140b add      w0, w8, w20
03dec09c: 1f000014 b        #0x3dec118
03dec0a0: e0031f2a mov      w0, wzr
03dec0a4: 1d000014 b        #0x3dec118
03dec0a8: e003142a mov      w0, w20
03dec0ac: e1031faa mov      x1, xzr
03dec0b0: 3f62d697 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03dec0b4: e0000036 tbz      w0, #0, #0x3dec0d0
03dec0b8: 602a40f9 ldr      x0, [x19, #0x50]
03dec0bc: 800300b4 cbz      x0, #0x3dec12c
03dec0c0: 61c242f8 ldur     x1, [x19, #0x2c]
03dec0c4: e2031faa mov      x2, xzr
03dec0c8: 12a1a597 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
03dec0cc: 04000014 b        #0x3dec0dc
03dec0d0: e00313aa mov      x0, x19
03dec0d4: e1031faa mov      x1, xzr
03dec0d8: 6f5bd697 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
03dec0dc: c10a40f9 ldr      x1, [x22, #0x10]
03dec0e0: a4608a52 mov      w4, #0x5305
03dec0e4: e20300aa mov      x2, x0
03dec0e8: 4400a072 movk     w4, #2, lsl #16
03dec0ec: e00313aa mov      x0, x19
03dec0f0: e303142a mov      w3, w20
03dec0f4: e503152a mov      w5, w21
03dec0f8: e6031faa mov      x6, xzr
03dec0fc: 3362d697 bl       #0x33849c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetItemExplodeExtraScore
03dec100: f503002a mov      w21, w0
03dec104: e00313aa mov      x0, x19
03dec108: e103142a mov      w1, w20
03dec10c: e2031faa mov      x2, xzr
03dec110: 1762d697 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
03dec114: 0000150b add      w0, w0, w21
03dec118: f37b42a9 ldp      x19, x30, [sp, #0x20]
03dec11c: f55341a9 ldp      x21, x20, [sp, #0x10]
03dec120: f60740f9 ldr      x22, [sp, #8]
03dec124: e80743fc ldr      d8, [sp], #0x30
03dec128: c0035fd6 ret      
03dec12c: bf144797 bl       #0xfb1428
