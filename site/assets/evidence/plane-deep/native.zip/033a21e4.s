# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$GetRedirectSmoother
# Linear span to next metadata entry; not a complete CFG.
033a21e4: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a21e8: f30300aa mov      x19, x0
033a21ec: e0031faa mov      x0, xzr
033a21f0: 8ec2ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a21f4: 612640bd ldr      s1, [x19, #0x24]
033a21f8: 285600b0 adrp     x8, #0x3e67000
033a21fc: 02fd44bd ldr      s2, [x8, #0x4fc]
033a2200: 0038211e fsub     s0, s0, s1
033a2204: 617a40bd ldr      s1, [x19, #0x78]
033a2208: 0018221e fdiv     s0, s0, s2
033a220c: 02102e1e fmov     s2, #1.00000000
033a2210: 0258221e fmin     s2, s0, s2
033a2214: 0820201e fcmp     s0, #0.0
033a2218: e003271e fmov     s0, wzr
033a221c: 425c201e fcsel    s2, s2, s0, pl
033a2220: 0038211e fsub     s0, s0, s1
033a2224: 0008221e fmul     s0, s0, s2
033a2228: 2028201e fadd     s0, s1, s0
033a222c: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a2230: c0035fd6 ret      
