# Royal.Scenes.Game.Mechanics.Items.LogCollectItem.LogCollectItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01c1ffe8: f553bea9 stp      x21, x20, [sp, #-0x20]!
01c1ffec: f37b01a9 stp      x19, x30, [sp, #0x10]
01c1fff0: f303012a mov      w19, w1
01c1fff4: f40300aa mov      x20, x0
01c1fff8: e003012a mov      w0, w1
01c1fffc: e1031faa mov      x1, xzr
01c20000: 4f925d94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
01c20004: 80030036 tbz      w0, #0, #0x1c20074
01c20008: 880240f9 ldr      x8, [x20]
01c2000c: e00314aa mov      x0, x20
01c20010: 096542f9 ldr      x9, [x8, #0x4c8]
01c20014: 016942f9 ldr      x1, [x8, #0x4d0]
01c20018: 20013fd6 blr      x9
01c2001c: 1f040071 cmp      w0, #1
01c20020: a1020054 b.ne     #0x1c20074
01c20024: 5ffeff97 bl       #0x1c1f9a0 ; Royal.Scenes.Game.Mechanics.Items.LogCollectItem.LogCollectItemModel$$get_LogItemHelper
01c20028: 200300b4 cbz      x0, #0x1c2008c
01c2002c: e1031faa mov      x1, xzr
01c20030: c5400894 bl       #0x1e30344 ; Royal.Scenes.Game.Mechanics.Items.LogItem.LogItemHelper$$OneTargetRemainingOnAnyLogItem
01c20034: 00020036 tbz      w0, #0, #0x1c20074
01c20038: 5afeff97 bl       #0x1c1f9a0 ; Royal.Scenes.Game.Mechanics.Items.LogCollectItem.LogCollectItemModel$$get_LogItemHelper
01c2003c: 800200b4 cbz      x0, #0x1c2008c
01c20040: e1031faa mov      x1, xzr
01c20044: 79410894 bl       #0x1e30628 ; Royal.Scenes.Game.Mechanics.Items.LogItem.LogItemHelper$$ShouldAddExtraScoreForLastState
01c20048: 1f000072 tst      w0, #1
01c2004c: 28509652 mov      w8, #0xb281
01c20050: e00314aa mov      x0, x20
01c20054: e103132a mov      w1, w19
01c20058: e2031faa mov      x2, xzr
01c2005c: 15119f1a csel     w21, w8, wzr, ne
01c20060: 43925d94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
01c20064: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c20068: a002000b add      w0, w21, w0
01c2006c: f553c2a8 ldp      x21, x20, [sp], #0x20
01c20070: c0035fd6 ret      
01c20074: e103132a mov      w1, w19
01c20078: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c2007c: e00314aa mov      x0, x20
01c20080: e2031faa mov      x2, xzr
01c20084: f553c2a8 ldp      x21, x20, [sp], #0x20
01c20088: 39925d14 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
01c2008c: e744ce97 bl       #0xfb1428
