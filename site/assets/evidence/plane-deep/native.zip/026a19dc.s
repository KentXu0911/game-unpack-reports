# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$set_LastValidCell
# Linear span to next metadata entry; not a complete CFG.
026a19dc: 010c0cf8 str      x1, [x0, #0xc0]!
026a19e0: 333ea417 b        #0xfb12ac
