# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddMultipleHittableMultiCellItemHit
# Linear span to next metadata entry; not a complete CFG.
026a7c48: f80f1cf8 str      x24, [sp, #-0x40]!
026a7c4c: f75b01a9 stp      x23, x22, [sp, #0x10]
026a7c50: f55302a9 stp      x21, x20, [sp, #0x20]
026a7c54: f37b03a9 stp      x19, x30, [sp, #0x30]
026a7c58: d87601b0 adrp     x24, #0x5580000
026a7c5c: 08874139 ldrb     w8, [x24, #0x61]
026a7c60: f303042a mov      w19, w4
026a7c64: f403032a mov      w20, w3
026a7c68: f703022a mov      w23, w2
026a7c6c: f603012a mov      w22, w1
026a7c70: f50300aa mov      x21, x0
026a7c74: c8000037 tbnz     w8, #0, #0x26a7c8c
026a7c78: 405a01f0 adrp     x0, #0x51f2000
026a7c7c: 000047f9 ldr      x0, [x0, #0xe00]
026a7c80: a025a497 bl       #0xfb1300
026a7c84: 28008052 mov      w8, #1
026a7c88: 08870139 strb     w8, [x24, #0x61]
026a7c8c: e00315aa mov      x0, x21
026a7c90: e103162a mov      w1, w22
026a7c94: 1a000094 bl       #0x26a7cfc ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$GetMultipleHittableMultiCellHitCount
026a7c98: 1f00176b cmp      w0, w23
026a7c9c: 4a020054 b.ge     #0x26a7ce4
026a7ca0: a82240f9 ldr      x8, [x21, #0x40]
026a7ca4: a80200b4 cbz      x8, #0x26a7cf8
026a7ca8: 495a01f0 adrp     x9, #0x51f2000
026a7cac: 290147f9 ldr      x9, [x9, #0xe00]
026a7cb0: 0200130b add      w2, w0, w19
026a7cb4: e00308aa mov      x0, x8
026a7cb8: e103162a mov      w1, w22
026a7cbc: 230140f9 ldr      x3, [x9]
026a7cc0: 1c214194 bl       #0x36f0130 ; System.Collections.Generic.Dictionary<int, int>$$set_Item
026a7cc4: e00315aa mov      x0, x21
026a7cc8: e103142a mov      w1, w20
026a7ccc: e203132a mov      w2, w19
026a7cd0: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a7cd4: f55342a9 ldp      x21, x20, [sp, #0x20]
026a7cd8: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a7cdc: f80744f8 ldr      x24, [sp], #0x40
026a7ce0: ccffff17 b        #0x26a7c10 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddGoalHit
026a7ce4: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a7ce8: f55342a9 ldp      x21, x20, [sp, #0x20]
026a7cec: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a7cf0: f80744f8 ldr      x24, [sp], #0x40
026a7cf4: c0035fd6 ret      
026a7cf8: cc25a497 bl       #0xfb1428
