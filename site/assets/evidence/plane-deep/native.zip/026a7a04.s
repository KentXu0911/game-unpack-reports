# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ClearGoalData
# Linear span to next metadata entry; not a complete CFG.
026a7a04: f40f1ef8 str      x20, [sp, #-0x20]!
026a7a08: f37b01a9 stp      x19, x30, [sp, #0x10]
026a7a0c: d47601b0 adrp     x20, #0x5580000
026a7a10: 887a4139 ldrb     w8, [x20, #0x5e]
026a7a14: f30300aa mov      x19, x0
026a7a18: 28010037 tbnz     w8, #0, #0x26a7a3c
026a7a1c: a05901d0 adrp     x0, #0x51dd000
026a7a20: 00d041f9 ldr      x0, [x0, #0x3a0]
026a7a24: 3726a497 bl       #0xfb1300
026a7a28: 20580190 adrp     x0, #0x51ab000
026a7a2c: 00c844f9 ldr      x0, [x0, #0x990]
026a7a30: 3426a497 bl       #0xfb1300
026a7a34: 28008052 mov      w8, #1
026a7a38: 887a0139 strb     w8, [x20, #0x5e]
026a7a3c: 6b1a40f9 ldr      x11, [x19, #0x30]
026a7a40: 6b0400b4 cbz      x11, #0x26a7acc
026a7a44: 681940b9 ldr      w8, [x11, #0x18]
026a7a48: 097d60d3 lsl      x9, x8, #0x20
026a7a4c: 3f0500f1 cmp      x9, #1
026a7a50: 4b010054 b.lt     #0x26a7a78
026a7a54: e9031faa mov      x9, xzr
026a7a58: 0a7d4093 sxtw     x10, w8
026a7a5c: 6b810091 add      x11, x11, #0x20
026a7a60: 3f0108eb cmp      x9, x8
026a7a64: 22030054 b.hs     #0x26a7ac8
026a7a68: 7f7929b8 str      wzr, [x11, x9, lsl #2]
026a7a6c: 29050091 add      x9, x9, #1
026a7a70: 3f010aeb cmp      x9, x10
026a7a74: 6bffff54 b.lt     #0x26a7a60
026a7a78: 601e40f9 ldr      x0, [x19, #0x38]
026a7a7c: 7f520039 strb     wzr, [x19, #0x14]
026a7a80: 7f1200b9 str      wzr, [x19, #0x10]
026a7a84: 400200b4 cbz      x0, #0x26a7acc
026a7a88: 28580190 adrp     x8, #0x51ab000
026a7a8c: 08c944f9 ldr      x8, [x8, #0x990]
026a7a90: 010140f9 ldr      x1, [x8]
026a7a94: 6e840e94 bl       #0x2a48c4c ; System.Collections.Generic.HashSet<int>$$Clear
026a7a98: 602240f9 ldr      x0, [x19, #0x40]
026a7a9c: 800100b4 cbz      x0, #0x26a7acc
026a7aa0: b45901d0 adrp     x20, #0x51dd000
026a7aa4: 94d241f9 ldr      x20, [x20, #0x3a0]
026a7aa8: 810240f9 ldr      x1, [x20]
026a7aac: 0a224194 bl       #0x36f02d4 ; System.Collections.Generic.Dictionary<int, int>$$Clear
026a7ab0: 602640f9 ldr      x0, [x19, #0x48]
026a7ab4: c00000b4 cbz      x0, #0x26a7acc
026a7ab8: 810240f9 ldr      x1, [x20]
026a7abc: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a7ac0: f40742f8 ldr      x20, [sp], #0x20
026a7ac4: 04224114 b        #0x36f02d4 ; System.Collections.Generic.Dictionary<int, int>$$Clear
026a7ac8: 5a26a497 bl       #0xfb1430
026a7acc: 5726a497 bl       #0xfb1428
