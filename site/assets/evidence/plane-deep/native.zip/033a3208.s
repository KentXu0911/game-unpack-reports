# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$IncrementTargetIndex
# Linear span to next metadata entry; not a complete CFG.
033a3208: c0035fd6 ret      
