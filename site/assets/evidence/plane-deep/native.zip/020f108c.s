# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$GetPrioritizedCellForJellySpread
# Linear span to next metadata entry; not a complete CFG.
020f108c: fc0f1bf8 str      x28, [sp, #-0x50]!
020f1090: f96301a9 stp      x25, x24, [sp, #0x10]
020f1094: f75b02a9 stp      x23, x22, [sp, #0x20]
020f1098: f55303a9 stp      x21, x20, [sp, #0x30]
020f109c: f37b04a9 stp      x19, x30, [sp, #0x40]
020f10a0: ffc309d1 sub      sp, sp, #0x270
020f10a4: 77a40190 adrp     x23, #0x557d000
020f10a8: e81a5539 ldrb     w8, [x23, #0x546]
020f10ac: f40302aa mov      x20, x2
020f10b0: f503012a mov      w21, w1
020f10b4: f30300aa mov      x19, x0
020f10b8: f6c30591 add      x22, sp, #0x170
020f10bc: c8000037 tbnz     w8, #0, #0x20f10d4
020f10c0: 408901d0 adrp     x0, #0x521b000
020f10c4: 00e842f9 ldr      x0, [x0, #0x5d0]
020f10c8: 8e00bb97 bl       #0xfb1300
020f10cc: 28008052 mov      w8, #1
020f10d0: e81a1539 strb     w8, [x23, #0x546]
020f10d4: 00e4006f movi     v0.2d, #0000000000000000
020f10d8: ff3301f9 str      xzr, [sp, #0x260]
020f10dc: fff300f9 str      xzr, [sp, #0x1e0]
020f10e0: c08206ad stp      q0, q0, [x22, #0xd0]
020f10e4: c08205ad stp      q0, q0, [x22, #0xb0]
020f10e8: c08204ad stp      q0, q0, [x22, #0x90]
020f10ec: c022803d str      q0, [x22, #0x80]
020f10f0: c08202ad stp      q0, q0, [x22, #0x50]
020f10f4: c08201ad stp      q0, q0, [x22, #0x30]
020f10f8: c08200ad stp      q0, q0, [x22, #0x10]
020f10fc: c002803d str      q0, [x22]
020f1100: 602640f9 ldr      x0, [x19, #0x48]
020f1104: 800f00b4 cbz      x0, #0x20f12f4
020f1108: 61008052 mov      w1, #3
020f110c: e2031faa mov      x2, xzr
020f1110: 5da6fd97 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
020f1114: e803002a mov      w8, w0
020f1118: e0031faa mov      x0, xzr
020f111c: e80d0036 tbz      w8, #0, #0x20f12d8
020f1120: 588901d0 adrp     x24, #0x521b000
020f1124: 18eb42f9 ldr      x24, [x24, #0x5d0]
020f1128: 000340f9 ldr      x0, [x24]
020f112c: 08e040b9 ldr      w8, [x0, #0xe0]
020f1130: 48000035 cbnz     w8, #0x20f1138
020f1134: b400bb97 bl       #0xfb1404
020f1138: 36a401d0 adrp     x22, #0x5577000
020f113c: c8f67f39 ldrb     w8, [x22, #0xffd]
020f1140: c8000035 cbnz     w8, #0x20f1158
020f1144: 408901d0 adrp     x0, #0x521b000
020f1148: 00e842f9 ldr      x0, [x0, #0x5d0]
020f114c: 6d00bb97 bl       #0xfb1300
020f1150: 28008052 mov      w8, #1
020f1154: c8f63f39 strb     w8, [x22, #0xffd]
020f1158: 170340f9 ldr      x23, [x24]
020f115c: e8e240b9 ldr      w8, [x23, #0xe0]
020f1160: 88000035 cbnz     w8, #0x20f1170
020f1164: e00317aa mov      x0, x23
020f1168: a700bb97 bl       #0xfb1404
020f116c: 170340f9 ldr      x23, [x24]
020f1170: e15e40f9 ldr      x1, [x23, #0xb8]
020f1174: e0c30791 add      x0, sp, #0x1f0
020f1178: 020f8052 mov      w2, #0x78
020f117c: 6546af97 bl       #0xcc2b10
020f1180: f6031f2a mov      w22, wzr
020f1184: f9031f2a mov      w25, wzr
020f1188: e8e240b9 ldr      w8, [x23, #0xe0]
020f118c: 68000035 cbnz     w8, #0x20f1198
020f1190: e00317aa mov      x0, x23
020f1194: 9c00bb97 bl       #0xfb1404
020f1198: 880240b9 ldr      w8, [x20]
020f119c: df02086b cmp      w22, w8
020f11a0: 2a050054 b.ge     #0x20f1244
020f11a4: 000340f9 ldr      x0, [x24]
020f11a8: 08e040b9 ldr      w8, [x0, #0xe0]
020f11ac: 48000035 cbnz     w8, #0x20f11b4
020f11b0: 9500bb97 bl       #0xfb1404
020f11b4: e00314aa mov      x0, x20
020f11b8: e103162a mov      w1, w22
020f11bc: e2031faa mov      x2, xzr
020f11c0: c319ca97 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
020f11c4: a00300b4 cbz      x0, #0x20f1238
020f11c8: e1031f2a mov      w1, wzr
020f11cc: e2031faa mov      x2, xzr
020f11d0: f70300aa mov      x23, x0
020f11d4: b26a2794 bl       #0x2acbc9c ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$CanReceiveJelly
020f11d8: 3903002a orr      w25, w25, w0
020f11dc: e00317aa mov      x0, x23
020f11e0: 55010036 tbz      w21, #0, #0x20f1208
020f11e4: e1031faa mov      x1, xzr
020f11e8: 4f612794 bl       #0x2ac9724 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$IsNormalCell
020f11ec: 60020036 tbz      w0, #0, #0x20f1238
020f11f0: e00317aa mov      x0, x23
020f11f4: e1031f2a mov      w1, wzr
020f11f8: e2031faa mov      x2, xzr
020f11fc: e86a2794 bl       #0x2acbd9c ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$HasJellySpreadBlockingItem
020f1200: c0000036 tbz      w0, #0, #0x20f1218
020f1204: 0d000014 b        #0x20f1238
020f1208: e1031f2a mov      w1, wzr
020f120c: e2031faa mov      x2, xzr
020f1210: 5e6b2794 bl       #0x2acbf88 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$CanSpreadJelly
020f1214: 20010036 tbz      w0, #0, #0x20f1238
020f1218: 000340f9 ldr      x0, [x24]
020f121c: 08e040b9 ldr      w8, [x0, #0xe0]
020f1220: 48000035 cbnz     w8, #0x20f1228
020f1224: 7800bb97 bl       #0xfb1404
020f1228: e0c30791 add      x0, sp, #0x1f0
020f122c: e10317aa mov      x1, x23
020f1230: e2031faa mov      x2, xzr
020f1234: 8a1aca97 bl       #0x1377c5c ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$Add
020f1238: 170340f9 ldr      x23, [x24]
020f123c: d6060011 add      w22, w22, #1
020f1240: d2ffff17 b        #0x20f1188
020f1244: 99040036 tbz      w25, #0, #0x20f12d4
020f1248: 000340f9 ldr      x0, [x24]
020f124c: 08e040b9 ldr      w8, [x0, #0xe0]
020f1250: 48000035 cbnz     w8, #0x20f1258
020f1254: 6c00bb97 bl       #0xfb1404
020f1258: e8f341b9 ldr      w8, [sp, #0x1f0]
020f125c: 1f050071 cmp      w8, #1
020f1260: ab030054 b.lt     #0x20f12d4
020f1264: 731e40f9 ldr      x19, [x19, #0x38]
020f1268: e0e30391 add      x0, sp, #0xf8
020f126c: e1c30791 add      x1, sp, #0x1f0
020f1270: 020f8052 mov      w2, #0x78
020f1274: d742af97 bl       #0xcc1dd0
020f1278: f30300b4 cbz      x19, #0x20f12f4
020f127c: e0230091 add      x0, sp, #8
020f1280: e1e30391 add      x1, sp, #0xf8
020f1284: 020f8052 mov      w2, #0x78
020f1288: d242af97 bl       #0xcc1dd0
020f128c: e8030291 add      x8, sp, #0x80
020f1290: e1230091 add      x1, sp, #8
020f1294: e00313aa mov      x0, x19
020f1298: e2031faa mov      x2, xzr
020f129c: 68ff2494 bl       #0x2a3103c ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleCells
020f12a0: e0c30591 add      x0, sp, #0x170
020f12a4: e1030291 add      x1, sp, #0x80
020f12a8: 020f8052 mov      w2, #0x78
020f12ac: c942af97 bl       #0xcc1dd0
020f12b0: 000340f9 ldr      x0, [x24]
020f12b4: 08e040b9 ldr      w8, [x0, #0xe0]
020f12b8: 48000035 cbnz     w8, #0x20f12c0
020f12bc: 5200bb97 bl       #0xfb1404
020f12c0: e0c30591 add      x0, sp, #0x170
020f12c4: e1031f2a mov      w1, wzr
020f12c8: e2031faa mov      x2, xzr
020f12cc: 8019ca97 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
020f12d0: 02000014 b        #0x20f12d8
020f12d4: e0031faa mov      x0, xzr
020f12d8: ffc30991 add      sp, sp, #0x270
020f12dc: f37b44a9 ldp      x19, x30, [sp, #0x40]
020f12e0: f55343a9 ldp      x21, x20, [sp, #0x30]
020f12e4: f75b42a9 ldp      x23, x22, [sp, #0x20]
020f12e8: f96341a9 ldp      x25, x24, [sp, #0x10]
020f12ec: fc0745f8 ldr      x28, [sp], #0x50
020f12f0: c0035fd6 ret      
020f12f4: 4d00bb97 bl       #0xfb1428
