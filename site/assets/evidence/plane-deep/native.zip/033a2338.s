# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$ArrangeScaleDown
# Linear span to next metadata entry; not a complete CFG.
033a2338: ffc301d1 sub      sp, sp, #0x70
033a233c: ee0b00fd str      d14, [sp, #0x10]
033a2340: ed33026d stp      d13, d12, [sp, #0x20]
033a2344: eb2b036d stp      d11, d10, [sp, #0x30]
033a2348: e923046d stp      d9, d8, [sp, #0x40]
033a234c: f55305a9 stp      x21, x20, [sp, #0x50]
033a2350: f37b06a9 stp      x19, x30, [sp, #0x60]
033a2354: 340f0190 adrp     x20, #0x5586000
033a2358: 88126739 ldrb     w8, [x20, #0x9c4]
033a235c: 081ca04e mov      v8.16b, v0.16b
033a2360: f30300aa mov      x19, x0
033a2364: c8000037 tbnz     w8, #0, #0x33a237c
033a2368: 40f200b0 adrp     x0, #0x51eb000
033a236c: 009c40f9 ldr      x0, [x0, #0x138]
033a2370: e43b7097 bl       #0xfb1300
033a2374: 28008052 mov      w8, #1
033a2378: 88122739 strb     w8, [x20, #0x9c4]
033a237c: 0821201e fcmp     s8, #0.0
033a2380: 45000054 b.pl     #0x33a2388
033a2384: 7f8600b9 str      wzr, [x19, #0x84]
033a2388: b50e0190 adrp     x21, #0x5576000
033a238c: 742e40f9 ldr      x20, [x19, #0x58]
033a2390: a8a27c39 ldrb     w8, [x21, #0xf28]
033a2394: 697240bd ldr      s9, [x19, #0x70]
033a2398: c8000035 cbnz     w8, #0x33a23b0
033a239c: 40f400b0 adrp     x0, #0x522b000
033a23a0: 00ac43f9 ldr      x0, [x0, #0x758]
033a23a4: d73b7097 bl       #0xfb1300
033a23a8: 28008052 mov      w8, #1
033a23ac: a8a23c39 strb     w8, [x21, #0xf28]
033a23b0: 00102e1e fmov     s0, #1.00000000
033a23b4: 0821201e fcmp     s8, #0.0
033a23b8: 0159201e fmin     s1, s8, s0
033a23bc: e003271e fmov     s0, wzr
033a23c0: 215c201e fcsel    s1, s1, s0, pl
033a23c4: 140f00b4 cbz      x20, #0x33a25a4
033a23c8: 55f400b0 adrp     x21, #0x522b000
033a23cc: b5ae43f9 ldr      x21, [x21, #0x758]
033a23d0: 2048201e fmax     s0, s1, s0
033a23d4: 07102f1e fmov     s7, #1.50000000
033a23d8: e00314aa mov      x0, x20
033a23dc: a80240f9 ldr      x8, [x21]
033a23e0: e1031faa mov      x1, xzr
033a23e4: 085d40f9 ldr      x8, [x8, #0xb8]
033a23e8: 018d412d ldp      s1, s3, [x8, #0xc]
033a23ec: 0291412d ldp      s2, s4, [x8, #0xc]
033a23f0: 051540bd ldr      s5, [x8, #0x14]
033a23f4: 061540bd ldr      s6, [x8, #0x14]
033a23f8: 2109211e fmul     s1, s9, s1
033a23fc: 2309231e fmul     s3, s9, s3
033a2400: 2509251e fmul     s5, s9, s5
033a2404: 4208271e fmul     s2, s2, s7
033a2408: 8408271e fmul     s4, s4, s7
033a240c: c608271e fmul     s6, s6, s7
033a2410: 4238211e fsub     s2, s2, s1
033a2414: 8438231e fsub     s4, s4, s3
033a2418: c638251e fsub     s6, s6, s5
033a241c: 0208221e fmul     s2, s0, s2
033a2420: 0408241e fmul     s4, s0, s4
033a2424: 0608261e fmul     s6, s0, s6
033a2428: 2028221e fadd     s0, s1, s2
033a242c: 6128241e fadd     s1, s3, s4
033a2430: a228261e fadd     s2, s5, s6
033a2434: fc9f2594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
033a2438: b40e0190 adrp     x20, #0x5576000
033a243c: 6a4243fc ldur     d10, [x19, #0x34]
033a2440: 88b27c39 ldrb     w8, [x20, #0xf2c]
033a2444: 6b3e40bd ldr      s11, [x19, #0x3c]
033a2448: c8000035 cbnz     w8, #0x33a2460
033a244c: 40f400b0 adrp     x0, #0x522b000
033a2450: 00ac43f9 ldr      x0, [x0, #0x758]
033a2454: ab3b7097 bl       #0xfb1300
033a2458: 28008052 mov      w8, #1
033a245c: 88b23c39 strb     w8, [x20, #0xf2c]
033a2460: a80240f9 ldr      x8, [x21]
033a2464: d40e01f0 adrp     x20, #0x557d000
033a2468: 89ba5f39 ldrb     w9, [x20, #0x7ee]
033a246c: 085d40f9 ldr      x8, [x8, #0xb8]
033a2470: 030140fd ldr      d3, [x8]
033a2474: 090940bd ldr      s9, [x8, #8]
033a2478: 09010035 cbnz     w9, #0x33a2498
033a247c: e0f200d0 adrp     x0, #0x5200000
033a2480: 008c46f9 ldr      x0, [x0, #0xd18]
033a2484: e303803d str      q3, [sp]
033a2488: 9e3b7097 bl       #0xfb1300
033a248c: e303c03d ldr      q3, [sp]
033a2490: 28008052 mov      w8, #1
033a2494: 88ba1f39 strb     w8, [x20, #0x7ee]
033a2498: 6cd4aa0e fsub     v12.2s, v3.2s, v10.2s
033a249c: 54f200b0 adrp     x20, #0x51eb000
033a24a0: 2d392b1e fsub     s13, s9, s11
033a24a4: 80dd2c2e fmul     v0.2s, v12.2s, v12.2s
033a24a8: 949e40f9 ldr      x20, [x20, #0x138]
033a24ac: 00d8307e faddp    s0, v0.2s
033a24b0: a1092d1e fmul     s1, s13, s13
033a24b4: 2e28201e fadd     s14, s1, s0
033a24b8: c821201e fcmp     s14, #0.0
033a24bc: 20030054 b.eq     #0x33a2520
033a24c0: 285600b0 adrp     x8, #0x3e67000
033a24c4: 00d547bd ldr      s0, [x8, #0x7d4]
033a24c8: 0229201e fadd     s2, s8, s0
033a24cc: 4820201e fcmp     s2, #0.0
033a24d0: 8b000054 b.lt     #0x33a24e0
033a24d4: 4008221e fmul     s0, s2, s2
033a24d8: c021201e fcmp     s14, s0
033a24dc: 29020054 b.ls     #0x33a2520
033a24e0: e8f200d0 adrp     x8, #0x5200000
033a24e4: 088d46f9 ldr      x8, [x8, #0xd18]
033a24e8: 000140f9 ldr      x0, [x8]
033a24ec: 08e040b9 ldr      w8, [x0, #0xe0]
033a24f0: 88000035 cbnz     w8, #0x33a2500
033a24f4: e203803d str      q2, [sp]
033a24f8: c33b7097 bl       #0xfb1404
033a24fc: e203c03d ldr      q2, [sp]
033a2500: c0c1211e fsqrt    s0, s14
033a2504: 0104040e dup      v1.2s, v0.s[0]
033a2508: a019201e fdiv     s0, s13, s0
033a250c: 81fd212e fdiv     v1.2s, v12.2s, v1.2s
033a2510: 4008201e fmul     s0, s2, s0
033a2514: 2190820f fmul     v1.2s, v1.2s, v2.s[0]
033a2518: 43d5210e fadd     v3.2s, v10.2s, v1.2s
033a251c: 6929201e fadd     s9, s11, s0
033a2520: 800240f9 ldr      x0, [x20]
033a2524: 08e040b9 ldr      w8, [x0, #0xe0]
033a2528: a8000035 cbnz     w8, #0x33a253c
033a252c: e303803d str      q3, [sp]
033a2530: b53b7097 bl       #0xfb1404
033a2534: e303c03d ldr      q3, [sp]
033a2538: 800240f9 ldr      x0, [x20]
033a253c: 085c40f9 ldr      x8, [x0, #0xb8]
033a2540: 61040c5e mov      s1, v3.s[1]
033a2544: 0009402d ldp      s0, s2, [x8]
033a2548: 682a40f9 ldr      x8, [x19, #0x50]
033a254c: 6020201e fcmp     s3, s0
033a2550: 684c201e fcsel    s8, s3, s0, mi
033a2554: 2020221e fcmp     s1, s2
033a2558: 2acc221e fcsel    s10, s1, s2, gt
033a255c: 480200b4 cbz      x8, #0x33a25a4
033a2560: 004140f9 ldr      x0, [x8, #0x80]
033a2564: 000200b4 cbz      x0, #0x33a25a4
033a2568: e1031faa mov      x1, xzr
033a256c: 0f822594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
033a2570: a00100b4 cbz      x0, #0x33a25a4
033a2574: 001da84e mov      v0.16b, v8.16b
033a2578: 411daa4e mov      v1.16b, v10.16b
033a257c: 221da94e mov      v2.16b, v9.16b
033a2580: f37b46a9 ldp      x19, x30, [sp, #0x60]
033a2584: f55345a9 ldp      x21, x20, [sp, #0x50]
033a2588: e923446d ldp      d9, d8, [sp, #0x40]
033a258c: eb2b436d ldp      d11, d10, [sp, #0x30]
033a2590: ed33426d ldp      d13, d12, [sp, #0x20]
033a2594: ee0b40fd ldr      d14, [sp, #0x10]
033a2598: e1031faa mov      x1, xzr
033a259c: ffc30191 add      sp, sp, #0x70
033a25a0: 4b9e2514 b        #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
033a25a4: a13b7097 bl       #0xfb1428
