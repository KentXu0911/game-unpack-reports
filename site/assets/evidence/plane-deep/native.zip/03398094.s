# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_SwipeStartFlyStateId
# Linear span to next metadata entry; not a complete CFG.
03398094: f40f1ef8 str      x20, [sp, #-0x20]!
03398098: f37b01a9 stp      x19, x30, [sp, #0x10]
0339809c: 740f01d0 adrp     x20, #0x5586000
033980a0: f3f10090 adrp     x19, #0x51d4000
033980a4: 885a6639 ldrb     w8, [x20, #0x996]
033980a8: 73da41f9 ldr      x19, [x19, #0x3b0]
033980ac: c8000037 tbnz     w8, #0, #0x33980c4
033980b0: e0f10090 adrp     x0, #0x51d4000
033980b4: 00d841f9 ldr      x0, [x0, #0x3b0]
033980b8: 92647097 bl       #0xfb1300
033980bc: 28008052 mov      w8, #1
033980c0: 885a2639 strb     w8, [x20, #0x996]
033980c4: 600240f9 ldr      x0, [x19]
033980c8: 08e040b9 ldr      w8, [x0, #0xe0]
033980cc: 68000035 cbnz     w8, #0x33980d8
033980d0: cd647097 bl       #0xfb1404
033980d4: 600240f9 ldr      x0, [x19]
033980d8: 085c40f9 ldr      x8, [x0, #0xb8]
033980dc: f37b41a9 ldp      x19, x30, [sp, #0x10]
033980e0: 000940b9 ldr      w0, [x8, #8]
033980e4: f40742f8 ldr      x20, [sp], #0x20
033980e8: c0035fd6 ret      
