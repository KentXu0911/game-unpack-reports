# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy.<ExplodeNeighbors>d__13$$MoveNext
# Linear span to next metadata entry; not a complete CFG.
033a3218: e923b96d stp      d9, d8, [sp, #-0x70]!
033a321c: fc6f01a9 stp      x28, x27, [sp, #0x10]
033a3220: fa6702a9 stp      x26, x25, [sp, #0x20]
033a3224: f85f03a9 stp      x24, x23, [sp, #0x30]
033a3228: f65704a9 stp      x22, x21, [sp, #0x40]
033a322c: f44f05a9 stp      x20, x19, [sp, #0x50]
033a3230: fd7b06a9 stp      x29, x30, [sp, #0x60]
033a3234: ffc308d1 sub      sp, sp, #0x230
033a3238: 140f01f0 adrp     x20, #0x5586000
033a323c: 883e6739 ldrb     w8, [x20, #0x9cf]
033a3240: f30300aa mov      x19, x0
033a3244: a8020037 tbnz     w8, #0, #0x33a3298
033a3248: e0f20090 adrp     x0, #0x51ff000
033a324c: 007447f9 ldr      x0, [x0, #0xee8]
033a3250: 2c387097 bl       #0xfb1300
033a3254: 60ef00f0 adrp     x0, #0x5192000
033a3258: 006846f9 ldr      x0, [x0, #0xcd0]
033a325c: 29387097 bl       #0xfb1300
033a3260: a0f000b0 adrp     x0, #0x51b8000
033a3264: 002840f9 ldr      x0, [x0, #0x50]
033a3268: 26387097 bl       #0xfb1300
033a326c: 80f000d0 adrp     x0, #0x51b5000
033a3270: 002c40f9 ldr      x0, [x0, #0x58]
033a3274: 23387097 bl       #0xfb1300
033a3278: e0ef00d0 adrp     x0, #0x51a1000
033a327c: 00ac45f9 ldr      x0, [x0, #0xb58]
033a3280: 20387097 bl       #0xfb1300
033a3284: 40f200f0 adrp     x0, #0x51ee000
033a3288: 006842f9 ldr      x0, [x0, #0x4d0]
033a328c: 1d387097 bl       #0xfb1300
033a3290: 28008052 mov      w8, #1
033a3294: 883e2739 strb     w8, [x20, #0x9cf]
033a3298: 681240b9 ldr      w8, [x19, #0x10]
033a329c: 1f050071 cmp      w8, #1
033a32a0: 80140054 b.eq     #0x33a3530
033a32a4: c8340035 cbnz     w8, #0x33a393c
033a32a8: f4f20090 adrp     x20, #0x51ff000
033a32ac: 947647f9 ldr      x20, [x20, #0xee8]
033a32b0: 08008012 mov      w8, #-1
033a32b4: 681200b9 str      w8, [x19, #0x10]
033a32b8: 800240f9 ldr      x0, [x20]
033a32bc: 08e040b9 ldr      w8, [x0, #0xe0]
033a32c0: 68000035 cbnz     w8, #0x33a32cc
033a32c4: 50387097 bl       #0xfb1404
033a32c8: 800240f9 ldr      x0, [x20]
033a32cc: 085c40f9 ldr      x8, [x0, #0xb8]
033a32d0: f40313aa mov      x20, x19
033a32d4: 010540f9 ldr      x1, [x8, #8]
033a32d8: 810e07f8 str      x1, [x20, #0x70]!
033a32dc: e00314aa mov      x0, x20
033a32e0: f3377097 bl       #0xfb12ac
033a32e4: 880240f9 ldr      x8, [x20]
033a32e8: e83300b4 cbz      x8, #0x33a3964
033a32ec: 69ef00f0 adrp     x9, #0x5192000
033a32f0: 296946f9 ldr      x9, [x9, #0xcd0]
033a32f4: 011940b9 ldr      w1, [x8, #0x18]
033a32f8: 200140f9 ldr      x0, [x9]
033a32fc: 1d387097 bl       #0xfb1370
033a3300: f50313aa mov      x21, x19
033a3304: a08e07f8 str      x0, [x21, #0x78]!
033a3308: e10300aa mov      x1, x0
033a330c: e00315aa mov      x0, x21
033a3310: e7377097 bl       #0xfb12ac
033a3314: a8825ff8 ldur     x8, [x21, #-8]
033a3318: 683200b4 cbz      x8, #0x33a3964
033a331c: 5af200f0 adrp     x26, #0x51ee000
033a3320: 5a6b42f9 ldr      x26, [x26, #0x4d0]
033a3324: f8031faa mov      x24, xzr
033a3328: fb031faa mov      x27, xzr
033a332c: f7031faa mov      x23, xzr
033a3330: 7ca20091 add      x28, x19, #0x28
033a3334: 091940b9 ldr      w9, [x8, #0x18]
033a3338: 1fc329eb cmp      x24, w9, sxtw
033a333c: ca260054 b.ge     #0x33a3814
033a3340: 6a1240f9 ldr      x10, [x19, #0x20]
033a3344: 0a3100b4 cbz      x10, #0x33a3964
033a3348: 1f0309eb cmp      x24, x9
033a334c: e2300054 b.hs     #0x33a3968
033a3350: 401140f9 ldr      x0, [x10, #0x20]
033a3354: 803000b4 cbz      x0, #0x33a3964
033a3358: 0809188b add      x8, x8, x24, lsl #2
033a335c: 012140b9 ldr      w1, [x8, #0x20]
033a3360: e2031faa mov      x2, xzr
033a3364: 7454e697 bl       #0x2d38534 ; Royal.Scenes.Game.Mechanics.Board.Grid.CellNeighbors$$Get
033a3368: 1f0000f1 cmp      x0, #0
033a336c: 7b03809a csel     x27, x27, x0, eq
033a3370: 800d00b4 cbz      x0, #0x33a3520
033a3374: 9b2f00b4 cbz      x27, #0x33a3964
033a3378: 7d5b40f9 ldr      x29, [x27, #0xb0]
033a337c: bf0300f1 cmp      x29, #0
033a3380: f6029d9a csel     x22, x23, x29, eq
033a3384: fd0c00b4 cbz      x29, #0x33a3520
033a3388: 881b40f9 ldr      x8, [x28, #0x30]
033a338c: 818340ad ldp      q1, q0, [x28, #0x10]
033a3390: 8203c03d ldr      q2, [x28]
033a3394: e81301f9 str      x8, [sp, #0x220]
033a3398: e10310ad stp      q1, q0, [sp, #0x200]
033a339c: e27f803d str      q2, [sp, #0x1f0]
033a33a0: 362e00b4 cbz      x22, #0x33a3964
033a33a4: e1834fad ldp      q1, q0, [sp, #0x1f0]
033a33a8: e287c03d ldr      q2, [sp, #0x210]
033a33ac: e81341f9 ldr      x8, [sp, #0x220]
033a33b0: e1c30691 add      x1, sp, #0x1b0
033a33b4: e00316aa mov      x0, x22
033a33b8: e2031faa mov      x2, xzr
033a33bc: e1830dad stp      q1, q0, [sp, #0x1b0]
033a33c0: e277803d str      q2, [sp, #0x1d0]
033a33c4: e8f300f9 str      x8, [sp, #0x1e0]
033a33c8: 0eb1dc97 bl       #0x2acf800 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$AddIncomingExploder
033a33cc: 800200b4 cbz      x0, #0x33a341c
033a33d0: 080040f9 ldr      x8, [x0]
033a33d4: aaf000b0 adrp     x10, #0x51b8000
033a33d8: f70300aa mov      x23, x0
033a33dc: 09554279 ldrh     w9, [x8, #0x12a]
033a33e0: 4a2940f9 ldr      x10, [x10, #0x50]
033a33e4: 410140f9 ldr      x1, [x10]
033a33e8: 290100b4 cbz      x9, #0x33a340c
033a33ec: 0a5940f9 ldr      x10, [x8, #0xb0]
033a33f0: 4a210091 add      x10, x10, #8
033a33f4: 4b815ff8 ldur     x11, [x10, #-8]
033a33f8: 7f0101eb cmp      x11, x1
033a33fc: 40010054 b.eq     #0x33a3424
033a3400: 290500f1 subs     x9, x9, #1
033a3404: 4a410091 add      x10, x10, #0x10
033a3408: 61ffff54 b.ne     #0x33a33f4
033a340c: 82018052 mov      w2, #0xc
033a3410: e00317aa mov      x0, x23
033a3414: b0776f97 bl       #0xf812d4
033a3418: 07000014 b        #0x33a3434
033a341c: f7031daa mov      x23, x29
033a3420: 40000014 b        #0x33a3520
033a3424: 490140b9 ldr      w9, [x10]
033a3428: 29310011 add      w9, w9, #0xc
033a342c: 08d1298b add      x8, x8, w9, sxtw #4
033a3430: 00e10491 add      x0, x8, #0x138
033a3434: 080440a9 ldp      x8, x1, [x0]
033a3438: e00317aa mov      x0, x23
033a343c: 00013fd6 blr      x8
033a3440: 00020036 tbz      w0, #0, #0x33a3480
033a3444: b90240f9 ldr      x25, [x21]
033a3448: f92800b4 cbz      x25, #0x33a3964
033a344c: 280340f9 ldr      x8, [x25]
033a3450: e00317aa mov      x0, x23
033a3454: 012140f9 ldr      x1, [x8, #0x40]
033a3458: ec377097 bl       #0xfb1408
033a345c: 802800b4 cbz      x0, #0x33a396c
033a3460: 281b40b9 ldr      w8, [x25, #0x18]
033a3464: 1f0308eb cmp      x24, x8
033a3468: 02280054 b.hs     #0x33a3968
033a346c: 200f188b add      x0, x25, x24, lsl #3
033a3470: 170c02f8 str      x23, [x0, #0x20]!
033a3474: e10317aa mov      x1, x23
033a3478: 8d377097 bl       #0xfb12ac
033a347c: 28000014 b        #0x33a351c
033a3480: 881b40f9 ldr      x8, [x28, #0x30]
033a3484: 818340ad ldp      q1, q0, [x28, #0x10]
033a3488: 8203c03d ldr      q2, [x28]
033a348c: aaf000b0 adrp     x10, #0x51b8000
033a3490: e8d300f9 str      x8, [sp, #0x1a0]
033a3494: e1030cad stp      q1, q0, [sp, #0x180]
033a3498: e25f803d str      q2, [sp, #0x170]
033a349c: e80240f9 ldr      x8, [x23]
033a34a0: 09554279 ldrh     w9, [x8, #0x12a]
033a34a4: 4a2940f9 ldr      x10, [x10, #0x50]
033a34a8: 410140f9 ldr      x1, [x10]
033a34ac: 290100b4 cbz      x9, #0x33a34d0
033a34b0: 0a5940f9 ldr      x10, [x8, #0xb0]
033a34b4: 4a210091 add      x10, x10, #8
033a34b8: 4b815ff8 ldur     x11, [x10, #-8]
033a34bc: 7f0101eb cmp      x11, x1
033a34c0: 00010054 b.eq     #0x33a34e0
033a34c4: 290500f1 subs     x9, x9, #1
033a34c8: 4a410091 add      x10, x10, #0x10
033a34cc: 61ffff54 b.ne     #0x33a34b8
033a34d0: e2008052 mov      w2, #7
033a34d4: e00317aa mov      x0, x23
033a34d8: 7f776f97 bl       #0xf812d4
033a34dc: 05000014 b        #0x33a34f0
033a34e0: 490140b9 ldr      w9, [x10]
033a34e4: 291d0011 add      w9, w9, #7
033a34e8: 08d1298b add      x8, x8, w9, sxtw #4
033a34ec: 00e10491 add      x0, x8, #0x138
033a34f0: e08b4bad ldp      q0, q2, [sp, #0x170]
033a34f4: e167c03d ldr      q1, [sp, #0x190]
033a34f8: e9d340f9 ldr      x9, [sp, #0x1a0]
033a34fc: 080040f9 ldr      x8, [x0]
033a3500: e08b0fad stp      q0, q2, [sp, #0x1f0]
033a3504: e187803d str      q1, [sp, #0x210]
033a3508: e91301f9 str      x9, [sp, #0x220]
033a350c: 020440f9 ldr      x2, [x0, #8]
033a3510: e1c30791 add      x1, sp, #0x1f0
033a3514: e00317aa mov      x0, x23
033a3518: 00013fd6 blr      x8
033a351c: f70316aa mov      x23, x22
033a3520: 880240f9 ldr      x8, [x20]
033a3524: 18070091 add      x24, x24, #1
033a3528: 68f0ffb5 cbnz     x8, #0x33a3334
033a352c: 0e010014 b        #0x33a3964
033a3530: 683a40f9 ldr      x8, [x19, #0x70]
033a3534: 743240f9 ldr      x20, [x19, #0x60]
033a3538: 09008012 mov      w9, #-1
033a353c: 691200b9 str      w9, [x19, #0x10]
033a3540: 282100b4 cbz      x8, #0x33a3964
033a3544: fd031faa mov      x29, xzr
033a3548: fc031f2a mov      w28, wzr
033a354c: fb031f2a mov      w27, wzr
033a3550: f5031f2a mov      w21, wzr
033a3554: f6031faa mov      x22, xzr
033a3558: 7aa20091 add      x26, x19, #0x28
033a355c: 08102e1e fmov     s8, #1.00000000
033a3560: 09102a1e fmov     s9, #0.25000000
033a3564: 091940b9 ldr      w9, [x8, #0x18]
033a3568: bfc329eb cmp      x29, w9, sxtw
033a356c: 2a170054 b.ge     #0x33a3850
033a3570: 6a1240f9 ldr      x10, [x19, #0x20]
033a3574: 8a1f00b4 cbz      x10, #0x33a3964
033a3578: bf0309eb cmp      x29, x9
033a357c: 621f0054 b.hs     #0x33a3968
033a3580: 401140f9 ldr      x0, [x10, #0x20]
033a3584: 001f00b4 cbz      x0, #0x33a3964
033a3588: 08091d8b add      x8, x8, x29, lsl #2
033a358c: 012140b9 ldr      w1, [x8, #0x20]
033a3590: e2031faa mov      x2, xzr
033a3594: e853e697 bl       #0x2d38534 ; Royal.Scenes.Game.Mechanics.Board.Grid.CellNeighbors$$Get
033a3598: f70300aa mov      x23, x0
033a359c: 600500b4 cbz      x0, #0x33a3648
033a35a0: e00317aa mov      x0, x23
033a35a4: e1031faa mov      x1, xzr
033a35a8: 2e95dc97 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
033a35ac: 681240f9 ldr      x8, [x19, #0x20]
033a35b0: a81d00b4 cbz      x8, #0x33a3964
033a35b4: f80300aa mov      x24, x0
033a35b8: 000d40f9 ldr      x0, [x8, #0x18]
033a35bc: e8c30791 add      x8, sp, #0x1f0
033a35c0: e003271e fmov     s0, wzr
033a35c4: 011da84e mov      v1.16b, v8.16b
033a35c8: e1031faa mov      x1, xzr
033a35cc: cf057f97 bl       #0x1364d08 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.JellyItem.View.JellySpreadData$$CreateOriginSpreading
033a35d0: e07fc03d ldr      q0, [sp, #0x1f0]
033a35d4: e80341f9 ldr      x8, [sp, #0x200]
033a35d8: e1430591 add      x1, sp, #0x150
033a35dc: e2430491 add      x2, sp, #0x110
033a35e0: e057803d str      q0, [sp, #0x150]
033a35e4: e8b300f9 str      x8, [sp, #0x160]
033a35e8: 481b40f9 ldr      x8, [x26, #0x30]
033a35ec: 418340ad ldp      q1, q0, [x26, #0x10]
033a35f0: 4203c03d ldr      q2, [x26]
033a35f4: e00317aa mov      x0, x23
033a35f8: e3031faa mov      x3, xzr
033a35fc: e8a300f9 str      x8, [sp, #0x140]
033a3600: e10309ad stp      q1, q0, [sp, #0x120]
033a3604: e247803d str      q2, [sp, #0x110]
033a3608: e6aadc97 bl       #0x2ace1a0 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$TrySetJellySpreadDataForExploder
033a360c: 481b40f9 ldr      x8, [x26, #0x30]
033a3610: 418340ad ldp      q1, q0, [x26, #0x10]
033a3614: 4203c03d ldr      q2, [x26]
033a3618: e1430391 add      x1, sp, #0xd0
033a361c: e00317aa mov      x0, x23
033a3620: e2031faa mov      x2, xzr
033a3624: e88300f9 str      x8, [sp, #0x100]
033a3628: e10307ad stp      q1, q0, [sp, #0xe0]
033a362c: e237803d str      q2, [sp, #0xd0]
033a3630: 849ddc97 bl       #0x2acac40 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$ExplodeCurrentItem
033a3634: e00317aa mov      x0, x23
033a3638: 201da94e mov      v0.16b, v9.16b
033a363c: e1031faa mov      x1, xzr
033a3640: 9a99dc97 bl       #0x2ac9ca8 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$FreezeFallForDuration
033a3644: 02000014 b        #0x33a364c
033a3648: f8031faa mov      x24, xzr
033a364c: 683e40f9 ldr      x8, [x19, #0x78]
033a3650: a81800b4 cbz      x8, #0x33a3964
033a3654: 091940b9 ldr      w9, [x8, #0x18]
033a3658: bf0309eb cmp      x29, x9
033a365c: 62180054 b.hs     #0x33a3968
033a3660: 080d1d8b add      x8, x8, x29, lsl #3
033a3664: 081140f9 ldr      x8, [x8, #0x20]
033a3668: 1f0100f1 cmp      x8, #0
033a366c: d602889a csel     x22, x22, x8, eq
033a3670: e80500b4 cbz      x8, #0x33a372c
033a3674: 481b40f9 ldr      x8, [x26, #0x30]
033a3678: 418340ad ldp      q1, q0, [x26, #0x10]
033a367c: 4203c03d ldr      q2, [x26]
033a3680: e86300f9 str      x8, [sp, #0xc0]
033a3684: e10305ad stp      q1, q0, [sp, #0xa0]
033a3688: e227803d str      q2, [sp, #0x90]
033a368c: d61600b4 cbz      x22, #0x33a3964
033a3690: e18344ad ldp      q1, q0, [sp, #0x90]
033a3694: e22fc03d ldr      q2, [sp, #0xb0]
033a3698: e86340f9 ldr      x8, [sp, #0xc0]
033a369c: aaf000b0 adrp     x10, #0x51b8000
033a36a0: e18302ad stp      q1, q0, [sp, #0x50]
033a36a4: e21f803d str      q2, [sp, #0x70]
033a36a8: e84300f9 str      x8, [sp, #0x80]
033a36ac: c80240f9 ldr      x8, [x22]
033a36b0: 09554279 ldrh     w9, [x8, #0x12a]
033a36b4: 4a2940f9 ldr      x10, [x10, #0x50]
033a36b8: 410140f9 ldr      x1, [x10]
033a36bc: 290100b4 cbz      x9, #0x33a36e0
033a36c0: 0a5940f9 ldr      x10, [x8, #0xb0]
033a36c4: 4a210091 add      x10, x10, #8
033a36c8: 4b815ff8 ldur     x11, [x10, #-8]
033a36cc: 7f0101eb cmp      x11, x1
033a36d0: 00010054 b.eq     #0x33a36f0
033a36d4: 290500f1 subs     x9, x9, #1
033a36d8: 4a410091 add      x10, x10, #0x10
033a36dc: 61ffff54 b.ne     #0x33a36c8
033a36e0: e2008052 mov      w2, #7
033a36e4: e00316aa mov      x0, x22
033a36e8: fb766f97 bl       #0xf812d4
033a36ec: 05000014 b        #0x33a3700
033a36f0: 490140b9 ldr      w9, [x10]
033a36f4: 291d0011 add      w9, w9, #7
033a36f8: 08d1298b add      x8, x8, w9, sxtw #4
033a36fc: 00e10491 add      x0, x8, #0x138
033a3700: e08b42ad ldp      q0, q2, [sp, #0x50]
033a3704: e11fc03d ldr      q1, [sp, #0x70]
033a3708: e94340f9 ldr      x9, [sp, #0x80]
033a370c: 080040f9 ldr      x8, [x0]
033a3710: e08b0fad stp      q0, q2, [sp, #0x1f0]
033a3714: e187803d str      q1, [sp, #0x210]
033a3718: e91301f9 str      x9, [sp, #0x220]
033a371c: 020440f9 ldr      x2, [x0, #8]
033a3720: e1c30791 add      x1, sp, #0x1f0
033a3724: e00316aa mov      x0, x22
033a3728: 00013fd6 blr      x8
033a372c: 770400b4 cbz      x23, #0x33a37b8
033a3730: e00317aa mov      x0, x23
033a3734: e1031faa mov      x1, xzr
033a3738: ca94dc97 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
033a373c: 200100b4 cbz      x0, #0x33a3760
033a3740: e8ef00d0 adrp     x8, #0x51a1000
033a3744: 090040f9 ldr      x9, [x0]
033a3748: 08ad45f9 ldr      x8, [x8, #0xb58]
033a374c: 2bb14439 ldrb     w11, [x9, #0x12c]
033a3750: 080140f9 ldr      x8, [x8]
033a3754: 0ab14439 ldrb     w10, [x8, #0x12c]
033a3758: 7f010a6b cmp      w11, w10
033a375c: 62000054 b.hs     #0x33a3768
033a3760: e8031faa mov      x8, xzr
033a3764: 06000014 b        #0x33a377c
033a3768: 296540f9 ldr      x9, [x9, #0xc8]
033a376c: 290d0a8b add      x9, x9, x10, lsl #3
033a3770: 29815ff8 ldur     x9, [x9, #-8]
033a3774: 3f0108eb cmp      x9, x8
033a3778: 08009f9a csel     x8, x0, xzr, eq
033a377c: 1f0100f1 cmp      x8, #0
033a3780: e8079f1a cset     w8, ne
033a3784: e00317aa mov      x0, x23
033a3788: e1031faa mov      x1, xzr
033a378c: 9c03082a orr      w28, w28, w8
033a3790: b494dc97 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
033a3794: 200100b4 cbz      x0, #0x33a37b8
033a3798: 88f000d0 adrp     x8, #0x51b5000
033a379c: 090040f9 ldr      x9, [x0]
033a37a0: 082d40f9 ldr      x8, [x8, #0x58]
033a37a4: 2bb14439 ldrb     w11, [x9, #0x12c]
033a37a8: 080140f9 ldr      x8, [x8]
033a37ac: 0ab14439 ldrb     w10, [x8, #0x12c]
033a37b0: 7f010a6b cmp      w11, w10
033a37b4: 42020054 b.hs     #0x33a37fc
033a37b8: e8031faa mov      x8, xzr
033a37bc: 1f0100f1 cmp      x8, #0
033a37c0: f9079f1a cset     w25, ne
033a37c4: 75000036 tbz      w21, #0, #0x33a37d0
033a37c8: 35008052 mov      w21, #1
033a37cc: 07000014 b        #0x33a37e8
033a37d0: b40c00b4 cbz      x20, #0x33a3964
033a37d4: e00314aa mov      x0, x20
033a37d8: e10317aa mov      x1, x23
033a37dc: e20318aa mov      x2, x24
033a37e0: 17feff97 bl       #0x33a303c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ShouldRedirectForIceCube
033a37e4: f503002a mov      w21, w0
033a37e8: 683a40f9 ldr      x8, [x19, #0x70]
033a37ec: 7b03192a orr      w27, w27, w25
033a37f0: bd070091 add      x29, x29, #1
033a37f4: 88ebffb5 cbnz     x8, #0x33a3564
033a37f8: 5b000014 b        #0x33a3964
033a37fc: 296540f9 ldr      x9, [x9, #0xc8]
033a3800: 290d0a8b add      x9, x9, x10, lsl #3
033a3804: 29815ff8 ldur     x9, [x9, #-8]
033a3808: 3f0108eb cmp      x9, x8
033a380c: 08009f9a csel     x8, x0, xzr, eq
033a3810: ebffff17 b        #0x33a37bc
033a3814: 400340f9 ldr      x0, [x26]
033a3818: 00377097 bl       #0xfb1418
033a381c: 400a00b4 cbz      x0, #0x33a3964
033a3820: 28560090 adrp     x8, #0x3e67000
033a3824: 00c144bd ldr      s0, [x8, #0x4c0]
033a3828: e1031faa mov      x1, xzr
033a382c: f40300aa mov      x20, x0
033a3830: 01507f97 bl       #0x1377834 ; Royal.Scenes.Game.Mechanics.Replay.WaitForGameplaySeconds$$.ctor
033a3834: 748e01f8 str      x20, [x19, #0x18]!
033a3838: e00313aa mov      x0, x19
033a383c: e10314aa mov      x1, x20
033a3840: 9b367097 bl       #0xfb12ac
033a3844: 20008052 mov      w0, #1
033a3848: 60821fb8 stur     w0, [x19, #-8]
033a384c: 3d000014 b        #0x33a3940
033a3850: dc000036 tbz      w28, #0, #0x33a3868
033a3854: 940800b4 cbz      x20, #0x33a3964
033a3858: e00314aa mov      x0, x20
033a385c: 45feff97 bl       #0x33a3170 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$TryRedirectForSoilWinCondition
033a3860: 08000012 and      w8, w0, #1
033a3864: 02000014 b        #0x33a386c
033a3868: e8031f2a mov      w8, wzr
033a386c: a9020012 and      w9, w21, #1
033a3870: 0801092a orr      w8, w8, w9
033a3874: c8000034 cbz      w8, #0x33a388c
033a3878: 603640f9 ldr      x0, [x19, #0x68]
033a387c: 400700b4 cbz      x0, #0x33a3964
033a3880: e1031faa mov      x1, xzr
033a3884: 7903cc97 bl       #0x26a4668 ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$ForceTargetChange
033a3888: 06000014 b        #0x33a38a0
033a388c: bb000036 tbz      w27, #0, #0x33a38a0
033a3890: b40600b4 cbz      x20, #0x33a3964
033a3894: e00314aa mov      x0, x20
033a3898: 12feff97 bl       #0x33a30e0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$TryRedirectForPowerCubeWinCondition
033a389c: e0fe0737 tbnz     w0, #0, #0x33a3878
033a38a0: 940e01f0 adrp     x20, #0x5576000
033a38a4: 88ae7c39 ldrb     w8, [x20, #0xf2b]
033a38a8: c8000035 cbnz     w8, #0x33a38c0
033a38ac: 20f300b0 adrp     x0, #0x5208000
033a38b0: 00c041f9 ldr      x0, [x0, #0x380]
033a38b4: 93367097 bl       #0xfb1300
033a38b8: 28008052 mov      w8, #1
033a38bc: 88ae3c39 strb     w8, [x20, #0xf2b]
033a38c0: 28f300b0 adrp     x8, #0x5208000
033a38c4: 08c141f9 ldr      x8, [x8, #0x380]
033a38c8: 080140f9 ldr      x8, [x8]
033a38cc: 085d40f9 ldr      x8, [x8, #0xb8]
033a38d0: 080140f9 ldr      x8, [x8]
033a38d4: 880400b4 cbz      x8, #0x33a3964
033a38d8: 081d40f9 ldr      x8, [x8, #0x38]
033a38dc: 480400b4 cbz      x8, #0x33a3964
033a38e0: 601240f9 ldr      x0, [x19, #0x20]
033a38e4: 000400b4 cbz      x0, #0x33a3964
033a38e8: 130d40f9 ldr      x19, [x8, #0x18]
033a38ec: e1031faa mov      x1, xzr
033a38f0: b29fdc97 bl       #0x2acb7b8 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetViewPosition
033a38f4: 481b40f9 ldr      x8, [x26, #0x30]
033a38f8: 448f40ad ldp      q4, q3, [x26, #0x10]
033a38fc: 4503c03d ldr      q5, [x26]
033a3900: e81301f9 str      x8, [sp, #0x220]
033a3904: e40f10ad stp      q4, q3, [sp, #0x200]
033a3908: e57f803d str      q5, [sp, #0x1f0]
033a390c: d30200b4 cbz      x19, #0x33a3964
033a3910: e48f4fad ldp      q4, q3, [sp, #0x1f0]
033a3914: e587c03d ldr      q5, [sp, #0x210]
033a3918: e81341f9 ldr      x8, [sp, #0x220]
033a391c: e1430091 add      x1, sp, #0x10
033a3920: e00313aa mov      x0, x19
033a3924: e2031f2a mov      w2, wzr
033a3928: e3031faa mov      x3, xzr
033a392c: e48f00ad stp      q4, q3, [sp, #0x10]
033a3930: e50f803d str      q5, [sp, #0x30]
033a3934: e82300f9 str      x8, [sp, #0x40]
033a3938: f1ebc297 bl       #0x245e8fc ; Royal.Player.Context.Data.Session.UserActiveLevelData$$TryCollectMadnessForExploder
033a393c: e0031f2a mov      w0, wzr
033a3940: ffc30891 add      sp, sp, #0x230
033a3944: fd7b46a9 ldp      x29, x30, [sp, #0x60]
033a3948: f44f45a9 ldp      x20, x19, [sp, #0x50]
033a394c: f65744a9 ldp      x22, x21, [sp, #0x40]
033a3950: f85f43a9 ldp      x24, x23, [sp, #0x30]
033a3954: fa6742a9 ldp      x26, x25, [sp, #0x20]
033a3958: fc6f41a9 ldp      x28, x27, [sp, #0x10]
033a395c: e923c76c ldp      d9, d8, [sp], #0x70
033a3960: c0035fd6 ret      
033a3964: b1367097 bl       #0xfb1428
033a3968: b2367097 bl       #0xfb1430
033a396c: b8367097 bl       #0xfb144c
033a3970: e1031faa mov      x1, xzr
033a3974: 9f367097 bl       #0xfb13f0
