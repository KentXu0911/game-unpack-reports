# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$FindSingleTargetForCellExploder
# Linear span to next metadata entry; not a complete CFG.
020f22e8: ff8301d1 sub      sp, sp, #0x60
020f22ec: f42300f9 str      x20, [sp, #0x40]
020f22f0: f37b05a9 stp      x19, x30, [sp, #0x50]
020f22f4: f30301aa mov      x19, x1
020f22f8: e1031f2a mov      w1, wzr
020f22fc: f40300aa mov      x20, x0
020f2300: 56f3ff97 bl       #0x20ef058 ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ClearLists
020f2304: 600a40b9 ldr      w0, [x19, #8]
020f2308: e1031faa mov      x1, xzr
020f230c: c9203194 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
020f2310: 68524039 ldrb     w8, [x19, #0x14]
020f2314: e103002a mov      w1, w0
020f2318: e00314aa mov      x0, x20
020f231c: 02010012 and      w2, w8, #1
020f2320: 49f5ff97 bl       #0x20ef844 ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$FillScores
020f2324: 681a40f9 ldr      x8, [x19, #0x30]
020f2328: 618240ad ldp      q1, q0, [x19, #0x10]
020f232c: 6202c03d ldr      q2, [x19]
020f2330: e1030091 mov      x1, sp
020f2334: e00314aa mov      x0, x20
020f2338: e2031faa mov      x2, xzr
020f233c: e81b00f9 str      x8, [sp, #0x30]
020f2340: e18300ad stp      q1, q0, [sp, #0x10]
020f2344: e203803d str      q2, [sp]
020f2348: b7feff97 bl       #0x20f1e24 ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$FindSingleTargetCellForExploder
020f234c: f37b45a9 ldp      x19, x30, [sp, #0x50]
020f2350: f42340f9 ldr      x20, [sp, #0x40]
020f2354: e00301aa mov      x0, x1
020f2358: ff830191 add      sp, sp, #0x60
020f235c: c0035fd6 ret      
