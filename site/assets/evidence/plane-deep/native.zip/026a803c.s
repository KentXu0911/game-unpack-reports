# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinConditionForVerticalRocket
# Linear span to next metadata entry; not a complete CFG.
026a803c: ffc302d1 sub      sp, sp, #0xb0
026a8040: f75b08a9 stp      x23, x22, [sp, #0x80]
026a8044: f55309a9 stp      x21, x20, [sp, #0x90]
026a8048: f37b0aa9 stp      x19, x30, [sp, #0xa0]
026a804c: f30302aa mov      x19, x2
026a8050: f403012a mov      w20, w1
026a8054: f50300aa mov      x21, x0
026a8058: d3010094 bl       #0x26a87a4 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ShouldCalculateSpecificWinConditions
026a805c: 80030036 tbz      w0, #0, #0x26a80cc
026a8060: a00e40f9 ldr      x0, [x21, #0x18]
026a8064: 400700b4 cbz      x0, #0x26a814c
026a8068: e1031faa mov      x1, xzr
026a806c: e6bb0294 bl       #0x2757004 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_BoardStartY
026a8070: a80e40f9 ldr      x8, [x21, #0x18]
026a8074: c80600b4 cbz      x8, #0x26a814c
026a8078: f603002a mov      w22, w0
026a807c: e00308aa mov      x0, x8
026a8080: e1031faa mov      x1, xzr
026a8084: f1bb0294 bl       #0x2757048 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_BoardEndY
026a8088: df02006b cmp      w22, w0
026a808c: 4c020054 b.gt     #0x26a80d4
026a8090: 681a40f9 ldr      x8, [x19, #0x30]
026a8094: 618240ad ldp      q1, q0, [x19, #0x10]
026a8098: 6202c03d ldr      q2, [x19]
026a809c: e3030191 add      x3, sp, #0x40
026a80a0: e00315aa mov      x0, x21
026a80a4: e103142a mov      w1, w20
026a80a8: e203162a mov      w2, w22
026a80ac: e83b00f9 str      x8, [sp, #0x70]
026a80b0: e18302ad stp      q1, q0, [sp, #0x50]
026a80b4: e213803d str      q2, [sp, #0x40]
026a80b8: cc010094 bl       #0x26a87e8 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddTemporaryIncomingExploder
026a80bc: a80e40f9 ldr      x8, [x21, #0x18]
026a80c0: d6060011 add      w22, w22, #1
026a80c4: c8fdffb5 cbnz     x8, #0x26a807c
026a80c8: 21000014 b        #0x26a814c
026a80cc: f6031f2a mov      w22, wzr
026a80d0: 20000014 b        #0x26a8150
026a80d4: e00315aa mov      x0, x21
026a80d8: fd010094 bl       #0x26a88cc ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinCondition
026a80dc: a80e40f9 ldr      x8, [x21, #0x18]
026a80e0: 680300b4 cbz      x8, #0x26a814c
026a80e4: f603002a mov      w22, w0
026a80e8: e00308aa mov      x0, x8
026a80ec: e1031faa mov      x1, xzr
026a80f0: c5bb0294 bl       #0x2757004 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_BoardStartY
026a80f4: a80e40f9 ldr      x8, [x21, #0x18]
026a80f8: a80200b4 cbz      x8, #0x26a814c
026a80fc: f703002a mov      w23, w0
026a8100: e00308aa mov      x0, x8
026a8104: e1031faa mov      x1, xzr
026a8108: d0bb0294 bl       #0x2757048 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_BoardEndY
026a810c: ff02006b cmp      w23, w0
026a8110: 0c020054 b.gt     #0x26a8150
026a8114: 681a40f9 ldr      x8, [x19, #0x30]
026a8118: 618240ad ldp      q1, q0, [x19, #0x10]
026a811c: 6202c03d ldr      q2, [x19]
026a8120: e3030091 mov      x3, sp
026a8124: e00315aa mov      x0, x21
026a8128: e103142a mov      w1, w20
026a812c: e203172a mov      w2, w23
026a8130: e81b00f9 str      x8, [sp, #0x30]
026a8134: e18300ad stp      q1, q0, [sp, #0x10]
026a8138: e203803d str      q2, [sp]
026a813c: 4d020094 bl       #0x26a8a70 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$RemoveTemporaryIncomingExploder
026a8140: a80e40f9 ldr      x8, [x21, #0x18]
026a8144: f7060011 add      w23, w23, #1
026a8148: c8fdffb5 cbnz     x8, #0x26a8100
026a814c: b724a497 bl       #0xfb1428
026a8150: c0020012 and      w0, w22, #1
026a8154: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
026a8158: f55349a9 ldp      x21, x20, [sp, #0x90]
026a815c: f75b48a9 ldp      x23, x22, [sp, #0x80]
026a8160: ffc30291 add      sp, sp, #0xb0
026a8164: c0035fd6 ret      
