# Royal.Scenes.Game.Mechanics.Items.MagicLanternItem.MagicLanternItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e250f8: f40f1ef8 str      x20, [sp, #-0x20]!
01e250fc: f37b01a9 stp      x19, x30, [sp, #0x10]
01e25100: 08244539 ldrb     w8, [x0, #0x149]
01e25104: f30300aa mov      x19, x0
01e25108: f403012a mov      w20, w1
01e2510c: 68050034 cbz      w8, #0x1e251b8
01e25110: e003142a mov      w0, w20
01e25114: e1031faa mov      x1, xzr
01e25118: 097e5594 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
01e2511c: 9f0a0071 cmp      w20, #2
01e25120: 40000054 b.eq     #0x1e25128
01e25124: e0030036 tbz      w0, #0, #0x1e251a0
01e25128: 680240f9 ldr      x8, [x19]
01e2512c: e00313aa mov      x0, x19
01e25130: 096542f9 ldr      x9, [x8, #0x4c8]
01e25134: 016942f9 ldr      x1, [x8, #0x4d0]
01e25138: 20013fd6 blr      x9
01e2513c: 1f040071 cmp      w0, #1
01e25140: 01030054 b.ne     #0x1e251a0
01e25144: 680240f9 ldr      x8, [x19]
01e25148: e00313aa mov      x0, x19
01e2514c: 09bd41f9 ldr      x9, [x8, #0x378]
01e25150: 01c141f9 ldr      x1, [x8, #0x380]
01e25154: 20013fd6 blr      x9
01e25158: e1031faa mov      x1, xzr
01e2515c: 0b7e5594 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e25160: 680240f9 ldr      x8, [x19]
01e25164: f403002a mov      w20, w0
01e25168: e00313aa mov      x0, x19
01e2516c: 09bd41f9 ldr      x9, [x8, #0x378]
01e25170: 01c141f9 ldr      x1, [x8, #0x380]
01e25174: 20013fd6 blr      x9
01e25178: e1031faa mov      x1, xzr
01e2517c: 037e5594 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e25180: c8aa8a52 mov      w8, #0x5556
01e25184: a8aaaa72 movk     w8, #0x5555, lsl #16
01e25188: 087c289b smull    x8, w0, w8
01e2518c: 09fd7fd3 lsr      x9, x8, #0x3f
01e25190: 08fd60d3 lsr      x8, x8, #0x20
01e25194: 0801090b add      w8, w8, w9
01e25198: 0001140b add      w0, w8, w20
01e2519c: 1b000014 b        #0x1e25208
01e251a0: e00313aa mov      x0, x19
01e251a4: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e251a8: e103142a mov      w1, w20
01e251ac: e2031faa mov      x2, xzr
01e251b0: f40742f8 ldr      x20, [sp], #0x20
01e251b4: b7b25514 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
01e251b8: e003142a mov      w0, w20
01e251bc: e1031faa mov      x1, xzr
01e251c0: df7d5594 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
01e251c4: 00020036 tbz      w0, #0, #0x1e25204
01e251c8: b7feff97 bl       #0x1e24ca4 ; Royal.Scenes.Game.Mechanics.Items.MagicLanternItem.MagicLanternItemModel$$get_ItemHelper
01e251cc: 400200b4 cbz      x0, #0x1e25214
01e251d0: d7fbff97 bl       #0x1e2412c ; Royal.Scenes.Game.Mechanics.Items.MagicLanternItem.MagicLanternItemHelper$$IsThereHittableMagicLanternOnBoard
01e251d4: 80010036 tbz      w0, #0, #0x1e25204
01e251d8: 68264539 ldrb     w8, [x19, #0x149]
01e251dc: a8f9ff35 cbnz     w8, #0x1e25110
01e251e0: 680240f9 ldr      x8, [x19]
01e251e4: e00313aa mov      x0, x19
01e251e8: 09bd41f9 ldr      x9, [x8, #0x378]
01e251ec: 01c141f9 ldr      x1, [x8, #0x380]
01e251f0: 20013fd6 blr      x9
01e251f4: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e251f8: e1031faa mov      x1, xzr
01e251fc: f40742f8 ldr      x20, [sp], #0x20
01e25200: e27d5514 b        #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e25204: e0031f2a mov      w0, wzr
01e25208: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e2520c: f40742f8 ldr      x20, [sp], #0x20
01e25210: c0035fd6 ret      
01e25214: 8530c697 bl       #0xfb1428
