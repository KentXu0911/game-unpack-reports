# Royal.Scenes.Game.Mechanics.Items.PropellerMachineItem.PropellerMachineItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0209a158: f553bea9 stp      x21, x20, [sp, #-0x20]!
0209a15c: f37b01a9 stp      x19, x30, [sp, #0x10]
0209a160: f303012a mov      w19, w1
0209a164: f40300aa mov      x20, x0
0209a168: e003012a mov      w0, w1
0209a16c: e1031faa mov      x1, xzr
0209a170: 0faa4b94 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
0209a174: 80000036 tbz      w0, #0, #0x209a184
0209a178: 00918f52 mov      w0, #0x7c88
0209a17c: 6000a072 movk     w0, #3, lsl #16
0209a180: 12000014 b        #0x209a1c8
0209a184: 803e40f9 ldr      x0, [x20, #0x78]
0209a188: 200300b4 cbz      x0, #0x209a1ec
0209a18c: 956a40b9 ldr      w21, [x20, #0x68]
0209a190: e1031faa mov      x1, xzr
0209a194: c7803294 bl       #0x2d3a4b0 ; Royal.Scenes.Game.Mechanics.Explode.IncomingExploderContainer$$GetIncomingCount
0209a198: a802004b sub      w8, w21, w0
0209a19c: 1f050071 cmp      w8, #1
0209a1a0: a1010054 b.ne     #0x209a1d4
0209a1a4: e003132a mov      w0, w19
0209a1a8: e1031faa mov      x1, xzr
0209a1ac: e4a94b94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
0209a1b0: 08229f52 mov      w8, #0xf910
0209a1b4: 09fd9852 mov      w9, #0xc7e8
0209a1b8: 1f000072 tst      w0, #1
0209a1bc: c800a072 movk     w8, #6, lsl #16
0209a1c0: 2902a072 movk     w9, #0x11, lsl #16
0209a1c4: 2011881a csel     w0, w9, w8, ne
0209a1c8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0209a1cc: f553c2a8 ldp      x21, x20, [sp], #0x20
0209a1d0: c0035fd6 ret      
0209a1d4: e103132a mov      w1, w19
0209a1d8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0209a1dc: e00314aa mov      x0, x20
0209a1e0: e2031faa mov      x2, xzr
0209a1e4: f553c2a8 ldp      x21, x20, [sp], #0x20
0209a1e8: aade4b14 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
0209a1ec: 8f5cbc97 bl       #0xfb1428
