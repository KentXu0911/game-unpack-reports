# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$InitializeCurveVariables
# Linear span to next metadata entry; not a complete CFG.
0339b77c: ff0302d1 sub      sp, sp, #0x80
0339b780: ed33026d stp      d13, d12, [sp, #0x20]
0339b784: eb2b036d stp      d11, d10, [sp, #0x30]
0339b788: e923046d stp      d9, d8, [sp, #0x40]
0339b78c: f62b00f9 str      x22, [sp, #0x50]
0339b790: f55306a9 stp      x21, x20, [sp, #0x60]
0339b794: f37b07a9 stp      x19, x30, [sp, #0x70]
0339b798: 540f01f0 adrp     x20, #0x5586000
0339b79c: 88aa6639 ldrb     w8, [x20, #0x9aa]
0339b7a0: 481ca24e mov      v8.16b, v2.16b
0339b7a4: 291ca14e mov      v9.16b, v1.16b
0339b7a8: 0a1ca04e mov      v10.16b, v0.16b
0339b7ac: f30300aa mov      x19, x0
0339b7b0: e8010037 tbnz     w8, #0, #0x339b7ec
0339b7b4: 80f400d0 adrp     x0, #0x522d000
0339b7b8: 008444f9 ldr      x0, [x0, #0x908]
0339b7bc: d1567097 bl       #0xfb1300
0339b7c0: a0f40090 adrp     x0, #0x522f000
0339b7c4: 000445f9 ldr      x0, [x0, #0xa08]
0339b7c8: ce567097 bl       #0xfb1300
0339b7cc: 80f00090 adrp     x0, #0x51ab000
0339b7d0: 005440f9 ldr      x0, [x0, #0xa8]
0339b7d4: cb567097 bl       #0xfb1300
0339b7d8: e0f100d0 adrp     x0, #0x51d9000
0339b7dc: 00cc42f9 ldr      x0, [x0, #0x598]
0339b7e0: c8567097 bl       #0xfb1300
0339b7e4: 28008052 mov      w8, #1
0339b7e8: 88aa2639 strb     w8, [x20, #0x9aa]
0339b7ec: e00313aa mov      x0, x19
0339b7f0: 401daa4e mov      v0.16b, v10.16b
0339b7f4: 211da94e mov      v1.16b, v9.16b
0339b7f8: 021da84e mov      v2.16b, v8.16b
0339b7fc: 7bf8ff97 bl       #0x33999e8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$InitializeCurveVariables
0339b800: f31b00b4 cbz      x19, #0x339bb7c
0339b804: 68664339 ldrb     w8, [x19, #0xd9]
0339b808: 69624339 ldrb     w9, [x19, #0xd8]
0339b80c: 2a008052 mov      w10, #1
0339b810: e00313aa mov      x0, x19
0339b814: 68160339 strb     w8, [x19, #0xc5]
0339b818: 2901084a eor      w9, w9, w8
0339b81c: 69120339 strb     w9, [x19, #0xc4]
0339b820: 6a6e0339 strb     w10, [x19, #0xdb]
0339b824: d7000094 bl       #0x339bb80 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$ArrangeSorting
0339b828: 606640f9 ldr      x0, [x19, #0xc8]
0339b82c: 801a00b4 cbz      x0, #0x339bb7c
0339b830: 080040f9 ldr      x8, [x0]
0339b834: 09bd41f9 ldr      x9, [x8, #0x378]
0339b838: 01c141f9 ldr      x1, [x8, #0x380]
0339b83c: 20013fd6 blr      x9
0339b840: 1f100071 cmp      w0, #4
0339b844: 606640f9 ldr      x0, [x19, #0xc8]
0339b848: 0090221e fmov     s0, #5.00000000
0339b84c: 0190241e fmov     s1, #10.00000000
0339b850: 200c201e fcsel    s0, s1, s0, eq
0339b854: 60be00bd str      s0, [x19, #0xbc]
0339b858: 201900b4 cbz      x0, #0x339bb7c
0339b85c: e1031faa mov      x1, xzr
0339b860: 80bf0b94 bl       #0x368b660 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$GetSpecialItemView
0339b864: c01800b4 cbz      x0, #0x339bb7c
0339b868: 144040f9 ldr      x20, [x0, #0x80]
0339b86c: 941800b4 cbz      x20, #0x339bb7c
0339b870: e00314aa mov      x0, x20
0339b874: e1031faa mov      x1, xzr
0339b878: 24c42594 bl       #0x3d0c908 ; UnityEngine.SpriteRenderer$$get_color
0339b87c: 685700d0 adrp     x8, #0x3e89000
0339b880: 03254bbd ldr      s3, [x8, #0xb24]
0339b884: e00314aa mov      x0, x20
0339b888: e1031faa mov      x1, xzr
0339b88c: 46c42594 bl       #0x3d0c9a4 ; UnityEngine.SpriteRenderer$$set_color
0339b890: 95f40090 adrp     x21, #0x522b000
0339b894: 68724139 ldrb     w8, [x19, #0x5c]
0339b898: b5ae43f9 ldr      x21, [x21, #0x758]
0339b89c: f60e01b0 adrp     x22, #0x5578000
0339b8a0: a80a0035 cbnz     w8, #0x339b9f4
0339b8a4: 743a40f9 ldr      x20, [x19, #0x70]
0339b8a8: b41600b4 cbz      x20, #0x339bb7c
0339b8ac: aaf40090 adrp     x10, #0x522f000
0339b8b0: 880240f9 ldr      x8, [x20]
0339b8b4: 4a0545f9 ldr      x10, [x10, #0xa08]
0339b8b8: 09554279 ldrh     w9, [x8, #0x12a]
0339b8bc: 410140f9 ldr      x1, [x10]
0339b8c0: 290100b4 cbz      x9, #0x339b8e4
0339b8c4: 0a5940f9 ldr      x10, [x8, #0xb0]
0339b8c8: 4a210091 add      x10, x10, #8
0339b8cc: 4b815ff8 ldur     x11, [x10, #-8]
0339b8d0: 7f0101eb cmp      x11, x1
0339b8d4: 00010054 b.eq     #0x339b8f4
0339b8d8: 290500f1 subs     x9, x9, #1
0339b8dc: 4a410091 add      x10, x10, #0x10
0339b8e0: 61ffff54 b.ne     #0x339b8cc
0339b8e4: 22008052 mov      w2, #1
0339b8e8: e00314aa mov      x0, x20
0339b8ec: 7a966f97 bl       #0xf812d4
0339b8f0: 05000014 b        #0x339b904
0339b8f4: 490140b9 ldr      w9, [x10]
0339b8f8: 29050011 add      w9, w9, #1
0339b8fc: 08d1298b add      x8, x8, w9, sxtw #4
0339b900: 00e10491 add      x0, x8, #0x138
0339b904: 080440a9 ldp      x8, x1, [x0]
0339b908: e00314aa mov      x0, x20
0339b90c: 00013fd6 blr      x8
0339b910: 603640f9 ldr      x0, [x19, #0x68]
0339b914: 401300b4 cbz      x0, #0x339bb7c
0339b918: e1031faa mov      x1, xzr
0339b91c: 081ca04e mov      v8.16b, v0.16b
0339b920: 291ca14e mov      v9.16b, v1.16b
0339b924: 4a1ca24e mov      v10.16b, v2.16b
0339b928: f3b82594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339b92c: f40e0190 adrp     x20, #0x5577000
0339b930: 881a6039 ldrb     w8, [x20, #0x806]
0339b934: 0b1ca04e mov      v11.16b, v0.16b
0339b938: 2c1ca14e mov      v12.16b, v1.16b
0339b93c: 4d1ca24e mov      v13.16b, v2.16b
0339b940: c8000035 cbnz     w8, #0x339b958
0339b944: 20f300b0 adrp     x0, #0x5200000
0339b948: 008c46f9 ldr      x0, [x0, #0xd18]
0339b94c: 6d567097 bl       #0xfb1300
0339b950: 28008052 mov      w8, #1
0339b954: 881a2039 strb     w8, [x20, #0x806]
0339b958: 28f300b0 adrp     x8, #0x5200000
0339b95c: 088d46f9 ldr      x8, [x8, #0xd18]
0339b960: 0b392b1e fsub     s11, s8, s11
0339b964: 29392c1e fsub     s9, s9, s12
0339b968: 48392d1e fsub     s8, s10, s13
0339b96c: 000140f9 ldr      x0, [x8]
0339b970: 08e040b9 ldr      w8, [x0, #0xe0]
0339b974: 48000035 cbnz     w8, #0x339b97c
0339b978: a3567097 bl       #0xfb1404
0339b97c: 60092b1e fmul     s0, s11, s11
0339b980: 2109291e fmul     s1, s9, s9
0339b984: 0209281e fmul     s2, s8, s8
0339b988: 0028211e fadd     s0, s0, s1
0339b98c: 4028201e fadd     s0, s2, s0
0339b990: 00c0211e fsqrt    s0, s0
0339b994: 0110201e fmov     s1, #2.00000000
0339b998: 0020211e fcmp     s0, s1
0339b99c: c8020054 b.hi     #0x339b9f4
0339b9a0: c872a852 mov      w8, #0x43960000
0339b9a4: 682a00b9 str      w8, [x19, #0x28]
0339b9a8: c86e4539 ldrb     w8, [x22, #0x15b]
0339b9ac: c8000035 cbnz     w8, #0x339b9c4
0339b9b0: 80f40090 adrp     x0, #0x522b000
0339b9b4: 00ac43f9 ldr      x0, [x0, #0x758]
0339b9b8: 52567097 bl       #0xfb1300
0339b9bc: 28008052 mov      w8, #1
0339b9c0: c86e0539 strb     w8, [x22, #0x15b]
0339b9c4: a80240f9 ldr      x8, [x21]
0339b9c8: 60c242fc ldur     d0, [x19, #0x2c]
0339b9cc: 613640bd ldr      s1, [x19, #0x34]
0339b9d0: 085d40f9 ldr      x8, [x8, #0xb8]
0339b9d4: 00d4200e fadd     v0.2s, v0.2s, v0.2s
0339b9d8: 2128211e fadd     s1, s1, s1
0339b9dc: 092540f9 ldr      x9, [x8, #0x48]
0339b9e0: 085140b9 ldr      w8, [x8, #0x50]
0339b9e4: 60c202fc stur     d0, [x19, #0x2c]
0339b9e8: 613600bd str      s1, [x19, #0x34]
0339b9ec: 691e00f9 str      x9, [x19, #0x38]
0339b9f0: 684200b9 str      w8, [x19, #0x40]
0339b9f4: 686a4339 ldrb     w8, [x19, #0xda]
0339b9f8: 280b0034 cbz      w8, #0x339bb5c
0339b9fc: e00313aa mov      x0, x19
0339ba00: 08cc4a38 ldrb     w8, [x0, #0xac]!
0339ba04: c80a0034 cbz      w8, #0x339bb5c
0339ba08: e8f100d0 adrp     x8, #0x51d9000
0339ba0c: 08cd42f9 ldr      x8, [x8, #0x598]
0339ba10: 010140f9 ldr      x1, [x8]
0339ba14: abd9dd97 bl       #0x2b120c0 ; System.Nullable<float>$$get_Value
0339ba18: c86e4539 ldrb     w8, [x22, #0x15b]
0339ba1c: 081ca04e mov      v8.16b, v0.16b
0339ba20: c8000035 cbnz     w8, #0x339ba38
0339ba24: 80f40090 adrp     x0, #0x522b000
0339ba28: 00ac43f9 ldr      x0, [x0, #0x758]
0339ba2c: 35567097 bl       #0xfb1300
0339ba30: 28008052 mov      w8, #1
0339ba34: c86e0539 strb     w8, [x22, #0x15b]
0339ba38: a80240f9 ldr      x8, [x21]
0339ba3c: e0031faa mov      x0, xzr
0339ba40: 085d40f9 ldr      x8, [x8, #0xb8]
0339ba44: 0109492d ldp      s1, s2, [x8, #0x48]
0339ba48: 035140bd ldr      s3, [x8, #0x50]
0339ba4c: 8866a852 mov      w8, #0x43340000
0339ba50: 0001271e fmov     s0, w8
0339ba54: 0029201e fadd     s0, s8, s0
0339ba58: c6a70594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339ba5c: d40e01f0 adrp     x20, #0x5576000
0339ba60: 88ba7c39 ldrb     w8, [x20, #0xf2e]
0339ba64: 081ca04e mov      v8.16b, v0.16b
0339ba68: 291ca14e mov      v9.16b, v1.16b
0339ba6c: 4a1ca24e mov      v10.16b, v2.16b
0339ba70: 6b1ca34e mov      v11.16b, v3.16b
0339ba74: c8000035 cbnz     w8, #0x339ba8c
0339ba78: 80f40090 adrp     x0, #0x522b000
0339ba7c: 00ac43f9 ldr      x0, [x0, #0x758]
0339ba80: 20567097 bl       #0xfb1300
0339ba84: 28008052 mov      w8, #1
0339ba88: 88ba3c39 strb     w8, [x20, #0xf2e]
0339ba8c: a80240f9 ldr      x8, [x21]
0339ba90: 001da84e mov      v0.16b, v8.16b
0339ba94: 211da94e mov      v1.16b, v9.16b
0339ba98: 421daa4e mov      v2.16b, v10.16b
0339ba9c: 085d40f9 ldr      x8, [x8, #0xb8]
0339baa0: 631dab4e mov      v3.16b, v11.16b
0339baa4: e0031faa mov      x0, xzr
0339baa8: 0415432d ldp      s4, s5, [x8, #0x18]
0339baac: 062140bd ldr      s6, [x8, #0x20]
0339bab0: 42a50594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339bab4: 603640f9 ldr      x0, [x19, #0x68]
0339bab8: 200600b4 cbz      x0, #0x339bb7c
0339babc: 68560090 adrp     x8, #0x3e67000
0339bac0: 030945bd ldr      s3, [x8, #0x508]
0339bac4: e1031faa mov      x1, xzr
0339bac8: 0808231e fmul     s8, s0, s3
0339bacc: 2908231e fmul     s9, s1, s3
0339bad0: 4a08231e fmul     s10, s2, s3
0339bad4: 88b82594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339bad8: 603640f9 ldr      x0, [x19, #0x68]
0339badc: 0029201e fadd     s0, s8, s0
0339bae0: 2129211e fadd     s1, s9, s1
0339bae4: 4229221e fadd     s2, s10, s2
0339bae8: 60861e2d stp      s0, s1, [x19, #0xf4]
0339baec: 62fe00bd str      s2, [x19, #0xfc]
0339baf0: 600400b4 cbz      x0, #0x339bb7c
0339baf4: 94f400d0 adrp     x20, #0x522d000
0339baf8: 948644f9 ldr      x20, [x20, #0x908]
0339bafc: e1031faa mov      x1, xzr
0339bb00: 7db82594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339bb04: 800240f9 ldr      x0, [x20]
0339bb08: 6cae5e2d ldp      s12, s11, [x19, #0xf4]
0339bb0c: 6afe40bd ldr      s10, [x19, #0xfc]
0339bb10: 081ca04e mov      v8.16b, v0.16b
0339bb14: 08e040b9 ldr      w8, [x0, #0xe0]
0339bb18: 291ca14e mov      v9.16b, v1.16b
0339bb1c: 4d1ca24e mov      v13.16b, v2.16b
0339bb20: 48000035 cbnz     w8, #0x339bb28
0339bb24: 38567097 bl       #0xfb1404
0339bb28: 0834a852 mov      w8, #0x41a00000
0339bb2c: e91b09b2 mov      x9, #0x3f8000003f800000
0339bb30: 0af0a752 mov      w10, #0x3f800000
0339bb34: 001da84e mov      v0.16b, v8.16b
0339bb38: 211da94e mov      v1.16b, v9.16b
0339bb3c: a21dad4e mov      v2.16b, v13.16b
0339bb40: 831dac4e mov      v3.16b, v12.16b
0339bb44: 641dab4e mov      v4.16b, v11.16b
0339bb48: 451daa4e mov      v5.16b, v10.16b
0339bb4c: e0031faa mov      x0, xzr
0339bb50: e81300b9 str      w8, [sp, #0x10]
0339bb54: ea2700a9 stp      x10, x9, [sp]
0339bb58: 37902594 bl       #0x3cffc34 ; UnityEngine.Debug$$DrawLine
0339bb5c: f37b47a9 ldp      x19, x30, [sp, #0x70]
0339bb60: f55346a9 ldp      x21, x20, [sp, #0x60]
0339bb64: f62b40f9 ldr      x22, [sp, #0x50]
0339bb68: e923446d ldp      d9, d8, [sp, #0x40]
0339bb6c: eb2b436d ldp      d11, d10, [sp, #0x30]
0339bb70: ed33426d ldp      d13, d12, [sp, #0x20]
0339bb74: ff030291 add      sp, sp, #0x80
0339bb78: c0035fd6 ret      
0339bb7c: 2b567097 bl       #0xfb1428
