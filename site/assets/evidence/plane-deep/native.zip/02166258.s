# Royal.Scenes.Game.Mechanics.Items.SlotMachineItem.SlotMachineItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02166258: e80f1dfc str      d8, [sp, #-0x30]!
0216625c: f60700f9 str      x22, [sp, #8]
02166260: f55301a9 stp      x21, x20, [sp, #0x10]
02166264: f37b02a9 stp      x19, x30, [sp, #0x20]
02166268: 080040f9 ldr      x8, [x0]
0216626c: f403012a mov      w20, w1
02166270: f30300aa mov      x19, x0
02166274: 096542f9 ldr      x9, [x8, #0x4c8]
02166278: 086942f9 ldr      x8, [x8, #0x4d0]
0216627c: e10308aa mov      x1, x8
02166280: 20013fd6 blr      x9
02166284: c0180034 cbz      w0, #0x216659c
02166288: f503002a mov      w21, w0
0216628c: e003142a mov      w0, w20
02166290: e1031faa mov      x1, xzr
02166294: aa794894 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02166298: bf060071 cmp      w21, #1
0216629c: 21020054 b.ne     #0x21662e0
021662a0: 684a41b9 ldr      w8, [x19, #0x148]
021662a4: 1f0d0071 cmp      w8, #3
021662a8: 80040036 tbz      w0, #0, #0x2166338
021662ac: e80e0054 b.hi     #0x2166488
021662b0: 69ec00b0 adrp     x9, #0x3ef3000
021662b4: e803082a mov      w8, w8
021662b8: 29313191 add      x9, x9, #0xc4c
021662bc: ca000010 adr      x10, #0x21662d4
021662c0: 2b696838 ldrb     w11, [x9, x8]
021662c4: 4a090b8b add      x10, x10, x11, lsl #2
021662c8: 00229f52 mov      w0, #0xf910
021662cc: c000a072 movk     w0, #6, lsl #16
021662d0: 40011fd6 br       x10
021662d4: 00aa9b52 mov      w0, #0xdd50
021662d8: 4004a072 movk     w0, #0x22, lsl #16
021662dc: b0000014 b        #0x216659c
021662e0: e803271e fmov     s8, wzr
021662e4: 40140037 tbnz     w0, #0, #0x216656c
021662e8: d9faff97 bl       #0x2164e4c ; Royal.Scenes.Game.Mechanics.Items.SlotMachineItem.SlotMachineItemModel$$GetItemHelper
021662ec: 201600b4 cbz      x0, #0x21665b0
021662f0: 756a40b9 ldr      w21, [x19, #0x68]
021662f4: 164840b9 ldr      w22, [x0, #0x48]
021662f8: 9f0a0071 cmp      w20, #2
021662fc: c1030054 b.ne     #0x2166374
02166300: 680240f9 ldr      x8, [x19]
02166304: e00313aa mov      x0, x19
02166308: 09bd41f9 ldr      x9, [x8, #0x378]
0216630c: 01c141f9 ldr      x1, [x8, #0x380]
02166310: 20013fd6 blr      x9
02166314: e1031faa mov      x1, xzr
02166318: 9c794894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
0216631c: bf02166b cmp      w21, w22
02166320: 0000221e scvtf    s0, w0
02166324: cd030054 b.le     #0x216639c
02166328: 0190231e fmov     s1, #7.00000000
0216632c: 0008211e fmul     s0, s0, s1
02166330: 0150241e fmov     s1, #9.00000000
02166334: 1b000014 b        #0x21663a0
02166338: e803271e fmov     s8, wzr
0216633c: 88110054 b.hi     #0x216656c
02166340: 69ec00b0 adrp     x9, #0x3ef3000
02166344: e803082a mov      w8, w8
02166348: 29213191 add      x9, x9, #0xc48
0216634c: 8a000010 adr      x10, #0x216635c
02166350: 2b696838 ldrb     w11, [x9, x8]
02166354: 4a090b8b add      x10, x10, x11, lsl #2
02166358: 40011fd6 br       x10
0216635c: e003142a mov      w0, w20
02166360: e1031faa mov      x1, xzr
02166364: 92794894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02166368: c00a0036 tbz      w0, #0, #0x21664c0
0216636c: a0608a52 mov      w0, #0x5305
02166370: 33000014 b        #0x216643c
02166374: e003142a mov      w0, w20
02166378: e1031faa mov      x1, xzr
0216637c: 8c794894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02166380: 80010036 tbz      w0, #0, #0x21663b0
02166384: a8608a52 mov      w8, #0x5305
02166388: bf02166b cmp      w21, w22
0216638c: 4800a072 movk     w8, #2, lsl #16
02166390: e9ca9852 mov      w9, #0xc657
02166394: 20c1881a csel     w0, w9, w8, gt
02166398: 81000014 b        #0x216659c
0216639c: 0110211e fmov     s1, #3.00000000
021663a0: 0018211e fdiv     s0, s0, s1
021663a4: e103271e fmov     s1, wzr
021663a8: 2838201e fsub     s8, s1, s0
021663ac: 70000014 b        #0x216656c
021663b0: e803271e fmov     s8, wzr
021663b4: bf02166b cmp      w21, w22
021663b8: e003271e fmov     s0, wzr
021663bc: 8d010054 b.le     #0x21663ec
021663c0: 680240f9 ldr      x8, [x19]
021663c4: e00313aa mov      x0, x19
021663c8: 09bd41f9 ldr      x9, [x8, #0x378]
021663cc: 01c141f9 ldr      x1, [x8, #0x380]
021663d0: 20013fd6 blr      x9
021663d4: e1031faa mov      x1, xzr
021663d8: 6c794894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
021663dc: 0000221e scvtf    s0, w0
021663e0: 0028201e fadd     s0, s0, s0
021663e4: 0110211e fmov     s1, #3.00000000
021663e8: 0018211e fdiv     s0, s0, s1
021663ec: 0839201e fsub     s8, s8, s0
021663f0: 5f000014 b        #0x216656c
021663f4: 680240f9 ldr      x8, [x19]
021663f8: e00313aa mov      x0, x19
021663fc: 09bd41f9 ldr      x9, [x8, #0x378]
02166400: 01c141f9 ldr      x1, [x8, #0x380]
02166404: 20013fd6 blr      x9
02166408: e1031faa mov      x1, xzr
0216640c: a9954894 bl       #0x338bab0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$CellsFreedAfterExplode
02166410: a8608a52 mov      w8, #0x5305
02166414: 69c19452 mov      w9, #0xa60b
02166418: 4800a072 movk     w8, #2, lsl #16
0216641c: 8900a072 movk     w9, #4, lsl #16
02166420: 0024081b madd     w0, w0, w8, w9
02166424: 5e000014 b        #0x216659c
02166428: e003142a mov      w0, w20
0216642c: e1031faa mov      x1, xzr
02166430: 5f794894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02166434: e0020036 tbz      w0, #0, #0x2166490
02166438: a0f89c52 mov      w0, #0xe7c5
0216643c: 4000a072 movk     w0, #2, lsl #16
02166440: 57000014 b        #0x216659c
02166444: 00e58652 mov      w0, #0x3728
02166448: 2009a072 movk     w0, #0x49, lsl #16
0216644c: 54000014 b        #0x216659c
02166450: e003142a mov      w0, w20
02166454: e1031faa mov      x1, xzr
02166458: 55794894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
0216645c: a0040036 tbz      w0, #0, #0x21664f0
02166460: 80598752 mov      w0, #0x3acc
02166464: a000a072 movk     w0, #5, lsl #16
02166468: 4d000014 b        #0x216659c
0216646c: e003142a mov      w0, w20
02166470: e1031faa mov      x1, xzr
02166474: 4e794894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02166478: 40050036 tbz      w0, #0, #0x2166520
0216647c: e0288252 mov      w0, #0x1147
02166480: 8000a072 movk     w0, #4, lsl #16
02166484: 46000014 b        #0x216659c
02166488: e0031f2a mov      w0, wzr
0216648c: 44000014 b        #0x216659c
02166490: 680240f9 ldr      x8, [x19]
02166494: e00313aa mov      x0, x19
02166498: 09bd41f9 ldr      x9, [x8, #0x378]
0216649c: 01c141f9 ldr      x1, [x8, #0x380]
021664a0: 20013fd6 blr      x9
021664a4: e1031faa mov      x1, xzr
021664a8: 38794894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
021664ac: 9f0a0071 cmp      w20, #2
021664b0: 0000221e scvtf    s0, w0
021664b4: 81050054 b.ne     #0x2166564
021664b8: 0110331e fmov     s1, #-6.00000000
021664bc: 24000014 b        #0x216654c
021664c0: 9f0a0071 cmp      w20, #2
021664c4: 41050054 b.ne     #0x216656c
021664c8: 680240f9 ldr      x8, [x19]
021664cc: e00313aa mov      x0, x19
021664d0: 09bd41f9 ldr      x9, [x8, #0x378]
021664d4: 01c141f9 ldr      x1, [x8, #0x380]
021664d8: 20013fd6 blr      x9
021664dc: e1031faa mov      x1, xzr
021664e0: 2a794894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
021664e4: 0000221e scvtf    s0, w0
021664e8: 0110311e fmov     s1, #-3.00000000
021664ec: 18000014 b        #0x216654c
021664f0: 680240f9 ldr      x8, [x19]
021664f4: e00313aa mov      x0, x19
021664f8: 09bd41f9 ldr      x9, [x8, #0x378]
021664fc: 01c141f9 ldr      x1, [x8, #0x380]
02166500: 20013fd6 blr      x9
02166504: e1031faa mov      x1, xzr
02166508: 20794894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
0216650c: 9f0a0071 cmp      w20, #2
02166510: 0000221e scvtf    s0, w0
02166514: 01020054 b.ne     #0x2166554
02166518: 01102c1e fmov     s1, #0.50000000
0216651c: 13000014 b        #0x2166568
02166520: 680240f9 ldr      x8, [x19]
02166524: e00313aa mov      x0, x19
02166528: 09bd41f9 ldr      x9, [x8, #0x378]
0216652c: 01c141f9 ldr      x1, [x8, #0x380]
02166530: 20013fd6 blr      x9
02166534: e1031faa mov      x1, xzr
02166538: 14794894 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
0216653c: 9f0a0071 cmp      w20, #2
02166540: 0000221e scvtf    s0, w0
02166544: c1000054 b.ne     #0x216655c
02166548: 0110231e fmov     s1, #6.00000000
0216654c: 0818211e fdiv     s8, s0, s1
02166550: 07000014 b        #0x216656c
02166554: 0190221e fmov     s1, #5.00000000
02166558: 02000014 b        #0x2166560
0216655c: 0110211e fmov     s1, #3.00000000
02166560: 0008211e fmul     s0, s0, s1
02166564: 01102a1e fmov     s1, #0.25000000
02166568: 0808211e fmul     s8, s0, s1
0216656c: e00313aa mov      x0, x19
02166570: e103142a mov      w1, w20
02166574: e2031faa mov      x2, xzr
02166578: c6ad4894 bl       #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
0216657c: 0000221e scvtf    s0, w0
02166580: 08f0af52 mov      w8, #0x7f800000
02166584: 0029201e fadd     s0, s8, s0
02166588: 0101271e fmov     s1, w8
0216658c: 0800381e fcvtzs   w8, s0
02166590: 0020211e fcmp     s0, s1
02166594: 0900b052 mov      w9, #-0x80000000
02166598: 2001881a csel     w0, w9, w8, eq
0216659c: f37b42a9 ldp      x19, x30, [sp, #0x20]
021665a0: f55341a9 ldp      x21, x20, [sp, #0x10]
021665a4: f60740f9 ldr      x22, [sp, #8]
021665a8: e80743fc ldr      d8, [sp], #0x30
021665ac: c0035fd6 ret      
021665b0: 9e2bb997 bl       #0xfb1428
