# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TargetReached
# Linear span to next metadata entry; not a complete CFG.
026a41f0: ff0306d1 sub      sp, sp, #0x180
026a41f4: fc6314a9 stp      x28, x24, [sp, #0x140]
026a41f8: f75b15a9 stp      x23, x22, [sp, #0x150]
026a41fc: f55316a9 stp      x21, x20, [sp, #0x160]
026a4200: f37b17a9 stp      x19, x30, [sp, #0x170]
026a4204: f4760190 adrp     x20, #0x5580000
026a4208: 88064139 ldrb     w8, [x20, #0x41]
026a420c: f30300aa mov      x19, x0
026a4210: 88010037 tbnz     w8, #0, #0x26a4240
026a4214: a05701b0 adrp     x0, #0x5199000
026a4218: 002046f9 ldr      x0, [x0, #0xc40]
026a421c: 3934a497 bl       #0xfb1300
026a4220: a0580190 adrp     x0, #0x51b8000
026a4224: 002840f9 ldr      x0, [x0, #0x50]
026a4228: 3634a497 bl       #0xfb1300
026a422c: 205c0190 adrp     x0, #0x5228000
026a4230: 000444f9 ldr      x0, [x0, #0x808]
026a4234: 3334a497 bl       #0xfb1300
026a4238: 28008052 mov      w8, #1
026a423c: 88060139 strb     w8, [x20, #0x41]
026a4240: e00313aa mov      x0, x19
026a4244: 8ff8ff97 bl       #0x26a2480 ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryDeregisterForTargetChange
026a4248: 76320491 add      x22, x19, #0x10c
026a424c: c28240ad ldp      q2, q0, [x22, #0x10]
026a4250: c81a40f9 ldr      x8, [x22, #0x30]
026a4254: c102c03d ldr      q1, [x22]
026a4258: 74a640f9 ldr      x20, [x19, #0x148]
026a425c: e28306ad stp      q2, q0, [sp, #0xd0]
026a4260: e87b00f9 str      x8, [sp, #0xf0]
026a4264: e133803d str      q1, [sp, #0xc0]
026a4268: 141b00b4 cbz      x20, #0x26a45c8
026a426c: e10346ad ldp      q1, q0, [sp, #0xc0]
026a4270: e23bc03d ldr      q2, [sp, #0xe0]
026a4274: e87b40f9 ldr      x8, [sp, #0xf0]
026a4278: b8580190 adrp     x24, #0x51b8000
026a427c: e10304ad stp      q1, q0, [sp, #0x80]
026a4280: e22b803d str      q2, [sp, #0xa0]
026a4284: e85b00f9 str      x8, [sp, #0xb0]
026a4288: 880240f9 ldr      x8, [x20]
026a428c: 182b40f9 ldr      x24, [x24, #0x50]
026a4290: 09554279 ldrh     w9, [x8, #0x12a]
026a4294: 010340f9 ldr      x1, [x24]
026a4298: 290100b4 cbz      x9, #0x26a42bc
026a429c: 0a5940f9 ldr      x10, [x8, #0xb0]
026a42a0: 4a210091 add      x10, x10, #8
026a42a4: 4b815ff8 ldur     x11, [x10, #-8]
026a42a8: 7f0101eb cmp      x11, x1
026a42ac: 00010054 b.eq     #0x26a42cc
026a42b0: 290500f1 subs     x9, x9, #1
026a42b4: 4a410091 add      x10, x10, #0x10
026a42b8: 61ffff54 b.ne     #0x26a42a4
026a42bc: e2008052 mov      w2, #7
026a42c0: e00314aa mov      x0, x20
026a42c4: 0474a397 bl       #0xf812d4
026a42c8: 05000014 b        #0x26a42dc
026a42cc: 490140b9 ldr      w9, [x10]
026a42d0: 291d0011 add      w9, w9, #7
026a42d4: 08d1298b add      x8, x8, w9, sxtw #4
026a42d8: 00e10491 add      x0, x8, #0x138
026a42dc: e00b44ad ldp      q0, q2, [sp, #0x80]
026a42e0: e12bc03d ldr      q1, [sp, #0xa0]
026a42e4: e95b40f9 ldr      x9, [sp, #0xb0]
026a42e8: 080040f9 ldr      x8, [x0]
026a42ec: e00b08ad stp      q0, q2, [sp, #0x100]
026a42f0: e14b803d str      q1, [sp, #0x120]
026a42f4: e99b00f9 str      x9, [sp, #0x130]
026a42f8: 020440f9 ldr      x2, [x0, #8]
026a42fc: 375c0190 adrp     x23, #0x5228000
026a4300: f70644f9 ldr      x23, [x23, #0x808]
026a4304: e1030491 add      x1, sp, #0x100
026a4308: e00314aa mov      x0, x20
026a430c: 00013fd6 blr      x8
026a4310: 68224439 ldrb     w8, [x19, #0x108]
026a4314: 68060035 cbnz     w8, #0x26a43e0
026a4318: 601641b9 ldr      w0, [x19, #0x114]
026a431c: 74a640f9 ldr      x20, [x19, #0x148]
026a4320: e1031faa mov      x1, xzr
026a4324: c3581a94 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
026a4328: 141500b4 cbz      x20, #0x26a45c8
026a432c: 880240f9 ldr      x8, [x20]
026a4330: 010340f9 ldr      x1, [x24]
026a4334: f503002a mov      w21, w0
026a4338: 09554279 ldrh     w9, [x8, #0x12a]
026a433c: 290100b4 cbz      x9, #0x26a4360
026a4340: 0a5940f9 ldr      x10, [x8, #0xb0]
026a4344: 4a210091 add      x10, x10, #8
026a4348: 4b815ff8 ldur     x11, [x10, #-8]
026a434c: 7f0101eb cmp      x11, x1
026a4350: 00010054 b.eq     #0x26a4370
026a4354: 290500f1 subs     x9, x9, #1
026a4358: 4a410091 add      x10, x10, #0x10
026a435c: 61ffff54 b.ne     #0x26a4348
026a4360: 42008052 mov      w2, #2
026a4364: e00314aa mov      x0, x20
026a4368: db73a397 bl       #0xf812d4
026a436c: 05000014 b        #0x26a4380
026a4370: 490140b9 ldr      w9, [x10]
026a4374: 29090011 add      w9, w9, #2
026a4378: 08d1298b add      x8, x8, w9, sxtw #4
026a437c: 00e10491 add      x0, x8, #0x138
026a4380: 080840a9 ldp      x8, x2, [x0]
026a4384: e00314aa mov      x0, x20
026a4388: e103152a mov      w1, w21
026a438c: 00013fd6 blr      x8
026a4390: 80020036 tbz      w0, #0, #0x26a43e0
026a4394: 75a640f9 ldr      x21, [x19, #0x148]
026a4398: 951100b4 cbz      x21, #0x26a45c8
026a439c: a80240f9 ldr      x8, [x21]
026a43a0: 747240f9 ldr      x20, [x19, #0xe0]
026a43a4: 010340f9 ldr      x1, [x24]
026a43a8: 09554279 ldrh     w9, [x8, #0x12a]
026a43ac: 290100b4 cbz      x9, #0x26a43d0
026a43b0: 0a5940f9 ldr      x10, [x8, #0xb0]
026a43b4: 4a210091 add      x10, x10, #8
026a43b8: 4b815ff8 ldur     x11, [x10, #-8]
026a43bc: 7f0101eb cmp      x11, x1
026a43c0: 800a0054 b.eq     #0x26a4510
026a43c4: 290500f1 subs     x9, x9, #1
026a43c8: 4a410091 add      x10, x10, #0x10
026a43cc: 61ffff54 b.ne     #0x26a43b8
026a43d0: 62008052 mov      w2, #3
026a43d4: e00315aa mov      x0, x21
026a43d8: bf73a397 bl       #0xf812d4
026a43dc: 51000014 b        #0x26a4520
026a43e0: 747240f9 ldr      x20, [x19, #0xe0]
026a43e4: c28240ad ldp      q2, q0, [x22, #0x10]
026a43e8: c81a40f9 ldr      x8, [x22, #0x30]
026a43ec: c102c03d ldr      q1, [x22]
026a43f0: 756240f9 ldr      x21, [x19, #0xc0]
026a43f4: e28306ad stp      q2, q0, [sp, #0xd0]
026a43f8: e87b00f9 str      x8, [sp, #0xf0]
026a43fc: e133803d str      q1, [sp, #0xc0]
026a4400: 540e00b4 cbz      x20, #0x26a45c8
026a4404: e10346ad ldp      q1, q0, [sp, #0xc0]
026a4408: e23bc03d ldr      q2, [sp, #0xe0]
026a440c: e87b40f9 ldr      x8, [sp, #0xf0]
026a4410: e10240f9 ldr      x1, [x23]
026a4414: e10302ad stp      q1, q0, [sp, #0x40]
026a4418: e21b803d str      q2, [sp, #0x60]
026a441c: e83b00f9 str      x8, [sp, #0x70]
026a4420: 880240f9 ldr      x8, [x20]
026a4424: 09554279 ldrh     w9, [x8, #0x12a]
026a4428: 290100b4 cbz      x9, #0x26a444c
026a442c: 0a5940f9 ldr      x10, [x8, #0xb0]
026a4430: 4a210091 add      x10, x10, #8
026a4434: 4b815ff8 ldur     x11, [x10, #-8]
026a4438: 7f0101eb cmp      x11, x1
026a443c: 00010054 b.eq     #0x26a445c
026a4440: 290500f1 subs     x9, x9, #1
026a4444: 4a410091 add      x10, x10, #0x10
026a4448: 61ffff54 b.ne     #0x26a4434
026a444c: 42008052 mov      w2, #2
026a4450: e00314aa mov      x0, x20
026a4454: a073a397 bl       #0xf812d4
026a4458: 05000014 b        #0x26a446c
026a445c: 490140b9 ldr      w9, [x10]
026a4460: 29090011 add      w9, w9, #2
026a4464: 08d1298b add      x8, x8, w9, sxtw #4
026a4468: 00e10491 add      x0, x8, #0x138
026a446c: 080040f9 ldr      x8, [x0]
026a4470: e00b42ad ldp      q0, q2, [sp, #0x40]
026a4474: e11bc03d ldr      q1, [sp, #0x60]
026a4478: e93b40f9 ldr      x9, [sp, #0x70]
026a447c: e00b08ad stp      q0, q2, [sp, #0x100]
026a4480: e14b803d str      q1, [sp, #0x120]
026a4484: e99b00f9 str      x9, [sp, #0x130]
026a4488: 030440f9 ldr      x3, [x0, #8]
026a448c: e2030491 add      x2, sp, #0x100
026a4490: e00314aa mov      x0, x20
026a4494: e10315aa mov      x1, x21
026a4498: 00013fd6 blr      x8
026a449c: 606e40f9 ldr      x0, [x19, #0xd8]
026a44a0: 7fde0339 strb     wzr, [x19, #0xf7]
026a44a4: 200900b4 cbz      x0, #0x26a45c8
026a44a8: 61008052 mov      w1, #3
026a44ac: e2031faa mov      x2, xzr
026a44b0: e9540e94 bl       #0x2a39854 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$OperationFinish
026a44b4: 606e40f9 ldr      x0, [x19, #0xd8]
026a44b8: 800800b4 cbz      x0, #0x26a45c8
026a44bc: b45701b0 adrp     x20, #0x5199000
026a44c0: 942246f9 ldr      x20, [x20, #0xc40]
026a44c4: e1031faa mov      x1, xzr
026a44c8: 52640e94 bl       #0x2a3d610 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$FinishSpecialOperation
026a44cc: e00313aa mov      x0, x19
026a44d0: 3f000094 bl       #0x26a45cc ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$UnfreezeCellsWithDelay
026a44d4: 880240f9 ldr      x8, [x20]
026a44d8: f30300aa mov      x19, x0
026a44dc: 09e140b9 ldr      w9, [x8, #0xe0]
026a44e0: 69000035 cbnz     w9, #0x26a44ec
026a44e4: e00308aa mov      x0, x8
026a44e8: c733a497 bl       #0xfb1404
026a44ec: e00313aa mov      x0, x19
026a44f0: e1031faa mov      x1, xzr
026a44f4: 17ef4494 bl       #0x37e0150 ; Royal.Scenes.Start.Context.ApplicationContext$$ManualStartCoroutine
026a44f8: f37b57a9 ldp      x19, x30, [sp, #0x170]
026a44fc: f55356a9 ldp      x21, x20, [sp, #0x160]
026a4500: f75b55a9 ldp      x23, x22, [sp, #0x150]
026a4504: fc6354a9 ldp      x28, x24, [sp, #0x140]
026a4508: ff030691 add      sp, sp, #0x180
026a450c: c0035fd6 ret      
026a4510: 490140b9 ldr      w9, [x10]
026a4514: 290d0011 add      w9, w9, #3
026a4518: 08d1298b add      x8, x8, w9, sxtw #4
026a451c: 00e10491 add      x0, x8, #0x138
026a4520: 080440a9 ldp      x8, x1, [x0]
026a4524: e00315aa mov      x0, x21
026a4528: 00013fd6 blr      x8
026a452c: c81a40f9 ldr      x8, [x22, #0x30]
026a4530: c18240ad ldp      q1, q0, [x22, #0x10]
026a4534: c202c03d ldr      q2, [x22]
026a4538: e87b00f9 str      x8, [sp, #0xf0]
026a453c: e18306ad stp      q1, q0, [sp, #0xd0]
026a4540: e233803d str      q2, [sp, #0xc0]
026a4544: 340400b4 cbz      x20, #0x26a45c8
026a4548: e10346ad ldp      q1, q0, [sp, #0xc0]
026a454c: e23bc03d ldr      q2, [sp, #0xe0]
026a4550: e87b40f9 ldr      x8, [sp, #0xf0]
026a4554: e10240f9 ldr      x1, [x23]
026a4558: e10300ad stp      q1, q0, [sp]
026a455c: e20b803d str      q2, [sp, #0x20]
026a4560: e81b00f9 str      x8, [sp, #0x30]
026a4564: 880240f9 ldr      x8, [x20]
026a4568: f50300aa mov      x21, x0
026a456c: 09554279 ldrh     w9, [x8, #0x12a]
026a4570: 290100b4 cbz      x9, #0x26a4594
026a4574: 0a5940f9 ldr      x10, [x8, #0xb0]
026a4578: 4a210091 add      x10, x10, #8
026a457c: 4b815ff8 ldur     x11, [x10, #-8]
026a4580: 7f0101eb cmp      x11, x1
026a4584: 00010054 b.eq     #0x26a45a4
026a4588: 290500f1 subs     x9, x9, #1
026a458c: 4a410091 add      x10, x10, #0x10
026a4590: 61ffff54 b.ne     #0x26a457c
026a4594: 42008052 mov      w2, #2
026a4598: e00314aa mov      x0, x20
026a459c: 4e73a397 bl       #0xf812d4
026a45a0: 05000014 b        #0x26a45b4
026a45a4: 490140b9 ldr      w9, [x10]
026a45a8: 29090011 add      w9, w9, #2
026a45ac: 08d1298b add      x8, x8, w9, sxtw #4
026a45b0: 00e10491 add      x0, x8, #0x138
026a45b4: 080040f9 ldr      x8, [x0]
026a45b8: e00b40ad ldp      q0, q2, [sp]
026a45bc: e10bc03d ldr      q1, [sp, #0x20]
026a45c0: e91b40f9 ldr      x9, [sp, #0x30]
026a45c4: aeffff17 b        #0x26a447c
026a45c8: 9833a497 bl       #0xfb1428
