# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ClearCumulativeHittableItemLists
# Linear span to next metadata entry; not a complete CFG.
026a7ad0: f40f1ef8 str      x20, [sp, #-0x20]!
026a7ad4: f37b01a9 stp      x19, x30, [sp, #0x10]
026a7ad8: d47601b0 adrp     x20, #0x5580000
026a7adc: 887e4139 ldrb     w8, [x20, #0x5f]
026a7ae0: f30300aa mov      x19, x0
026a7ae4: c8000037 tbnz     w8, #0, #0x26a7afc
026a7ae8: a05901d0 adrp     x0, #0x51dd000
026a7aec: 00d041f9 ldr      x0, [x0, #0x3a0]
026a7af0: 0426a497 bl       #0xfb1300
026a7af4: 28008052 mov      w8, #1
026a7af8: 887e0139 strb     w8, [x20, #0x5f]
026a7afc: 602640f9 ldr      x0, [x19, #0x48]
026a7b00: e00000b4 cbz      x0, #0x26a7b1c
026a7b04: a85901d0 adrp     x8, #0x51dd000
026a7b08: 08d141f9 ldr      x8, [x8, #0x3a0]
026a7b0c: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a7b10: 010140f9 ldr      x1, [x8]
026a7b14: f40742f8 ldr      x20, [sp], #0x20
026a7b18: ef214114 b        #0x36f02d4 ; System.Collections.Generic.Dictionary<int, int>$$Clear
026a7b1c: 4326a497 bl       #0xfb1428
