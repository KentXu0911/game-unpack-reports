# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.FireworksRocketStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a28f4: ea0f1cfc str      d10, [sp, #-0x40]!
033a28f8: e923016d stp      d9, d8, [sp, #0x10]
033a28fc: f55302a9 stp      x21, x20, [sp, #0x20]
033a2900: f37b03a9 stp      x19, x30, [sp, #0x30]
033a2904: 35000012 and      w21, w1, #1
033a2908: e1031f2a mov      w1, wzr
033a290c: f30302aa mov      x19, x2
033a2910: 481ca24e mov      v8.16b, v2.16b
033a2914: 291ca14e mov      v9.16b, v1.16b
033a2918: 0a1ca04e mov      v10.16b, v0.16b
033a291c: f40300aa mov      x20, x0
033a2920: 6b000094 bl       #0x33a2acc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$.ctor
033a2924: 938e03f8 str      x19, [x20, #0x38]!
033a2928: 9fc21eb8 stur     wzr, [x20, #-0x14]
033a292c: 95021f38 sturb    w21, [x20, #-0x10]
033a2930: 8aa63e2d stp      s10, s9, [x20, #-0xc]
033a2934: 88c21fbc stur     s8, [x20, #-4]
033a2938: e00314aa mov      x0, x20
033a293c: e10313aa mov      x1, x19
033a2940: f37b43a9 ldp      x19, x30, [sp, #0x30]
033a2944: f55342a9 ldp      x21, x20, [sp, #0x20]
033a2948: e923416d ldp      d9, d8, [sp, #0x10]
033a294c: ea0744fc ldr      d10, [sp], #0x40
033a2950: 573a7017 b        #0xfb12ac
