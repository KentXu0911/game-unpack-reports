# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$StartFlying
# Linear span to next metadata entry; not a complete CFG.
0339b6d4: f60f1df8 str      x22, [sp, #-0x30]!
0339b6d8: f55301a9 stp      x21, x20, [sp, #0x10]
0339b6dc: f37b02a9 stp      x19, x30, [sp, #0x20]
0339b6e0: f40300aa mov      x20, x0
0339b6e4: 006840f9 ldr      x0, [x0, #0xd0]
0339b6e8: c00200b4 cbz      x0, #0x339b740
0339b6ec: f50301aa mov      x21, x1
0339b6f0: e1031faa mov      x1, xzr
0339b6f4: f30302aa mov      x19, x2
0339b6f8: ac9d2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339b6fc: 350200b4 cbz      x21, #0x339b740
0339b700: f60300aa mov      x22, x0
0339b704: e00315aa mov      x0, x21
0339b708: e1031faa mov      x1, xzr
0339b70c: a79d2594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339b710: 960100b4 cbz      x22, #0x339b740
0339b714: e10300aa mov      x1, x0
0339b718: e00316aa mov      x0, x22
0339b71c: e2031faa mov      x2, xzr
0339b720: d8bb2594 bl       #0x3d0a680 ; UnityEngine.Transform$$SetParent
0339b724: e00314aa mov      x0, x20
0339b728: e10315aa mov      x1, x21
0339b72c: e20313aa mov      x2, x19
0339b730: f37b42a9 ldp      x19, x30, [sp, #0x20]
0339b734: f55341a9 ldp      x21, x20, [sp, #0x10]
0339b738: f60743f8 ldr      x22, [sp], #0x30
0339b73c: acf4ff17 b        #0x33989ec ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$StartFlying
0339b740: 3a577097 bl       #0xfb1428
