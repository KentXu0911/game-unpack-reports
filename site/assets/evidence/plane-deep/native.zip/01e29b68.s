# Royal.Scenes.Game.Mechanics.Items.MagicGemItem.MagicGemItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e29b68: f553bea9 stp      x21, x20, [sp, #-0x20]!
01e29b6c: f37b01a9 stp      x19, x30, [sp, #0x10]
01e29b70: 086840b9 ldr      w8, [x0, #0x68]
01e29b74: 68020034 cbz      w8, #0x1e29bc0
01e29b78: 080040f9 ldr      x8, [x0]
01e29b7c: f403012a mov      w20, w1
01e29b80: f30300aa mov      x19, x0
01e29b84: 096542f9 ldr      x9, [x8, #0x4c8]
01e29b88: 016942f9 ldr      x1, [x8, #0x4d0]
01e29b8c: 20013fd6 blr      x9
01e29b90: 1f040071 cmp      w0, #1
01e29b94: 6b010054 b.lt     #0x1e29bc0
01e29b98: e003142a mov      w0, w20
01e29b9c: e1031faa mov      x1, xzr
01e29ba0: 836b5594 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
01e29ba4: 20010036 tbz      w0, #0, #0x1e29bc8
01e29ba8: 602a40f9 ldr      x0, [x19, #0x50]
01e29bac: 200400b4 cbz      x0, #0x1e29c30
01e29bb0: 61c242f8 ldur     x1, [x19, #0x2c]
01e29bb4: e2031faa mov      x2, xzr
01e29bb8: 56aa2494 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
01e29bbc: 06000014 b        #0x1e29bd4
01e29bc0: e0031f2a mov      w0, wzr
01e29bc4: 18000014 b        #0x1e29c24
01e29bc8: e00313aa mov      x0, x19
01e29bcc: e1031faa mov      x1, xzr
01e29bd0: b1645594 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
01e29bd4: f50300aa mov      x21, x0
01e29bd8: 605e40f9 ldr      x0, [x19, #0xb8]
01e29bdc: a00200b4 cbz      x0, #0x1e29c30
01e29be0: 614641b9 ldr      w1, [x19, #0x144]
01e29be4: fffbff97 bl       #0x1e28be0 ; Royal.Scenes.Game.Mechanics.Items.MagicGemItem.MagicGemItemHelper$$GetMagicGemGroupItems
01e29be8: a4608a52 mov      w4, #0x5305
01e29bec: e10300aa mov      x1, x0
01e29bf0: 4400a072 movk     w4, #2, lsl #16
01e29bf4: 05008012 mov      w5, #-1
01e29bf8: e00313aa mov      x0, x19
01e29bfc: e20315aa mov      x2, x21
01e29c00: e303142a mov      w3, w20
01e29c04: e6031faa mov      x6, xzr
01e29c08: 706b5594 bl       #0x33849c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetItemExplodeExtraScore
01e29c0c: f503002a mov      w21, w0
01e29c10: e00313aa mov      x0, x19
01e29c14: e103142a mov      w1, w20
01e29c18: e2031faa mov      x2, xzr
01e29c1c: 546b5594 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
01e29c20: 0000150b add      w0, w0, w21
01e29c24: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e29c28: f553c2a8 ldp      x21, x20, [sp], #0x20
01e29c2c: c0035fd6 ret      
01e29c30: fe1dc697 bl       #0xfb1428
