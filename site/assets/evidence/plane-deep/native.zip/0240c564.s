# Royal.Scenes.Game.Mechanics.Items.SeedBoxItem.SeedBoxItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0240c564: f553bea9 stp      x21, x20, [sp, #-0x20]!
0240c568: f37b01a9 stp      x19, x30, [sp, #0x10]
0240c56c: 08e44239 ldrb     w8, [x0, #0xb9]
0240c570: 28020034 cbz      w8, #0x240c5b4
0240c574: f30300aa mov      x19, x0
0240c578: f403012a mov      w20, w1
0240c57c: 1bfdff97 bl       #0x240b9e8 ; Royal.Scenes.Game.Mechanics.Items.SeedBoxItem.SeedBoxItemModel$$GetItemHelper
0240c580: e00200b4 cbz      x0, #0x240c5dc
0240c584: f50300aa mov      x21, x0
0240c588: 63f9ff97 bl       #0x240ab14 ; Royal.Scenes.Game.Mechanics.Items.SeedBoxItem.SeedBoxItemHelper$$GetGrassGoal
0240c58c: a83e40b9 ldr      w8, [x21, #0x3c]
0240c590: 1f01006b cmp      w8, w0
0240c594: 0a010054 b.ge     #0x240c5b4
0240c598: 756a40b9 ldr      w21, [x19, #0x68]
0240c59c: e00313aa mov      x0, x19
0240c5a0: eafbff97 bl       #0x240b548 ; Royal.Scenes.Game.Mechanics.Items.SeedBoxItem.SeedBoxItemModel$$GetTotalIncoming
0240c5a4: 0800154b sub      w8, w0, w21
0240c5a8: 080d0011 add      w8, w8, #3
0240c5ac: 1f090071 cmp      w8, #2
0240c5b0: ad000054 b.le     #0x240c5c4
0240c5b4: f37b41a9 ldp      x19, x30, [sp, #0x10]
0240c5b8: e0031f2a mov      w0, wzr
0240c5bc: f553c2a8 ldp      x21, x20, [sp], #0x20
0240c5c0: c0035fd6 ret      
0240c5c4: e00313aa mov      x0, x19
0240c5c8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0240c5cc: e103142a mov      w1, w20
0240c5d0: e2031faa mov      x2, xzr
0240c5d4: f553c2a8 ldp      x21, x20, [sp], #0x20
0240c5d8: e5e03d14 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
0240c5dc: 9393ae97 bl       #0xfb1428
