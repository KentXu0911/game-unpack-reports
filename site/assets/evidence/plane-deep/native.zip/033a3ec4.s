# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$FinishOperationWithDelay
# Linear span to next metadata entry; not a complete CFG.
033a3ec4: e80f1dfc str      d8, [sp, #-0x30]!
033a3ec8: f55301a9 stp      x21, x20, [sp, #0x10]
033a3ecc: f37b02a9 stp      x19, x30, [sp, #0x20]
033a3ed0: 140f01f0 adrp     x20, #0x5586000
033a3ed4: 95ef00f0 adrp     x21, #0x5196000
033a3ed8: 885e6739 ldrb     w8, [x20, #0x9d7]
033a3edc: b5ce45f9 ldr      x21, [x21, #0xb98]
033a3ee0: 081ca04e mov      v8.16b, v0.16b
033a3ee4: f30300aa mov      x19, x0
033a3ee8: c8000037 tbnz     w8, #0, #0x33a3f00
033a3eec: 80ef00f0 adrp     x0, #0x5196000
033a3ef0: 00cc45f9 ldr      x0, [x0, #0xb98]
033a3ef4: 03357097 bl       #0xfb1300
033a3ef8: 28008052 mov      w8, #1
033a3efc: 885e2739 strb     w8, [x20, #0x9d7]
033a3f00: a00240f9 ldr      x0, [x21]
033a3f04: 45357097 bl       #0xfb1418
033a3f08: e00100b4 cbz      x0, #0x33a3f44
033a3f0c: e1031faa mov      x1, xzr
033a3f10: f40300aa mov      x20, x0
033a3f14: b83dbb97 bl       #0x22735f4 ; System.Object$$.ctor
033a3f18: e00314aa mov      x0, x20
033a3f1c: 9f1200b9 str      wzr, [x20, #0x10]
033a3f20: 138c02f8 str      x19, [x0, #0x28]!
033a3f24: e10313aa mov      x1, x19
033a3f28: e1347097 bl       #0xfb12ac
033a3f2c: 882200bd str      s8, [x20, #0x20]
033a3f30: e00314aa mov      x0, x20
033a3f34: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a3f38: f55341a9 ldp      x21, x20, [sp, #0x10]
033a3f3c: e80743fc ldr      d8, [sp], #0x30
033a3f40: c0035fd6 ret      
033a3f44: 39357097 bl       #0xfb1428
