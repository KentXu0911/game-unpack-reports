# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy.<ExplodeWithDelay>d__4$$System.IDisposable.Dispose
# Linear span to next metadata entry; not a complete CFG.
033a4114: c0035fd6 ret      
