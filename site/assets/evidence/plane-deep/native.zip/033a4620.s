# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy.<FinishOperationWithDelay>d__11$$System.IDisposable.Dispose
# Linear span to next metadata entry; not a complete CFG.
033a4620: c0035fd6 ret      
