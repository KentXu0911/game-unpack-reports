# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$GetAngleSmoother
# Linear span to next metadata entry; not a complete CFG.
033a2234: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a2238: 080040f9 ldr      x8, [x0]
033a223c: f30300aa mov      x19, x0
033a2240: 092d41f9 ldr      x9, [x8, #0x258]
033a2244: 013141f9 ldr      x1, [x8, #0x260]
033a2248: 20013fd6 blr      x9
033a224c: 285600b0 adrp     x8, #0x3e67000
033a2250: 611a40bd ldr      s1, [x19, #0x18]
033a2254: 024144bd ldr      s2, [x8, #0x440]
033a2258: 285600b0 adrp     x8, #0x3e67000
033a225c: 03a944bd ldr      s3, [x8, #0x4a8]
033a2260: 2108221e fmul     s1, s1, s2
033a2264: 02102e1e fmov     s2, #1.00000000
033a2268: 2258221e fmin     s2, s1, s2
033a226c: 4208231e fmul     s2, s2, s3
033a2270: e303271e fmov     s3, wzr
033a2274: 4228231e fadd     s2, s2, s3
033a2278: 2820201e fcmp     s1, #0.0
033a227c: 415c231e fcsel    s1, s2, s3, pl
033a2280: 0008211e fmul     s0, s0, s1
033a2284: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a2288: c0035fd6 ret      
