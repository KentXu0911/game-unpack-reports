# Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$ShouldBlockPropellerForLog
# Linear span to next metadata entry; not a complete CFG.
02acc640: f40f1ef8 str      x20, [sp, #-0x20]!
02acc644: f37b01a9 stp      x19, x30, [sp, #0x10]
02acc648: 081040f9 ldr      x8, [x0, #0x20]
02acc64c: 680600b4 cbz      x8, #0x2acc718
02acc650: f30300aa mov      x19, x0
02acc654: 006140f9 ldr      x0, [x8, #0xc0]
02acc658: 000600b4 cbz      x0, #0x2acc718
02acc65c: fcf4ff97 bl       #0x2ac9a4c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasAboveItem
02acc660: 681240f9 ldr      x8, [x19, #0x20]
02acc664: a80500b4 cbz      x8, #0x2acc718
02acc668: c0000036 tbz      w0, #0, #0x2acc680
02acc66c: 006140f9 ldr      x0, [x8, #0xc0]
02acc670: 400500b4 cbz      x0, #0x2acc718
02acc674: ccf6ff97 bl       #0x2aca1a4 ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$GetTopMostAboveItem
02acc678: c00300b5 cbnz     x0, #0x2acc6f0
02acc67c: 27000014 b        #0x2acc718
02acc680: 000940f9 ldr      x0, [x8, #0x10]
02acc684: a00400b4 cbz      x0, #0x2acc718
02acc688: e1031faa mov      x1, xzr
02acc68c: f5e5f197 bl       #0x2745e60 ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$get_CurrentItem
02acc690: 800100b4 cbz      x0, #0x2acc6c0
02acc694: 080040f9 ldr      x8, [x0]
02acc698: f40300aa mov      x20, x0
02acc69c: 09ad43f9 ldr      x9, [x8, #0x758]
02acc6a0: 01b143f9 ldr      x1, [x8, #0x760]
02acc6a4: 20013fd6 blr      x9
02acc6a8: c0000036 tbz      w0, #0, #0x2acc6c0
02acc6ac: 880240f9 ldr      x8, [x20]
02acc6b0: e00314aa mov      x0, x20
02acc6b4: 028d44f9 ldr      x2, [x8, #0x918]
02acc6b8: 019144f9 ldr      x1, [x8, #0x920]
02acc6bc: 10000014 b        #0x2acc6fc
02acc6c0: 681240f9 ldr      x8, [x19, #0x20]
02acc6c4: a80200b4 cbz      x8, #0x2acc718
02acc6c8: 006140f9 ldr      x0, [x8, #0xc0]
02acc6cc: 600200b4 cbz      x0, #0x2acc718
02acc6d0: f3f4ff97 bl       #0x2ac9a9c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasBelowItem
02acc6d4: a0010036 tbz      w0, #0, #0x2acc708
02acc6d8: 681240f9 ldr      x8, [x19, #0x20]
02acc6dc: e80100b4 cbz      x8, #0x2acc718
02acc6e0: 006140f9 ldr      x0, [x8, #0xc0]
02acc6e4: a00100b4 cbz      x0, #0x2acc718
02acc6e8: 01f5ff97 bl       #0x2ac9aec ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$GetTopMostBelowItem
02acc6ec: 600100b4 cbz      x0, #0x2acc718
02acc6f0: 080040f9 ldr      x8, [x0]
02acc6f4: 02f542f9 ldr      x2, [x8, #0x5e8]
02acc6f8: 01f942f9 ldr      x1, [x8, #0x5f0]
02acc6fc: f37b41a9 ldp      x19, x30, [sp, #0x10]
02acc700: f40742f8 ldr      x20, [sp], #0x20
02acc704: 40001fd6 br       x2
02acc708: f37b41a9 ldp      x19, x30, [sp, #0x10]
02acc70c: 20008052 mov      w0, #1
02acc710: f40742f8 ldr      x20, [sp], #0x20
02acc714: c0035fd6 ret      
02acc718: 44939397 bl       #0xfb1428
