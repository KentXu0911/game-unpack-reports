# Royal.Scenes.Game.Mechanics.Items.VendingMachineItem.VendingMachineFakeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03c1a9a4: f553bea9 stp      x21, x20, [sp, #-0x20]!
03c1a9a8: f37b01a9 stp      x19, x30, [sp, #0x10]
03c1a9ac: 95cb00b0 adrp     x21, #0x558b000
03c1a9b0: a8824639 ldrb     w8, [x21, #0x1a0]
03c1a9b4: f303012a mov      w19, w1
03c1a9b8: f40300aa mov      x20, x0
03c1a9bc: c8000037 tbnz     w8, #0, #0x3c1a9d4
03c1a9c0: 80ad0090 adrp     x0, #0x51ca000
03c1a9c4: 004c41f9 ldr      x0, [x0, #0x298]
03c1a9c8: 4e5a4e97 bl       #0xfb1300
03c1a9cc: 28008052 mov      w8, #1
03c1a9d0: a8820639 strb     w8, [x21, #0x1a0]
03c1a9d4: e003132a mov      w0, w19
03c1a9d8: e1031faa mov      x1, xzr
03c1a9dc: f4a7dd97 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03c1a9e0: a0000036 tbz      w0, #0, #0x3c1a9f4
03c1a9e4: 889e40f9 ldr      x8, [x20, #0x138]
03c1a9e8: 680100b4 cbz      x8, #0x3c1aa14
03c1a9ec: 89c242f8 ldur     x9, [x20, #0x2c]
03c1a9f0: 09c102f8 stur     x9, [x8, #0x2c]
03c1a9f4: 88ad0090 adrp     x8, #0x51ca000
03c1a9f8: 084d41f9 ldr      x8, [x8, #0x298]
03c1a9fc: e103132a mov      w1, w19
03c1aa00: f37b41a9 ldp      x19, x30, [sp, #0x10]
03c1aa04: e00314aa mov      x0, x20
03c1aa08: 020140f9 ldr      x2, [x8]
03c1aa0c: f553c2a8 ldp      x21, x20, [sp], #0x20
03c1aa10: b071ba17 b        #0x2ab70d0 ; Royal.Scenes.Game.Mechanics.Items.Config.FakeItemModel<object>$$GetExplodeScore
03c1aa14: 855a4e97 bl       #0xfb1428
