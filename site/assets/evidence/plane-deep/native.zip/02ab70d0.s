# Royal.Scenes.Game.Mechanics.Items.Config.FakeItemModel<object>$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02ab70d0: fe0f1ff8 str      x30, [sp, #-0x10]!
02ab70d4: 009c40f9 ldr      x0, [x0, #0x138]
02ab70d8: c00000b4 cbz      x0, #0x2ab70f0
02ab70dc: 080040f9 ldr      x8, [x0]
02ab70e0: 033542f9 ldr      x3, [x8, #0x468]
02ab70e4: 023942f9 ldr      x2, [x8, #0x470]
02ab70e8: fe0741f8 ldr      x30, [sp], #0x10
02ab70ec: 60001fd6 br       x3
02ab70f0: cee89397 bl       #0xfb1428
