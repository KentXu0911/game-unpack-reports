# Royal.Scenes.Game.Mechanics.Items.RadarItem.RadarItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02093f18: f553bea9 stp      x21, x20, [sp, #-0x20]!
02093f1c: f37b01a9 stp      x19, x30, [sp, #0x10]
02093f20: 080040f9 ldr      x8, [x0]
02093f24: f303012a mov      w19, w1
02093f28: f40300aa mov      x20, x0
02093f2c: 096542f9 ldr      x9, [x8, #0x4c8]
02093f30: 086942f9 ldr      x8, [x8, #0x4d0]
02093f34: e10308aa mov      x1, x8
02093f38: 20013fd6 blr      x9
02093f3c: 1f040071 cmp      w0, #1
02093f40: 0b010054 b.lt     #0x2093f60
02093f44: e003132a mov      w0, w19
02093f48: e1031faa mov      x1, xzr
02093f4c: 98c24b94 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02093f50: c0000036 tbz      w0, #0, #0x2093f68
02093f54: 14918f52 mov      w20, #0x7c88
02093f58: 7400a072 movk     w20, #3, lsl #16
02093f5c: 14000014 b        #0x2093fac
02093f60: f4031f2a mov      w20, wzr
02093f64: 12000014 b        #0x2093fac
02093f68: 803e40f9 ldr      x0, [x20, #0x78]
02093f6c: 800200b4 cbz      x0, #0x2093fbc
02093f70: 956a40b9 ldr      w21, [x20, #0x68]
02093f74: 14229f52 mov      w20, #0xf910
02093f78: e1031faa mov      x1, xzr
02093f7c: d400a072 movk     w20, #6, lsl #16
02093f80: 4c993294 bl       #0x2d3a4b0 ; Royal.Scenes.Game.Mechanics.Explode.IncomingExploderContainer$$GetIncomingCount
02093f84: a802004b sub      w8, w21, w0
02093f88: 1f050071 cmp      w8, #1
02093f8c: 01010054 b.ne     #0x2093fac
02093f90: e003132a mov      w0, w19
02093f94: e1031faa mov      x1, xzr
02093f98: 69c24b94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02093f9c: 28f58c52 mov      w8, #0x67a9
02093fa0: 1f000072 tst      w0, #1
02093fa4: 0803a072 movk     w8, #0x18, lsl #16
02093fa8: 1411941a csel     w20, w8, w20, ne
02093fac: f37b41a9 ldp      x19, x30, [sp, #0x10]
02093fb0: e003142a mov      w0, w20
02093fb4: f553c2a8 ldp      x21, x20, [sp], #0x20
02093fb8: c0035fd6 ret      
02093fbc: 1b75bc97 bl       #0xfb1428
