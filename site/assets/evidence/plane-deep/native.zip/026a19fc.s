# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$.ctor
# Linear span to next metadata entry; not a complete CFG.
026a19fc: f80f1cf8 str      x24, [sp, #-0x40]!
026a1a00: f75b01a9 stp      x23, x22, [sp, #0x10]
026a1a04: f55302a9 stp      x21, x20, [sp, #0x20]
026a1a08: f37b03a9 stp      x19, x30, [sp, #0x30]
026a1a0c: f67601f0 adrp     x22, #0x5580000
026a1a10: 975701f0 adrp     x23, #0x5194000
026a1a14: c8e24039 ldrb     w8, [x22, #0x38]
026a1a18: f78a46f9 ldr      x23, [x23, #0xd10]
026a1a1c: f503022a mov      w21, w2
026a1a20: f30301aa mov      x19, x1
026a1a24: f40300aa mov      x20, x0
026a1a28: e8010037 tbnz     w8, #0, #0x26a1a64
026a1a2c: 60590190 adrp     x0, #0x51cd000
026a1a30: 000446f9 ldr      x0, [x0, #0xc08]
026a1a34: 333ea497 bl       #0xfb1300
026a1a38: c05a01f0 adrp     x0, #0x51fc000
026a1a3c: 002047f9 ldr      x0, [x0, #0xe40]
026a1a40: 303ea497 bl       #0xfb1300
026a1a44: 205c01d0 adrp     x0, #0x5227000
026a1a48: 00d846f9 ldr      x0, [x0, #0xdb0]
026a1a4c: 2d3ea497 bl       #0xfb1300
026a1a50: 805701f0 adrp     x0, #0x5194000
026a1a54: 008846f9 ldr      x0, [x0, #0xd10]
026a1a58: 2a3ea497 bl       #0xfb1300
026a1a5c: 28008052 mov      w8, #1
026a1a60: c8e20039 strb     w8, [x22, #0x38]
026a1a64: e00240f9 ldr      x0, [x23]
026a1a68: 6c3ea497 bl       #0xfb1418
026a1a6c: 000500b4 cbz      x0, #0x26a1b0c
026a1a70: 285c01d0 adrp     x8, #0x5227000
026a1a74: 08d946f9 ldr      x8, [x8, #0xdb0]
026a1a78: 77590190 adrp     x23, #0x51cd000
026a1a7c: d85a01f0 adrp     x24, #0x51fc000
026a1a80: f60300aa mov      x22, x0
026a1a84: 010140f9 ldr      x1, [x8]
026a1a88: f70646f9 ldr      x23, [x23, #0xc08]
026a1a8c: 182347f9 ldr      x24, [x24, #0xe40]
026a1a90: fbb00c94 bl       #0x29cde7c ; System.Collections.Generic.List<object>$$.ctor
026a1a94: 80020491 add      x0, x20, #0x100
026a1a98: e10316aa mov      x1, x22
026a1a9c: 968200f9 str      x22, [x20, #0x100]
026a1aa0: 033ea497 bl       #0xfb12ac
026a1aa4: e00314aa mov      x0, x20
026a1aa8: e103152a mov      w1, w21
026a1aac: e2031faa mov      x2, xzr
026a1ab0: d9a63f94 bl       #0x368b614 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$.ctor
026a1ab4: e10240f9 ldr      x1, [x23]
026a1ab8: a0018052 mov      w0, #0xd
026a1abc: ce73fa97 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
026a1ac0: e10300aa mov      x1, x0
026a1ac4: e00314aa mov      x0, x20
026a1ac8: 010c0df8 str      x1, [x0, #0xd0]!
026a1acc: f83da497 bl       #0xfb12ac
026a1ad0: 010340f9 ldr      x1, [x24]
026a1ad4: e0018052 mov      w0, #0xf
026a1ad8: c773fa97 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
026a1adc: e10300aa mov      x1, x0
026a1ae0: e00314aa mov      x0, x20
026a1ae4: 018c0df8 str      x1, [x0, #0xd8]!
026a1ae8: f13da497 bl       #0xfb12ac
026a1aec: 930e0ef8 str      x19, [x20, #0xe0]!
026a1af0: e00314aa mov      x0, x20
026a1af4: e10313aa mov      x1, x19
026a1af8: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a1afc: f55342a9 ldp      x21, x20, [sp, #0x20]
026a1b00: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a1b04: f80744f8 ldr      x24, [sp], #0x40
026a1b08: e93da417 b        #0xfb12ac
026a1b0c: 473ea497 bl       #0xfb1428
