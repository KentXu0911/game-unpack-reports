# Royal.Scenes.Game.Mechanics.Items.RoyalBotItem.RoyalBotItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01ed0bd8: 086840b9 ldr      w8, [x0, #0x68]
01ed0bdc: 1f010071 cmp      w8, #0
01ed0be0: 08229f52 mov      w8, #0xf910
01ed0be4: c800a072 movk     w8, #6, lsl #16
01ed0be8: 00c19f1a csel     w0, w8, wzr, gt
01ed0bec: c0035fd6 ret      
