# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$IsComboExploder
# Linear span to next metadata entry; not a complete CFG.
033a300c: e0031f2a mov      w0, wzr
033a3010: c0035fd6 ret      
