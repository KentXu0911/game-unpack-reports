# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$InitializeCurveVariables
# Linear span to next metadata entry; not a complete CFG.
033a107c: ef3bb96d stp      d15, d14, [sp, #-0x70]!
033a1080: ed33016d stp      d13, d12, [sp, #0x10]
033a1084: eb2b026d stp      d11, d10, [sp, #0x20]
033a1088: e923036d stp      d9, d8, [sp, #0x30]
033a108c: f62300f9 str      x22, [sp, #0x40]
033a1090: f55305a9 stp      x21, x20, [sp, #0x50]
033a1094: f37b06a9 stp      x19, x30, [sp, #0x60]
033a1098: 340f01b0 adrp     x20, #0x5586000
033a109c: 88026739 ldrb     w8, [x20, #0x9c0]
033a10a0: f30300aa mov      x19, x0
033a10a4: 88010037 tbnz     w8, #0, #0x33a10d4
033a10a8: 60f400d0 adrp     x0, #0x522f000
033a10ac: 000445f9 ldr      x0, [x0, #0xa08]
033a10b0: 94407097 bl       #0xfb1300
033a10b4: c0ef0090 adrp     x0, #0x5199000
033a10b8: 008444f9 ldr      x0, [x0, #0x908]
033a10bc: 91407097 bl       #0xfb1300
033a10c0: 20f00090 adrp     x0, #0x51a5000
033a10c4: 006445f9 ldr      x0, [x0, #0xac8]
033a10c8: 8e407097 bl       #0xfb1300
033a10cc: 28008052 mov      w8, #1
033a10d0: 88022739 strb     w8, [x20, #0x9c0]
033a10d4: 602a40f9 ldr      x0, [x19, #0x50]
033a10d8: e02400b4 cbz      x0, #0x33a1574
033a10dc: e1031f2a mov      w1, wzr
033a10e0: e2031f2a mov      w2, wzr
033a10e4: e3031faa mov      x3, xzr
033a10e8: 25a10b94 bl       #0x368957c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$PlayStartFlyAnimation
033a10ec: a85a0090 adrp     x8, #0x3ef5000
033a10f0: 00dd47fd ldr      d0, [x8, #0xfb8]
033a10f4: e0031faa mov      x0, xzr
033a10f8: 7f2200b9 str      wzr, [x19, #0x20]
033a10fc: 600e00fd str      d0, [x19, #0x18]
033a1100: cac6ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a1104: 35008052 mov      w21, #1
033a1108: 602600bd str      s0, [x19, #0x24]
033a110c: 7f6e00b9 str      wzr, [x19, #0x6c]
033a1110: 758600b9 str      w21, [x19, #0x84]
033a1114: 75560239 strb     w21, [x19, #0x95]
033a1118: b40e01b0 adrp     x20, #0x5576000
033a111c: 88b27c39 ldrb     w8, [x20, #0xf2c]
033a1120: a8000035 cbnz     w8, #0x33a1134
033a1124: 40f400d0 adrp     x0, #0x522b000
033a1128: 00ac43f9 ldr      x0, [x0, #0x758]
033a112c: 75407097 bl       #0xfb1300
033a1130: 95b23c39 strb     w21, [x20, #0xf2c]
033a1134: 54f400d0 adrp     x20, #0x522b000
033a1138: 94ae43f9 ldr      x20, [x20, #0x758]
033a113c: 602e40f9 ldr      x0, [x19, #0x58]
033a1140: 880240f9 ldr      x8, [x20]
033a1144: 095d40f9 ldr      x9, [x8, #0xb8]
033a1148: 2a0140f9 ldr      x10, [x9]
033a114c: 290940b9 ldr      w9, [x9, #8]
033a1150: 6a2200f9 str      x10, [x19, #0x40]
033a1154: 694a00b9 str      w9, [x19, #0x48]
033a1158: 085d40f9 ldr      x8, [x8, #0xb8]
033a115c: 0af0a752 mov      w10, #0x3f800000
033a1160: 090140f9 ldr      x9, [x8]
033a1164: 080940b9 ldr      w8, [x8, #8]
033a1168: 75020239 strb     w21, [x19, #0x80]
033a116c: 6ab600b9 str      w10, [x19, #0xb4]
033a1170: 694600f9 str      x9, [x19, #0x88]
033a1174: 689200b9 str      w8, [x19, #0x90]
033a1178: e01f00b4 cbz      x0, #0x33a1574
033a117c: e1031faa mov      x1, xzr
033a1180: 2ba32594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
033a1184: 081ca04e mov      v8.16b, v0.16b
033a1188: 0c10201e fmov     s12, #2.00000000
033a118c: 0010231e fmov     s0, #6.00000000
033a1190: 602e40f9 ldr      x0, [x19, #0x58]
033a1194: 00212c1e fcmp     s8, s12
033a1198: e8579f1a cset     w8, mi
033a119c: 0021201e fcmp     s8, s0
033a11a0: e9d79f1a cset     w9, gt
033a11a4: 0801092a orr      w8, w8, w9
033a11a8: 68320139 strb     w8, [x19, #0x4c]
033a11ac: 401e00b4 cbz      x0, #0x33a1574
033a11b0: e1031faa mov      x1, xzr
033a11b4: 291ca14e mov      v9.16b, v1.16b
033a11b8: c1a42594 bl       #0x3d0a4bc ; UnityEngine.Transform$$get_parent
033a11bc: 763240f9 ldr      x22, [x19, #0x60]
033a11c0: b61d00b4 cbz      x22, #0x33a1574
033a11c4: 6af400d0 adrp     x10, #0x522f000
033a11c8: c80240f9 ldr      x8, [x22]
033a11cc: 4a0545f9 ldr      x10, [x10, #0xa08]
033a11d0: f50300aa mov      x21, x0
033a11d4: 09554279 ldrh     w9, [x8, #0x12a]
033a11d8: 410140f9 ldr      x1, [x10]
033a11dc: 290100b4 cbz      x9, #0x33a1200
033a11e0: 0a5940f9 ldr      x10, [x8, #0xb0]
033a11e4: 4a210091 add      x10, x10, #8
033a11e8: 4b815ff8 ldur     x11, [x10, #-8]
033a11ec: 7f0101eb cmp      x11, x1
033a11f0: 00010054 b.eq     #0x33a1210
033a11f4: 290500f1 subs     x9, x9, #1
033a11f8: 4a410091 add      x10, x10, #0x10
033a11fc: 61ffff54 b.ne     #0x33a11e8
033a1200: 22008052 mov      w2, #1
033a1204: e00316aa mov      x0, x22
033a1208: 33806f97 bl       #0xf812d4
033a120c: 05000014 b        #0x33a1220
033a1210: 490140b9 ldr      w9, [x10]
033a1214: 29050011 add      w9, w9, #1
033a1218: 08d1298b add      x8, x8, w9, sxtw #4
033a121c: 00e10491 add      x0, x8, #0x138
033a1220: 080440a9 ldp      x8, x1, [x0]
033a1224: e00316aa mov      x0, x22
033a1228: 00013fd6 blr      x8
033a122c: 551a00b4 cbz      x21, #0x33a1574
033a1230: e00315aa mov      x0, x21
033a1234: e1031faa mov      x1, xzr
033a1238: d3a72594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
033a123c: 68324139 ldrb     w8, [x19, #0x4c]
033a1240: 0a1ca04e mov      v10.16b, v0.16b
033a1244: 2b1ca14e mov      v11.16b, v1.16b
033a1248: b50e01f0 adrp     x21, #0x5578000
033a124c: 08020034 cbz      w8, #0x33a128c
033a1250: 00212c1e fcmp     s8, s12
033a1254: 05070054 b.pl     #0x33a1334
033a1258: a86e4539 ldrb     w8, [x21, #0x15b]
033a125c: c8000035 cbnz     w8, #0x33a1274
033a1260: 40f400d0 adrp     x0, #0x522b000
033a1264: 00ac43f9 ldr      x0, [x0, #0x758]
033a1268: 26407097 bl       #0xfb1300
033a126c: 28008052 mov      w8, #1
033a1270: a86e0539 strb     w8, [x21, #0x15b]
033a1274: 880240f9 ldr      x8, [x20]
033a1278: 0a5d40f9 ldr      x10, [x8, #0xb8]
033a127c: 48210191 add      x8, x10, #0x48
033a1280: 49310191 add      x9, x10, #0x4c
033a1284: 4a410191 add      x10, x10, #0x50
033a1288: 38000014 b        #0x33a1368
033a128c: a86e4539 ldrb     w8, [x21, #0x15b]
033a1290: c8000035 cbnz     w8, #0x33a12a8
033a1294: 40f400d0 adrp     x0, #0x522b000
033a1298: 00ac43f9 ldr      x0, [x0, #0x758]
033a129c: 19407097 bl       #0xfb1300
033a12a0: 28008052 mov      w8, #1
033a12a4: a86e0539 strb     w8, [x21, #0x15b]
033a12a8: 880240f9 ldr      x8, [x20]
033a12ac: 00102e1e fmov     s0, #1.00000000
033a12b0: 4021201e fcmp     s10, s0
033a12b4: 095d40f9 ldr      x9, [x8, #0xb8]
033a12b8: 2a2540f9 ldr      x10, [x9, #0x48]
033a12bc: 295140b9 ldr      w9, [x9, #0x50]
033a12c0: 6a1600f9 str      x10, [x19, #0x28]
033a12c4: 693200b9 str      w9, [x19, #0x30]
033a12c8: a5000054 b.pl     #0x33a12dc
033a12cc: 085d40f9 ldr      x8, [x8, #0xb8]
033a12d0: 092540f9 ldr      x9, [x8, #0x48]
033a12d4: 085140b9 ldr      w8, [x8, #0x50]
033a12d8: 0f000014 b        #0x33a1314
033a12dc: 0090231e fmov     s0, #7.00000000
033a12e0: 4021201e fcmp     s10, s0
033a12e4: ed010054 b.le     #0x33a1320
033a12e8: b50e01d0 adrp     x21, #0x5577000
033a12ec: a9627939 ldrb     w9, [x21, #0xe58]
033a12f0: c9000035 cbnz     w9, #0x33a1308
033a12f4: e00314aa mov      x0, x20
033a12f8: 02407097 bl       #0xfb1300
033a12fc: 880240f9 ldr      x8, [x20]
033a1300: 29008052 mov      w9, #1
033a1304: a9623939 strb     w9, [x21, #0xe58]
033a1308: 085d40f9 ldr      x8, [x8, #0xb8]
033a130c: 094145f8 ldur     x9, [x8, #0x54]
033a1310: 085d40b9 ldr      w8, [x8, #0x5c]
033a1314: 691600f9 str      x9, [x19, #0x28]
033a1318: 683200b9 str      w8, [x19, #0x30]
033a131c: 18000014 b        #0x33a137c
033a1320: e0031faa mov      x0, xzr
033a1324: 5bb00594 bl       #0x350d490 ; UnityEngine.Random$$get_value
033a1328: 01102c1e fmov     s1, #0.50000000
033a132c: 0020211e fcmp     s0, s1
033a1330: 44f9ff54 b.mi     #0x33a1258
033a1334: b50e01d0 adrp     x21, #0x5577000
033a1338: a8627939 ldrb     w8, [x21, #0xe58]
033a133c: c8000035 cbnz     w8, #0x33a1354
033a1340: 40f400d0 adrp     x0, #0x522b000
033a1344: 00ac43f9 ldr      x0, [x0, #0x758]
033a1348: ee3f7097 bl       #0xfb1300
033a134c: 28008052 mov      w8, #1
033a1350: a8623939 strb     w8, [x21, #0xe58]
033a1354: 880240f9 ldr      x8, [x20]
033a1358: 0a5d40f9 ldr      x10, [x8, #0xb8]
033a135c: 48510191 add      x8, x10, #0x54
033a1360: 49610191 add      x9, x10, #0x58
033a1364: 4a710191 add      x10, x10, #0x5c
033a1368: 080140b9 ldr      w8, [x8]
033a136c: 290140b9 ldr      w9, [x9]
033a1370: 4a0140b9 ldr      w10, [x10]
033a1374: 68260529 stp      w8, w9, [x19, #0x28]
033a1378: 6a3200b9 str      w10, [x19, #0x30]
033a137c: b40e01b0 adrp     x20, #0x5576000
033a1380: 88d27c39 ldrb     w8, [x20, #0xf34]
033a1384: c8000035 cbnz     w8, #0x33a139c
033a1388: 40f40090 adrp     x0, #0x5229000
033a138c: 001840f9 ldr      x0, [x0, #0x30]
033a1390: dc3f7097 bl       #0xfb1300
033a1394: 28008052 mov      w8, #1
033a1398: 88d23c39 strb     w8, [x20, #0xf34]
033a139c: 48f40090 adrp     x8, #0x5229000
033a13a0: 081940f9 ldr      x8, [x8, #0x30]
033a13a4: b40e01d0 adrp     x20, #0x5577000
033a13a8: 89665d39 ldrb     w9, [x20, #0x759]
033a13ac: 4c39281e fsub     s12, s10, s8
033a13b0: 080140f9 ldr      x8, [x8]
033a13b4: 6a39291e fsub     s10, s11, s9
033a13b8: 085d40f9 ldr      x8, [x8, #0xb8]
033a13bc: 0f39422d ldp      s15, s14, [x8, #0x10]
033a13c0: c9000035 cbnz     w9, #0x33a13d8
033a13c4: e0f200f0 adrp     x0, #0x5200000
033a13c8: 008c46f9 ldr      x0, [x0, #0xd18]
033a13cc: cd3f7097 bl       #0xfb1300
033a13d0: 28008052 mov      w8, #1
033a13d4: 88661d39 strb     w8, [x20, #0x759]
033a13d8: f4f200f0 adrp     x20, #0x5200000
033a13dc: 948e46f9 ldr      x20, [x20, #0xd18]
033a13e0: e0092f1e fmul     s0, s15, s15
033a13e4: c1092e1e fmul     s1, s14, s14
033a13e8: 0b28211e fadd     s11, s0, s1
033a13ec: 800240f9 ldr      x0, [x20]
033a13f0: 80092c1e fmul     s0, s12, s12
033a13f4: 41092a1e fmul     s1, s10, s10
033a13f8: 0d28211e fadd     s13, s0, s1
033a13fc: 08e040b9 ldr      w8, [x0, #0xe0]
033a1400: 48000035 cbnz     w8, #0x33a1408
033a1404: 00407097 bl       #0xfb1404
033a1408: 885600d0 adrp     x8, #0x3e73000
033a140c: 028d4bbd ldr      s2, [x8, #0xb8c]
033a1410: a0092b1e fmul     s0, s13, s11
033a1414: 01c0211e fsqrt    s1, s0
033a1418: e003271e fmov     s0, wzr
033a141c: 2020221e fcmp     s1, s2
033a1420: 0b103e1e fmov     s11, #-1.00000000
033a1424: 64020054 b.mi     #0x33a1470
033a1428: 800240f9 ldr      x0, [x20]
033a142c: 80092f1e fmul     s0, s12, s15
033a1430: 42092e1e fmul     s2, s10, s14
033a1434: 0028221e fadd     s0, s0, s2
033a1438: 08e040b9 ldr      w8, [x0, #0xe0]
033a143c: 0018211e fdiv     s0, s0, s1
033a1440: 01102e1e fmov     s1, #1.00000000
033a1444: 0158211e fmin     s1, s0, s1
033a1448: 00202b1e fcmp     s0, s11
033a144c: 2d5c2b1e fcsel    s13, s1, s11, pl
033a1450: 48000035 cbnz     w8, #0x33a1458
033a1454: ec3f7097 bl       #0xfb1404
033a1458: a0c1221e fcvt     d0, s13
033a145c: 59866497 bl       #0xcc2dc0
033a1460: 885600d0 adrp     x8, #0x3e73000
033a1464: 01914bbd ldr      s1, [x8, #0xb90]
033a1468: 0040621e fcvt     s0, d0
033a146c: 0008211e fmul     s0, s0, s1
033a1470: 41092f1e fmul     s1, s10, s15
033a1474: 82092e1e fmul     s2, s12, s14
033a1478: 2138221e fsub     s1, s1, s2
033a147c: 2820201e fcmp     s1, #0.0
033a1480: 01102e1e fmov     s1, #1.00000000
033a1484: 21ac2b1e fcsel    s1, s1, s11, ge
033a1488: 602a40f9 ldr      x0, [x19, #0x50]
033a148c: 2008201e fmul     s0, s1, s0
033a1490: 0820201e fcmp     s0, #0.0
033a1494: e8d79f1a cset     w8, gt
033a1498: 68c20239 strb     w8, [x19, #0xb0]
033a149c: c00600b4 cbz      x0, #0x33a1574
033a14a0: 34f00090 adrp     x20, #0x51a5000
033a14a4: 946645f9 ldr      x20, [x20, #0xac8]
033a14a8: 0820201e fcmp     s0, #0.0
033a14ac: e1d79f1a cset     w1, gt
033a14b0: e2031faa mov      x2, xzr
033a14b4: 6cbcbf97 bl       #0x2390664 ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$StartFlyAnimationForDirection
033a14b8: 800240f9 ldr      x0, [x20]
033a14bc: 742a40f9 ldr      x20, [x19, #0x50]
033a14c0: 08e040b9 ldr      w8, [x0, #0xe0]
033a14c4: 48000035 cbnz     w8, #0x33a14cc
033a14c8: cf3f7097 bl       #0xfb1404
033a14cc: e0031f2a mov      w0, wzr
033a14d0: e1031f2a mov      w1, wzr
033a14d4: e2031faa mov      x2, xzr
033a14d8: be477f97 bl       #0x13733d0 ; Royal.Scenes.Game.Mechanics.Sortings.Sorting$$GetPropellerFlyingSorting
033a14dc: d40400b4 cbz      x20, #0x33a1574
033a14e0: d5ef0090 adrp     x21, #0x5199000
033a14e4: b58644f9 ldr      x21, [x21, #0x908]
033a14e8: e30300aa mov      x3, x0
033a14ec: 227c4092 and      x2, x1, #0xffffffff
033a14f0: e00314aa mov      x0, x20
033a14f4: e10303aa mov      x1, x3
033a14f8: e3031f2a mov      w3, wzr
033a14fc: e4031faa mov      x4, xzr
033a1500: f2bbff97 bl       #0x33904c8 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$UpdateSortingForAnimation
033a1504: a10240f9 ldr      x1, [x21]
033a1508: e00b8052 mov      w0, #0x5f
033a150c: 5875c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a1510: 200300b4 cbz      x0, #0x33a1574
033a1514: 001da84e mov      v0.16b, v8.16b
033a1518: 211da94e mov      v1.16b, v9.16b
033a151c: 821dac4e mov      v2.16b, v12.16b
033a1520: 431daa4e mov      v3.16b, v10.16b
033a1524: e1031faa mov      x1, xzr
033a1528: 57b8bf97 bl       #0x238f684 ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemHelper$$AddToBoomerangFlightData
033a152c: 40010036 tbz      w0, #0, #0x33a1554
033a1530: 885600d0 adrp     x8, #0x3e73000
033a1534: 295600d0 adrp     x9, #0x3e67000
033a1538: 00c948bd ldr      s0, [x8, #0x8c8]
033a153c: 213544bd ldr      s1, [x9, #0x434]
033a1540: 68b640bd ldr      s8, [x19, #0xb4]
033a1544: e0031faa mov      x0, xzr
033a1548: a0af0594 bl       #0x350d3c8 ; UnityEngine.Random$$Range
033a154c: 0029201e fadd     s0, s8, s0
033a1550: 60b600bd str      s0, [x19, #0xb4]
033a1554: f37b46a9 ldp      x19, x30, [sp, #0x60]
033a1558: f55345a9 ldp      x21, x20, [sp, #0x50]
033a155c: f62340f9 ldr      x22, [sp, #0x40]
033a1560: e923436d ldp      d9, d8, [sp, #0x30]
033a1564: eb2b426d ldp      d11, d10, [sp, #0x20]
033a1568: ed33416d ldp      d13, d12, [sp, #0x10]
033a156c: ef3bc76c ldp      d15, d14, [sp], #0x70
033a1570: c0035fd6 ret      
033a1574: ad3f7097 bl       #0xfb1428
