# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$SetRestoredData
# Linear span to next metadata entry; not a complete CFG.
03397a3c: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
03397a40: e1031faa mov      x1, xzr
03397a44: f30300aa mov      x19, x0
03397a48: 2fdbff97 bl       #0x338e704 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$SetRestoredData
03397a4c: 28008052 mov      w8, #1
03397a50: 68420539 strb     w8, [x19, #0x150]
03397a54: f37bc1a8 ldp      x19, x30, [sp], #0x10
03397a58: c0035fd6 ret      
