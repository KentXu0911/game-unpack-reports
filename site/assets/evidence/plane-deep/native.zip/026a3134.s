# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$UpdateStrategy
# Linear span to next metadata entry; not a complete CFG.
026a3134: 010c0ef8 str      x1, [x0, #0xe0]!
026a3138: 5d38a417 b        #0xfb12ac
