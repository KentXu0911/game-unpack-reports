# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$get_TargetItem
# Linear span to next metadata entry; not a complete CFG.
026a1b50: 00a440f9 ldr      x0, [x0, #0x148]
026a1b54: c0035fd6 ret      
