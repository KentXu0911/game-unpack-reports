# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$CalculateRedirectAngleVariables
# Linear span to next metadata entry; not a complete CFG.
0339d0fc: ffc302d1 sub      sp, sp, #0xb0
0339d100: ef3b026d stp      d15, d14, [sp, #0x20]
0339d104: ed33036d stp      d13, d12, [sp, #0x30]
0339d108: eb2b046d stp      d11, d10, [sp, #0x40]
0339d10c: e923056d stp      d9, d8, [sp, #0x50]
0339d110: fb6b06a9 stp      x27, x26, [sp, #0x60]
0339d114: f96307a9 stp      x25, x24, [sp, #0x70]
0339d118: f75b08a9 stp      x23, x22, [sp, #0x80]
0339d11c: f55309a9 stp      x21, x20, [sp, #0x90]
0339d120: f37b0aa9 stp      x19, x30, [sp, #0xa0]
0339d124: 540f01b0 adrp     x20, #0x5586000
0339d128: 88ce6639 ldrb     w8, [x20, #0x9b3]
0339d12c: f30300aa mov      x19, x0
0339d130: c8000037 tbnz     w8, #0, #0x339d148
0339d134: 80f400d0 adrp     x0, #0x522f000
0339d138: 000445f9 ldr      x0, [x0, #0xa08]
0339d13c: 71507097 bl       #0xfb1300
0339d140: 28008052 mov      w8, #1
0339d144: 88ce2639 strb     w8, [x20, #0x9b3]
0339d148: 743240f9 ldr      x20, [x19, #0x60]
0339d14c: f42f00b4 cbz      x20, #0x339d748
0339d150: 8af400d0 adrp     x10, #0x522f000
0339d154: 880240f9 ldr      x8, [x20]
0339d158: 4a0545f9 ldr      x10, [x10, #0xa08]
0339d15c: 09554279 ldrh     w9, [x8, #0x12a]
0339d160: 410140f9 ldr      x1, [x10]
0339d164: 290100b4 cbz      x9, #0x339d188
0339d168: 0a5940f9 ldr      x10, [x8, #0xb0]
0339d16c: 4a210091 add      x10, x10, #8
0339d170: 4b815ff8 ldur     x11, [x10, #-8]
0339d174: 7f0101eb cmp      x11, x1
0339d178: 00010054 b.eq     #0x339d198
0339d17c: 290500f1 subs     x9, x9, #1
0339d180: 4a410091 add      x10, x10, #0x10
0339d184: 61ffff54 b.ne     #0x339d170
0339d188: 22008052 mov      w2, #1
0339d18c: e00314aa mov      x0, x20
0339d190: 51906f97 bl       #0xf812d4
0339d194: 05000014 b        #0x339d1a8
0339d198: 490140b9 ldr      w9, [x10]
0339d19c: 29050011 add      w9, w9, #1
0339d1a0: 08d1298b add      x8, x8, w9, sxtw #4
0339d1a4: 00e10491 add      x0, x8, #0x138
0339d1a8: 080440a9 ldp      x8, x1, [x0]
0339d1ac: e00314aa mov      x0, x20
0339d1b0: 00013fd6 blr      x8
0339d1b4: 602e40f9 ldr      x0, [x19, #0x58]
0339d1b8: 802c00b4 cbz      x0, #0x339d748
0339d1bc: e1031faa mov      x1, xzr
0339d1c0: 081ca04e mov      v8.16b, v0.16b
0339d1c4: 291ca14e mov      v9.16b, v1.16b
0339d1c8: 4a1ca24e mov      v10.16b, v2.16b
0339d1cc: cab22594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339d1d0: d70e01d0 adrp     x23, #0x5577000
0339d1d4: e8fa7f39 ldrb     w8, [x23, #0xffe]
0339d1d8: 0b1ca04e mov      v11.16b, v0.16b
0339d1dc: 2c1ca14e mov      v12.16b, v1.16b
0339d1e0: 4d1ca24e mov      v13.16b, v2.16b
0339d1e4: c8000035 cbnz     w8, #0x339d1fc
0339d1e8: 00f300f0 adrp     x0, #0x5200000
0339d1ec: 008c46f9 ldr      x0, [x0, #0xd18]
0339d1f0: 44507097 bl       #0xfb1300
0339d1f4: 28008052 mov      w8, #1
0339d1f8: e8fa3f39 strb     w8, [x23, #0xffe]
0339d1fc: 15f300f0 adrp     x21, #0x5200000
0339d200: b58e46f9 ldr      x21, [x21, #0xd18]
0339d204: 0b392b1e fsub     s11, s8, s11
0339d208: 29392c1e fsub     s9, s9, s12
0339d20c: 48392d1e fsub     s8, s10, s13
0339d210: a00240f9 ldr      x0, [x21]
0339d214: 08e040b9 ldr      w8, [x0, #0xe0]
0339d218: 48000035 cbnz     w8, #0x339d220
0339d21c: 7a507097 bl       #0xfb1404
0339d220: a85600d0 adrp     x8, #0x3e73000
0339d224: 60092b1e fmul     s0, s11, s11
0339d228: 2109291e fmul     s1, s9, s9
0339d22c: 0f894bbd ldr      s15, [x8, #0xb88]
0339d230: 74f400d0 adrp     x20, #0x522b000
0339d234: 0209281e fmul     s2, s8, s8
0339d238: 0028211e fadd     s0, s0, s1
0339d23c: 94ae43f9 ldr      x20, [x20, #0x758]
0339d240: 4028201e fadd     s0, s2, s0
0339d244: 00c0211e fsqrt    s0, s0
0339d248: 00202f1e fcmp     s0, s15
0339d24c: d60e01b0 adrp     x22, #0x5576000
0339d250: ed000054 b.le     #0x339d26c
0339d254: 6119201e fdiv     s1, s11, s0
0339d258: e11b00bd str      s1, [sp, #0x18]
0339d25c: 2119201e fdiv     s1, s9, s0
0339d260: e11700bd str      s1, [sp, #0x14]
0339d264: 0019201e fdiv     s0, s8, s0
0339d268: 0f000014 b        #0x339d2a4
0339d26c: c8b27c39 ldrb     w8, [x22, #0xf2c]
0339d270: c8000035 cbnz     w8, #0x339d288
0339d274: 60f400d0 adrp     x0, #0x522b000
0339d278: 00ac43f9 ldr      x0, [x0, #0x758]
0339d27c: 21507097 bl       #0xfb1300
0339d280: 28008052 mov      w8, #1
0339d284: c8b23c39 strb     w8, [x22, #0xf2c]
0339d288: 880240f9 ldr      x8, [x20]
0339d28c: 085d40f9 ldr      x8, [x8, #0xb8]
0339d290: 000140bd ldr      s0, [x8]
0339d294: e01b00bd str      s0, [sp, #0x18]
0339d298: 000540bd ldr      s0, [x8, #4]
0339d29c: e01700bd str      s0, [sp, #0x14]
0339d2a0: 000940bd ldr      s0, [x8, #8]
0339d2a4: 602e40f9 ldr      x0, [x19, #0x58]
0339d2a8: e01f00bd str      s0, [sp, #0x1c]
0339d2ac: e02400b4 cbz      x0, #0x339d748
0339d2b0: e1031faa mov      x1, xzr
0339d2b4: ef1300bd str      s15, [sp, #0x10]
0339d2b8: d0b32594 bl       #0x3d0a1f8 ; UnityEngine.Transform$$get_forward
0339d2bc: 602e40f9 ldr      x0, [x19, #0x58]
0339d2c0: 402400b4 cbz      x0, #0x339d748
0339d2c4: e1031faa mov      x1, xzr
0339d2c8: 081ca04e mov      v8.16b, v0.16b
0339d2cc: 291ca14e mov      v9.16b, v1.16b
0339d2d0: 4a1ca24e mov      v10.16b, v2.16b
0339d2d4: 30b32594 bl       #0x3d09f94 ; UnityEngine.Transform$$get_rotation
0339d2d8: d80e01b0 adrp     x24, #0x5576000
0339d2dc: 08bb7c39 ldrb     w8, [x24, #0xf2e]
0339d2e0: 0b1ca04e mov      v11.16b, v0.16b
0339d2e4: 2c1ca14e mov      v12.16b, v1.16b
0339d2e8: 4d1ca24e mov      v13.16b, v2.16b
0339d2ec: 6e1ca34e mov      v14.16b, v3.16b
0339d2f0: c8000035 cbnz     w8, #0x339d308
0339d2f4: 60f400d0 adrp     x0, #0x522b000
0339d2f8: 00ac43f9 ldr      x0, [x0, #0x758]
0339d2fc: 01507097 bl       #0xfb1300
0339d300: 28008052 mov      w8, #1
0339d304: 08bb3c39 strb     w8, [x24, #0xf2e]
0339d308: 880240f9 ldr      x8, [x20]
0339d30c: 601dab4e mov      v0.16b, v11.16b
0339d310: 811dac4e mov      v1.16b, v12.16b
0339d314: a21dad4e mov      v2.16b, v13.16b
0339d318: 085d40f9 ldr      x8, [x8, #0xb8]
0339d31c: c31dae4e mov      v3.16b, v14.16b
0339d320: e0031faa mov      x0, xzr
0339d324: 0415432d ldp      s4, s5, [x8, #0x18]
0339d328: 062140bd ldr      s6, [x8, #0x20]
0339d32c: 239f0594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339d330: 390f01f0 adrp     x25, #0x5584000
0339d334: 28ff4f39 ldrb     w8, [x25, #0x3ff]
0339d338: 0b1ca04e mov      v11.16b, v0.16b
0339d33c: 2c1ca14e mov      v12.16b, v1.16b
0339d340: 4d1ca24e mov      v13.16b, v2.16b
0339d344: c8000035 cbnz     w8, #0x339d35c
0339d348: 00f300f0 adrp     x0, #0x5200000
0339d34c: 008c46f9 ldr      x0, [x0, #0xd18]
0339d350: ec4f7097 bl       #0xfb1300
0339d354: 28008052 mov      w8, #1
0339d358: 28ff0f39 strb     w8, [x25, #0x3ff]
0339d35c: e183422d ldp      s1, s0, [sp, #0x14]
0339d360: a00240f9 ldr      x0, [x21]
0339d364: 0008201e fmul     s0, s0, s0
0339d368: 2108211e fmul     s1, s1, s1
0339d36c: 0028211e fadd     s0, s0, s1
0339d370: e11f40bd ldr      s1, [sp, #0x1c]
0339d374: 08e040b9 ldr      w8, [x0, #0xe0]
0339d378: 2108211e fmul     s1, s1, s1
0339d37c: 2f28201e fadd     s15, s1, s0
0339d380: 0009281e fmul     s0, s8, s8
0339d384: 2109291e fmul     s1, s9, s9
0339d388: 0028211e fadd     s0, s0, s1
0339d38c: 41092a1e fmul     s1, s10, s10
0339d390: 2e28201e fadd     s14, s1, s0
0339d394: 48000035 cbnz     w8, #0x339d39c
0339d398: 1b507097 bl       #0xfb1404
0339d39c: a85600d0 adrp     x8, #0x3e73000
0339d3a0: 028d4bbd ldr      s2, [x8, #0xb8c]
0339d3a4: e1092e1e fmul     s1, s15, s14
0339d3a8: 21c0211e fsqrt    s1, s1
0339d3ac: ef0f00bd str      s15, [sp, #0xc]
0339d3b0: e003271e fmov     s0, wzr
0339d3b4: 0e102e1e fmov     s14, #1.00000000
0339d3b8: 2020221e fcmp     s1, s2
0339d3bc: 0f103e1e fmov     s15, #-1.00000000
0339d3c0: b85600d0 adrp     x24, #0x3e73000
0339d3c4: e20b00bd str      s2, [sp, #8]
0339d3c8: e4020054 b.mi     #0x339d424
0339d3cc: e283422d ldp      s2, s0, [sp, #0x14]
0339d3d0: a00240f9 ldr      x0, [x21]
0339d3d4: 0008281e fmul     s0, s0, s8
0339d3d8: 4208291e fmul     s2, s2, s9
0339d3dc: 0028221e fadd     s0, s0, s2
0339d3e0: e21f40bd ldr      s2, [sp, #0x1c]
0339d3e4: 08e040b9 ldr      w8, [x0, #0xe0]
0339d3e8: 42082a1e fmul     s2, s2, s10
0339d3ec: 4028201e fadd     s0, s2, s0
0339d3f0: 0018211e fdiv     s0, s0, s1
0339d3f4: 01582e1e fmin     s1, s0, s14
0339d3f8: 00202f1e fcmp     s0, s15
0339d3fc: 2e5c2f1e fcsel    s14, s1, s15, pl
0339d400: e21daf4e mov      v2.16b, v15.16b
0339d404: 48000035 cbnz     w8, #0x339d40c
0339d408: ff4f7097 bl       #0xfb1404
0339d40c: c0c1221e fcvt     d0, s14
0339d410: 6c966497 bl       #0xcc2dc0
0339d414: 01934bbd ldr      s1, [x24, #0xb90]
0339d418: 0040621e fcvt     s0, d0
0339d41c: 0e102e1e fmov     s14, #1.00000000
0339d420: 0008211e fmul     s0, s0, s1
0339d424: e593422d ldp      s5, s4, [sp, #0x14]
0339d428: e31f40bd ldr      s3, [sp, #0x1c]
0339d42c: da0e01f0 adrp     x26, #0x5578000
0339d430: a1082a1e fmul     s1, s5, s10
0339d434: 6208291e fmul     s2, s3, s9
0339d438: 2138221e fsub     s1, s1, s2
0339d43c: 6208281e fmul     s2, s3, s8
0339d440: 83082a1e fmul     s3, s4, s10
0339d444: 8408291e fmul     s4, s4, s9
0339d448: a508281e fmul     s5, s5, s8
0339d44c: 4238231e fsub     s2, s2, s3
0339d450: 8338251e fsub     s3, s4, s5
0339d454: 21082b1e fmul     s1, s1, s11
0339d458: 42082c1e fmul     s2, s2, s12
0339d45c: 2128221e fadd     s1, s1, s2
0339d460: 62082d1e fmul     s2, s3, s13
0339d464: 4128211e fadd     s1, s2, s1
0339d468: 2820201e fcmp     s1, #0.0
0339d46c: c1ad2f1e fcsel    s1, s14, s15, ge
0339d470: 2008201e fmul     s0, s1, s0
0339d474: 0820201e fcmp     s0, #0.0
0339d478: e5010054 b.pl     #0x339d4b4
0339d47c: 486f4539 ldrb     w8, [x26, #0x15b]
0339d480: ec1340bd ldr      s12, [sp, #0x10]
0339d484: c8000035 cbnz     w8, #0x339d49c
0339d488: 60f400d0 adrp     x0, #0x522b000
0339d48c: 00ac43f9 ldr      x0, [x0, #0x758]
0339d490: 9c4f7097 bl       #0xfb1300
0339d494: 28008052 mov      w8, #1
0339d498: 486f0539 strb     w8, [x26, #0x15b]
0339d49c: 880240f9 ldr      x8, [x20]
0339d4a0: 0b5d40f9 ldr      x11, [x8, #0xb8]
0339d4a4: 69210191 add      x9, x11, #0x48
0339d4a8: 6a310191 add      x10, x11, #0x4c
0339d4ac: 6b410191 add      x11, x11, #0x50
0339d4b0: 18000014 b        #0x339d510
0339d4b4: ec1340bd ldr      s12, [sp, #0x10]
0339d4b8: db0e01d0 adrp     x27, #0x5577000
0339d4bc: 2c010054 b.gt     #0x339d4e0
0339d4c0: 605640f9 ldr      x0, [x19, #0xa8]
0339d4c4: 201400b4 cbz      x0, #0x339d748
0339d4c8: e1031faa mov      x1, xzr
0339d4cc: 5e43cf97 bl       #0x276e244 ; Royal.Infrastructure.Utils.Randoming.RandomManager$$NextBool
0339d4d0: 80000036 tbz      w0, #0, #0x339d4e0
0339d4d4: 486f4539 ldrb     w8, [x26, #0x15b]
0339d4d8: 28feff35 cbnz     w8, #0x339d49c
0339d4dc: ebffff17 b        #0x339d488
0339d4e0: 68637939 ldrb     w8, [x27, #0xe58]
0339d4e4: c8000035 cbnz     w8, #0x339d4fc
0339d4e8: 60f400d0 adrp     x0, #0x522b000
0339d4ec: 00ac43f9 ldr      x0, [x0, #0x758]
0339d4f0: 844f7097 bl       #0xfb1300
0339d4f4: 28008052 mov      w8, #1
0339d4f8: 68633939 strb     w8, [x27, #0xe58]
0339d4fc: 880240f9 ldr      x8, [x20]
0339d500: 0b5d40f9 ldr      x11, [x8, #0xb8]
0339d504: 69510191 add      x9, x11, #0x54
0339d508: 6a610191 add      x10, x11, #0x58
0339d50c: 6b710191 add      x11, x11, #0x5c
0339d510: 290140b9 ldr      w9, [x9]
0339d514: 4a0140b9 ldr      w10, [x10]
0339d518: 6b0140b9 ldr      w11, [x11]
0339d51c: 684240bd ldr      s8, [x19, #0x40]
0339d520: 694244fc ldur     d9, [x19, #0x44]
0339d524: 692a0529 stp      w9, w10, [x19, #0x28]
0339d528: 6b3200b9 str      w11, [x19, #0x30]
0339d52c: c9b27c39 ldrb     w9, [x22, #0xf2c]
0339d530: c9000035 cbnz     w9, #0x339d548
0339d534: e00314aa mov      x0, x20
0339d538: 724f7097 bl       #0xfb1300
0339d53c: 880240f9 ldr      x8, [x20]
0339d540: 29008052 mov      w9, #1
0339d544: c9b23c39 strb     w9, [x22, #0xf2c]
0339d548: 085d40f9 ldr      x8, [x8, #0xb8]
0339d54c: 000140bd ldr      s0, [x8]
0339d550: 014140fc ldur     d1, [x8, #4]
0339d554: a85600d0 adrp     x8, #0x3e73000
0339d558: 02314bbd ldr      s2, [x8, #0xb30]
0339d55c: 0039201e fsub     s0, s8, s0
0339d560: 21d5a10e fsub     v1.2s, v9.2s, v1.2s
0339d564: 0008201e fmul     s0, s0, s0
0339d568: 21dc212e fmul     v1.2s, v1.2s, v1.2s
0339d56c: 0028211e fadd     s0, s0, s1
0339d570: 21040c5e mov      s1, v1.s[1]
0339d574: 2028201e fadd     s0, s1, s0
0339d578: 0020221e fcmp     s0, s2
0339d57c: 25030054 b.pl     #0x339d5e0
0339d580: 682a582d ldp      s8, s10, [x19, #0xc0]
0339d584: e8fa7f39 ldrb     w8, [x23, #0xffe]
0339d588: 6bca40bd ldr      s11, [x19, #0xc8]
0339d58c: c8000035 cbnz     w8, #0x339d5a4
0339d590: 00f300f0 adrp     x0, #0x5200000
0339d594: 008c46f9 ldr      x0, [x0, #0xd18]
0339d598: 5a4f7097 bl       #0xfb1300
0339d59c: 28008052 mov      w8, #1
0339d5a0: e8fa3f39 strb     w8, [x23, #0xffe]
0339d5a4: a00240f9 ldr      x0, [x21]
0339d5a8: 08e040b9 ldr      w8, [x0, #0xe0]
0339d5ac: 48000035 cbnz     w8, #0x339d5b4
0339d5b0: 954f7097 bl       #0xfb1404
0339d5b4: 0009281e fmul     s0, s8, s8
0339d5b8: 41092a1e fmul     s1, s10, s10
0339d5bc: 0028211e fadd     s0, s0, s1
0339d5c0: 61092b1e fmul     s1, s11, s11
0339d5c4: 2028201e fadd     s0, s1, s0
0339d5c8: 00c0211e fsqrt    s0, s0
0339d5cc: 00202c1e fcmp     s0, s12
0339d5d0: ad030054 b.le     #0x339d644
0339d5d4: 0919201e fdiv     s9, s8, s0
0339d5d8: 4a19201e fdiv     s10, s10, s0
0339d5dc: 18000014 b        #0x339d63c
0339d5e0: 6922482d ldp      s9, s8, [x19, #0x40]
0339d5e4: e8fa7f39 ldrb     w8, [x23, #0xffe]
0339d5e8: 6b4a40bd ldr      s11, [x19, #0x48]
0339d5ec: c8000035 cbnz     w8, #0x339d604
0339d5f0: 00f300f0 adrp     x0, #0x5200000
0339d5f4: 008c46f9 ldr      x0, [x0, #0xd18]
0339d5f8: 424f7097 bl       #0xfb1300
0339d5fc: 28008052 mov      w8, #1
0339d600: e8fa3f39 strb     w8, [x23, #0xffe]
0339d604: a00240f9 ldr      x0, [x21]
0339d608: 08e040b9 ldr      w8, [x0, #0xe0]
0339d60c: 48000035 cbnz     w8, #0x339d614
0339d610: 7d4f7097 bl       #0xfb1404
0339d614: 2009291e fmul     s0, s9, s9
0339d618: 0109281e fmul     s1, s8, s8
0339d61c: 0028211e fadd     s0, s0, s1
0339d620: 61092b1e fmul     s1, s11, s11
0339d624: 2028201e fadd     s0, s1, s0
0339d628: 00c0211e fsqrt    s0, s0
0339d62c: 00202c1e fcmp     s0, s12
0339d630: ad000054 b.le     #0x339d644
0339d634: 2919201e fdiv     s9, s9, s0
0339d638: 0a19201e fdiv     s10, s8, s0
0339d63c: 6819201e fdiv     s8, s11, s0
0339d640: 0c000014 b        #0x339d670
0339d644: c8b27c39 ldrb     w8, [x22, #0xf2c]
0339d648: c8000035 cbnz     w8, #0x339d660
0339d64c: 60f400d0 adrp     x0, #0x522b000
0339d650: 00ac43f9 ldr      x0, [x0, #0x758]
0339d654: 2b4f7097 bl       #0xfb1300
0339d658: 28008052 mov      w8, #1
0339d65c: c8b23c39 strb     w8, [x22, #0xf2c]
0339d660: 880240f9 ldr      x8, [x20]
0339d664: 085d40f9 ldr      x8, [x8, #0xb8]
0339d668: 0929402d ldp      s9, s10, [x8]
0339d66c: 080940bd ldr      s8, [x8, #8]
0339d670: 28ff4f39 ldrb     w8, [x25, #0x3ff]
0339d674: c8000035 cbnz     w8, #0x339d68c
0339d678: 00f300f0 adrp     x0, #0x5200000
0339d67c: 008c46f9 ldr      x0, [x0, #0xd18]
0339d680: 204f7097 bl       #0xfb1300
0339d684: 28008052 mov      w8, #1
0339d688: 28ff0f39 strb     w8, [x25, #0x3ff]
0339d68c: a00240f9 ldr      x0, [x21]
0339d690: 2009291e fmul     s0, s9, s9
0339d694: 41092a1e fmul     s1, s10, s10
0339d698: 2028201e fadd     s0, s1, s0
0339d69c: 08e040b9 ldr      w8, [x0, #0xe0]
0339d6a0: 0109281e fmul     s1, s8, s8
0339d6a4: 2b28201e fadd     s11, s1, s0
0339d6a8: 48000035 cbnz     w8, #0x339d6b0
0339d6ac: 564f7097 bl       #0xfb1404
0339d6b0: e103412d ldp      s1, s0, [sp, #8]
0339d6b4: 00082b1e fmul     s0, s0, s11
0339d6b8: 00c0211e fsqrt    s0, s0
0339d6bc: 0020211e fcmp     s0, s1
0339d6c0: e103271e fmov     s1, wzr
0339d6c4: a4020054 b.mi     #0x339d718
0339d6c8: e287422d ldp      s2, s1, [sp, #0x14]
0339d6cc: a00240f9 ldr      x0, [x21]
0339d6d0: 2108291e fmul     s1, s1, s9
0339d6d4: 42082a1e fmul     s2, s2, s10
0339d6d8: 4128211e fadd     s1, s2, s1
0339d6dc: e21f40bd ldr      s2, [sp, #0x1c]
0339d6e0: 08e040b9 ldr      w8, [x0, #0xe0]
0339d6e4: 4208281e fmul     s2, s2, s8
0339d6e8: 4128211e fadd     s1, s2, s1
0339d6ec: 2018201e fdiv     s0, s1, s0
0339d6f0: 01582e1e fmin     s1, s0, s14
0339d6f4: 00202f1e fcmp     s0, s15
0339d6f8: 285c2f1e fcsel    s8, s1, s15, pl
0339d6fc: 48000035 cbnz     w8, #0x339d704
0339d700: 414f7097 bl       #0xfb1404
0339d704: 00c1221e fcvt     d0, s8
0339d708: ae956497 bl       #0xcc2dc0
0339d70c: 01934bbd ldr      s1, [x24, #0xb90]
0339d710: 0040621e fcvt     s0, d0
0339d714: 0108211e fmul     s1, s0, s1
0339d718: 611e00bd str      s1, [x19, #0x1c]
0339d71c: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
0339d720: f55349a9 ldp      x21, x20, [sp, #0x90]
0339d724: f75b48a9 ldp      x23, x22, [sp, #0x80]
0339d728: f96347a9 ldp      x25, x24, [sp, #0x70]
0339d72c: fb6b46a9 ldp      x27, x26, [sp, #0x60]
0339d730: e923456d ldp      d9, d8, [sp, #0x50]
0339d734: eb2b446d ldp      d11, d10, [sp, #0x40]
0339d738: ed33436d ldp      d13, d12, [sp, #0x30]
0339d73c: ef3b426d ldp      d15, d14, [sp, #0x20]
0339d740: ffc30291 add      sp, sp, #0xb0
0339d744: c0035fd6 ret      
0339d748: 384f7097 bl       #0xfb1428
