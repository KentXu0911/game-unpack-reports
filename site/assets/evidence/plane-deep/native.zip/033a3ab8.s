# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerNoExplodeStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a3ab8: e80f1efc str      d8, [sp, #-0x20]!
033a3abc: f40700f9 str      x20, [sp, #8]
033a3ac0: f37b01a9 stp      x19, x30, [sp, #0x10]
033a3ac4: 34000012 and      w20, w1, #1
033a3ac8: e1031f2a mov      w1, wzr
033a3acc: 081ca04e mov      v8.16b, v0.16b
033a3ad0: f30300aa mov      x19, x0
033a3ad4: fefbff97 bl       #0x33a2acc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$.ctor
033a3ad8: 682600bd str      s8, [x19, #0x24]
033a3adc: 74a20039 strb     w20, [x19, #0x28]
033a3ae0: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a3ae4: f40740f9 ldr      x20, [sp, #8]
033a3ae8: e80742fc ldr      d8, [sp], #0x20
033a3aec: c0035fd6 ret      
