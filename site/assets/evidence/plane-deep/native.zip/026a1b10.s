# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$get_TargetExplodeData
# Linear span to next metadata entry; not a complete CFG.
026a1b10: 09300491 add      x9, x0, #0x10c
026a1b14: 2a1940f9 ldr      x10, [x9, #0x30]
026a1b18: 228140ad ldp      q2, q0, [x9, #0x10]
026a1b1c: 2101c03d ldr      q1, [x9]
026a1b20: 0a1900f9 str      x10, [x8, #0x30]
026a1b24: 028100ad stp      q2, q0, [x8, #0x10]
026a1b28: 0101803d str      q1, [x8]
026a1b2c: c0035fd6 ret      
