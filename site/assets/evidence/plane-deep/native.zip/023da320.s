# Royal.Scenes.Game.Mechanics.Items.LaserItem.LaserItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
023da320: fe0f1ff8 str      x30, [sp, #-0x10]!
023da324: 080040f9 ldr      x8, [x0]
023da328: 096542f9 ldr      x9, [x8, #0x4c8]
023da32c: 016942f9 ldr      x1, [x8, #0x4d0]
023da330: 20013fd6 blr      x9
023da334: 08229f52 mov      w8, #0xf910
023da338: a9828952 mov      w9, #0x4c15
023da33c: 1f040071 cmp      w0, #1
023da340: c800a072 movk     w8, #6, lsl #16
023da344: 2901a072 movk     w9, #9, lsl #16
023da348: 2001881a csel     w0, w9, w8, eq
023da34c: fe0741f8 ldr      x30, [sp], #0x10
023da350: c0035fd6 ret      
