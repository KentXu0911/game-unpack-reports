# Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.BoomerangBoxItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0238ca1c: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
0238ca20: 080040f9 ldr      x8, [x0]
0238ca24: f303012a mov      w19, w1
0238ca28: 096542f9 ldr      x9, [x8, #0x4c8]
0238ca2c: 086942f9 ldr      x8, [x8, #0x4d0]
0238ca30: e10308aa mov      x1, x8
0238ca34: 20013fd6 blr      x9
0238ca38: 7f1e0071 cmp      w19, #7
0238ca3c: e1000054 b.ne     #0x238ca58
0238ca40: c8e69c52 mov      w8, #0xe736
0238ca44: 491e8552 mov      w9, #0x28f2
0238ca48: 1f040071 cmp      w0, #1
0238ca4c: c800a072 movk     w8, #6, lsl #16
0238ca50: a900a072 movk     w9, #5, lsl #16
0238ca54: 06000014 b        #0x238ca6c
0238ca58: a8828952 mov      w8, #0x4c15
0238ca5c: 09229f52 mov      w9, #0xf910
0238ca60: 1f040071 cmp      w0, #1
0238ca64: 2801a072 movk     w8, #9, lsl #16
0238ca68: c900a072 movk     w9, #6, lsl #16
0238ca6c: 2011881a csel     w0, w9, w8, ne
0238ca70: f37bc1a8 ldp      x19, x30, [sp], #0x10
0238ca74: c0035fd6 ret      
