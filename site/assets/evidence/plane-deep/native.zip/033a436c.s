# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$OnTargetCancelled
# Linear span to next metadata entry; not a complete CFG.
033a436c: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a4370: 080040f9 ldr      x8, [x0]
033a4374: 131c40f9 ldr      x19, [x0, #0x38]
033a4378: 097d41f9 ldr      x9, [x8, #0x2f8]
033a437c: 018141f9 ldr      x1, [x8, #0x300]
033a4380: 20013fd6 blr      x9
033a4384: d30000b4 cbz      x19, #0x33a439c
033a4388: e103002a mov      w1, w0
033a438c: e00313aa mov      x0, x19
033a4390: e2031faa mov      x2, xzr
033a4394: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a4398: 2f55da17 b        #0x2a39854 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$OperationFinish
033a439c: 23347097 bl       #0xfb1428
