# Royal.Scenes.Game.Mechanics.Items.SpecialItems.LightballItem.LightballItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
033a4e18: ff0301d1 sub      sp, sp, #0x40
033a4e1c: f75b01a9 stp      x23, x22, [sp, #0x10]
033a4e20: f55302a9 stp      x21, x20, [sp, #0x20]
033a4e24: f37b03a9 stp      x19, x30, [sp, #0x30]
033a4e28: 150f01d0 adrp     x21, #0x5586000
033a4e2c: a87a6739 ldrb     w8, [x21, #0x9de]
033a4e30: f303012a mov      w19, w1
033a4e34: f40300aa mov      x20, x0
033a4e38: 68030037 tbnz     w8, #0, #0x33a4ea4
033a4e3c: e0f30090 adrp     x0, #0x5220000
033a4e40: 00d847f9 ldr      x0, [x0, #0xfb0]
033a4e44: 2f317097 bl       #0xfb1300
033a4e48: 80f300f0 adrp     x0, #0x5217000
033a4e4c: 000846f9 ldr      x0, [x0, #0xc10]
033a4e50: 2c317097 bl       #0xfb1300
033a4e54: a0f200d0 adrp     x0, #0x51fa000
033a4e58: 00f840f9 ldr      x0, [x0, #0x1f0]
033a4e5c: 29317097 bl       #0xfb1300
033a4e60: a0f300f0 adrp     x0, #0x521b000
033a4e64: 002847f9 ldr      x0, [x0, #0xe50]
033a4e68: 26317097 bl       #0xfb1300
033a4e6c: 20f400d0 adrp     x0, #0x522a000
033a4e70: 003440f9 ldr      x0, [x0, #0x68]
033a4e74: 23317097 bl       #0xfb1300
033a4e78: 00f000f0 adrp     x0, #0x51a7000
033a4e7c: 009c45f9 ldr      x0, [x0, #0xb38]
033a4e80: 20317097 bl       #0xfb1300
033a4e84: a0f00090 adrp     x0, #0x51b8000
033a4e88: 006c45f9 ldr      x0, [x0, #0xad8]
033a4e8c: 1d317097 bl       #0xfb1300
033a4e90: a0f000b0 adrp     x0, #0x51b9000
033a4e94: 007045f9 ldr      x0, [x0, #0xae0]
033a4e98: 1a317097 bl       #0xfb1300
033a4e9c: 28008052 mov      w8, #1
033a4ea0: a87a2739 strb     w8, [x21, #0x9de]
033a4ea4: ff0f00b9 str      wzr, [sp, #0xc]
033a4ea8: 886640f9 ldr      x8, [x20, #0xc8]
033a4eac: a80000b4 cbz      x8, #0x33a4ec0
033a4eb0: 08e54239 ldrb     w8, [x8, #0xb9]
033a4eb4: 68000034 cbz      w8, #0x33a4ec0
033a4eb8: 15008012 mov      w21, #-1
033a4ebc: b0000014 b        #0x33a517c
033a4ec0: b5f000b0 adrp     x21, #0x51b9000
033a4ec4: b57245f9 ldr      x21, [x21, #0xae0]
033a4ec8: a00240f9 ldr      x0, [x21]
033a4ecc: 08e040b9 ldr      w8, [x0, #0xe0]
033a4ed0: 48000035 cbnz     w8, #0x33a4ed8
033a4ed4: 4c317097 bl       #0xfb1404
033a4ed8: 960e01f0 adrp     x22, #0x5577000
033a4edc: c84e7d39 ldrb     w8, [x22, #0xf53]
033a4ee0: c8000035 cbnz     w8, #0x33a4ef8
033a4ee4: a0f000b0 adrp     x0, #0x51b9000
033a4ee8: 007045f9 ldr      x0, [x0, #0xae0]
033a4eec: 05317097 bl       #0xfb1300
033a4ef0: 28008052 mov      w8, #1
033a4ef4: c84e3d39 strb     w8, [x22, #0xf53]
033a4ef8: a00240f9 ldr      x0, [x21]
033a4efc: 08e040b9 ldr      w8, [x0, #0xe0]
033a4f00: 68000035 cbnz     w8, #0x33a4f0c
033a4f04: 40317097 bl       #0xfb1404
033a4f08: a00240f9 ldr      x0, [x21]
033a4f0c: 085c40f9 ldr      x8, [x0, #0xb8]
033a4f10: 08514039 ldrb     w8, [x8, #0x14]
033a4f14: a8030034 cbz      w8, #0x33a4f88
033a4f18: e00314aa mov      x0, x20
033a4f1c: e1031faa mov      x1, xzr
033a4f20: dd77ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a4f24: 400900b4 cbz      x0, #0x33a504c
033a4f28: a8f00090 adrp     x8, #0x51b8000
033a4f2c: 086d45f9 ldr      x8, [x8, #0xad8]
033a4f30: 60088052 mov      w0, #0x43
033a4f34: 010140f9 ldr      x1, [x8]
033a4f38: cd66c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a4f3c: f50300aa mov      x21, x0
033a4f40: e00314aa mov      x0, x20
033a4f44: e1031faa mov      x1, xzr
033a4f48: d377ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a4f4c: 751b00b4 cbz      x21, #0x33a52b8
033a4f50: e10300aa mov      x1, x0
033a4f54: e00315aa mov      x0, x21
033a4f58: e2031faa mov      x2, xzr
033a4f5c: 6f7f7597 bl       #0x1104d18 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.WaterItem.WaterItemHelper$$IsInBoostingArea
033a4f60: 40010036 tbz      w0, #0, #0x33a4f88
033a4f64: e00314aa mov      x0, x20
033a4f68: e1031faa mov      x1, xzr
033a4f6c: ca77ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a4f70: 401a00b4 cbz      x0, #0x33a52b8
033a4f74: 006440f9 ldr      x0, [x0, #0xc8]
033a4f78: 001a00b4 cbz      x0, #0x33a52b8
033a4f7c: e1031faa mov      x1, xzr
033a4f80: a1badc97 bl       #0x2ad3a04 ; Royal.Scenes.Game.Mechanics.Board.Cell.WaterItemMediator$$HasWaterView
033a4f84: a00f0036 tbz      w0, #0, #0x33a5178
033a4f88: e003132a mov      w0, w19
033a4f8c: e1031faa mov      x1, xzr
033a4f90: 6b7eff97 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
033a4f94: 40010036 tbz      w0, #0, #0x33a4fbc
033a4f98: e00314aa mov      x0, x20
033a4f9c: e103132a mov      w1, w19
033a4fa0: e2031faa mov      x2, xzr
033a4fa4: 9b9a0b94 bl       #0x368ba10 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.SpecialItemModel$$GetExplodeScore
033a4fa8: 1f000071 cmp      w0, #0
033a4fac: 283b8252 mov      w8, #0x11d9
033a4fb0: 08c19f1a csel     w8, w8, wzr, gt
033a4fb4: 1500084b sub      w21, w0, w8
033a4fb8: 71000014 b        #0x33a517c
033a4fbc: b50b9352 mov      w21, #0x985d
033a4fc0: e00314aa mov      x0, x20
033a4fc4: e1031faa mov      x1, xzr
033a4fc8: f5fcbf72 movk     w21, #0xffe7, lsl #16
033a4fcc: b277ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a4fd0: 600d00b4 cbz      x0, #0x33a517c
033a4fd4: 20068052 mov      w0, #0x31
033a4fd8: e1031faa mov      x1, xzr
033a4fdc: afbbce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033a4fe0: a0030036 tbz      w0, #0, #0x33a5054
033a4fe4: a8f200d0 adrp     x8, #0x51fa000
033a4fe8: 08f940f9 ldr      x8, [x8, #0x1f0]
033a4fec: 20068052 mov      w0, #0x31
033a4ff0: 010140f9 ldr      x1, [x8]
033a4ff4: 9e66c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a4ff8: f60300aa mov      x22, x0
033a4ffc: e00314aa mov      x0, x20
033a5000: e1031faa mov      x1, xzr
033a5004: a477ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a5008: 961500b4 cbz      x22, #0x33a52b8
033a500c: 84c242f8 ldur     x4, [x20, #0x2c]
033a5010: e10300aa mov      x1, x0
033a5014: e2330091 add      x2, sp, #0xc
033a5018: e00316aa mov      x0, x22
033a501c: e303132a mov      w3, w19
033a5020: e5031faa mov      x5, xzr
033a5024: d5ebb597 bl       #0x211ff78 ; Royal.Scenes.Game.Mechanics.Items.IceCubeItem.IceCubeItemHelper$$GetAvailableIceCubeScoreAboveCell
033a5028: 1f040071 cmp      w0, #1
033a502c: 4b010054 b.lt     #0x33a5054
033a5030: f50f40b9 ldr      w21, [sp, #0xc]
033a5034: 28e18552 mov      w8, #0x2f09
033a5038: 8800a072 movk     w8, #4, lsl #16
033a503c: bf02086b cmp      w21, w8
033a5040: f703152a mov      w23, w21
033a5044: ad000054 b.le     #0x33a5058
033a5048: 4d000014 b        #0x33a517c
033a504c: 153b8212 mov      w21, #-0x11d9
033a5050: 4b000014 b        #0x33a517c
033a5054: f7031f2a mov      w23, wzr
033a5058: e0028052 mov      w0, #0x17
033a505c: e1031faa mov      x1, xzr
033a5060: 8ebbce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033a5064: 80020036 tbz      w0, #0, #0x33a50b4
033a5068: c8f300f0 adrp     x8, #0x5220000
033a506c: 08d947f9 ldr      x8, [x8, #0xfb0]
033a5070: e0028052 mov      w0, #0x17
033a5074: 010140f9 ldr      x1, [x8]
033a5078: 7d66c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a507c: f60300aa mov      x22, x0
033a5080: e00314aa mov      x0, x20
033a5084: e1031faa mov      x1, xzr
033a5088: 8377ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a508c: 761100b4 cbz      x22, #0x33a52b8
033a5090: 84c242f8 ldur     x4, [x20, #0x2c]
033a5094: e10300aa mov      x1, x0
033a5098: e2330091 add      x2, sp, #0xc
033a509c: e00316aa mov      x0, x22
033a50a0: e303132a mov      w3, w19
033a50a4: e5031faa mov      x5, xzr
033a50a8: 7b2fb797 bl       #0x2170e94 ; Royal.Scenes.Game.Mechanics.Items.BirdItem.BirdItemHelper$$GetAvailableBirdScoreAboveCell
033a50ac: 1f040071 cmp      w0, #1
033a50b0: ea050054 b.ge     #0x33a516c
033a50b4: 200d8052 mov      w0, #0x69
033a50b8: e1031faa mov      x1, xzr
033a50bc: 77bbce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033a50c0: 80020036 tbz      w0, #0, #0x33a5110
033a50c4: 08f000d0 adrp     x8, #0x51a7000
033a50c8: 089d45f9 ldr      x8, [x8, #0xb38]
033a50cc: 200d8052 mov      w0, #0x69
033a50d0: 010140f9 ldr      x1, [x8]
033a50d4: 6666c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a50d8: f60300aa mov      x22, x0
033a50dc: e00314aa mov      x0, x20
033a50e0: e1031faa mov      x1, xzr
033a50e4: 6c77ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a50e8: 960e00b4 cbz      x22, #0x33a52b8
033a50ec: 84c242f8 ldur     x4, [x20, #0x2c]
033a50f0: e10300aa mov      x1, x0
033a50f4: e2330091 add      x2, sp, #0xc
033a50f8: e00316aa mov      x0, x22
033a50fc: e303132a mov      w3, w19
033a5100: e5031faa mov      x5, xzr
033a5104: 55e32894 bl       #0x3ddde58 ; Royal.Scenes.Game.Mechanics.Items.TurtleItem.TurtleItemHelper$$GetAvailableTurtleScoreAboveCell
033a5108: 1f040071 cmp      w0, #1
033a510c: 0a030054 b.ge     #0x33a516c
033a5110: 200a8052 mov      w0, #0x51
033a5114: e1031faa mov      x1, xzr
033a5118: 60bbce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033a511c: c0030036 tbz      w0, #0, #0x33a5194
033a5120: 28f400b0 adrp     x8, #0x522a000
033a5124: 083540f9 ldr      x8, [x8, #0x68]
033a5128: 200a8052 mov      w0, #0x51
033a512c: 010140f9 ldr      x1, [x8]
033a5130: 4f66c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a5134: f60300aa mov      x22, x0
033a5138: e00314aa mov      x0, x20
033a513c: e1031faa mov      x1, xzr
033a5140: 5577ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a5144: b60b00b4 cbz      x22, #0x33a52b8
033a5148: 84c242f8 ldur     x4, [x20, #0x2c]
033a514c: e10300aa mov      x1, x0
033a5150: e2330091 add      x2, sp, #0xc
033a5154: e00316aa mov      x0, x22
033a5158: e303132a mov      w3, w19
033a515c: e5031faa mov      x5, xzr
033a5160: ac1ab797 bl       #0x216bc10 ; Royal.Scenes.Game.Mechanics.Items.ShuttleItem.ShuttleItemHelper$$GetAvailableShuttleScoreAboveCell
033a5164: 1f040071 cmp      w0, #1
033a5168: 6b010054 b.lt     #0x33a5194
033a516c: e80f40b9 ldr      w8, [sp, #0xc]
033a5170: 1501174b sub      w21, w8, w23
033a5174: 02000014 b        #0x33a517c
033a5178: 95c59a52 mov      w21, #0xd62c
033a517c: e003152a mov      w0, w21
033a5180: f37b43a9 ldp      x19, x30, [sp, #0x30]
033a5184: f55342a9 ldp      x21, x20, [sp, #0x20]
033a5188: f75b41a9 ldp      x23, x22, [sp, #0x10]
033a518c: ff030191 add      sp, sp, #0x40
033a5190: c0035fd6 ret      
033a5194: c00b8052 mov      w0, #0x5e
033a5198: e1031faa mov      x1, xzr
033a519c: 3fbbce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033a51a0: 00030036 tbz      w0, #0, #0x33a5200
033a51a4: a8f300d0 adrp     x8, #0x521b000
033a51a8: 082947f9 ldr      x8, [x8, #0xe50]
033a51ac: c00b8052 mov      w0, #0x5e
033a51b0: 010140f9 ldr      x1, [x8]
033a51b4: 2e66c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a51b8: f60300aa mov      x22, x0
033a51bc: e00314aa mov      x0, x20
033a51c0: e1031faa mov      x1, xzr
033a51c4: 3477ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a51c8: 960700b4 cbz      x22, #0x33a52b8
033a51cc: 84c242f8 ldur     x4, [x20, #0x2c]
033a51d0: e10300aa mov      x1, x0
033a51d4: e2330091 add      x2, sp, #0xc
033a51d8: e00316aa mov      x0, x22
033a51dc: e303132a mov      w3, w19
033a51e0: e5031faa mov      x5, xzr
033a51e4: 02a6ac97 bl       #0x1ece9ec ; Royal.Scenes.Game.Mechanics.Items.RoyalBotItem.RoyalBotItemHelper$$GetAvailableRoyalBotScoreAboveCell
033a51e8: 1f040071 cmp      w0, #1
033a51ec: ab000054 b.lt     #0x33a5200
033a51f0: e80f40b9 ldr      w8, [sp, #0xc]
033a51f4: a902174b sub      w9, w21, w23
033a51f8: 3501080b add      w21, w9, w8
033a51fc: e0ffff17 b        #0x33a517c
033a5200: 40048052 mov      w0, #0x22
033a5204: e1031faa mov      x1, xzr
033a5208: 24bbce97 bl       #0x2753e98 ; Royal.Scenes.Game.Levels.LevelContext$$Has
033a520c: 80fb0736 tbz      w0, #0, #0x33a517c
033a5210: 88f300d0 adrp     x8, #0x5217000
033a5214: 080946f9 ldr      x8, [x8, #0xc10]
033a5218: 40048052 mov      w0, #0x22
033a521c: 010140f9 ldr      x1, [x8]
033a5220: 1366c697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a5224: f60300aa mov      x22, x0
033a5228: e00314aa mov      x0, x20
033a522c: e1031faa mov      x1, xzr
033a5230: 1977ff97 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
033a5234: 360400b4 cbz      x22, #0x33a52b8
033a5238: 84c242f8 ldur     x4, [x20, #0x2c]
033a523c: e10300aa mov      x1, x0
033a5240: e2330091 add      x2, sp, #0xc
033a5244: e00316aa mov      x0, x22
033a5248: e303132a mov      w3, w19
033a524c: e5031faa mov      x5, xzr
033a5250: 894be797 bl       #0x2d78074 ; Royal.Scenes.Game.Mechanics.Items.FrogItem.FrogItemHelper$$GetAvailableFrogScoreAboveCell
033a5254: 1f040071 cmp      w0, #1
033a5258: 2bf9ff54 b.lt     #0x33a517c
033a525c: e80f40b9 ldr      w8, [sp, #0xc]
033a5260: 09958852 mov      w9, #0x44a8
033a5264: 1f01096b cmp      w8, w9
033a5268: 81010054 b.ne     #0x33a5298
033a526c: 7f0a0071 cmp      w19, #2
033a5270: a0000054 b.eq     #0x33a5284
033a5274: e003132a mov      w0, w19
033a5278: e1031faa mov      x1, xzr
033a527c: b07dff97 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
033a5280: a0000036 tbz      w0, #0, #0x33a5294
033a5284: 08229f52 mov      w8, #0xf910
033a5288: c800a072 movk     w8, #6, lsl #16
033a528c: e80f00b9 str      w8, [sp, #0xc]
033a5290: 02000014 b        #0x33a5298
033a5294: e80f40b9 ldr      w8, [sp, #0xc]
033a5298: e9cc8c52 mov      w9, #0x6667
033a529c: c9ccac72 movk     w9, #0x6666, lsl #16
033a52a0: 087d299b smull    x8, w8, w9
033a52a4: 09fd7fd3 lsr      x9, x8, #0x3f
033a52a8: 08fd6193 asr      x8, x8, #0x21
033a52ac: 0801090b add      w8, w8, w9
033a52b0: 0805080b add      w8, w8, w8, lsl #1
033a52b4: afffff17 b        #0x33a5170
033a52b8: 5c307097 bl       #0xfb1428
