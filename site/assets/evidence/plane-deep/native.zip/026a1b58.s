# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$set_TargetItem
# Linear span to next metadata entry; not a complete CFG.
026a1b58: 08200591 add      x8, x0, #0x148
026a1b5c: 01a400f9 str      x1, [x0, #0x148]
026a1b60: e00308aa mov      x0, x8
026a1b64: d23da417 b        #0xfb12ac
