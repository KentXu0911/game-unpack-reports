# Royal.Scenes.Game.Mechanics.Items.FireworksItem.FireworksItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02aa460c: f553bea9 stp      x21, x20, [sp, #-0x20]!
02aa4610: f37b01a9 stp      x19, x30, [sp, #0x10]
02aa4614: f55601d0 adrp     x21, #0x5582000
02aa4618: a8124339 ldrb     w8, [x21, #0xc4]
02aa461c: f403012a mov      w20, w1
02aa4620: f30300aa mov      x19, x0
02aa4624: e8010037 tbnz     w8, #0, #0x2aa4660
02aa4628: 803b01f0 adrp     x0, #0x5217000
02aa462c: 00d041f9 ldr      x0, [x0, #0x3a0]
02aa4630: 34339497 bl       #0xfb1300
02aa4634: a03801b0 adrp     x0, #0x51b9000
02aa4638: 007045f9 ldr      x0, [x0, #0xae0]
02aa463c: 31339497 bl       #0xfb1300
02aa4640: 00390190 adrp     x0, #0x51c4000
02aa4644: 001042f9 ldr      x0, [x0, #0x420]
02aa4648: 2e339497 bl       #0xfb1300
02aa464c: 603801f0 adrp     x0, #0x51b3000
02aa4650: 00a041f9 ldr      x0, [x0, #0x340]
02aa4654: 2b339497 bl       #0xfb1300
02aa4658: 28008052 mov      w8, #1
02aa465c: a8120339 strb     w8, [x21, #0xc4]
02aa4660: 680240f9 ldr      x8, [x19]
02aa4664: e00313aa mov      x0, x19
02aa4668: 096542f9 ldr      x9, [x8, #0x4c8]
02aa466c: 016942f9 ldr      x1, [x8, #0x4d0]
02aa4670: 20013fd6 blr      x9
02aa4674: 1f040071 cmp      w0, #1
02aa4678: 8b0e0054 b.lt     #0x2aa4848
02aa467c: 9f120071 cmp      w20, #4
02aa4680: c1040054 b.ne     #0x2aa4718
02aa4684: e00313aa mov      x0, x19
02aa4688: e1031faa mov      x1, xzr
02aa468c: 027a2394 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02aa4690: 600e00b4 cbz      x0, #0x2aa485c
02aa4694: 006040f9 ldr      x0, [x0, #0xc0]
02aa4698: 200e00b4 cbz      x0, #0x2aa485c
02aa469c: e1031faa mov      x1, xzr
02aa46a0: 13950094 bl       #0x2ac9aec ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$GetTopMostBelowItem
02aa46a4: f40300aa mov      x20, x0
02aa46a8: 200d00b4 cbz      x0, #0x2aa484c
02aa46ac: 683801f0 adrp     x8, #0x51b3000
02aa46b0: 08a141f9 ldr      x8, [x8, #0x340]
02aa46b4: 15390190 adrp     x21, #0x51c4000
02aa46b8: 000140f9 ldr      x0, [x8]
02aa46bc: 08e040b9 ldr      w8, [x0, #0xe0]
02aa46c0: b51242f9 ldr      x21, [x21, #0x420]
02aa46c4: 48000035 cbnz     w8, #0x2aa46cc
02aa46c8: 4f339497 bl       #0xfb1404
02aa46cc: a10240f9 ldr      x1, [x21]
02aa46d0: 40008052 mov      w0, #2
02aa46d4: 24c7f697 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
02aa46d8: 200c00b4 cbz      x0, #0x2aa485c
02aa46dc: 61068052 mov      w1, #0x33
02aa46e0: e2031faa mov      x2, xzr
02aa46e4: 1ad9d697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
02aa46e8: c0050036 tbz      w0, #0, #0x2aa47a0
02aa46ec: 680240f9 ldr      x8, [x19]
02aa46f0: e00313aa mov      x0, x19
02aa46f4: 096542f9 ldr      x9, [x8, #0x4c8]
02aa46f8: 016942f9 ldr      x1, [x8, #0x4d0]
02aa46fc: 20013fd6 blr      x9
02aa4700: 08229f52 mov      w8, #0xf910
02aa4704: 1f080071 cmp      w0, #2
02aa4708: c800a072 movk     w8, #6, lsl #16
02aa470c: 49038052 mov      w9, #0x1a
02aa4710: 2001881a csel     w0, w9, w8, eq
02aa4714: 4f000014 b        #0x2aa4850
02aa4718: b43801b0 adrp     x20, #0x51b9000
02aa471c: 947245f9 ldr      x20, [x20, #0xae0]
02aa4720: 800240f9 ldr      x0, [x20]
02aa4724: 08e040b9 ldr      w8, [x0, #0xe0]
02aa4728: 48000035 cbnz     w8, #0x2aa4730
02aa472c: 36339497 bl       #0xfb1404
02aa4730: 955601f0 adrp     x21, #0x5577000
02aa4734: a84e7d39 ldrb     w8, [x21, #0xf53]
02aa4738: c8000035 cbnz     w8, #0x2aa4750
02aa473c: a03801b0 adrp     x0, #0x51b9000
02aa4740: 007045f9 ldr      x0, [x0, #0xae0]
02aa4744: ef329497 bl       #0xfb1300
02aa4748: 28008052 mov      w8, #1
02aa474c: a84e3d39 strb     w8, [x21, #0xf53]
02aa4750: 800240f9 ldr      x0, [x20]
02aa4754: 08e040b9 ldr      w8, [x0, #0xe0]
02aa4758: 68000035 cbnz     w8, #0x2aa4764
02aa475c: 2a339497 bl       #0xfb1404
02aa4760: 800240f9 ldr      x0, [x20]
02aa4764: 085c40f9 ldr      x8, [x0, #0xb8]
02aa4768: 14229f52 mov      w20, #0xf910
02aa476c: d400a072 movk     w20, #6, lsl #16
02aa4770: 08514039 ldrb     w8, [x8, #0x14]
02aa4774: c8060035 cbnz     w8, #0x2aa484c
02aa4778: 680240f9 ldr      x8, [x19]
02aa477c: e00313aa mov      x0, x19
02aa4780: 096542f9 ldr      x9, [x8, #0x4c8]
02aa4784: 016942f9 ldr      x1, [x8, #0x4d0]
02aa4788: 20013fd6 blr      x9
02aa478c: 68f08252 mov      w8, #0x1783
02aa4790: 1f040071 cmp      w0, #1
02aa4794: 4800a072 movk     w8, #2, lsl #16
02aa4798: 9402881a csel     w20, w20, w8, eq
02aa479c: 2c000014 b        #0x2aa484c
02aa47a0: 893b01f0 adrp     x9, #0x5217000
02aa47a4: 29d141f9 ldr      x9, [x9, #0x3a0]
02aa47a8: 880240f9 ldr      x8, [x20]
02aa47ac: 290140f9 ldr      x9, [x9]
02aa47b0: 0bb14439 ldrb     w11, [x8, #0x12c]
02aa47b4: 2ab14439 ldrb     w10, [x9, #0x12c]
02aa47b8: 7f010a6b cmp      w11, w10
02aa47bc: c3000054 b.lo     #0x2aa47d4
02aa47c0: 0b6540f9 ldr      x11, [x8, #0xc8]
02aa47c4: 6a0d0a8b add      x10, x11, x10, lsl #3
02aa47c8: 4a815ff8 ldur     x10, [x10, #-8]
02aa47cc: 5f0109eb cmp      x10, x9
02aa47d0: e0010054 b.eq     #0x2aa480c
02aa47d4: 097542f9 ldr      x9, [x8, #0x4e8]
02aa47d8: 017942f9 ldr      x1, [x8, #0x4f0]
02aa47dc: e00314aa mov      x0, x20
02aa47e0: 20013fd6 blr      x9
02aa47e4: 1f040071 cmp      w0, #1
02aa47e8: 0b030054 b.lt     #0x2aa4848
02aa47ec: 880240f9 ldr      x8, [x20]
02aa47f0: 81008052 mov      w1, #4
02aa47f4: e00314aa mov      x0, x20
02aa47f8: 092d42f9 ldr      x9, [x8, #0x458]
02aa47fc: 023142f9 ldr      x2, [x8, #0x460]
02aa4800: 20013fd6 blr      x9
02aa4804: 14040051 sub      w20, w0, #1
02aa4808: 11000014 b        #0x2aa484c
02aa480c: e00314aa mov      x0, x20
02aa4810: e1031faa mov      x1, xzr
02aa4814: 96dfa297 bl       #0x135c66c ; Royal.Scenes.Game.Mechanics.Items.StaticItems.JellyItem.JellyItemModel$$IsLogicActive
02aa4818: 80010037 tbnz     w0, #0, #0x2aa4848
02aa481c: 680240f9 ldr      x8, [x19]
02aa4820: e00313aa mov      x0, x19
02aa4824: 096542f9 ldr      x9, [x8, #0x4c8]
02aa4828: 016942f9 ldr      x1, [x8, #0x4d0]
02aa482c: 20013fd6 blr      x9
02aa4830: 1f040071 cmp      w0, #1
02aa4834: ac000054 b.gt     #0x2aa4848
02aa4838: 60008052 mov      w0, #3
02aa483c: e1031faa mov      x1, xzr
02aa4840: c69c2394 bl       #0x338bb58 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
02aa4844: f0ffff17 b        #0x2aa4804
02aa4848: f4031f2a mov      w20, wzr
02aa484c: e003142a mov      w0, w20
02aa4850: f37b41a9 ldp      x19, x30, [sp, #0x10]
02aa4854: f553c2a8 ldp      x21, x20, [sp], #0x20
02aa4858: c0035fd6 ret      
02aa485c: f3329497 bl       #0xfb1428
