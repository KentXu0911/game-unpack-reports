# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$GetPrioritizedCellInColumnForChainBottomCollect
# Linear span to next metadata entry; not a complete CFG.
020f0c98: fc6fbaa9 stp      x28, x27, [sp, #-0x60]!
020f0c9c: fa6701a9 stp      x26, x25, [sp, #0x10]
020f0ca0: f85f02a9 stp      x24, x23, [sp, #0x20]
020f0ca4: f65703a9 stp      x22, x21, [sp, #0x30]
020f0ca8: f44f04a9 stp      x20, x19, [sp, #0x40]
020f0cac: fd7b05a9 stp      x29, x30, [sp, #0x50]
020f0cb0: ff0308d1 sub      sp, sp, #0x200
020f0cb4: 76a401b0 adrp     x22, #0x557d000
020f0cb8: c8165539 ldrb     w8, [x22, #0x545]
020f0cbc: f40302aa mov      x20, x2
020f0cc0: f503012a mov      w21, w1
020f0cc4: f70300aa mov      x23, x0
020f0cc8: f3030691 add      x19, sp, #0x180
020f0ccc: c8000037 tbnz     w8, #0, #0x20f0ce4
020f0cd0: 408901f0 adrp     x0, #0x521b000
020f0cd4: 00e842f9 ldr      x0, [x0, #0x5d0]
020f0cd8: 8a01bb97 bl       #0xfb1300
020f0cdc: 28008052 mov      w8, #1
020f0ce0: c8161539 strb     w8, [x22, #0x545]
020f0ce4: 00e4006f movi     v0.2d, #0000000000000000
020f0ce8: fffb00f9 str      xzr, [sp, #0x1f0]
020f0cec: 608202ad stp      q0, q0, [x19, #0x50]
020f0cf0: 608201ad stp      q0, q0, [x19, #0x30]
020f0cf4: 608200ad stp      q0, q0, [x19, #0x10]
020f0cf8: 6002803d str      q0, [x19]
020f0cfc: e02640f9 ldr      x0, [x23, #0x48]
020f0d00: 401c00b4 cbz      x0, #0x20f1088
020f0d04: e1031faa mov      x1, xzr
020f0d08: 75a7fd97 bl       #0x205aadc ; Royal.Player.Context.Units.LevelManager$$IsThereBottomCollectInLevel
020f0d0c: e803002a mov      w8, w0
020f0d10: e0031faa mov      x0, xzr
020f0d14: a81a0036 tbz      w8, #0, #0x20f1068
020f0d18: e02640f9 ldr      x0, [x23, #0x48]
020f0d1c: 601b00b4 cbz      x0, #0x20f1088
020f0d20: c1008052 mov      w1, #6
020f0d24: e2031faa mov      x2, xzr
020f0d28: 57a7fd97 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
020f0d2c: e803002a mov      w8, w0
020f0d30: e0031faa mov      x0, xzr
020f0d34: a8190036 tbz      w8, #0, #0x20f1068
020f0d38: 5c8901f0 adrp     x28, #0x521b000
020f0d3c: 9ceb42f9 ldr      x28, [x28, #0x5d0]
020f0d40: 800340f9 ldr      x0, [x28]
020f0d44: 08e040b9 ldr      w8, [x0, #0xe0]
020f0d48: 48000035 cbnz     w8, #0x20f0d50
020f0d4c: ae01bb97 bl       #0xfb1404
020f0d50: 33a401f0 adrp     x19, #0x5577000
020f0d54: 68f67f39 ldrb     w8, [x19, #0xffd]
020f0d58: c8000035 cbnz     w8, #0x20f0d70
020f0d5c: 408901f0 adrp     x0, #0x521b000
020f0d60: 00e842f9 ldr      x0, [x0, #0x5d0]
020f0d64: 6701bb97 bl       #0xfb1300
020f0d68: 28008052 mov      w8, #1
020f0d6c: 68f63f39 strb     w8, [x19, #0xffd]
020f0d70: 9a0340f9 ldr      x26, [x28]
020f0d74: f70700f9 str      x23, [sp, #8]
020f0d78: 48e340b9 ldr      w8, [x26, #0xe0]
020f0d7c: 88000035 cbnz     w8, #0x20f0d8c
020f0d80: e0031aaa mov      x0, x26
020f0d84: a001bb97 bl       #0xfb1404
020f0d88: 9a0340f9 ldr      x26, [x28]
020f0d8c: 415f40f9 ldr      x1, [x26, #0xb8]
020f0d90: e0030691 add      x0, sp, #0x180
020f0d94: 020f8052 mov      w2, #0x78
020f0d98: 5e47af97 bl       #0xcc2b10
020f0d9c: ff0b00f9 str      xzr, [sp, #0x10]
020f0da0: f7031faa mov      x23, xzr
020f0da4: f9031faa mov      x25, xzr
020f0da8: f6031faa mov      x22, xzr
020f0dac: f8031f2a mov      w24, wzr
020f0db0: fd031f2a mov      w29, wzr
020f0db4: f3031f2a mov      w19, wzr
020f0db8: 48e340b9 ldr      w8, [x26, #0xe0]
020f0dbc: a8000034 cbz      w8, #0x20f0dd0
020f0dc0: 880240b9 ldr      w8, [x20]
020f0dc4: 1f03086b cmp      w24, w8
020f0dc8: 6b010054 b.lt     #0x20f0df4
020f0dcc: 82000014 b        #0x20f0fd4
020f0dd0: e0031aaa mov      x0, x26
020f0dd4: 8c01bb97 bl       #0xfb1404
020f0dd8: 800340f9 ldr      x0, [x28]
020f0ddc: 9a0240b9 ldr      w26, [x20]
020f0de0: 08e040b9 ldr      w8, [x0, #0xe0]
020f0de4: 48000035 cbnz     w8, #0x20f0dec
020f0de8: 8701bb97 bl       #0xfb1404
020f0dec: 1f031a6b cmp      w24, w26
020f0df0: 2a0f0054 b.ge     #0x20f0fd4
020f0df4: e00314aa mov      x0, x20
020f0df8: e103182a mov      w1, w24
020f0dfc: e2031faa mov      x2, xzr
020f0e00: b31aca97 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
020f0e04: 200e00b4 cbz      x0, #0x20f0fc8
020f0e08: e1031faa mov      x1, xzr
020f0e0c: fa0300aa mov      x26, x0
020f0e10: 145f2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f0e14: 1f0000f1 cmp      x0, #0
020f0e18: d602809a csel     x22, x22, x0, eq
020f0e1c: 200100b4 cbz      x0, #0x20f0e40
020f0e20: 561300b4 cbz      x22, #0x20f1088
020f0e24: c80240f9 ldr      x8, [x22]
020f0e28: e00316aa mov      x0, x22
020f0e2c: 09bd41f9 ldr      x9, [x8, #0x378]
020f0e30: 01c141f9 ldr      x1, [x8, #0x380]
020f0e34: 20013fd6 blr      x9
020f0e38: 1f400071 cmp      w0, #0x10
020f0e3c: 60060054 b.eq     #0x20f0f08
020f0e40: e0031aaa mov      x0, x26
020f0e44: e1031faa mov      x1, xzr
020f0e48: 065f2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f0e4c: 1f0000f1 cmp      x0, #0
020f0e50: 3903809a csel     x25, x25, x0, eq
020f0e54: 800100b4 cbz      x0, #0x20f0e84
020f0e58: 991100b4 cbz      x25, #0x20f1088
020f0e5c: 280340f9 ldr      x8, [x25]
020f0e60: fb0300aa mov      x27, x0
020f0e64: e00319aa mov      x0, x25
020f0e68: 09bd41f9 ldr      x9, [x8, #0x378]
020f0e6c: 01c141f9 ldr      x1, [x8, #0x380]
020f0e70: 20013fd6 blr      x9
020f0e74: 1f7c0071 cmp      w0, #0x1f
020f0e78: 61000054 b.ne     #0x20f0e84
020f0e7c: f9031baa mov      x25, x27
020f0e80: 22000014 b        #0x20f0f08
020f0e84: e0031aaa mov      x0, x26
020f0e88: e1031faa mov      x1, xzr
020f0e8c: f55e2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f0e90: 1f0000f1 cmp      x0, #0
020f0e94: f702809a csel     x23, x23, x0, eq
020f0e98: 800100b4 cbz      x0, #0x20f0ec8
020f0e9c: 770f00b4 cbz      x23, #0x20f1088
020f0ea0: e80240f9 ldr      x8, [x23]
020f0ea4: fb0300aa mov      x27, x0
020f0ea8: e00317aa mov      x0, x23
020f0eac: 09bd41f9 ldr      x9, [x8, #0x378]
020f0eb0: 01c141f9 ldr      x1, [x8, #0x380]
020f0eb4: 20013fd6 blr      x9
020f0eb8: 1f800171 cmp      w0, #0x60
020f0ebc: 61000054 b.ne     #0x20f0ec8
020f0ec0: f7031baa mov      x23, x27
020f0ec4: 11000014 b        #0x20f0f08
020f0ec8: e0031aaa mov      x0, x26
020f0ecc: e1031faa mov      x1, xzr
020f0ed0: e45e2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f0ed4: e80b40f9 ldr      x8, [sp, #0x10]
020f0ed8: 1f0000f1 cmp      x0, #0
020f0edc: fb0300aa mov      x27, x0
020f0ee0: 0001809a csel     x0, x8, x0, eq
020f0ee4: 5b0100b4 cbz      x27, #0x20f0f0c
020f0ee8: 000d00b4 cbz      x0, #0x20f1088
020f0eec: 080040f9 ldr      x8, [x0]
020f0ef0: 09bd41f9 ldr      x9, [x8, #0x378]
020f0ef4: 01c141f9 ldr      x1, [x8, #0x380]
020f0ef8: 20013fd6 blr      x9
020f0efc: 1fb80171 cmp      w0, #0x6e
020f0f00: fb0b00f9 str      x27, [sp, #0x10]
020f0f04: 41000054 b.ne     #0x20f0f0c
020f0f08: 33008052 mov      w19, #1
020f0f0c: 406340f9 ldr      x0, [x26, #0xc0]
020f0f10: c00b00b4 cbz      x0, #0x20f1088
020f0f14: c1008052 mov      w1, #6
020f0f18: e2031faa mov      x2, xzr
020f0f1c: fc6a2794 bl       #0x2acbb0c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasStaticItem
020f0f20: 485b40f9 ldr      x8, [x26, #0xb0]
020f0f24: 280b00b4 cbz      x8, #0x20f1088
020f0f28: bd03002a orr      w29, w29, w0
020f0f2c: e00308aa mov      x0, x8
020f0f30: e103152a mov      w1, w21
020f0f34: e2031f2a mov      w2, wzr
020f0f38: e3031faa mov      x3, xzr
020f0f3c: e4031faa mov      x4, xzr
020f0f40: a9782794 bl       #0x2acf1e4 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$GetScore
020f0f44: 1f040071 cmp      w0, #1
020f0f48: 0b040054 b.lt     #0x20f0fc8
020f0f4c: 406340f9 ldr      x0, [x26, #0xc0]
020f0f50: c00900b4 cbz      x0, #0x20f1088
020f0f54: e1031faa mov      x1, xzr
020f0f58: d1622794 bl       #0x2ac9a9c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasBelowItem
020f0f5c: 60020037 tbnz     w0, #0, #0x20f0fa8
020f0f60: 406340f9 ldr      x0, [x26, #0xc0]
020f0f64: 200900b4 cbz      x0, #0x20f1088
020f0f68: e1031faa mov      x1, xzr
020f0f6c: b8622794 bl       #0x2ac9a4c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasAboveItem
020f0f70: c0010037 tbnz     w0, #0, #0x20f0fa8
020f0f74: e0031aaa mov      x0, x26
020f0f78: e1031faa mov      x1, xzr
020f0f7c: b95e2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f0f80: 400200b4 cbz      x0, #0x20f0fc8
020f0f84: e0031aaa mov      x0, x26
020f0f88: e1031faa mov      x1, xzr
020f0f8c: b55e2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f0f90: c00700b4 cbz      x0, #0x20f1088
020f0f94: 080040f9 ldr      x8, [x0]
020f0f98: 090543f9 ldr      x9, [x8, #0x608]
020f0f9c: 010943f9 ldr      x1, [x8, #0x610]
020f0fa0: 20013fd6 blr      x9
020f0fa4: 20010037 tbnz     w0, #0, #0x20f0fc8
020f0fa8: 800340f9 ldr      x0, [x28]
020f0fac: 08e040b9 ldr      w8, [x0, #0xe0]
020f0fb0: 48000035 cbnz     w8, #0x20f0fb8
020f0fb4: 1401bb97 bl       #0xfb1404
020f0fb8: e0030691 add      x0, sp, #0x180
020f0fbc: e1031aaa mov      x1, x26
020f0fc0: e2031faa mov      x2, xzr
020f0fc4: 261bca97 bl       #0x1377c5c ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$Add
020f0fc8: 9a0340f9 ldr      x26, [x28]
020f0fcc: 18070011 add      w24, w24, #1
020f0fd0: 7affff17 b        #0x20f0db8
020f0fd4: e88341b9 ldr      w8, [sp, #0x180]
020f0fd8: 1f010071 cmp      w8, #0
020f0fdc: e8d79f1a cset     w8, gt
020f0fe0: 6802080a and      w8, w19, w8
020f0fe4: a803080a and      w8, w29, w8
020f0fe8: 1f050071 cmp      w8, #1
020f0fec: c1030054 b.ne     #0x20f1064
020f0ff0: e80740f9 ldr      x8, [sp, #8]
020f0ff4: e0230491 add      x0, sp, #0x108
020f0ff8: e1030691 add      x1, sp, #0x180
020f0ffc: 020f8052 mov      w2, #0x78
020f1000: 131d40f9 ldr      x19, [x8, #0x38]
020f1004: 7343af97 bl       #0xcc1dd0
020f1008: 130400b4 cbz      x19, #0x20f1088
020f100c: e0630091 add      x0, sp, #0x18
020f1010: e1230491 add      x1, sp, #0x108
020f1014: 020f8052 mov      w2, #0x78
020f1018: 6e43af97 bl       #0xcc1dd0
020f101c: e8430291 add      x8, sp, #0x90
020f1020: e1630091 add      x1, sp, #0x18
020f1024: e00313aa mov      x0, x19
020f1028: e2031faa mov      x2, xzr
020f102c: 04002594 bl       #0x2a3103c ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleCells
020f1030: e0030691 add      x0, sp, #0x180
020f1034: e1430291 add      x1, sp, #0x90
020f1038: 020f8052 mov      w2, #0x78
020f103c: 6543af97 bl       #0xcc1dd0
020f1040: 800340f9 ldr      x0, [x28]
020f1044: 08e040b9 ldr      w8, [x0, #0xe0]
020f1048: 48000035 cbnz     w8, #0x20f1050
020f104c: ee00bb97 bl       #0xfb1404
020f1050: e0030691 add      x0, sp, #0x180
020f1054: e1031f2a mov      w1, wzr
020f1058: e2031faa mov      x2, xzr
020f105c: 1c1aca97 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
020f1060: 02000014 b        #0x20f1068
020f1064: e0031faa mov      x0, xzr
020f1068: ff030891 add      sp, sp, #0x200
020f106c: fd7b45a9 ldp      x29, x30, [sp, #0x50]
020f1070: f44f44a9 ldp      x20, x19, [sp, #0x40]
020f1074: f65743a9 ldp      x22, x21, [sp, #0x30]
020f1078: f85f42a9 ldp      x24, x23, [sp, #0x20]
020f107c: fa6741a9 ldp      x26, x25, [sp, #0x10]
020f1080: fc6fc6a8 ldp      x28, x27, [sp], #0x60
020f1084: c0035fd6 ret      
020f1088: e800bb97 bl       #0xfb1428
