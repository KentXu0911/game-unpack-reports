# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339fed4: ea0f1dfc str      d10, [sp, #-0x30]!
0339fed8: e923016d stp      d9, d8, [sp, #0x10]
0339fedc: f37b02a9 stp      x19, x30, [sp, #0x20]
0339fee0: 08f0a752 mov      w8, #0x3f800000
0339fee4: e1031faa mov      x1, xzr
0339fee8: 481ca24e mov      v8.16b, v2.16b
0339feec: 291ca14e mov      v9.16b, v1.16b
0339fef0: 0a1ca04e mov      v10.16b, v0.16b
0339fef4: f30300aa mov      x19, x0
0339fef8: 08b400b9 str      w8, [x0, #0xb4]
0339fefc: be4dbb97 bl       #0x22735f4 ; System.Object$$.ctor
0339ff00: 6a26132d stp      s10, s9, [x19, #0x98]
0339ff04: 68a200bd str      s8, [x19, #0xa0]
0339ff08: f37b42a9 ldp      x19, x30, [sp, #0x20]
0339ff0c: e923416d ldp      d9, d8, [sp, #0x10]
0339ff10: ea0743fc ldr      d10, [sp], #0x30
0339ff14: c0035fd6 ret      
