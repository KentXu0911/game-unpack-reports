# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.IGuidedExploderPilot$$TargetStepUpdated
# Linear span to next metadata entry; not a complete CFG.
0339af50: c0035fd6 ret      
