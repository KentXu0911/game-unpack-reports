# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339752c: f40f1ef8 str      x20, [sp, #-0x20]!
03397530: f37b01a9 stp      x19, x30, [sp, #0x10]
03397534: 54000012 and      w20, w2, #1
03397538: e203032a mov      w2, w3
0339753c: e3031faa mov      x3, xzr
03397540: f30300aa mov      x19, x0
03397544: 2e29cc97 bl       #0x26a19fc ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$.ctor
03397548: 28008052 mov      w8, #1
0339754c: 68ba00b9 str      w8, [x19, #0xb8]
03397550: 74f20239 strb     w20, [x19, #0xbc]
03397554: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397558: f40742f8 ldr      x20, [sp], #0x20
0339755c: c0035fd6 ret      
