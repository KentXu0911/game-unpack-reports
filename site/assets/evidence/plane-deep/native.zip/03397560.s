# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.PropellerItemModel$$CreateView
# Linear span to next metadata entry; not a complete CFG.
03397560: ea0f1dfc str      d10, [sp, #-0x30]!
03397564: e9a3006d stp      d9, d8, [sp, #8]
03397568: f40f00f9 str      x20, [sp, #0x18]
0339756c: f37b02a9 stp      x19, x30, [sp, #0x20]
03397570: 740f01f0 adrp     x20, #0x5586000
03397574: 882a6639 ldrb     w8, [x20, #0x98a]
03397578: 481ca24e mov      v8.16b, v2.16b
0339757c: 291ca14e mov      v9.16b, v1.16b
03397580: 0a1ca04e mov      v10.16b, v0.16b
03397584: f30300aa mov      x19, x0
03397588: c8000037 tbnz     w8, #0, #0x33975a0
0339758c: 00f300d0 adrp     x0, #0x51f9000
03397590: 007845f9 ldr      x0, [x0, #0xaf0]
03397594: 5b677097 bl       #0xfb1300
03397598: 28008052 mov      w8, #1
0339759c: 882a2639 strb     w8, [x20, #0x98a]
033975a0: 602e40f9 ldr      x0, [x19, #0x58]
033975a4: a00500b4 cbz      x0, #0x3397658
033975a8: 08f300d0 adrp     x8, #0x51f9000
033975ac: 087945f9 ldr      x8, [x8, #0xaf0]
033975b0: 41018052 mov      w1, #0xa
033975b4: 22008052 mov      w2, #1
033975b8: 030140f9 ldr      x3, [x8]
033975bc: ed8dc697 bl       #0x253ad70 ; Royal.Scenes.Game.Levels.Units.ItemCreation.ItemFactory$$Spawn<object>
033975c0: f40313aa mov      x20, x19
033975c4: 808e0cf8 str      x0, [x20, #0xc8]!
033975c8: e10300aa mov      x1, x0
033975cc: e00314aa mov      x0, x20
033975d0: 37677097 bl       #0xfb12ac
033975d4: 800240f9 ldr      x0, [x20]
033975d8: 000400b4 cbz      x0, #0x3397658
033975dc: 080040f9 ldr      x8, [x0]
033975e0: e10313aa mov      x1, x19
033975e4: 401daa4e mov      v0.16b, v10.16b
033975e8: 211da94e mov      v1.16b, v9.16b
033975ec: 092542f9 ldr      x9, [x8, #0x448]
033975f0: 022942f9 ldr      x2, [x8, #0x450]
033975f4: 021da84e mov      v2.16b, v8.16b
033975f8: 20013fd6 blr      x9
033975fc: 680240f9 ldr      x8, [x19]
03397600: 21008052 mov      w1, #1
03397604: e00313aa mov      x0, x19
03397608: 09b541f9 ldr      x9, [x8, #0x368]
0339760c: 02b941f9 ldr      x2, [x8, #0x370]
03397610: 20013fd6 blr      x9
03397614: 68424539 ldrb     w8, [x19, #0x150]
03397618: 68010034 cbz      w8, #0x3397644
0339761c: 800240f9 ldr      x0, [x20]
03397620: c00100b4 cbz      x0, #0x3397658
03397624: 080040f9 ldr      x8, [x0]
03397628: f37b42a9 ldp      x19, x30, [sp, #0x20]
0339762c: f40f40f9 ldr      x20, [sp, #0x18]
03397630: e9a3406d ldp      d9, d8, [sp, #8]
03397634: 02d541f9 ldr      x2, [x8, #0x3a8]
03397638: 01d941f9 ldr      x1, [x8, #0x3b0]
0339763c: ea0743fc ldr      d10, [sp], #0x30
03397640: 40001fd6 br       x2
03397644: f37b42a9 ldp      x19, x30, [sp, #0x20]
03397648: f40f40f9 ldr      x20, [sp, #0x18]
0339764c: e9a3406d ldp      d9, d8, [sp, #8]
03397650: ea0743fc ldr      d10, [sp], #0x30
03397654: c0035fd6 ret      
03397658: 74677097 bl       #0xfb1428
