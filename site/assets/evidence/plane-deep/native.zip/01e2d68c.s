# Royal.Scenes.Game.Mechanics.Items.MagicCubeItem.MagicCubeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e2d68c: f553bea9 stp      x21, x20, [sp, #-0x20]!
01e2d690: f37b01a9 stp      x19, x30, [sp, #0x10]
01e2d694: 080040f9 ldr      x8, [x0]
01e2d698: f403012a mov      w20, w1
01e2d69c: f30300aa mov      x19, x0
01e2d6a0: 096542f9 ldr      x9, [x8, #0x4c8]
01e2d6a4: 086942f9 ldr      x8, [x8, #0x4d0]
01e2d6a8: e10308aa mov      x1, x8
01e2d6ac: 20013fd6 blr      x9
01e2d6b0: 1f040071 cmp      w0, #1
01e2d6b4: 0b040054 b.lt     #0x1e2d734
01e2d6b8: e003142a mov      w0, w20
01e2d6bc: e1031faa mov      x1, xzr
01e2d6c0: 9f5c5594 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
01e2d6c4: c0030036 tbz      w0, #0, #0x1e2d73c
01e2d6c8: 680240f9 ldr      x8, [x19]
01e2d6cc: e00313aa mov      x0, x19
01e2d6d0: 096542f9 ldr      x9, [x8, #0x4c8]
01e2d6d4: 016942f9 ldr      x1, [x8, #0x4d0]
01e2d6d8: 20013fd6 blr      x9
01e2d6dc: 1f040071 cmp      w0, #1
01e2d6e0: a1080054 b.ne     #0x1e2d7f4
01e2d6e4: 680240f9 ldr      x8, [x19]
01e2d6e8: e00313aa mov      x0, x19
01e2d6ec: 09bd41f9 ldr      x9, [x8, #0x378]
01e2d6f0: 01c141f9 ldr      x1, [x8, #0x380]
01e2d6f4: 20013fd6 blr      x9
01e2d6f8: e1031faa mov      x1, xzr
01e2d6fc: a35c5594 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e2d700: 685e40f9 ldr      x8, [x19, #0xb8]
01e2d704: a80800b4 cbz      x8, #0x1e2d818
01e2d708: f503002a mov      w21, w0
01e2d70c: e00308aa mov      x0, x8
01e2d710: e1031faa mov      x1, xzr
01e2d714: 14390d94 bl       #0x217bb64 ; Royal.Scenes.Game.Mechanics.Items.AncientVaultItem.AncientVaultItemHelper$$GetMagicCubeItemCountOnBoard
01e2d718: a80e0011 add      w8, w21, #3
01e2d71c: bf020071 cmp      w21, #0
01e2d720: 08b1951a csel     w8, w8, w21, lt
01e2d724: 087d0213 asr      w8, w8, #2
01e2d728: 09040051 sub      w9, w0, #1
01e2d72c: 357d081b mul      w21, w9, w8
01e2d730: 32000014 b        #0x1e2d7f8
01e2d734: e0031f2a mov      w0, wzr
01e2d738: 35000014 b        #0x1e2d80c
01e2d73c: e0031faa mov      x0, xzr
01e2d740: 73427b94 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
01e2d744: 68c240b9 ldr      w8, [x19, #0xc0]
01e2d748: 1f00086b cmp      w0, w8
01e2d74c: 20020054 b.eq     #0x1e2d790
01e2d750: 755e40f9 ldr      x21, [x19, #0xb8]
01e2d754: e00313aa mov      x0, x19
01e2d758: e1031faa mov      x1, xzr
01e2d75c: ce555594 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
01e2d760: c00500b4 cbz      x0, #0x1e2d818
01e2d764: e1031faa mov      x1, xzr
01e2d768: a66e3294 bl       #0x2ac9200 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetBoardAdjustedPoint
01e2d76c: 750500b4 cbz      x21, #0x1e2d818
01e2d770: e20300aa mov      x2, x0
01e2d774: e00315aa mov      x0, x21
01e2d778: e103142a mov      w1, w20
01e2d77c: e3031faa mov      x3, xzr
01e2d780: f1390d94 bl       #0x217bf44 ; Royal.Scenes.Game.Mechanics.Items.AncientVaultItem.AncientVaultItemHelper$$UpdateExtraScoreCache
01e2d784: e0031faa mov      x0, xzr
01e2d788: 61427b94 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
01e2d78c: 60c200b9 str      w0, [x19, #0xc0]
01e2d790: 605e40f9 ldr      x0, [x19, #0xb8]
01e2d794: 200400b4 cbz      x0, #0x1e2d818
01e2d798: e1031faa mov      x1, xzr
01e2d79c: f2380d94 bl       #0x217bb64 ; Royal.Scenes.Game.Mechanics.Items.AncientVaultItem.AncientVaultItemHelper$$GetMagicCubeItemCountOnBoard
01e2d7a0: 680240f9 ldr      x8, [x19]
01e2d7a4: f503002a mov      w21, w0
01e2d7a8: e00313aa mov      x0, x19
01e2d7ac: 096542f9 ldr      x9, [x8, #0x4c8]
01e2d7b0: 016942f9 ldr      x1, [x8, #0x4d0]
01e2d7b4: 20013fd6 blr      x9
01e2d7b8: b502006b subs     w21, w21, w0
01e2d7bc: c4010054 b.mi     #0x1e2d7f4
01e2d7c0: 680240f9 ldr      x8, [x19]
01e2d7c4: e00313aa mov      x0, x19
01e2d7c8: 09bd41f9 ldr      x9, [x8, #0x378]
01e2d7cc: 01c141f9 ldr      x1, [x8, #0x380]
01e2d7d0: 20013fd6 blr      x9
01e2d7d4: e1031faa mov      x1, xzr
01e2d7d8: 6c5c5594 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e2d7dc: 080c0011 add      w8, w0, #3
01e2d7e0: 1f000071 cmp      w0, #0
01e2d7e4: 08b1801a csel     w8, w8, w0, lt
01e2d7e8: 087d0213 asr      w8, w8, #2
01e2d7ec: 157d151b mul      w21, w8, w21
01e2d7f0: 02000014 b        #0x1e2d7f8
01e2d7f4: f5031f2a mov      w21, wzr
01e2d7f8: e00313aa mov      x0, x19
01e2d7fc: e103142a mov      w1, w20
01e2d800: e2031faa mov      x2, xzr
01e2d804: 5a5c5594 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
01e2d808: 0000150b add      w0, w0, w21
01e2d80c: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e2d810: f553c2a8 ldp      x21, x20, [sp], #0x20
01e2d814: c0035fd6 ret      
01e2d818: 040fc697 bl       #0xfb1428
