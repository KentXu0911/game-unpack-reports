# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryDeregisterForTargetChange
# Linear span to next metadata entry; not a complete CFG.
026a2480: f963bca9 stp      x25, x24, [sp, #-0x40]!
026a2484: f75b01a9 stp      x23, x22, [sp, #0x10]
026a2488: f55302a9 stp      x21, x20, [sp, #0x20]
026a248c: f37b03a9 stp      x19, x30, [sp, #0x30]
026a2490: f47601d0 adrp     x20, #0x5580000
026a2494: 880a4139 ldrb     w8, [x20, #0x42]
026a2498: f30300aa mov      x19, x0
026a249c: c8060037 tbnz     w8, #0, #0x26a2574
026a24a0: c05801b0 adrp     x0, #0x51bb000
026a24a4: 009c46f9 ldr      x0, [x0, #0xd38]
026a24a8: 963ba497 bl       #0xfb1300
026a24ac: 405c01d0 adrp     x0, #0x522c000
026a24b0: 00e443f9 ldr      x0, [x0, #0x7c8]
026a24b4: 933ba497 bl       #0xfb1300
026a24b8: a0580190 adrp     x0, #0x51b6000
026a24bc: 00d846f9 ldr      x0, [x0, #0xdb0]
026a24c0: 903ba497 bl       #0xfb1300
026a24c4: a05801b0 adrp     x0, #0x51b7000
026a24c8: 001c44f9 ldr      x0, [x0, #0x838]
026a24cc: 8d3ba497 bl       #0xfb1300
026a24d0: 405c01d0 adrp     x0, #0x522c000
026a24d4: 00c040f9 ldr      x0, [x0, #0x180]
026a24d8: 8a3ba497 bl       #0xfb1300
026a24dc: 405901d0 adrp     x0, #0x51cc000
026a24e0: 00bc45f9 ldr      x0, [x0, #0xb78]
026a24e4: 873ba497 bl       #0xfb1300
026a24e8: e05a0190 adrp     x0, #0x51fe000
026a24ec: 001c44f9 ldr      x0, [x0, #0x838]
026a24f0: 843ba497 bl       #0xfb1300
026a24f4: c05801d0 adrp     x0, #0x51bc000
026a24f8: 003c45f9 ldr      x0, [x0, #0xa78]
026a24fc: 813ba497 bl       #0xfb1300
026a2500: 805b01f0 adrp     x0, #0x5215000
026a2504: 004445f9 ldr      x0, [x0, #0xa88]
026a2508: 7e3ba497 bl       #0xfb1300
026a250c: 405c01f0 adrp     x0, #0x522d000
026a2510: 001447f9 ldr      x0, [x0, #0xe28]
026a2514: 7b3ba497 bl       #0xfb1300
026a2518: c05c01d0 adrp     x0, #0x523c000
026a251c: 00cc44f9 ldr      x0, [x0, #0x998]
026a2520: 783ba497 bl       #0xfb1300
026a2524: a05901b0 adrp     x0, #0x51d7000
026a2528: 007840f9 ldr      x0, [x0, #0xf0]
026a252c: 753ba497 bl       #0xfb1300
026a2530: 605901d0 adrp     x0, #0x51d0000
026a2534: 007840f9 ldr      x0, [x0, #0xf0]
026a2538: 723ba497 bl       #0xfb1300
026a253c: 605701d0 adrp     x0, #0x5190000
026a2540: 007444f9 ldr      x0, [x0, #0x8e8]
026a2544: 6f3ba497 bl       #0xfb1300
026a2548: 405c0190 adrp     x0, #0x522a000
026a254c: 003440f9 ldr      x0, [x0, #0x68]
026a2550: 6c3ba497 bl       #0xfb1300
026a2554: 605901b0 adrp     x0, #0x51cf000
026a2558: 004845f9 ldr      x0, [x0, #0xa90]
026a255c: 693ba497 bl       #0xfb1300
026a2560: 605a0190 adrp     x0, #0x51ee000
026a2564: 00e444f9 ldr      x0, [x0, #0x9c8]
026a2568: 663ba497 bl       #0xfb1300
026a256c: 28008052 mov      w8, #1
026a2570: 880a0139 strb     w8, [x20, #0x42]
026a2574: 602640f9 ldr      x0, [x19, #0x48]
026a2578: 803b00b4 cbz      x0, #0x26a2ce8
026a257c: d85801b0 adrp     x24, #0x51bb000
026a2580: b75801b0 adrp     x23, #0x51b7000
026a2584: 189f46f9 ldr      x24, [x24, #0xd38]
026a2588: f71e44f9 ldr      x23, [x23, #0x838]
026a258c: 81058052 mov      w1, #0x2c
026a2590: e2031faa mov      x2, xzr
026a2594: 6ee1e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2598: a0020036 tbz      w0, #0, #0x26a25ec
026a259c: c85c01d0 adrp     x8, #0x523c000
026a25a0: 08cd44f9 ldr      x8, [x8, #0x998]
026a25a4: 40058052 mov      w0, #0x2a
026a25a8: 010140f9 ldr      x1, [x8]
026a25ac: 3071fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a25b0: 080340f9 ldr      x8, [x24]
026a25b4: f40300aa mov      x20, x0
026a25b8: e00308aa mov      x0, x8
026a25bc: 973ba497 bl       #0xfb1418
026a25c0: 403900b4 cbz      x0, #0x26a2ce8
026a25c4: e20240f9 ldr      x2, [x23]
026a25c8: e10313aa mov      x1, x19
026a25cc: e3031faa mov      x3, xzr
026a25d0: f50300aa mov      x21, x0
026a25d4: a789e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a25d8: 943800b4 cbz      x20, #0x26a2ce8
026a25dc: e00314aa mov      x0, x20
026a25e0: e10315aa mov      x1, x21
026a25e4: e2031faa mov      x2, xzr
026a25e8: 4edf0094 bl       #0x26da320 ; Royal.Scenes.Game.Mechanics.Items.GummyItem.GummyItemHelper$$remove_OnItemSpawned
026a25ec: 602640f9 ldr      x0, [x19, #0x48]
026a25f0: c03700b4 cbz      x0, #0x26a2ce8
026a25f4: a1038052 mov      w1, #0x1d
026a25f8: e2031faa mov      x2, xzr
026a25fc: 54e1e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2600: e0020036 tbz      w0, #0, #0x26a265c
026a2604: c85801d0 adrp     x8, #0x51bc000
026a2608: 083d45f9 ldr      x8, [x8, #0xa78]
026a260c: e0038052 mov      w0, #0x1f
026a2610: 010140f9 ldr      x1, [x8]
026a2614: 1671fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2618: 080340f9 ldr      x8, [x24]
026a261c: f40300aa mov      x20, x0
026a2620: e00308aa mov      x0, x8
026a2624: 7d3ba497 bl       #0xfb1418
026a2628: 003600b4 cbz      x0, #0x26a2ce8
026a262c: a8580190 adrp     x8, #0x51b6000
026a2630: 08d946f9 ldr      x8, [x8, #0xdb0]
026a2634: e10313aa mov      x1, x19
026a2638: e3031faa mov      x3, xzr
026a263c: f50300aa mov      x21, x0
026a2640: 020140f9 ldr      x2, [x8]
026a2644: 8b89e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2648: 143500b4 cbz      x20, #0x26a2ce8
026a264c: e00314aa mov      x0, x20
026a2650: e10315aa mov      x1, x21
026a2654: e2031faa mov      x2, xzr
026a2658: 2e831c94 bl       #0x2dc3310 ; Royal.Scenes.Game.Mechanics.Items.DrillItem.DrillHelper$$remove_OnDrillActivated
026a265c: 602640f9 ldr      x0, [x19, #0x48]
026a2660: 403400b4 cbz      x0, #0x26a2ce8
026a2664: 01018052 mov      w1, #8
026a2668: e2031faa mov      x2, xzr
026a266c: 06e1e697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2670: c0020036 tbz      w0, #0, #0x26a26c8
026a2674: 685a0190 adrp     x8, #0x51ee000
026a2678: 08e544f9 ldr      x8, [x8, #0x9c8]
026a267c: c0058052 mov      w0, #0x2e
026a2680: 010140f9 ldr      x1, [x8]
026a2684: fa70fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2688: 080340f9 ldr      x8, [x24]
026a268c: f40300aa mov      x20, x0
026a2690: e00308aa mov      x0, x8
026a2694: 613ba497 bl       #0xfb1418
026a2698: 803200b4 cbz      x0, #0x26a2ce8
026a269c: 680240f9 ldr      x8, [x19]
026a26a0: e10313aa mov      x1, x19
026a26a4: e3031faa mov      x3, xzr
026a26a8: f50300aa mov      x21, x0
026a26ac: 023145f9 ldr      x2, [x8, #0xa60]
026a26b0: 7089e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a26b4: b43100b4 cbz      x20, #0x26a2ce8
026a26b8: e00314aa mov      x0, x20
026a26bc: e10315aa mov      x1, x21
026a26c0: e2031faa mov      x2, xzr
026a26c4: 55e3af97 bl       #0x129b418 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.TreasureMapItem.TreasureMapHelper$$remove_OnTreasureMapReveal
026a26c8: 602640f9 ldr      x0, [x19, #0x48]
026a26cc: e03000b4 cbz      x0, #0x26a2ce8
026a26d0: a1068052 mov      w1, #0x35
026a26d4: e2031faa mov      x2, xzr
026a26d8: 1de1e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a26dc: e0020036 tbz      w0, #0, #0x26a2738
026a26e0: 000340f9 ldr      x0, [x24]
026a26e4: 4d3ba497 bl       #0xfb1418
026a26e8: 003000b4 cbz      x0, #0x26a2ce8
026a26ec: e20240f9 ldr      x2, [x23]
026a26f0: e10313aa mov      x1, x19
026a26f4: e3031faa mov      x3, xzr
026a26f8: f40300aa mov      x20, x0
026a26fc: 5d89e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2700: e00314aa mov      x0, x20
026a2704: e1031faa mov      x1, xzr
026a2708: 0e351094 bl       #0x2aafb40 ; Royal.Scenes.Game.Mechanics.Items.DuckShootingItem.DuckShootingItemRegistry$$remove_OnFirstSetFinished
026a270c: 000340f9 ldr      x0, [x24]
026a2710: 423ba497 bl       #0xfb1418
026a2714: a02e00b4 cbz      x0, #0x26a2ce8
026a2718: e20240f9 ldr      x2, [x23]
026a271c: e10313aa mov      x1, x19
026a2720: e3031faa mov      x3, xzr
026a2724: f40300aa mov      x20, x0
026a2728: 5289e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a272c: e00314aa mov      x0, x20
026a2730: e1031faa mov      x1, xzr
026a2734: 60351094 bl       #0x2aafcb4 ; Royal.Scenes.Game.Mechanics.Items.DuckShootingItem.DuckShootingItemRegistry$$remove_OnSecondSetStarted
026a2738: 602640f9 ldr      x0, [x19, #0x48]
026a273c: 602d00b4 cbz      x0, #0x26a2ce8
026a2740: a1078052 mov      w1, #0x3d
026a2744: e2031faa mov      x2, xzr
026a2748: 01e1e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a274c: 80010036 tbz      w0, #0, #0x26a277c
026a2750: 000340f9 ldr      x0, [x24]
026a2754: 313ba497 bl       #0xfb1418
026a2758: 802c00b4 cbz      x0, #0x26a2ce8
026a275c: e20240f9 ldr      x2, [x23]
026a2760: e10313aa mov      x1, x19
026a2764: e3031faa mov      x3, xzr
026a2768: f40300aa mov      x20, x0
026a276c: 4189e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2770: e00314aa mov      x0, x20
026a2774: e1031faa mov      x1, xzr
026a2778: a11f1a94 bl       #0x2d2a5fc ; Royal.Scenes.Game.Mechanics.Items.CoilItem.CoilItemHelper$$remove_OnDoorOpen
026a277c: 602640f9 ldr      x0, [x19, #0x48]
026a2780: 402b00b4 cbz      x0, #0x26a2ce8
026a2784: 61088052 mov      w1, #0x43
026a2788: e2031faa mov      x2, xzr
026a278c: f0e0e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2790: a0020036 tbz      w0, #0, #0x26a27e4
026a2794: 485c01f0 adrp     x8, #0x522d000
026a2798: 081547f9 ldr      x8, [x8, #0xe28]
026a279c: 20088052 mov      w0, #0x41
026a27a0: 010140f9 ldr      x1, [x8]
026a27a4: b270fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a27a8: 080340f9 ldr      x8, [x24]
026a27ac: f40300aa mov      x20, x0
026a27b0: e00308aa mov      x0, x8
026a27b4: 193ba497 bl       #0xfb1418
026a27b8: 802900b4 cbz      x0, #0x26a2ce8
026a27bc: e20240f9 ldr      x2, [x23]
026a27c0: e10313aa mov      x1, x19
026a27c4: e3031faa mov      x3, xzr
026a27c8: f50300aa mov      x21, x0
026a27cc: 2989e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a27d0: d42800b4 cbz      x20, #0x26a2ce8
026a27d4: e00314aa mov      x0, x20
026a27d8: e10315aa mov      x1, x21
026a27dc: e2031faa mov      x2, xzr
026a27e0: fc1c1b94 bl       #0x2d69bd0 ; Royal.Scenes.Game.Mechanics.Items.GiantPiggyItem.GiantPiggyItemHelper$$remove_OnItemSpawned
026a27e4: 602640f9 ldr      x0, [x19, #0x48]
026a27e8: 002800b4 cbz      x0, #0x26a2ce8
026a27ec: e10d8052 mov      w1, #0x6f
026a27f0: e2031faa mov      x2, xzr
026a27f4: d6e0e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a27f8: a0020036 tbz      w0, #0, #0x26a284c
026a27fc: 685901b0 adrp     x8, #0x51cf000
026a2800: 084945f9 ldr      x8, [x8, #0xa90]
026a2804: 400d8052 mov      w0, #0x6a
026a2808: 010140f9 ldr      x1, [x8]
026a280c: 9870fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2810: 080340f9 ldr      x8, [x24]
026a2814: f40300aa mov      x20, x0
026a2818: e00308aa mov      x0, x8
026a281c: ff3aa497 bl       #0xfb1418
026a2820: 402600b4 cbz      x0, #0x26a2ce8
026a2824: e20240f9 ldr      x2, [x23]
026a2828: e10313aa mov      x1, x19
026a282c: e3031faa mov      x3, xzr
026a2830: f50300aa mov      x21, x0
026a2834: 0f89e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2838: 942500b4 cbz      x20, #0x26a2ce8
026a283c: e00314aa mov      x0, x20
026a2840: e10315aa mov      x1, x21
026a2844: e2031faa mov      x2, xzr
026a2848: 43115d94 bl       #0x3de6d54 ; Royal.Scenes.Game.Mechanics.Items.ToyBoatItem.ToyBoatItemHelper$$remove_OnItemSpawned
026a284c: 602640f9 ldr      x0, [x19, #0x48]
026a2850: c02400b4 cbz      x0, #0x26a2ce8
026a2854: c1088052 mov      w1, #0x46
026a2858: e2031faa mov      x2, xzr
026a285c: bce0e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2860: a0020036 tbz      w0, #0, #0x26a28b4
026a2864: 685701d0 adrp     x8, #0x5190000
026a2868: 087544f9 ldr      x8, [x8, #0x8e8]
026a286c: e0088052 mov      w0, #0x47
026a2870: 010140f9 ldr      x1, [x8]
026a2874: 7e70fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2878: 080340f9 ldr      x8, [x24]
026a287c: f40300aa mov      x20, x0
026a2880: e00308aa mov      x0, x8
026a2884: e53aa497 bl       #0xfb1418
026a2888: 002300b4 cbz      x0, #0x26a2ce8
026a288c: e20240f9 ldr      x2, [x23]
026a2890: e10313aa mov      x1, x19
026a2894: e3031faa mov      x3, xzr
026a2898: f50300aa mov      x21, x0
026a289c: f588e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a28a0: 542200b4 cbz      x20, #0x26a2ce8
026a28a4: e00314aa mov      x0, x20
026a28a8: e10315aa mov      x1, x21
026a28ac: e2031faa mov      x2, xzr
026a28b0: 03bbd597 bl       #0x1c114bc ; Royal.Scenes.Game.Mechanics.Items.PorcelainItem.PorcelainItemHelper$$remove_OnItemSpawned
026a28b4: 602640f9 ldr      x0, [x19, #0x48]
026a28b8: 802100b4 cbz      x0, #0x26a2ce8
026a28bc: 595c01d0 adrp     x25, #0x522c000
026a28c0: 39e743f9 ldr      x25, [x25, #0x7c8]
026a28c4: 61018052 mov      w1, #0xb
026a28c8: e2031faa mov      x2, xzr
026a28cc: 6ee0e697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a28d0: 00040036 tbz      w0, #0, #0x26a2950
026a28d4: 485c01d0 adrp     x8, #0x522c000
026a28d8: 08c140f9 ldr      x8, [x8, #0x180]
026a28dc: 40088052 mov      w0, #0x42
026a28e0: 010140f9 ldr      x1, [x8]
026a28e4: 6270fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a28e8: 681641b9 ldr      w8, [x19, #0x114]
026a28ec: f40300aa mov      x20, x0
026a28f0: e1031faa mov      x1, xzr
026a28f4: e003082a mov      w0, w8
026a28f8: 4e5f1a94 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
026a28fc: e1031faa mov      x1, xzr
026a2900: 0f883394 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026a2904: 080340f9 ldr      x8, [x24]
026a2908: f603002a mov      w22, w0
026a290c: e00308aa mov      x0, x8
026a2910: c23aa497 bl       #0xfb1418
026a2914: a01e00b4 cbz      x0, #0x26a2ce8
026a2918: f50300aa mov      x21, x0
026a291c: 76000036 tbz      w22, #0, #0x26a2928
026a2920: e20240f9 ldr      x2, [x23]
026a2924: 02000014 b        #0x26a292c
026a2928: 220340f9 ldr      x2, [x25]
026a292c: e00315aa mov      x0, x21
026a2930: e10313aa mov      x1, x19
026a2934: e3031faa mov      x3, xzr
026a2938: ce88e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a293c: 741d00b4 cbz      x20, #0x26a2ce8
026a2940: e00314aa mov      x0, x20
026a2944: e10315aa mov      x1, x21
026a2948: e2031faa mov      x2, xzr
026a294c: 2e6fc797 bl       #0x187e604 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.BlindsItem.BlindsItemHelper$$remove_OnBlindsItemReveal
026a2950: 602640f9 ldr      x0, [x19, #0x48]
026a2954: a01c00b4 cbz      x0, #0x26a2ce8
026a2958: 41028052 mov      w1, #0x12
026a295c: e2031faa mov      x2, xzr
026a2960: 49e0e697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2964: 00040036 tbz      w0, #0, #0x26a29e4
026a2968: 685901d0 adrp     x8, #0x51d0000
026a296c: 087940f9 ldr      x8, [x8, #0xf0]
026a2970: 000d8052 mov      w0, #0x68
026a2974: 010140f9 ldr      x1, [x8]
026a2978: 3d70fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a297c: 681641b9 ldr      w8, [x19, #0x114]
026a2980: f40300aa mov      x20, x0
026a2984: e1031faa mov      x1, xzr
026a2988: e003082a mov      w0, w8
026a298c: 295f1a94 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
026a2990: e1031faa mov      x1, xzr
026a2994: ea873394 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026a2998: 080340f9 ldr      x8, [x24]
026a299c: f603002a mov      w22, w0
026a29a0: e00308aa mov      x0, x8
026a29a4: 9d3aa497 bl       #0xfb1418
026a29a8: 001a00b4 cbz      x0, #0x26a2ce8
026a29ac: f50300aa mov      x21, x0
026a29b0: 76000036 tbz      w22, #0, #0x26a29bc
026a29b4: e20240f9 ldr      x2, [x23]
026a29b8: 02000014 b        #0x26a29c0
026a29bc: 220340f9 ldr      x2, [x25]
026a29c0: e00315aa mov      x0, x21
026a29c4: e10313aa mov      x1, x19
026a29c8: e3031faa mov      x3, xzr
026a29cc: a988e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a29d0: d41800b4 cbz      x20, #0x26a2ce8
026a29d4: e00314aa mov      x0, x20
026a29d8: e10315aa mov      x1, x21
026a29dc: e2031faa mov      x2, xzr
026a29e0: 99deba97 bl       #0x155a444 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.MetalPlateItem.MetalPlateItemHelper$$remove_OnMetalPlateItemReveal
026a29e4: 602640f9 ldr      x0, [x19, #0x48]
026a29e8: 001800b4 cbz      x0, #0x26a2ce8
026a29ec: a1008052 mov      w1, #5
026a29f0: e2031faa mov      x2, xzr
026a29f4: 24e0e697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a29f8: c0020036 tbz      w0, #0, #0x26a2a50
026a29fc: e85a0190 adrp     x8, #0x51fe000
026a2a00: 081d44f9 ldr      x8, [x8, #0x838]
026a2a04: 40038052 mov      w0, #0x1a
026a2a08: 010140f9 ldr      x1, [x8]
026a2a0c: 1870fa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2a10: 080340f9 ldr      x8, [x24]
026a2a14: f40300aa mov      x20, x0
026a2a18: e00308aa mov      x0, x8
026a2a1c: 7f3aa497 bl       #0xfb1418
026a2a20: 401600b4 cbz      x0, #0x26a2ce8
026a2a24: 680240f9 ldr      x8, [x19]
026a2a28: e10313aa mov      x1, x19
026a2a2c: e3031faa mov      x3, xzr
026a2a30: f50300aa mov      x21, x0
026a2a34: 023145f9 ldr      x2, [x8, #0xa60]
026a2a38: 8e88e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2a3c: 741500b4 cbz      x20, #0x26a2ce8
026a2a40: e00314aa mov      x0, x20
026a2a44: e10315aa mov      x1, x21
026a2a48: e2031faa mov      x2, xzr
026a2a4c: 1c99bc97 bl       #0x15c8ebc ; Royal.Scenes.Game.Mechanics.Items.StaticItems.CurtainItem.CurtainHelper$$remove_OnCurtainReveal
026a2a50: 602640f9 ldr      x0, [x19, #0x48]
026a2a54: a01400b4 cbz      x0, #0x26a2ce8
026a2a58: 01028052 mov      w1, #0x10
026a2a5c: e2031faa mov      x2, xzr
026a2a60: 09e0e697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2a64: c0020036 tbz      w0, #0, #0x26a2abc
026a2a68: 485901d0 adrp     x8, #0x51cc000
026a2a6c: 08bd45f9 ldr      x8, [x8, #0xb78]
026a2a70: 400a8052 mov      w0, #0x52
026a2a74: 010140f9 ldr      x1, [x8]
026a2a78: fd6ffa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2a7c: 080340f9 ldr      x8, [x24]
026a2a80: f40300aa mov      x20, x0
026a2a84: e00308aa mov      x0, x8
026a2a88: 643aa497 bl       #0xfb1418
026a2a8c: e01200b4 cbz      x0, #0x26a2ce8
026a2a90: 680240f9 ldr      x8, [x19]
026a2a94: e10313aa mov      x1, x19
026a2a98: e3031faa mov      x3, xzr
026a2a9c: f50300aa mov      x21, x0
026a2aa0: 023145f9 ldr      x2, [x8, #0xa60]
026a2aa4: 7388e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2aa8: 141200b4 cbz      x20, #0x26a2ce8
026a2aac: e00314aa mov      x0, x20
026a2ab0: e10315aa mov      x1, x21
026a2ab4: e2031faa mov      x2, xzr
026a2ab8: 8038c797 bl       #0x1870cb8 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.CryptexItem.CryptexItemHelper$$remove_OnCryptexReveal
026a2abc: 602640f9 ldr      x0, [x19, #0x48]
026a2ac0: 401100b4 cbz      x0, #0x26a2ce8
026a2ac4: 61098052 mov      w1, #0x4b
026a2ac8: e2031faa mov      x2, xzr
026a2acc: 20e0e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2ad0: 80010036 tbz      w0, #0, #0x26a2b00
026a2ad4: 000340f9 ldr      x0, [x24]
026a2ad8: 503aa497 bl       #0xfb1418
026a2adc: 601000b4 cbz      x0, #0x26a2ce8
026a2ae0: e20240f9 ldr      x2, [x23]
026a2ae4: e10313aa mov      x1, x19
026a2ae8: e3031faa mov      x3, xzr
026a2aec: f40300aa mov      x20, x0
026a2af0: 6088e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2af4: e00314aa mov      x0, x20
026a2af8: e1031faa mov      x1, xzr
026a2afc: dd60eb97 bl       #0x217ae70 ; Royal.Scenes.Game.Mechanics.Items.AncientVaultItem.AncientVaultItemHelper$$remove_OnDoorOpen
026a2b00: 602640f9 ldr      x0, [x19, #0x48]
026a2b04: 200f00b4 cbz      x0, #0x26a2ce8
026a2b08: 010e8052 mov      w1, #0x70
026a2b0c: e2031faa mov      x2, xzr
026a2b10: 0fe0e697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2b14: 80010036 tbz      w0, #0, #0x26a2b44
026a2b18: 000340f9 ldr      x0, [x24]
026a2b1c: 3f3aa497 bl       #0xfb1418
026a2b20: 400e00b4 cbz      x0, #0x26a2ce8
026a2b24: e20240f9 ldr      x2, [x23]
026a2b28: e10313aa mov      x1, x19
026a2b2c: e3031faa mov      x3, xzr
026a2b30: f40300aa mov      x20, x0
026a2b34: 4f88e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2b38: e00314aa mov      x0, x20
026a2b3c: e1031faa mov      x1, xzr
026a2b40: 6f302994 bl       #0x30eecfc ; Royal.Scenes.Game.Mechanics.Items.ColorMixerItem.ColorMixerItemHelper$$remove_OnDoorOpen
026a2b44: 602640f9 ldr      x0, [x19, #0x48]
026a2b48: 000d00b4 cbz      x0, #0x26a2ce8
026a2b4c: e1018052 mov      w1, #0xf
026a2b50: e2031faa mov      x2, xzr
026a2b54: ccdfe697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2b58: c0020036 tbz      w0, #0, #0x26a2bb0
026a2b5c: 885b01f0 adrp     x8, #0x5215000
026a2b60: 084545f9 ldr      x8, [x8, #0xa88]
026a2b64: a0098052 mov      w0, #0x4d
026a2b68: 010140f9 ldr      x1, [x8]
026a2b6c: c06ffa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2b70: 080340f9 ldr      x8, [x24]
026a2b74: f40300aa mov      x20, x0
026a2b78: e00308aa mov      x0, x8
026a2b7c: 273aa497 bl       #0xfb1418
026a2b80: 400b00b4 cbz      x0, #0x26a2ce8
026a2b84: 680240f9 ldr      x8, [x19]
026a2b88: e10313aa mov      x1, x19
026a2b8c: e3031faa mov      x3, xzr
026a2b90: f50300aa mov      x21, x0
026a2b94: 023145f9 ldr      x2, [x8, #0xa60]
026a2b98: 3688e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2b9c: 740a00b4 cbz      x20, #0x26a2ce8
026a2ba0: e00314aa mov      x0, x20
026a2ba4: e10315aa mov      x1, x21
026a2ba8: e2031faa mov      x2, xzr
026a2bac: 1e1ad497 bl       #0x1ba9424 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.ForceFieldItem.ForceFieldItemHelper$$remove_OnReveal
026a2bb0: 602640f9 ldr      x0, [x19, #0x48]
026a2bb4: a00900b4 cbz      x0, #0x26a2ce8
026a2bb8: e1098052 mov      w1, #0x4f
026a2bbc: e2031faa mov      x2, xzr
026a2bc0: e3dfe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2bc4: 80010036 tbz      w0, #0, #0x26a2bf4
026a2bc8: 000340f9 ldr      x0, [x24]
026a2bcc: 133aa497 bl       #0xfb1418
026a2bd0: c00800b4 cbz      x0, #0x26a2ce8
026a2bd4: e20240f9 ldr      x2, [x23]
026a2bd8: e10313aa mov      x1, x19
026a2bdc: e3031faa mov      x3, xzr
026a2be0: f40300aa mov      x20, x0
026a2be4: 2388e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2be8: e00314aa mov      x0, x20
026a2bec: e1031faa mov      x1, xzr
026a2bf0: 8b31de97 bl       #0x1e2f21c ; Royal.Scenes.Game.Mechanics.Items.LogItem.LogItemHelper$$remove_OnLatestReveal
026a2bf4: 602640f9 ldr      x0, [x19, #0x48]
026a2bf8: 800700b4 cbz      x0, #0x26a2ce8
026a2bfc: 410a8052 mov      w1, #0x52
026a2c00: e2031faa mov      x2, xzr
026a2c04: d2dfe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2c08: a0020036 tbz      w0, #0, #0x26a2c5c
026a2c0c: 485c0190 adrp     x8, #0x522a000
026a2c10: 083540f9 ldr      x8, [x8, #0x68]
026a2c14: 200a8052 mov      w0, #0x51
026a2c18: 010140f9 ldr      x1, [x8]
026a2c1c: 946ffa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2c20: 080340f9 ldr      x8, [x24]
026a2c24: f40300aa mov      x20, x0
026a2c28: e00308aa mov      x0, x8
026a2c2c: fb39a497 bl       #0xfb1418
026a2c30: c00500b4 cbz      x0, #0x26a2ce8
026a2c34: e20240f9 ldr      x2, [x23]
026a2c38: e10313aa mov      x1, x19
026a2c3c: e3031faa mov      x3, xzr
026a2c40: f50300aa mov      x21, x0
026a2c44: 0b88e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2c48: 140500b4 cbz      x20, #0x26a2ce8
026a2c4c: e00314aa mov      x0, x20
026a2c50: e10315aa mov      x1, x21
026a2c54: e2031faa mov      x2, xzr
026a2c58: ad20eb97 bl       #0x216af0c ; Royal.Scenes.Game.Mechanics.Items.ShuttleItem.ShuttleItemHelper$$remove_OnItemSpawned
026a2c5c: 602640f9 ldr      x0, [x19, #0x48]
026a2c60: 400400b4 cbz      x0, #0x26a2ce8
026a2c64: 210d8052 mov      w1, #0x69
026a2c68: e2031faa mov      x2, xzr
026a2c6c: b8dfe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a2c70: 20030036 tbz      w0, #0, #0x26a2cd4
026a2c74: a85901b0 adrp     x8, #0x51d7000
026a2c78: 087940f9 ldr      x8, [x8, #0xf0]
026a2c7c: 800c8052 mov      w0, #0x64
026a2c80: 010140f9 ldr      x1, [x8]
026a2c84: 7a6ffa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a2c88: 080340f9 ldr      x8, [x24]
026a2c8c: f40300aa mov      x20, x0
026a2c90: e00308aa mov      x0, x8
026a2c94: e139a497 bl       #0xfb1418
026a2c98: 800200b4 cbz      x0, #0x26a2ce8
026a2c9c: e20240f9 ldr      x2, [x23]
026a2ca0: e10313aa mov      x1, x19
026a2ca4: e3031faa mov      x3, xzr
026a2ca8: f50300aa mov      x21, x0
026a2cac: f187e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a2cb0: d40100b4 cbz      x20, #0x26a2ce8
026a2cb4: e00314aa mov      x0, x20
026a2cb8: e10315aa mov      x1, x21
026a2cbc: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a2cc0: f55342a9 ldp      x21, x20, [sp, #0x20]
026a2cc4: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a2cc8: e2031faa mov      x2, xzr
026a2ccc: f963c4a8 ldp      x25, x24, [sp], #0x40
026a2cd0: 6f03de17 b        #0x1e23a8c ; Royal.Scenes.Game.Mechanics.Items.MagicLanternItem.MagicLanternItemHelper$$remove_OnMagicLanternActivate
026a2cd4: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a2cd8: f55342a9 ldp      x21, x20, [sp, #0x20]
026a2cdc: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a2ce0: f963c4a8 ldp      x25, x24, [sp], #0x40
026a2ce4: c0035fd6 ret      
026a2ce8: d039a497 bl       #0xfb1428
