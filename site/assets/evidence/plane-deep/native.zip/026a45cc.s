# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$UnfreezeCellsWithDelay
# Linear span to next metadata entry; not a complete CFG.
026a45cc: f553bea9 stp      x21, x20, [sp, #-0x20]!
026a45d0: f37b01a9 stp      x19, x30, [sp, #0x10]
026a45d4: f4760190 adrp     x20, #0x5580000
026a45d8: 955801b0 adrp     x21, #0x51b5000
026a45dc: 880e4139 ldrb     w8, [x20, #0x43]
026a45e0: b5a645f9 ldr      x21, [x21, #0xb48]
026a45e4: f30300aa mov      x19, x0
026a45e8: c8000037 tbnz     w8, #0, #0x26a4600
026a45ec: 805801b0 adrp     x0, #0x51b5000
026a45f0: 00a445f9 ldr      x0, [x0, #0xb48]
026a45f4: 4333a497 bl       #0xfb1300
026a45f8: 28008052 mov      w8, #1
026a45fc: 880e0139 strb     w8, [x20, #0x43]
026a4600: a00240f9 ldr      x0, [x21]
026a4604: 8533a497 bl       #0xfb1418
026a4608: a00100b4 cbz      x0, #0x26a463c
026a460c: e1031faa mov      x1, xzr
026a4610: f40300aa mov      x20, x0
026a4614: f83bef97 bl       #0x22735f4 ; System.Object$$.ctor
026a4618: e00314aa mov      x0, x20
026a461c: 9f1200b9 str      wzr, [x20, #0x10]
026a4620: 130c02f8 str      x19, [x0, #0x20]!
026a4624: e10313aa mov      x1, x19
026a4628: 2133a497 bl       #0xfb12ac
026a462c: f37b41a9 ldp      x19, x30, [sp, #0x10]
026a4630: e00314aa mov      x0, x20
026a4634: f553c2a8 ldp      x21, x20, [sp], #0x20
026a4638: c0035fd6 ret      
026a463c: 7b33a497 bl       #0xfb1428
