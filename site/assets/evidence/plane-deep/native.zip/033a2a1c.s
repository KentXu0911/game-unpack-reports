# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.FireworksRocketStrategy$$NextExploder
# Linear span to next metadata entry; not a complete CFG.
033a2a1c: ffc302d1 sub      sp, sp, #0xb0
033a2a20: f55309a9 stp      x21, x20, [sp, #0x90]
033a2a24: f37b0aa9 stp      x19, x30, [sp, #0xa0]
033a2a28: 55d03bd5 mrs      x21, tpidr_el0
033a2a2c: f40308aa mov      x20, x8
033a2a30: a81640f9 ldr      x8, [x21, #0x28]
033a2a34: f30300aa mov      x19, x0
033a2a38: 00e4006f movi     v0.2d, #0000000000000000
033a2a3c: 60038052 mov      w0, #0x1b
033a2a40: e84700f9 str      x8, [sp, #0x88]
033a2a44: e8230091 add      x8, sp, #8
033a2a48: e1031faa mov      x1, xzr
033a2a4c: ff7f04a9 stp      xzr, xzr, [sp, #0x40]
033a2a50: ff5300b9 str      wzr, [sp, #0x50]
033a2a54: e00303ad stp      q0, q0, [sp, #0x60]
033a2a58: fff307b8 stur     wzr, [sp, #0x7f]
033a2a5c: 935ce697 bl       #0x2d39ca8 ; Royal.Scenes.Game.Mechanics.Explode.Exploder$$Next
033a2a60: e81b40b9 ldr      w8, [sp, #0x18]
033a2a64: e083c03c ldur     q0, [sp, #8]
033a2a68: e1d3c13c ldur     q1, [sp, #0x1d]
033a2a6c: e2d3c23c ldur     q2, [sp, #0x2d]
033a2a70: e93f40b9 ldr      w9, [sp, #0x3c]
033a2a74: e85300b9 str      w8, [sp, #0x50]
033a2a78: e013803d str      q0, [sp, #0x40]
033a2a7c: e10b03ad stp      q1, q2, [sp, #0x60]
033a2a80: e9f307b8 stur     w9, [sp, #0x7f]
033a2a84: 69a24039 ldrb     w9, [x19, #0x28]
033a2a88: 881200b9 str      w8, [x20, #0x10]
033a2a8c: 8002803d str      q0, [x20]
033a2a90: e8f347b8 ldur     w8, [sp, #0x7f]
033a2a94: e10343ad ldp      q1, q0, [sp, #0x60]
033a2a98: 89520039 strb     w9, [x20, #0x14]
033a2a9c: 883600b9 str      w8, [x20, #0x34]
033a2aa0: 8052823c stur     q0, [x20, #0x25]
033a2aa4: 8152813c stur     q1, [x20, #0x15]
033a2aa8: a81640f9 ldr      x8, [x21, #0x28]
033a2aac: e94740f9 ldr      x9, [sp, #0x88]
033a2ab0: 1f0109eb cmp      x8, x9
033a2ab4: a1000054 b.ne     #0x33a2ac8
033a2ab8: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
033a2abc: f55349a9 ldp      x21, x20, [sp, #0x90]
033a2ac0: ffc30291 add      sp, sp, #0xb0
033a2ac4: c0035fd6 ret      
033a2ac8: a2816497 bl       #0xcc3150
