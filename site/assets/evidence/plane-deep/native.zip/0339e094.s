# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeScale
# Linear span to next metadata entry; not a complete CFG.
0339e094: ed33bb6d stp      d13, d12, [sp, #-0x50]!
0339e098: eb2b016d stp      d11, d10, [sp, #0x10]
0339e09c: e923026d stp      d9, d8, [sp, #0x20]
0339e0a0: f41b00f9 str      x20, [sp, #0x30]
0339e0a4: f37b04a9 stp      x19, x30, [sp, #0x40]
0339e0a8: 087c40b9 ldr      w8, [x0, #0x7c]
0339e0ac: f30300aa mov      x19, x0
0339e0b0: 1f050071 cmp      w8, #1
0339e0b4: a0010054 b.eq     #0x339e0e8
0339e0b8: 1f090071 cmp      w8, #2
0339e0bc: 41080054 b.ne     #0x339e1c4
0339e0c0: 617640bd ldr      s1, [x19, #0x74]
0339e0c4: e00313aa mov      x0, x19
0339e0c8: f37b44a9 ldp      x19, x30, [sp, #0x40]
0339e0cc: f41b40f9 ldr      x20, [sp, #0x30]
0339e0d0: e923426d ldp      d9, d8, [sp, #0x20]
0339e0d4: eb2b416d ldp      d11, d10, [sp, #0x10]
0339e0d8: 2038201e fsub     s0, s1, s0
0339e0dc: 0018211e fdiv     s0, s0, s1
0339e0e0: ed33c56c ldp      d13, d12, [sp], #0x50
0339e0e4: 5b060014 b        #0x339fa50 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeScaleDown
0339e0e8: d40e0190 adrp     x20, #0x5576000
0339e0ec: 88a27c39 ldrb     w8, [x20, #0xf28]
0339e0f0: c8000035 cbnz     w8, #0x339e108
0339e0f4: 60f400b0 adrp     x0, #0x522b000
0339e0f8: 00ac43f9 ldr      x0, [x0, #0x758]
0339e0fc: 814c7097 bl       #0xfb1300
0339e100: 28008052 mov      w8, #1
0339e104: 88a23c39 strb     w8, [x20, #0xf28]
0339e108: 602e40f9 ldr      x0, [x19, #0x58]
0339e10c: 800600b4 cbz      x0, #0x339e1dc
0339e110: 68f400b0 adrp     x8, #0x522b000
0339e114: 08ad43f9 ldr      x8, [x8, #0x758]
0339e118: a95600b0 adrp     x9, #0x3e73000
0339e11c: 20a548bd ldr      s0, [x9, #0x8a4]
0339e120: e1031faa mov      x1, xzr
0339e124: 080140f9 ldr      x8, [x8]
0339e128: 085d40f9 ldr      x8, [x8, #0xb8]
0339e12c: 0189412d ldp      s1, s2, [x8, #0xc]
0339e130: 031540bd ldr      s3, [x8, #0x14]
0339e134: 2808201e fmul     s8, s1, s0
0339e138: 4908201e fmul     s9, s2, s0
0339e13c: 6a08201e fmul     s10, s3, s0
0339e140: 91b02594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
0339e144: 2c1ca14e mov      v12.16b, v1.16b
0339e148: 01103e1e fmov     s1, #-1.00000000
0339e14c: 0b1ca04e mov      v11.16b, v0.16b
0339e150: 0039201e fsub     s0, s8, s0
0339e154: 0129211e fadd     s1, s8, s1
0339e158: 0018211e fdiv     s0, s0, s1
0339e15c: e0031faa mov      x0, xzr
0339e160: 4d1ca24e mov      v13.16b, v2.16b
0339e164: ecaefb97 bl       #0x3289d14 ; Royal.Infrastructure.Utils.Animation.ManualEasing$$Linear
0339e168: 485600b0 adrp     x8, #0x3e67000
0339e16c: 013544bd ldr      s1, [x8, #0x434]
0339e170: 485600b0 adrp     x8, #0x3e67000
0339e174: 02102e1e fmov     s2, #1.00000000
0339e178: e00313aa mov      x0, x19
0339e17c: 0020211e fcmp     s0, s1
0339e180: 010145bd ldr      s1, [x8, #0x500]
0339e184: 0058221e fmin     s0, s0, s2
0339e188: 0210221e fmov     s2, #4.00000000
0339e18c: 0008221e fmul     s0, s0, s2
0339e190: 065c211e fcsel    s6, s0, s1, pl
0339e194: 001da84e mov      v0.16b, v8.16b
0339e198: 211da94e mov      v1.16b, v9.16b
0339e19c: 421daa4e mov      v2.16b, v10.16b
0339e1a0: 631dab4e mov      v3.16b, v11.16b
0339e1a4: f37b44a9 ldp      x19, x30, [sp, #0x40]
0339e1a8: f41b40f9 ldr      x20, [sp, #0x30]
0339e1ac: e923426d ldp      d9, d8, [sp, #0x20]
0339e1b0: eb2b416d ldp      d11, d10, [sp, #0x10]
0339e1b4: 841dac4e mov      v4.16b, v12.16b
0339e1b8: a51dad4e mov      v5.16b, v13.16b
0339e1bc: ed33c56c ldp      d13, d12, [sp], #0x50
0339e1c0: 87060014 b        #0x339fbdc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeScaleUp
0339e1c4: f37b44a9 ldp      x19, x30, [sp, #0x40]
0339e1c8: f41b40f9 ldr      x20, [sp, #0x30]
0339e1cc: e923426d ldp      d9, d8, [sp, #0x20]
0339e1d0: eb2b416d ldp      d11, d10, [sp, #0x10]
0339e1d4: ed33c56c ldp      d13, d12, [sp], #0x50
0339e1d8: c0035fd6 ret      
0339e1dc: 934c7097 bl       #0xfb1428
