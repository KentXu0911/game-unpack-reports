# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerFlySfx
# Linear span to next metadata entry; not a complete CFG.
03397cd0: fe0f1ff8 str      x30, [sp, #-0x10]!
03397cd4: 081440f9 ldr      x8, [x0, #0x28]
03397cd8: e80000b4 cbz      x8, #0x3397cf4
03397cdc: 091940b9 ldr      w9, [x8, #0x18]
03397ce0: 3f050071 cmp      w9, #1
03397ce4: a9000054 b.ls     #0x3397cf8
03397ce8: 001540f9 ldr      x0, [x8, #0x28]
03397cec: fe0741f8 ldr      x30, [sp], #0x10
03397cf0: c0035fd6 ret      
03397cf4: cd657097 bl       #0xfb1428
03397cf8: ce657097 bl       #0xfb1430
