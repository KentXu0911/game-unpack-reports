# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$OnCellGridViewsInitialized
# Linear span to next metadata entry; not a complete CFG.
020eecf0: ffc301d1 sub      sp, sp, #0x70
020eecf4: f62300f9 str      x22, [sp, #0x40]
020eecf8: f55305a9 stp      x21, x20, [sp, #0x50]
020eecfc: f37b06a9 stp      x19, x30, [sp, #0x60]
020eed00: 74a401f0 adrp     x20, #0x557d000
020eed04: 88065539 ldrb     w8, [x20, #0x541]
020eed08: f30300aa mov      x19, x0
020eed0c: 28010037 tbnz     w8, #0, #0x20eed30
020eed10: 20860190 adrp     x0, #0x51b2000
020eed14: 00d044f9 ldr      x0, [x0, #0x9a0]
020eed18: 7a09bb97 bl       #0xfb1300
020eed1c: e08601f0 adrp     x0, #0x51cd000
020eed20: 007c47f9 ldr      x0, [x0, #0xef8]
020eed24: 7709bb97 bl       #0xfb1300
020eed28: 28008052 mov      w8, #1
020eed2c: 88061539 strb     w8, [x20, #0x541]
020eed30: e00313aa mov      x0, x19
020eed34: 66000094 bl       #0x20eeecc ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ArrangeWinCalculationData
020eed38: 601a40f9 ldr      x0, [x19, #0x30]
020eed3c: 600c00b4 cbz      x0, #0x20eeec8
020eed40: f58601f0 adrp     x21, #0x51cd000
020eed44: b57e47f9 ldr      x21, [x21, #0xef8]
020eed48: e1031faa mov      x1, xzr
020eed4c: a5a01994 bl       #0x2756fe0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Width
020eed50: a80240f9 ldr      x8, [x21]
020eed54: e103002a mov      w1, w0
020eed58: e00308aa mov      x0, x8
020eed5c: 8509bb97 bl       #0xfb1370
020eed60: f40313aa mov      x20, x19
020eed64: 800e09f8 str      x0, [x20, #0x90]!
020eed68: e10300aa mov      x1, x0
020eed6c: e00314aa mov      x0, x20
020eed70: 4f09bb97 bl       #0xfb12ac
020eed74: 80025af8 ldur     x0, [x20, #-0x60]
020eed78: 800a00b4 cbz      x0, #0x20eeec8
020eed7c: e1031faa mov      x1, xzr
020eed80: 8fa01994 bl       #0x2756fbc ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Height
020eed84: a80240f9 ldr      x8, [x21]
020eed88: e103002a mov      w1, w0
020eed8c: e00308aa mov      x0, x8
020eed90: 7809bb97 bl       #0xfb1370
020eed94: f40313aa mov      x20, x19
020eed98: 808e09f8 str      x0, [x20, #0x98]!
020eed9c: e10300aa mov      x1, x0
020eeda0: e00314aa mov      x0, x20
020eeda4: 4209bb97 bl       #0xfb12ac
020eeda8: 808259f8 ldur     x0, [x20, #-0x68]
020eedac: e00800b4 cbz      x0, #0x20eeec8
020eedb0: 36860190 adrp     x22, #0x51b2000
020eedb4: d6d244f9 ldr      x22, [x22, #0x9a0]
020eedb8: e1031faa mov      x1, xzr
020eedbc: 89a01994 bl       #0x2756fe0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Width
020eedc0: c80240f9 ldr      x8, [x22]
020eedc4: e103002a mov      w1, w0
020eedc8: e00308aa mov      x0, x8
020eedcc: 6909bb97 bl       #0xfb1370
020eedd0: f40313aa mov      x20, x19
020eedd4: 808e0af8 str      x0, [x20, #0xa8]!
020eedd8: e10300aa mov      x1, x0
020eeddc: e00314aa mov      x0, x20
020eede0: 3309bb97 bl       #0xfb12ac
020eede4: 808258f8 ldur     x0, [x20, #-0x78]
020eede8: 000700b4 cbz      x0, #0x20eeec8
020eedec: e1031faa mov      x1, xzr
020eedf0: 73a01994 bl       #0x2756fbc ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Height
020eedf4: c80240f9 ldr      x8, [x22]
020eedf8: e103002a mov      w1, w0
020eedfc: e00308aa mov      x0, x8
020eee00: 5c09bb97 bl       #0xfb1370
020eee04: f40313aa mov      x20, x19
020eee08: 800e0bf8 str      x0, [x20, #0xb0]!
020eee0c: e10300aa mov      x1, x0
020eee10: e00314aa mov      x0, x20
020eee14: 2609bb97 bl       #0xfb12ac
020eee18: 800258f8 ldur     x0, [x20, #-0x80]
020eee1c: 600500b4 cbz      x0, #0x20eeec8
020eee20: e8230091 add      x8, sp, #8
020eee24: 21008052 mov      w1, #1
020eee28: e2031faa mov      x2, xzr
020eee2c: f1771994 bl       #0x274cdf0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$GetIterator
020eee30: e80f40f9 ldr      x8, [sp, #0x18]
020eee34: e083c03c ldur     q0, [sp, #8]
020eee38: 60420191 add      x0, x19, #0x50
020eee3c: e1031faa mov      x1, xzr
020eee40: e81b00f9 str      x8, [sp, #0x30]
020eee44: e00b803d str      q0, [sp, #0x20]
020eee48: 683200f9 str      x8, [x19, #0x60]
020eee4c: 6016803d str      q0, [x19, #0x50]
020eee50: 1709bb97 bl       #0xfb12ac
020eee54: 602240f9 ldr      x0, [x19, #0x40]
020eee58: 800300b4 cbz      x0, #0x20eeec8
020eee5c: e1031faa mov      x1, xzr
020eee60: d9fb2494 bl       #0x2a2ddc4 ; Royal.Scenes.Game.Levels.Units.GoalManager$$GetCurrentGoals
020eee64: 200300b4 cbz      x0, #0x20eeec8
020eee68: 011840b9 ldr      w1, [x0, #0x18]
020eee6c: 3f040071 cmp      w1, #1
020eee70: 2b020054 b.lt     #0x20eeeb4
020eee74: e8031faa mov      x8, xzr
020eee78: 09800091 add      x9, x0, #0x20
020eee7c: 2a7968f8 ldr      x10, [x9, x8, lsl #3]
020eee80: 4a0200b4 cbz      x10, #0x20eeec8
020eee84: 4a814039 ldrb     w10, [x10, #0x20]
020eee88: aa000035 cbnz     w10, #0x20eee9c
020eee8c: 08050091 add      x8, x8, #1
020eee90: 1f01016b cmp      w8, w1
020eee94: 4bffff54 b.lt     #0x20eee7c
020eee98: 07000014 b        #0x20eeeb4
020eee9c: a00240f9 ldr      x0, [x21]
020eeea0: 3409bb97 bl       #0xfb1370
020eeea4: 600e0af8 str      x0, [x19, #0xa0]!
020eeea8: e10300aa mov      x1, x0
020eeeac: e00313aa mov      x0, x19
020eeeb0: ff08bb97 bl       #0xfb12ac
020eeeb4: f37b46a9 ldp      x19, x30, [sp, #0x60]
020eeeb8: f55345a9 ldp      x21, x20, [sp, #0x50]
020eeebc: f62340f9 ldr      x22, [sp, #0x40]
020eeec0: ffc30191 add      sp, sp, #0x70
020eeec4: c0035fd6 ret      
020eeec8: 5809bb97 bl       #0xfb1428
