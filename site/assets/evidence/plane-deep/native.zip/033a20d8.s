# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$CalculateVelocitySmoother
# Linear span to next metadata entry; not a complete CFG.
033a20d8: eb2bbd6d stp      d11, d10, [sp, #-0x30]!
033a20dc: e923016d stp      d9, d8, [sp, #0x10]
033a20e0: f37b02a9 stp      x19, x30, [sp, #0x20]
033a20e4: f30300aa mov      x19, x0
033a20e8: e0031faa mov      x0, xzr
033a20ec: 081ca04e mov      v8.16b, v0.16b
033a20f0: cec2ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a20f4: 612640bd ldr      s1, [x19, #0x24]
033a20f8: 285600b0 adrp     x8, #0x3e67000
033a20fc: 690240f9 ldr      x9, [x19]
033a2100: 03fd44bd ldr      s3, [x8, #0x4fc]
033a2104: 627a40bd ldr      s2, [x19, #0x78]
033a2108: 0038211e fsub     s0, s0, s1
033a210c: 09102e1e fmov     s9, #1.00000000
033a2110: 282d41f9 ldr      x8, [x9, #0x258]
033a2114: 213141f9 ldr      x1, [x9, #0x260]
033a2118: 0018231e fdiv     s0, s0, s3
033a211c: ea03271e fmov     s10, wzr
033a2120: 0158291e fmin     s1, s0, s9
033a2124: 0820201e fcmp     s0, #0.0
033a2128: 205c2a1e fcsel    s0, s1, s10, pl
033a212c: 4139221e fsub     s1, s10, s2
033a2130: 2008201e fmul     s0, s1, s0
033a2134: e00313aa mov      x0, x19
033a2138: 4b28201e fadd     s11, s2, s0
033a213c: 00013fd6 blr      x8
033a2140: 285600b0 adrp     x8, #0x3e67000
033a2144: 611a40bd ldr      s1, [x19, #0x18]
033a2148: 024144bd ldr      s2, [x8, #0x440]
033a214c: e85600f0 adrp     x8, #0x3e81000
033a2150: 03954cbd ldr      s3, [x8, #0xc94]
033a2154: 485800b0 adrp     x8, #0x3eab000
033a2158: 2108221e fmul     s1, s1, s2
033a215c: 02794cbd ldr      s2, [x8, #0xc78]
033a2160: 285600b0 adrp     x8, #0x3e67000
033a2164: 04a944bd ldr      s4, [x8, #0x4a8]
033a2168: 0329231e fadd     s3, s8, s3
033a216c: 2820201e fcmp     s1, #0.0
033a2170: 2158291e fmin     s1, s1, s9
033a2174: 6218221e fdiv     s2, s3, s2
033a2178: 2108241e fmul     s1, s1, s4
033a217c: 4358291e fmin     s3, s2, s9
033a2180: 21282a1e fadd     s1, s1, s10
033a2184: 63082a1e fmul     s3, s3, s10
033a2188: 215c2a1e fcsel    s1, s1, s10, pl
033a218c: 4820201e fcmp     s2, #0.0
033a2190: e0031faa mov      x0, xzr
033a2194: 0808211e fmul     s8, s0, s1
033a2198: 6a5c2a1e fcsel    s10, s3, s10, pl
033a219c: a3c2ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a21a0: 612640bd ldr      s1, [x19, #0x24]
033a21a4: 285600b0 adrp     x8, #0x3e67000
033a21a8: 027d44bd ldr      s2, [x8, #0x47c]
033a21ac: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a21b0: 0038211e fsub     s0, s0, s1
033a21b4: 0158291e fmin     s1, s0, s9
033a21b8: 0820201e fcmp     s0, #0.0
033a21bc: 2008221e fmul     s0, s1, s2
033a21c0: 4038201e fsub     s0, s2, s0
033a21c4: 005c221e fcsel    s0, s0, s2, pl
033a21c8: 4129281e fadd     s1, s10, s8
033a21cc: e923416d ldp      d9, d8, [sp, #0x10]
033a21d0: 2008201e fmul     s0, s1, s0
033a21d4: 00202b1e fcmp     s0, s11
033a21d8: 00cc2b1e fcsel    s0, s0, s11, gt
033a21dc: eb2bc36c ldp      d11, d10, [sp], #0x30
033a21e0: c0035fd6 ret      
