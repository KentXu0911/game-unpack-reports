# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$MoveToTarget
# Linear span to next metadata entry; not a complete CFG.
0339d74c: ff4304d1 sub      sp, sp, #0x110
0339d750: ef3b076d stp      d15, d14, [sp, #0x70]
0339d754: ed33086d stp      d13, d12, [sp, #0x80]
0339d758: eb2b096d stp      d11, d10, [sp, #0x90]
0339d75c: e9230a6d stp      d9, d8, [sp, #0xa0]
0339d760: fc6f0ba9 stp      x28, x27, [sp, #0xb0]
0339d764: fa670ca9 stp      x26, x25, [sp, #0xc0]
0339d768: f85f0da9 stp      x24, x23, [sp, #0xd0]
0339d76c: f6570ea9 stp      x22, x21, [sp, #0xe0]
0339d770: f44f0fa9 stp      x20, x19, [sp, #0xf0]
0339d774: fd7b10a9 stp      x29, x30, [sp, #0x100]
0339d778: 540f01b0 adrp     x20, #0x5586000
0339d77c: 88d66639 ldrb     w8, [x20, #0x9b5]
0339d780: f30300aa mov      x19, x0
0339d784: c8030037 tbnz     w8, #0, #0x339d7fc
0339d788: c0f300b0 adrp     x0, #0x5216000
0339d78c: 001c44f9 ldr      x0, [x0, #0x838]
0339d790: dc4e7097 bl       #0xfb1300
0339d794: 40f200b0 adrp     x0, #0x51e6000
0339d798: 007840f9 ldr      x0, [x0, #0xf0]
0339d79c: d94e7097 bl       #0xfb1300
0339d7a0: 40f000f0 adrp     x0, #0x51a8000
0339d7a4: 00dc41f9 ldr      x0, [x0, #0x3b8]
0339d7a8: d64e7097 bl       #0xfb1300
0339d7ac: 80f400d0 adrp     x0, #0x522f000
0339d7b0: 000445f9 ldr      x0, [x0, #0xa08]
0339d7b4: d34e7097 bl       #0xfb1300
0339d7b8: a0f40090 adrp     x0, #0x5231000
0339d7bc: 003841f9 ldr      x0, [x0, #0x270]
0339d7c0: d04e7097 bl       #0xfb1300
0339d7c4: c0f200f0 adrp     x0, #0x51f8000
0339d7c8: 000847f9 ldr      x0, [x0, #0xe10]
0339d7cc: cd4e7097 bl       #0xfb1300
0339d7d0: 60f400d0 adrp     x0, #0x522b000
0339d7d4: 00ac43f9 ldr      x0, [x0, #0x758]
0339d7d8: ca4e7097 bl       #0xfb1300
0339d7dc: 00f300b0 adrp     x0, #0x51fe000
0339d7e0: 00b041f9 ldr      x0, [x0, #0x360]
0339d7e4: c74e7097 bl       #0xfb1300
0339d7e8: c0f400d0 adrp     x0, #0x5237000
0339d7ec: 003c41f9 ldr      x0, [x0, #0x278]
0339d7f0: c44e7097 bl       #0xfb1300
0339d7f4: 28008052 mov      w8, #1
0339d7f8: 88d62639 strb     w8, [x20, #0x9b5]
0339d7fc: 602e40f9 ldr      x0, [x19, #0x58]
0339d800: 004400b4 cbz      x0, #0x339e080
0339d804: e1031faa mov      x1, xzr
0339d808: 3bb12594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339d80c: 743240f9 ldr      x20, [x19, #0x60]
0339d810: 944300b4 cbz      x20, #0x339e080
0339d814: 95f400d0 adrp     x21, #0x522f000
0339d818: 880240f9 ldr      x8, [x20]
0339d81c: b50645f9 ldr      x21, [x21, #0xa08]
0339d820: 091ca04e mov      v9.16b, v0.16b
0339d824: 281ca14e mov      v8.16b, v1.16b
0339d828: 09554279 ldrh     w9, [x8, #0x12a]
0339d82c: a10240f9 ldr      x1, [x21]
0339d830: 4a1ca24e mov      v10.16b, v2.16b
0339d834: 290100b4 cbz      x9, #0x339d858
0339d838: 0a5940f9 ldr      x10, [x8, #0xb0]
0339d83c: 4a210091 add      x10, x10, #8
0339d840: 4b815ff8 ldur     x11, [x10, #-8]
0339d844: 7f0101eb cmp      x11, x1
0339d848: 00010054 b.eq     #0x339d868
0339d84c: 290500f1 subs     x9, x9, #1
0339d850: 4a410091 add      x10, x10, #0x10
0339d854: 61ffff54 b.ne     #0x339d840
0339d858: 22008052 mov      w2, #1
0339d85c: e00314aa mov      x0, x20
0339d860: 9d8e6f97 bl       #0xf812d4
0339d864: 05000014 b        #0x339d878
0339d868: 490140b9 ldr      w9, [x10]
0339d86c: 29050011 add      w9, w9, #1
0339d870: 08d1298b add      x8, x8, w9, sxtw #4
0339d874: 00e10491 add      x0, x8, #0x138
0339d878: 080440a9 ldp      x8, x1, [x0]
0339d87c: e00314aa mov      x0, x20
0339d880: 00013fd6 blr      x8
0339d884: d60e01d0 adrp     x22, #0x5577000
0339d888: c81a6039 ldrb     w8, [x22, #0x806]
0339d88c: 0b1ca04e mov      v11.16b, v0.16b
0339d890: 2d1ca14e mov      v13.16b, v1.16b
0339d894: 4e1ca24e mov      v14.16b, v2.16b
0339d898: c8000035 cbnz     w8, #0x339d8b0
0339d89c: 00f300f0 adrp     x0, #0x5200000
0339d8a0: 008c46f9 ldr      x0, [x0, #0xd18]
0339d8a4: 974e7097 bl       #0xfb1300
0339d8a8: 28008052 mov      w8, #1
0339d8ac: c81a2039 strb     w8, [x22, #0x806]
0339d8b0: 17f300f0 adrp     x23, #0x5200000
0339d8b4: f78e46f9 ldr      x23, [x23, #0xd18]
0339d8b8: cf392a1e fsub     s15, s14, s10
0339d8bc: ea0b00bd str      s10, [sp, #8]
0339d8c0: e00240f9 ldr      x0, [x23]
0339d8c4: 08e040b9 ldr      w8, [x0, #0xe0]
0339d8c8: e9a3012d stp      s9, s8, [sp, #0xc]
0339d8cc: 6939291e fsub     s9, s11, s9
0339d8d0: a839281e fsub     s8, s13, s8
0339d8d4: 48000035 cbnz     w8, #0x339d8dc
0339d8d8: cb4e7097 bl       #0xfb1404
0339d8dc: d40e01d0 adrp     x20, #0x5577000
0339d8e0: 88fa7f39 ldrb     w8, [x20, #0xffe]
0339d8e4: 2009291e fmul     s0, s9, s9
0339d8e8: 0109281e fmul     s1, s8, s8
0339d8ec: 0028211e fadd     s0, s0, s1
0339d8f0: e1092f1e fmul     s1, s15, s15
0339d8f4: 2a28201e fadd     s10, s1, s0
0339d8f8: e82700bd str      s8, [sp, #0x24]
0339d8fc: c8000035 cbnz     w8, #0x339d914
0339d900: 00f300f0 adrp     x0, #0x5200000
0339d904: 008c46f9 ldr      x0, [x0, #0xd18]
0339d908: 7e4e7097 bl       #0xfb1300
0339d90c: 28008052 mov      w8, #1
0339d910: 88fa3f39 strb     w8, [x20, #0xffe]
0339d914: e00240f9 ldr      x0, [x23]
0339d918: 48c1211e fsqrt    s8, s10
0339d91c: 08e040b9 ldr      w8, [x0, #0xe0]
0339d920: 48000035 cbnz     w8, #0x339d928
0339d924: b84e7097 bl       #0xfb1404
0339d928: a85600d0 adrp     x8, #0x3e73000
0339d92c: 00894bbd ldr      s0, [x8, #0xb88]
0339d930: 7bf400d0 adrp     x27, #0x522b000
0339d934: 7baf43f9 ldr      x27, [x27, #0x758]
0339d938: 6c1dab4e mov      v12.16b, v11.16b
0339d93c: 0021201e fcmp     s8, s0
0339d940: ef2300bd str      s15, [sp, #0x20]
0339d944: 0d010054 b.le     #0x339d964
0339d948: 2019281e fdiv     s0, s9, s8
0339d94c: e01f00bd str      s0, [sp, #0x1c]
0339d950: e02740bd ldr      s0, [sp, #0x24]
0339d954: 0018281e fdiv     s0, s0, s8
0339d958: e01b00bd str      s0, [sp, #0x18]
0339d95c: e019281e fdiv     s0, s15, s8
0339d960: 10000014 b        #0x339d9a0
0339d964: d40e01b0 adrp     x20, #0x5576000
0339d968: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339d96c: c8000035 cbnz     w8, #0x339d984
0339d970: 60f400d0 adrp     x0, #0x522b000
0339d974: 00ac43f9 ldr      x0, [x0, #0x758]
0339d978: 624e7097 bl       #0xfb1300
0339d97c: 28008052 mov      w8, #1
0339d980: 88b23c39 strb     w8, [x20, #0xf2c]
0339d984: 680340f9 ldr      x8, [x27]
0339d988: 085d40f9 ldr      x8, [x8, #0xb8]
0339d98c: 000140bd ldr      s0, [x8]
0339d990: e01f00bd str      s0, [sp, #0x1c]
0339d994: 000540bd ldr      s0, [x8, #4]
0339d998: e01b00bd str      s0, [sp, #0x18]
0339d99c: 000940bd ldr      s0, [x8, #8]
0339d9a0: 602a40f9 ldr      x0, [x19, #0x50]
0339d9a4: e01700bd str      s0, [sp, #0x14]
0339d9a8: c03600b4 cbz      x0, #0x339e080
0339d9ac: 080040f9 ldr      x8, [x0]
0339d9b0: cf1dae4e mov      v15.16b, v14.16b
0339d9b4: 093d42f9 ldr      x9, [x8, #0x478]
0339d9b8: 014142f9 ldr      x1, [x8, #0x480]
0339d9bc: 20013fd6 blr      x9
0339d9c0: c81a6039 ldrb     w8, [x22, #0x806]
0339d9c4: 0e1ca04e mov      v14.16b, v0.16b
0339d9c8: 2b1ca14e mov      v11.16b, v1.16b
0339d9cc: 4a1ca24e mov      v10.16b, v2.16b
0339d9d0: c8000035 cbnz     w8, #0x339d9e8
0339d9d4: 00f300f0 adrp     x0, #0x5200000
0339d9d8: 008c46f9 ldr      x0, [x0, #0xd18]
0339d9dc: 494e7097 bl       #0xfb1300
0339d9e0: 28008052 mov      w8, #1
0339d9e4: c81a2039 strb     w8, [x22, #0x806]
0339d9e8: e00240f9 ldr      x0, [x23]
0339d9ec: 8e392e1e fsub     s14, s12, s14
0339d9f0: ab392b1e fsub     s11, s13, s11
0339d9f4: ea392a1e fsub     s10, s15, s10
0339d9f8: 08e040b9 ldr      w8, [x0, #0xe0]
0339d9fc: 48000035 cbnz     w8, #0x339da04
0339da00: 814e7097 bl       #0xfb1404
0339da04: c0092e1e fmul     s0, s14, s14
0339da08: 61092b1e fmul     s1, s11, s11
0339da0c: 42092a1e fmul     s2, s10, s10
0339da10: 0028211e fadd     s0, s0, s1
0339da14: 4028201e fadd     s0, s2, s0
0339da18: 00c0211e fsqrt    s0, s0
0339da1c: 01103a1e fmov     s1, #-0.25000000
0339da20: 0028211e fadd     s0, s0, s1
0339da24: e00313aa mov      x0, x19
0339da28: 9b010094 bl       #0x339e094 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeScale
0339da2c: e207442d ldp      s2, s1, [sp, #0x20]
0339da30: e40f432d ldp      s4, s3, [sp, #0x18]
0339da34: e51740bd ldr      s5, [sp, #0x14]
0339da38: e00313aa mov      x0, x19
0339da3c: 201da94e mov      v0.16b, v9.16b
0339da40: 061da84e mov      v6.16b, v8.16b
0339da44: 0a1da84e mov      v10.16b, v8.16b
0339da48: e6010094 bl       #0x339e1e0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangePosition
0339da4c: 80000036 tbz      w0, #0, #0x339da5c
0339da50: 7ff600b9 str      wzr, [x19, #0xf4]
0339da54: ee1daf4e mov      v14.16b, v15.16b
0339da58: 4f010014 b        #0x339df94
0339da5c: 68f640b9 ldr      w8, [x19, #0xf4]
0339da60: ee1daf4e mov      v14.16b, v15.16b
0339da64: 08050011 add      w8, w8, #1
0339da68: 1f790071 cmp      w8, #0x1e
0339da6c: 68f600b9 str      w8, [x19, #0xf4]
0339da70: 2b290054 b.lt     #0x339df94
0339da74: 607240f9 ldr      x0, [x19, #0xe0]
0339da78: 403000b4 cbz      x0, #0x339e080
0339da7c: 801dac4e mov      v0.16b, v12.16b
0339da80: a11dad4e mov      v1.16b, v13.16b
0339da84: c21dae4e mov      v2.16b, v14.16b
0339da88: e1031faa mov      x1, xzr
0339da8c: beb52594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
0339da90: e203042d stp      s2, s0, [sp, #0x20]
0339da94: 602e40f9 ldr      x0, [x19, #0x58]
0339da98: 402f00b4 cbz      x0, #0x339e080
0339da9c: bdf40090 adrp     x29, #0x5231000
0339daa0: dcf200f0 adrp     x28, #0x51f8000
0339daa4: 5af000f0 adrp     x26, #0x51a8000
0339daa8: d9f300b0 adrp     x25, #0x5216000
0339daac: 58f200b0 adrp     x24, #0x51e6000
0339dab0: bd3b41f9 ldr      x29, [x29, #0x270]
0339dab4: 9c0b47f9 ldr      x28, [x28, #0xe10]
0339dab8: 5adf41f9 ldr      x26, [x26, #0x3b8]
0339dabc: 391f44f9 ldr      x25, [x25, #0x838]
0339dac0: 187b40f9 ldr      x24, [x24, #0xf0]
0339dac4: e1031faa mov      x1, xzr
0339dac8: 2b1ca14e mov      v11.16b, v1.16b
0339dacc: d8b02594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
0339dad0: 68e24339 ldrb     w8, [x19, #0xf8]
0339dad4: 091ca04e mov      v9.16b, v0.16b
0339dad8: 281ca14e mov      v8.16b, v1.16b
0339dadc: 4f1ca24e mov      v15.16b, v2.16b
0339dae0: c80f0034 cbz      w8, #0x339dcd8
0339dae4: 21008052 mov      w1, #1
0339dae8: e00313aa mov      x0, x19
0339daec: 0f040094 bl       #0x339eb28 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$TargetReached
0339daf0: a00340f9 ldr      x0, [x29]
0339daf4: c1008052 mov      w1, #6
0339daf8: 1e4e7097 bl       #0xfb1370
0339dafc: f40300aa mov      x20, x0
0339db00: 600340f9 ldr      x0, [x27]
0339db04: e1830191 add      x1, sp, #0x60
0339db08: e9230c2d stp      s9, s8, [sp, #0x60]
0339db0c: ef6b00bd str      s15, [sp, #0x68]
0339db10: 3f4e7097 bl       #0xfb140c
0339db14: 742b00b4 cbz      x20, #0x339e080
0339db18: f50300aa mov      x21, x0
0339db1c: c00000b4 cbz      x0, #0x339db34
0339db20: 880240f9 ldr      x8, [x20]
0339db24: e00315aa mov      x0, x21
0339db28: 012140f9 ldr      x1, [x8, #0x40]
0339db2c: 374e7097 bl       #0xfb1408
0339db30: c02a00b4 cbz      x0, #0x339e088
0339db34: 881a40b9 ldr      w8, [x20, #0x18]
0339db38: 682a0034 cbz      w8, #0x339e084
0339db3c: e00314aa mov      x0, x20
0339db40: 150c02f8 str      x21, [x0, #0x20]!
0339db44: e10315aa mov      x1, x21
0339db48: d94d7097 bl       #0xfb12ac
0339db4c: e00f40bd ldr      s0, [sp, #0xc]
0339db50: 600340f9 ldr      x0, [x27]
0339db54: e1430191 add      x1, sp, #0x50
0339db58: e05300bd str      s0, [sp, #0x50]
0339db5c: e00b40bd ldr      s0, [sp, #8]
0339db60: e05b00bd str      s0, [sp, #0x58]
0339db64: e01340bd ldr      s0, [sp, #0x10]
0339db68: e05700bd str      s0, [sp, #0x54]
0339db6c: 284e7097 bl       #0xfb140c
0339db70: f50300aa mov      x21, x0
0339db74: c00000b4 cbz      x0, #0x339db8c
0339db78: 880240f9 ldr      x8, [x20]
0339db7c: e00315aa mov      x0, x21
0339db80: 012140f9 ldr      x1, [x8, #0x40]
0339db84: 214e7097 bl       #0xfb1408
0339db88: 002800b4 cbz      x0, #0x339e088
0339db8c: 881a40b9 ldr      w8, [x20, #0x18]
0339db90: 1f050071 cmp      w8, #1
0339db94: 89270054 b.ls     #0x339e084
0339db98: e00314aa mov      x0, x20
0339db9c: 158c02f8 str      x21, [x0, #0x28]!
0339dba0: e10315aa mov      x1, x21
0339dba4: c24d7097 bl       #0xfb12ac
0339dba8: e02740bd ldr      s0, [sp, #0x24]
0339dbac: 600340f9 ldr      x0, [x27]
0339dbb0: e1030191 add      x1, sp, #0x40
0339dbb4: e02f082d stp      s0, s11, [sp, #0x40]
0339dbb8: e02340bd ldr      s0, [sp, #0x20]
0339dbbc: e04b00bd str      s0, [sp, #0x48]
0339dbc0: 134e7097 bl       #0xfb140c
0339dbc4: f50300aa mov      x21, x0
0339dbc8: c00000b4 cbz      x0, #0x339dbe0
0339dbcc: 880240f9 ldr      x8, [x20]
0339dbd0: e00315aa mov      x0, x21
0339dbd4: 012140f9 ldr      x1, [x8, #0x40]
0339dbd8: 0c4e7097 bl       #0xfb1408
0339dbdc: 602500b4 cbz      x0, #0x339e088
0339dbe0: 881a40b9 ldr      w8, [x20, #0x18]
0339dbe4: 1f090071 cmp      w8, #2
0339dbe8: e9240054 b.ls     #0x339e084
0339dbec: e00314aa mov      x0, x20
0339dbf0: 150c03f8 str      x21, [x0, #0x30]!
0339dbf4: e10315aa mov      x1, x21
0339dbf8: ad4d7097 bl       #0xfb12ac
0339dbfc: 600340f9 ldr      x0, [x27]
0339dc00: e1c30091 add      x1, sp, #0x30
0339dc04: ec37062d stp      s12, s13, [sp, #0x30]
0339dc08: ee3b00bd str      s14, [sp, #0x38]
0339dc0c: 004e7097 bl       #0xfb140c
0339dc10: f50300aa mov      x21, x0
0339dc14: c00000b4 cbz      x0, #0x339dc2c
0339dc18: 880240f9 ldr      x8, [x20]
0339dc1c: e00315aa mov      x0, x21
0339dc20: 012140f9 ldr      x1, [x8, #0x40]
0339dc24: f94d7097 bl       #0xfb1408
0339dc28: 002300b4 cbz      x0, #0x339e088
0339dc2c: 881a40b9 ldr      w8, [x20, #0x18]
0339dc30: 1f0d0071 cmp      w8, #3
0339dc34: 89220054 b.ls     #0x339e084
0339dc38: e00314aa mov      x0, x20
0339dc3c: 158c03f8 str      x21, [x0, #0x38]!
0339dc40: e10315aa mov      x1, x21
0339dc44: 9a4d7097 bl       #0xfb12ac
0339dc48: 800340f9 ldr      x0, [x28]
0339dc4c: e1b30091 add      x1, sp, #0x2c
0339dc50: ea2f00bd str      s10, [sp, #0x2c]
0339dc54: ee4d7097 bl       #0xfb140c
0339dc58: f50300aa mov      x21, x0
0339dc5c: c00000b4 cbz      x0, #0x339dc74
0339dc60: 880240f9 ldr      x8, [x20]
0339dc64: e00315aa mov      x0, x21
0339dc68: 012140f9 ldr      x1, [x8, #0x40]
0339dc6c: e74d7097 bl       #0xfb1408
0339dc70: c02000b4 cbz      x0, #0x339e088
0339dc74: 881a40b9 ldr      w8, [x20, #0x18]
0339dc78: 1f110071 cmp      w8, #4
0339dc7c: 49200054 b.ls     #0x339e084
0339dc80: e00314aa mov      x0, x20
0339dc84: 150c04f8 str      x21, [x0, #0x40]!
0339dc88: e10315aa mov      x1, x21
0339dc8c: 884d7097 bl       #0xfb12ac
0339dc90: 686a40b9 ldr      w8, [x19, #0x68]
0339dc94: 400340f9 ldr      x0, [x26]
0339dc98: e1a30091 add      x1, sp, #0x28
0339dc9c: e82b00b9 str      w8, [sp, #0x28]
0339dca0: db4d7097 bl       #0xfb140c
0339dca4: f50300aa mov      x21, x0
0339dca8: c00000b4 cbz      x0, #0x339dcc0
0339dcac: 880240f9 ldr      x8, [x20]
0339dcb0: e00315aa mov      x0, x21
0339dcb4: 012140f9 ldr      x1, [x8, #0x40]
0339dcb8: d44d7097 bl       #0xfb1408
0339dcbc: 601e00b4 cbz      x0, #0x339e088
0339dcc0: 881a40b9 ldr      w8, [x20, #0x18]
0339dcc4: 1f150071 cmp      w8, #5
0339dcc8: e91d0054 b.ls     #0x339e084
0339dccc: daf400d0 adrp     x26, #0x5237000
0339dcd0: 5a3f41f9 ldr      x26, [x26, #0x278]
0339dcd4: 96000014 b        #0x339df2c
0339dcd8: 743240f9 ldr      x20, [x19, #0x60]
0339dcdc: 341d00b4 cbz      x20, #0x339e080
0339dce0: 880240f9 ldr      x8, [x20]
0339dce4: a10240f9 ldr      x1, [x21]
0339dce8: 09554279 ldrh     w9, [x8, #0x12a]
0339dcec: 290100b4 cbz      x9, #0x339dd10
0339dcf0: 0a5940f9 ldr      x10, [x8, #0xb0]
0339dcf4: 4a210091 add      x10, x10, #8
0339dcf8: 4b815ff8 ldur     x11, [x10, #-8]
0339dcfc: 7f0101eb cmp      x11, x1
0339dd00: 00010054 b.eq     #0x339dd20
0339dd04: 290500f1 subs     x9, x9, #1
0339dd08: 4a410091 add      x10, x10, #0x10
0339dd0c: 61ffff54 b.ne     #0x339dcf8
0339dd10: 62008052 mov      w2, #3
0339dd14: e00314aa mov      x0, x20
0339dd18: 6f8d6f97 bl       #0xf812d4
0339dd1c: 05000014 b        #0x339dd30
0339dd20: 490140b9 ldr      w9, [x10]
0339dd24: 290d0011 add      w9, w9, #3
0339dd28: 08d1298b add      x8, x8, w9, sxtw #4
0339dd2c: 00e10491 add      x0, x8, #0x138
0339dd30: 080440a9 ldp      x8, x1, [x0]
0339dd34: e00314aa mov      x0, x20
0339dd38: 00013fd6 blr      x8
0339dd3c: 28008052 mov      w8, #1
0339dd40: 68e20339 strb     w8, [x19, #0xf8]
0339dd44: 7ff600b9 str      wzr, [x19, #0xf4]
0339dd48: a00340f9 ldr      x0, [x29]
0339dd4c: c1008052 mov      w1, #6
0339dd50: 884d7097 bl       #0xfb1370
0339dd54: f40300aa mov      x20, x0
0339dd58: 600340f9 ldr      x0, [x27]
0339dd5c: e1830191 add      x1, sp, #0x60
0339dd60: e9230c2d stp      s9, s8, [sp, #0x60]
0339dd64: ef6b00bd str      s15, [sp, #0x68]
0339dd68: a94d7097 bl       #0xfb140c
0339dd6c: b41800b4 cbz      x20, #0x339e080
0339dd70: f50300aa mov      x21, x0
0339dd74: c00000b4 cbz      x0, #0x339dd8c
0339dd78: 880240f9 ldr      x8, [x20]
0339dd7c: e00315aa mov      x0, x21
0339dd80: 012140f9 ldr      x1, [x8, #0x40]
0339dd84: a14d7097 bl       #0xfb1408
0339dd88: 001800b4 cbz      x0, #0x339e088
0339dd8c: 881a40b9 ldr      w8, [x20, #0x18]
0339dd90: a8170034 cbz      w8, #0x339e084
0339dd94: e00314aa mov      x0, x20
0339dd98: 150c02f8 str      x21, [x0, #0x20]!
0339dd9c: e10315aa mov      x1, x21
0339dda0: 434d7097 bl       #0xfb12ac
0339dda4: e00f40bd ldr      s0, [sp, #0xc]
0339dda8: 600340f9 ldr      x0, [x27]
0339ddac: e1430191 add      x1, sp, #0x50
0339ddb0: e05300bd str      s0, [sp, #0x50]
0339ddb4: e00b40bd ldr      s0, [sp, #8]
0339ddb8: e05b00bd str      s0, [sp, #0x58]
0339ddbc: e01340bd ldr      s0, [sp, #0x10]
0339ddc0: e05700bd str      s0, [sp, #0x54]
0339ddc4: 924d7097 bl       #0xfb140c
0339ddc8: f50300aa mov      x21, x0
0339ddcc: c00000b4 cbz      x0, #0x339dde4
0339ddd0: 880240f9 ldr      x8, [x20]
0339ddd4: e00315aa mov      x0, x21
0339ddd8: 012140f9 ldr      x1, [x8, #0x40]
0339dddc: 8b4d7097 bl       #0xfb1408
0339dde0: 401500b4 cbz      x0, #0x339e088
0339dde4: 881a40b9 ldr      w8, [x20, #0x18]
0339dde8: 1f050071 cmp      w8, #1
0339ddec: c9140054 b.ls     #0x339e084
0339ddf0: e00314aa mov      x0, x20
0339ddf4: 158c02f8 str      x21, [x0, #0x28]!
0339ddf8: e10315aa mov      x1, x21
0339ddfc: 2c4d7097 bl       #0xfb12ac
0339de00: e02740bd ldr      s0, [sp, #0x24]
0339de04: 600340f9 ldr      x0, [x27]
0339de08: e1030191 add      x1, sp, #0x40
0339de0c: e02f082d stp      s0, s11, [sp, #0x40]
0339de10: e02340bd ldr      s0, [sp, #0x20]
0339de14: e04b00bd str      s0, [sp, #0x48]
0339de18: 7d4d7097 bl       #0xfb140c
0339de1c: f50300aa mov      x21, x0
0339de20: c00000b4 cbz      x0, #0x339de38
0339de24: 880240f9 ldr      x8, [x20]
0339de28: e00315aa mov      x0, x21
0339de2c: 012140f9 ldr      x1, [x8, #0x40]
0339de30: 764d7097 bl       #0xfb1408
0339de34: a01200b4 cbz      x0, #0x339e088
0339de38: 881a40b9 ldr      w8, [x20, #0x18]
0339de3c: 1f090071 cmp      w8, #2
0339de40: 29120054 b.ls     #0x339e084
0339de44: e00314aa mov      x0, x20
0339de48: 150c03f8 str      x21, [x0, #0x30]!
0339de4c: e10315aa mov      x1, x21
0339de50: 174d7097 bl       #0xfb12ac
0339de54: 600340f9 ldr      x0, [x27]
0339de58: e1c30091 add      x1, sp, #0x30
0339de5c: ec37062d stp      s12, s13, [sp, #0x30]
0339de60: ee3b00bd str      s14, [sp, #0x38]
0339de64: 6a4d7097 bl       #0xfb140c
0339de68: f50300aa mov      x21, x0
0339de6c: c00000b4 cbz      x0, #0x339de84
0339de70: 880240f9 ldr      x8, [x20]
0339de74: e00315aa mov      x0, x21
0339de78: 012140f9 ldr      x1, [x8, #0x40]
0339de7c: 634d7097 bl       #0xfb1408
0339de80: 401000b4 cbz      x0, #0x339e088
0339de84: 881a40b9 ldr      w8, [x20, #0x18]
0339de88: 1f0d0071 cmp      w8, #3
0339de8c: c90f0054 b.ls     #0x339e084
0339de90: e00314aa mov      x0, x20
0339de94: 158c03f8 str      x21, [x0, #0x38]!
0339de98: e10315aa mov      x1, x21
0339de9c: 044d7097 bl       #0xfb12ac
0339dea0: 800340f9 ldr      x0, [x28]
0339dea4: e1b30091 add      x1, sp, #0x2c
0339dea8: ea2f00bd str      s10, [sp, #0x2c]
0339deac: 584d7097 bl       #0xfb140c
0339deb0: f50300aa mov      x21, x0
0339deb4: c00000b4 cbz      x0, #0x339decc
0339deb8: 880240f9 ldr      x8, [x20]
0339debc: e00315aa mov      x0, x21
0339dec0: 012140f9 ldr      x1, [x8, #0x40]
0339dec4: 514d7097 bl       #0xfb1408
0339dec8: 000e00b4 cbz      x0, #0x339e088
0339decc: 881a40b9 ldr      w8, [x20, #0x18]
0339ded0: 1f110071 cmp      w8, #4
0339ded4: 890d0054 b.ls     #0x339e084
0339ded8: e00314aa mov      x0, x20
0339dedc: 150c04f8 str      x21, [x0, #0x40]!
0339dee0: e10315aa mov      x1, x21
0339dee4: f24c7097 bl       #0xfb12ac
0339dee8: 686a40b9 ldr      w8, [x19, #0x68]
0339deec: 400340f9 ldr      x0, [x26]
0339def0: e1a30091 add      x1, sp, #0x28
0339def4: e82b00b9 str      w8, [sp, #0x28]
0339def8: 454d7097 bl       #0xfb140c
0339defc: f50300aa mov      x21, x0
0339df00: c00000b4 cbz      x0, #0x339df18
0339df04: 880240f9 ldr      x8, [x20]
0339df08: e00315aa mov      x0, x21
0339df0c: 012140f9 ldr      x1, [x8, #0x40]
0339df10: 3e4d7097 bl       #0xfb1408
0339df14: a00b00b4 cbz      x0, #0x339e088
0339df18: 881a40b9 ldr      w8, [x20, #0x18]
0339df1c: 1f150071 cmp      w8, #5
0339df20: 290b0054 b.ls     #0x339e084
0339df24: 1af300b0 adrp     x26, #0x51fe000
0339df28: 5ab341f9 ldr      x26, [x26, #0x360]
0339df2c: e00314aa mov      x0, x20
0339df30: 158c04f8 str      x21, [x0, #0x48]!
0339df34: e10315aa mov      x1, x21
0339df38: dd4c7097 bl       #0xfb12ac
0339df3c: 400340f9 ldr      x0, [x26]
0339df40: e10314aa mov      x1, x20
0339df44: e2031faa mov      x2, xzr
0339df48: 7aa9a597 bl       #0x1d08530 ; System.String$$Format
0339df4c: 280340f9 ldr      x8, [x25]
0339df50: f50300aa mov      x21, x0
0339df54: e00308aa mov      x0, x8
0339df58: 304d7097 bl       #0xfb1418
0339df5c: 200900b4 cbz      x0, #0x339e080
0339df60: e10315aa mov      x1, x21
0339df64: e2031faa mov      x2, xzr
0339df68: f40300aa mov      x20, x0
0339df6c: d525bb97 bl       #0x22676c0 ; System.Exception$$.ctor
0339df70: 000340f9 ldr      x0, [x24]
0339df74: 08e040b9 ldr      w8, [x0, #0xe0]
0339df78: 48000035 cbnz     w8, #0x339df80
0339df7c: 224d7097 bl       #0xfb1404
0339df80: 61018052 mov      w1, #0xb
0339df84: e00314aa mov      x0, x20
0339df88: e2031faa mov      x2, xzr
0339df8c: e3031faa mov      x3, xzr
0339df90: 15eeea97 bl       #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
0339df94: 602a40f9 ldr      x0, [x19, #0x50]
0339df98: 400700b4 cbz      x0, #0x339e080
0339df9c: 080040f9 ldr      x8, [x0]
0339dfa0: 093d42f9 ldr      x9, [x8, #0x478]
0339dfa4: 014142f9 ldr      x1, [x8, #0x480]
0339dfa8: 20013fd6 blr      x9
0339dfac: c81a6039 ldrb     w8, [x22, #0x806]
0339dfb0: 081ca04e mov      v8.16b, v0.16b
0339dfb4: 291ca14e mov      v9.16b, v1.16b
0339dfb8: 4a1ca24e mov      v10.16b, v2.16b
0339dfbc: c8000035 cbnz     w8, #0x339dfd4
0339dfc0: 00f300f0 adrp     x0, #0x5200000
0339dfc4: 008c46f9 ldr      x0, [x0, #0xd18]
0339dfc8: ce4c7097 bl       #0xfb1300
0339dfcc: 28008052 mov      w8, #1
0339dfd0: c81a2039 strb     w8, [x22, #0x806]
0339dfd4: e00240f9 ldr      x0, [x23]
0339dfd8: 08e040b9 ldr      w8, [x0, #0xe0]
0339dfdc: 48000035 cbnz     w8, #0x339dfe4
0339dfe0: 094d7097 bl       #0xfb1404
0339dfe4: 601640bd ldr      s0, [x19, #0x14]
0339dfe8: 0b102a1e fmov     s11, #0.25000000
0339dfec: 00202b1e fcmp     s0, s11
0339dff0: 0b030054 b.lt     #0x339e050
0339dff4: 68f24239 ldrb     w8, [x19, #0xbc]
0339dff8: c8020035 cbnz     w8, #0x339e050
0339dffc: 00392c1e fsub     s0, s8, s12
0339e000: 21392d1e fsub     s1, s9, s13
0339e004: 42392e1e fsub     s2, s10, s14
0339e008: 0008201e fmul     s0, s0, s0
0339e00c: 2108211e fmul     s1, s1, s1
0339e010: 485600b0 adrp     x8, #0x3e67000
0339e014: 0028211e fadd     s0, s0, s1
0339e018: 4108221e fmul     s1, s2, s2
0339e01c: 024944bd ldr      s2, [x8, #0x448]
0339e020: 2028201e fadd     s0, s1, s0
0339e024: 08c0211e fsqrt    s8, s0
0339e028: e103271e fmov     s1, wzr
0339e02c: 001da84e mov      v0.16b, v8.16b
0339e030: e0031faa mov      x0, xzr
0339e034: 4482fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339e038: 00212b1e fcmp     s8, s11
0339e03c: 44000054 b.mi     #0x339e044
0339e040: 80000036 tbz      w0, #0, #0x339e050
0339e044: e00313aa mov      x0, x19
0339e048: e1031f2a mov      w1, wzr
0339e04c: b7020094 bl       #0x339eb28 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$TargetReached
0339e050: fd7b50a9 ldp      x29, x30, [sp, #0x100]
0339e054: f44f4fa9 ldp      x20, x19, [sp, #0xf0]
0339e058: f6574ea9 ldp      x22, x21, [sp, #0xe0]
0339e05c: f85f4da9 ldp      x24, x23, [sp, #0xd0]
0339e060: fa674ca9 ldp      x26, x25, [sp, #0xc0]
0339e064: fc6f4ba9 ldp      x28, x27, [sp, #0xb0]
0339e068: e9234a6d ldp      d9, d8, [sp, #0xa0]
0339e06c: eb2b496d ldp      d11, d10, [sp, #0x90]
0339e070: ed33486d ldp      d13, d12, [sp, #0x80]
0339e074: ef3b476d ldp      d15, d14, [sp, #0x70]
0339e078: ff430491 add      sp, sp, #0x110
0339e07c: c0035fd6 ret      
0339e080: ea4c7097 bl       #0xfb1428
0339e084: eb4c7097 bl       #0xfb1430
0339e088: f14c7097 bl       #0xfb144c
0339e08c: e1031faa mov      x1, xzr
0339e090: d84c7097 bl       #0xfb13f0
