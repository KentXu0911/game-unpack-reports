# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy.<ExplodeNeighbors>d__13$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a3014: f40f1ef8 str      x20, [sp, #-0x20]!
033a3018: f37b01a9 stp      x19, x30, [sp, #0x10]
033a301c: f303012a mov      w19, w1
033a3020: e1031faa mov      x1, xzr
033a3024: f40300aa mov      x20, x0
033a3028: 7341bb97 bl       #0x22735f4 ; System.Object$$.ctor
033a302c: 931200b9 str      w19, [x20, #0x10]
033a3030: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a3034: f40742f8 ldr      x20, [sp], #0x20
033a3038: c0035fd6 ret      
