# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$ArrangePosition
# Linear span to next metadata entry; not a complete CFG.
033a1578: ff8302d1 sub      sp, sp, #0xa0
033a157c: ef3b036d stp      d15, d14, [sp, #0x30]
033a1580: ed33046d stp      d13, d12, [sp, #0x40]
033a1584: eb2b056d stp      d11, d10, [sp, #0x50]
033a1588: e923066d stp      d9, d8, [sp, #0x60]
033a158c: f63b00f9 str      x22, [sp, #0x70]
033a1590: f55308a9 stp      x21, x20, [sp, #0x80]
033a1594: f37b09a9 stp      x19, x30, [sp, #0x90]
033a1598: 340f01b0 adrp     x20, #0x5586000
033a159c: 880a6739 ldrb     w8, [x20, #0x9c2]
033a15a0: ae1ca54e mov      v14.16b, v5.16b
033a15a4: 8f1ca44e mov      v15.16b, v4.16b
033a15a8: 6c1ca34e mov      v12.16b, v3.16b
033a15ac: 481ca24e mov      v8.16b, v2.16b
033a15b0: 291ca14e mov      v9.16b, v1.16b
033a15b4: 0a1ca04e mov      v10.16b, v0.16b
033a15b8: f30300aa mov      x19, x0
033a15bc: e62f00bd str      s6, [sp, #0x2c]
033a15c0: 88010037 tbnz     w8, #0, #0x33a15f0
033a15c4: 80f40090 adrp     x0, #0x5231000
033a15c8: 003841f9 ldr      x0, [x0, #0x270]
033a15cc: 4d3f7097 bl       #0xfb1300
033a15d0: a0f200f0 adrp     x0, #0x51f8000
033a15d4: 000847f9 ldr      x0, [x0, #0xe10]
033a15d8: 4a3f7097 bl       #0xfb1300
033a15dc: 80f200d0 adrp     x0, #0x51f3000
033a15e0: 003045f9 ldr      x0, [x0, #0xa60]
033a15e4: 473f7097 bl       #0xfb1300
033a15e8: 28008052 mov      w8, #1
033a15ec: 880a2739 strb     w8, [x20, #0x9c2]
033a15f0: e0031faa mov      x0, xzr
033a15f4: f7bbce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
033a15f8: 0b102c1e fmov     s11, #0.50000000
033a15fc: 0d1ca04e mov      v13.16b, v0.16b
033a1600: 00202b1e fcmp     s0, s11
033a1604: 8d040054 b.le     #0x33a1694
033a1608: 88f40090 adrp     x8, #0x5231000
033a160c: 083941f9 ldr      x8, [x8, #0x270]
033a1610: b5f200f0 adrp     x21, #0x51f8000
033a1614: 21008052 mov      w1, #1
033a1618: 000140f9 ldr      x0, [x8]
033a161c: b50a47f9 ldr      x21, [x21, #0xe10]
033a1620: 543f7097 bl       #0xfb1370
033a1624: f40300aa mov      x20, x0
033a1628: a00240f9 ldr      x0, [x21]
033a162c: e1f30191 add      x1, sp, #0x7c
033a1630: ed7f00bd str      s13, [sp, #0x7c]
033a1634: 763f7097 bl       #0xfb140c
033a1638: 542b00b4 cbz      x20, #0x33a1ba0
033a163c: f50300aa mov      x21, x0
033a1640: c00000b4 cbz      x0, #0x33a1658
033a1644: 880240f9 ldr      x8, [x20]
033a1648: e00315aa mov      x0, x21
033a164c: 012140f9 ldr      x1, [x8, #0x40]
033a1650: 6e3f7097 bl       #0xfb1408
033a1654: a02a00b4 cbz      x0, #0x33a1ba8
033a1658: 881a40b9 ldr      w8, [x20, #0x18]
033a165c: 482a0034 cbz      w8, #0x33a1ba4
033a1660: 96f200d0 adrp     x22, #0x51f3000
033a1664: d63245f9 ldr      x22, [x22, #0xa60]
033a1668: e00314aa mov      x0, x20
033a166c: 150c02f8 str      x21, [x0, #0x20]!
033a1670: e10315aa mov      x1, x21
033a1674: 0e3f7097 bl       #0xfb12ac
033a1678: c20240f9 ldr      x2, [x22]
033a167c: 61018052 mov      w1, #0xb
033a1680: e00313aa mov      x0, x19
033a1684: e30314aa mov      x3, x20
033a1688: e4031faa mov      x4, xzr
033a168c: 9c7ed197 bl       #0x28010fc ; Royal.Infrastructure.Services.Logs.Log$$Error
033a1690: 6d1dab4e mov      v13.16b, v11.16b
033a1694: e00313aa mov      x0, x19
033a1698: 401daa4e mov      v0.16b, v10.16b
033a169c: 211da94e mov      v1.16b, v9.16b
033a16a0: 021da84e mov      v2.16b, v8.16b
033a16a4: ed23042d stp      s13, s8, [sp, #0x20]
033a16a8: eaa7012d stp      s10, s9, [sp, #0xc]
033a16ac: 42010094 bl       #0x33a1bb4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TryResetForNextTarget
033a16b0: e0031faa mov      x0, xzr
033a16b4: 5dc5ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a16b8: 6286442d ldp      s2, s1, [x19, #0x24]
033a16bc: 692e482d ldp      s9, s11, [x19, #0x40]
033a16c0: 140f01f0 adrp     x20, #0x5584000
033a16c4: 6a4a40bd ldr      s10, [x19, #0x48]
033a16c8: e11700bd str      s1, [sp, #0x14]
033a16cc: 612e40bd ldr      s1, [x19, #0x2c]
033a16d0: 88fe4f39 ldrb     w8, [x20, #0x3ff]
033a16d4: 081ca04e mov      v8.16b, v0.16b
033a16d8: e11b00bd str      s1, [sp, #0x18]
033a16dc: 613240bd ldr      s1, [x19, #0x30]
033a16e0: e11f00bd str      s1, [sp, #0x1c]
033a16e4: 08010035 cbnz     w8, #0x33a1704
033a16e8: e0f200f0 adrp     x0, #0x5200000
033a16ec: 008c46f9 ldr      x0, [x0, #0xd18]
033a16f0: 4d1ca24e mov      v13.16b, v2.16b
033a16f4: 033f7097 bl       #0xfb1300
033a16f8: a21dad4e mov      v2.16b, v13.16b
033a16fc: 28008052 mov      w8, #1
033a1700: 88fe0f39 strb     w8, [x20, #0x3ff]
033a1704: f5f200f0 adrp     x21, #0x5200000
033a1708: b58e46f9 ldr      x21, [x21, #0xd18]
033a170c: 2009291e fmul     s0, s9, s9
033a1710: 61092b1e fmul     s1, s11, s11
033a1714: 0028211e fadd     s0, s0, s1
033a1718: a00240f9 ldr      x0, [x21]
033a171c: 41092a1e fmul     s1, s10, s10
033a1720: 2d28201e fadd     s13, s1, s0
033a1724: 80092c1e fmul     s0, s12, s12
033a1728: 08e040b9 ldr      w8, [x0, #0xe0]
033a172c: e1092f1e fmul     s1, s15, s15
033a1730: 0028211e fadd     s0, s0, s1
033a1734: c1092e1e fmul     s1, s14, s14
033a1738: ec2b00bd str      s12, [sp, #0x28]
033a173c: ec1daf4e mov      v12.16b, v15.16b
033a1740: cf1dae4e mov      v15.16b, v14.16b
033a1744: 2e28201e fadd     s14, s1, s0
033a1748: 88000035 cbnz     w8, #0x33a1758
033a174c: e27b00bd str      s2, [sp, #0x78]
033a1750: 2d3f7097 bl       #0xfb1404
033a1754: e27b40bd ldr      s2, [sp, #0x78]
033a1758: 885600d0 adrp     x8, #0x3e73000
033a175c: 0039221e fsub     s0, s8, s2
033a1760: 028d4bbd ldr      s2, [x8, #0xb8c]
033a1764: e07b00bd str      s0, [sp, #0x78]
033a1768: c0092d1e fmul     s0, s14, s13
033a176c: 01c0211e fsqrt    s1, s0
033a1770: 08102e1e fmov     s8, #1.00000000
033a1774: 2020221e fcmp     s1, s2
033a1778: 11103e1e fmov     s17, #-1.00000000
033a177c: e003271e fmov     s0, wzr
033a1780: ed1daf4e mov      v13.16b, v15.16b
033a1784: 8e1dac4e mov      v14.16b, v12.16b
033a1788: e4020054 b.mi     #0x33a17e4
033a178c: e02b40bd ldr      s0, [sp, #0x28]
033a1790: a00240f9 ldr      x0, [x21]
033a1794: c2092b1e fmul     s2, s14, s11
033a1798: 2f1eb14e mov      v15.16b, v17.16b
033a179c: 0008291e fmul     s0, s0, s9
033a17a0: 0028221e fadd     s0, s0, s2
033a17a4: a2092a1e fmul     s2, s13, s10
033a17a8: 4028201e fadd     s0, s2, s0
033a17ac: 08e040b9 ldr      w8, [x0, #0xe0]
033a17b0: 0018211e fdiv     s0, s0, s1
033a17b4: 0158281e fmin     s1, s0, s8
033a17b8: 0020311e fcmp     s0, s17
033a17bc: 2c5c311e fcsel    s12, s1, s17, pl
033a17c0: 48000035 cbnz     w8, #0x33a17c8
033a17c4: 103f7097 bl       #0xfb1404
033a17c8: 80c1221e fcvt     d0, s12
033a17cc: 7d856497 bl       #0xcc2dc0
033a17d0: 885600d0 adrp     x8, #0x3e73000
033a17d4: 01914bbd ldr      s1, [x8, #0xb90]
033a17d8: 0040621e fcvt     s0, d0
033a17dc: f11daf4e mov      v17.16b, v15.16b
033a17e0: 0008211e fmul     s0, s0, s1
033a17e4: ec2b40bd ldr      s12, [sp, #0x28]
033a17e8: a1092b1e fmul     s1, s13, s11
033a17ec: c2092a1e fmul     s2, s14, s10
033a17f0: 2138221e fsub     s1, s1, s2
033a17f4: 83092a1e fmul     s3, s12, s10
033a17f8: a209291e fmul     s2, s13, s9
033a17fc: 6338221e fsub     s3, s3, s2
033a1800: e27b40bd ldr      s2, [sp, #0x78]
033a1804: f01f40bd ldr      s16, [sp, #0x1c]
033a1808: c409291e fmul     s4, s14, s9
033a180c: 85092b1e fmul     s5, s12, s11
033a1810: 4628221e fadd     s6, s2, s2
033a1814: e29f422d ldp      s2, s7, [sp, #0x14]
033a1818: 8438251e fsub     s4, s4, s5
033a181c: 8408301e fmul     s4, s4, s16
033a1820: e903271e fmov     s9, wzr
033a1824: 4508211e fmul     s5, s2, s1
033a1828: e308231e fmul     s3, s7, s3
033a182c: a328231e fadd     s3, s5, s3
033a1830: 8328231e fadd     s3, s4, s3
033a1834: 6820201e fcmp     s3, #0.0
033a1838: 03ad311e fcsel    s3, s8, s17, ge
033a183c: 610a452d ldp      s1, s2, [x19, #0x28]
033a1840: c758281e fmin     s7, s6, s8
033a1844: c820201e fcmp     s6, #0.0
033a1848: 6008201e fmul     s0, s3, s0
033a184c: 633240bd ldr      s3, [x19, #0x30]
033a1850: e45c291e fcsel    s4, s7, s9, pl
033a1854: 2539201e fsub     s5, s9, s0
033a1858: 8408251e fmul     s4, s4, s5
033a185c: 0028241e fadd     s0, s0, s4
033a1860: e0031faa mov      x0, xzr
033a1864: 601a00bd str      s0, [x19, #0x18]
033a1868: 42900594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
033a186c: 841dac4e mov      v4.16b, v12.16b
033a1870: c51dae4e mov      v5.16b, v14.16b
033a1874: a61dad4e mov      v6.16b, v13.16b
033a1878: e0031faa mov      x0, xzr
033a187c: cf8d0594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
033a1880: 285600d0 adrp     x8, #0x3e67000
033a1884: 631e40bd ldr      s3, [x19, #0x1c]
033a1888: 043544bd ldr      s4, [x8, #0x434]
033a188c: 883ba852 mov      w8, #0x41dc0000
033a1890: 0501271e fmov     s5, w8
033a1894: 8836a852 mov      w8, #0x41b40000
033a1898: 6318241e fdiv     s3, s3, s4
033a189c: 6820201e fcmp     s3, #0.0
033a18a0: 6358281e fmin     s3, s3, s8
033a18a4: 64b640bd ldr      s4, [x19, #0xb4]
033a18a8: 6308251e fmul     s3, s3, s5
033a18ac: 0501271e fmov     s5, w8
033a18b0: 6328251e fadd     s3, s3, s5
033a18b4: e72340bd ldr      s7, [sp, #0x20]
033a18b8: 635c251e fcsel    s3, s3, s5, pl
033a18bc: 656e40bd ldr      s5, [x19, #0x6c]
033a18c0: eb2f40bd ldr      s11, [sp, #0x2c]
033a18c4: 8308231e fmul     s3, s4, s3
033a18c8: 0844a852 mov      w8, #0x42200000
033a18cc: e308231e fmul     s3, s7, s3
033a18d0: a328231e fadd     s3, s5, s3
033a18d4: 0501271e fmov     s5, w8
033a18d8: 04392b1e fsub     s4, s8, s11
033a18dc: 6558251e fmin     s5, s3, s5
033a18e0: 6820201e fcmp     s3, #0.0
033a18e4: 8358281e fmin     s3, s4, s8
033a18e8: 06102c1e fmov     s6, #0.50000000
033a18ec: a55c291e fcsel    s5, s5, s9, pl
033a18f0: 6308261e fmul     s3, s3, s6
033a18f4: 8820201e fcmp     s4, #0.0
033a18f8: e408251e fmul     s4, s7, s5
033a18fc: 6328281e fadd     s3, s3, s8
033a1900: 0908241e fmul     s9, s0, s4
033a1904: 4008241e fmul     s0, s2, s4
033a1908: e0031faa mov      x0, xzr
033a190c: cc1ca64e mov      v12.16b, v6.16b
033a1910: 656e00bd str      s5, [x19, #0x6c]
033a1914: 2a08241e fmul     s10, s1, s4
033a1918: e02b00bd str      s0, [sp, #0x28]
033a191c: 6e5c281e fcsel    s14, s3, s8, pl
033a1920: c2c4ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a1924: 612640bd ldr      s1, [x19, #0x24]
033a1928: 6d4a40bd ldr      s13, [x19, #0x48]
033a192c: e00313aa mov      x0, x19
033a1930: 74220291 add      x20, x19, #0x88
033a1934: 0038211e fsub     s0, s0, s1
033a1938: 0028201e fadd     s0, s0, s0
033a193c: 0258281e fmin     s2, s0, s8
033a1940: 01102f1e fmov     s1, #1.50000000
033a1944: 0820201e fcmp     s0, #0.0
033a1948: 40082c1e fmul     s0, s2, s12
033a194c: 2038201e fsub     s0, s1, s0
033a1950: 005c211e fcsel    s0, s0, s1, pl
033a1954: e12b40bd ldr      s1, [sp, #0x28]
033a1958: 6832482d ldp      s8, s12, [x19, #0x40]
033a195c: c021201e fcmp     s14, s0
033a1960: c0cd201e fcsel    s0, s14, s0, gt
033a1964: 2e09201e fmul     s14, s9, s0
033a1968: 4f09201e fmul     s15, s10, s0
033a196c: 2908201e fmul     s9, s1, s0
033a1970: 601dab4e mov      v0.16b, v11.16b
033a1974: d9010094 bl       #0x33a20d8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$CalculateVelocitySmoother
033a1978: e0031faa mov      x0, xzr
033a197c: 0a1ca04e mov      v10.16b, v0.16b
033a1980: 99712594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
033a1984: 08f0af52 mov      w8, #0x7f800000
033a1988: e00300bd str      s0, [sp]
033a198c: 0701271e fmov     s7, w8
033a1990: 001da84e mov      v0.16b, v8.16b
033a1994: 811dac4e mov      v1.16b, v12.16b
033a1998: a21dad4e mov      v2.16b, v13.16b
033a199c: c31dae4e mov      v3.16b, v14.16b
033a19a0: e41daf4e mov      v4.16b, v15.16b
033a19a4: 251da94e mov      v5.16b, v9.16b
033a19a8: e00314aa mov      x0, x20
033a19ac: 461daa4e mov      v6.16b, v10.16b
033a19b0: e1031faa mov      x1, xzr
033a19b4: 0c9e0594 bl       #0x35091e4 ; UnityEngine.Vector3$$SmoothDamp
033a19b8: 6006082d stp      s0, s1, [x19, #0x40]
033a19bc: 0090211e fmov     s0, #3.50000000
033a19c0: 6021201e fcmp     s11, s0
033a19c4: eb2740bd ldr      s11, [sp, #0x24]
033a19c8: 365600d0 adrp     x22, #0x3e67000
033a19cc: 624a00bd str      s2, [x19, #0x48]
033a19d0: a5040054 b.pl     #0x33a1a64
033a19d4: 602e40f9 ldr      x0, [x19, #0x58]
033a19d8: 400e00b4 cbz      x0, #0x33a1ba0
033a19dc: e1031faa mov      x1, xzr
033a19e0: 69a22594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
033a19e4: 48570090 adrp     x8, #0x3e89000
033a19e8: 012d4dbd ldr      s1, [x8, #0xd2c]
033a19ec: 0020211e fcmp     s0, s1
033a19f0: ad030054 b.le     #0x33a1a64
033a19f4: c24a44bd ldr      s2, [x22, #0x448]
033a19f8: e02f40bd ldr      s0, [sp, #0x2c]
033a19fc: e103271e fmov     s1, wzr
033a1a00: e0031faa mov      x0, xzr
033a1a04: d073fb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
033a1a08: e0020037 tbnz     w0, #0, #0x33a1a64
033a1a0c: 602e40f9 ldr      x0, [x19, #0x58]
033a1a10: e02f40bd ldr      s0, [sp, #0x2c]
033a1a14: 607600bd str      s0, [x19, #0x74]
033a1a18: 400c00b4 cbz      x0, #0x33a1ba0
033a1a1c: e1031faa mov      x1, xzr
033a1a20: 59a22594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
033a1a24: 682a40f9 ldr      x8, [x19, #0x50]
033a1a28: 607200bd str      s0, [x19, #0x70]
033a1a2c: a80b00b4 cbz      x8, #0x33a1ba0
033a1a30: 004140f9 ldr      x0, [x8, #0x80]
033a1a34: 600b00b4 cbz      x0, #0x33a1ba0
033a1a38: e1031faa mov      x1, xzr
033a1a3c: db842594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
033a1a40: 000b00b4 cbz      x0, #0x33a1ba0
033a1a44: e1031faa mov      x1, xzr
033a1a48: f9a02594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
033a1a4c: 48008052 mov      w8, #2
033a1a50: 29008052 mov      w9, #1
033a1a54: 6086062d stp      s0, s1, [x19, #0x34]
033a1a58: 623e00bd str      s2, [x19, #0x3c]
033a1a5c: 688600b9 str      w8, [x19, #0x84]
033a1a60: 69520239 strb     w9, [x19, #0x94]
033a1a64: 680240f9 ldr      x8, [x19]
033a1a68: e00313aa mov      x0, x19
033a1a6c: 091541f9 ldr      x9, [x8, #0x228]
033a1a70: 011941f9 ldr      x1, [x8, #0x230]
033a1a74: 20013fd6 blr      x9
033a1a78: e17b40bd ldr      s1, [sp, #0x78]
033a1a7c: 2020201e fcmp     s1, s0
033a1a80: 8d030054 b.le     #0x33a1af0
033a1a84: b40e01d0 adrp     x20, #0x5577000
033a1a88: 881a6039 ldrb     w8, [x20, #0x806]
033a1a8c: c8000035 cbnz     w8, #0x33a1aa4
033a1a90: e0f200f0 adrp     x0, #0x5200000
033a1a94: 008c46f9 ldr      x0, [x0, #0xd18]
033a1a98: 1a3e7097 bl       #0xfb1300
033a1a9c: 28008052 mov      w8, #1
033a1aa0: 881a2039 strb     w8, [x20, #0x806]
033a1aa4: a00240f9 ldr      x0, [x21]
033a1aa8: 6a26482d ldp      s10, s9, [x19, #0x40]
033a1aac: 684a40bd ldr      s8, [x19, #0x48]
033a1ab0: 08e040b9 ldr      w8, [x0, #0xe0]
033a1ab4: 48000035 cbnz     w8, #0x33a1abc
033a1ab8: 533e7097 bl       #0xfb1404
033a1abc: 40092a1e fmul     s0, s10, s10
033a1ac0: 2109291e fmul     s1, s9, s9
033a1ac4: 0028211e fadd     s0, s0, s1
033a1ac8: 0109281e fmul     s1, s8, s8
033a1acc: 0028211e fadd     s0, s0, s1
033a1ad0: e12f40bd ldr      s1, [sp, #0x2c]
033a1ad4: 00c0211e fsqrt    s0, s0
033a1ad8: 0020211e fcmp     s0, s1
033a1adc: ad000054 b.le     #0x33a1af0
033a1ae0: e00f40bd ldr      s0, [sp, #0xc]
033a1ae4: 604200bd str      s0, [x19, #0x40]
033a1ae8: e01340bd ldr      s0, [sp, #0x10]
033a1aec: 60ae082d stp      s0, s11, [x19, #0x44]
033a1af0: 602e40f9 ldr      x0, [x19, #0x58]
033a1af4: 600500b4 cbz      x0, #0x33a1ba0
033a1af8: e1031faa mov      x1, xzr
033a1afc: 7ea02594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a1b00: 742e40f9 ldr      x20, [x19, #0x58]
033a1b04: f40400b4 cbz      x20, #0x33a1ba0
033a1b08: e00314aa mov      x0, x20
033a1b0c: e1031faa mov      x1, xzr
033a1b10: 081ca04e mov      v8.16b, v0.16b
033a1b14: 291ca14e mov      v9.16b, v1.16b
033a1b18: 4a1ca24e mov      v10.16b, v2.16b
033a1b1c: 76a02594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a1b20: 6312482d ldp      s3, s4, [x19, #0x40]
033a1b24: 654a40bd ldr      s5, [x19, #0x48]
033a1b28: e00314aa mov      x0, x20
033a1b2c: e1031faa mov      x1, xzr
033a1b30: 0028231e fadd     s0, s0, s3
033a1b34: 2128241e fadd     s1, s1, s4
033a1b38: 4228251e fadd     s2, s2, s5
033a1b3c: 96a02594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
033a1b40: 602e40f9 ldr      x0, [x19, #0x58]
033a1b44: e00200b4 cbz      x0, #0x33a1ba0
033a1b48: e1031faa mov      x1, xzr
033a1b4c: 6aa02594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a1b50: c64a44bd ldr      s6, [x22, #0x448]
033a1b54: 031ca04e mov      v3.16b, v0.16b
033a1b58: 241ca14e mov      v4.16b, v1.16b
033a1b5c: 451ca24e mov      v5.16b, v2.16b
033a1b60: 001da84e mov      v0.16b, v8.16b
033a1b64: 211da94e mov      v1.16b, v9.16b
033a1b68: 421daa4e mov      v2.16b, v10.16b
033a1b6c: e0031faa mov      x0, xzr
033a1b70: b78afb97 bl       #0x328464c ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
033a1b74: f37b49a9 ldp      x19, x30, [sp, #0x90]
033a1b78: f55348a9 ldp      x21, x20, [sp, #0x80]
033a1b7c: f63b40f9 ldr      x22, [sp, #0x70]
033a1b80: e923466d ldp      d9, d8, [sp, #0x60]
033a1b84: eb2b456d ldp      d11, d10, [sp, #0x50]
033a1b88: ed33446d ldp      d13, d12, [sp, #0x40]
033a1b8c: ef3b436d ldp      d15, d14, [sp, #0x30]
033a1b90: e803202a mvn      w8, w0
033a1b94: 00010012 and      w0, w8, #1
033a1b98: ff830291 add      sp, sp, #0xa0
033a1b9c: c0035fd6 ret      
033a1ba0: 223e7097 bl       #0xfb1428
033a1ba4: 233e7097 bl       #0xfb1430
033a1ba8: 293e7097 bl       #0xfb144c
033a1bac: e1031faa mov      x1, xzr
033a1bb0: 103e7097 bl       #0xfb13f0
