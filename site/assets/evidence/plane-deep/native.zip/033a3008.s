# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ForceExplode
# Linear span to next metadata entry; not a complete CFG.
033a3008: c0035fd6 ret      
