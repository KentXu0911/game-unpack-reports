# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a3cd8: fa0f1bf8 str      x26, [sp, #-0x50]!
033a3cdc: f96301a9 stp      x25, x24, [sp, #0x10]
033a3ce0: f75b02a9 stp      x23, x22, [sp, #0x20]
033a3ce4: f55303a9 stp      x21, x20, [sp, #0x30]
033a3ce8: f37b04a9 stp      x19, x30, [sp, #0x40]
033a3cec: 1a0f01f0 adrp     x26, #0x5586000
033a3cf0: d6f200b0 adrp     x22, #0x51fc000
033a3cf4: 48576739 ldrb     w8, [x26, #0x9d5]
033a3cf8: d62247f9 ldr      x22, [x22, #0xe40]
033a3cfc: f40305aa mov      x20, x5
033a3d00: f50301aa mov      x21, x1
033a3d04: f30300aa mov      x19, x0
033a3d08: 59000012 and      w25, w2, #1
033a3d0c: 78000012 and      w24, w3, #1
033a3d10: 97000012 and      w23, w4, #1
033a3d14: c8000037 tbnz     w8, #0, #0x33a3d2c
033a3d18: c0f200b0 adrp     x0, #0x51fc000
033a3d1c: 002047f9 ldr      x0, [x0, #0xe40]
033a3d20: 78357097 bl       #0xfb1300
033a3d24: 28008052 mov      w8, #1
033a3d28: 48572739 strb     w8, [x26, #0x9d5]
033a3d2c: e00313aa mov      x0, x19
033a3d30: e1031f2a mov      w1, wzr
033a3d34: 66fbff97 bl       #0x33a2acc ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$.ctor
033a3d38: e00313aa mov      x0, x19
033a3d3c: 158c02f8 str      x21, [x0, #0x28]!
033a3d40: e10315aa mov      x1, x21
033a3d44: 5a357097 bl       #0xfb12ac
033a3d48: 79c20039 strb     w25, [x19, #0x30]
033a3d4c: 78c60039 strb     w24, [x19, #0x31]
033a3d50: 77ca0039 strb     w23, [x19, #0x32]
033a3d54: 742200f9 str      x20, [x19, #0x40]
033a3d58: c10240f9 ldr      x1, [x22]
033a3d5c: e0018052 mov      w0, #0xf
033a3d60: 256bc697 bl       #0x253e9f4 ; Royal.Scenes.Game.Levels.LevelContext$$Get<object>
033a3d64: 608e03f8 str      x0, [x19, #0x38]!
033a3d68: e10300aa mov      x1, x0
033a3d6c: e00313aa mov      x0, x19
033a3d70: f37b44a9 ldp      x19, x30, [sp, #0x40]
033a3d74: f55343a9 ldp      x21, x20, [sp, #0x30]
033a3d78: f75b42a9 ldp      x23, x22, [sp, #0x20]
033a3d7c: f96341a9 ldp      x25, x24, [sp, #0x10]
033a3d80: fa0745f8 ldr      x26, [sp], #0x50
033a3d84: 4a357017 b        #0xfb12ac
