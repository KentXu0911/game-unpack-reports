# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$GetTargetPosition
# Linear span to next metadata entry; not a complete CFG.
026a2e54: f60f1df8 str      x22, [sp, #-0x30]!
026a2e58: f55301a9 stp      x21, x20, [sp, #0x10]
026a2e5c: f37b02a9 stp      x19, x30, [sp, #0x20]
026a2e60: f47601d0 adrp     x20, #0x5580000
026a2e64: 88f24039 ldrb     w8, [x20, #0x3c]
026a2e68: f30300aa mov      x19, x0
026a2e6c: 28010037 tbnz     w8, #0, #0x26a2e90
026a2e70: a05801d0 adrp     x0, #0x51b8000
026a2e74: 002840f9 ldr      x0, [x0, #0x50]
026a2e78: 2239a497 bl       #0xfb1300
026a2e7c: 205c01d0 adrp     x0, #0x5228000
026a2e80: 000444f9 ldr      x0, [x0, #0x808]
026a2e84: 1f39a497 bl       #0xfb1300
026a2e88: 28008052 mov      w8, #1
026a2e8c: 88f20039 strb     w8, [x20, #0x3c]
026a2e90: 68224439 ldrb     w8, [x19, #0x108]
026a2e94: c8000034 cbz      w8, #0x26a2eac
026a2e98: 606240f9 ldr      x0, [x19, #0xc0]
026a2e9c: 800f00b4 cbz      x0, #0x26a308c
026a2ea0: e1031faa mov      x1, xzr
026a2ea4: 45a21094 bl       #0x2acb7b8 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetViewPosition
026a2ea8: 75000014 b        #0x26a307c
026a2eac: 601641b9 ldr      w0, [x19, #0x114]
026a2eb0: 74a640f9 ldr      x20, [x19, #0x148]
026a2eb4: e1031faa mov      x1, xzr
026a2eb8: de5d1a94 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
026a2ebc: 940e00b4 cbz      x20, #0x26a308c
026a2ec0: b65801d0 adrp     x22, #0x51b8000
026a2ec4: 880240f9 ldr      x8, [x20]
026a2ec8: d62a40f9 ldr      x22, [x22, #0x50]
026a2ecc: f503002a mov      w21, w0
026a2ed0: 09554279 ldrh     w9, [x8, #0x12a]
026a2ed4: c10240f9 ldr      x1, [x22]
026a2ed8: 290100b4 cbz      x9, #0x26a2efc
026a2edc: 0a5940f9 ldr      x10, [x8, #0xb0]
026a2ee0: 4a210091 add      x10, x10, #8
026a2ee4: 4b815ff8 ldur     x11, [x10, #-8]
026a2ee8: 7f0101eb cmp      x11, x1
026a2eec: 00010054 b.eq     #0x26a2f0c
026a2ef0: 290500f1 subs     x9, x9, #1
026a2ef4: 4a410091 add      x10, x10, #0x10
026a2ef8: 61ffff54 b.ne     #0x26a2ee4
026a2efc: 42008052 mov      w2, #2
026a2f00: e00314aa mov      x0, x20
026a2f04: f478a397 bl       #0xf812d4
026a2f08: 05000014 b        #0x26a2f1c
026a2f0c: 490140b9 ldr      w9, [x10]
026a2f10: 29090011 add      w9, w9, #2
026a2f14: 08d1298b add      x8, x8, w9, sxtw #4
026a2f18: 00e10491 add      x0, x8, #0x138
026a2f1c: 080840a9 ldp      x8, x2, [x0]
026a2f20: e00314aa mov      x0, x20
026a2f24: e103152a mov      w1, w21
026a2f28: 00013fd6 blr      x8
026a2f2c: 400a0036 tbz      w0, #0, #0x26a3074
026a2f30: 747240f9 ldr      x20, [x19, #0xe0]
026a2f34: d40a00b4 cbz      x20, #0x26a308c
026a2f38: 2a5c01d0 adrp     x10, #0x5228000
026a2f3c: 880240f9 ldr      x8, [x20]
026a2f40: 4a0544f9 ldr      x10, [x10, #0x808]
026a2f44: 09554279 ldrh     w9, [x8, #0x12a]
026a2f48: 410140f9 ldr      x1, [x10]
026a2f4c: 290100b4 cbz      x9, #0x26a2f70
026a2f50: 0a5940f9 ldr      x10, [x8, #0xb0]
026a2f54: 4a210091 add      x10, x10, #8
026a2f58: 4b815ff8 ldur     x11, [x10, #-8]
026a2f5c: 7f0101eb cmp      x11, x1
026a2f60: 00010054 b.eq     #0x26a2f80
026a2f64: 290500f1 subs     x9, x9, #1
026a2f68: 4a410091 add      x10, x10, #0x10
026a2f6c: 61ffff54 b.ne     #0x26a2f58
026a2f70: 82008052 mov      w2, #4
026a2f74: e00314aa mov      x0, x20
026a2f78: d778a397 bl       #0xf812d4
026a2f7c: 05000014 b        #0x26a2f90
026a2f80: 490140b9 ldr      w9, [x10]
026a2f84: 29110011 add      w9, w9, #4
026a2f88: 08d1298b add      x8, x8, w9, sxtw #4
026a2f8c: 00e10491 add      x0, x8, #0x138
026a2f90: 080440a9 ldp      x8, x1, [x0]
026a2f94: e00314aa mov      x0, x20
026a2f98: 00013fd6 blr      x8
026a2f9c: 74a640f9 ldr      x20, [x19, #0x148]
026a2fa0: 1f000072 tst      w0, #1
026a2fa4: 75129f9a csel     x21, x19, xzr, ne
026a2fa8: 340700b4 cbz      x20, #0x26a308c
026a2fac: 880240f9 ldr      x8, [x20]
026a2fb0: c10240f9 ldr      x1, [x22]
026a2fb4: 09554279 ldrh     w9, [x8, #0x12a]
026a2fb8: c0010036 tbz      w0, #0, #0x26a2ff0
026a2fbc: 29010034 cbz      w9, #0x26a2fe0
026a2fc0: 0a5940f9 ldr      x10, [x8, #0xb0]
026a2fc4: 4a210091 add      x10, x10, #8
026a2fc8: 4b815ff8 ldur     x11, [x10, #-8]
026a2fcc: 7f0101eb cmp      x11, x1
026a2fd0: a0020054 b.eq     #0x26a3024
026a2fd4: 290500f1 subs     x9, x9, #1
026a2fd8: 4a410091 add      x10, x10, #0x10
026a2fdc: 61ffff54 b.ne     #0x26a2fc8
026a2fe0: 82008052 mov      w2, #4
026a2fe4: e00314aa mov      x0, x20
026a2fe8: bb78a397 bl       #0xf812d4
026a2fec: 12000014 b        #0x26a3034
026a2ff0: 29010034 cbz      w9, #0x26a3014
026a2ff4: 0a5940f9 ldr      x10, [x8, #0xb0]
026a2ff8: 4a210091 add      x10, x10, #8
026a2ffc: 4b815ff8 ldur     x11, [x10, #-8]
026a3000: 7f0101eb cmp      x11, x1
026a3004: 20020054 b.eq     #0x26a3048
026a3008: 290500f1 subs     x9, x9, #1
026a300c: 4a410091 add      x10, x10, #0x10
026a3010: 61ffff54 b.ne     #0x26a2ffc
026a3014: a2008052 mov      w2, #5
026a3018: e00314aa mov      x0, x20
026a301c: ae78a397 bl       #0xf812d4
026a3020: 0e000014 b        #0x26a3058
026a3024: 490140b9 ldr      w9, [x10]
026a3028: 29110011 add      w9, w9, #4
026a302c: 08d1298b add      x8, x8, w9, sxtw #4
026a3030: 00e10491 add      x0, x8, #0x138
026a3034: 080440a9 ldp      x8, x1, [x0]
026a3038: e00314aa mov      x0, x20
026a303c: 00013fd6 blr      x8
026a3040: 750100b5 cbnz     x21, #0x26a306c
026a3044: 12000014 b        #0x26a308c
026a3048: 490140b9 ldr      w9, [x10]
026a304c: 29150011 add      w9, w9, #5
026a3050: 08d1298b add      x8, x8, w9, sxtw #4
026a3054: 00e10491 add      x0, x8, #0x138
026a3058: 080440a9 ldp      x8, x1, [x0]
026a305c: e00314aa mov      x0, x20
026a3060: 00013fd6 blr      x8
026a3064: f50313aa mov      x21, x19
026a3068: 350100b4 cbz      x21, #0x26a308c
026a306c: a0061d2d stp      s0, s1, [x21, #0xe8]
026a3070: a2f200bd str      s2, [x21, #0xf0]
026a3074: 60065d2d ldp      s0, s1, [x19, #0xe8]
026a3078: 62f240bd ldr      s2, [x19, #0xf0]
026a307c: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a3080: f55341a9 ldp      x21, x20, [sp, #0x10]
026a3084: f60743f8 ldr      x22, [sp], #0x30
026a3088: c0035fd6 ret      
026a308c: e738a497 bl       #0xfb1428
