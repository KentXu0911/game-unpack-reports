# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$CalculateAngleSmoothCoefficient
# Linear span to next metadata entry; not a complete CFG.
0339b514: e80f1efc str      d8, [sp, #-0x20]!
0339b518: f37b01a9 stp      x19, x30, [sp, #0x10]
0339b51c: f30300aa mov      x19, x0
0339b520: e0031faa mov      x0, xzr
0339b524: c1ddce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339b528: 61aa40bd ldr      s1, [x19, #0xa8]
0339b52c: e0031faa mov      x0, xzr
0339b530: 0838211e fsub     s8, s0, s1
0339b534: bdddce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339b538: 612640bd ldr      s1, [x19, #0x24]
0339b53c: 68560090 adrp     x8, #0x3e67000
0339b540: 037d44bd ldr      s3, [x8, #0x47c]
0339b544: 02102e1e fmov     s2, #1.00000000
0339b548: 0038211e fsub     s0, s0, s1
0339b54c: 0021201e fcmp     s8, s0
0339b550: 004d201e fcsel    s0, s8, s0, mi
0339b554: 0018231e fdiv     s0, s0, s3
0339b558: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339b55c: 0158221e fmin     s1, s0, s2
0339b560: 4138211e fsub     s1, s2, s1
0339b564: 0820201e fcmp     s0, #0.0
0339b568: 205c221e fcsel    s0, s1, s2, pl
0339b56c: e80742fc ldr      d8, [sp], #0x20
0339b570: c0035fd6 ret      
