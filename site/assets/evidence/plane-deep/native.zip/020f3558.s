# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ClearGoalDependentItems
# Linear span to next metadata entry; not a complete CFG.
020f3558: 005040f9 ldr      x0, [x0, #0xa0]
020f355c: a00000b4 cbz      x0, #0x20f3570
020f3560: 021840b9 ldr      w2, [x0, #0x18]
020f3564: e1031f2a mov      w1, wzr
020f3568: e3031faa mov      x3, xzr
020f356c: 3ad31114 b        #0x2568254 ; System.Array$$Clear
020f3570: c0035fd6 ret      
