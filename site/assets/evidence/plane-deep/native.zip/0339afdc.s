# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$InitializeCurveVariables
# Linear span to next metadata entry; not a complete CFG.
0339afdc: ffc301d1 sub      sp, sp, #0x70
0339afe0: ed33026d stp      d13, d12, [sp, #0x20]
0339afe4: eb2b036d stp      d11, d10, [sp, #0x30]
0339afe8: e923046d stp      d9, d8, [sp, #0x40]
0339afec: f55305a9 stp      x21, x20, [sp, #0x50]
0339aff0: f37b06a9 stp      x19, x30, [sp, #0x60]
0339aff4: 740f0190 adrp     x20, #0x5586000
0339aff8: 889e6639 ldrb     w8, [x20, #0x9a7]
0339affc: 481ca24e mov      v8.16b, v2.16b
0339b000: 291ca14e mov      v9.16b, v1.16b
0339b004: 0a1ca04e mov      v10.16b, v0.16b
0339b008: f30300aa mov      x19, x0
0339b00c: c8000037 tbnz     w8, #0, #0x339b024
0339b010: 80f400d0 adrp     x0, #0x522d000
0339b014: 008444f9 ldr      x0, [x0, #0x908]
0339b018: ba587097 bl       #0xfb1300
0339b01c: 28008052 mov      w8, #1
0339b020: 889e2639 strb     w8, [x20, #0x9a7]
0339b024: e00313aa mov      x0, x19
0339b028: 401daa4e mov      v0.16b, v10.16b
0339b02c: 211da94e mov      v1.16b, v9.16b
0339b030: 021da84e mov      v2.16b, v8.16b
0339b034: 6dfaff97 bl       #0x33999e8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$InitializeCurveVariables
0339b038: f40e01b0 adrp     x20, #0x5578000
0339b03c: 886e4539 ldrb     w8, [x20, #0x15b]
0339b040: 68ba40bd ldr      s8, [x19, #0xb8]
0339b044: c8000035 cbnz     w8, #0x339b05c
0339b048: 80f40090 adrp     x0, #0x522b000
0339b04c: 00ac43f9 ldr      x0, [x0, #0x758]
0339b050: ac587097 bl       #0xfb1300
0339b054: 28008052 mov      w8, #1
0339b058: 886e0539 strb     w8, [x20, #0x15b]
0339b05c: 94f40090 adrp     x20, #0x522b000
0339b060: 94ae43f9 ldr      x20, [x20, #0x758]
0339b064: 001da84e mov      v0.16b, v8.16b
0339b068: e0031faa mov      x0, xzr
0339b06c: 880240f9 ldr      x8, [x20]
0339b070: 085d40f9 ldr      x8, [x8, #0xb8]
0339b074: 0109492d ldp      s1, s2, [x8, #0x48]
0339b078: 035140bd ldr      s3, [x8, #0x50]
0339b07c: 3daa0594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339b080: d50e01f0 adrp     x21, #0x5576000
0339b084: a8be7c39 ldrb     w8, [x21, #0xf2f]
0339b088: 081ca04e mov      v8.16b, v0.16b
0339b08c: 291ca14e mov      v9.16b, v1.16b
0339b090: 4a1ca24e mov      v10.16b, v2.16b
0339b094: 6b1ca34e mov      v11.16b, v3.16b
0339b098: c8000035 cbnz     w8, #0x339b0b0
0339b09c: 80f40090 adrp     x0, #0x522b000
0339b0a0: 00ac43f9 ldr      x0, [x0, #0x758]
0339b0a4: 97587097 bl       #0xfb1300
0339b0a8: 28008052 mov      w8, #1
0339b0ac: a8be3c39 strb     w8, [x21, #0xf2f]
0339b0b0: 880240f9 ldr      x8, [x20]
0339b0b4: 001da84e mov      v0.16b, v8.16b
0339b0b8: 211da94e mov      v1.16b, v9.16b
0339b0bc: 421daa4e mov      v2.16b, v10.16b
0339b0c0: 085d40f9 ldr      x8, [x8, #0xb8]
0339b0c4: 631dab4e mov      v3.16b, v11.16b
0339b0c8: e0031faa mov      x0, xzr
0339b0cc: 0495472d ldp      s4, s5, [x8, #0x3c]
0339b0d0: 064540bd ldr      s6, [x8, #0x44]
0339b0d4: b9a70594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339b0d8: 603640f9 ldr      x0, [x19, #0x68]
0339b0dc: c00500b4 cbz      x0, #0x339b194
0339b0e0: e1031faa mov      x1, xzr
0339b0e4: 091ca04e mov      v9.16b, v0.16b
0339b0e8: 2a1ca14e mov      v10.16b, v1.16b
0339b0ec: 481ca24e mov      v8.16b, v2.16b
0339b0f0: 01bb2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339b0f4: 603640f9 ldr      x0, [x19, #0x68]
0339b0f8: 2029201e fadd     s0, s9, s0
0339b0fc: 4129211e fadd     s1, s10, s1
0339b100: 0229221e fadd     s2, s8, s2
0339b104: 6086152d stp      s0, s1, [x19, #0xac]
0339b108: 62b600bd str      s2, [x19, #0xb4]
0339b10c: 400400b4 cbz      x0, #0x339b194
0339b110: 94f400d0 adrp     x20, #0x522d000
0339b114: 948644f9 ldr      x20, [x20, #0x908]
0339b118: e1031faa mov      x1, xzr
0339b11c: f6ba2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339b120: 800240f9 ldr      x0, [x20]
0339b124: 6cae552d ldp      s12, s11, [x19, #0xac]
0339b128: 6ab640bd ldr      s10, [x19, #0xb4]
0339b12c: 081ca04e mov      v8.16b, v0.16b
0339b130: 08e040b9 ldr      w8, [x0, #0xe0]
0339b134: 291ca14e mov      v9.16b, v1.16b
0339b138: 4d1ca24e mov      v13.16b, v2.16b
0339b13c: 48000035 cbnz     w8, #0x339b144
0339b140: b1587097 bl       #0xfb1404
0339b144: 0834a852 mov      w8, #0x41a00000
0339b148: e91b09b2 mov      x9, #0x3f8000003f800000
0339b14c: 0af0a752 mov      w10, #0x3f800000
0339b150: 001da84e mov      v0.16b, v8.16b
0339b154: 211da94e mov      v1.16b, v9.16b
0339b158: a21dad4e mov      v2.16b, v13.16b
0339b15c: 831dac4e mov      v3.16b, v12.16b
0339b160: 641dab4e mov      v4.16b, v11.16b
0339b164: 451daa4e mov      v5.16b, v10.16b
0339b168: e0031faa mov      x0, xzr
0339b16c: e81300b9 str      w8, [sp, #0x10]
0339b170: ea2700a9 stp      x10, x9, [sp]
0339b174: b0922594 bl       #0x3cffc34 ; UnityEngine.Debug$$DrawLine
0339b178: f37b46a9 ldp      x19, x30, [sp, #0x60]
0339b17c: f55345a9 ldp      x21, x20, [sp, #0x50]
0339b180: e923446d ldp      d9, d8, [sp, #0x40]
0339b184: eb2b436d ldp      d11, d10, [sp, #0x30]
0339b188: ed33426d ldp      d13, d12, [sp, #0x20]
0339b18c: ffc30191 add      sp, sp, #0x70
0339b190: c0035fd6 ret      
0339b194: a5587097 bl       #0xfb1428
