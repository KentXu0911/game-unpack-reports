# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$TargetReached
# Linear span to next metadata entry; not a complete CFG.
0339eb28: f553bea9 stp      x21, x20, [sp, #-0x20]!
0339eb2c: f37b01a9 stp      x19, x30, [sp, #0x10]
0339eb30: 550f0190 adrp     x21, #0x5586000
0339eb34: a8de6639 ldrb     w8, [x21, #0x9b7]
0339eb38: f403012a mov      w20, w1
0339eb3c: f30300aa mov      x19, x0
0339eb40: c8000037 tbnz     w8, #0, #0x339eb58
0339eb44: c0f000f0 adrp     x0, #0x51b9000
0339eb48: 00d046f9 ldr      x0, [x0, #0xda0]
0339eb4c: ed497097 bl       #0xfb1300
0339eb50: 28008052 mov      w8, #1
0339eb54: a8de2639 strb     w8, [x21, #0x9b7]
0339eb58: 602a40f9 ldr      x0, [x19, #0x50]
0339eb5c: 7f6a00b9 str      wzr, [x19, #0x68]
0339eb60: 000400b4 cbz      x0, #0x339ebe0
0339eb64: c9f000f0 adrp     x9, #0x51b9000
0339eb68: 29d146f9 ldr      x9, [x9, #0xda0]
0339eb6c: 080040f9 ldr      x8, [x0]
0339eb70: 210140f9 ldr      x1, [x9]
0339eb74: 0ab14439 ldrb     w10, [x8, #0x12c]
0339eb78: 29b04439 ldrb     w9, [x1, #0x12c]
0339eb7c: 5f01096b cmp      w10, w9
0339eb80: 23030054 b.lo     #0x339ebe4
0339eb84: 086540f9 ldr      x8, [x8, #0xc8]
0339eb88: 080d098b add      x8, x8, x9, lsl #3
0339eb8c: 08815ff8 ldur     x8, [x8, #-8]
0339eb90: 1f0101eb cmp      x8, x1
0339eb94: 81020054 b.ne     #0x339ebe4
0339eb98: e1031faa mov      x1, xzr
0339eb9c: e224dc97 bl       #0x2aa7f24 ; Royal.Scenes.Game.Mechanics.Items.FireworksItem.View.FireworkRocket.FireworkRocketView$$RecycleParticlesDelayed
0339eba0: 602a40f9 ldr      x0, [x19, #0x50]
0339eba4: e00100b4 cbz      x0, #0x339ebe0
0339eba8: e1031faa mov      x1, xzr
0339ebac: 74000036 tbz      w20, #0, #0x339ebb8
0339ebb0: 23ac0b94 bl       #0x3689c3c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$TriggerFakeTargetReached
0339ebb4: 02000014 b        #0x339ebbc
0339ebb8: fcab0b94 bl       #0x3689ba8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$TriggerTargetReached
0339ebbc: 602a40f9 ldr      x0, [x19, #0x50]
0339ebc0: 000100b4 cbz      x0, #0x339ebe0
0339ebc4: 080040f9 ldr      x8, [x0]
0339ebc8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339ebcc: e1031f2a mov      w1, wzr
0339ebd0: 033542f9 ldr      x3, [x8, #0x468]
0339ebd4: 023942f9 ldr      x2, [x8, #0x470]
0339ebd8: f553c2a8 ldp      x21, x20, [sp], #0x20
0339ebdc: 60001fd6 br       x3
0339ebe0: 124a7097 bl       #0xfb1428
0339ebe4: f74a7097 bl       #0xfb17c0
