# Royal.Scenes.Game.Mechanics.Items.CoilCollectItem.CoilCollectItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02add400: f553bea9 stp      x21, x20, [sp, #-0x20]!
02add404: f37b01a9 stp      x19, x30, [sp, #0x10]
02add408: 080040f9 ldr      x8, [x0]
02add40c: f403012a mov      w20, w1
02add410: f30300aa mov      x19, x0
02add414: 096542f9 ldr      x9, [x8, #0x4c8]
02add418: 086942f9 ldr      x8, [x8, #0x4d0]
02add41c: e10308aa mov      x1, x8
02add420: 20013fd6 blr      x9
02add424: 1f040071 cmp      w0, #1
02add428: 01030054 b.ne     #0x2add488
02add42c: 606240f9 ldr      x0, [x19, #0xc0]
02add430: 200600b4 cbz      x0, #0x2add4f4
02add434: e1031faa mov      x1, xzr
02add438: 6b3a0994 bl       #0x2d2bde4 ; Royal.Scenes.Game.Mechanics.Items.CoilItem.CoilItemHelper$$OneTargetRemainingOnAnyCoilItem
02add43c: 60020036 tbz      w0, #0, #0x2add488
02add440: e003142a mov      w0, w20
02add444: e1031faa mov      x1, xzr
02add448: 3d9d2294 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02add44c: 756240f9 ldr      x21, [x19, #0xc0]
02add450: 80020036 tbz      w0, #0, #0x2add4a0
02add454: 150500b4 cbz      x21, #0x2add4f4
02add458: e00315aa mov      x0, x21
02add45c: e1031faa mov      x1, xzr
02add460: 1a3b0994 bl       #0x2d2c0c8 ; Royal.Scenes.Game.Mechanics.Items.CoilItem.CoilItemHelper$$ShouldAddExtraScoreForLastState
02add464: 1f000072 tst      w0, #1
02add468: 28509652 mov      w8, #0xb281
02add46c: e00313aa mov      x0, x19
02add470: e103142a mov      w1, w20
02add474: e2031faa mov      x2, xzr
02add478: 15119f1a csel     w21, w8, wzr, ne
02add47c: 3c9d2294 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02add480: a002000b add      w0, w21, w0
02add484: 19000014 b        #0x2add4e8
02add488: e00313aa mov      x0, x19
02add48c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02add490: e103142a mov      w1, w20
02add494: e2031faa mov      x2, xzr
02add498: f553c2a8 ldp      x21, x20, [sp], #0x20
02add49c: 349d2214 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02add4a0: e00313aa mov      x0, x19
02add4a4: e1031faa mov      x1, xzr
02add4a8: 7b962294 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
02add4ac: 400200b4 cbz      x0, #0x2add4f4
02add4b0: e1031faa mov      x1, xzr
02add4b4: 53afff97 bl       #0x2ac9200 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetBoardAdjustedPoint
02add4b8: f50100b4 cbz      x21, #0x2add4f4
02add4bc: e20300aa mov      x2, x0
02add4c0: e00315aa mov      x0, x21
02add4c4: e103142a mov      w1, w20
02add4c8: e3031faa mov      x3, xzr
02add4cc: a93a0994 bl       #0x2d2bf70 ; Royal.Scenes.Game.Mechanics.Items.CoilItem.CoilItemHelper$$UpdateExtraScoreCache
02add4d0: e00313aa mov      x0, x19
02add4d4: e103142a mov      w1, w20
02add4d8: e2031faa mov      x2, xzr
02add4dc: 249d2294 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
02add4e0: 28509652 mov      w8, #0xb281
02add4e4: 0000080b add      w0, w0, w8
02add4e8: f37b41a9 ldp      x19, x30, [sp, #0x10]
02add4ec: f553c2a8 ldp      x21, x20, [sp], #0x20
02add4f0: c0035fd6 ret      
02add4f4: cd4f9397 bl       #0xfb1428
