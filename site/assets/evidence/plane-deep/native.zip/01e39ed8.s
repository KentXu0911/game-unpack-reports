# Royal.Scenes.Game.Mechanics.Items.PouchItem.PouchItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e39ed8: f40f1ef8 str      x20, [sp, #-0x20]!
01e39edc: f37b01a9 stp      x19, x30, [sp, #0x10]
01e39ee0: 14ba01f0 adrp     x20, #0x557c000
01e39ee4: 139c0190 adrp     x19, #0x51b9000
01e39ee8: 88924e39 ldrb     w8, [x20, #0x3a4]
01e39eec: 737245f9 ldr      x19, [x19, #0xae0]
01e39ef0: c8000037 tbnz     w8, #0, #0x1e39f08
01e39ef4: 009c0190 adrp     x0, #0x51b9000
01e39ef8: 007045f9 ldr      x0, [x0, #0xae0]
01e39efc: 01ddc597 bl       #0xfb1300
01e39f00: 28008052 mov      w8, #1
01e39f04: 88920e39 strb     w8, [x20, #0x3a4]
01e39f08: 600240f9 ldr      x0, [x19]
01e39f0c: 08e040b9 ldr      w8, [x0, #0xe0]
01e39f10: 48000035 cbnz     w8, #0x1e39f18
01e39f14: 3cddc597 bl       #0xfb1404
01e39f18: f4b901d0 adrp     x20, #0x5577000
01e39f1c: 884e7d39 ldrb     w8, [x20, #0xf53]
01e39f20: c8000035 cbnz     w8, #0x1e39f38
01e39f24: 009c0190 adrp     x0, #0x51b9000
01e39f28: 007045f9 ldr      x0, [x0, #0xae0]
01e39f2c: f5dcc597 bl       #0xfb1300
01e39f30: 28008052 mov      w8, #1
01e39f34: 884e3d39 strb     w8, [x20, #0xf53]
01e39f38: 600240f9 ldr      x0, [x19]
01e39f3c: 08e040b9 ldr      w8, [x0, #0xe0]
01e39f40: 68000035 cbnz     w8, #0x1e39f4c
01e39f44: 30ddc597 bl       #0xfb1404
01e39f48: 600240f9 ldr      x0, [x19]
01e39f4c: 085c40f9 ldr      x8, [x0, #0xb8]
01e39f50: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e39f54: 09229f52 mov      w9, #0xf910
01e39f58: c900a072 movk     w9, #6, lsl #16
01e39f5c: 08514039 ldrb     w8, [x8, #0x14]
01e39f60: 1f010071 cmp      w8, #0
01e39f64: 68f08252 mov      w8, #0x1783
01e39f68: 4800a072 movk     w8, #2, lsl #16
01e39f6c: 0001891a csel     w0, w8, w9, eq
01e39f70: f40742f8 ldr      x20, [sp], #0x20
01e39f74: c0035fd6 ret      
