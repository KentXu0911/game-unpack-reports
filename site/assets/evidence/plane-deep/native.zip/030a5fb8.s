# Royal.Scenes.Game.Mechanics.Items.CookieJarItem.CookieJarItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
030a5fb8: f60f1df8 str      x22, [sp, #-0x30]!
030a5fbc: f55301a9 stp      x21, x20, [sp, #0x10]
030a5fc0: f37b02a9 stp      x19, x30, [sp, #0x20]
030a5fc4: 15270190 adrp     x21, #0x5585000
030a5fc8: a80e5539 ldrb     w8, [x21, #0x543]
030a5fcc: f303012a mov      w19, w1
030a5fd0: f40300aa mov      x20, x0
030a5fd4: c8000037 tbnz     w8, #0, #0x30a5fec
030a5fd8: 400a01b0 adrp     x0, #0x51ee000
030a5fdc: 00e043f9 ldr      x0, [x0, #0x7c0]
030a5fe0: c82c7c97 bl       #0xfb1300
030a5fe4: 28008052 mov      w8, #1
030a5fe8: a80e1539 strb     w8, [x21, #0x543]
030a5fec: 88224339 ldrb     w8, [x20, #0xc8]
030a5ff0: e8030034 cbz      w8, #0x30a606c
030a5ff4: e003132a mov      w0, w19
030a5ff8: e1031faa mov      x1, xzr
030a5ffc: 507a0b94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
030a6000: a0030036 tbz      w0, #0, #0x30a6074
030a6004: 880240f9 ldr      x8, [x20]
030a6008: e00314aa mov      x0, x20
030a600c: 096542f9 ldr      x9, [x8, #0x4c8]
030a6010: 016942f9 ldr      x1, [x8, #0x4d0]
030a6014: 20013fd6 blr      x9
030a6018: 1f040071 cmp      w0, #1
030a601c: c1080054 b.ne     #0x30a6134
030a6020: 880240f9 ldr      x8, [x20]
030a6024: e00314aa mov      x0, x20
030a6028: 09bd41f9 ldr      x9, [x8, #0x378]
030a602c: 01c141f9 ldr      x1, [x8, #0x380]
030a6030: 20013fd6 blr      x9
030a6034: e1031faa mov      x1, xzr
030a6038: 547a0b94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
030a603c: 885e40f9 ldr      x8, [x20, #0xb8]
030a6040: e80800b4 cbz      x8, #0x30a615c
030a6044: 082540f9 ldr      x8, [x8, #0x48]
030a6048: a80800b4 cbz      x8, #0x30a615c
030a604c: 081940b9 ldr      w8, [x8, #0x18]
030a6050: 090c0011 add      w9, w0, #3
030a6054: 1f000071 cmp      w0, #0
030a6058: 29b1801a csel     w9, w9, w0, lt
030a605c: 297d0213 asr      w9, w9, #2
030a6060: 08050051 sub      w8, w8, #1
030a6064: 157d091b mul      w21, w8, w9
030a6068: 34000014 b        #0x30a6138
030a606c: e0031f2a mov      w0, wzr
030a6070: 37000014 b        #0x30a614c
030a6074: e0031faa mov      x0, xzr
030a6078: 25603194 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
030a607c: 88ce40b9 ldr      w8, [x20, #0xcc]
030a6080: 1f00086b cmp      w0, w8
030a6084: 00020054 b.eq     #0x30a60c4
030a6088: 955e40f9 ldr      x21, [x20, #0xb8]
030a608c: e00314aa mov      x0, x20
030a6090: e1031faa mov      x1, xzr
030a6094: 80730b94 bl       #0x3382e94 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$get_CurrentCell
030a6098: 200600b4 cbz      x0, #0x30a615c
030a609c: e1031faa mov      x1, xzr
030a60a0: 588ce897 bl       #0x2ac9200 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetBoardAdjustedPoint
030a60a4: d50500b4 cbz      x21, #0x30a615c
030a60a8: e20300aa mov      x2, x0
030a60ac: e00315aa mov      x0, x21
030a60b0: e103132a mov      w1, w19
030a60b4: 2b000094 bl       #0x30a6160 ; Royal.Scenes.Game.Mechanics.Items.CookieJarItem.View.CookieJarCollectHelper$$UpdateExtraScoreCache
030a60b8: e0031faa mov      x0, xzr
030a60bc: 14603194 bl       #0x3cfe10c ; UnityEngine.Time$$get_frameCount
030a60c0: 80ce00b9 str      w0, [x20, #0xcc]
030a60c4: 885e40f9 ldr      x8, [x20, #0xb8]
030a60c8: a80400b4 cbz      x8, #0x30a615c
030a60cc: 092540f9 ldr      x9, [x8, #0x48]
030a60d0: 690400b4 cbz      x9, #0x30a615c
030a60d4: 803240f9 ldr      x0, [x20, #0x60]
030a60d8: 200400b4 cbz      x0, #0x30a615c
030a60dc: 15a940b9 ldr      w21, [x8, #0xa8]
030a60e0: 361940b9 ldr      w22, [x9, #0x18]
030a60e4: e1048052 mov      w1, #0x27
030a60e8: e2031f2a mov      w2, wzr
030a60ec: e3031faa mov      x3, xzr
030a60f0: f122e697 bl       #0x2a2ecb4 ; Royal.Scenes.Game.Levels.Units.GoalManager$$GetGoalLeftCount
030a60f4: c802004b sub      w8, w22, w0
030a60f8: 1501152b adds     w21, w8, w21
030a60fc: c4010054 b.mi     #0x30a6134
030a6100: 880240f9 ldr      x8, [x20]
030a6104: e00314aa mov      x0, x20
030a6108: 09bd41f9 ldr      x9, [x8, #0x378]
030a610c: 01c141f9 ldr      x1, [x8, #0x380]
030a6110: 20013fd6 blr      x9
030a6114: e1031faa mov      x1, xzr
030a6118: 1c7a0b94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
030a611c: 080c0011 add      w8, w0, #3
030a6120: 1f000071 cmp      w0, #0
030a6124: 08b1801a csel     w8, w8, w0, lt
030a6128: 087d0213 asr      w8, w8, #2
030a612c: 157d151b mul      w21, w8, w21
030a6130: 02000014 b        #0x30a6138
030a6134: f5031f2a mov      w21, wzr
030a6138: e00314aa mov      x0, x20
030a613c: e103132a mov      w1, w19
030a6140: e2031faa mov      x2, xzr
030a6144: 0a7a0b94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
030a6148: 0000150b add      w0, w0, w21
030a614c: f37b42a9 ldp      x19, x30, [sp, #0x20]
030a6150: f55341a9 ldp      x21, x20, [sp, #0x10]
030a6154: f60743f8 ldr      x22, [sp], #0x30
030a6158: c0035fd6 ret      
030a615c: b32c7c97 bl       #0xfb1428
