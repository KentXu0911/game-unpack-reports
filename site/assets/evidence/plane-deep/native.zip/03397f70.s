# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemExplodeParticles$$Play
# Linear span to next metadata entry; not a complete CFG.
03397f70: f40f1ef8 str      x20, [sp, #-0x20]!
03397f74: f37b01a9 stp      x19, x30, [sp, #0x10]
03397f78: 740f01f0 adrp     x20, #0x5586000
03397f7c: 884e6639 ldrb     w8, [x20, #0x993]
03397f80: f30300aa mov      x19, x0
03397f84: c8000037 tbnz     w8, #0, #0x3397f9c
03397f88: 60f10090 adrp     x0, #0x51c3000
03397f8c: 007843f9 ldr      x0, [x0, #0x6f0]
03397f90: dc647097 bl       #0xfb1300
03397f94: 28008052 mov      w8, #1
03397f98: 884e2639 strb     w8, [x20, #0x993]
03397f9c: 601a40f9 ldr      x0, [x19, #0x30]
03397fa0: 800100b4 cbz      x0, #0x3397fd0
03397fa4: 74f10090 adrp     x20, #0x51c3000
03397fa8: 947a43f9 ldr      x20, [x20, #0x6f0]
03397fac: e1031faa mov      x1, xzr
03397fb0: c08b1094 bl       #0x37baeb0 ; UnityEngine.ParticleSystem$$Play
03397fb4: 810240f9 ldr      x1, [x20]
03397fb8: e00313aa mov      x0, x19
03397fbc: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397fc0: 00102e1e fmov     s0, #1.00000000
03397fc4: e2031faa mov      x2, xzr
03397fc8: f40742f8 ldr      x20, [sp], #0x20
03397fcc: 66be2514 b        #0x3d07964 ; UnityEngine.MonoBehaviour$$Invoke
03397fd0: 16657097 bl       #0xfb1428
