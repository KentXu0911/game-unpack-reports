# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$IsRowWinning
# Linear span to next metadata entry; not a complete CFG.
026a8224: ff0302d1 sub      sp, sp, #0x80
026a8228: f75b05a9 stp      x23, x22, [sp, #0x50]
026a822c: f55306a9 stp      x21, x20, [sp, #0x60]
026a8230: f37b07a9 stp      x19, x30, [sp, #0x70]
026a8234: f30300aa mov      x19, x0
026a8238: 001040f9 ldr      x0, [x0, #0x20]
026a823c: 400a00b4 cbz      x0, #0x26a8384
026a8240: f403012a mov      w20, w1
026a8244: e1031faa mov      x1, xzr
026a8248: f50302aa mov      x21, x2
026a824c: 321b0e94 bl       #0x2a2ef14 ; Royal.Scenes.Game.Levels.Units.GoalManager$$HasAnyPrerequisite
026a8250: 00040037 tbnz     w0, #0, #0x26a82d0
026a8254: 767601d0 adrp     x22, #0x5576000
026a8258: c8ae7c39 ldrb     w8, [x22, #0xf2b]
026a825c: c8000035 cbnz     w8, #0x26a8274
026a8260: 005b0190 adrp     x0, #0x5208000
026a8264: 00c041f9 ldr      x0, [x0, #0x380]
026a8268: 2624a497 bl       #0xfb1300
026a826c: 28008052 mov      w8, #1
026a8270: c8ae3c39 strb     w8, [x22, #0xf2b]
026a8274: 085b0190 adrp     x8, #0x5208000
026a8278: 08c141f9 ldr      x8, [x8, #0x380]
026a827c: 080140f9 ldr      x8, [x8]
026a8280: 085d40f9 ldr      x8, [x8, #0xb8]
026a8284: 080140f9 ldr      x8, [x8]
026a8288: e80700b4 cbz      x8, #0x26a8384
026a828c: 081d40f9 ldr      x8, [x8, #0x38]
026a8290: a80700b4 cbz      x8, #0x26a8384
026a8294: 080d40f9 ldr      x8, [x8, #0x18]
026a8298: 680700b4 cbz      x8, #0x26a8384
026a829c: 08a14039 ldrb     w8, [x8, #0x28]
026a82a0: 88010035 cbnz     w8, #0x26a82d0
026a82a4: a81a40f9 ldr      x8, [x21, #0x30]
026a82a8: a18240ad ldp      q1, q0, [x21, #0x10]
026a82ac: a202c03d ldr      q2, [x21]
026a82b0: e2430091 add      x2, sp, #0x10
026a82b4: e00313aa mov      x0, x19
026a82b8: e103142a mov      w1, w20
026a82bc: e82300f9 str      x8, [sp, #0x40]
026a82c0: e10301ad stp      q1, q0, [sp, #0x20]
026a82c4: e207803d str      q2, [sp, #0x10]
026a82c8: 33000094 bl       #0x26a8394 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinConditionForHorizontalRocket
026a82cc: 00010036 tbz      w0, #0, #0x26a82ec
026a82d0: e0031f2a mov      w0, wzr
026a82d4: f37b47a9 ldp      x19, x30, [sp, #0x70]
026a82d8: f55346a9 ldp      x21, x20, [sp, #0x60]
026a82dc: f75b45a9 ldp      x23, x22, [sp, #0x50]
026a82e0: 00000012 and      w0, w0, #1
026a82e4: ff030291 add      sp, sp, #0x80
026a82e8: c0035fd6 ret      
026a82ec: e00313aa mov      x0, x19
026a82f0: c5fdff97 bl       #0x26a7a04 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ClearGoalData
026a82f4: c8008052 mov      w8, #6
026a82f8: 681200b9 str      w8, [x19, #0x10]
026a82fc: a8524039 ldrb     w8, [x21, #0x14]
026a8300: 600e40f9 ldr      x0, [x19, #0x18]
026a8304: 08010012 and      w8, w8, #1
026a8308: 68520039 strb     w8, [x19, #0x14]
026a830c: c00300b4 cbz      x0, #0x26a8384
026a8310: f5031f2a mov      w21, wzr
026a8314: f6031faa mov      x22, xzr
026a8318: e1031faa mov      x1, xzr
026a831c: 31bb0294 bl       #0x2756fe0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Width
026a8320: bf02006b cmp      w21, w0
026a8324: 2a030054 b.ge     #0x26a8388
026a8328: 770e40f9 ldr      x23, [x19, #0x18]
026a832c: e0230091 add      x0, sp, #8
026a8330: e103152a mov      w1, w21
026a8334: e203142a mov      w2, w20
026a8338: e3031faa mov      x3, xzr
026a833c: ff0700f9 str      xzr, [sp, #8]
026a8340: 4d7f1094 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
026a8344: 170200b4 cbz      x23, #0x26a8384
026a8348: e10740f9 ldr      x1, [sp, #8]
026a834c: e00317aa mov      x0, x23
026a8350: e2031faa mov      x2, xzr
026a8354: 6fb00294 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
026a8358: 1f0000f1 cmp      x0, #0
026a835c: d602809a csel     x22, x22, x0, eq
026a8360: c00000b4 cbz      x0, #0x26a8378
026a8364: 160100b4 cbz      x22, #0x26a8384
026a8368: e00316aa mov      x0, x22
026a836c: e10313aa mov      x1, x19
026a8370: e2031faa mov      x2, xzr
026a8374: ff891094 bl       #0x2acab70 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$CalculateGoalDecrementByPropellerHit
026a8378: 600e40f9 ldr      x0, [x19, #0x18]
026a837c: b5060011 add      w21, w21, #1
026a8380: c0fcffb5 cbnz     x0, #0x26a8318
026a8384: 2924a497 bl       #0xfb1428
026a8388: e00313aa mov      x0, x19
026a838c: 77ffff97 bl       #0x26a8168 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$IsWinningByHitCells
026a8390: d1ffff17 b        #0x26a82d4
