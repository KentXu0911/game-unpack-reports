# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy.<ExplodeNeighbors>d__13$$System.Collections.IEnumerator.get_Current
# Linear span to next metadata entry; not a complete CFG.
033a39c0: 000c40f9 ldr      x0, [x0, #0x18]
033a39c4: c0035fd6 ret      
