# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$GetStartState
# Linear span to next metadata entry; not a complete CFG.
03398c90: 40008052 mov      w0, #2
03398c94: c0035fd6 ret      
