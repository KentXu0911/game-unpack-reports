# Royal.Scenes.Game.Mechanics.Items.MagnetItem.MagnetItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
020dab6c: fe0f1ff8 str      x30, [sp, #-0x10]!
020dab70: 08004339 ldrb     w8, [x0, #0xc0]
020dab74: a8010034 cbz      w8, #0x20daba8
020dab78: 080040f9 ldr      x8, [x0]
020dab7c: 095542f9 ldr      x9, [x8, #0x4a8]
020dab80: 015942f9 ldr      x1, [x8, #0x4b0]
020dab84: 20013fd6 blr      x9
020dab88: 08229f52 mov      w8, #0xf910
020dab8c: 49e39352 mov      w9, #0x9f1a
020dab90: 1f040071 cmp      w0, #1
020dab94: c800a072 movk     w8, #6, lsl #16
020dab98: 6901a072 movk     w9, #0xb, lsl #16
020dab9c: 2001881a csel     w0, w9, w8, eq
020daba0: fe0741f8 ldr      x30, [sp], #0x10
020daba4: c0035fd6 ret      
020daba8: e0031f2a mov      w0, wzr
020dabac: fe0741f8 ldr      x30, [sp], #0x10
020dabb0: c0035fd6 ret      
