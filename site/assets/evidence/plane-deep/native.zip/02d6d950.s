# Royal.Scenes.Game.Mechanics.Items.GiantBirdItem.GiantBirdFakeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02d6d950: fe0f1ff8 str      x30, [sp, #-0x10]!
02d6d954: 005840f9 ldr      x0, [x0, #0xb0]
02d6d958: c00000b4 cbz      x0, #0x2d6d970
02d6d95c: 080040f9 ldr      x8, [x0]
02d6d960: 033542f9 ldr      x3, [x8, #0x468]
02d6d964: 023942f9 ldr      x2, [x8, #0x470]
02d6d968: fe0741f8 ldr      x30, [sp], #0x10
02d6d96c: 60001fd6 br       x3
02d6d970: ae0e8997 bl       #0xfb1428
