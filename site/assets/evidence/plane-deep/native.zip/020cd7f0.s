# Royal.Scenes.Game.Mechanics.Items.MapScrollCollectItem.MapScrollCollectItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
020cd7f0: f553bea9 stp      x21, x20, [sp, #-0x20]!
020cd7f4: f37b01a9 stp      x19, x30, [sp, #0x10]
020cd7f8: f303012a mov      w19, w1
020cd7fc: f40300aa mov      x20, x0
020cd800: e003012a mov      w0, w1
020cd804: e1031faa mov      x1, xzr
020cd808: 4ddc4a94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
020cd80c: a0030036 tbz      w0, #0, #0x20cd880
020cd810: 59feff97 bl       #0x20cd174 ; Royal.Scenes.Game.Mechanics.Items.MapScrollCollectItem.MapScrollCollectItemModel$$get_TreasureMapHelper
020cd814: 200400b4 cbz      x0, #0x20cd898
020cd818: e1031faa mov      x1, xzr
020cd81c: 593fc797 bl       #0x129d580 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.TreasureMapItem.TreasureMapHelper$$IsOneHitRemainingOnActiveTreasureMap
020cd820: 00030036 tbz      w0, #0, #0x20cd880
020cd824: 880240f9 ldr      x8, [x20]
020cd828: e00314aa mov      x0, x20
020cd82c: 096542f9 ldr      x9, [x8, #0x4c8]
020cd830: 016942f9 ldr      x1, [x8, #0x4d0]
020cd834: 20013fd6 blr      x9
020cd838: 1f040071 cmp      w0, #1
020cd83c: 21020054 b.ne     #0x20cd880
020cd840: 4dfeff97 bl       #0x20cd174 ; Royal.Scenes.Game.Mechanics.Items.MapScrollCollectItem.MapScrollCollectItemModel$$get_TreasureMapHelper
020cd844: a00200b4 cbz      x0, #0x20cd898
020cd848: e1031faa mov      x1, xzr
020cd84c: a840c797 bl       #0x129daec ; Royal.Scenes.Game.Mechanics.Items.StaticItems.TreasureMapItem.TreasureMapHelper$$ShouldAddExtraScoreForLastState
020cd850: 28729552 mov      w8, #0xab91
020cd854: 1f000072 tst      w0, #1
020cd858: e800a072 movk     w8, #7, lsl #16
020cd85c: e00314aa mov      x0, x20
020cd860: e103132a mov      w1, w19
020cd864: e2031faa mov      x2, xzr
020cd868: 15119f1a csel     w21, w8, wzr, ne
020cd86c: 40dc4a94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
020cd870: f37b41a9 ldp      x19, x30, [sp, #0x10]
020cd874: a002000b add      w0, w21, w0
020cd878: f553c2a8 ldp      x21, x20, [sp], #0x20
020cd87c: c0035fd6 ret      
020cd880: e103132a mov      w1, w19
020cd884: f37b41a9 ldp      x19, x30, [sp, #0x10]
020cd888: e00314aa mov      x0, x20
020cd88c: e2031faa mov      x2, xzr
020cd890: f553c2a8 ldp      x21, x20, [sp], #0x20
020cd894: 36dc4a14 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
020cd898: e48ebb97 bl       #0xfb1428
