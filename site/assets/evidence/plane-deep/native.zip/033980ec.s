# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_StartFallStateId
# Linear span to next metadata entry; not a complete CFG.
033980ec: f40f1ef8 str      x20, [sp, #-0x20]!
033980f0: f37b01a9 stp      x19, x30, [sp, #0x10]
033980f4: 740f01d0 adrp     x20, #0x5586000
033980f8: f3f10090 adrp     x19, #0x51d4000
033980fc: 885e6639 ldrb     w8, [x20, #0x997]
03398100: 73da41f9 ldr      x19, [x19, #0x3b0]
03398104: c8000037 tbnz     w8, #0, #0x339811c
03398108: e0f10090 adrp     x0, #0x51d4000
0339810c: 00d841f9 ldr      x0, [x0, #0x3b0]
03398110: 7c647097 bl       #0xfb1300
03398114: 28008052 mov      w8, #1
03398118: 885e2639 strb     w8, [x20, #0x997]
0339811c: 600240f9 ldr      x0, [x19]
03398120: 08e040b9 ldr      w8, [x0, #0xe0]
03398124: 68000035 cbnz     w8, #0x3398130
03398128: b7647097 bl       #0xfb1404
0339812c: 600240f9 ldr      x0, [x19]
03398130: 085c40f9 ldr      x8, [x0, #0xb8]
03398134: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398138: 000d40b9 ldr      w0, [x8, #0xc]
0339813c: f40742f8 ldr      x20, [sp], #0x20
03398140: c0035fd6 ret      
