# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$GetCumulativeHittableMultiCellHitCount
# Linear span to next metadata entry; not a complete CFG.
026a7e28: ffc300d1 sub      sp, sp, #0x30
026a7e2c: f55301a9 stp      x21, x20, [sp, #0x10]
026a7e30: f37b02a9 stp      x19, x30, [sp, #0x20]
026a7e34: d57601b0 adrp     x21, #0x5580000
026a7e38: a8964139 ldrb     w8, [x21, #0x65]
026a7e3c: f303012a mov      w19, w1
026a7e40: f40300aa mov      x20, x0
026a7e44: c8000037 tbnz     w8, #0, #0x26a7e5c
026a7e48: e05b01f0 adrp     x0, #0x5226000
026a7e4c: 00bc44f9 ldr      x0, [x0, #0x978]
026a7e50: 2c25a497 bl       #0xfb1300
026a7e54: 28008052 mov      w8, #1
026a7e58: a8960139 strb     w8, [x21, #0x65]
026a7e5c: ff0f00b9 str      wzr, [sp, #0xc]
026a7e60: 802640f9 ldr      x0, [x20, #0x48]
026a7e64: 800100b4 cbz      x0, #0x26a7e94
026a7e68: e85b01f0 adrp     x8, #0x5226000
026a7e6c: 08bd44f9 ldr      x8, [x8, #0x978]
026a7e70: e2330091 add      x2, sp, #0xc
026a7e74: e103132a mov      w1, w19
026a7e78: 030140f9 ldr      x3, [x8]
026a7e7c: 56274194 bl       #0x36f1bd4 ; System.Collections.Generic.Dictionary<int, int>$$TryGetValue
026a7e80: e00f40b9 ldr      w0, [sp, #0xc]
026a7e84: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a7e88: f55341a9 ldp      x21, x20, [sp, #0x10]
026a7e8c: ffc30091 add      sp, sp, #0x30
026a7e90: c0035fd6 ret      
026a7e94: 6525a497 bl       #0xfb1428
