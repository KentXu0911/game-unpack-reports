# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$FallEnded
# Linear span to next metadata entry; not a complete CFG.
033983b0: ff4302d1 sub      sp, sp, #0x90
033983b4: f63300f9 str      x22, [sp, #0x60]
033983b8: f55307a9 stp      x21, x20, [sp, #0x70]
033983bc: f37b08a9 stp      x19, x30, [sp, #0x80]
033983c0: 740f01d0 adrp     x20, #0x5586000
033983c4: 886a6639 ldrb     w8, [x20, #0x99a]
033983c8: f30300aa mov      x19, x0
033983cc: c8000037 tbnz     w8, #0, #0x33983e4
033983d0: 80f100f0 adrp     x0, #0x51cb000
033983d4: 00c843f9 ldr      x0, [x0, #0x790]
033983d8: ca637097 bl       #0xfb1300
033983dc: 28008052 mov      w8, #1
033983e0: 886a2639 strb     w8, [x20, #0x99a]
033983e4: 00e4006f movi     v0.2d, #0000000000000000
033983e8: e00313aa mov      x0, x19
033983ec: e1031faa mov      x1, xzr
033983f0: ff5300b9 str      wzr, [sp, #0x50]
033983f4: e08301ad stp      q0, q0, [sp, #0x30]
033983f8: 0fe1ff97 bl       #0x3390834 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$FallEnded
033983fc: 603e40f9 ldr      x0, [x19, #0x78]
03398400: 401500b4 cbz      x0, #0x33986a8
03398404: e8230091 add      x8, sp, #8
03398408: e1031f2a mov      w1, wzr
0339840c: e2031faa mov      x2, xzr
03398410: c7c8a897 bl       #0x1dca72c ; UnityEngine.Animator$$GetCurrentAnimatorStateInfo
03398414: e083c03c ldur     q0, [sp, #8]
03398418: e183c13c ldur     q1, [sp, #0x18]
0339841c: e82b40b9 ldr      w8, [sp, #0x28]
03398420: e0c30091 add      x0, sp, #0x30
03398424: e1031faa mov      x1, xzr
03398428: e08701ad stp      q0, q1, [sp, #0x30]
0339842c: e85300b9 str      w8, [sp, #0x50]
03398430: fec6a897 bl       #0x1dca028 ; UnityEngine.AnimatorStateInfo$$get_fullPathHash
03398434: 680240f9 ldr      x8, [x19]
03398438: f403002a mov      w20, w0
0339843c: e00313aa mov      x0, x19
03398440: 094542f9 ldr      x9, [x8, #0x488]
03398444: 014942f9 ldr      x1, [x8, #0x490]
03398448: 20013fd6 blr      x9
0339844c: 9f02006b cmp      w20, w0
03398450: 61000054 b.ne     #0x339845c
03398454: e00313aa mov      x0, x19
03398458: 95000094 bl       #0x33986ac ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$PlayEndFallAnimation
0339845c: 745e40f9 ldr      x20, [x19, #0xb8]
03398460: 541200b4 cbz      x20, #0x33986a8
03398464: 96f100f0 adrp     x22, #0x51cb000
03398468: 880240f9 ldr      x8, [x20]
0339846c: d6ca43f9 ldr      x22, [x22, #0x790]
03398470: 09554279 ldrh     w9, [x8, #0x12a]
03398474: c10240f9 ldr      x1, [x22]
03398478: 290100b4 cbz      x9, #0x339849c
0339847c: 0a5940f9 ldr      x10, [x8, #0xb0]
03398480: 4a210091 add      x10, x10, #8
03398484: 4b815ff8 ldur     x11, [x10, #-8]
03398488: 7f0101eb cmp      x11, x1
0339848c: 00010054 b.eq     #0x33984ac
03398490: 290500f1 subs     x9, x9, #1
03398494: 4a410091 add      x10, x10, #0x10
03398498: 61ffff54 b.ne     #0x3398484
0339849c: 62008052 mov      w2, #3
033984a0: e00314aa mov      x0, x20
033984a4: 8ca36f97 bl       #0xf812d4
033984a8: 05000014 b        #0x33984bc
033984ac: 490140b9 ldr      w9, [x10]
033984b0: 290d0011 add      w9, w9, #3
033984b4: 08d1298b add      x8, x8, w9, sxtw #4
033984b8: 00e10491 add      x0, x8, #0x138
033984bc: 080440a9 ldp      x8, x1, [x0]
033984c0: e00314aa mov      x0, x20
033984c4: 00013fd6 blr      x8
033984c8: 600e00b4 cbz      x0, #0x3398694
033984cc: 745e40f9 ldr      x20, [x19, #0xb8]
033984d0: d40e00b4 cbz      x20, #0x33986a8
033984d4: 880240f9 ldr      x8, [x20]
033984d8: c10240f9 ldr      x1, [x22]
033984dc: 09554279 ldrh     w9, [x8, #0x12a]
033984e0: 290100b4 cbz      x9, #0x3398504
033984e4: 0a5940f9 ldr      x10, [x8, #0xb0]
033984e8: 4a210091 add      x10, x10, #8
033984ec: 4b815ff8 ldur     x11, [x10, #-8]
033984f0: 7f0101eb cmp      x11, x1
033984f4: 00010054 b.eq     #0x3398514
033984f8: 290500f1 subs     x9, x9, #1
033984fc: 4a410091 add      x10, x10, #0x10
03398500: 61ffff54 b.ne     #0x33984ec
03398504: 62008052 mov      w2, #3
03398508: e00314aa mov      x0, x20
0339850c: 72a36f97 bl       #0xf812d4
03398510: 05000014 b        #0x3398524
03398514: 490140b9 ldr      w9, [x10]
03398518: 290d0011 add      w9, w9, #3
0339851c: 08d1298b add      x8, x8, w9, sxtw #4
03398520: 00e10491 add      x0, x8, #0x138
03398524: 080440a9 ldp      x8, x1, [x0]
03398528: e00314aa mov      x0, x20
0339852c: 00013fd6 blr      x8
03398530: c00b00b4 cbz      x0, #0x33986a8
03398534: e1031faa mov      x1, xzr
03398538: 4ac1dc97 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
0339853c: 600b00b4 cbz      x0, #0x33986a8
03398540: e1031faa mov      x1, xzr
03398544: b1d3ff97 bl       #0x338d408 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$IsUnderNonFallBlockingAboveStaticItem
03398548: 600a0037 tbnz     w0, #0, #0x3398694
0339854c: f40e01d0 adrp     x20, #0x5576000
03398550: 88ae7c39 ldrb     w8, [x20, #0xf2b]
03398554: c8000035 cbnz     w8, #0x339856c
03398558: 80f30090 adrp     x0, #0x5208000
0339855c: 00c041f9 ldr      x0, [x0, #0x380]
03398560: 68637097 bl       #0xfb1300
03398564: 28008052 mov      w8, #1
03398568: 88ae3c39 strb     w8, [x20, #0xf2b]
0339856c: 88f30090 adrp     x8, #0x5208000
03398570: 08c141f9 ldr      x8, [x8, #0x380]
03398574: 080140f9 ldr      x8, [x8]
03398578: 085d40f9 ldr      x8, [x8, #0xb8]
0339857c: 080140f9 ldr      x8, [x8]
03398580: 480900b4 cbz      x8, #0x33986a8
03398584: 091d40f9 ldr      x9, [x8, #0x38]
03398588: 090900b4 cbz      x9, #0x33986a8
0339858c: 755e40f9 ldr      x21, [x19, #0xb8]
03398590: d50800b4 cbz      x21, #0x33986a8
03398594: a80240f9 ldr      x8, [x21]
03398598: 340d40f9 ldr      x20, [x9, #0x18]
0339859c: c10240f9 ldr      x1, [x22]
033985a0: 09554279 ldrh     w9, [x8, #0x12a]
033985a4: 290100b4 cbz      x9, #0x33985c8
033985a8: 0a5940f9 ldr      x10, [x8, #0xb0]
033985ac: 4a210091 add      x10, x10, #8
033985b0: 4b815ff8 ldur     x11, [x10, #-8]
033985b4: 7f0101eb cmp      x11, x1
033985b8: 00010054 b.eq     #0x33985d8
033985bc: 290500f1 subs     x9, x9, #1
033985c0: 4a410091 add      x10, x10, #0x10
033985c4: 61ffff54 b.ne     #0x33985b0
033985c8: 62008052 mov      w2, #3
033985cc: e00315aa mov      x0, x21
033985d0: 41a36f97 bl       #0xf812d4
033985d4: 05000014 b        #0x33985e8
033985d8: 490140b9 ldr      w9, [x10]
033985dc: 290d0011 add      w9, w9, #3
033985e0: 08d1298b add      x8, x8, w9, sxtw #4
033985e4: 00e10491 add      x0, x8, #0x138
033985e8: 080440a9 ldp      x8, x1, [x0]
033985ec: e00315aa mov      x0, x21
033985f0: 00013fd6 blr      x8
033985f4: a00500b4 cbz      x0, #0x33986a8
033985f8: e1031faa mov      x1, xzr
033985fc: 19c1dc97 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
03398600: 755e40f9 ldr      x21, [x19, #0xb8]
03398604: 350500b4 cbz      x21, #0x33986a8
03398608: a80240f9 ldr      x8, [x21]
0339860c: c10240f9 ldr      x1, [x22]
03398610: f30300aa mov      x19, x0
03398614: 09554279 ldrh     w9, [x8, #0x12a]
03398618: 290100b4 cbz      x9, #0x339863c
0339861c: 0a5940f9 ldr      x10, [x8, #0xb0]
03398620: 4a210091 add      x10, x10, #8
03398624: 4b815ff8 ldur     x11, [x10, #-8]
03398628: 7f0101eb cmp      x11, x1
0339862c: 00010054 b.eq     #0x339864c
03398630: 290500f1 subs     x9, x9, #1
03398634: 4a410091 add      x10, x10, #0x10
03398638: 61ffff54 b.ne     #0x3398624
0339863c: 62008052 mov      w2, #3
03398640: e00315aa mov      x0, x21
03398644: 24a36f97 bl       #0xf812d4
03398648: 05000014 b        #0x339865c
0339864c: 490140b9 ldr      w9, [x10]
03398650: 290d0011 add      w9, w9, #3
03398654: 08d1298b add      x8, x8, w9, sxtw #4
03398658: 00e10491 add      x0, x8, #0x138
0339865c: 080440a9 ldp      x8, x1, [x0]
03398660: e00315aa mov      x0, x21
03398664: 00013fd6 blr      x8
03398668: 000200b4 cbz      x0, #0x33986a8
0339866c: e1031faa mov      x1, xzr
03398670: 52ccdc97 bl       #0x2acb7b8 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetViewPosition
03398674: b40100b4 cbz      x20, #0x33986a8
03398678: 23008052 mov      w3, #1
0339867c: 24008052 mov      w4, #1
03398680: e00314aa mov      x0, x20
03398684: e10313aa mov      x1, x19
03398688: e2031f2a mov      w2, wzr
0339868c: e5031faa mov      x5, xzr
03398690: e717c397 bl       #0x245e62c ; Royal.Player.Context.Data.Session.UserActiveLevelData$$SpecialItemCreated
03398694: f37b48a9 ldp      x19, x30, [sp, #0x80]
03398698: f55347a9 ldp      x21, x20, [sp, #0x70]
0339869c: f63340f9 ldr      x22, [sp, #0x60]
033986a0: ff430291 add      sp, sp, #0x90
033986a4: c0035fd6 ret      
033986a8: 60637097 bl       #0xfb1428
