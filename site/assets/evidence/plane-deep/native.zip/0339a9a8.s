# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScaleDown
# Linear span to next metadata entry; not a complete CFG.
0339a9a8: ffc301d1 sub      sp, sp, #0x70
0339a9ac: ed33026d stp      d13, d12, [sp, #0x20]
0339a9b0: eb2b036d stp      d11, d10, [sp, #0x30]
0339a9b4: e923046d stp      d9, d8, [sp, #0x40]
0339a9b8: f55305a9 stp      x21, x20, [sp, #0x50]
0339a9bc: f37b06a9 stp      x19, x30, [sp, #0x60]
0339a9c0: 740f0190 adrp     x20, #0x5586000
0339a9c4: 888e6639 ldrb     w8, [x20, #0x9a3]
0339a9c8: f30300aa mov      x19, x0
0339a9cc: e007803d str      q0, [sp, #0x10]
0339a9d0: e8000037 tbnz     w8, #0, #0x339a9ec
0339a9d4: e0f200b0 adrp     x0, #0x51f7000
0339a9d8: 00f844f9 ldr      x0, [x0, #0x9f0]
0339a9dc: 495a7097 bl       #0xfb1300
0339a9e0: e007c03d ldr      q0, [sp, #0x10]
0339a9e4: 28008052 mov      w8, #1
0339a9e8: 888e2639 strb     w8, [x20, #0x9a3]
0339a9ec: 0820201e fcmp     s0, #0.0
0339a9f0: 45000054 b.pl     #0x339a9f8
0339a9f4: 7f9600b9 str      wzr, [x19, #0x94]
0339a9f8: f50e0190 adrp     x21, #0x5576000
0339a9fc: 743640f9 ldr      x20, [x19, #0x68]
0339aa00: a8a27c39 ldrb     w8, [x21, #0xf28]
0339aa04: 688a40bd ldr      s8, [x19, #0x88]
0339aa08: e8000035 cbnz     w8, #0x339aa24
0339aa0c: 80f400b0 adrp     x0, #0x522b000
0339aa10: 00ac43f9 ldr      x0, [x0, #0x758]
0339aa14: 3b5a7097 bl       #0xfb1300
0339aa18: e007c03d ldr      q0, [sp, #0x10]
0339aa1c: 28008052 mov      w8, #1
0339aa20: a8a23c39 strb     w8, [x21, #0xf28]
0339aa24: 01102e1e fmov     s1, #1.00000000
0339aa28: 0820201e fcmp     s0, #0.0
0339aa2c: 0158211e fmin     s1, s0, s1
0339aa30: e003271e fmov     s0, wzr
0339aa34: 215c201e fcsel    s1, s1, s0, pl
0339aa38: 140e00b4 cbz      x20, #0x339abf8
0339aa3c: 95f400b0 adrp     x21, #0x522b000
0339aa40: b5ae43f9 ldr      x21, [x21, #0x758]
0339aa44: 2048201e fmax     s0, s1, s0
0339aa48: e00314aa mov      x0, x20
0339aa4c: e1031faa mov      x1, xzr
0339aa50: a80240f9 ldr      x8, [x21]
0339aa54: 085d40f9 ldr      x8, [x8, #0xb8]
0339aa58: 018d412d ldp      s1, s3, [x8, #0xc]
0339aa5c: 051540bd ldr      s5, [x8, #0x14]
0339aa60: 0291412d ldp      s2, s4, [x8, #0xc]
0339aa64: 061540bd ldr      s6, [x8, #0x14]
0339aa68: 0109211e fmul     s1, s8, s1
0339aa6c: 0309231e fmul     s3, s8, s3
0339aa70: 0509251e fmul     s5, s8, s5
0339aa74: 4238211e fsub     s2, s2, s1
0339aa78: 8438231e fsub     s4, s4, s3
0339aa7c: c638251e fsub     s6, s6, s5
0339aa80: 0208221e fmul     s2, s0, s2
0339aa84: 0408241e fmul     s4, s0, s4
0339aa88: 0608261e fmul     s6, s0, s6
0339aa8c: 2028221e fadd     s0, s1, s2
0339aa90: 6128241e fadd     s1, s3, s4
0339aa94: a228261e fadd     s2, s5, s6
0339aa98: 63be2594 bl       #0x3d0a424 ; UnityEngine.Transform$$set_localScale
0339aa9c: f40e0190 adrp     x20, #0x5576000
0339aaa0: 694244fc ldur     d9, [x19, #0x44]
0339aaa4: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339aaa8: 6a4e40bd ldr      s10, [x19, #0x4c]
0339aaac: c8000035 cbnz     w8, #0x339aac4
0339aab0: 80f400b0 adrp     x0, #0x522b000
0339aab4: 00ac43f9 ldr      x0, [x0, #0x758]
0339aab8: 125a7097 bl       #0xfb1300
0339aabc: 28008052 mov      w8, #1
0339aac0: 88b23c39 strb     w8, [x20, #0xf2c]
0339aac4: a80240f9 ldr      x8, [x21]
0339aac8: 140f01f0 adrp     x20, #0x557d000
0339aacc: 89ba5f39 ldrb     w9, [x20, #0x7ee]
0339aad0: 085d40f9 ldr      x8, [x8, #0xb8]
0339aad4: 030140fd ldr      d3, [x8]
0339aad8: 080940bd ldr      s8, [x8, #8]
0339aadc: 09010035 cbnz     w9, #0x339aafc
0339aae0: 20f300d0 adrp     x0, #0x5200000
0339aae4: 008c46f9 ldr      x0, [x0, #0xd18]
0339aae8: e303803d str      q3, [sp]
0339aaec: 055a7097 bl       #0xfb1300
0339aaf0: e303c03d ldr      q3, [sp]
0339aaf4: 28008052 mov      w8, #1
0339aaf8: 88ba1f39 strb     w8, [x20, #0x7ee]
0339aafc: 6bd4a90e fsub     v11.2s, v3.2s, v9.2s
0339ab00: f4f200b0 adrp     x20, #0x51f7000
0339ab04: 0c392a1e fsub     s12, s8, s10
0339ab08: 60dd2b2e fmul     v0.2s, v11.2s, v11.2s
0339ab0c: 94fa44f9 ldr      x20, [x20, #0x9f0]
0339ab10: 00d8307e faddp    s0, v0.2s
0339ab14: 81092c1e fmul     s1, s12, s12
0339ab18: 2d28201e fadd     s13, s1, s0
0339ab1c: a821201e fcmp     s13, #0.0
0339ab20: c0020054 b.eq     #0x339ab78
0339ab24: e007c03d ldr      q0, [sp, #0x10]
0339ab28: 0820201e fcmp     s0, #0.0
0339ab2c: 8b000054 b.lt     #0x339ab3c
0339ab30: 0008201e fmul     s0, s0, s0
0339ab34: a021201e fcmp     s13, s0
0339ab38: 09020054 b.ls     #0x339ab78
0339ab3c: 28f300d0 adrp     x8, #0x5200000
0339ab40: 088d46f9 ldr      x8, [x8, #0xd18]
0339ab44: 000140f9 ldr      x0, [x8]
0339ab48: 08e040b9 ldr      w8, [x0, #0xe0]
0339ab4c: 48000035 cbnz     w8, #0x339ab54
0339ab50: 2d5a7097 bl       #0xfb1404
0339ab54: e207c03d ldr      q2, [sp, #0x10]
0339ab58: a0c1211e fsqrt    s0, s13
0339ab5c: 0104040e dup      v1.2s, v0.s[0]
0339ab60: 8019201e fdiv     s0, s12, s0
0339ab64: 61fd212e fdiv     v1.2s, v11.2s, v1.2s
0339ab68: 0008221e fmul     s0, s0, s2
0339ab6c: 2190820f fmul     v1.2s, v1.2s, v2.s[0]
0339ab70: 23d5210e fadd     v3.2s, v9.2s, v1.2s
0339ab74: 4829201e fadd     s8, s10, s0
0339ab78: 800240f9 ldr      x0, [x20]
0339ab7c: 08e040b9 ldr      w8, [x0, #0xe0]
0339ab80: a8000035 cbnz     w8, #0x339ab94
0339ab84: e303803d str      q3, [sp]
0339ab88: 1f5a7097 bl       #0xfb1404
0339ab8c: e303c03d ldr      q3, [sp]
0339ab90: 800240f9 ldr      x0, [x20]
0339ab94: 085c40f9 ldr      x8, [x0, #0xb8]
0339ab98: 61040c5e mov      s1, v3.s[1]
0339ab9c: 0009402d ldp      s0, s2, [x8]
0339aba0: 683240f9 ldr      x8, [x19, #0x60]
0339aba4: 6020201e fcmp     s3, s0
0339aba8: 694c201e fcsel    s9, s3, s0, mi
0339abac: 2020221e fcmp     s1, s2
0339abb0: 2acc221e fcsel    s10, s1, s2, gt
0339abb4: 280200b4 cbz      x8, #0x339abf8
0339abb8: 004140f9 ldr      x0, [x8, #0x80]
0339abbc: e00100b4 cbz      x0, #0x339abf8
0339abc0: e1031faa mov      x1, xzr
0339abc4: 79a02594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339abc8: 800100b4 cbz      x0, #0x339abf8
0339abcc: 201da94e mov      v0.16b, v9.16b
0339abd0: 411daa4e mov      v1.16b, v10.16b
0339abd4: 021da84e mov      v2.16b, v8.16b
0339abd8: f37b46a9 ldp      x19, x30, [sp, #0x60]
0339abdc: f55345a9 ldp      x21, x20, [sp, #0x50]
0339abe0: e923446d ldp      d9, d8, [sp, #0x40]
0339abe4: eb2b436d ldp      d11, d10, [sp, #0x30]
0339abe8: ed33426d ldp      d13, d12, [sp, #0x20]
0339abec: e1031faa mov      x1, xzr
0339abf0: ffc30191 add      sp, sp, #0x70
0339abf4: b6bc2514 b        #0x3d09ecc ; UnityEngine.Transform$$set_localPosition
0339abf8: 0c5a7097 bl       #0xfb1428
