# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$GetDistanceSmoother
# Linear span to next metadata entry; not a complete CFG.
033a228c: e85600f0 adrp     x8, #0x3e81000
033a2290: 495800b0 adrp     x9, #0x3eab000
033a2294: 01954cbd ldr      s1, [x8, #0xc94]
033a2298: 22794cbd ldr      s2, [x9, #0xc78]
033a229c: 03102e1e fmov     s3, #1.00000000
033a22a0: e403271e fmov     s4, wzr
033a22a4: 0028211e fadd     s0, s0, s1
033a22a8: 0018221e fdiv     s0, s0, s2
033a22ac: 0158231e fmin     s1, s0, s3
033a22b0: 2108241e fmul     s1, s1, s4
033a22b4: 0820201e fcmp     s0, #0.0
033a22b8: 205c241e fcsel    s0, s1, s4, pl
033a22bc: c0035fd6 ret      
