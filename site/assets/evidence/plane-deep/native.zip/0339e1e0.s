# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangePosition
# Linear span to next metadata entry; not a complete CFG.
0339e1e0: ff8302d1 sub      sp, sp, #0xa0
0339e1e4: ef3b036d stp      d15, d14, [sp, #0x30]
0339e1e8: ed33046d stp      d13, d12, [sp, #0x40]
0339e1ec: eb2b056d stp      d11, d10, [sp, #0x50]
0339e1f0: e923066d stp      d9, d8, [sp, #0x60]
0339e1f4: f75b07a9 stp      x23, x22, [sp, #0x70]
0339e1f8: f55308a9 stp      x21, x20, [sp, #0x80]
0339e1fc: f37b09a9 stp      x19, x30, [sp, #0x90]
0339e200: 540f0190 adrp     x20, #0x5586000
0339e204: 88e26639 ldrb     w8, [x20, #0x9b8]
0339e208: ac1ca54e mov      v12.16b, v5.16b
0339e20c: 8d1ca44e mov      v13.16b, v4.16b
0339e210: 6e1ca34e mov      v14.16b, v3.16b
0339e214: f30300aa mov      x19, x0
0339e218: e62b00bd str      s6, [sp, #0x28]
0339e21c: e10b022d stp      s1, s2, [sp, #0x10]
0339e220: e00f00bd str      s0, [sp, #0xc]
0339e224: e8010037 tbnz     w8, #0, #0x339e260
0339e228: 80f400b0 adrp     x0, #0x522f000
0339e22c: 000445f9 ldr      x0, [x0, #0xa08]
0339e230: 344c7097 bl       #0xfb1300
0339e234: 80f400f0 adrp     x0, #0x5231000
0339e238: 003841f9 ldr      x0, [x0, #0x270]
0339e23c: 314c7097 bl       #0xfb1300
0339e240: c0f200d0 adrp     x0, #0x51f8000
0339e244: 000847f9 ldr      x0, [x0, #0xe10]
0339e248: 2e4c7097 bl       #0xfb1300
0339e24c: a0f200b0 adrp     x0, #0x51f3000
0339e250: 003045f9 ldr      x0, [x0, #0xa60]
0339e254: 2b4c7097 bl       #0xfb1300
0339e258: 28008052 mov      w8, #1
0339e25c: 88e22639 strb     w8, [x20, #0x9b8]
0339e260: e0031faa mov      x0, xzr
0339e264: 607f2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339e268: 08102c1e fmov     s8, #0.50000000
0339e26c: 0f1ca04e mov      v15.16b, v0.16b
0339e270: 0020281e fcmp     s0, s8
0339e274: 8d040054 b.le     #0x339e304
0339e278: 88f400f0 adrp     x8, #0x5231000
0339e27c: 083941f9 ldr      x8, [x8, #0x270]
0339e280: d5f200d0 adrp     x21, #0x51f8000
0339e284: 21008052 mov      w1, #1
0339e288: 000140f9 ldr      x0, [x8]
0339e28c: b50a47f9 ldr      x21, [x21, #0xe10]
0339e290: 384c7097 bl       #0xfb1370
0339e294: f40300aa mov      x20, x0
0339e298: a00240f9 ldr      x0, [x21]
0339e29c: e1b30091 add      x1, sp, #0x2c
0339e2a0: ef2f00bd str      s15, [sp, #0x2c]
0339e2a4: 5a4c7097 bl       #0xfb140c
0339e2a8: 744300b4 cbz      x20, #0x339eb14
0339e2ac: f50300aa mov      x21, x0
0339e2b0: c00000b4 cbz      x0, #0x339e2c8
0339e2b4: 880240f9 ldr      x8, [x20]
0339e2b8: e00315aa mov      x0, x21
0339e2bc: 012140f9 ldr      x1, [x8, #0x40]
0339e2c0: 524c7097 bl       #0xfb1408
0339e2c4: c04200b4 cbz      x0, #0x339eb1c
0339e2c8: 881a40b9 ldr      w8, [x20, #0x18]
0339e2cc: 68420034 cbz      w8, #0x339eb18
0339e2d0: b6f200b0 adrp     x22, #0x51f3000
0339e2d4: d63245f9 ldr      x22, [x22, #0xa60]
0339e2d8: e00314aa mov      x0, x20
0339e2dc: 150c02f8 str      x21, [x0, #0x20]!
0339e2e0: e10315aa mov      x1, x21
0339e2e4: f24b7097 bl       #0xfb12ac
0339e2e8: c20240f9 ldr      x2, [x22]
0339e2ec: 61018052 mov      w1, #0xb
0339e2f0: e00313aa mov      x0, x19
0339e2f4: e30314aa mov      x3, x20
0339e2f8: e4031faa mov      x4, xzr
0339e2fc: 808bd197 bl       #0x28010fc ; Royal.Infrastructure.Services.Logs.Log$$Error
0339e300: 0f1da84e mov      v15.16b, v8.16b
0339e304: 68f24239 ldrb     w8, [x19, #0xbc]
0339e308: 48010034 cbz      w8, #0x339e330
0339e30c: e00313aa mov      x0, x19
0339e310: c01dae4e mov      v0.16b, v14.16b
0339e314: a11dad4e mov      v1.16b, v13.16b
0339e318: 821dac4e mov      v2.16b, v12.16b
0339e31c: e31daf4e mov      v3.16b, v15.16b
0339e320: e5030094 bl       #0x339f2b4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeSteadyFlightPosition
0339e324: 60000036 tbz      w0, #0, #0x339e330
0339e328: 34008052 mov      w20, #1
0339e32c: 14010014 b        #0x339e77c
0339e330: 681640bd ldr      s8, [x19, #0x14]
0339e334: 692640bd ldr      s9, [x19, #0x24]
0339e338: 40008052 mov      w0, #2
0339e33c: e1031faa mov      x1, xzr
0339e340: 9baefb97 bl       #0x3289dac ; Royal.Infrastructure.Utils.Animation.ManualEasing$$GetEase
0339e344: 803e00b4 cbz      x0, #0x339eb14
0339e348: 082040f9 ldr      x8, [x0, #0x40]
0339e34c: 090c40f9 ldr      x9, [x0, #0x18]
0339e350: 011440f9 ldr      x1, [x0, #0x28]
0339e354: 6a1e40bd ldr      s10, [x19, #0x1c]
0339e358: 6bda40bd ldr      s11, [x19, #0xd8]
0339e35c: 0019291e fdiv     s0, s8, s9
0339e360: 08102e1e fmov     s8, #1.00000000
0339e364: 0058281e fmin     s0, s0, s8
0339e368: e00308aa mov      x0, x8
0339e36c: 20013fd6 blr      x9
0339e370: 0358281e fmin     s3, s0, s8
0339e374: 0820201e fcmp     s0, #0.0
0339e378: e003271e fmov     s0, wzr
0339e37c: 610a452d ldp      s1, s2, [x19, #0x28]
0339e380: 605c201e fcsel    s0, s3, s0, pl
0339e384: 633240bd ldr      s3, [x19, #0x30]
0339e388: 64392a1e fsub     s4, s11, s10
0339e38c: 8008201e fmul     s0, s4, s0
0339e390: 4029201e fadd     s0, s10, s0
0339e394: e0031faa mov      x0, xzr
0339e398: 606e00bd str      s0, [x19, #0x6c]
0339e39c: 759d0594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339e3a0: c41dae4e mov      v4.16b, v14.16b
0339e3a4: a51dad4e mov      v5.16b, v13.16b
0339e3a8: 861dac4e mov      v6.16b, v12.16b
0339e3ac: e0031faa mov      x0, xzr
0339e3b0: 029b0594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339e3b4: d40e0190 adrp     x20, #0x5576000
0339e3b8: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339e3bc: 681240bd ldr      s8, [x19, #0x10]
0339e3c0: 091ca04e mov      v9.16b, v0.16b
0339e3c4: 2a1ca14e mov      v10.16b, v1.16b
0339e3c8: 4b1ca24e mov      v11.16b, v2.16b
0339e3cc: c8000035 cbnz     w8, #0x339e3e4
0339e3d0: 60f400b0 adrp     x0, #0x522b000
0339e3d4: 00ac43f9 ldr      x0, [x0, #0x758]
0339e3d8: ca4b7097 bl       #0xfb1300
0339e3dc: 28008052 mov      w8, #1
0339e3e0: 88b23c39 strb     w8, [x20, #0xf2c]
0339e3e4: 601640bd ldr      s0, [x19, #0x14]
0339e3e8: 612640bd ldr      s1, [x19, #0x24]
0339e3ec: 76f400b0 adrp     x22, #0x522b000
0339e3f0: d6ae43f9 ldr      x22, [x22, #0x758]
0339e3f4: ea27042d stp      s10, s9, [sp, #0x20]
0339e3f8: 0020211e fcmp     s0, s1
0339e3fc: eb1f00bd str      s11, [sp, #0x1c]
0339e400: 8d030054 b.le     #0x339e470
0339e404: 60ea40bd ldr      s0, [x19, #0xe8]
0339e408: 0190241e fmov     s1, #10.00000000
0339e40c: 0849a852 mov      w8, #0x42480000
0339e410: e109211e fmul     s1, s15, s1
0339e414: 2028201e fadd     s0, s1, s0
0339e418: 0101271e fmov     s1, w8
0339e41c: e203271e fmov     s2, wzr
0339e420: 0158211e fmin     s1, s0, s1
0339e424: 0820201e fcmp     s0, #0.0
0339e428: 205c221e fcsel    s0, s1, s2, pl
0339e42c: e109201e fmul     s1, s15, s0
0339e430: ce09211e fmul     s14, s14, s1
0339e434: a309211e fmul     s3, s13, s1
0339e438: 8c09211e fmul     s12, s12, s1
0339e43c: c1092e1e fmul     s1, s14, s14
0339e440: 6208231e fmul     s2, s3, s3
0339e444: 2128221e fadd     s1, s1, s2
0339e448: 82092c1e fmul     s2, s12, s12
0339e44c: 4128211e fadd     s1, s2, s1
0339e450: e22b40bd ldr      s2, [sp, #0x28]
0339e454: 60ea00bd str      s0, [x19, #0xe8]
0339e458: 4208221e fmul     s2, s2, s2
0339e45c: 2020221e fcmp     s1, s2
0339e460: 0d010054 b.le     #0x339e480
0339e464: e333422d ldp      s3, s12, [sp, #0x10]
0339e468: ee0f40bd ldr      s14, [sp, #0xc]
0339e46c: 05000014 b        #0x339e480
0339e470: c80240f9 ldr      x8, [x22]
0339e474: 085d40f9 ldr      x8, [x8, #0xb8]
0339e478: 0e0d402d ldp      s14, s3, [x8]
0339e47c: 0c0940bd ldr      s12, [x8, #8]
0339e480: e31b00bd str      s3, [sp, #0x18]
0339e484: d70e01b0 adrp     x23, #0x5577000
0339e488: 692e482d ldp      s9, s11, [x19, #0x40]
0339e48c: e8fa7f39 ldrb     w8, [x23, #0xffe]
0339e490: 6d4a40bd ldr      s13, [x19, #0x48]
0339e494: c8000035 cbnz     w8, #0x339e4ac
0339e498: 00f300d0 adrp     x0, #0x5200000
0339e49c: 008c46f9 ldr      x0, [x0, #0xd18]
0339e4a0: 984b7097 bl       #0xfb1300
0339e4a4: 28008052 mov      w8, #1
0339e4a8: e8fa3f39 strb     w8, [x23, #0xffe]
0339e4ac: 15f300d0 adrp     x21, #0x5200000
0339e4b0: b58e46f9 ldr      x21, [x21, #0xd18]
0339e4b4: a00240f9 ldr      x0, [x21]
0339e4b8: 08e040b9 ldr      w8, [x0, #0xe0]
0339e4bc: 48000035 cbnz     w8, #0x339e4c4
0339e4c0: d14b7097 bl       #0xfb1404
0339e4c4: a85600b0 adrp     x8, #0x3e73000
0339e4c8: 2009291e fmul     s0, s9, s9
0339e4cc: 61092b1e fmul     s1, s11, s11
0339e4d0: 0a894bbd ldr      s10, [x8, #0xb88]
0339e4d4: 0028211e fadd     s0, s0, s1
0339e4d8: a1092d1e fmul     s1, s13, s13
0339e4dc: 2028201e fadd     s0, s1, s0
0339e4e0: 00c0211e fsqrt    s0, s0
0339e4e4: 00202a1e fcmp     s0, s10
0339e4e8: e809281e fmul     s8, s15, s8
0339e4ec: ad000054 b.le     #0x339e500
0339e4f0: 2f19201e fdiv     s15, s9, s0
0339e4f4: 6919201e fdiv     s9, s11, s0
0339e4f8: ab19201e fdiv     s11, s13, s0
0339e4fc: 0c000014 b        #0x339e52c
0339e500: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339e504: c8000035 cbnz     w8, #0x339e51c
0339e508: 60f400b0 adrp     x0, #0x522b000
0339e50c: 00ac43f9 ldr      x0, [x0, #0x758]
0339e510: 7c4b7097 bl       #0xfb1300
0339e514: 28008052 mov      w8, #1
0339e518: 88b23c39 strb     w8, [x20, #0xf2c]
0339e51c: c80240f9 ldr      x8, [x22]
0339e520: 085d40f9 ldr      x8, [x8, #0xb8]
0339e524: 0f25402d ldp      s15, s9, [x8]
0339e528: 0b0940bd ldr      s11, [x8, #8]
0339e52c: e103442d ldp      s1, s0, [sp, #0x20]
0339e530: e21f40bd ldr      s2, [sp, #0x1c]
0339e534: e8fa7f39 ldrb     w8, [x23, #0xffe]
0339e538: 0008281e fmul     s0, s0, s8
0339e53c: 2d08281e fmul     s13, s1, s8
0339e540: 4808281e fmul     s8, s2, s8
0339e544: 88020035 cbnz     w8, #0x339e594
0339e548: 00f300d0 adrp     x0, #0x5200000
0339e54c: 008c46f9 ldr      x0, [x0, #0xd18]
0339e550: ec2700bd str      s12, [sp, #0x24]
0339e554: cc1dae4e mov      v12.16b, v14.16b
0339e558: 2e1da94e mov      v14.16b, v9.16b
0339e55c: e91daf4e mov      v9.16b, v15.16b
0339e560: 6f1dab4e mov      v15.16b, v11.16b
0339e564: 0b1da84e mov      v11.16b, v8.16b
0339e568: 081ca04e mov      v8.16b, v0.16b
0339e56c: 654b7097 bl       #0xfb1300
0339e570: 001da84e mov      v0.16b, v8.16b
0339e574: 681dab4e mov      v8.16b, v11.16b
0339e578: eb1daf4e mov      v11.16b, v15.16b
0339e57c: 2f1da94e mov      v15.16b, v9.16b
0339e580: c91dae4e mov      v9.16b, v14.16b
0339e584: 8e1dac4e mov      v14.16b, v12.16b
0339e588: ec2740bd ldr      s12, [sp, #0x24]
0339e58c: 28008052 mov      w8, #1
0339e590: e8fa3f39 strb     w8, [x23, #0xffe]
0339e594: a00240f9 ldr      x0, [x21]
0339e598: 0e282e1e fadd     s14, s0, s14
0339e59c: 0c292c1e fadd     s12, s8, s12
0339e5a0: 08e040b9 ldr      w8, [x0, #0xe0]
0339e5a4: e037042d stp      s0, s13, [sp, #0x20]
0339e5a8: e01b40bd ldr      s0, [sp, #0x18]
0339e5ac: ad29201e fadd     s13, s13, s0
0339e5b0: 48000035 cbnz     w8, #0x339e5b8
0339e5b4: 944b7097 bl       #0xfb1404
0339e5b8: c0092e1e fmul     s0, s14, s14
0339e5bc: a1092d1e fmul     s1, s13, s13
0339e5c0: 2028201e fadd     s0, s1, s0
0339e5c4: 81092c1e fmul     s1, s12, s12
0339e5c8: 2028201e fadd     s0, s1, s0
0339e5cc: 00c0211e fsqrt    s0, s0
0339e5d0: 00202a1e fcmp     s0, s10
0339e5d4: cd000054 b.le     #0x339e5ec
0339e5d8: c119201e fdiv     s1, s14, s0
0339e5dc: a219201e fdiv     s2, s13, s0
0339e5e0: 8019201e fdiv     s0, s12, s0
0339e5e4: 0a102c1e fmov     s10, #0.50000000
0339e5e8: 0d000014 b        #0x339e61c
0339e5ec: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339e5f0: 0a102c1e fmov     s10, #0.50000000
0339e5f4: c8000035 cbnz     w8, #0x339e60c
0339e5f8: 60f400b0 adrp     x0, #0x522b000
0339e5fc: 00ac43f9 ldr      x0, [x0, #0x758]
0339e600: 404b7097 bl       #0xfb1300
0339e604: 28008052 mov      w8, #1
0339e608: 88b23c39 strb     w8, [x20, #0xf2c]
0339e60c: c80240f9 ldr      x8, [x22]
0339e610: 085d40f9 ldr      x8, [x8, #0xb8]
0339e614: 0109402d ldp      s1, s2, [x8]
0339e618: 000940bd ldr      s0, [x8, #8]
0339e61c: e32b40bd ldr      s3, [sp, #0x28]
0339e620: 495b00f0 adrp     x9, #0x3f09000
0339e624: 29612291 add      x9, x9, #0x898
0339e628: e109211e fmul     s1, s15, s1
0339e62c: 60202a1e fcmp     s3, s10
0339e630: e8d79f1a cset     w8, gt
0339e634: 235968bc ldr      s3, [x9, w8, uxtw #2]
0339e638: 2209221e fmul     s2, s9, s2
0339e63c: 2128221e fadd     s1, s1, s2
0339e640: 6009201e fmul     s0, s11, s0
0339e644: 0028211e fadd     s0, s0, s1
0339e648: 0020231e fcmp     s0, s3
0339e64c: e5000054 b.pl     #0x339e668
0339e650: 601640bd ldr      s0, [x19, #0x14]
0339e654: 612640bd ldr      s1, [x19, #0x24]
0339e658: 0020211e fcmp     s0, s1
0339e65c: 6d000054 b.le     #0x339e668
0339e660: eeb7412d ldp      s14, s13, [sp, #0xc]
0339e664: ec1740bd ldr      s12, [sp, #0x14]
0339e668: 694240bd ldr      s9, [x19, #0x40]
0339e66c: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339e670: 6a4244fc ldur     d10, [x19, #0x44]
0339e674: c8000035 cbnz     w8, #0x339e68c
0339e678: 60f400b0 adrp     x0, #0x522b000
0339e67c: 00ac43f9 ldr      x0, [x0, #0x758]
0339e680: 204b7097 bl       #0xfb1300
0339e684: 28008052 mov      w8, #1
0339e688: 88b23c39 strb     w8, [x20, #0xf2c]
0339e68c: c80240f9 ldr      x8, [x22]
0339e690: 085d40f9 ldr      x8, [x8, #0xb8]
0339e694: 000140bd ldr      s0, [x8]
0339e698: 014140fc ldur     d1, [x8, #4]
0339e69c: a85600b0 adrp     x8, #0x3e73000
0339e6a0: 02314bbd ldr      s2, [x8, #0xb30]
0339e6a4: 2039201e fsub     s0, s9, s0
0339e6a8: 41d5a10e fsub     v1.2s, v10.2s, v1.2s
0339e6ac: 0008201e fmul     s0, s0, s0
0339e6b0: 21dc212e fmul     v1.2s, v1.2s, v1.2s
0339e6b4: 0028211e fadd     s0, s0, s1
0339e6b8: 21040c5e mov      s1, v1.s[1]
0339e6bc: 2028201e fadd     s0, s1, s0
0339e6c0: 0020221e fcmp     s0, s2
0339e6c4: 84000054 b.mi     #0x339e6d4
0339e6c8: 687e40b9 ldr      w8, [x19, #0x7c]
0339e6cc: 1f090071 cmp      w8, #2
0339e6d0: a1060054 b.ne     #0x339e7a4
0339e6d4: 6e36082d stp      s14, s13, [x19, #0x40]
0339e6d8: 6c4a00bd str      s12, [x19, #0x48]
0339e6dc: 602e40f9 ldr      x0, [x19, #0x58]
0339e6e0: a02100b4 cbz      x0, #0x339eb14
0339e6e4: e1031faa mov      x1, xzr
0339e6e8: 83ad2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339e6ec: 602e40f9 ldr      x0, [x19, #0x58]
0339e6f0: 202100b4 cbz      x0, #0x339eb14
0339e6f4: 091ca04e mov      v9.16b, v0.16b
0339e6f8: 2a1ca14e mov      v10.16b, v1.16b
0339e6fc: 4b1ca24e mov      v11.16b, v2.16b
0339e700: 6006482d ldp      s0, s1, [x19, #0x40]
0339e704: 624a40bd ldr      s2, [x19, #0x48]
0339e708: e1031faa mov      x1, xzr
0339e70c: 2c29201e fadd     s12, s9, s0
0339e710: 4d29211e fadd     s13, s10, s1
0339e714: 6e29221e fadd     s14, s11, s2
0339e718: 801dac4e mov      v0.16b, v12.16b
0339e71c: a11dad4e mov      v1.16b, v13.16b
0339e720: c21dae4e mov      v2.16b, v14.16b
0339e724: 9cad2594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
0339e728: 485600b0 adrp     x8, #0x3e67000
0339e72c: 064944bd ldr      s6, [x8, #0x448]
0339e730: 801dac4e mov      v0.16b, v12.16b
0339e734: a11dad4e mov      v1.16b, v13.16b
0339e738: c21dae4e mov      v2.16b, v14.16b
0339e73c: 231da94e mov      v3.16b, v9.16b
0339e740: 441daa4e mov      v4.16b, v10.16b
0339e744: 651dab4e mov      v5.16b, v11.16b
0339e748: e0031faa mov      x0, xzr
0339e74c: c097fb97 bl       #0x328464c ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339e750: 485600b0 adrp     x8, #0x3e67000
0339e754: 003544bd ldr      s0, [x8, #0x434]
0339e758: e12b40bd ldr      s1, [sp, #0x28]
0339e75c: 14000052 eor      w20, w0, #1
0339e760: 2020201e fcmp     s1, s0
0339e764: cd000054 b.le     #0x339e77c
0339e768: e00313aa mov      x0, x19
0339e76c: 201da94e mov      v0.16b, v9.16b
0339e770: 411daa4e mov      v1.16b, v10.16b
0339e774: 621dab4e mov      v2.16b, v11.16b
0339e778: 57040094 bl       #0x339f8d4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeRotation
0339e77c: 80020012 and      w0, w20, #1
0339e780: f37b49a9 ldp      x19, x30, [sp, #0x90]
0339e784: f55348a9 ldp      x21, x20, [sp, #0x80]
0339e788: f75b47a9 ldp      x23, x22, [sp, #0x70]
0339e78c: e923466d ldp      d9, d8, [sp, #0x60]
0339e790: eb2b456d ldp      d11, d10, [sp, #0x50]
0339e794: ed33446d ldp      d13, d12, [sp, #0x40]
0339e798: ef3b436d ldp      d15, d14, [sp, #0x30]
0339e79c: ff830291 add      sp, sp, #0xa0
0339e7a0: c0035fd6 ret      
0339e7a4: e0031faa mov      x0, xzr
0339e7a8: 20d1ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339e7ac: 611a40bd ldr      s1, [x19, #0x18]
0339e7b0: 485600b0 adrp     x8, #0x3e67000
0339e7b4: 027d44bd ldr      s2, [x8, #0x47c]
0339e7b8: 340f01d0 adrp     x20, #0x5584000
0339e7bc: 0038211e fsub     s0, s0, s1
0339e7c0: 6a2e482d ldp      s10, s11, [x19, #0x40]
0339e7c4: 634a40bd ldr      s3, [x19, #0x48]
0339e7c8: 88fe4f39 ldrb     w8, [x20, #0x3ff]
0339e7cc: 0018221e fdiv     s0, s0, s2
0339e7d0: 01102e1e fmov     s1, #1.00000000
0339e7d4: 221ca14e mov      v2.16b, v1.16b
0339e7d8: 0158211e fmin     s1, s0, s1
0339e7dc: 4138211e fsub     s1, s2, s1
0339e7e0: 0820201e fcmp     s0, #0.0
0339e7e4: 205c221e fcsel    s0, s1, s2, pl
0339e7e8: e01f00bd str      s0, [sp, #0x1c]
0339e7ec: 08010035 cbnz     w8, #0x339e80c
0339e7f0: 00f300d0 adrp     x0, #0x5200000
0339e7f4: 008c46f9 ldr      x0, [x0, #0xd18]
0339e7f8: 691ca34e mov      v9.16b, v3.16b
0339e7fc: c14a7097 bl       #0xfb1300
0339e800: 231da94e mov      v3.16b, v9.16b
0339e804: 28008052 mov      w8, #1
0339e808: 88fe0f39 strb     w8, [x20, #0x3ff]
0339e80c: e007442d ldp      s0, s1, [sp, #0x20]
0339e810: a00240f9 ldr      x0, [x21]
0339e814: 0008201e fmul     s0, s0, s0
0339e818: 2108211e fmul     s1, s1, s1
0339e81c: 0028211e fadd     s0, s0, s1
0339e820: 0109281e fmul     s1, s8, s8
0339e824: 08e040b9 ldr      w8, [x0, #0xe0]
0339e828: 2f28201e fadd     s15, s1, s0
0339e82c: 40092a1e fmul     s0, s10, s10
0339e830: 61092b1e fmul     s1, s11, s11
0339e834: 0028211e fadd     s0, s0, s1
0339e838: 6108231e fmul     s1, s3, s3
0339e83c: 2928201e fadd     s9, s1, s0
0339e840: 88000035 cbnz     w8, #0x339e850
0339e844: e31b00bd str      s3, [sp, #0x18]
0339e848: ef4a7097 bl       #0xfb1404
0339e84c: e31b40bd ldr      s3, [sp, #0x18]
0339e850: a85600b0 adrp     x8, #0x3e73000
0339e854: 008d4bbd ldr      s0, [x8, #0xb8c]
0339e858: e109291e fmul     s1, s15, s9
0339e85c: 21c0211e fsqrt    s1, s1
0339e860: ef03271e fmov     s15, wzr
0339e864: 2020201e fcmp     s1, s0
0339e868: e003271e fmov     s0, wzr
0339e86c: e4020054 b.mi     #0x339e8c8
0339e870: e00b442d ldp      s0, s2, [sp, #0x20]
0339e874: a00240f9 ldr      x0, [x21]
0339e878: 00082a1e fmul     s0, s0, s10
0339e87c: 42082b1e fmul     s2, s2, s11
0339e880: 0028221e fadd     s0, s0, s2
0339e884: 0209231e fmul     s2, s8, s3
0339e888: 4028201e fadd     s0, s2, s0
0339e88c: 08e040b9 ldr      w8, [x0, #0xe0]
0339e890: 0018211e fdiv     s0, s0, s1
0339e894: 01102e1e fmov     s1, #1.00000000
0339e898: 02103e1e fmov     s2, #-1.00000000
0339e89c: 0158211e fmin     s1, s0, s1
0339e8a0: 0020221e fcmp     s0, s2
0339e8a4: 285c221e fcsel    s8, s1, s2, pl
0339e8a8: 48000035 cbnz     w8, #0x339e8b0
0339e8ac: d64a7097 bl       #0xfb1404
0339e8b0: 00c1221e fcvt     d0, s8
0339e8b4: 43916497 bl       #0xcc2dc0
0339e8b8: a85600b0 adrp     x8, #0x3e73000
0339e8bc: 01914bbd ldr      s1, [x8, #0xb90]
0339e8c0: 0040621e fcvt     s0, d0
0339e8c4: 0008211e fmul     s0, s0, s1
0339e8c8: 8856a852 mov      w8, #0x42b40000
0339e8cc: 0101271e fmov     s1, w8
0339e8d0: 485600b0 adrp     x8, #0x3e67000
0339e8d4: e82b40bd ldr      s8, [sp, #0x28]
0339e8d8: 0018211e fdiv     s0, s0, s1
0339e8dc: 013146bd ldr      s1, [x8, #0x630]
0339e8e0: 0210301e fmov     s2, #-2.00000000
0339e8e4: 04102e1e fmov     s4, #1.00000000
0339e8e8: 485600b0 adrp     x8, #0x3e67000
0339e8ec: 0229221e fadd     s2, s8, s2
0339e8f0: 03102c1e fmov     s3, #0.50000000
0339e8f4: 0820201e fcmp     s0, #0.0
0339e8f8: 0058241e fmin     s0, s0, s4
0339e8fc: 4208231e fmul     s2, s2, s3
0339e900: 039544bd ldr      s3, [x8, #0x494]
0339e904: 0008211e fmul     s0, s0, s1
0339e908: 00282f1e fadd     s0, s0, s15
0339e90c: 4458241e fmin     s4, s2, s4
0339e910: 005c2f1e fcsel    s0, s0, s15, pl
0339e914: 4820201e fcmp     s2, #0.0
0339e918: e21f40bd ldr      s2, [sp, #0x1c]
0339e91c: 8108231e fmul     s1, s4, s3
0339e920: 692a482d ldp      s9, s10, [x19, #0x40]
0339e924: 6b4a40bd ldr      s11, [x19, #0x48]
0339e928: 21282f1e fadd     s1, s1, s15
0339e92c: 4008201e fmul     s0, s2, s0
0339e930: 215c2f1e fcsel    s1, s1, s15, pl
0339e934: e0031faa mov      x0, xzr
0339e938: 2f28201e fadd     s15, s1, s0
0339e93c: 74020291 add      x20, x19, #0x80
0339e940: a97d2594 bl       #0x3cfdfe4 ; UnityEngine.Time$$get_deltaTime
0339e944: 08f0af52 mov      w8, #0x7f800000
0339e948: e00300bd str      s0, [sp]
0339e94c: 0701271e fmov     s7, w8
0339e950: 201da94e mov      v0.16b, v9.16b
0339e954: 411daa4e mov      v1.16b, v10.16b
0339e958: 621dab4e mov      v2.16b, v11.16b
0339e95c: c31dae4e mov      v3.16b, v14.16b
0339e960: a41dad4e mov      v4.16b, v13.16b
0339e964: 851dac4e mov      v5.16b, v12.16b
0339e968: e00314aa mov      x0, x20
0339e96c: e61daf4e mov      v6.16b, v15.16b
0339e970: e1031faa mov      x1, xzr
0339e974: 1caa0594 bl       #0x35091e4 ; UnityEngine.Vector3$$SmoothDamp
0339e978: 6006082d stp      s0, s1, [x19, #0x40]
0339e97c: 0010201e fmov     s0, #2.00000000
0339e980: 0021201e fcmp     s8, s0
0339e984: 624a00bd str      s2, [x19, #0x48]
0339e988: a5eaff54 b.pl     #0x339e6dc
0339e98c: 68f24239 ldrb     w8, [x19, #0xbc]
0339e990: a8000034 cbz      w8, #0x339e9a4
0339e994: 601640bd ldr      s0, [x19, #0x14]
0339e998: 612640bd ldr      s1, [x19, #0x24]
0339e99c: 0020211e fcmp     s0, s1
0339e9a0: ede9ff54 b.le     #0x339e6dc
0339e9a4: 687e40b9 ldr      w8, [x19, #0x7c]
0339e9a8: a8e9ff35 cbnz     w8, #0x339e6dc
0339e9ac: 743240f9 ldr      x20, [x19, #0x60]
0339e9b0: 340b00b4 cbz      x20, #0x339eb14
0339e9b4: 8af400b0 adrp     x10, #0x522f000
0339e9b8: 880240f9 ldr      x8, [x20]
0339e9bc: 4a0545f9 ldr      x10, [x10, #0xa08]
0339e9c0: 09554279 ldrh     w9, [x8, #0x12a]
0339e9c4: 410140f9 ldr      x1, [x10]
0339e9c8: 290100b4 cbz      x9, #0x339e9ec
0339e9cc: 0a5940f9 ldr      x10, [x8, #0xb0]
0339e9d0: 4a210091 add      x10, x10, #8
0339e9d4: 4b815ff8 ldur     x11, [x10, #-8]
0339e9d8: 7f0101eb cmp      x11, x1
0339e9dc: 00010054 b.eq     #0x339e9fc
0339e9e0: 290500f1 subs     x9, x9, #1
0339e9e4: 4a410091 add      x10, x10, #0x10
0339e9e8: 61ffff54 b.ne     #0x339e9d4
0339e9ec: 22008052 mov      w2, #1
0339e9f0: e00314aa mov      x0, x20
0339e9f4: 388a6f97 bl       #0xf812d4
0339e9f8: 05000014 b        #0x339ea0c
0339e9fc: 490140b9 ldr      w9, [x10]
0339ea00: 29050011 add      w9, w9, #1
0339ea04: 08d1298b add      x8, x8, w9, sxtw #4
0339ea08: 00e10491 add      x0, x8, #0x138
0339ea0c: 080440a9 ldp      x8, x1, [x0]
0339ea10: e00314aa mov      x0, x20
0339ea14: 00013fd6 blr      x8
0339ea18: 602a40f9 ldr      x0, [x19, #0x50]
0339ea1c: c00700b4 cbz      x0, #0x339eb14
0339ea20: 080040f9 ldr      x8, [x0]
0339ea24: 091ca04e mov      v9.16b, v0.16b
0339ea28: 2a1ca14e mov      v10.16b, v1.16b
0339ea2c: 4b1ca24e mov      v11.16b, v2.16b
0339ea30: 093d42f9 ldr      x9, [x8, #0x478]
0339ea34: 014142f9 ldr      x1, [x8, #0x480]
0339ea38: 20013fd6 blr      x9
0339ea3c: d40e01b0 adrp     x20, #0x5577000
0339ea40: 881a6039 ldrb     w8, [x20, #0x806]
0339ea44: 0c1ca04e mov      v12.16b, v0.16b
0339ea48: 2d1ca14e mov      v13.16b, v1.16b
0339ea4c: 4e1ca24e mov      v14.16b, v2.16b
0339ea50: c8000035 cbnz     w8, #0x339ea68
0339ea54: 00f300d0 adrp     x0, #0x5200000
0339ea58: 008c46f9 ldr      x0, [x0, #0xd18]
0339ea5c: 294a7097 bl       #0xfb1300
0339ea60: 28008052 mov      w8, #1
0339ea64: 881a2039 strb     w8, [x20, #0x806]
0339ea68: a00240f9 ldr      x0, [x21]
0339ea6c: 2c392c1e fsub     s12, s9, s12
0339ea70: 49392d1e fsub     s9, s10, s13
0339ea74: 68392e1e fsub     s8, s11, s14
0339ea78: 08e040b9 ldr      w8, [x0, #0xe0]
0339ea7c: 48000035 cbnz     w8, #0x339ea84
0339ea80: 614a7097 bl       #0xfb1404
0339ea84: 80092c1e fmul     s0, s12, s12
0339ea88: 2109291e fmul     s1, s9, s9
0339ea8c: 602e40f9 ldr      x0, [x19, #0x58]
0339ea90: 0028211e fadd     s0, s0, s1
0339ea94: 0109281e fmul     s1, s8, s8
0339ea98: 2028201e fadd     s0, s1, s0
0339ea9c: 00c0211e fsqrt    s0, s0
0339eaa0: 607600bd str      s0, [x19, #0x74]
0339eaa4: 800300b4 cbz      x0, #0x339eb14
0339eaa8: e1031faa mov      x1, xzr
0339eaac: 36ae2594 bl       #0x3d0a384 ; UnityEngine.Transform$$get_localScale
0339eab0: 682a40f9 ldr      x8, [x19, #0x50]
0339eab4: 607200bd str      s0, [x19, #0x70]
0339eab8: e80200b4 cbz      x8, #0x339eb14
0339eabc: 004140f9 ldr      x0, [x8, #0x80]
0339eac0: a00200b4 cbz      x0, #0x339eb14
0339eac4: e1031faa mov      x1, xzr
0339eac8: b8902594 bl       #0x3d02da8 ; UnityEngine.Component$$get_transform
0339eacc: 400200b4 cbz      x0, #0x339eb14
0339ead0: e1031faa mov      x1, xzr
0339ead4: 88ac2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339ead8: 602e40f9 ldr      x0, [x19, #0x58]
0339eadc: c00100b4 cbz      x0, #0x339eb14
0339eae0: e1031faa mov      x1, xzr
0339eae4: 091ca04e mov      v9.16b, v0.16b
0339eae8: 2a1ca14e mov      v10.16b, v1.16b
0339eaec: 4b1ca24e mov      v11.16b, v2.16b
0339eaf0: 81ac2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339eaf4: 2039201e fsub     s0, s9, s0
0339eaf8: 4139211e fsub     s1, s10, s1
0339eafc: 6239221e fsub     s2, s11, s2
0339eb00: 48008052 mov      w8, #2
0339eb04: 6086062d stp      s0, s1, [x19, #0x34]
0339eb08: 623e00bd str      s2, [x19, #0x3c]
0339eb0c: 687e00b9 str      w8, [x19, #0x7c]
0339eb10: f3feff17 b        #0x339e6dc
0339eb14: 454a7097 bl       #0xfb1428
0339eb18: 464a7097 bl       #0xfb1430
0339eb1c: 4c4a7097 bl       #0xfb144c
0339eb20: e1031faa mov      x1, xzr
0339eb24: 334a7097 bl       #0xfb13f0
