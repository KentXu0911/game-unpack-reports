# Royal.Scenes.Game.Mechanics.Items.GrassBombItem.GrassBombItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
026e5aec: f40f1ef8 str      x20, [sp, #-0x20]!
026e5af0: f37b01a9 stp      x19, x30, [sp, #0x10]
026e5af4: 080040f9 ldr      x8, [x0]
026e5af8: f403012a mov      w20, w1
026e5afc: f30300aa mov      x19, x0
026e5b00: 096542f9 ldr      x9, [x8, #0x4c8]
026e5b04: 086942f9 ldr      x8, [x8, #0x4d0]
026e5b08: e10308aa mov      x1, x8
026e5b0c: 20013fd6 blr      x9
026e5b10: 1f040071 cmp      w0, #1
026e5b14: eb000054 b.lt     #0x26e5b30
026e5b18: e00313aa mov      x0, x19
026e5b1c: f37b41a9 ldp      x19, x30, [sp, #0x10]
026e5b20: e103142a mov      w1, w20
026e5b24: e2031faa mov      x2, xzr
026e5b28: f40742f8 ldr      x20, [sp], #0x20
026e5b2c: 59b03214 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
026e5b30: f37b41a9 ldp      x19, x30, [sp, #0x10]
026e5b34: e0031f2a mov      w0, wzr
026e5b38: f40742f8 ldr      x20, [sp], #0x20
026e5b3c: c0035fd6 ret      
