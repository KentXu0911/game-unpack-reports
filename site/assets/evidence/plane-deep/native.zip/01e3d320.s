# Royal.Scenes.Game.Mechanics.Items.PotionTubeItem.PotionTubeItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01e3d320: f40f1ef8 str      x20, [sp, #-0x20]!
01e3d324: f37b01a9 stp      x19, x30, [sp, #0x10]
01e3d328: 080040f9 ldr      x8, [x0]
01e3d32c: f30300aa mov      x19, x0
01e3d330: 096542f9 ldr      x9, [x8, #0x4c8]
01e3d334: 016942f9 ldr      x1, [x8, #0x4d0]
01e3d338: 20013fd6 blr      x9
01e3d33c: 680240f9 ldr      x8, [x19]
01e3d340: 1f040071 cmp      w0, #1
01e3d344: e00313aa mov      x0, x19
01e3d348: 09bd41f9 ldr      x9, [x8, #0x378]
01e3d34c: 01c141f9 ldr      x1, [x8, #0x380]
01e3d350: a8608a52 mov      w8, #0x5305
01e3d354: 4800a072 movk     w8, #2, lsl #16
01e3d358: 14019f1a csel     w20, w8, wzr, eq
01e3d35c: 20013fd6 blr      x9
01e3d360: e1031faa mov      x1, xzr
01e3d364: 891d5594 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01e3d368: f37b41a9 ldp      x19, x30, [sp, #0x10]
01e3d36c: 0000140b add      w0, w0, w20
01e3d370: f40742f8 ldr      x20, [sp], #0x20
01e3d374: c0035fd6 ret      
