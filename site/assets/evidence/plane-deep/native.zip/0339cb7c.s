# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$CalculateAngleSmoothCoefficient
# Linear span to next metadata entry; not a complete CFG.
0339cb7c: e80f1efc str      d8, [sp, #-0x20]!
0339cb80: f40700f9 str      x20, [sp, #8]
0339cb84: f37b01a9 stp      x19, x30, [sp, #0x10]
0339cb88: 14684339 ldrb     w20, [x0, #0xda]
0339cb8c: f30300aa mov      x19, x0
0339cb90: e0031faa mov      x0, xzr
0339cb94: 25d8ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339cb98: 54010034 cbz      w20, #0x339cbc0
0339cb9c: 61ba40bd ldr      s1, [x19, #0xb8]
0339cba0: e0031faa mov      x0, xzr
0339cba4: 0838211e fsub     s8, s0, s1
0339cba8: 20d8ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339cbac: 612640bd ldr      s1, [x19, #0x24]
0339cbb0: 0038211e fsub     s0, s0, s1
0339cbb4: 0021201e fcmp     s8, s0
0339cbb8: 004d201e fcsel    s0, s8, s0, mi
0339cbbc: 03000014 b        #0x339cbc8
0339cbc0: 612640bd ldr      s1, [x19, #0x24]
0339cbc4: 0038211e fsub     s0, s0, s1
0339cbc8: 485600f0 adrp     x8, #0x3e67000
0339cbcc: 017d44bd ldr      s1, [x8, #0x47c]
0339cbd0: 02102e1e fmov     s2, #1.00000000
0339cbd4: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339cbd8: f40740f9 ldr      x20, [sp, #8]
0339cbdc: 0018211e fdiv     s0, s0, s1
0339cbe0: 0158221e fmin     s1, s0, s2
0339cbe4: 4138211e fsub     s1, s2, s1
0339cbe8: 0820201e fcmp     s0, #0.0
0339cbec: 205c221e fcsel    s0, s1, s2, pl
0339cbf0: e80742fc ldr      d8, [sp], #0x20
0339cbf4: c0035fd6 ret      
