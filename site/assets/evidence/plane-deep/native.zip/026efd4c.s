# Royal.Scenes.Game.Mechanics.Items.SapphireItem.SapphireItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
026efd4c: f60f1df8 str      x22, [sp, #-0x30]!
026efd50: f55301a9 stp      x21, x20, [sp, #0x10]
026efd54: f37b02a9 stp      x19, x30, [sp, #0x20]
026efd58: 08344539 ldrb     w8, [x0, #0x14d]
026efd5c: 68000034 cbz      w8, #0x26efd68
026efd60: f3031f2a mov      w19, wzr
026efd64: 20000014 b        #0x26efde4
026efd68: f50300aa mov      x21, x0
026efd6c: f403012a mov      w20, w1
026efd70: e003012a mov      w0, w1
026efd74: e1031faa mov      x1, xzr
026efd78: 0d533294 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
026efd7c: 80000036 tbz      w0, #0, #0x26efd8c
026efd80: 13918f52 mov      w19, #0x7c88
026efd84: 7300a072 movk     w19, #3, lsl #16
026efd88: 17000014 b        #0x26efde4
026efd8c: a03e40f9 ldr      x0, [x21, #0x78]
026efd90: 400300b4 cbz      x0, #0x26efdf8
026efd94: b66a40b9 ldr      w22, [x21, #0x68]
026efd98: 13229f52 mov      w19, #0xf910
026efd9c: e1031faa mov      x1, xzr
026efda0: d300a072 movk     w19, #6, lsl #16
026efda4: c3291994 bl       #0x2d3a4b0 ; Royal.Scenes.Game.Mechanics.Explode.IncomingExploderContainer$$GetIncomingCount
026efda8: c802004b sub      w8, w22, w0
026efdac: 1f050071 cmp      w8, #1
026efdb0: a1010054 b.ne     #0x26efde4
026efdb4: b5324539 ldrb     w21, [x21, #0x14c]
026efdb8: e003142a mov      w0, w20
026efdbc: e1031faa mov      x1, xzr
026efdc0: df523294 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026efdc4: 08279252 mov      w8, #0x9138
026efdc8: e9439e52 mov      w9, #0xf21f
026efdcc: bf020071 cmp      w21, #0
026efdd0: 2803a072 movk     w8, #0x19, lsl #16
026efdd4: a901a072 movk     w9, #0xd, lsl #16
026efdd8: 2801881a csel     w8, w9, w8, eq
026efddc: 1f000072 tst      w0, #1
026efde0: 1311931a csel     w19, w8, w19, ne
026efde4: e003132a mov      w0, w19
026efde8: f37b42a9 ldp      x19, x30, [sp, #0x20]
026efdec: f55341a9 ldp      x21, x20, [sp, #0x10]
026efdf0: f60743f8 ldr      x22, [sp], #0x30
026efdf4: c0035fd6 ret      
026efdf8: 8c05a397 bl       #0xfb1428
