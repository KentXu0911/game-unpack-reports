# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_MaxOutSpeedConst
# Linear span to next metadata entry; not a complete CFG.
0339b584: 68560090 adrp     x8, #0x3e67000
0339b588: 004144bd ldr      s0, [x8, #0x440]
0339b58c: c0035fd6 ret      
