# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$BeginProfile
# Linear span to next metadata entry; not a complete CFG.
020ef5bc: c0035fd6 ret      
