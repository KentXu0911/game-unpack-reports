# Royal.Scenes.Game.Mechanics.Items.RoofMachineItem.RoofMachineItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01ed5c28: f40f1ef8 str      x20, [sp, #-0x20]!
01ed5c2c: f37b01a9 stp      x19, x30, [sp, #0x10]
01ed5c30: 080040f9 ldr      x8, [x0]
01ed5c34: f403012a mov      w20, w1
01ed5c38: f30300aa mov      x19, x0
01ed5c3c: 096542f9 ldr      x9, [x8, #0x4c8]
01ed5c40: 086942f9 ldr      x8, [x8, #0x4d0]
01ed5c44: e10308aa mov      x1, x8
01ed5c48: 20013fd6 blr      x9
01ed5c4c: e0000034 cbz      w0, #0x1ed5c68
01ed5c50: e00313aa mov      x0, x19
01ed5c54: f37b41a9 ldp      x19, x30, [sp, #0x10]
01ed5c58: e103142a mov      w1, w20
01ed5c5c: e2031faa mov      x2, xzr
01ed5c60: f40742f8 ldr      x20, [sp], #0x20
01ed5c64: 42bb5214 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
01ed5c68: f37b41a9 ldp      x19, x30, [sp, #0x10]
01ed5c6c: f40742f8 ldr      x20, [sp], #0x20
01ed5c70: c0035fd6 ret      
