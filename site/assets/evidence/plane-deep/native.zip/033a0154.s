# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$Move
# Linear span to next metadata entry; not a complete CFG.
033a0154: e923bd6d stp      d9, d8, [sp, #-0x30]!
033a0158: f40b00f9 str      x20, [sp, #0x10]
033a015c: f37b02a9 stp      x19, x30, [sp, #0x20]
033a0160: 340f01d0 adrp     x20, #0x5586000
033a0164: 88fa6639 ldrb     w8, [x20, #0x9be]
033a0168: f30300aa mov      x19, x0
033a016c: c8000037 tbnz     w8, #0, #0x33a0184
033a0170: 60f400f0 adrp     x0, #0x522f000
033a0174: 000445f9 ldr      x0, [x0, #0xa08]
033a0178: 62447097 bl       #0xfb1300
033a017c: 28008052 mov      w8, #1
033a0180: 88fa2639 strb     w8, [x20, #0x9be]
033a0184: 747e40b9 ldr      w20, [x19, #0x7c]
033a0188: e0031faa mov      x0, xzr
033a018c: 77cace97 bl       #0x2752b68 ; Royal.Scenes.Game.Levels.LevelContext$$get_FrameCount
033a0190: 9f02006b cmp      w20, w0
033a0194: 20080054 b.eq     #0x33a0298
033a0198: e0031faa mov      x0, xzr
033a019c: 73cace97 bl       #0x2752b68 ; Royal.Scenes.Game.Levels.LevelContext$$get_FrameCount
033a01a0: 681e40bd ldr      s8, [x19, #0x1c]
033a01a4: 607e00b9 str      w0, [x19, #0x7c]
033a01a8: e0031faa mov      x0, xzr
033a01ac: 09c1ce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
033a01b0: 692240bd ldr      s9, [x19, #0x20]
033a01b4: 0029201e fadd     s0, s8, s0
033a01b8: e0031faa mov      x0, xzr
033a01bc: 601e00bd str      s0, [x19, #0x1c]
033a01c0: 04c1ce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
033a01c4: 743240f9 ldr      x20, [x19, #0x60]
033a01c8: 2029201e fadd     s0, s9, s0
033a01cc: 602200bd str      s0, [x19, #0x20]
033a01d0: d40600b4 cbz      x20, #0x33a02a8
033a01d4: 6af400f0 adrp     x10, #0x522f000
033a01d8: 880240f9 ldr      x8, [x20]
033a01dc: 4a0545f9 ldr      x10, [x10, #0xa08]
033a01e0: 09554279 ldrh     w9, [x8, #0x12a]
033a01e4: 410140f9 ldr      x1, [x10]
033a01e8: 290100b4 cbz      x9, #0x33a020c
033a01ec: 0a5940f9 ldr      x10, [x8, #0xb0]
033a01f0: 4a210091 add      x10, x10, #8
033a01f4: 4b815ff8 ldur     x11, [x10, #-8]
033a01f8: 7f0101eb cmp      x11, x1
033a01fc: 00010054 b.eq     #0x33a021c
033a0200: 290500f1 subs     x9, x9, #1
033a0204: 4a410091 add      x10, x10, #0x10
033a0208: 61ffff54 b.ne     #0x33a01f4
033a020c: e00314aa mov      x0, x20
033a0210: e2031f2a mov      w2, wzr
033a0214: 30846f97 bl       #0xf812d4
033a0218: 04000014 b        #0x33a0228
033a021c: 490180b9 ldrsw    x9, [x10]
033a0220: 0811098b add      x8, x8, x9, lsl #4
033a0224: 00e10491 add      x0, x8, #0x138
033a0228: 080440a9 ldp      x8, x1, [x0]
033a022c: e00314aa mov      x0, x20
033a0230: 00013fd6 blr      x8
033a0234: 20030036 tbz      w0, #0, #0x33a0298
033a0238: 885600f0 adrp     x8, #0x3e73000
033a023c: 602240bd ldr      s0, [x19, #0x20]
033a0240: 011148bd ldr      s1, [x8, #0x810]
033a0244: 0020211e fcmp     s0, s1
033a0248: 8b010054 b.lt     #0x33a0278
033a024c: 605640f9 ldr      x0, [x19, #0xa8]
033a0250: c00200b4 cbz      x0, #0x33a02a8
033a0254: 285600f0 adrp     x8, #0x3e67000
033a0258: 004144bd ldr      s0, [x8, #0x440]
033a025c: e103271e fmov     s1, wzr
033a0260: 61038052 mov      w1, #0x1b
033a0264: 42008052 mov      w2, #2
033a0268: e3031f2a mov      w3, wzr
033a026c: e4031faa mov      x4, xzr
033a0270: ee820394 bl       #0x3480e28 ; Royal.Scenes.Start.Context.Units.Haptic.HapticManager$$PlayHaptic
033a0274: 7f2200b9 str      wzr, [x19, #0x20]
033a0278: 680240f9 ldr      x8, [x19]
033a027c: e00313aa mov      x0, x19
033a0280: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a0284: f40b40f9 ldr      x20, [sp, #0x10]
033a0288: 020d41f9 ldr      x2, [x8, #0x218]
033a028c: 011141f9 ldr      x1, [x8, #0x220]
033a0290: e923c36c ldp      d9, d8, [sp], #0x30
033a0294: 40001fd6 br       x2
033a0298: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a029c: f40b40f9 ldr      x20, [sp, #0x10]
033a02a0: e923c36c ldp      d9, d8, [sp], #0x30
033a02a4: c0035fd6 ret      
033a02a8: 60447097 bl       #0xfb1428
