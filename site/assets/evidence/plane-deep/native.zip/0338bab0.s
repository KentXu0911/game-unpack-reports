# Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$CellsFreedAfterExplode
# Linear span to next metadata entry; not a complete CFG.
0338bab0: 1f780071 cmp      w0, #0x1e
0338bab4: 2c010054 b.gt     #0x338bad8
0338bab8: 1f380071 cmp      w0, #0xe
0338babc: ec010054 b.gt     #0x338baf8
0338bac0: 08200051 sub      w8, w0, #8
0338bac4: 1f1d0071 cmp      w8, #7
0338bac8: 02040054 b.hs     #0x338bb48
0338bacc: e95b00d0 adrp     x9, #0x3f09000
0338bad0: 29611b91 add      x9, x9, #0x6d8
0338bad4: 14000014 b        #0x338bb24
0338bad8: 1f2c0171 cmp      w0, #0x4b
0338badc: ac010054 b.gt     #0x338bb10
0338bae0: 089c0051 sub      w8, w0, #0x27
0338bae4: 1f950071 cmp      w8, #0x25
0338bae8: 02030054 b.hs     #0x338bb48
0338baec: e95b00d0 adrp     x9, #0x3f09000
0338baf0: 29411c91 add      x9, x9, #0x710
0338baf4: 0c000014 b        #0x338bb24
0338baf8: 08600051 sub      w8, w0, #0x18
0338bafc: 1f1d0071 cmp      w8, #7
0338bb00: 42020054 b.hs     #0x338bb48
0338bb04: e95b00d0 adrp     x9, #0x3f09000
0338bb08: 29d11b91 add      x9, x9, #0x6f4
0338bb0c: 06000014 b        #0x338bb24
0338bb10: 08600151 sub      w8, w0, #0x58
0338bb14: 1f490071 cmp      w8, #0x12
0338bb18: a2000054 b.hs     #0x338bb2c
0338bb1c: e95b00d0 adrp     x9, #0x3f09000
0338bb20: 29911e91 add      x9, x9, #0x7a4
0338bb24: 20d968b8 ldr      w0, [x9, w8, sxtw #2]
0338bb28: c0035fd6 ret      
0338bb2c: 08bc0151 sub      w8, w0, #0x6f
0338bb30: 1f090071 cmp      w8, #2
0338bb34: e3000054 b.lo     #0x338bb50
0338bb38: 1fcc0171 cmp      w0, #0x73
0338bb3c: 61000054 b.ne     #0x338bb48
0338bb40: 40008052 mov      w0, #2
0338bb44: c0035fd6 ret      
0338bb48: 20008052 mov      w0, #1
0338bb4c: c0035fd6 ret      
0338bb50: 80008052 mov      w0, #4
0338bb54: c0035fd6 ret      
