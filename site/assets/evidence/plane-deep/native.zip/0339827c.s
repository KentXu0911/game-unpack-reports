# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$FallStarted
# Linear span to next metadata entry; not a complete CFG.
0339827c: ff0302d1 sub      sp, sp, #0x80
03398280: f43300f9 str      x20, [sp, #0x60]
03398284: f37b07a9 stp      x19, x30, [sp, #0x70]
03398288: 00e4006f movi     v0.2d, #0000000000000000
0339828c: e1031faa mov      x1, xzr
03398290: f30300aa mov      x19, x0
03398294: ff5300b9 str      wzr, [sp, #0x50]
03398298: e08301ad stp      q0, q0, [sp, #0x30]
0339829c: 65e1ff97 bl       #0x3390830 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemView$$FallStarted
033982a0: 603e40f9 ldr      x0, [x19, #0x78]
033982a4: 400800b4 cbz      x0, #0x33983ac
033982a8: e8230091 add      x8, sp, #8
033982ac: e1031f2a mov      w1, wzr
033982b0: e2031faa mov      x2, xzr
033982b4: 1ec9a897 bl       #0x1dca72c ; UnityEngine.Animator$$GetCurrentAnimatorStateInfo
033982b8: e083c03c ldur     q0, [sp, #8]
033982bc: e183c13c ldur     q1, [sp, #0x18]
033982c0: e82b40b9 ldr      w8, [sp, #0x28]
033982c4: e0c30091 add      x0, sp, #0x30
033982c8: e1031faa mov      x1, xzr
033982cc: e08701ad stp      q0, q1, [sp, #0x30]
033982d0: e85300b9 str      w8, [sp, #0x50]
033982d4: 55c7a897 bl       #0x1dca028 ; UnityEngine.AnimatorStateInfo$$get_fullPathHash
033982d8: 680240f9 ldr      x8, [x19]
033982dc: f403002a mov      w20, w0
033982e0: e00313aa mov      x0, x19
033982e4: 09f541f9 ldr      x9, [x8, #0x3e8]
033982e8: 01f941f9 ldr      x1, [x8, #0x3f0]
033982ec: 20013fd6 blr      x9
033982f0: 9f02006b cmp      w20, w0
033982f4: e1000054 b.ne     #0x3398310
033982f8: e0c30091 add      x0, sp, #0x30
033982fc: e1031faa mov      x1, xzr
03398300: 4ec7a897 bl       #0x1dca038 ; UnityEngine.AnimatorStateInfo$$get_normalizedTime
03398304: 01102e1e fmov     s1, #1.00000000
03398308: 0020211e fcmp     s0, s1
0339830c: ea020054 b.ge     #0x3398368
03398310: e0c30091 add      x0, sp, #0x30
03398314: e1031faa mov      x1, xzr
03398318: 44c7a897 bl       #0x1dca028 ; UnityEngine.AnimatorStateInfo$$get_fullPathHash
0339831c: 680240f9 ldr      x8, [x19]
03398320: f403002a mov      w20, w0
03398324: e00313aa mov      x0, x19
03398328: 094d42f9 ldr      x9, [x8, #0x498]
0339832c: 015142f9 ldr      x1, [x8, #0x4a0]
03398330: 20013fd6 blr      x9
03398334: 9f02006b cmp      w20, w0
03398338: 80010054 b.eq     #0x3398368
0339833c: e0c30091 add      x0, sp, #0x30
03398340: e1031faa mov      x1, xzr
03398344: 39c7a897 bl       #0x1dca028 ; UnityEngine.AnimatorStateInfo$$get_fullPathHash
03398348: 680240f9 ldr      x8, [x19]
0339834c: f403002a mov      w20, w0
03398350: e00313aa mov      x0, x19
03398354: 095542f9 ldr      x9, [x8, #0x4a8]
03398358: 015942f9 ldr      x1, [x8, #0x4b0]
0339835c: 20013fd6 blr      x9
03398360: 9f02006b cmp      w20, w0
03398364: c1010054 b.ne     #0x339839c
03398368: 680240f9 ldr      x8, [x19]
0339836c: 743e40f9 ldr      x20, [x19, #0x78]
03398370: e00313aa mov      x0, x19
03398374: 094542f9 ldr      x9, [x8, #0x488]
03398378: 014942f9 ldr      x1, [x8, #0x490]
0339837c: 20013fd6 blr      x9
03398380: 740100b4 cbz      x20, #0x33983ac
03398384: e103002a mov      w1, w0
03398388: e003271e fmov     s0, wzr
0339838c: e00314aa mov      x0, x20
03398390: e2031f2a mov      w2, wzr
03398394: e3031faa mov      x3, xzr
03398398: 66cba897 bl       #0x1dcb130 ; UnityEngine.Animator$$Play
0339839c: f37b47a9 ldp      x19, x30, [sp, #0x70]
033983a0: f43340f9 ldr      x20, [sp, #0x60]
033983a4: ff030291 add      sp, sp, #0x80
033983a8: c0035fd6 ret      
033983ac: 1f647097 bl       #0xfb1428
