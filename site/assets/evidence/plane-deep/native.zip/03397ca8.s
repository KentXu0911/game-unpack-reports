# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerCreationSfx
# Linear span to next metadata entry; not a complete CFG.
03397ca8: fe0f1ff8 str      x30, [sp, #-0x10]!
03397cac: 081440f9 ldr      x8, [x0, #0x28]
03397cb0: c80000b4 cbz      x8, #0x3397cc8
03397cb4: 091940b9 ldr      w9, [x8, #0x18]
03397cb8: a9000034 cbz      w9, #0x3397ccc
03397cbc: 001140f9 ldr      x0, [x8, #0x20]
03397cc0: fe0741f8 ldr      x30, [sp], #0x10
03397cc4: c0035fd6 ret      
03397cc8: d8657097 bl       #0xfb1428
03397ccc: d9657097 bl       #0xfb1430
