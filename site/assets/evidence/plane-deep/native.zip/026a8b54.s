# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$IsCellWinningForSingleHitAreaExploder
# Linear span to next metadata entry; not a complete CFG.
026a8b54: ff4302d1 sub      sp, sp, #0x90
026a8b58: f63300f9 str      x22, [sp, #0x60]
026a8b5c: f55307a9 stp      x21, x20, [sp, #0x70]
026a8b60: f37b08a9 stp      x19, x30, [sp, #0x80]
026a8b64: f30300aa mov      x19, x0
026a8b68: 001040f9 ldr      x0, [x0, #0x20]
026a8b6c: e00800b4 cbz      x0, #0x26a8c88
026a8b70: f50301aa mov      x21, x1
026a8b74: e1031faa mov      x1, xzr
026a8b78: f40302aa mov      x20, x2
026a8b7c: e6180e94 bl       #0x2a2ef14 ; Royal.Scenes.Game.Levels.Units.GoalManager$$HasAnyPrerequisite
026a8b80: 80040037 tbnz     w0, #0, #0x26a8c10
026a8b84: 767601d0 adrp     x22, #0x5576000
026a8b88: c8ae7c39 ldrb     w8, [x22, #0xf2b]
026a8b8c: c8000035 cbnz     w8, #0x26a8ba4
026a8b90: 005b0190 adrp     x0, #0x5208000
026a8b94: 00c041f9 ldr      x0, [x0, #0x380]
026a8b98: da21a497 bl       #0xfb1300
026a8b9c: 28008052 mov      w8, #1
026a8ba0: c8ae3c39 strb     w8, [x22, #0xf2b]
026a8ba4: 085b0190 adrp     x8, #0x5208000
026a8ba8: 08c141f9 ldr      x8, [x8, #0x380]
026a8bac: 080140f9 ldr      x8, [x8]
026a8bb0: 085d40f9 ldr      x8, [x8, #0xb8]
026a8bb4: 080140f9 ldr      x8, [x8]
026a8bb8: 880600b4 cbz      x8, #0x26a8c88
026a8bbc: 081d40f9 ldr      x8, [x8, #0x38]
026a8bc0: 480600b4 cbz      x8, #0x26a8c88
026a8bc4: 080d40f9 ldr      x8, [x8, #0x18]
026a8bc8: 080600b4 cbz      x8, #0x26a8c88
026a8bcc: 08a14039 ldrb     w8, [x8, #0x28]
026a8bd0: 08020035 cbnz     w8, #0x26a8c10
026a8bd4: a81a40f9 ldr      x8, [x21, #0x30]
026a8bd8: a18240ad ldp      q1, q0, [x21, #0x10]
026a8bdc: a202c03d ldr      q2, [x21]
026a8be0: e1830091 add      x1, sp, #0x20
026a8be4: e82b00f9 str      x8, [sp, #0x50]
026a8be8: e18301ad stp      q1, q0, [sp, #0x30]
026a8bec: e20b803d str      q2, [sp, #0x20]
026a8bf0: 880a40f9 ldr      x8, [x20, #0x10]
026a8bf4: 8002c03d ldr      q0, [x20]
026a8bf8: e2030091 mov      x2, sp
026a8bfc: e00313aa mov      x0, x19
026a8c00: e80b00f9 str      x8, [sp, #0x10]
026a8c04: e003803d str      q0, [sp]
026a8c08: 21000094 bl       #0x26a8c8c ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinConditionForSingleHitAreaExploder
026a8c0c: 00010036 tbz      w0, #0, #0x26a8c2c
026a8c10: e0031f2a mov      w0, wzr
026a8c14: f37b48a9 ldp      x19, x30, [sp, #0x80]
026a8c18: f55347a9 ldp      x21, x20, [sp, #0x70]
026a8c1c: f63340f9 ldr      x22, [sp, #0x60]
026a8c20: 00000012 and      w0, w0, #1
026a8c24: ff430291 add      sp, sp, #0x90
026a8c28: c0035fd6 ret      
026a8c2c: e00313aa mov      x0, x19
026a8c30: 75fbff97 bl       #0x26a7a04 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ClearGoalData
026a8c34: a80a40b9 ldr      w8, [x21, #8]
026a8c38: e00314aa mov      x0, x20
026a8c3c: e1031faa mov      x1, xzr
026a8c40: 681200b9 str      w8, [x19, #0x10]
026a8c44: a8524039 ldrb     w8, [x21, #0x14]
026a8c48: 08010012 and      w8, w8, #1
026a8c4c: 68520039 strb     w8, [x19, #0x14]
026a8c50: 8a7e1094 bl       #0x2ac8678 ; Royal.Scenes.Game.Mechanics.Board.Grid.Iterator.GridIterator$$Reset
026a8c54: e00314aa mov      x0, x20
026a8c58: e1031faa mov      x1, xzr
026a8c5c: 717e1094 bl       #0x2ac8620 ; Royal.Scenes.Game.Mechanics.Board.Grid.Iterator.GridIterator$$MoveNext
026a8c60: e00000b4 cbz      x0, #0x26a8c7c
026a8c64: 800a40f9 ldr      x0, [x20, #0x10]
026a8c68: 60ffffb4 cbz      x0, #0x26a8c54
026a8c6c: e10313aa mov      x1, x19
026a8c70: e2031faa mov      x2, xzr
026a8c74: bf871094 bl       #0x2acab70 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$CalculateGoalDecrementByPropellerHit
026a8c78: f7ffff17 b        #0x26a8c54
026a8c7c: e00313aa mov      x0, x19
026a8c80: 3afdff97 bl       #0x26a8168 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$IsWinningByHitCells
026a8c84: e4ffff17 b        #0x26a8c14
026a8c88: e821a497 bl       #0xfb1428
