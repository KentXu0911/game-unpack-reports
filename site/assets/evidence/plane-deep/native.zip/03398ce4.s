# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$Move
# Linear span to next metadata entry; not a complete CFG.
03398ce4: e80f1efc str      d8, [sp, #-0x20]!
03398ce8: f40700f9 str      x20, [sp, #8]
03398cec: f37b01a9 stp      x19, x30, [sp, #0x10]
03398cf0: 740f01d0 adrp     x20, #0x5586000
03398cf4: 887a6639 ldrb     w8, [x20, #0x99e]
03398cf8: f30300aa mov      x19, x0
03398cfc: c8000037 tbnz     w8, #0, #0x3398d14
03398d00: a0f400f0 adrp     x0, #0x522f000
03398d04: 000445f9 ldr      x0, [x0, #0xa08]
03398d08: 7e617097 bl       #0xfb1300
03398d0c: 28008052 mov      w8, #1
03398d10: 887a2639 strb     w8, [x20, #0x99e]
03398d14: 749240b9 ldr      w20, [x19, #0x90]
03398d18: e0031faa mov      x0, xzr
03398d1c: 93e7ce97 bl       #0x2752b68 ; Royal.Scenes.Game.Levels.LevelContext$$get_FrameCount
03398d20: 9f02006b cmp      w20, w0
03398d24: 80050054 b.eq     #0x3398dd4
03398d28: e0031faa mov      x0, xzr
03398d2c: 8fe7ce97 bl       #0x2752b68 ; Royal.Scenes.Game.Levels.LevelContext$$get_FrameCount
03398d30: 682240bd ldr      s8, [x19, #0x20]
03398d34: 609200b9 str      w0, [x19, #0x90]
03398d38: e0031faa mov      x0, xzr
03398d3c: 25dece97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
03398d40: 743a40f9 ldr      x20, [x19, #0x70]
03398d44: 0029201e fadd     s0, s8, s0
03398d48: 602200bd str      s0, [x19, #0x20]
03398d4c: d40400b4 cbz      x20, #0x3398de4
03398d50: aaf400f0 adrp     x10, #0x522f000
03398d54: 880240f9 ldr      x8, [x20]
03398d58: 4a0545f9 ldr      x10, [x10, #0xa08]
03398d5c: 09554279 ldrh     w9, [x8, #0x12a]
03398d60: 410140f9 ldr      x1, [x10]
03398d64: 290100b4 cbz      x9, #0x3398d88
03398d68: 0a5940f9 ldr      x10, [x8, #0xb0]
03398d6c: 4a210091 add      x10, x10, #8
03398d70: 4b815ff8 ldur     x11, [x10, #-8]
03398d74: 7f0101eb cmp      x11, x1
03398d78: 00010054 b.eq     #0x3398d98
03398d7c: 290500f1 subs     x9, x9, #1
03398d80: 4a410091 add      x10, x10, #0x10
03398d84: 61ffff54 b.ne     #0x3398d70
03398d88: e00314aa mov      x0, x20
03398d8c: e2031f2a mov      w2, wzr
03398d90: 51a16f97 bl       #0xf812d4
03398d94: 04000014 b        #0x3398da4
03398d98: 490180b9 ldrsw    x9, [x10]
03398d9c: 0811098b add      x8, x8, x9, lsl #4
03398da0: 00e10491 add      x0, x8, #0x138
03398da4: 080440a9 ldp      x8, x1, [x0]
03398da8: e00314aa mov      x0, x20
03398dac: 00013fd6 blr      x8
03398db0: 20010036 tbz      w0, #0, #0x3398dd4
03398db4: 680240f9 ldr      x8, [x19]
03398db8: e00313aa mov      x0, x19
03398dbc: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398dc0: f40740f9 ldr      x20, [sp, #8]
03398dc4: 024541f9 ldr      x2, [x8, #0x288]
03398dc8: 014941f9 ldr      x1, [x8, #0x290]
03398dcc: e80742fc ldr      d8, [sp], #0x20
03398dd0: 40001fd6 br       x2
03398dd4: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398dd8: f40740f9 ldr      x20, [sp, #8]
03398ddc: e80742fc ldr      d8, [sp], #0x20
03398de0: c0035fd6 ret      
03398de4: 91617097 bl       #0xfb1428
