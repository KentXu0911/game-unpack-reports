# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy$$ExplodeWithDelay
# Linear span to next metadata entry; not a complete CFG.
033a3f48: f75bbda9 stp      x23, x22, [sp, #-0x30]!
033a3f4c: f55301a9 stp      x21, x20, [sp, #0x10]
033a3f50: f37b02a9 stp      x19, x30, [sp, #0x20]
033a3f54: 160f01f0 adrp     x22, #0x5586000
033a3f58: f7ef00b0 adrp     x23, #0x51a0000
033a3f5c: c84e6739 ldrb     w8, [x22, #0x9d3]
033a3f60: f7ca41f9 ldr      x23, [x23, #0x390]
033a3f64: f30302aa mov      x19, x2
033a3f68: f40301aa mov      x20, x1
033a3f6c: f50300aa mov      x21, x0
033a3f70: c8000037 tbnz     w8, #0, #0x33a3f88
033a3f74: e0ef00b0 adrp     x0, #0x51a0000
033a3f78: 00c841f9 ldr      x0, [x0, #0x390]
033a3f7c: e1347097 bl       #0xfb1300
033a3f80: 28008052 mov      w8, #1
033a3f84: c84e2739 strb     w8, [x22, #0x9d3]
033a3f88: e00240f9 ldr      x0, [x23]
033a3f8c: 23357097 bl       #0xfb1418
033a3f90: 000300b4 cbz      x0, #0x33a3ff0
033a3f94: e1031faa mov      x1, xzr
033a3f98: f60300aa mov      x22, x0
033a3f9c: 963dbb97 bl       #0x22735f4 ; System.Object$$.ctor
033a3fa0: e00316aa mov      x0, x22
033a3fa4: df1200b9 str      wzr, [x22, #0x10]
033a3fa8: 158c05f8 str      x21, [x0, #0x58]!
033a3fac: e10315aa mov      x1, x21
033a3fb0: bf347097 bl       #0xfb12ac
033a3fb4: e00316aa mov      x0, x22
033a3fb8: 140c06f8 str      x20, [x0, #0x60]!
033a3fbc: e10314aa mov      x1, x20
033a3fc0: bb347097 bl       #0xfb12ac
033a3fc4: 681a40f9 ldr      x8, [x19, #0x30]
033a3fc8: 628240ad ldp      q2, q0, [x19, #0x10]
033a3fcc: 6102c03d ldr      q1, [x19]
033a3fd0: e00316aa mov      x0, x22
033a3fd4: c82a00f9 str      x8, [x22, #0x50]
033a3fd8: c28201ad stp      q2, q0, [x22, #0x30]
033a3fdc: c10a803d str      q1, [x22, #0x20]
033a3fe0: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a3fe4: f55341a9 ldp      x21, x20, [sp, #0x10]
033a3fe8: f75bc3a8 ldp      x23, x22, [sp], #0x30
033a3fec: c0035fd6 ret      
033a3ff0: 0e357097 bl       #0xfb1428
