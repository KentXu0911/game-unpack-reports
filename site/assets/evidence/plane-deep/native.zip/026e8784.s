# Royal.Scenes.Game.Mechanics.Items.SeaMineItem.SeaMineItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
026e8784: fe0f1ff8 str      x30, [sp, #-0x10]!
026e8788: 080040f9 ldr      x8, [x0]
026e878c: 096542f9 ldr      x9, [x8, #0x4c8]
026e8790: 016942f9 ldr      x1, [x8, #0x4d0]
026e8794: 20013fd6 blr      x9
026e8798: 08229f52 mov      w8, #0xf910
026e879c: a9828952 mov      w9, #0x4c15
026e87a0: 1f040071 cmp      w0, #1
026e87a4: c800a072 movk     w8, #6, lsl #16
026e87a8: 2901a072 movk     w9, #9, lsl #16
026e87ac: 2001881a csel     w0, w9, w8, eq
026e87b0: fe0741f8 ldr      x30, [sp], #0x10
026e87b4: c0035fd6 ret      
