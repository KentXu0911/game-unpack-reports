# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$GetRowScore
# Linear span to next metadata entry; not a complete CFG.
020f1878: ffc301d1 sub      sp, sp, #0x70
020f187c: fc6f01a9 stp      x28, x27, [sp, #0x10]
020f1880: fa6702a9 stp      x26, x25, [sp, #0x20]
020f1884: f85f03a9 stp      x24, x23, [sp, #0x30]
020f1888: f65704a9 stp      x22, x21, [sp, #0x40]
020f188c: f44f05a9 stp      x20, x19, [sp, #0x50]
020f1890: fd7b06a9 stp      x29, x30, [sp, #0x60]
020f1894: 73a40190 adrp     x19, #0x557d000
020f1898: 68225539 ldrb     w8, [x19, #0x548]
020f189c: f80303aa mov      x24, x3
020f18a0: fa03022a mov      w26, w2
020f18a4: f603012a mov      w22, w1
020f18a8: f70300aa mov      x23, x0
020f18ac: 28010037 tbnz     w8, #0, #0x20f18d0
020f18b0: 608501f0 adrp     x0, #0x51a0000
020f18b4: 00f441f9 ldr      x0, [x0, #0x3e8]
020f18b8: 92feba97 bl       #0xfb1300
020f18bc: e08701b0 adrp     x0, #0x51ee000
020f18c0: 00e444f9 ldr      x0, [x0, #0x9c8]
020f18c4: 8ffeba97 bl       #0xfb1300
020f18c8: 28008052 mov      w8, #1
020f18cc: 68221539 strb     w8, [x19, #0x548]
020f18d0: 1f030039 strb     wzr, [x24]
020f18d4: e06240f9 ldr      x0, [x23, #0xc0]
020f18d8: e01b00b4 cbz      x0, #0x20f1c54
020f18dc: 021840b9 ldr      w2, [x0, #0x18]
020f18e0: e1031f2a mov      w1, wzr
020f18e4: e3031faa mov      x3, xzr
020f18e8: 5bda1194 bl       #0x2568254 ; System.Array$$Clear
020f18ec: e01a40f9 ldr      x0, [x23, #0x30]
020f18f0: 201b00b4 cbz      x0, #0x20f1c54
020f18f4: f3031f2a mov      w19, wzr
020f18f8: ff0300f9 str      xzr, [sp]
020f18fc: f4031f2a mov      w20, wzr
020f1900: f9031f2a mov      w25, wzr
020f1904: 5a030012 and      w26, w26, #1
020f1908: e1031faa mov      x1, xzr
020f190c: b5951994 bl       #0x2756fe0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Width
020f1910: 3f03006b cmp      w25, w0
020f1914: 0a130054 b.ge     #0x20f1b74
020f1918: fb1a40f9 ldr      x27, [x23, #0x30]
020f191c: e0230091 add      x0, sp, #8
020f1920: e103192a mov      w1, w25
020f1924: e203162a mov      w2, w22
020f1928: e3031faa mov      x3, xzr
020f192c: ff0700f9 str      xzr, [sp, #8]
020f1930: d1592794 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
020f1934: 1b1900b4 cbz      x27, #0x20f1c54
020f1938: e10740f9 ldr      x1, [sp, #8]
020f193c: e0031baa mov      x0, x27
020f1940: e2031faa mov      x2, xzr
020f1944: f38a1994 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
020f1948: fc0300aa mov      x28, x0
020f194c: 42008052 mov      w2, #2
020f1950: e00317aa mov      x0, x23
020f1954: e1031caa mov      x1, x28
020f1958: e3031a2a mov      w3, w26
020f195c: 68ffff97 bl       #0x20f16fc ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$GetCellScoreForRocket
020f1960: 15034039 ldrb     w21, [x24]
020f1964: fb03002a mov      w27, w0
020f1968: 1f000071 cmp      w0, #0
020f196c: 6d000054 b.le     #0x20f1978
020f1970: 28008052 mov      w8, #1
020f1974: 04000014 b        #0x20f1984
020f1978: e1031caa mov      x1, x28
020f197c: 7affff97 bl       #0x20f1764 ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$HasTargetableBelowItemUnderLightball
020f1980: 08000012 and      w8, w0, #1
020f1984: 0801152a orr      w8, w8, w21
020f1988: 08030039 strb     w8, [x24]
020f198c: 5c1600b4 cbz      x28, #0x20f1c54
020f1990: 806340f9 ldr      x0, [x28, #0xc0]
020f1994: 001600b4 cbz      x0, #0x20f1c54
020f1998: e1031faa mov      x1, xzr
020f199c: 7303130b add      w19, w27, w19
020f19a0: 2b602794 bl       #0x2ac9a4c ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$HasAboveItem
020f19a4: 000e0037 tbnz     w0, #0, #0x20f1b64
020f19a8: 800b40f9 ldr      x0, [x28, #0x10]
020f19ac: 401500b4 cbz      x0, #0x20f1c54
020f19b0: e1031faa mov      x1, xzr
020f19b4: 32511994 bl       #0x2745e7c ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$HasCurrentItem
020f19b8: 600d0036 tbz      w0, #0, #0x20f1b64
020f19bc: e0031caa mov      x0, x28
020f19c0: e1031faa mov      x1, xzr
020f19c4: 275c2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f19c8: 601400b4 cbz      x0, #0x20f1c54
020f19cc: 080040f9 ldr      x8, [x0]
020f19d0: 09bd41f9 ldr      x9, [x8, #0x378]
020f19d4: 01c141f9 ldr      x1, [x8, #0x380]
020f19d8: 20013fd6 blr      x9
020f19dc: 1f140071 cmp      w0, #5
020f19e0: 01010054 b.ne     #0x20f1a00
020f19e4: a80b9352 mov      w8, #0x985d
020f19e8: e8fcbf72 movk     w8, #0xffe7, lsl #16
020f19ec: 6802080b add      w8, w19, w8
020f19f0: 7f070071 cmp      w27, #1
020f19f4: 73b2881a csel     w19, w19, w8, lt
020f19f8: 35008052 mov      w21, #1
020f19fc: 3d000014 b        #0x20f1af0
020f1a00: e0031caa mov      x0, x28
020f1a04: e1031faa mov      x1, xzr
020f1a08: 165c2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f1a0c: 401200b4 cbz      x0, #0x20f1c54
020f1a10: 080040f9 ldr      x8, [x0]
020f1a14: 09bd41f9 ldr      x9, [x8, #0x378]
020f1a18: 01c141f9 ldr      x1, [x8, #0x380]
020f1a1c: 20013fd6 blr      x9
020f1a20: 1fc00071 cmp      w0, #0x30
020f1a24: 61010054 b.ne     #0x20f1a50
020f1a28: e0031caa mov      x0, x28
020f1a2c: e1031faa mov      x1, xzr
020f1a30: 0c5c2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f1a34: 001100b4 cbz      x0, #0x20f1c54
020f1a38: 080040f9 ldr      x8, [x0]
020f1a3c: 096542f9 ldr      x9, [x8, #0x4c8]
020f1a40: 016942f9 ldr      x1, [x8, #0x4d0]
020f1a44: 20013fd6 blr      x9
020f1a48: 1f040071 cmp      w0, #1
020f1a4c: 0d040054 b.le     #0x20f1acc
020f1a50: e0031caa mov      x0, x28
020f1a54: e1031faa mov      x1, xzr
020f1a58: 025c2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f1a5c: c00f00b4 cbz      x0, #0x20f1c54
020f1a60: 080040f9 ldr      x8, [x0]
020f1a64: 09bd41f9 ldr      x9, [x8, #0x378]
020f1a68: 01c141f9 ldr      x1, [x8, #0x380]
020f1a6c: 20013fd6 blr      x9
020f1a70: 1f400171 cmp      w0, #0x50
020f1a74: 61010054 b.ne     #0x20f1aa0
020f1a78: e0031caa mov      x0, x28
020f1a7c: e1031faa mov      x1, xzr
020f1a80: f85b2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f1a84: 800e00b4 cbz      x0, #0x20f1c54
020f1a88: 080040f9 ldr      x8, [x0]
020f1a8c: 096542f9 ldr      x9, [x8, #0x4c8]
020f1a90: 016942f9 ldr      x1, [x8, #0x4d0]
020f1a94: 20013fd6 blr      x9
020f1a98: 1f040071 cmp      w0, #1
020f1a9c: 2d020054 b.le     #0x20f1ae0
020f1aa0: e0031caa mov      x0, x28
020f1aa4: e1031faa mov      x1, xzr
020f1aa8: ee5b2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f1aac: 400d00b4 cbz      x0, #0x20f1c54
020f1ab0: 080040f9 ldr      x8, [x0]
020f1ab4: 09bd41f9 ldr      x9, [x8, #0x378]
020f1ab8: 01c141f9 ldr      x1, [x8, #0x380]
020f1abc: 20013fd6 blr      x9
020f1ac0: 1fb00171 cmp      w0, #0x6c
020f1ac4: f5079f1a cset     w21, ne
020f1ac8: 0a000014 b        #0x20f1af0
020f1acc: e80740b9 ldr      w8, [sp, #4]
020f1ad0: 35008052 mov      w21, #1
020f1ad4: 08050011 add      w8, w8, #1
020f1ad8: e80700b9 str      w8, [sp, #4]
020f1adc: 05000014 b        #0x20f1af0
020f1ae0: e80340b9 ldr      w8, [sp]
020f1ae4: 35008052 mov      w21, #1
020f1ae8: 08050011 add      w8, w8, #1
020f1aec: e80300b9 str      w8, [sp]
020f1af0: e02640f9 ldr      x0, [x23, #0x48]
020f1af4: 000b00b4 cbz      x0, #0x20f1c54
020f1af8: e1031faa mov      x1, xzr
020f1afc: f8a3fd97 bl       #0x205aadc ; Royal.Player.Context.Units.LevelManager$$IsThereBottomCollectInLevel
020f1b00: a0020036 tbz      w0, #0, #0x20f1b54
020f1b04: e0031caa mov      x0, x28
020f1b08: e1031faa mov      x1, xzr
020f1b0c: d55b2794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f1b10: fd6240f9 ldr      x29, [x23, #0xc0]
020f1b14: fc0300aa mov      x28, x0
020f1b18: e0230091 add      x0, sp, #8
020f1b1c: e1031f2a mov      w1, wzr
020f1b20: e203162a mov      w2, w22
020f1b24: e3031faa mov      x3, xzr
020f1b28: ff0700f9 str      xzr, [sp, #8]
020f1b2c: 52592794 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
020f1b30: 3c0900b4 cbz      x28, #0x20f1c54
020f1b34: 880340f9 ldr      x8, [x28]
020f1b38: e30740f9 ldr      x3, [sp, #8]
020f1b3c: 41008052 mov      w1, #2
020f1b40: e0031caa mov      x0, x28
020f1b44: 091544f9 ldr      x9, [x8, #0x828]
020f1b48: 041944f9 ldr      x4, [x8, #0x830]
020f1b4c: e2031daa mov      x2, x29
020f1b50: 20013fd6 blr      x9
020f1b54: 7f030071 cmp      w27, #0
020f1b58: e8d79f1a cset     w8, gt
020f1b5c: a802080a and      w8, w21, w8
020f1b60: 9402080b add      w20, w20, w8
020f1b64: e01a40f9 ldr      x0, [x23, #0x30]
020f1b68: 39070011 add      w25, w25, #1
020f1b6c: e0ecffb5 cbnz     x0, #0x20f1908
020f1b70: 39000014 b        #0x20f1c54
020f1b74: e02640f9 ldr      x0, [x23, #0x48]
020f1b78: e00600b4 cbz      x0, #0x20f1c54
020f1b7c: e1031faa mov      x1, xzr
020f1b80: d7a3fd97 bl       #0x205aadc ; Royal.Player.Context.Units.LevelManager$$IsThereBottomCollectInLevel
020f1b84: 9f060071 cmp      w20, #1
020f1b88: 2b020054 b.lt     #0x20f1bcc
020f1b8c: 00020036 tbz      w0, #0, #0x20f1bcc
020f1b90: f81a40f9 ldr      x24, [x23, #0x30]
020f1b94: f76240f9 ldr      x23, [x23, #0xc0]
020f1b98: e0230091 add      x0, sp, #8
020f1b9c: e1031f2a mov      w1, wzr
020f1ba0: e203162a mov      w2, w22
020f1ba4: e3031faa mov      x3, xzr
020f1ba8: ff0700f9 str      xzr, [sp, #8]
020f1bac: 32592794 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
020f1bb0: 380500b4 cbz      x24, #0x20f1c54
020f1bb4: e20740f9 ldr      x2, [sp, #8]
020f1bb8: e00318aa mov      x0, x24
020f1bbc: e10317aa mov      x1, x23
020f1bc0: e3031faa mov      x3, xzr
020f1bc4: a8a81994 bl       #0x275be64 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$GetBottomCollectHorizontalRocketScoreForClearedCells
020f1bc8: 1300130b add      w19, w0, w19
020f1bcc: f4574029 ldp      w20, w21, [sp]
020f1bd0: bf060071 cmp      w21, #1
020f1bd4: 6b010054 b.lt     #0x20f1c00
020f1bd8: e88701b0 adrp     x8, #0x51ee000
020f1bdc: 08e544f9 ldr      x8, [x8, #0x9c8]
020f1be0: c0058052 mov      w0, #0x2e
020f1be4: 010140f9 ldr      x1, [x8]
020f1be8: a1331194 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
020f1bec: 400300b4 cbz      x0, #0x20f1c54
020f1bf0: e103152a mov      w1, w21
020f1bf4: e2031faa mov      x2, xzr
020f1bf8: d7aec697 bl       #0x129d754 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.TreasureMapItem.TreasureMapHelper$$GetTreasureRevealExtraScore
020f1bfc: 1300130b add      w19, w0, w19
020f1c00: 9f060071 cmp      w20, #1
020f1c04: 6b010054 b.lt     #0x20f1c30
020f1c08: 688501f0 adrp     x8, #0x51a0000
020f1c0c: 08f541f9 ldr      x8, [x8, #0x3e8]
020f1c10: e0098052 mov      w0, #0x4f
020f1c14: 010140f9 ldr      x1, [x8]
020f1c18: 95331194 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
020f1c1c: c00100b4 cbz      x0, #0x20f1c54
020f1c20: e103142a mov      w1, w20
020f1c24: e2031faa mov      x2, xzr
020f1c28: cafbf497 bl       #0x1e30b50 ; Royal.Scenes.Game.Mechanics.Items.LogItem.LogItemHelper$$GetLogActivateExtraScore
020f1c2c: 1300130b add      w19, w0, w19
020f1c30: e003132a mov      w0, w19
020f1c34: fd7b46a9 ldp      x29, x30, [sp, #0x60]
020f1c38: f44f45a9 ldp      x20, x19, [sp, #0x50]
020f1c3c: f65744a9 ldp      x22, x21, [sp, #0x40]
020f1c40: f85f43a9 ldp      x24, x23, [sp, #0x30]
020f1c44: fa6742a9 ldp      x26, x25, [sp, #0x20]
020f1c48: fc6f41a9 ldp      x28, x27, [sp, #0x10]
020f1c4c: ffc30191 add      sp, sp, #0x70
020f1c50: c0035fd6 ret      
020f1c54: f5fdba97 bl       #0xfb1428
