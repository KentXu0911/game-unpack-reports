# Royal.Scenes.Game.Mechanics.Items.RoyalCapsuleVerticalItem.RoyalCapsuleVerticalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
026f8888: f553bea9 stp      x21, x20, [sp, #-0x20]!
026f888c: f37b01a9 stp      x19, x30, [sp, #0x10]
026f8890: 55740190 adrp     x21, #0x5580000
026f8894: 145601b0 adrp     x20, #0x51b9000
026f8898: a83a5039 ldrb     w8, [x21, #0x40e]
026f889c: 947245f9 ldr      x20, [x20, #0xae0]
026f88a0: f30300aa mov      x19, x0
026f88a4: c8000037 tbnz     w8, #0, #0x26f88bc
026f88a8: 005601b0 adrp     x0, #0x51b9000
026f88ac: 007045f9 ldr      x0, [x0, #0xae0]
026f88b0: 94e2a297 bl       #0xfb1300
026f88b4: 28008052 mov      w8, #1
026f88b8: a83a1039 strb     w8, [x21, #0x40e]
026f88bc: 800240f9 ldr      x0, [x20]
026f88c0: 08e040b9 ldr      w8, [x0, #0xe0]
026f88c4: 48000035 cbnz     w8, #0x26f88cc
026f88c8: cfe2a297 bl       #0xfb1404
026f88cc: f57301f0 adrp     x21, #0x5577000
026f88d0: a84e7d39 ldrb     w8, [x21, #0xf53]
026f88d4: c8000035 cbnz     w8, #0x26f88ec
026f88d8: 005601b0 adrp     x0, #0x51b9000
026f88dc: 007045f9 ldr      x0, [x0, #0xae0]
026f88e0: 88e2a297 bl       #0xfb1300
026f88e4: 28008052 mov      w8, #1
026f88e8: a84e3d39 strb     w8, [x21, #0xf53]
026f88ec: 800240f9 ldr      x0, [x20]
026f88f0: 08e040b9 ldr      w8, [x0, #0xe0]
026f88f4: 68000035 cbnz     w8, #0x26f8900
026f88f8: c3e2a297 bl       #0xfb1404
026f88fc: 800240f9 ldr      x0, [x20]
026f8900: 085c40f9 ldr      x8, [x0, #0xb8]
026f8904: 00229f52 mov      w0, #0xf910
026f8908: c000a072 movk     w0, #6, lsl #16
026f890c: 08514039 ldrb     w8, [x8, #0x14]
026f8910: 48020035 cbnz     w8, #0x26f8958
026f8914: 686a40b9 ldr      w8, [x19, #0x68]
026f8918: 1f050071 cmp      w8, #1
026f891c: a1010054 b.ne     #0x26f8950
026f8920: 68ae40f9 ldr      x8, [x19, #0x158]
026f8924: 280200b4 cbz      x8, #0x26f8968
026f8928: 091940b9 ldr      w9, [x8, #0x18]
026f892c: c9010034 cbz      w9, #0x26f8964
026f8930: 0a2140b9 ldr      w10, [x8, #0x20]
026f8934: 5fc90071 cmp      w10, #0x32
026f8938: 00010054 b.eq     #0x26f8958
026f893c: 3f050071 cmp      w9, #1
026f8940: 29010054 b.ls     #0x26f8964
026f8944: 082540b9 ldr      w8, [x8, #0x24]
026f8948: 1fc90071 cmp      w8, #0x32
026f894c: 60000054 b.eq     #0x26f8958
026f8950: 209f8952 mov      w0, #0x4cf9
026f8954: 4000a072 movk     w0, #2, lsl #16
026f8958: f37b41a9 ldp      x19, x30, [sp, #0x10]
026f895c: f553c2a8 ldp      x21, x20, [sp], #0x20
026f8960: c0035fd6 ret      
026f8964: b3e2a297 bl       #0xfb1430
026f8968: b0e2a297 bl       #0xfb1428
