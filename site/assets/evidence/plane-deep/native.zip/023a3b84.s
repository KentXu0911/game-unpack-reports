# Royal.Scenes.Game.Mechanics.Items.SoilItem.SoilItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
023a3b84: f553bea9 stp      x21, x20, [sp, #-0x20]!
023a3b88: f37b01a9 stp      x19, x30, [sp, #0x10]
023a3b8c: 080040f9 ldr      x8, [x0]
023a3b90: f303012a mov      w19, w1
023a3b94: f40300aa mov      x20, x0
023a3b98: 096542f9 ldr      x9, [x8, #0x4c8]
023a3b9c: 086942f9 ldr      x8, [x8, #0x4d0]
023a3ba0: e10308aa mov      x1, x8
023a3ba4: 20013fd6 blr      x9
023a3ba8: f503002a mov      w21, w0
023a3bac: e00314aa mov      x0, x20
023a3bb0: e103132a mov      w1, w19
023a3bb4: e2031faa mov      x2, xzr
023a3bb8: 6d833f94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
023a3bbc: bf060071 cmp      w21, #1
023a3bc0: f303002a mov      w19, w0
023a3bc4: e1020054 b.ne     #0x23a3c20
023a3bc8: 880240f9 ldr      x8, [x20]
023a3bcc: e00314aa mov      x0, x20
023a3bd0: 09bd41f9 ldr      x9, [x8, #0x378]
023a3bd4: 01c141f9 ldr      x1, [x8, #0x380]
023a3bd8: 20013fd6 blr      x9
023a3bdc: e1031faa mov      x1, xzr
023a3be0: 6a833f94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
023a3be4: 886640f9 ldr      x8, [x20, #0xc8]
023a3be8: 480200b4 cbz      x8, #0x23a3c30
023a3bec: 81ba40b9 ldr      w1, [x20, #0xb8]
023a3bf0: f503002a mov      w21, w0
023a3bf4: e00308aa mov      x0, x8
023a3bf8: 8af0ff97 bl       #0x239fe20 ; Royal.Scenes.Game.Mechanics.Items.SoilItem.SoilItemHelper$$GetGroupLength
023a3bfc: 08040051 sub      w8, w0, #1
023a3c00: c9aa8a52 mov      w9, #0x5556
023a3c04: a9aaaa72 movk     w9, #0x5555, lsl #16
023a3c08: 087d151b mul      w8, w8, w21
023a3c0c: 087d299b smull    x8, w8, w9
023a3c10: 09fd7fd3 lsr      x9, x8, #0x3f
023a3c14: 08fd60d3 lsr      x8, x8, #0x20
023a3c18: 0801090b add      w8, w8, w9
023a3c1c: 1301130b add      w19, w8, w19
023a3c20: e003132a mov      w0, w19
023a3c24: f37b41a9 ldp      x19, x30, [sp, #0x10]
023a3c28: f553c2a8 ldp      x21, x20, [sp], #0x20
023a3c2c: c0035fd6 ret      
023a3c30: fe35b097 bl       #0xfb1428
