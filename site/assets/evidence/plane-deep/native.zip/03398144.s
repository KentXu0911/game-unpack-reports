# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_EndFallStateId
# Linear span to next metadata entry; not a complete CFG.
03398144: f40f1ef8 str      x20, [sp, #-0x20]!
03398148: f37b01a9 stp      x19, x30, [sp, #0x10]
0339814c: 740f01d0 adrp     x20, #0x5586000
03398150: f3f10090 adrp     x19, #0x51d4000
03398154: 88626639 ldrb     w8, [x20, #0x998]
03398158: 73da41f9 ldr      x19, [x19, #0x3b0]
0339815c: c8000037 tbnz     w8, #0, #0x3398174
03398160: e0f10090 adrp     x0, #0x51d4000
03398164: 00d841f9 ldr      x0, [x0, #0x3b0]
03398168: 66647097 bl       #0xfb1300
0339816c: 28008052 mov      w8, #1
03398170: 88622639 strb     w8, [x20, #0x998]
03398174: 600240f9 ldr      x0, [x19]
03398178: 08e040b9 ldr      w8, [x0, #0xe0]
0339817c: 68000035 cbnz     w8, #0x3398188
03398180: a1647097 bl       #0xfb1404
03398184: 600240f9 ldr      x0, [x19]
03398188: 085c40f9 ldr      x8, [x0, #0xb8]
0339818c: f37b41a9 ldp      x19, x30, [sp, #0x10]
03398190: 001140b9 ldr      w0, [x8, #0x10]
03398194: f40742f8 ldr      x20, [sp], #0x20
03398198: c0035fd6 ret      
