# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$Clear
# Linear span to next metadata entry; not a complete CFG.
020eefe0: f40f1ef8 str      x20, [sp, #-0x20]!
020eefe4: f37b01a9 stp      x19, x30, [sp, #0x10]
020eefe8: f403012a mov      w20, w1
020eefec: 21000012 and      w1, w1, #1
020eeff0: f30300aa mov      x19, x0
020eeff4: 19000094 bl       #0x20ef058 ; Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$ClearLists
020eeff8: b4000036 tbz      w20, #0, #0x20ef00c
020eeffc: 7f0e0af8 str      xzr, [x19, #0xa0]!
020ef000: e00313aa mov      x0, x19
020ef004: e1031faa mov      x1, xzr
020ef008: a908bb97 bl       #0xfb12ac
020ef00c: e0031faa mov      x0, xzr
020ef010: a789f697 bl       #0x1e916ac ; Royal.Scenes.Game.Mechanics.Items.MatchItem.MatchItemExplodeScoreCalculator$$Reset
020ef014: 73a401d0 adrp     x19, #0x557d000
020ef018: f4850190 adrp     x20, #0x51ab000
020ef01c: 680e5539 ldrb     w8, [x19, #0x543]
020ef020: 94c642f9 ldr      x20, [x20, #0x588]
020ef024: c8000037 tbnz     w8, #0, #0x20ef03c
020ef028: e0850190 adrp     x0, #0x51ab000
020ef02c: 00c442f9 ldr      x0, [x0, #0x588]
020ef030: b408bb97 bl       #0xfb1300
020ef034: 28008052 mov      w8, #1
020ef038: 680e1539 strb     w8, [x19, #0x543]
020ef03c: 880240f9 ldr      x8, [x20]
020ef040: 09e28452 mov      w9, #0x2710
020ef044: 085d40f9 ldr      x8, [x8, #0xb8]
020ef048: 090100b9 str      w9, [x8]
020ef04c: f37b41a9 ldp      x19, x30, [sp, #0x10]
020ef050: f40742f8 ldr      x20, [sp], #0x20
020ef054: c0035fd6 ret      
