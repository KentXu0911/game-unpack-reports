# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$PlayEndFallAnimation
# Linear span to next metadata entry; not a complete CFG.
033986ac: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033986b0: 080040f9 ldr      x8, [x0]
033986b4: 133c40f9 ldr      x19, [x0, #0x78]
033986b8: 094d42f9 ldr      x9, [x8, #0x498]
033986bc: 015142f9 ldr      x1, [x8, #0x4a0]
033986c0: 20013fd6 blr      x9
033986c4: 130100b4 cbz      x19, #0x33986e4
033986c8: e103002a mov      w1, w0
033986cc: e003271e fmov     s0, wzr
033986d0: e00313aa mov      x0, x19
033986d4: e2031f2a mov      w2, wzr
033986d8: e3031faa mov      x3, xzr
033986dc: f37bc1a8 ldp      x19, x30, [sp], #0x10
033986e0: 94caa817 b        #0x1dcb130 ; UnityEngine.Animator$$Play
033986e4: 51637097 bl       #0xfb1428
