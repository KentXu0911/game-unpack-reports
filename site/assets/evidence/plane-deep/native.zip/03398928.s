# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerRocketComboParticles$$.ctor
# Linear span to next metadata entry; not a complete CFG.
03398928: e1031faa mov      x1, xzr
0339892c: e9b4ff17 b        #0x3385cd0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemParticles$$.ctor
