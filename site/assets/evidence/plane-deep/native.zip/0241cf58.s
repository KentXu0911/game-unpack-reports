# Royal.Scenes.Game.Mechanics.Items.HatItem.HatItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
0241cf58: f553bea9 stp      x21, x20, [sp, #-0x20]!
0241cf5c: f37b01a9 stp      x19, x30, [sp, #0x10]
0241cf60: 08084339 ldrb     w8, [x0, #0xc2]
0241cf64: 28020034 cbz      w8, #0x241cfa8
0241cf68: 155c40f9 ldr      x21, [x0, #0xb8]
0241cf6c: f30300aa mov      x19, x0
0241cf70: 150300b4 cbz      x21, #0x241cfd0
0241cf74: e00315aa mov      x0, x21
0241cf78: f403012a mov      w20, w1
0241cf7c: 70f9ff97 bl       #0x241b53c ; Royal.Scenes.Game.Mechanics.Items.HatItem.HatItemHelper$$GetPurpleGoal
0241cf80: a84e40b9 ldr      w8, [x21, #0x4c]
0241cf84: 1f01006b cmp      w8, w0
0241cf88: 0a010054 b.ge     #0x241cfa8
0241cf8c: 756a40b9 ldr      w21, [x19, #0x68]
0241cf90: e00313aa mov      x0, x19
0241cf94: 4bfdff97 bl       #0x241c4c0 ; Royal.Scenes.Game.Mechanics.Items.HatItem.HatItemModel$$GetTotalIncoming
0241cf98: 0800154b sub      w8, w0, w21
0241cf9c: 080d0011 add      w8, w8, #3
0241cfa0: 1f090071 cmp      w8, #2
0241cfa4: ad000054 b.le     #0x241cfb8
0241cfa8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0241cfac: e0031f2a mov      w0, wzr
0241cfb0: f553c2a8 ldp      x21, x20, [sp], #0x20
0241cfb4: c0035fd6 ret      
0241cfb8: e00313aa mov      x0, x19
0241cfbc: f37b41a9 ldp      x19, x30, [sp, #0x10]
0241cfc0: e103142a mov      w1, w20
0241cfc4: e2031faa mov      x2, xzr
0241cfc8: f553c2a8 ldp      x21, x20, [sp], #0x20
0241cfcc: 689e3d14 b        #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
0241cfd0: 1651ae97 bl       #0xfb1428
