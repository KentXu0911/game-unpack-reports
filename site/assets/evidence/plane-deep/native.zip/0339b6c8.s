# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$GetMinFlyTime
# Linear span to next metadata entry; not a complete CFG.
0339b6c8: 68560090 adrp     x8, #0x3e67000
0339b6cc: 009544bd ldr      s0, [x8, #0x494]
0339b6d0: c0035fd6 ret      
