# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ExplodeNeighbors
# Linear span to next metadata entry; not a complete CFG.
033a2b98: ff4306d1 sub      sp, sp, #0x190
033a2b9c: fca300f9 str      x28, [sp, #0x140]
033a2ba0: f96315a9 stp      x25, x24, [sp, #0x150]
033a2ba4: f75b16a9 stp      x23, x22, [sp, #0x160]
033a2ba8: f55317a9 stp      x21, x20, [sp, #0x170]
033a2bac: f37b18a9 stp      x19, x30, [sp, #0x180]
033a2bb0: 58d03bd5 mrs      x24, tpidr_el0
033a2bb4: 081740f9 ldr      x8, [x24, #0x28]
033a2bb8: 370f0190 adrp     x23, #0x5586000
033a2bbc: f30303aa mov      x19, x3
033a2bc0: f603022a mov      w22, w2
033a2bc4: e89f00f9 str      x8, [sp, #0x138]
033a2bc8: e8266739 ldrb     w8, [x23, #0x9c9]
033a2bcc: f40301aa mov      x20, x1
033a2bd0: f50300aa mov      x21, x0
033a2bd4: f9e30191 add      x25, sp, #0x78
033a2bd8: c8000037 tbnz     w8, #0, #0x33a2bf0
033a2bdc: e0ef00d0 adrp     x0, #0x51a0000
033a2be0: 00bc46f9 ldr      x0, [x0, #0xd78]
033a2be4: c7397097 bl       #0xfb1300
033a2be8: 28008052 mov      w8, #1
033a2bec: e8262739 strb     w8, [x23, #0x9c9]
033a2bf0: 00e4006f movi     v0.2d, #0000000000000000
033a2bf4: ff7f0fa9 stp      xzr, xzr, [sp, #0xf0]
033a2bf8: ff0301b9 str      wzr, [sp, #0x100]
033a2bfc: e08308ad stp      q0, q0, [sp, #0x110]
033a2c00: 3f730bb8 stur     wzr, [x25, #0xb7]
033a2c04: 540a00b4 cbz      x20, #0x33a2d4c
033a2c08: 976240f9 ldr      x23, [x20, #0xc0]
033a2c0c: e8e30191 add      x8, sp, #0x78
033a2c10: 00018052 mov      w0, #8
033a2c14: e1031faa mov      x1, xzr
033a2c18: 245ce697 bl       #0x2d39ca8 ; Royal.Scenes.Game.Mechanics.Explode.Exploder$$Next
033a2c1c: 228340ad ldp      q2, q0, [x25, #0x10]
033a2c20: e183c73c ldur     q1, [sp, #0x78]
033a2c24: e85740f9 ldr      x8, [sp, #0xa8]
033a2c28: e20306ad stp      q2, q0, [sp, #0xc0]
033a2c2c: e12f803d str      q1, [sp, #0xb0]
033a2c30: e87300f9 str      x8, [sp, #0xe0]
033a2c34: d70800b4 cbz      x23, #0x33a2d4c
033a2c38: e18345ad ldp      q1, q0, [sp, #0xb0]
033a2c3c: e237c03d ldr      q2, [sp, #0xd0]
033a2c40: e87340f9 ldr      x8, [sp, #0xe0]
033a2c44: e1030191 add      x1, sp, #0x40
033a2c48: e00317aa mov      x0, x23
033a2c4c: e2031faa mov      x2, xzr
033a2c50: e10302ad stp      q1, q0, [sp, #0x40]
033a2c54: e21b803d str      q2, [sp, #0x60]
033a2c58: e83b00f9 str      x8, [sp, #0x70]
033a2c5c: 19a1dc97 bl       #0x2acb0c0 ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$ExplodeTopMostBelowItem
033a2c60: df3e0071 cmp      w22, #0xf
033a2c64: c0050054 b.eq     #0x33a2d1c
033a2c68: 810e40f9 ldr      x1, [x20, #0x18]
033a2c6c: f6ef00d0 adrp     x22, #0x51a0000
033a2c70: d6be46f9 ldr      x22, [x22, #0xd78]
033a2c74: e8c30291 add      x8, sp, #0xb0
033a2c78: 20018052 mov      w0, #9
033a2c7c: e2031faa mov      x2, xzr
033a2c80: 4d5ce697 bl       #0x2d39db4 ; Royal.Scenes.Game.Mechanics.Explode.Exploder$$Next
033a2c84: e02fc03d ldr      q0, [sp, #0xb0]
033a2c88: e8e740b9 ldr      w8, [sp, #0xe4]
033a2c8c: e9c340b9 ldr      w9, [sp, #0xc0]
033a2c90: 21d3c53c ldur     q1, [x25, #0x5d]
033a2c94: 22d3c43c ldur     q2, [x25, #0x4d]
033a2c98: e00314aa mov      x0, x20
033a2c9c: e1031faa mov      x1, xzr
033a2ca0: e03f803d str      q0, [sp, #0xf0]
033a2ca4: e90301b9 str      w9, [sp, #0x100]
033a2ca8: e28708ad stp      q2, q1, [sp, #0x110]
033a2cac: 28730bb8 stur     w8, [x25, #0xb7]
033a2cb0: 16a4dc97 bl       #0x2acbd08 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$HasJellyView
033a2cb4: e03fc03d ldr      q0, [sp, #0xf0]
033a2cb8: e90341b9 ldr      w9, [sp, #0x100]
033a2cbc: e28748ad ldp      q2, q1, [sp, #0x110]
033a2cc0: 2a734bb8 ldur     w10, [x25, #0xb7]
033a2cc4: 08000012 and      w8, w0, #1
033a2cc8: e2030091 mov      x2, sp
033a2ccc: e00315aa mov      x0, x21
033a2cd0: e10314aa mov      x1, x20
033a2cd4: e30313aa mov      x3, x19
033a2cd8: e8530039 strb     w8, [sp, #0x14]
033a2cdc: e003803d str      q0, [sp]
033a2ce0: e91300b9 str      w9, [sp, #0x10]
033a2ce4: e253813c stur     q2, [sp, #0x15]
033a2ce8: e153823c stur     q1, [sp, #0x25]
033a2cec: ea3700b9 str      w10, [sp, #0x34]
033a2cf0: 19000094 bl       #0x33a2d54 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ExplodeNeighbors
033a2cf4: c80240f9 ldr      x8, [x22]
033a2cf8: f30300aa mov      x19, x0
033a2cfc: 09e140b9 ldr      w9, [x8, #0xe0]
033a2d00: 69000035 cbnz     w9, #0x33a2d0c
033a2d04: e00308aa mov      x0, x8
033a2d08: bf397097 bl       #0xfb1404
033a2d0c: e00313aa mov      x0, x19
033a2d10: e1031faa mov      x1, xzr
033a2d14: e2031faa mov      x2, xzr
033a2d18: 7958c297 bl       #0x2438efc ; Royal.Scenes.Game.Context.GameContext$$ManualStartCoroutine
033a2d1c: 081740f9 ldr      x8, [x24, #0x28]
033a2d20: e99f40f9 ldr      x9, [sp, #0x138]
033a2d24: 1f0109eb cmp      x8, x9
033a2d28: 41010054 b.ne     #0x33a2d50
033a2d2c: f37b58a9 ldp      x19, x30, [sp, #0x180]
033a2d30: f55357a9 ldp      x21, x20, [sp, #0x170]
033a2d34: f75b56a9 ldp      x23, x22, [sp, #0x160]
033a2d38: f96355a9 ldp      x25, x24, [sp, #0x150]
033a2d3c: fca340f9 ldr      x28, [sp, #0x140]
033a2d40: 20008052 mov      w0, #1
033a2d44: ff430691 add      sp, sp, #0x190
033a2d48: c0035fd6 ret      
033a2d4c: b7397097 bl       #0xfb1428
033a2d50: 00816497 bl       #0xcc3150
