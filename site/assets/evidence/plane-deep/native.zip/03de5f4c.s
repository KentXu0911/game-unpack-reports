# Royal.Scenes.Game.Mechanics.Items.ToyBoxHorizontalItem.ToyBoxHorizontalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03de5f4c: f40f1ef8 str      x20, [sp, #-0x20]!
03de5f50: f37b01a9 stp      x19, x30, [sp, #0x10]
03de5f54: f403012a mov      w20, w1
03de5f58: f30300aa mov      x19, x0
03de5f5c: e003012a mov      w0, w1
03de5f60: e1031faa mov      x1, xzr
03de5f64: 767ad697 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03de5f68: a0000037 tbnz     w0, #0, #0x3de5f7c
03de5f6c: e003142a mov      w0, w20
03de5f70: e1031faa mov      x1, xzr
03de5f74: 0493d697 bl       #0x338ab84 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsVerticalLineExploder
03de5f78: 20040036 tbz      w0, #0, #0x3de5ffc
03de5f7c: 680240f9 ldr      x8, [x19]
03de5f80: e00313aa mov      x0, x19
03de5f84: 096542f9 ldr      x9, [x8, #0x4c8]
03de5f88: 016942f9 ldr      x1, [x8, #0x4d0]
03de5f8c: 20013fd6 blr      x9
03de5f90: 1f040071 cmp      w0, #1
03de5f94: 41030054 b.ne     #0x3de5ffc
03de5f98: 680240f9 ldr      x8, [x19]
03de5f9c: e00313aa mov      x0, x19
03de5fa0: 09bd41f9 ldr      x9, [x8, #0x378]
03de5fa4: 01c141f9 ldr      x1, [x8, #0x380]
03de5fa8: 20013fd6 blr      x9
03de5fac: e1031faa mov      x1, xzr
03de5fb0: 767ad697 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03de5fb4: 680240f9 ldr      x8, [x19]
03de5fb8: f403002a mov      w20, w0
03de5fbc: e00313aa mov      x0, x19
03de5fc0: 09bd41f9 ldr      x9, [x8, #0x378]
03de5fc4: 01c141f9 ldr      x1, [x8, #0x380]
03de5fc8: 20013fd6 blr      x9
03de5fcc: e1031faa mov      x1, xzr
03de5fd0: 6e7ad697 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
03de5fd4: c8aa8a52 mov      w8, #0x5556
03de5fd8: a8aaaa72 movk     w8, #0x5555, lsl #16
03de5fdc: 087c289b smull    x8, w0, w8
03de5fe0: f37b41a9 ldp      x19, x30, [sp, #0x10]
03de5fe4: 09fd7fd3 lsr      x9, x8, #0x3f
03de5fe8: 08fd60d3 lsr      x8, x8, #0x20
03de5fec: 0801090b add      w8, w8, w9
03de5ff0: 0001140b add      w0, w8, w20
03de5ff4: f40742f8 ldr      x20, [sp], #0x20
03de5ff8: c0035fd6 ret      
03de5ffc: e00313aa mov      x0, x19
03de6000: f37b41a9 ldp      x19, x30, [sp, #0x10]
03de6004: e103142a mov      w1, w20
03de6008: e2031faa mov      x2, xzr
03de600c: f40742f8 ldr      x20, [sp], #0x20
03de6010: 20afd617 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
