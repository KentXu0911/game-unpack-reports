# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinConditionForSingleHitAreaExploder
# Linear span to next metadata entry; not a complete CFG.
026a8c8c: ffc302d1 sub      sp, sp, #0xb0
026a8c90: f64300f9 str      x22, [sp, #0x80]
026a8c94: f55309a9 stp      x21, x20, [sp, #0x90]
026a8c98: f37b0aa9 stp      x19, x30, [sp, #0xa0]
026a8c9c: f30302aa mov      x19, x2
026a8ca0: f40301aa mov      x20, x1
026a8ca4: f50300aa mov      x21, x0
026a8ca8: bffeff97 bl       #0x26a87a4 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ShouldCalculateSpecificWinConditions
026a8cac: a0020036 tbz      w0, #0, #0x26a8d00
026a8cb0: e00313aa mov      x0, x19
026a8cb4: e1031faa mov      x1, xzr
026a8cb8: 707e1094 bl       #0x2ac8678 ; Royal.Scenes.Game.Mechanics.Board.Grid.Iterator.GridIterator$$Reset
026a8cbc: e00313aa mov      x0, x19
026a8cc0: e1031faa mov      x1, xzr
026a8cc4: 577e1094 bl       #0x2ac8620 ; Royal.Scenes.Game.Mechanics.Board.Grid.Iterator.GridIterator$$MoveNext
026a8cc8: 000200b4 cbz      x0, #0x26a8d08
026a8ccc: 680a40f9 ldr      x8, [x19, #0x10]
026a8cd0: 680500b4 cbz      x8, #0x26a8d7c
026a8cd4: 800640ad ldp      q0, q1, [x20]
026a8cd8: 891a40f9 ldr      x9, [x20, #0x30]
026a8cdc: 820ac03d ldr      q2, [x20, #0x20]
026a8ce0: 01094329 ldp      w1, w2, [x8, #0x18]
026a8ce4: e3030191 add      x3, sp, #0x40
026a8ce8: e00315aa mov      x0, x21
026a8cec: e93b00f9 str      x9, [sp, #0x70]
026a8cf0: e18b02ad stp      q1, q2, [sp, #0x50]
026a8cf4: e013803d str      q0, [sp, #0x40]
026a8cf8: bcfeff97 bl       #0x26a87e8 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddTemporaryIncomingExploder
026a8cfc: f0ffff17 b        #0x26a8cbc
026a8d00: f6031f2a mov      w22, wzr
026a8d04: 18000014 b        #0x26a8d64
026a8d08: e00315aa mov      x0, x21
026a8d0c: f0feff97 bl       #0x26a88cc ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinCondition
026a8d10: f603002a mov      w22, w0
026a8d14: e00313aa mov      x0, x19
026a8d18: e1031faa mov      x1, xzr
026a8d1c: 577e1094 bl       #0x2ac8678 ; Royal.Scenes.Game.Mechanics.Board.Grid.Iterator.GridIterator$$Reset
026a8d20: e00313aa mov      x0, x19
026a8d24: e1031faa mov      x1, xzr
026a8d28: 3e7e1094 bl       #0x2ac8620 ; Royal.Scenes.Game.Mechanics.Board.Grid.Iterator.GridIterator$$MoveNext
026a8d2c: c00100b4 cbz      x0, #0x26a8d64
026a8d30: 680a40f9 ldr      x8, [x19, #0x10]
026a8d34: 480200b4 cbz      x8, #0x26a8d7c
026a8d38: 800640ad ldp      q0, q1, [x20]
026a8d3c: 891a40f9 ldr      x9, [x20, #0x30]
026a8d40: 820ac03d ldr      q2, [x20, #0x20]
026a8d44: 01094329 ldp      w1, w2, [x8, #0x18]
026a8d48: e3030091 mov      x3, sp
026a8d4c: e00315aa mov      x0, x21
026a8d50: e91b00f9 str      x9, [sp, #0x30]
026a8d54: e18b00ad stp      q1, q2, [sp, #0x10]
026a8d58: e003803d str      q0, [sp]
026a8d5c: 45ffff97 bl       #0x26a8a70 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$RemoveTemporaryIncomingExploder
026a8d60: f0ffff17 b        #0x26a8d20
026a8d64: c0020012 and      w0, w22, #1
026a8d68: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
026a8d6c: f55349a9 ldp      x21, x20, [sp, #0x90]
026a8d70: f64340f9 ldr      x22, [sp, #0x80]
026a8d74: ffc30291 add      sp, sp, #0xb0
026a8d78: c0035fd6 ret      
026a8d7c: ab21a497 bl       #0xfb1428
