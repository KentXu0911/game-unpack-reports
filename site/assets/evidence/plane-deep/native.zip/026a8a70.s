# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$RemoveTemporaryIncomingExploder
# Linear span to next metadata entry; not a complete CFG.
026a8a70: ff8303d1 sub      sp, sp, #0xe0
026a8a74: f46300f9 str      x20, [sp, #0xc0]
026a8a78: f37b0da9 stp      x19, x30, [sp, #0xd0]
026a8a7c: 140c40f9 ldr      x20, [x0, #0x18]
026a8a80: f30303aa mov      x19, x3
026a8a84: e0030291 add      x0, sp, #0x80
026a8a88: e3031faa mov      x3, xzr
026a8a8c: ff4300f9 str      xzr, [sp, #0x80]
026a8a90: 797d1094 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
026a8a94: f40500b4 cbz      x20, #0x26a8b50
026a8a98: e14340f9 ldr      x1, [sp, #0x80]
026a8a9c: e00314aa mov      x0, x20
026a8aa0: e2031faa mov      x2, xzr
026a8aa4: 9bae0294 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
026a8aa8: c00400b4 cbz      x0, #0x26a8b40
026a8aac: f40300aa mov      x20, x0
026a8ab0: 006040f9 ldr      x0, [x0, #0xc0]
026a8ab4: e00400b4 cbz      x0, #0x26a8b50
026a8ab8: e1031faa mov      x1, xzr
026a8abc: ba851094 bl       #0x2aca1a4 ; Royal.Scenes.Game.Mechanics.Board.Cell.StaticItemMediator$$GetTopMostAboveItem
026a8ac0: c00100b4 cbz      x0, #0x26a8af8
026a8ac4: 681a40f9 ldr      x8, [x19, #0x30]
026a8ac8: 618240ad ldp      q1, q0, [x19, #0x10]
026a8acc: 6202c03d ldr      q2, [x19]
026a8ad0: e83b00f9 str      x8, [sp, #0x70]
026a8ad4: e18302ad stp      q1, q0, [sp, #0x50]
026a8ad8: e213803d str      q2, [sp, #0x40]
026a8adc: 090040f9 ldr      x9, [x0]
026a8ae0: 2a8542f9 ldr      x10, [x9, #0x508]
026a8ae4: e20704ad stp      q2, q1, [sp, #0x80]
026a8ae8: e02b803d str      q0, [sp, #0xa0]
026a8aec: e85b00f9 str      x8, [sp, #0xb0]
026a8af0: 228942f9 ldr      x2, [x9, #0x510]
026a8af4: 11000014 b        #0x26a8b38
026a8af8: e00314aa mov      x0, x20
026a8afc: e1031faa mov      x1, xzr
026a8b00: e67f1094 bl       #0x2ac8a98 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_TargetItem
026a8b04: e00100b4 cbz      x0, #0x26a8b40
026a8b08: 681a40f9 ldr      x8, [x19, #0x30]
026a8b0c: 618240ad ldp      q1, q0, [x19, #0x10]
026a8b10: 6202c03d ldr      q2, [x19]
026a8b14: e81b00f9 str      x8, [sp, #0x30]
026a8b18: e18300ad stp      q1, q0, [sp, #0x10]
026a8b1c: e203803d str      q2, [sp]
026a8b20: 090040f9 ldr      x9, [x0]
026a8b24: 2a7d42f9 ldr      x10, [x9, #0x4f8]
026a8b28: e20704ad stp      q2, q1, [sp, #0x80]
026a8b2c: e02b803d str      q0, [sp, #0xa0]
026a8b30: e85b00f9 str      x8, [sp, #0xb0]
026a8b34: 228142f9 ldr      x2, [x9, #0x500]
026a8b38: e1030291 add      x1, sp, #0x80
026a8b3c: 40013fd6 blr      x10
026a8b40: f37b4da9 ldp      x19, x30, [sp, #0xd0]
026a8b44: f46340f9 ldr      x20, [sp, #0xc0]
026a8b48: ff830391 add      sp, sp, #0xe0
026a8b4c: c0035fd6 ret      
026a8b50: 3622a497 bl       #0xfb1428
