# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$TryAddGoalHitWithMaster
# Linear span to next metadata entry; not a complete CFG.
026a7b20: f75bbda9 stp      x23, x22, [sp, #-0x30]!
026a7b24: f55301a9 stp      x21, x20, [sp, #0x10]
026a7b28: f37b02a9 stp      x19, x30, [sp, #0x20]
026a7b2c: d77601b0 adrp     x23, #0x5580000
026a7b30: e8824139 ldrb     w8, [x23, #0x60]
026a7b34: f303032a mov      w19, w3
026a7b38: f403022a mov      w20, w2
026a7b3c: f603012a mov      w22, w1
026a7b40: f50300aa mov      x21, x0
026a7b44: c8000037 tbnz     w8, #0, #0x26a7b5c
026a7b48: a05901f0 adrp     x0, #0x51de000
026a7b4c: 007842f9 ldr      x0, [x0, #0x4f0]
026a7b50: ec25a497 bl       #0xfb1300
026a7b54: 28008052 mov      w8, #1
026a7b58: e8820139 strb     w8, [x23, #0x60]
026a7b5c: e00315aa mov      x0, x21
026a7b60: e103162a mov      w1, w22
026a7b64: 15000094 bl       #0x26a7bb8 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$HasMasterId
026a7b68: a0000036 tbz      w0, #0, #0x26a7b7c
026a7b6c: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a7b70: f55341a9 ldp      x21, x20, [sp, #0x10]
026a7b74: f75bc3a8 ldp      x23, x22, [sp], #0x30
026a7b78: c0035fd6 ret      
026a7b7c: a01e40f9 ldr      x0, [x21, #0x38]
026a7b80: a00100b4 cbz      x0, #0x26a7bb4
026a7b84: a85901f0 adrp     x8, #0x51de000
026a7b88: 087942f9 ldr      x8, [x8, #0x4f0]
026a7b8c: e103162a mov      w1, w22
026a7b90: 020140f9 ldr      x2, [x8]
026a7b94: 20870e94 bl       #0x2a49814 ; System.Collections.Generic.HashSet<int>$$Add
026a7b98: e00315aa mov      x0, x21
026a7b9c: e103142a mov      w1, w20
026a7ba0: e203132a mov      w2, w19
026a7ba4: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a7ba8: f55341a9 ldp      x21, x20, [sp, #0x10]
026a7bac: f75bc3a8 ldp      x23, x22, [sp], #0x30
026a7bb0: 18000014 b        #0x26a7c10 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddGoalHit
026a7bb4: 1d26a497 bl       #0xfb1428
