# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$ArrangeComboExpandPosition
# Linear span to next metadata entry; not a complete CFG.
0339b1ac: ff4302d1 sub      sp, sp, #0x90
0339b1b0: eb2b056d stp      d11, d10, [sp, #0x50]
0339b1b4: e923066d stp      d9, d8, [sp, #0x60]
0339b1b8: f55307a9 stp      x21, x20, [sp, #0x70]
0339b1bc: f37b08a9 stp      x19, x30, [sp, #0x80]
0339b1c0: 540f01f0 adrp     x20, #0x5586000
0339b1c4: 88a26639 ldrb     w8, [x20, #0x9a8]
0339b1c8: f30300aa mov      x19, x0
0339b1cc: c8000037 tbnz     w8, #0, #0x339b1e4
0339b1d0: 80f400d0 adrp     x0, #0x522d000
0339b1d4: 008444f9 ldr      x0, [x0, #0x908]
0339b1d8: 4a587097 bl       #0xfb1300
0339b1dc: 28008052 mov      w8, #1
0339b1e0: 88a22639 strb     w8, [x20, #0x9a8]
0339b1e4: 603640f9 ldr      x0, [x19, #0x68]
0339b1e8: 401900b4 cbz      x0, #0x339b510
0339b1ec: e1031faa mov      x1, xzr
0339b1f0: c1ba2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339b1f4: 662240bd ldr      s6, [x19, #0x20]
0339b1f8: 68560090 adrp     x8, #0x3e67000
0339b1fc: 044144bd ldr      s4, [x8, #0x440]
0339b200: 05102d1e fmov     s5, #0.75000000
0339b204: 481ca24e mov      v8.16b, v2.16b
0339b208: 02102e1e fmov     s2, #1.00000000
0339b20c: 632e40bd ldr      s3, [x19, #0x2c]
0339b210: c618251e fdiv     s6, s6, s5
0339b214: 653640bd ldr      s5, [x19, #0x34]
0339b218: c658221e fmin     s6, s6, s2
0339b21c: c618241e fdiv     s6, s6, s4
0339b220: e403271e fmov     s4, wzr
0339b224: c258221e fmin     s2, s6, s2
0339b228: c820201e fcmp     s6, #0.0
0339b22c: 425c241e fcsel    s2, s2, s4, pl
0339b230: a438231e fsub     s4, s5, s3
0339b234: 8208221e fmul     s2, s4, s2
0339b238: 0690231e fmov     s6, #7.00000000
0339b23c: 6228221e fadd     s2, s3, s2
0339b240: 4208261e fmul     s2, s2, s6
0339b244: 621e00bd str      s2, [x19, #0x1c]
0339b248: f40e0190 adrp     x20, #0x5577000
0339b24c: 69c24afc ldur     d9, [x19, #0xac]
0339b250: 88fa7f39 ldrb     w8, [x20, #0xffe]
0339b254: 6bb640bd ldr      s11, [x19, #0xb4]
0339b258: e00701ad stp      q0, q1, [sp, #0x20]
0339b25c: 20040c6e mov      v0.s[1], v1.s[0]
0339b260: 08010035 cbnz     w8, #0x339b280
0339b264: 20f300b0 adrp     x0, #0x5200000
0339b268: 008c46f9 ldr      x0, [x0, #0xd18]
0339b26c: e013803d str      q0, [sp, #0x40]
0339b270: 24587097 bl       #0xfb1300
0339b274: e013c03d ldr      q0, [sp, #0x40]
0339b278: 28008052 mov      w8, #1
0339b27c: 88fa3f39 strb     w8, [x20, #0xffe]
0339b280: 35f300b0 adrp     x21, #0x5200000
0339b284: b58e46f9 ldr      x21, [x21, #0xd18]
0339b288: 2ad5a00e fsub     v10.2s, v9.2s, v0.2s
0339b28c: 6939281e fsub     s9, s11, s8
0339b290: a00240f9 ldr      x0, [x21]
0339b294: 08e040b9 ldr      w8, [x0, #0xe0]
0339b298: 48000035 cbnz     w8, #0x339b2a0
0339b29c: 5a587097 bl       #0xfb1404
0339b2a0: c8560090 adrp     x8, #0x3e73000
0339b2a4: 40dd2a2e fmul     v0.2s, v10.2s, v10.2s
0339b2a8: 01894bbd ldr      s1, [x8, #0xb88]
0339b2ac: 00d8307e faddp    s0, v0.2s
0339b2b0: 2209291e fmul     s2, s9, s9
0339b2b4: 4028201e fadd     s0, s2, s0
0339b2b8: 02c0211e fsqrt    s2, s0
0339b2bc: 4020211e fcmp     s2, s1
0339b2c0: e213803d str      q2, [sp, #0x40]
0339b2c4: ad000054 b.le     #0x339b2d8
0339b2c8: 4004040e dup      v0.2s, v2.s[0]
0339b2cc: 4afd202e fdiv     v10.2s, v10.2s, v0.2s
0339b2d0: 2919221e fdiv     s9, s9, s2
0339b2d4: 0f000014 b        #0x339b310
0339b2d8: d40e01f0 adrp     x20, #0x5576000
0339b2dc: 88b27c39 ldrb     w8, [x20, #0xf2c]
0339b2e0: c8000035 cbnz     w8, #0x339b2f8
0339b2e4: 80f40090 adrp     x0, #0x522b000
0339b2e8: 00ac43f9 ldr      x0, [x0, #0x758]
0339b2ec: 05587097 bl       #0xfb1300
0339b2f0: 28008052 mov      w8, #1
0339b2f4: 88b23c39 strb     w8, [x20, #0xf2c]
0339b2f8: 88f40090 adrp     x8, #0x522b000
0339b2fc: 08ad43f9 ldr      x8, [x8, #0x758]
0339b300: 080140f9 ldr      x8, [x8]
0339b304: 085d40f9 ldr      x8, [x8, #0xb8]
0339b308: 0a0140fd ldr      d10, [x8]
0339b30c: 090940bd ldr      s9, [x8, #8]
0339b310: 6b1e40bd ldr      s11, [x19, #0x1c]
0339b314: e0031faa mov      x0, xzr
0339b318: aed4ce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
0339b31c: 743640f9 ldr      x20, [x19, #0x68]
0339b320: 6009201e fmul     s0, s11, s0
0339b324: 4191800f fmul     v1.2s, v10.2s, v0.s[0]
0339b328: 2009201e fmul     s0, s9, s0
0339b32c: 612a00fd str      d1, [x19, #0x50]
0339b330: 605a00bd str      s0, [x19, #0x58]
0339b334: f40e00b4 cbz      x20, #0x339b510
0339b338: e00314aa mov      x0, x20
0339b33c: e1031faa mov      x1, xzr
0339b340: 6dba2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339b344: 63124a2d ldp      s3, s4, [x19, #0x50]
0339b348: 655a40bd ldr      s5, [x19, #0x58]
0339b34c: e00314aa mov      x0, x20
0339b350: e1031faa mov      x1, xzr
0339b354: 0028231e fadd     s0, s0, s3
0339b358: 2128241e fadd     s1, s1, s4
0339b35c: 4228251e fadd     s2, s2, s5
0339b360: 8dba2594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
0339b364: f40e0190 adrp     x20, #0x5577000
0339b368: 881a6039 ldrb     w8, [x20, #0x806]
0339b36c: c8000035 cbnz     w8, #0x339b384
0339b370: 20f300b0 adrp     x0, #0x5200000
0339b374: 008c46f9 ldr      x0, [x0, #0xd18]
0339b378: e2577097 bl       #0xfb1300
0339b37c: 28008052 mov      w8, #1
0339b380: 881a2039 strb     w8, [x20, #0x806]
0339b384: a00240f9 ldr      x0, [x21]
0339b388: 6b2a4a2d ldp      s11, s10, [x19, #0x50]
0339b38c: 695a40bd ldr      s9, [x19, #0x58]
0339b390: 08e040b9 ldr      w8, [x0, #0xe0]
0339b394: 68000034 cbz      w8, #0x339b3a0
0339b398: e8031f2a mov      w8, wzr
0339b39c: 05000014 b        #0x339b3b0
0339b3a0: 19587097 bl       #0xfb1404
0339b3a4: 881a6039 ldrb     w8, [x20, #0x806]
0339b3a8: 1f010071 cmp      w8, #0
0339b3ac: e8179f1a cset     w8, eq
0339b3b0: 60092b1e fmul     s0, s11, s11
0339b3b4: 41092a1e fmul     s1, s10, s10
0339b3b8: 0028211e fadd     s0, s0, s1
0339b3bc: 2109291e fmul     s1, s9, s9
0339b3c0: 0928211e fadd     s9, s0, s1
0339b3c4: c8000034 cbz      w8, #0x339b3dc
0339b3c8: 20f300b0 adrp     x0, #0x5200000
0339b3cc: 008c46f9 ldr      x0, [x0, #0xd18]
0339b3d0: cc577097 bl       #0xfb1300
0339b3d4: 28008052 mov      w8, #1
0339b3d8: 881a2039 strb     w8, [x20, #0x806]
0339b3dc: a00240f9 ldr      x0, [x21]
0339b3e0: e013c03d ldr      q0, [sp, #0x40]
0339b3e4: 29c1211e fsqrt    s9, s9
0339b3e8: 08e040b9 ldr      w8, [x0, #0xe0]
0339b3ec: 68000035 cbnz     w8, #0x339b3f8
0339b3f0: 05587097 bl       #0xfb1404
0339b3f4: e013c03d ldr      q0, [sp, #0x40]
0339b3f8: 2021201e fcmp     s9, s0
0339b3fc: 0c010054 b.gt     #0x339b41c
0339b400: 68560090 adrp     x8, #0x3e67000
0339b404: 024944bd ldr      s2, [x8, #0x448]
0339b408: 201da94e mov      v0.16b, v9.16b
0339b40c: e113c03d ldr      q1, [sp, #0x40]
0339b410: e0031faa mov      x0, xzr
0339b414: 4c8dfb97 bl       #0x327e944 ; Royal.Infrastructure.Utils.Math.NumberExtensions$$Approximately
0339b418: 20020036 tbz      w0, #0, #0x339b45c
0339b41c: e0031faa mov      x0, xzr
0339b420: 02dece97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339b424: 6a560090 adrp     x10, #0x3e67000
0339b428: 60aa00bd str      s0, [x19, #0xa8]
0339b42c: 602a40fd ldr      d0, [x19, #0x50]
0339b430: 615a40bd ldr      s1, [x19, #0x58]
0339b434: 42fd44bd ldr      s2, [x10, #0x4fc]
0339b438: 49339352 mov      w9, #0x999a
0339b43c: 29e3a772 movk     w9, #0x3f19, lsl #16
0339b440: 230d040e dup      v3.2s, w9
0339b444: 48008052 mov      w8, #2
0339b448: 00dc232e fmul     v0.2s, v0.2s, v3.2s
0339b44c: 2108221e fmul     s1, s1, s2
0339b450: 687a00b9 str      w8, [x19, #0x78]
0339b454: 602a00fd str      d0, [x19, #0x50]
0339b458: 615a00bd str      s1, [x19, #0x58]
0339b45c: 881a6039 ldrb     w8, [x20, #0x806]
0339b460: c8000035 cbnz     w8, #0x339b478
0339b464: 20f300b0 adrp     x0, #0x5200000
0339b468: 008c46f9 ldr      x0, [x0, #0xd18]
0339b46c: a5577097 bl       #0xfb1300
0339b470: 28008052 mov      w8, #1
0339b474: 881a2039 strb     w8, [x20, #0x806]
0339b478: a00240f9 ldr      x0, [x21]
0339b47c: 08e040b9 ldr      w8, [x0, #0xe0]
0339b480: 48000035 cbnz     w8, #0x339b488
0339b484: e0577097 bl       #0xfb1404
0339b488: e00313aa mov      x0, x19
0339b48c: e013c03d ldr      q0, [sp, #0x40]
0339b490: c8f8ff97 bl       #0x33997b0 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$ArrangeScale
0339b494: 603640f9 ldr      x0, [x19, #0x68]
0339b498: c00300b4 cbz      x0, #0x339b510
0339b49c: 93f400d0 adrp     x19, #0x522d000
0339b4a0: 738644f9 ldr      x19, [x19, #0x908]
0339b4a4: e1031faa mov      x1, xzr
0339b4a8: 13ba2594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339b4ac: 600240f9 ldr      x0, [x19]
0339b4b0: 091ca04e mov      v9.16b, v0.16b
0339b4b4: 2a1ca14e mov      v10.16b, v1.16b
0339b4b8: 4b1ca24e mov      v11.16b, v2.16b
0339b4bc: 08e040b9 ldr      w8, [x0, #0xe0]
0339b4c0: 48000035 cbnz     w8, #0x339b4c8
0339b4c4: d0577097 bl       #0xfb1404
0339b4c8: 0814a852 mov      w8, #0x40a00000
0339b4cc: 09f0e7d2 mov      x9, #0x3f80000000000000
0339b4d0: 0af0a752 mov      w10, #0x3f800000
0339b4d4: e00741ad ldp      q0, q1, [sp, #0x20]
0339b4d8: 021da84e mov      v2.16b, v8.16b
0339b4dc: 231da94e mov      v3.16b, v9.16b
0339b4e0: 441daa4e mov      v4.16b, v10.16b
0339b4e4: 651dab4e mov      v5.16b, v11.16b
0339b4e8: e0031faa mov      x0, xzr
0339b4ec: e81300b9 str      w8, [sp, #0x10]
0339b4f0: ea2700a9 stp      x10, x9, [sp]
0339b4f4: d0912594 bl       #0x3cffc34 ; UnityEngine.Debug$$DrawLine
0339b4f8: f37b48a9 ldp      x19, x30, [sp, #0x80]
0339b4fc: f55347a9 ldp      x21, x20, [sp, #0x70]
0339b500: e923466d ldp      d9, d8, [sp, #0x60]
0339b504: eb2b456d ldp      d11, d10, [sp, #0x50]
0339b508: ff430291 add      sp, sp, #0x90
0339b50c: c0035fd6 ret      
0339b510: c6577097 bl       #0xfb1428
