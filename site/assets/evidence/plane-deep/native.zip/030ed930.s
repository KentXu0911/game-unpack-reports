# Royal.Scenes.Game.Mechanics.Items.Config.StaticItemModel$$GetSpecialItemExplodeScore
# Linear span to next metadata entry; not a complete CFG.
030ed930: 21010036 tbz      w1, #0, #0x30ed954
030ed934: a80b9352 mov      w8, #0x985d
030ed938: e8fcbf72 movk     w8, #0xffe7, lsl #16
030ed93c: 49da8b52 mov      w9, #0x5ed2
030ed940: 5f000072 tst      w2, #1
030ed944: 6800080b add      w8, w3, w8
030ed948: 4900a072 movk     w9, #2, lsl #16
030ed94c: 2011881a csel     w0, w9, w8, ne
030ed950: c0035fd6 ret      
030ed954: 60158e52 mov      w0, #0x70ab
030ed958: 4000a072 movk     w0, #2, lsl #16
030ed95c: c0035fd6 ret      
