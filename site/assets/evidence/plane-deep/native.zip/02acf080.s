# Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$ShouldInvalidateCacheForNonSingleExploder
# Linear span to next metadata entry; not a complete CFG.
02acf080: f40f1ef8 str      x20, [sp, #-0x20]!
02acf084: f37b01a9 stp      x19, x30, [sp, #0x10]
02acf088: f403012a mov      w20, w1
02acf08c: f30300aa mov      x19, x0
02acf090: 21000094 bl       #0x2acf114 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$IsThereAnyExplodeCacheInvalidatingOperation
02acf094: 60000036 tbz      w0, #0, #0x2acf0a0
02acf098: 20008052 mov      w0, #1
02acf09c: 1a000014 b        #0x2acf104
02acf0a0: e003142a mov      w0, w20
02acf0a4: e1031faa mov      x1, xzr
02acf0a8: 41d62294 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02acf0ac: a0020036 tbz      w0, #0, #0x2acf100
02acf0b0: 681240f9 ldr      x8, [x19, #0x20]
02acf0b4: e80200b4 cbz      x8, #0x2acf110
02acf0b8: 000940f9 ldr      x0, [x8, #0x10]
02acf0bc: a00200b4 cbz      x0, #0x2acf110
02acf0c0: e1031faa mov      x1, xzr
02acf0c4: 6edbf197 bl       #0x2745e7c ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$HasCurrentItem
02acf0c8: c0010036 tbz      w0, #0, #0x2acf100
02acf0cc: 681240f9 ldr      x8, [x19, #0x20]
02acf0d0: 080200b4 cbz      x8, #0x2acf110
02acf0d4: 000940f9 ldr      x0, [x8, #0x10]
02acf0d8: c00100b4 cbz      x0, #0x2acf110
02acf0dc: e1031faa mov      x1, xzr
02acf0e0: 60dbf197 bl       #0x2745e60 ; Royal.Scenes.Game.Mechanics.Board.Cell.Mediator.CellMediator$$get_CurrentItem
02acf0e4: 600100b4 cbz      x0, #0x2acf110
02acf0e8: 080040f9 ldr      x8, [x0]
02acf0ec: f37b41a9 ldp      x19, x30, [sp, #0x10]
02acf0f0: 020d44f9 ldr      x2, [x8, #0x818]
02acf0f4: 011144f9 ldr      x1, [x8, #0x820]
02acf0f8: f40742f8 ldr      x20, [sp], #0x20
02acf0fc: 40001fd6 br       x2
02acf100: e0031f2a mov      w0, wzr
02acf104: f37b41a9 ldp      x19, x30, [sp, #0x10]
02acf108: f40742f8 ldr      x20, [sp], #0x20
02acf10c: c0035fd6 ret      
02acf110: c6889397 bl       #0xfb1428
