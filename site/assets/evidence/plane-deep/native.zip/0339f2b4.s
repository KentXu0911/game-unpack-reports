# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeSteadyFlightPosition
# Linear span to next metadata entry; not a complete CFG.
0339f2b4: ff0302d1 sub      sp, sp, #0x80
0339f2b8: ef3b016d stp      d15, d14, [sp, #0x10]
0339f2bc: ed33026d stp      d13, d12, [sp, #0x20]
0339f2c0: eb2b036d stp      d11, d10, [sp, #0x30]
0339f2c4: e923046d stp      d9, d8, [sp, #0x40]
0339f2c8: f75b05a9 stp      x23, x22, [sp, #0x50]
0339f2cc: f55306a9 stp      x21, x20, [sp, #0x60]
0339f2d0: f37b07a9 stp      x19, x30, [sp, #0x70]
0339f2d4: 340f01f0 adrp     x20, #0x5586000
0339f2d8: 88e66639 ldrb     w8, [x20, #0x9b9]
0339f2dc: 691ca34e mov      v9.16b, v3.16b
0339f2e0: 481ca24e mov      v8.16b, v2.16b
0339f2e4: f30300aa mov      x19, x0
0339f2e8: e007012d stp      s0, s1, [sp, #8]
0339f2ec: e8010037 tbnz     w8, #0, #0x339f328
0339f2f0: 00f400f0 adrp     x0, #0x5222000
0339f2f4: 00ec42f9 ldr      x0, [x0, #0x5d8]
0339f2f8: 02487097 bl       #0xfb1300
0339f2fc: 80f40090 adrp     x0, #0x522f000
0339f300: 000445f9 ldr      x0, [x0, #0xa08]
0339f304: ff477097 bl       #0xfb1300
0339f308: 00f300b0 adrp     x0, #0x5200000
0339f30c: 008c46f9 ldr      x0, [x0, #0xd18]
0339f310: fc477097 bl       #0xfb1300
0339f314: 00f300d0 adrp     x0, #0x5201000
0339f318: 002044f9 ldr      x0, [x0, #0x840]
0339f31c: f9477097 bl       #0xfb1300
0339f320: 28008052 mov      w8, #1
0339f324: 88e62639 strb     w8, [x20, #0x9b9]
0339f328: 753240f9 ldr      x21, [x19, #0x60]
0339f32c: 352b00b4 cbz      x21, #0x339f890
0339f330: 8af40090 adrp     x10, #0x522f000
0339f334: a80240f9 ldr      x8, [x21]
0339f338: 4a0545f9 ldr      x10, [x10, #0xa08]
0339f33c: 747240f9 ldr      x20, [x19, #0xe0]
0339f340: 09554279 ldrh     w9, [x8, #0x12a]
0339f344: 410140f9 ldr      x1, [x10]
0339f348: 290100b4 cbz      x9, #0x339f36c
0339f34c: 0a5940f9 ldr      x10, [x8, #0xb0]
0339f350: 4a210091 add      x10, x10, #8
0339f354: 4b815ff8 ldur     x11, [x10, #-8]
0339f358: 7f0101eb cmp      x11, x1
0339f35c: 00010054 b.eq     #0x339f37c
0339f360: 290500f1 subs     x9, x9, #1
0339f364: 4a410091 add      x10, x10, #0x10
0339f368: 61ffff54 b.ne     #0x339f354
0339f36c: 22008052 mov      w2, #1
0339f370: e00315aa mov      x0, x21
0339f374: d8876f97 bl       #0xf812d4
0339f378: 05000014 b        #0x339f38c
0339f37c: 490140b9 ldr      w9, [x10]
0339f380: 29050011 add      w9, w9, #1
0339f384: 08d1298b add      x8, x8, w9, sxtw #4
0339f388: 00e10491 add      x0, x8, #0x138
0339f38c: 080440a9 ldp      x8, x1, [x0]
0339f390: e00315aa mov      x0, x21
0339f394: 00013fd6 blr      x8
0339f398: d42700b4 cbz      x20, #0x339f890
0339f39c: e00314aa mov      x0, x20
0339f3a0: e1031faa mov      x1, xzr
0339f3a4: 78af2594 bl       #0x3d0b184 ; UnityEngine.Transform$$InverseTransformPoint
0339f3a8: 602e40f9 ldr      x0, [x19, #0x58]
0339f3ac: 202700b4 cbz      x0, #0x339f890
0339f3b0: 14f300b0 adrp     x20, #0x5200000
0339f3b4: 948e46f9 ldr      x20, [x20, #0xd18]
0339f3b8: e1031faa mov      x1, xzr
0339f3bc: 0e1ca04e mov      v14.16b, v0.16b
0339f3c0: 2c1ca14e mov      v12.16b, v1.16b
0339f3c4: 9aaa2594 bl       #0x3d09e2c ; UnityEngine.Transform$$get_localPosition
0339f3c8: 800240f9 ldr      x0, [x20]
0339f3cc: 6a9240bd ldr      s10, [x19, #0x90]
0339f3d0: 0f1ca04e mov      v15.16b, v0.16b
0339f3d4: e10300bd str      s1, [sp]
0339f3d8: 08e040b9 ldr      w8, [x0, #0xe0]
0339f3dc: 48000035 cbnz     w8, #0x339f3e4
0339f3e0: 09487097 bl       #0xfb1404
0339f3e4: b50e01f0 adrp     x21, #0x5576000
0339f3e8: 6bc240bd ldr      s11, [x19, #0xc0]
0339f3ec: a8b27c39 ldrb     w8, [x21, #0xf2c]
0339f3f0: 6d424cfc ldur     d13, [x19, #0xc4]
0339f3f4: e90700bd str      s9, [sp, #4]
0339f3f8: c8000035 cbnz     w8, #0x339f410
0339f3fc: 60f40090 adrp     x0, #0x522b000
0339f400: 00ac43f9 ldr      x0, [x0, #0x758]
0339f404: bf477097 bl       #0xfb1300
0339f408: 28008052 mov      w8, #1
0339f40c: a8b23c39 strb     w8, [x21, #0xf2c]
0339f410: 76f40090 adrp     x22, #0x522b000
0339f414: d6ae43f9 ldr      x22, [x22, #0x758]
0339f418: c9d5af7e fabd     s9, s14, s15
0339f41c: cfd5aa7e fabd     s15, s14, s10
0339f420: c80240f9 ldr      x8, [x22]
0339f424: 085d40f9 ldr      x8, [x8, #0xb8]
0339f428: 000140bd ldr      s0, [x8]
0339f42c: 014140fc ldur     d1, [x8, #4]
0339f430: a8560090 adrp     x8, #0x3e73000
0339f434: 02314bbd ldr      s2, [x8, #0xb30]
0339f438: 6039201e fsub     s0, s11, s0
0339f43c: a1d5a10e fsub     v1.2s, v13.2s, v1.2s
0339f440: 0008201e fmul     s0, s0, s0
0339f444: 21dc212e fmul     v1.2s, v1.2s, v1.2s
0339f448: 0028211e fadd     s0, s0, s1
0339f44c: 21040c5e mov      s1, v1.s[1]
0339f450: 2028201e fadd     s0, s1, s0
0339f454: 0020221e fcmp     s0, s2
0339f458: 0b102e1e fmov     s11, #1.00000000
0339f45c: 0d103e1e fmov     s13, #-1.00000000
0339f460: 05050054 b.pl     #0x339f500
0339f464: e00b40bd ldr      s0, [sp, #8]
0339f468: 681e40b9 ldr      w8, [x19, #0x1c]
0339f46c: c1392a1e fsub     s1, s14, s10
0339f470: 2820201e fcmp     s1, #0.0
0339f474: 60ce00bd str      s0, [x19, #0xcc]
0339f478: e00f40bd ldr      s0, [sp, #0xc]
0339f47c: 0e1da84e mov      v14.16b, v8.16b
0339f480: 686e00b9 str      w8, [x19, #0x6c]
0339f484: 60221a2d stp      s0, s8, [x19, #0xd0]
0339f488: 0001271e fmov     s0, w8
0339f48c: c0000054 b.eq     #0x339f4a4
0339f490: e0212b1e fcmp     s15, s11
0339f494: 88000054 b.hi     #0x339f4a4
0339f498: 62f240bd ldr      s2, [x19, #0xf0]
0339f49c: 4820201e fcmp     s2, #0.0
0339f4a0: 4c010054 b.gt     #0x339f4c8
0339f4a4: 2820201e fcmp     s1, #0.0
0339f4a8: e103271e fmov     s1, wzr
0339f4ac: 61020054 b.ne     #0x339f4f8
0339f4b0: 62f240bd ldr      s2, [x19, #0xf0]
0339f4b4: 4820201e fcmp     s2, #0.0
0339f4b8: 0d020054 b.le     #0x339f4f8
0339f4bc: 0310231e fmov     s3, #6.00000000
0339f4c0: 4020231e fcmp     s2, s3
0339f4c4: a8010054 b.hi     #0x339f4f8
0339f4c8: 485b00d0 adrp     x8, #0x3f09000
0339f4cc: 49560090 adrp     x9, #0x3e67000
0339f4d0: 038548bd ldr      s3, [x8, #0x884]
0339f4d4: 41282d1e fadd     s1, s2, s13
0339f4d8: 0290241e fmov     s2, #10.00000000
0339f4dc: 24fd44bd ldr      s4, [x9, #0x4fc]
0339f4e0: 2118221e fdiv     s1, s1, s2
0339f4e4: 22582b1e fmin     s2, s1, s11
0339f4e8: 4208231e fmul     s2, s2, s3
0339f4ec: 4228241e fadd     s2, s2, s4
0339f4f0: 2820201e fcmp     s1, #0.0
0339f4f4: 415c241e fcsel    s1, s2, s4, pl
0339f4f8: 61fe00bd str      s1, [x19, #0xfc]
0339f4fc: 03000014 b        #0x339f508
0339f500: 606e40bd ldr      s0, [x19, #0x6c]
0339f504: 0e1da84e mov      v14.16b, v8.16b
0339f508: 610a452d ldp      s1, s2, [x19, #0x28]
0339f50c: 633240bd ldr      s3, [x19, #0x30]
0339f510: e0031faa mov      x0, xzr
0339f514: 17990594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
0339f518: 6496592d ldp      s4, s5, [x19, #0xcc]
0339f51c: 66d640bd ldr      s6, [x19, #0xd4]
0339f520: e0031faa mov      x0, xzr
0339f524: a5960594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
0339f528: 631240bd ldr      s3, [x19, #0x10]
0339f52c: 0410311e fmov     s4, #-3.00000000
0339f530: e60740bd ldr      s6, [sp, #4]
0339f534: 2429241e fadd     s4, s9, s4
0339f538: 0590321e fmov     s5, #-5.00000000
0339f53c: 8418251e fdiv     s4, s4, s5
0339f540: 0590341e fmov     s5, #-10.00000000
0339f544: 8519251e fdiv     s5, s12, s5
0339f548: 6308261e fmul     s3, s3, s6
0339f54c: a5282b1e fadd     s5, s5, s11
0339f550: 0008231e fmul     s0, s0, s3
0339f554: 2108231e fmul     s1, s1, s3
0339f558: a820201e fcmp     s5, #0.0
0339f55c: a5582b1e fmin     s5, s5, s11
0339f560: 84282b1e fadd     s4, s4, s11
0339f564: e603271e fmov     s6, wzr
0339f568: a528251e fadd     s5, s5, s5
0339f56c: 6006182d stp      s0, s1, [x19, #0xc0]
0339f570: 80582b1e fmin     s0, s4, s11
0339f574: 4208231e fmul     s2, s2, s3
0339f578: 0310301e fmov     s3, #-2.00000000
0339f57c: a128261e fadd     s1, s5, s6
0339f580: 0028201e fadd     s0, s0, s0
0339f584: 215c261e fcsel    s1, s1, s6, pl
0339f588: 0028231e fadd     s0, s0, s3
0339f58c: 8820201e fcmp     s4, #0.0
0339f590: 005c231e fcsel    s0, s0, s3, pl
0339f594: e0212b1e fcmp     s15, s11
0339f598: 2028201e fadd     s0, s1, s0
0339f59c: 62ca00bd str      s2, [x19, #0xc8]
0339f5a0: c8000054 b.hi     #0x339f5b8
0339f5a4: 68324139 ldrb     w8, [x19, #0x4c]
0339f5a8: 88000034 cbz      w8, #0x339f5b8
0339f5ac: 48560090 adrp     x8, #0x3e67000
0339f5b0: 018d44bd ldr      s1, [x8, #0x48c]
0339f5b4: 07000014 b        #0x339f5d0
0339f5b8: 605640f9 ldr      x0, [x19, #0xa8]
0339f5bc: a01600b4 cbz      x0, #0x339f890
0339f5c0: 01282b1e fadd     s1, s0, s11
0339f5c4: e1031faa mov      x1, xzr
0339f5c8: 283bcf97 bl       #0x276e268 ; Royal.Infrastructure.Utils.Randoming.RandomManager$$Next
0339f5cc: 61fe40bd ldr      s1, [x19, #0xfc]
0339f5d0: 0028211e fadd     s0, s0, s1
0339f5d4: e10340bd ldr      s1, [sp]
0339f5d8: 8029201e fadd     s0, s12, s0
0339f5dc: 0020211e fcmp     s0, s1
0339f5e0: 6d070054 b.le     #0x339f6cc
0339f5e4: 602e40f9 ldr      x0, [x19, #0x58]
0339f5e8: 401500b4 cbz      x0, #0x339f890
0339f5ec: e1031faa mov      x1, xzr
0339f5f0: 691dab4e mov      v9.16b, v11.16b
0339f5f4: a81dad4e mov      v8.16b, v13.16b
0339f5f8: bfa92594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339f5fc: 602e40f9 ldr      x0, [x19, #0x58]
0339f600: 801400b4 cbz      x0, #0x339f890
0339f604: 0b1ca04e mov      v11.16b, v0.16b
0339f608: 2c1ca14e mov      v12.16b, v1.16b
0339f60c: 4d1ca24e mov      v13.16b, v2.16b
0339f610: 6006582d ldp      s0, s1, [x19, #0xc0]
0339f614: 62ca40bd ldr      s2, [x19, #0xc8]
0339f618: e1031faa mov      x1, xzr
0339f61c: 6029201e fadd     s0, s11, s0
0339f620: 8129211e fadd     s1, s12, s1
0339f624: a229221e fadd     s2, s13, s2
0339f628: dba92594 bl       #0x3d09d94 ; UnityEngine.Transform$$set_position
0339f62c: 602e40f9 ldr      x0, [x19, #0x58]
0339f630: 001300b4 cbz      x0, #0x339f890
0339f634: e1031faa mov      x1, xzr
0339f638: afa92594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
0339f63c: 8021211e fcmp     s12, s1
0339f640: 05010054 b.pl     #0x339f660
0339f644: e00313aa mov      x0, x19
0339f648: 601dab4e mov      v0.16b, v11.16b
0339f64c: 811dac4e mov      v1.16b, v12.16b
0339f650: a21dad4e mov      v2.16b, v13.16b
0339f654: a0000094 bl       #0x339f8d4 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$ArrangeRotation
0339f658: 20008052 mov      w0, #1
0339f65c: 84000014 b        #0x339f86c
0339f660: 08f400f0 adrp     x8, #0x5222000
0339f664: 08ed42f9 ldr      x8, [x8, #0x5d8]
0339f668: 170140f9 ldr      x23, [x8]
0339f66c: e81e40f9 ldr      x8, [x23, #0x38]
0339f670: 000140f9 ldr      x0, [x8]
0339f674: 08c84439 ldrb     w8, [x0, #0x132]
0339f678: 48000037 tbnz     w8, #0, #0x339f680
0339f67c: 5a866f97 bl       #0xf80fe4
0339f680: 08e040b9 ldr      w8, [x0, #0xe0]
0339f684: 0d1da84e mov      v13.16b, v8.16b
0339f688: 2b1da94e mov      v11.16b, v9.16b
0339f68c: 48000035 cbnz     w8, #0x339f694
0339f690: 5d477097 bl       #0xfb1404
0339f694: e81e40f9 ldr      x8, [x23, #0x38]
0339f698: 17f300d0 adrp     x23, #0x5201000
0339f69c: 000140f9 ldr      x0, [x8]
0339f6a0: 08c84439 ldrb     w8, [x0, #0x132]
0339f6a4: f72244f9 ldr      x23, [x23, #0x840]
0339f6a8: 48000037 tbnz     w8, #0, #0x339f6b0
0339f6ac: 4e866f97 bl       #0xf80fe4
0339f6b0: 085c40f9 ldr      x8, [x0, #0xb8]
0339f6b4: e20240f9 ldr      x2, [x23]
0339f6b8: 61018052 mov      w1, #0xb
0339f6bc: e00313aa mov      x0, x19
0339f6c0: 030140f9 ldr      x3, [x8]
0339f6c4: e4031faa mov      x4, xzr
0339f6c8: 8d86d197 bl       #0x28010fc ; Royal.Infrastructure.Services.Logs.Log$$Error
0339f6cc: e0031faa mov      x0, xzr
0339f6d0: 7ff20239 strb     wzr, [x19, #0xbc]
0339f6d4: 7f1600b9 str      wzr, [x19, #0x14]
0339f6d8: 54cdce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339f6dc: 686240f9 ldr      x8, [x19, #0xc0]
0339f6e0: 69ca40b9 ldr      w9, [x19, #0xc8]
0339f6e4: 601a00bd str      s0, [x19, #0x18]
0339f6e8: d70e0190 adrp     x23, #0x5577000
0339f6ec: 682200f9 str      x8, [x19, #0x40]
0339f6f0: 694a00b9 str      w9, [x19, #0x48]
0339f6f4: 6922482d ldp      s9, s8, [x19, #0x40]
0339f6f8: e8fa7f39 ldrb     w8, [x23, #0xffe]
0339f6fc: 6a4a40bd ldr      s10, [x19, #0x48]
0339f700: c8000035 cbnz     w8, #0x339f718
0339f704: 00f300b0 adrp     x0, #0x5200000
0339f708: 008c46f9 ldr      x0, [x0, #0xd18]
0339f70c: fd467097 bl       #0xfb1300
0339f710: 28008052 mov      w8, #1
0339f714: e8fa3f39 strb     w8, [x23, #0xffe]
0339f718: 800240f9 ldr      x0, [x20]
0339f71c: 08e040b9 ldr      w8, [x0, #0xe0]
0339f720: 48000035 cbnz     w8, #0x339f728
0339f724: 38477097 bl       #0xfb1404
0339f728: 2009291e fmul     s0, s9, s9
0339f72c: 0109281e fmul     s1, s8, s8
0339f730: a8560090 adrp     x8, #0x3e73000
0339f734: 0028211e fadd     s0, s0, s1
0339f738: 01894bbd ldr      s1, [x8, #0xb88]
0339f73c: 42092a1e fmul     s2, s10, s10
0339f740: 4028201e fadd     s0, s2, s0
0339f744: 00c0211e fsqrt    s0, s0
0339f748: 6f1dab4e mov      v15.16b, v11.16b
0339f74c: 0020211e fcmp     s0, s1
0339f750: ad000054 b.le     #0x339f764
0339f754: 2919201e fdiv     s9, s9, s0
0339f758: 0b19201e fdiv     s11, s8, s0
0339f75c: 4819201e fdiv     s8, s10, s0
0339f760: 0c000014 b        #0x339f790
0339f764: a8b27c39 ldrb     w8, [x21, #0xf2c]
0339f768: c8000035 cbnz     w8, #0x339f780
0339f76c: 60f40090 adrp     x0, #0x522b000
0339f770: 00ac43f9 ldr      x0, [x0, #0x758]
0339f774: e3467097 bl       #0xfb1300
0339f778: 28008052 mov      w8, #1
0339f77c: a8b23c39 strb     w8, [x21, #0xf2c]
0339f780: c80240f9 ldr      x8, [x22]
0339f784: 085d40f9 ldr      x8, [x8, #0xb8]
0339f788: 092d402d ldp      s9, s11, [x8]
0339f78c: 080940bd ldr      s8, [x8, #8]
0339f790: 350f01b0 adrp     x21, #0x5584000
0339f794: a8fe4f39 ldrb     w8, [x21, #0x3ff]
0339f798: c8000035 cbnz     w8, #0x339f7b0
0339f79c: 00f300b0 adrp     x0, #0x5200000
0339f7a0: 008c46f9 ldr      x0, [x0, #0xd18]
0339f7a4: d7467097 bl       #0xfb1300
0339f7a8: 28008052 mov      w8, #1
0339f7ac: a8fe0f39 strb     w8, [x21, #0x3ff]
0339f7b0: 2009291e fmul     s0, s9, s9
0339f7b4: 61092b1e fmul     s1, s11, s11
0339f7b8: 800240f9 ldr      x0, [x20]
0339f7bc: 0028211e fadd     s0, s0, s1
0339f7c0: 0109281e fmul     s1, s8, s8
0339f7c4: 2a28201e fadd     s10, s1, s0
0339f7c8: e007412d ldp      s0, s1, [sp, #8]
0339f7cc: 08e040b9 ldr      w8, [x0, #0xe0]
0339f7d0: 0008201e fmul     s0, s0, s0
0339f7d4: 2108211e fmul     s1, s1, s1
0339f7d8: 0028211e fadd     s0, s0, s1
0339f7dc: c1092e1e fmul     s1, s14, s14
0339f7e0: 2c28201e fadd     s12, s1, s0
0339f7e4: 48000035 cbnz     w8, #0x339f7ec
0339f7e8: 07477097 bl       #0xfb1404
0339f7ec: a8560090 adrp     x8, #0x3e73000
0339f7f0: 018d4bbd ldr      s1, [x8, #0xb8c]
0339f7f4: 80092a1e fmul     s0, s12, s10
0339f7f8: 00c0211e fsqrt    s0, s0
0339f7fc: 0020211e fcmp     s0, s1
0339f800: e103271e fmov     s1, wzr
0339f804: a4020054 b.mi     #0x339f858
0339f808: e10b412d ldp      s1, s2, [sp, #8]
0339f80c: 800240f9 ldr      x0, [x20]
0339f810: 2108291e fmul     s1, s1, s9
0339f814: 42082b1e fmul     s2, s2, s11
0339f818: 2128221e fadd     s1, s1, s2
0339f81c: c209281e fmul     s2, s14, s8
0339f820: 4128211e fadd     s1, s2, s1
0339f824: 08e040b9 ldr      w8, [x0, #0xe0]
0339f828: 2018201e fdiv     s0, s1, s0
0339f82c: 01582f1e fmin     s1, s0, s15
0339f830: 00202d1e fcmp     s0, s13
0339f834: 285c2d1e fcsel    s8, s1, s13, pl
0339f838: 48000035 cbnz     w8, #0x339f840
0339f83c: f2467097 bl       #0xfb1404
0339f840: 00c1221e fcvt     d0, s8
0339f844: 5f8d6497 bl       #0xcc2dc0
0339f848: a8560090 adrp     x8, #0x3e73000
0339f84c: 01914bbd ldr      s1, [x8, #0xb90]
0339f850: 0040621e fcvt     s0, d0
0339f854: 0108211e fmul     s1, s0, s1
0339f858: 48339352 mov      w8, #0x999a
0339f85c: e0031f2a mov      w0, wzr
0339f860: 28d3a772 movk     w8, #0x3e99, lsl #16
0339f864: 611e00bd str      s1, [x19, #0x1c]
0339f868: 682600b9 str      w8, [x19, #0x24]
0339f86c: f37b47a9 ldp      x19, x30, [sp, #0x70]
0339f870: f55346a9 ldp      x21, x20, [sp, #0x60]
0339f874: f75b45a9 ldp      x23, x22, [sp, #0x50]
0339f878: e923446d ldp      d9, d8, [sp, #0x40]
0339f87c: eb2b436d ldp      d11, d10, [sp, #0x30]
0339f880: ed33426d ldp      d13, d12, [sp, #0x20]
0339f884: ef3b416d ldp      d15, d14, [sp, #0x10]
0339f888: ff030291 add      sp, sp, #0x80
0339f88c: c0035fd6 ret      
0339f890: e6467097 bl       #0xfb1428
