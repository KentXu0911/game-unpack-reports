# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$get_ShouldPlaySfxInLoop
# Linear span to next metadata entry; not a complete CFG.
033989dc: 20008052 mov      w0, #1
033989e0: c0035fd6 ret      
