# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy.<FinishOperationWithDelay>d__11$$MoveNext
# Linear span to next metadata entry; not a complete CFG.
033a4624: e80f1efc str      d8, [sp, #-0x20]!
033a4628: f40700f9 str      x20, [sp, #8]
033a462c: f37b01a9 stp      x19, x30, [sp, #0x10]
033a4630: 140f01d0 adrp     x20, #0x5586000
033a4634: 88666739 ldrb     w8, [x20, #0x9d9]
033a4638: f30300aa mov      x19, x0
033a463c: c8000037 tbnz     w8, #0, #0x33a4654
033a4640: 40f200d0 adrp     x0, #0x51ee000
033a4644: 006842f9 ldr      x0, [x0, #0x4d0]
033a4648: 2e337097 bl       #0xfb1300
033a464c: 28008052 mov      w8, #1
033a4650: 88662739 strb     w8, [x20, #0x9d9]
033a4654: 681240b9 ldr      w8, [x19, #0x10]
033a4658: 1f050071 cmp      w8, #1
033a465c: a0020054 b.eq     #0x33a46b0
033a4660: 48040035 cbnz     w8, #0x33a46e8
033a4664: 48f200d0 adrp     x8, #0x51ee000
033a4668: 086942f9 ldr      x8, [x8, #0x4d0]
033a466c: 09008012 mov      w9, #-1
033a4670: 691200b9 str      w9, [x19, #0x10]
033a4674: 682240bd ldr      s8, [x19, #0x20]
033a4678: 000140f9 ldr      x0, [x8]
033a467c: 67337097 bl       #0xfb1418
033a4680: e00300b4 cbz      x0, #0x33a46fc
033a4684: 001da84e mov      v0.16b, v8.16b
033a4688: e1031faa mov      x1, xzr
033a468c: f40300aa mov      x20, x0
033a4690: 694c7f97 bl       #0x1377834 ; Royal.Scenes.Game.Mechanics.Replay.WaitForGameplaySeconds$$.ctor
033a4694: 748e01f8 str      x20, [x19, #0x18]!
033a4698: e00313aa mov      x0, x19
033a469c: e10314aa mov      x1, x20
033a46a0: 03337097 bl       #0xfb12ac
033a46a4: 20008052 mov      w0, #1
033a46a8: 60821fb8 stur     w0, [x19, #-8]
033a46ac: 10000014 b        #0x33a46ec
033a46b0: 601640f9 ldr      x0, [x19, #0x28]
033a46b4: 08008012 mov      w8, #-1
033a46b8: 681200b9 str      w8, [x19, #0x10]
033a46bc: 000200b4 cbz      x0, #0x33a46fc
033a46c0: 080040f9 ldr      x8, [x0]
033a46c4: 131c40f9 ldr      x19, [x0, #0x38]
033a46c8: 097d41f9 ldr      x9, [x8, #0x2f8]
033a46cc: 018141f9 ldr      x1, [x8, #0x300]
033a46d0: 20013fd6 blr      x9
033a46d4: 530100b4 cbz      x19, #0x33a46fc
033a46d8: e103002a mov      w1, w0
033a46dc: e00313aa mov      x0, x19
033a46e0: e2031faa mov      x2, xzr
033a46e4: 5c54da97 bl       #0x2a39854 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$OperationFinish
033a46e8: e0031f2a mov      w0, wzr
033a46ec: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a46f0: f40740f9 ldr      x20, [sp, #8]
033a46f4: e80742fc ldr      d8, [sp], #0x20
033a46f8: c0035fd6 ret      
033a46fc: 4b337097 bl       #0xfb1428
