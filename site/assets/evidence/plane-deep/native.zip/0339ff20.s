# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$get_FlyState
# Linear span to next metadata entry; not a complete CFG.
0339ff20: 006840b9 ldr      w0, [x0, #0x68]
0339ff24: c0035fd6 ret      
