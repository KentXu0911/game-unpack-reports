# Royal.Scenes.Game.Mechanics.Explode.IncomingExploderContainer$$GetIncomingCount
# Linear span to next metadata entry; not a complete CFG.
02d3a4b0: f40f1ef8 str      x20, [sp, #-0x20]!
02d3a4b4: f37b01a9 stp      x19, x30, [sp, #0x10]
02d3a4b8: 544201d0 adrp     x20, #0x5584000
02d3a4bc: 88c25039 ldrb     w8, [x20, #0x430]
02d3a4c0: f30300aa mov      x19, x0
02d3a4c4: c8000037 tbnz     w8, #0, #0x2d3a4dc
02d3a4c8: 802301d0 adrp     x0, #0x51ac000
02d3a4cc: 008844f9 ldr      x0, [x0, #0x910]
02d3a4d0: 8cdb8997 bl       #0xfb1300
02d3a4d4: 28008052 mov      w8, #1
02d3a4d8: 88c21039 strb     w8, [x20, #0x430]
02d3a4dc: 680a40f9 ldr      x8, [x19, #0x10]
02d3a4e0: a80000b4 cbz      x8, #0x2d3a4f4
02d3a4e4: 002140b9 ldr      w0, [x8, #0x20]
02d3a4e8: f37b41a9 ldp      x19, x30, [sp, #0x10]
02d3a4ec: f40742f8 ldr      x20, [sp], #0x20
02d3a4f0: c0035fd6 ret      
02d3a4f4: cddb8997 bl       #0xfb1428
