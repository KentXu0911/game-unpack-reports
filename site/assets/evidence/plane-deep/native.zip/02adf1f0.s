# Royal.Scenes.Game.Mechanics.Items.ClockTowerItem.ClockTowerItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02adf1f0: f40f1ef8 str      x20, [sp, #-0x20]!
02adf1f4: f37b01a9 stp      x19, x30, [sp, #0x10]
02adf1f8: 080040f9 ldr      x8, [x0]
02adf1fc: f303012a mov      w19, w1
02adf200: f40300aa mov      x20, x0
02adf204: 096542f9 ldr      x9, [x8, #0x4c8]
02adf208: 086942f9 ldr      x8, [x8, #0x4d0]
02adf20c: e10308aa mov      x1, x8
02adf210: 20013fd6 blr      x9
02adf214: 40040034 cbz      w0, #0x2adf29c
02adf218: 880240f9 ldr      x8, [x20]
02adf21c: e00314aa mov      x0, x20
02adf220: 096542f9 ldr      x9, [x8, #0x4c8]
02adf224: 016942f9 ldr      x1, [x8, #0x4d0]
02adf228: 20013fd6 blr      x9
02adf22c: f403002a mov      w20, w0
02adf230: e003132a mov      w0, w19
02adf234: e1031faa mov      x1, xzr
02adf238: c1952294 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02adf23c: 00010036 tbz      w0, #0, #0x2adf25c
02adf240: 08229f52 mov      w8, #0xf910
02adf244: 494d8f52 mov      w9, #0x7a6a
02adf248: 9f060071 cmp      w20, #1
02adf24c: c800a072 movk     w8, #6, lsl #16
02adf250: 4902a072 movk     w9, #0x12, lsl #16
02adf254: 2001881a csel     w0, w9, w8, eq
02adf258: 11000014 b        #0x2adf29c
02adf25c: e003132a mov      w0, w19
02adf260: e1031faa mov      x1, xzr
02adf264: 48ae2294 bl       #0x338ab84 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsVerticalLineExploder
02adf268: 80000036 tbz      w0, #0, #0x2adf278
02adf26c: 40c19452 mov      w0, #0xa60a
02adf270: 8000a072 movk     w0, #4, lsl #16
02adf274: 0a000014 b        #0x2adf29c
02adf278: e003132a mov      w0, w19
02adf27c: e1031faa mov      x1, xzr
02adf280: cb952294 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02adf284: 08229f52 mov      w8, #0xf910
02adf288: a9608a52 mov      w9, #0x5305
02adf28c: 1f000072 tst      w0, #1
02adf290: c800a072 movk     w8, #6, lsl #16
02adf294: 4900a072 movk     w9, #2, lsl #16
02adf298: 2011881a csel     w0, w9, w8, ne
02adf29c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02adf2a0: f40742f8 ldr      x20, [sp], #0x20
02adf2a4: c0035fd6 ret      
