# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$TargetReached
# Linear span to next metadata entry; not a complete CFG.
03399ec4: f40f1ef8 str      x20, [sp, #-0x20]!
03399ec8: f37b01a9 stp      x19, x30, [sp, #0x10]
03399ecc: f30300aa mov      x19, x0
03399ed0: 003040f9 ldr      x0, [x0, #0x60]
03399ed4: 7f7a00b9 str      wzr, [x19, #0x78]
03399ed8: c00200b4 cbz      x0, #0x3399f30
03399edc: 81000036 tbz      w1, #0, #0x3399eec
03399ee0: e1031faa mov      x1, xzr
03399ee4: 56bf0b94 bl       #0x3689c3c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$TriggerFakeTargetReached
03399ee8: 03000014 b        #0x3399ef4
03399eec: e1031faa mov      x1, xzr
03399ef0: 2ebf0b94 bl       #0x3689ba8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$TriggerTargetReached
03399ef4: 680240f9 ldr      x8, [x19]
03399ef8: 743240f9 ldr      x20, [x19, #0x60]
03399efc: e00313aa mov      x0, x19
03399f00: 096541f9 ldr      x9, [x8, #0x2c8]
03399f04: 016941f9 ldr      x1, [x8, #0x2d0]
03399f08: 20013fd6 blr      x9
03399f0c: 340100b4 cbz      x20, #0x3399f30
03399f10: 880240f9 ldr      x8, [x20]
03399f14: f37b41a9 ldp      x19, x30, [sp, #0x10]
03399f18: 01000012 and      w1, w0, #1
03399f1c: e00314aa mov      x0, x20
03399f20: 033542f9 ldr      x3, [x8, #0x468]
03399f24: 023942f9 ldr      x2, [x8, #0x470]
03399f28: f40742f8 ldr      x20, [sp], #0x20
03399f2c: 60001fd6 br       x3
03399f30: 3e5d7097 bl       #0xfb1428
