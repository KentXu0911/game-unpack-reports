# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$IsTntOrRocketCombo
# Linear span to next metadata entry; not a complete CFG.
033a2ff8: e0031f2a mov      w0, wzr
033a2ffc: c0035fd6 ret      
