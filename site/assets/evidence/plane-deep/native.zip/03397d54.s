# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$CreateItemPools
# Linear span to next metadata entry; not a complete CFG.
03397d54: f963bca9 stp      x25, x24, [sp, #-0x40]!
03397d58: f75b01a9 stp      x23, x22, [sp, #0x10]
03397d5c: f55302a9 stp      x21, x20, [sp, #0x20]
03397d60: f37b03a9 stp      x19, x30, [sp, #0x30]
03397d64: 760f01f0 adrp     x22, #0x5586000
03397d68: c8466639 ldrb     w8, [x22, #0x991]
03397d6c: f503022a mov      w21, w2
03397d70: f30301aa mov      x19, x1
03397d74: f40300aa mov      x20, x0
03397d78: e8010037 tbnz     w8, #0, #0x3397db4
03397d7c: 20f000d0 adrp     x0, #0x519d000
03397d80: 001846f9 ldr      x0, [x0, #0xc30]
03397d84: 5f657097 bl       #0xfb1300
03397d88: a0f400d0 adrp     x0, #0x522d000
03397d8c: 004841f9 ldr      x0, [x0, #0x290]
03397d90: 5c657097 bl       #0xfb1300
03397d94: e0f200f0 adrp     x0, #0x51f6000
03397d98: 00bc40f9 ldr      x0, [x0, #0x178]
03397d9c: 59657097 bl       #0xfb1300
03397da0: 00f500f0 adrp     x0, #0x523a000
03397da4: 00a842f9 ldr      x0, [x0, #0x550]
03397da8: 56657097 bl       #0xfb1300
03397dac: 28008052 mov      w8, #1
03397db0: c8462639 strb     w8, [x22, #0x991]
03397db4: e00314aa mov      x0, x20
03397db8: 29ffff97 bl       #0x3397a5c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetViewPrefab
03397dbc: f30500b4 cbz      x19, #0x3397e78
03397dc0: a8f400d0 adrp     x8, #0x522d000
03397dc4: 084941f9 ldr      x8, [x8, #0x290]
03397dc8: 37f000d0 adrp     x23, #0x519d000
03397dcc: 18f500f0 adrp     x24, #0x523a000
03397dd0: f9f200f0 adrp     x25, #0x51f6000
03397dd4: 030140f9 ldr      x3, [x8]
03397dd8: f71a46f9 ldr      x23, [x23, #0xc30]
03397ddc: 18ab42f9 ldr      x24, [x24, #0x550]
03397de0: 39bf40f9 ldr      x25, [x25, #0x178]
03397de4: e10300aa mov      x1, x0
03397de8: e00313aa mov      x0, x19
03397dec: e203152a mov      w2, w21
03397df0: 7e9bc697 bl       #0x253ebe8 ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$CreatePool<object>
03397df4: e00314aa mov      x0, x20
03397df8: 3dffff97 bl       #0x3397aec ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetExplodePrefabs
03397dfc: f60300aa mov      x22, x0
03397e00: e003152a mov      w0, w21
03397e04: e1031faa mov      x1, xzr
03397e08: 36cdff97 bl       #0x338b2e0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemAssets$$GetParticleAmount
03397e0c: e30240f9 ldr      x3, [x23]
03397e10: e203002a mov      w2, w0
03397e14: e00313aa mov      x0, x19
03397e18: e10316aa mov      x1, x22
03397e1c: 739bc697 bl       #0x253ebe8 ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$CreatePool<object>
03397e20: e00314aa mov      x0, x20
03397e24: 57ffff97 bl       #0x3397b80 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetTargetExplodePrefabs
03397e28: f60300aa mov      x22, x0
03397e2c: e003152a mov      w0, w21
03397e30: e1031faa mov      x1, xzr
03397e34: 2bcdff97 bl       #0x338b2e0 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemAssets$$GetParticleAmount
03397e38: 030340f9 ldr      x3, [x24]
03397e3c: e203002a mov      w2, w0
03397e40: e00313aa mov      x0, x19
03397e44: e10316aa mov      x1, x22
03397e48: 689bc697 bl       #0x253ebe8 ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$CreatePool<object>
03397e4c: e00314aa mov      x0, x20
03397e50: 71ffff97 bl       #0x3397c14 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetPropellerRocketComboParticlePrefab
03397e54: 230340f9 ldr      x3, [x25]
03397e58: e10300aa mov      x1, x0
03397e5c: e00313aa mov      x0, x19
03397e60: f37b43a9 ldp      x19, x30, [sp, #0x30]
03397e64: f55342a9 ldp      x21, x20, [sp, #0x20]
03397e68: f75b41a9 ldp      x23, x22, [sp, #0x10]
03397e6c: 22008052 mov      w2, #1
03397e70: f963c4a8 ldp      x25, x24, [sp], #0x40
03397e74: 5d9bc617 b        #0x253ebe8 ; Royal.Scenes.Game.Levels.Units.Pool.LevelGameObjectPool$$CreatePool<object>
03397e78: 6c657097 bl       #0xfb1428
