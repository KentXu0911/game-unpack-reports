# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$FindSingleTargetCellForBoomerang
# Linear span to next metadata entry; not a complete CFG.
020f2360: fc6fbaa9 stp      x28, x27, [sp, #-0x60]!
020f2364: fa6701a9 stp      x26, x25, [sp, #0x10]
020f2368: f85f02a9 stp      x24, x23, [sp, #0x20]
020f236c: f65703a9 stp      x22, x21, [sp, #0x30]
020f2370: f44f04a9 stp      x20, x19, [sp, #0x40]
020f2374: fd7b05a9 stp      x29, x30, [sp, #0x50]
020f2378: ffc308d1 sub      sp, sp, #0x230
020f237c: 53a401f0 adrp     x19, #0x557d000
020f2380: 682e5539 ldrb     w8, [x19, #0x54b]
020f2384: f70302aa mov      x23, x2
020f2388: f60301aa mov      x22, x1
020f238c: e01700f9 str      x0, [sp, #0x28]
020f2390: 08090037 tbnz     w8, #0, #0x20f24b0
020f2394: 80890190 adrp     x0, #0x5222000
020f2398: 00ec42f9 ldr      x0, [x0, #0x5d8]
020f239c: d9fbba97 bl       #0xfb1300
020f23a0: e08601f0 adrp     x0, #0x51d1000
020f23a4: 005c44f9 ldr      x0, [x0, #0x8b8]
020f23a8: d6fbba97 bl       #0xfb1300
020f23ac: 40850190 adrp     x0, #0x519a000
020f23b0: 000843f9 ldr      x0, [x0, #0x610]
020f23b4: d3fbba97 bl       #0xfb1300
020f23b8: 00850190 adrp     x0, #0x5192000
020f23bc: 002c41f9 ldr      x0, [x0, #0x258]
020f23c0: d0fbba97 bl       #0xfb1300
020f23c4: 208801b0 adrp     x0, #0x51f7000
020f23c8: 00ac47f9 ldr      x0, [x0, #0xf58]
020f23cc: cdfbba97 bl       #0xfb1300
020f23d0: 20870190 adrp     x0, #0x51d6000
020f23d4: 009044f9 ldr      x0, [x0, #0x920]
020f23d8: cafbba97 bl       #0xfb1300
020f23dc: a08501f0 adrp     x0, #0x51a9000
020f23e0: 004846f9 ldr      x0, [x0, #0xc90]
020f23e4: c7fbba97 bl       #0xfb1300
020f23e8: 408501d0 adrp     x0, #0x519c000
020f23ec: 009c42f9 ldr      x0, [x0, #0x538]
020f23f0: c4fbba97 bl       #0xfb1300
020f23f4: 208a01f0 adrp     x0, #0x5239000
020f23f8: 00ac44f9 ldr      x0, [x0, #0x958]
020f23fc: c1fbba97 bl       #0xfb1300
020f2400: 208601d0 adrp     x0, #0x51b8000
020f2404: 002840f9 ldr      x0, [x0, #0x50]
020f2408: befbba97 bl       #0xfb1300
020f240c: e08601b0 adrp     x0, #0x51cf000
020f2410: 00a842f9 ldr      x0, [x0, #0x550]
020f2414: bbfbba97 bl       #0xfb1300
020f2418: c08401f0 adrp     x0, #0x518d000
020f241c: 00b844f9 ldr      x0, [x0, #0x970]
020f2420: b8fbba97 bl       #0xfb1300
020f2424: 808601d0 adrp     x0, #0x51c4000
020f2428: 004447f9 ldr      x0, [x0, #0xe88]
020f242c: b5fbba97 bl       #0xfb1300
020f2430: e08601b0 adrp     x0, #0x51cf000
020f2434: 002044f9 ldr      x0, [x0, #0x840]
020f2438: b2fbba97 bl       #0xfb1300
020f243c: 008701b0 adrp     x0, #0x51d3000
020f2440: 00f845f9 ldr      x0, [x0, #0xbf0]
020f2444: affbba97 bl       #0xfb1300
020f2448: 208701d0 adrp     x0, #0x51d8000
020f244c: 00c842f9 ldr      x0, [x0, #0x590]
020f2450: acfbba97 bl       #0xfb1300
020f2454: e08401d0 adrp     x0, #0x5190000
020f2458: 00b044f9 ldr      x0, [x0, #0x960]
020f245c: a9fbba97 bl       #0xfb1300
020f2460: a08901b0 adrp     x0, #0x5227000
020f2464: 00b841f9 ldr      x0, [x0, #0x370]
020f2468: a6fbba97 bl       #0xfb1300
020f246c: 60890190 adrp     x0, #0x521e000
020f2470: 002c41f9 ldr      x0, [x0, #0x258]
020f2474: a3fbba97 bl       #0xfb1300
020f2478: a0860190 adrp     x0, #0x51c6000
020f247c: 00f045f9 ldr      x0, [x0, #0xbe0]
020f2480: a0fbba97 bl       #0xfb1300
020f2484: e08701f0 adrp     x0, #0x51f1000
020f2488: 00a845f9 ldr      x0, [x0, #0xb50]
020f248c: 9dfbba97 bl       #0xfb1300
020f2490: 008a01f0 adrp     x0, #0x5235000
020f2494: 00b447f9 ldr      x0, [x0, #0xf68]
020f2498: 9afbba97 bl       #0xfb1300
020f249c: 40870190 adrp     x0, #0x51da000
020f24a0: 000846f9 ldr      x0, [x0, #0xc10]
020f24a4: 97fbba97 bl       #0xfb1300
020f24a8: 28008052 mov      w8, #1
020f24ac: 682e1539 strb     w8, [x19, #0x54b]
020f24b0: e81740f9 ldr      x8, [sp, #0x28]
020f24b4: 00e4006f movi     v0.2d, #0000000000000000
020f24b8: ffff1da9 stp      xzr, xzr, [sp, #0x1d8]
020f24bc: ffff1ca9 stp      xzr, xzr, [sp, #0x1c8]
020f24c0: e00310ad stp      q0, q0, [sp, #0x200]
020f24c4: e07f803d str      q0, [sp, #0x1f0]
020f24c8: ffe300f9 str      xzr, [sp, #0x1c0]
020f24cc: 003540f9 ldr      x0, [x8, #0x68]
020f24d0: 205500b4 cbz      x0, #0x20f2f74
020f24d4: e88701f0 adrp     x8, #0x51f1000
020f24d8: 08a945f9 ldr      x8, [x8, #0xb50]
020f24dc: bd8501f0 adrp     x29, #0x51a9000
020f24e0: 348a01f0 adrp     x20, #0x5239000
020f24e4: 1b8701b0 adrp     x27, #0x51d3000
020f24e8: bd4b46f9 ldr      x29, [x29, #0xc90]
020f24ec: 94ae44f9 ldr      x20, [x20, #0x958]
020f24f0: 7bfb45f9 ldr      x27, [x27, #0xbf0]
020f24f4: 010140f9 ldr      x1, [x8]
020f24f8: e8030691 add      x8, sp, #0x180
020f24fc: f3030691 add      x19, sp, #0x180
020f2500: 00f3d097 bl       #0x152f100 ; System.Collections.Generic.SortedDictionary<int, object>$$GetEnumerator
020f2504: e1034cad ldp      q1, q0, [sp, #0x180]
020f2508: e26bc03d ldr      q2, [sp, #0x1a0]
020f250c: 68b20091 add      x8, x19, #0x2c
020f2510: f31740f9 ldr      x19, [sp, #0x28]
020f2514: ff7f01a9 stp      xzr, xzr, [sp, #0x10]
020f2518: ff1300f9 str      xzr, [sp, #0x20]
020f251c: e1830fad stp      q1, q0, [sp, #0x1f0]
020f2520: e287803d str      q2, [sp, #0x210]
020f2524: e80700f9 str      x8, [sp, #8]
020f2528: a10340f9 ldr      x1, [x29]
020f252c: e0c30791 add      x0, sp, #0x1f0
020f2530: a9933394 bl       #0x2dd73d4 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$MoveNext
020f2534: e0290036 tbz      w0, #0, #0x20f2a70
020f2538: 810240f9 ldr      x1, [x20]
020f253c: e0c30791 add      x0, sp, #0x1f0
020f2540: c2933394 bl       #0x2dd7448 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$get_Current
020f2544: f50301aa mov      x21, x1
020f2548: 570000b4 cbz      x23, #0x20f2550
020f254c: 402e0034 cbz      w0, #0x20f2b14
020f2550: 154f00b4 cbz      x21, #0x20f2f30
020f2554: a81a40b9 ldr      w8, [x21, #0x18]
020f2558: 88feff34 cbz      w8, #0x20f2528
020f255c: 48850190 adrp     x8, #0x519a000
020f2560: 080943f9 ldr      x8, [x8, #0x610]
020f2564: 000140f9 ldr      x0, [x8]
020f2568: 08e040b9 ldr      w8, [x0, #0xe0]
020f256c: a8000035 cbnz     w8, #0x20f2580
020f2570: a5fbba97 bl       #0xfb1404
020f2574: 48850190 adrp     x8, #0x519a000
020f2578: 080943f9 ldr      x8, [x8, #0x610]
020f257c: 000140f9 ldr      x0, [x8]
020f2580: 085c40f9 ldr      x8, [x0, #0xb8]
020f2584: e91340f9 ldr      x9, [sp, #0x20]
020f2588: ff0200f1 cmp      x23, #0
020f258c: 081d40f9 ldr      x8, [x8, #0x38]
020f2590: 2901889a csel     x9, x9, x8, eq
020f2594: e91300f9 str      x9, [sp, #0x20]
020f2598: 770600b4 cbz      x23, #0x20f2664
020f259c: e80240f9 ldr      x8, [x23]
020f25a0: 2a8601d0 adrp     x10, #0x51b8000
020f25a4: 09554279 ldrh     w9, [x8, #0x12a]
020f25a8: 4a2940f9 ldr      x10, [x10, #0x50]
020f25ac: 410140f9 ldr      x1, [x10]
020f25b0: 290100b4 cbz      x9, #0x20f25d4
020f25b4: 0a5940f9 ldr      x10, [x8, #0xb0]
020f25b8: 4a210091 add      x10, x10, #8
020f25bc: 4b815ff8 ldur     x11, [x10, #-8]
020f25c0: 7f0101eb cmp      x11, x1
020f25c4: 00010054 b.eq     #0x20f25e4
020f25c8: 290500f1 subs     x9, x9, #1
020f25cc: 4a410091 add      x10, x10, #0x10
020f25d0: 61ffff54 b.ne     #0x20f25bc
020f25d4: 62008052 mov      w2, #3
020f25d8: e00317aa mov      x0, x23
020f25dc: 3e3bba97 bl       #0xf812d4
020f25e0: 05000014 b        #0x20f25f4
020f25e4: 490140b9 ldr      w9, [x10]
020f25e8: 290d0011 add      w9, w9, #3
020f25ec: 08d1298b add      x8, x8, w9, sxtw #4
020f25f0: 00e10491 add      x0, x8, #0x138
020f25f4: 080440a9 ldp      x8, x1, [x0]
020f25f8: e00317aa mov      x0, x23
020f25fc: 00013fd6 blr      x8
020f2600: e80b40f9 ldr      x8, [sp, #0x10]
020f2604: 1f0000f1 cmp      x0, #0
020f2608: fa0300aa mov      x26, x0
020f260c: 0901809a csel     x9, x8, x0, eq
020f2610: e81340f9 ldr      x8, [sp, #0x20]
020f2614: 800200b4 cbz      x0, #0x20f2664
020f2618: 894a00b4 cbz      x9, #0x20f2f68
020f261c: 68890190 adrp     x8, #0x521e000
020f2620: 210d40f9 ldr      x1, [x9, #0x18]
020f2624: 082d41f9 ldr      x8, [x8, #0x258]
020f2628: ff8b01b9 str      wzr, [sp, #0x188]
020f262c: ffc300f9 str      xzr, [sp, #0x180]
020f2630: 020140f9 ldr      x2, [x8]
020f2634: e0030691 add      x0, sp, #0x180
020f2638: becb3494 bl       #0x2e25530 ; System.Nullable<CellPoint>$$.ctor
020f263c: e8034639 ldrb     w8, [sp, #0x180]
020f2640: e8000034 cbz      w8, #0x20f265c
020f2644: e8030691 add      x8, sp, #0x180
020f2648: 094140f8 ldur     x9, [x8, #4]
020f264c: e81340f9 ldr      x8, [sp, #0x20]
020f2650: fa0b00f9 str      x26, [sp, #0x10]
020f2654: c80000b5 cbnz     x8, #0x20f266c
020f2658: 3d020014 b        #0x20f2f4c
020f265c: e81340f9 ldr      x8, [sp, #0x20]
020f2660: fa0b00f9 str      x26, [sp, #0x10]
020f2664: c90240f9 ldr      x9, [x22]
020f2668: 284700b4 cbz      x8, #0x20f2f4c
020f266c: 090900f9 str      x9, [x8, #0x10]
020f2670: 48850190 adrp     x8, #0x519a000
020f2674: 080943f9 ldr      x8, [x8, #0x610]
020f2678: 000140f9 ldr      x0, [x8]
020f267c: 08e040b9 ldr      w8, [x0, #0xe0]
020f2680: a8000035 cbnz     w8, #0x20f2694
020f2684: 60fbba97 bl       #0xfb1404
020f2688: 48850190 adrp     x8, #0x519a000
020f268c: 080943f9 ldr      x8, [x8, #0x610]
020f2690: 000140f9 ldr      x0, [x8]
020f2694: 085c40f9 ldr      x8, [x0, #0xb8]
020f2698: c28240ad ldp      q2, q0, [x22, #0x10]
020f269c: c91a40f9 ldr      x9, [x22, #0x30]
020f26a0: c102c03d ldr      q1, [x22]
020f26a4: ea0740f9 ldr      x10, [sp, #8]
020f26a8: 081d40f9 ldr      x8, [x8, #0x38]
020f26ac: e9db00f9 str      x9, [sp, #0x1b0]
020f26b0: e2830cad stp      q2, q0, [sp, #0x190]
020f26b4: e163803d str      q1, [sp, #0x180]
020f26b8: 490940b9 ldr      w9, [x10, #8]
020f26bc: 4a0140f9 ldr      x10, [x10]
020f26c0: e9bb00b9 str      w9, [sp, #0xb8]
020f26c4: ea5b00f9 str      x10, [sp, #0xb0]
020f26c8: 484400b4 cbz      x8, #0x20f2f50
020f26cc: e9bb40b9 ldr      w9, [sp, #0xb8]
020f26d0: ea5b40f9 ldr      x10, [sp, #0xb0]
020f26d4: 092100b9 str      w9, [x8, #0x20]
020f26d8: 0a0d00f9 str      x10, [x8, #0x18]
020f26dc: 888601d0 adrp     x8, #0x51c4000
020f26e0: 611e40f9 ldr      x1, [x19, #0x38]
020f26e4: 084547f9 ldr      x8, [x8, #0xe88]
020f26e8: 020140f9 ldr      x2, [x8]
020f26ec: e00315aa mov      x0, x21
020f26f0: 8b551194 bl       #0x2547d1c ; Royal.Infrastructure.Utils.Extensions.ListExtensions$$Shuffle<object>
020f26f4: 48850190 adrp     x8, #0x519a000
020f26f8: 080943f9 ldr      x8, [x8, #0x610]
020f26fc: 080140f9 ldr      x8, [x8]
020f2700: 085d40f9 ldr      x8, [x8, #0xb8]
020f2704: 131d40f9 ldr      x19, [x8, #0x38]
020f2708: 734200b4 cbz      x19, #0x20f2f54
020f270c: e88601f0 adrp     x8, #0x51d1000
020f2710: 085d44f9 ldr      x8, [x8, #0x8b8]
020f2714: 000140f9 ldr      x0, [x8]
020f2718: 08e040b9 ldr      w8, [x0, #0xe0]
020f271c: a8000035 cbnz     w8, #0x20f2730
020f2720: 39fbba97 bl       #0xfb1404
020f2724: e88601f0 adrp     x8, #0x51d1000
020f2728: 085d44f9 ldr      x8, [x8, #0x8b8]
020f272c: 000140f9 ldr      x0, [x8]
020f2730: 085c40f9 ldr      x8, [x0, #0xb8]
020f2734: 60420091 add      x0, x19, #0x10
020f2738: 010140f9 ldr      x1, [x8]
020f273c: e2031faa mov      x2, xzr
020f2740: 2f722794 bl       #0x2aceffc ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$Equals
020f2744: f31740f9 ldr      x19, [sp, #0x28]
020f2748: 60060037 tbnz     w0, #0, #0x20f2814
020f274c: e88601b0 adrp     x8, #0x51cf000
020f2750: 082144f9 ldr      x8, [x8, #0x840]
020f2754: 010140f9 ldr      x1, [x8]
020f2758: e8030691 add      x8, sp, #0x180
020f275c: e00315aa mov      x0, x21
020f2760: 55722394 bl       #0x29cf0b4 ; System.Collections.Generic.List<object>$$GetEnumerator
020f2764: e063c03d ldr      q0, [sp, #0x180]
020f2768: e8cb40f9 ldr      x8, [sp, #0x190]
020f276c: e077803d str      q0, [sp, #0x1d0]
020f2770: e8f300f9 str      x8, [sp, #0x1e0]
020f2774: 28870190 adrp     x8, #0x51d6000
020f2778: 089144f9 ldr      x8, [x8, #0x920]
020f277c: 010140f9 ldr      x1, [x8]
020f2780: e0430791 add      x0, sp, #0x1d0
020f2784: 2a022894 bl       #0x2af302c ; System.Collections.Generic.List.Enumerator<object>$$MoveNext
020f2788: 20010036 tbz      w0, #0, #0x20f27ac
020f278c: e8f340f9 ldr      x8, [sp, #0x1e0]
020f2790: 881400b4 cbz      x8, #0x20f2a20
020f2794: 006940f9 ldr      x0, [x8, #0xd0]
020f2798: a01400b4 cbz      x0, #0x20f2a2c
020f279c: 611e40f9 ldr      x1, [x19, #0x38]
020f27a0: e2031faa mov      x2, xzr
020f27a4: f1220d94 bl       #0x243b368 ; Royal.Scenes.Game.Levels.Units.Booster.PatternData$$InitRandom
020f27a8: f3ffff17 b        #0x20f2774
020f27ac: fc031baa mov      x28, x27
020f27b0: fb031faa mov      x27, xzr
020f27b4: 33038052 mov      w19, #0x19
020f27b8: 08850190 adrp     x8, #0x5192000
020f27bc: 082d41f9 ldr      x8, [x8, #0x258]
020f27c0: 010140f9 ldr      x1, [x8]
020f27c4: e0430791 add      x0, sp, #0x1d0
020f27c8: 18022894 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
020f27cc: 1b3d00b5 cbnz     x27, #0x20f2f6c
020f27d0: 7f660071 cmp      w19, #0x19
020f27d4: 40000054 b.eq     #0x20f27dc
020f27d8: d3360035 cbnz     w19, #0x20f2eb0
020f27dc: 48850190 adrp     x8, #0x519a000
020f27e0: 080943f9 ldr      x8, [x8, #0x610]
020f27e4: 000140f9 ldr      x0, [x8]
020f27e8: 08e040b9 ldr      w8, [x0, #0xe0]
020f27ec: a8000035 cbnz     w8, #0x20f2800
020f27f0: 05fbba97 bl       #0xfb1404
020f27f4: 48850190 adrp     x8, #0x519a000
020f27f8: 080943f9 ldr      x8, [x8, #0x610]
020f27fc: 000140f9 ldr      x0, [x8]
020f2800: 085c40f9 ldr      x8, [x0, #0xb8]
020f2804: 820340f9 ldr      x2, [x28]
020f2808: 011d40f9 ldr      x1, [x8, #0x38]
020f280c: e00315aa mov      x0, x21
020f2810: 0d762394 bl       #0x29d0044 ; System.Collections.Generic.List<object>$$Sort
020f2814: e98401d0 adrp     x9, #0x5190000
020f2818: a81a40b9 ldr      w8, [x21, #0x18]
020f281c: 29b144f9 ldr      x9, [x9, #0x960]
020f2820: 1f050071 cmp      w8, #1
020f2824: 220140f9 ldr      x2, [x9]
020f2828: 4b090054 b.lt     #0x20f2950
020f282c: fa031f2a mov      w26, wzr
020f2830: f3031f2a mov      w19, wzr
020f2834: fb031f2a mov      w27, wzr
020f2838: e00315aa mov      x0, x21
020f283c: e1031b2a mov      w1, w27
020f2840: eb6e2394 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
020f2844: fc0300aa mov      x28, x0
020f2848: 603700b4 cbz      x0, #0x20f2f34
020f284c: e0031caa mov      x0, x28
020f2850: e1031faa mov      x1, xzr
020f2854: f36f2794 bl       #0x2ace820 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$GetIdentifierOfItemTakingDamage
020f2858: c82640b9 ldr      w8, [x22, #0x24]
020f285c: c2c241f8 ldur     x2, [x22, #0x1c]
020f2860: 097f6092 and      x9, x24, #0xffffffff00000000
020f2864: 397c40b3 bfxil    x25, x1, #0, #0x20
020f2868: 380108aa orr      x24, x9, x8
020f286c: e10319aa mov      x1, x25
020f2870: e30318aa mov      x3, x24
020f2874: e4031faa mov      x4, xzr
020f2878: 23704a94 bl       #0x338e904 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel.ItemIdentifier$$op_Equality
020f287c: 80000036 tbz      w0, #0, #0x20f288c
020f2880: f3020036 tbz      w19, #0, #0x20f28dc
020f2884: 33008052 mov      w19, #1
020f2888: 2a000014 b        #0x20f2930
020f288c: c28240ad ldp      q2, q0, [x22, #0x10]
020f2890: c81a40f9 ldr      x8, [x22, #0x30]
020f2894: c102c03d ldr      q1, [x22]
020f2898: 805b40f9 ldr      x0, [x28, #0xb0]
020f289c: e2830cad stp      q2, q0, [sp, #0x190]
020f28a0: e8db00f9 str      x8, [sp, #0x1b0]
020f28a4: e163803d str      q1, [sp, #0x180]
020f28a8: c03400b4 cbz      x0, #0x20f2f40
020f28ac: e1034cad ldp      q1, q0, [sp, #0x180]
020f28b0: e26bc03d ldr      q2, [sp, #0x1a0]
020f28b4: e8db40f9 ldr      x8, [sp, #0x1b0]
020f28b8: e10308ad stp      q1, q0, [sp, #0x100]
020f28bc: e24b803d str      q2, [sp, #0x120]
020f28c0: e89b00f9 str      x8, [sp, #0x130]
020f28c4: e1030491 add      x1, sp, #0x100
020f28c8: e2031faa mov      x2, xzr
020f28cc: 4d732794 bl       #0x2acf600 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$RemainingExplodeCount
020f28d0: 1f040071 cmp      w0, #1
020f28d4: eb020054 b.lt     #0x20f2930
020f28d8: 3f010014 b        #0x20f2dd4
020f28dc: c28240ad ldp      q2, q0, [x22, #0x10]
020f28e0: c81a40f9 ldr      x8, [x22, #0x30]
020f28e4: c102c03d ldr      q1, [x22]
020f28e8: 805b40f9 ldr      x0, [x28, #0xb0]
020f28ec: e2830cad stp      q2, q0, [sp, #0x190]
020f28f0: e8db00f9 str      x8, [sp, #0x1b0]
020f28f4: e163803d str      q1, [sp, #0x180]
020f28f8: 603300b4 cbz      x0, #0x20f2f64
020f28fc: e1034cad ldp      q1, q0, [sp, #0x180]
020f2900: e26bc03d ldr      q2, [sp, #0x1a0]
020f2904: e8db40f9 ldr      x8, [sp, #0x1b0]
020f2908: e1030aad stp      q1, q0, [sp, #0x140]
020f290c: e25b803d str      q2, [sp, #0x160]
020f2910: e8bb00f9 str      x8, [sp, #0x170]
020f2914: e1030591 add      x1, sp, #0x140
020f2918: e2031faa mov      x2, xzr
020f291c: 39732794 bl       #0x2acf600 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$RemainingExplodeCount
020f2920: 1f000071 cmp      w0, #0
020f2924: f3d79f1a cset     w19, gt
020f2928: 1f040071 cmp      w0, #1
020f292c: 5ab39b1a csel     w26, w26, w27, lt
020f2930: e98401d0 adrp     x9, #0x5190000
020f2934: a81a40b9 ldr      w8, [x21, #0x18]
020f2938: 29b144f9 ldr      x9, [x9, #0x960]
020f293c: 7b070011 add      w27, w27, #1
020f2940: 7f03086b cmp      w27, w8
020f2944: 220140f9 ldr      x2, [x9]
020f2948: 8bf7ff54 b.lt     #0x20f2838
020f294c: 02000014 b        #0x20f2954
020f2950: fa031f2a mov      w26, wzr
020f2954: e00315aa mov      x0, x21
020f2958: e1031a2a mov      w1, w26
020f295c: a46e2394 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
020f2960: 1b8701b0 adrp     x27, #0x51d3000
020f2964: f31740f9 ldr      x19, [sp, #0x28]
020f2968: 7bfb45f9 ldr      x27, [x27, #0xbf0]
020f296c: fa0300aa mov      x26, x0
020f2970: 402f00b4 cbz      x0, #0x20f2f58
020f2974: c28240ad ldp      q2, q0, [x22, #0x10]
020f2978: c81a40f9 ldr      x8, [x22, #0x30]
020f297c: c102c03d ldr      q1, [x22]
020f2980: 405b40f9 ldr      x0, [x26, #0xb0]
020f2984: e2830cad stp      q2, q0, [sp, #0x190]
020f2988: e8db00f9 str      x8, [sp, #0x1b0]
020f298c: e163803d str      q1, [sp, #0x180]
020f2990: 602e00b4 cbz      x0, #0x20f2f5c
020f2994: e1034cad ldp      q1, q0, [sp, #0x180]
020f2998: e26bc03d ldr      q2, [sp, #0x1a0]
020f299c: e8db40f9 ldr      x8, [sp, #0x1b0]
020f29a0: e18303ad stp      q1, q0, [sp, #0x70]
020f29a4: e227803d str      q2, [sp, #0x90]
020f29a8: e85300f9 str      x8, [sp, #0xa0]
020f29ac: e1c30191 add      x1, sp, #0x70
020f29b0: e2031faa mov      x2, xzr
020f29b4: 13732794 bl       #0x2acf600 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$RemainingExplodeCount
020f29b8: 1f040071 cmp      w0, #1
020f29bc: 6bdbff54 b.lt     #0x20f2528
020f29c0: c28240ad ldp      q2, q0, [x22, #0x10]
020f29c4: c81a40f9 ldr      x8, [x22, #0x30]
020f29c8: c102c03d ldr      q1, [x22]
020f29cc: 405b40f9 ldr      x0, [x26, #0xb0]
020f29d0: e2830cad stp      q2, q0, [sp, #0x190]
020f29d4: e8db00f9 str      x8, [sp, #0x1b0]
020f29d8: e163803d str      q1, [sp, #0x180]
020f29dc: 202c00b4 cbz      x0, #0x20f2f60
020f29e0: e1034cad ldp      q1, q0, [sp, #0x180]
020f29e4: e26bc03d ldr      q2, [sp, #0x1a0]
020f29e8: e8db40f9 ldr      x8, [sp, #0x1b0]
020f29ec: e18301ad stp      q1, q0, [sp, #0x30]
020f29f0: e217803d str      q2, [sp, #0x50]
020f29f4: e83300f9 str      x8, [sp, #0x60]
020f29f8: e1c30091 add      x1, sp, #0x30
020f29fc: e20315aa mov      x2, x21
020f2a00: e3031faa mov      x3, xzr
020f2a04: 25742794 bl       #0x2acfa98 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$TryRedirect
020f2a08: e00f00f9 str      x0, [sp, #0x18]
020f2a0c: c82a40b9 ldr      w8, [x22, #0x28]
020f2a10: 08050051 sub      w8, w8, #1
020f2a14: 1f090071 cmp      w8, #2
020f2a18: 83d8ff54 b.lo     #0x20f2528
020f2a1c: 32010014 b        #0x20f2ee4
020f2a20: fc031baa mov      x28, x27
020f2a24: 81faba97 bl       #0xfb1428
020f2a28: 43010014 b        #0x20f2f34
020f2a2c: fc031baa mov      x28, x27
020f2a30: 7efaba97 bl       #0xfb1428
020f2a34: 40010014 b        #0x20f2f34
020f2a38: 04000014 b        #0x20f2a48
020f2a3c: 03000014 b        #0x20f2a48
020f2a40: 01000014 b        #0x20f2a44
020f2a44: fc031baa mov      x28, x27
020f2a48: f30301aa mov      x19, x1
020f2a4c: fa0300aa mov      x26, x0
020f2a50: 7f060071 cmp      w19, #1
020f2a54: a1250054 b.ne     #0x20f2f08
020f2a58: e0031aaa mov      x0, x26
020f2a5c: dd42af97 bl       #0xcc35d0
020f2a60: 1b0040f9 ldr      x27, [x0]
020f2a64: 5741af97 bl       #0xcc2fc0
020f2a68: f3031f2a mov      w19, wzr
020f2a6c: 53ffff17 b        #0x20f27b8
020f2a70: 288801b0 adrp     x8, #0x51f7000
020f2a74: 08ad47f9 ldr      x8, [x8, #0xf58]
020f2a78: e0c30791 add      x0, sp, #0x1f0
020f2a7c: 010140f9 ldr      x1, [x8]
020f2a80: 71923394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020f2a84: 188a01f0 adrp     x24, #0x5235000
020f2a88: 18b747f9 ldr      x24, [x24, #0xf68]
020f2a8c: 88890190 adrp     x8, #0x5222000
020f2a90: 08ed42f9 ldr      x8, [x8, #0x5d8]
020f2a94: 130140f9 ldr      x19, [x8]
020f2a98: 681e40f9 ldr      x8, [x19, #0x38]
020f2a9c: 000140f9 ldr      x0, [x8]
020f2aa0: 08c84439 ldrb     w8, [x0, #0x132]
020f2aa4: 48000037 tbnz     w8, #0, #0x20f2aac
020f2aa8: 4f39ba97 bl       #0xf80fe4
020f2aac: 08e040b9 ldr      w8, [x0, #0xe0]
020f2ab0: 48000035 cbnz     w8, #0x20f2ab8
020f2ab4: 54faba97 bl       #0xfb1404
020f2ab8: 681e40f9 ldr      x8, [x19, #0x38]
020f2abc: 000140f9 ldr      x0, [x8]
020f2ac0: 08c84439 ldrb     w8, [x0, #0x132]
020f2ac4: 48000037 tbnz     w8, #0, #0x20f2acc
020f2ac8: 4739ba97 bl       #0xf80fe4
020f2acc: 4a870190 adrp     x10, #0x51da000
020f2ad0: e91740f9 ldr      x9, [sp, #0x28]
020f2ad4: 4a0946f9 ldr      x10, [x10, #0xc10]
020f2ad8: 085c40f9 ldr      x8, [x0, #0xb8]
020f2adc: 61018052 mov      w1, #0xb
020f2ae0: e00309aa mov      x0, x9
020f2ae4: 420140f9 ldr      x2, [x10]
020f2ae8: 030140f9 ldr      x3, [x8]
020f2aec: e4031faa mov      x4, xzr
020f2af0: 8c371c94 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
020f2af4: 030340f9 ldr      x3, [x24]
020f2af8: e0830891 add      x0, sp, #0x220
020f2afc: e1031f2a mov      w1, wzr
020f2b00: e2031faa mov      x2, xzr
020f2b04: ff1701f9 str      xzr, [sp, #0x228]
020f2b08: ff1301f9 str      xzr, [sp, #0x220]
020f2b0c: 7de9e297 bl       #0x19ad100 ; System.ValueTuple<bool, object>$$.ctor
020f2b10: de000014 b        #0x20f2e88
020f2b14: 188a01f0 adrp     x24, #0x5235000
020f2b18: 59850190 adrp     x25, #0x519a000
020f2b1c: 18b747f9 ldr      x24, [x24, #0xf68]
020f2b20: f40f40f9 ldr      x20, [sp, #0x18]
020f2b24: 390b43f9 ldr      x25, [x25, #0x610]
020f2b28: b40000b4 cbz      x20, #0x20f2b3c
020f2b2c: e00314aa mov      x0, x20
020f2b30: e1031faa mov      x1, xzr
020f2b34: 076f2794 bl       #0x2ace750 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$IsHittingUseful
020f2b38: 80180037 tbnz     w0, #0, #0x20f2e48
020f2b3c: 200340f9 ldr      x0, [x25]
020f2b40: 08e040b9 ldr      w8, [x0, #0xe0]
020f2b44: 68000035 cbnz     w8, #0x20f2b50
020f2b48: 2ffaba97 bl       #0xfb1404
020f2b4c: 200340f9 ldr      x0, [x25]
020f2b50: 095c40f9 ldr      x9, [x0, #0xb8]
020f2b54: e80240f9 ldr      x8, [x23]
020f2b58: 2a8601d0 adrp     x10, #0x51b8000
020f2b5c: 331d40f9 ldr      x19, [x9, #0x38]
020f2b60: 09554279 ldrh     w9, [x8, #0x12a]
020f2b64: 4a2940f9 ldr      x10, [x10, #0x50]
020f2b68: 410140f9 ldr      x1, [x10]
020f2b6c: 290100b4 cbz      x9, #0x20f2b90
020f2b70: 0a5940f9 ldr      x10, [x8, #0xb0]
020f2b74: 4a210091 add      x10, x10, #8
020f2b78: 4b815ff8 ldur     x11, [x10, #-8]
020f2b7c: 7f0101eb cmp      x11, x1
020f2b80: 00010054 b.eq     #0x20f2ba0
020f2b84: 290500f1 subs     x9, x9, #1
020f2b88: 4a410091 add      x10, x10, #0x10
020f2b8c: 61ffff54 b.ne     #0x20f2b78
020f2b90: 62008052 mov      w2, #3
020f2b94: e00317aa mov      x0, x23
020f2b98: cf39ba97 bl       #0xf812d4
020f2b9c: 05000014 b        #0x20f2bb0
020f2ba0: 490140b9 ldr      w9, [x10]
020f2ba4: 290d0011 add      w9, w9, #3
020f2ba8: 08d1298b add      x8, x8, w9, sxtw #4
020f2bac: 00e10491 add      x0, x8, #0x138
020f2bb0: 080440a9 ldp      x8, x1, [x0]
020f2bb4: e00317aa mov      x0, x23
020f2bb8: 00013fd6 blr      x8
020f2bbc: f31d00b4 cbz      x19, #0x20f2f78
020f2bc0: 08600091 add      x8, x0, #0x18
020f2bc4: 1f0000f1 cmp      x0, #0
020f2bc8: c802889a csel     x8, x22, x8, eq
020f2bcc: 080140f9 ldr      x8, [x8]
020f2bd0: 680a00f9 str      x8, [x19, #0x10]
020f2bd4: 200340f9 ldr      x0, [x25]
020f2bd8: 08e040b9 ldr      w8, [x0, #0xe0]
020f2bdc: 68000034 cbz      w8, #0x20f2be8
020f2be0: f31740f9 ldr      x19, [sp, #0x28]
020f2be4: 04000014 b        #0x20f2bf4
020f2be8: f31740f9 ldr      x19, [sp, #0x28]
020f2bec: 06faba97 bl       #0xfb1404
020f2bf0: 200340f9 ldr      x0, [x25]
020f2bf4: 085c40f9 ldr      x8, [x0, #0xb8]
020f2bf8: c28240ad ldp      q2, q0, [x22, #0x10]
020f2bfc: c91a40f9 ldr      x9, [x22, #0x30]
020f2c00: c102c03d ldr      q1, [x22]
020f2c04: 081d40f9 ldr      x8, [x8, #0x38]
020f2c08: e2830cad stp      q2, q0, [sp, #0x190]
020f2c0c: e9db00f9 str      x9, [sp, #0x1b0]
020f2c10: e163803d str      q1, [sp, #0x180]
020f2c14: e9030691 add      x9, sp, #0x180
020f2c18: 29c142f8 ldur     x9, [x9, #0x2c]
020f2c1c: eab741b9 ldr      w10, [sp, #0x1b4]
020f2c20: e95b00f9 str      x9, [sp, #0xb0]
020f2c24: eabb00b9 str      w10, [sp, #0xb8]
020f2c28: a81a00b4 cbz      x8, #0x20f2f7c
020f2c2c: e9bb40b9 ldr      w9, [sp, #0xb8]
020f2c30: ea5b40f9 ldr      x10, [sp, #0xb0]
020f2c34: 092100b9 str      w9, [x8, #0x20]
020f2c38: 0a0d00f9 str      x10, [x8, #0x18]
020f2c3c: 888601d0 adrp     x8, #0x51c4000
020f2c40: 611e40f9 ldr      x1, [x19, #0x38]
020f2c44: 084547f9 ldr      x8, [x8, #0xe88]
020f2c48: 020140f9 ldr      x2, [x8]
020f2c4c: e00315aa mov      x0, x21
020f2c50: 33541194 bl       #0x2547d1c ; Royal.Infrastructure.Utils.Extensions.ListExtensions$$Shuffle<object>
020f2c54: f68601f0 adrp     x22, #0x51d1000
020f2c58: d65e44f9 ldr      x22, [x22, #0x8b8]
020f2c5c: 280340f9 ldr      x8, [x25]
020f2c60: 085d40f9 ldr      x8, [x8, #0xb8]
020f2c64: 131d40f9 ldr      x19, [x8, #0x38]
020f2c68: d31800b4 cbz      x19, #0x20f2f80
020f2c6c: c00240f9 ldr      x0, [x22]
020f2c70: 08e040b9 ldr      w8, [x0, #0xe0]
020f2c74: 68000035 cbnz     w8, #0x20f2c80
020f2c78: e3f9ba97 bl       #0xfb1404
020f2c7c: c00240f9 ldr      x0, [x22]
020f2c80: 085c40f9 ldr      x8, [x0, #0xb8]
020f2c84: 60420091 add      x0, x19, #0x10
020f2c88: 010140f9 ldr      x1, [x8]
020f2c8c: e2031faa mov      x2, xzr
020f2c90: db702794 bl       #0x2aceffc ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$Equals
020f2c94: f31740f9 ldr      x19, [sp, #0x28]
020f2c98: e0050037 tbnz     w0, #0, #0x20f2d54
020f2c9c: 751700b4 cbz      x21, #0x20f2f88
020f2ca0: e88601b0 adrp     x8, #0x51cf000
020f2ca4: 082144f9 ldr      x8, [x8, #0x840]
020f2ca8: 010140f9 ldr      x1, [x8]
020f2cac: e8030691 add      x8, sp, #0x180
020f2cb0: e00315aa mov      x0, x21
020f2cb4: 00712394 bl       #0x29cf0b4 ; System.Collections.Generic.List<object>$$GetEnumerator
020f2cb8: e063c03d ldr      q0, [sp, #0x180]
020f2cbc: e8cb40f9 ldr      x8, [sp, #0x190]
020f2cc0: e077803d str      q0, [sp, #0x1d0]
020f2cc4: e8f300f9 str      x8, [sp, #0x1e0]
020f2cc8: 28870190 adrp     x8, #0x51d6000
020f2ccc: 089144f9 ldr      x8, [x8, #0x920]
020f2cd0: 010140f9 ldr      x1, [x8]
020f2cd4: e0430791 add      x0, sp, #0x1d0
020f2cd8: d5002894 bl       #0x2af302c ; System.Collections.Generic.List.Enumerator<object>$$MoveNext
020f2cdc: 20010036 tbz      w0, #0, #0x20f2d00
020f2ce0: e8f340f9 ldr      x8, [sp, #0x1e0]
020f2ce4: a81200b4 cbz      x8, #0x20f2f38
020f2ce8: 006940f9 ldr      x0, [x8, #0xd0]
020f2cec: 801200b4 cbz      x0, #0x20f2f3c
020f2cf0: 611e40f9 ldr      x1, [x19, #0x38]
020f2cf4: e2031faa mov      x2, xzr
020f2cf8: 9c210d94 bl       #0x243b368 ; Royal.Scenes.Game.Levels.Units.Booster.PatternData$$InitRandom
020f2cfc: f3ffff17 b        #0x20f2cc8
020f2d00: f6031faa mov      x22, xzr
020f2d04: 93018052 mov      w19, #0xc
020f2d08: 08850190 adrp     x8, #0x5192000
020f2d0c: 082d41f9 ldr      x8, [x8, #0x258]
020f2d10: 010140f9 ldr      x1, [x8]
020f2d14: e0430791 add      x0, sp, #0x1d0
020f2d18: c4002894 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
020f2d1c: 961300b5 cbnz     x22, #0x20f2f8c
020f2d20: 7f320071 cmp      w19, #0xc
020f2d24: 40000054 b.eq     #0x20f2d2c
020f2d28: 930c0035 cbnz     w19, #0x20f2eb8
020f2d2c: 200340f9 ldr      x0, [x25]
020f2d30: 08e040b9 ldr      w8, [x0, #0xe0]
020f2d34: 68000035 cbnz     w8, #0x20f2d40
020f2d38: b3f9ba97 bl       #0xfb1404
020f2d3c: 200340f9 ldr      x0, [x25]
020f2d40: 085c40f9 ldr      x8, [x0, #0xb8]
020f2d44: 620340f9 ldr      x2, [x27]
020f2d48: 011d40f9 ldr      x1, [x8, #0x38]
020f2d4c: e00315aa mov      x0, x21
020f2d50: bd742394 bl       #0x29d0044 ; System.Collections.Generic.List<object>$$Sort
020f2d54: 951100b4 cbz      x21, #0x20f2f84
020f2d58: a81a40b9 ldr      w8, [x21, #0x18]
020f2d5c: 1f050071 cmp      w8, #1
020f2d60: 4b070054 b.lt     #0x20f2e48
020f2d64: f6031f2a mov      w22, wzr
020f2d68: e88401d0 adrp     x8, #0x5190000
020f2d6c: 08b144f9 ldr      x8, [x8, #0x960]
020f2d70: 020140f9 ldr      x2, [x8]
020f2d74: e00315aa mov      x0, x21
020f2d78: e103162a mov      w1, w22
020f2d7c: 9c6d2394 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
020f2d80: f70300aa mov      x23, x0
020f2d84: 000e00b4 cbz      x0, #0x20f2f44
020f2d88: e00317aa mov      x0, x23
020f2d8c: e1031faa mov      x1, xzr
020f2d90: 34572794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f2d94: 600100b4 cbz      x0, #0x20f2dc0
020f2d98: e00317aa mov      x0, x23
020f2d9c: e1031faa mov      x1, xzr
020f2da0: 30572794 bl       #0x2ac8a60 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$get_CurrentItem
020f2da4: 200d00b4 cbz      x0, #0x20f2f48
020f2da8: 080040f9 ldr      x8, [x0]
020f2dac: 01c141f9 ldr      x1, [x8, #0x380]
020f2db0: 09bd41f9 ldr      x9, [x8, #0x378]
020f2db4: 20013fd6 blr      x9
020f2db8: 1f040071 cmp      w0, #1
020f2dbc: 40040054 b.eq     #0x20f2e44
020f2dc0: a81a40b9 ldr      w8, [x21, #0x18]
020f2dc4: d6060011 add      w22, w22, #1
020f2dc8: df02086b cmp      w22, w8
020f2dcc: ebfcff54 b.lt     #0x20f2d68
020f2dd0: 1e000014 b        #0x20f2e48
020f2dd4: c28240ad ldp      q2, q0, [x22, #0x10]
020f2dd8: c81a40f9 ldr      x8, [x22, #0x30]
020f2ddc: c102c03d ldr      q1, [x22]
020f2de0: 805b40f9 ldr      x0, [x28, #0xb0]
020f2de4: e2830cad stp      q2, q0, [sp, #0x190]
020f2de8: e8db00f9 str      x8, [sp, #0x1b0]
020f2dec: e163803d str      q1, [sp, #0x180]
020f2df0: 200d00b4 cbz      x0, #0x20f2f94
020f2df4: e1034cad ldp      q1, q0, [sp, #0x180]
020f2df8: e26bc03d ldr      q2, [sp, #0x1a0]
020f2dfc: e8db40f9 ldr      x8, [sp, #0x1b0]
020f2e00: e10306ad stp      q1, q0, [sp, #0xc0]
020f2e04: e23b803d str      q2, [sp, #0xe0]
020f2e08: e87b00f9 str      x8, [sp, #0xf0]
020f2e0c: 138a01f0 adrp     x19, #0x5235000
020f2e10: 73b647f9 ldr      x19, [x19, #0xf68]
020f2e14: e1030391 add      x1, sp, #0xc0
020f2e18: e20315aa mov      x2, x21
020f2e1c: e3031faa mov      x3, xzr
020f2e20: 1e732794 bl       #0x2acfa98 ; Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$TryRedirect
020f2e24: 630240f9 ldr      x3, [x19]
020f2e28: e20300aa mov      x2, x0
020f2e2c: ff7f0ba9 stp      xzr, xzr, [sp, #0xb0]
020f2e30: e0c30291 add      x0, sp, #0xb0
020f2e34: e1031f2a mov      w1, wzr
020f2e38: b2e8e297 bl       #0x19ad100 ; System.ValueTuple<bool, object>$$.ctor
020f2e3c: e02fc03d ldr      q0, [sp, #0xb0]
020f2e40: 0a000014 b        #0x20f2e68
020f2e44: f40317aa mov      x20, x23
020f2e48: 030340f9 ldr      x3, [x24]
020f2e4c: 9f0200f1 cmp      x20, #0
020f2e50: e1179f1a cset     w1, eq
020f2e54: ff7f18a9 stp      xzr, xzr, [sp, #0x180]
020f2e58: e0030691 add      x0, sp, #0x180
020f2e5c: e20314aa mov      x2, x20
020f2e60: a8e8e297 bl       #0x19ad100 ; System.ValueTuple<bool, object>$$.ctor
020f2e64: e063c03d ldr      q0, [sp, #0x180]
020f2e68: e073803d str      q0, [sp, #0x1c0]
020f2e6c: 288801b0 adrp     x8, #0x51f7000
020f2e70: 08ad47f9 ldr      x8, [x8, #0xf58]
020f2e74: e0c30791 add      x0, sp, #0x1f0
020f2e78: 010140f9 ldr      x1, [x8]
020f2e7c: 72913394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020f2e80: e073c03d ldr      q0, [sp, #0x1c0]
020f2e84: e08b803d str      q0, [sp, #0x220]
020f2e88: e11741f9 ldr      x1, [sp, #0x228]
020f2e8c: e01341f9 ldr      x0, [sp, #0x220]
020f2e90: ffc30891 add      sp, sp, #0x230
020f2e94: fd7b45a9 ldp      x29, x30, [sp, #0x50]
020f2e98: f44f44a9 ldp      x20, x19, [sp, #0x40]
020f2e9c: f65743a9 ldp      x22, x21, [sp, #0x30]
020f2ea0: f85f42a9 ldp      x24, x23, [sp, #0x20]
020f2ea4: fa6741a9 ldp      x26, x25, [sp, #0x10]
020f2ea8: fc6fc6a8 ldp      x28, x27, [sp], #0x60
020f2eac: c0035fd6 ret      
020f2eb0: 188a01f0 adrp     x24, #0x5235000
020f2eb4: 18b747f9 ldr      x24, [x24, #0xf68]
020f2eb8: 288801b0 adrp     x8, #0x51f7000
020f2ebc: 08ad47f9 ldr      x8, [x8, #0xf58]
020f2ec0: e0c30791 add      x0, sp, #0x1f0
020f2ec4: 010140f9 ldr      x1, [x8]
020f2ec8: 5f913394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020f2ecc: 7f7a0071 cmp      w19, #0x1e
020f2ed0: e0ddff54 b.eq     #0x20f2a8c
020f2ed4: 7f420071 cmp      w19, #0x10
020f2ed8: 40fdff54 b.eq     #0x20f2e80
020f2edc: 93ddff34 cbz      w19, #0x20f2a8c
020f2ee0: eaffff17 b        #0x20f2e88
020f2ee4: 088a01f0 adrp     x8, #0x5235000
020f2ee8: 08b547f9 ldr      x8, [x8, #0xf68]
020f2eec: ff7f18a9 stp      xzr, xzr, [sp, #0x180]
020f2ef0: 030140f9 ldr      x3, [x8]
020f2ef4: e20f40f9 ldr      x2, [sp, #0x18]
020f2ef8: e0030691 add      x0, sp, #0x180
020f2efc: e1031f2a mov      w1, wzr
020f2f00: 80e8e297 bl       #0x19ad100 ; System.ValueTuple<bool, object>$$.ctor
020f2f04: d8ffff17 b        #0x20f2e64
020f2f08: fb031faa mov      x27, xzr
020f2f0c: 08850190 adrp     x8, #0x5192000
020f2f10: 082d41f9 ldr      x8, [x8, #0x258]
020f2f14: 010140f9 ldr      x1, [x8]
020f2f18: e0430791 add      x0, sp, #0x1d0
020f2f1c: 43002894 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
020f2f20: e10313aa mov      x1, x19
020f2f24: db0e00b4 cbz      x27, #0x20f30fc
020f2f28: e0031baa mov      x0, x27
020f2f2c: 2ba9ba97 bl       #0xf9d3d8
020f2f30: 3ef9ba97 bl       #0xfb1428
020f2f34: 3df9ba97 bl       #0xfb1428
020f2f38: 3cf9ba97 bl       #0xfb1428
020f2f3c: 3bf9ba97 bl       #0xfb1428
020f2f40: 3af9ba97 bl       #0xfb1428
020f2f44: 39f9ba97 bl       #0xfb1428
020f2f48: 38f9ba97 bl       #0xfb1428
020f2f4c: 37f9ba97 bl       #0xfb1428
020f2f50: 36f9ba97 bl       #0xfb1428
020f2f54: 35f9ba97 bl       #0xfb1428
020f2f58: 34f9ba97 bl       #0xfb1428
020f2f5c: 33f9ba97 bl       #0xfb1428
020f2f60: 32f9ba97 bl       #0xfb1428
020f2f64: 31f9ba97 bl       #0xfb1428
020f2f68: 30f9ba97 bl       #0xfb1428
020f2f6c: e0031baa mov      x0, x27
020f2f70: 1aa9ba97 bl       #0xf9d3d8
020f2f74: 2df9ba97 bl       #0xfb1428
020f2f78: 2cf9ba97 bl       #0xfb1428
020f2f7c: 2bf9ba97 bl       #0xfb1428
020f2f80: 2af9ba97 bl       #0xfb1428
020f2f84: 29f9ba97 bl       #0xfb1428
020f2f88: 28f9ba97 bl       #0xfb1428
020f2f8c: e00316aa mov      x0, x22
020f2f90: 12a9ba97 bl       #0xf9d3d8
020f2f94: 25f9ba97 bl       #0xfb1428
020f2f98: 58000014 b        #0x20f30f8
020f2f9c: 57000014 b        #0x20f30f8
020f2fa0: 56000014 b        #0x20f30f8
020f2fa4: 55000014 b        #0x20f30f8
020f2fa8: 54000014 b        #0x20f30f8
020f2fac: 53000014 b        #0x20f30f8
020f2fb0: 52000014 b        #0x20f30f8
020f2fb4: 51000014 b        #0x20f30f8
020f2fb8: 50000014 b        #0x20f30f8
020f2fbc: 4f000014 b        #0x20f30f8
020f2fc0: 4e000014 b        #0x20f30f8
020f2fc4: 4d000014 b        #0x20f30f8
020f2fc8: 4c000014 b        #0x20f30f8
020f2fcc: 4b000014 b        #0x20f30f8
020f2fd0: 4a000014 b        #0x20f30f8
020f2fd4: 29000014 b        #0x20f3078
020f2fd8: 28000014 b        #0x20f3078
020f2fdc: 47000014 b        #0x20f30f8
020f2fe0: 46000014 b        #0x20f30f8
020f2fe4: 45000014 b        #0x20f30f8
020f2fe8: f30301aa mov      x19, x1
020f2fec: fa0300aa mov      x26, x0
020f2ff0: c7ffff17 b        #0x20f2f0c
020f2ff4: 41000014 b        #0x20f30f8
020f2ff8: 40000014 b        #0x20f30f8
020f2ffc: 3f000014 b        #0x20f30f8
020f3000: 3e000014 b        #0x20f30f8
020f3004: 3d000014 b        #0x20f30f8
020f3008: 3c000014 b        #0x20f30f8
020f300c: 3b000014 b        #0x20f30f8
020f3010: 3a000014 b        #0x20f30f8
020f3014: 39000014 b        #0x20f30f8
020f3018: 38000014 b        #0x20f30f8
020f301c: 37000014 b        #0x20f30f8
020f3020: 36000014 b        #0x20f30f8
020f3024: 35000014 b        #0x20f30f8
020f3028: 34000014 b        #0x20f30f8
020f302c: 33000014 b        #0x20f30f8
020f3030: 32000014 b        #0x20f30f8
020f3034: 31000014 b        #0x20f30f8
020f3038: 30000014 b        #0x20f30f8
020f303c: 2f000014 b        #0x20f30f8
020f3040: 2e000014 b        #0x20f30f8
020f3044: 2d000014 b        #0x20f30f8
020f3048: 2c000014 b        #0x20f30f8
020f304c: 2b000014 b        #0x20f30f8
020f3050: 2a000014 b        #0x20f30f8
020f3054: 29000014 b        #0x20f30f8
020f3058: 28000014 b        #0x20f30f8
020f305c: 27000014 b        #0x20f30f8
020f3060: 26000014 b        #0x20f30f8
020f3064: 25000014 b        #0x20f30f8
020f3068: 24000014 b        #0x20f30f8
020f306c: 23000014 b        #0x20f30f8
020f3070: 22000014 b        #0x20f30f8
020f3074: 01000014 b        #0x20f3078
020f3078: f70301aa mov      x23, x1
020f307c: fa0300aa mov      x26, x0
020f3080: ff060071 cmp      w23, #1
020f3084: 81010054 b.ne     #0x20f30b4
020f3088: e0031aaa mov      x0, x26
020f308c: 5141af97 bl       #0xcc35d0
020f3090: 160040f9 ldr      x22, [x0]
020f3094: cb3faf97 bl       #0xcc2fc0
020f3098: 188a01d0 adrp     x24, #0x5235000
020f309c: 398501f0 adrp     x25, #0x519a000
020f30a0: 18b747f9 ldr      x24, [x24, #0xf68]
020f30a4: f40f40f9 ldr      x20, [sp, #0x18]
020f30a8: 390b43f9 ldr      x25, [x25, #0x610]
020f30ac: f3031f2a mov      w19, wzr
020f30b0: 16ffff17 b        #0x20f2d08
020f30b4: f6031faa mov      x22, xzr
020f30b8: e88401f0 adrp     x8, #0x5192000
020f30bc: 082d41f9 ldr      x8, [x8, #0x258]
020f30c0: 010140f9 ldr      x1, [x8]
020f30c4: e0430791 add      x0, sp, #0x1d0
020f30c8: d8ff2794 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
020f30cc: e10317aa mov      x1, x23
020f30d0: 760100b4 cbz      x22, #0x20f30fc
020f30d4: e00316aa mov      x0, x22
020f30d8: c0a8ba97 bl       #0xf9d3d8
020f30dc: f70301aa mov      x23, x1
020f30e0: fa0300aa mov      x26, x0
020f30e4: f5ffff17 b        #0x20f30b8
020f30e8: 04000014 b        #0x20f30f8
020f30ec: 03000014 b        #0x20f30f8
020f30f0: 02000014 b        #0x20f30f8
020f30f4: 01000014 b        #0x20f30f8
020f30f8: fa0300aa mov      x26, x0
020f30fc: 3f040071 cmp      w1, #1
020f3100: e1010054 b.ne     #0x20f313c
020f3104: e0031aaa mov      x0, x26
020f3108: 3241af97 bl       #0xcc35d0
020f310c: 140040f9 ldr      x20, [x0]
020f3110: ac3faf97 bl       #0xcc2fc0
020f3114: 28880190 adrp     x8, #0x51f7000
020f3118: 08ad47f9 ldr      x8, [x8, #0xf58]
020f311c: e0c30791 add      x0, sp, #0x1f0
020f3120: 010140f9 ldr      x1, [x8]
020f3124: c8903394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020f3128: 188a01d0 adrp     x24, #0x5235000
020f312c: 18b747f9 ldr      x24, [x24, #0xf68]
020f3130: f4caffb4 cbz      x20, #0x20f2a8c
020f3134: e00314aa mov      x0, x20
020f3138: a8a8ba97 bl       #0xf9d3d8
020f313c: f4031faa mov      x20, xzr
020f3140: 02000014 b        #0x20f3148
020f3144: fa0300aa mov      x26, x0
020f3148: 28880190 adrp     x8, #0x51f7000
020f314c: 08ad47f9 ldr      x8, [x8, #0xf58]
020f3150: 010140f9 ldr      x1, [x8]
020f3154: e0c30791 add      x0, sp, #0x1f0
020f3158: bb903394 bl       #0x2dd7444 ; System.Collections.Generic.SortedDictionary.Enumerator<int, object>$$Dispose
020f315c: 740000b5 cbnz     x20, #0x20f3168
020f3160: e0031aaa mov      x0, x26
020f3164: 673faf97 bl       #0xcc2f00
020f3168: e00314aa mov      x0, x20
020f316c: 9ba8ba97 bl       #0xf9d3d8
020f3170: 7655af97 bl       #0xcc8748
