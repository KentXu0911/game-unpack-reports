# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$.ctor
# Linear span to next metadata entry; not a complete CFG.
0339af54: e80f1dfc str      d8, [sp, #-0x30]!
0339af58: f55301a9 stp      x21, x20, [sp, #0x10]
0339af5c: f37b02a9 stp      x19, x30, [sp, #0x20]
0339af60: 740f0190 adrp     x20, #0x5586000
0339af64: f5f200b0 adrp     x21, #0x51f7000
0339af68: 889a6639 ldrb     w8, [x20, #0x9a6]
0339af6c: b5fa44f9 ldr      x21, [x21, #0x9f0]
0339af70: 081ca04e mov      v8.16b, v0.16b
0339af74: f30300aa mov      x19, x0
0339af78: c8000037 tbnz     w8, #0, #0x339af90
0339af7c: e0f200b0 adrp     x0, #0x51f7000
0339af80: 00f844f9 ldr      x0, [x0, #0x9f0]
0339af84: df587097 bl       #0xfb1300
0339af88: 28008052 mov      w8, #1
0339af8c: 889a2639 strb     w8, [x20, #0x9a6]
0339af90: a00240f9 ldr      x0, [x21]
0339af94: 08e040b9 ldr      w8, [x0, #0xe0]
0339af98: 48000035 cbnz     w8, #0x339afa0
0339af9c: 1a597097 bl       #0xfb1404
0339afa0: e00313aa mov      x0, x19
0339afa4: e1031faa mov      x1, xzr
0339afa8: 9361bb97 bl       #0x22735f4 ; System.Object$$.ctor
0339afac: 68ba00bd str      s8, [x19, #0xb8]
0339afb0: f37b42a9 ldp      x19, x30, [sp, #0x20]
0339afb4: f55341a9 ldp      x21, x20, [sp, #0x10]
0339afb8: e80743fc ldr      d8, [sp], #0x30
0339afbc: c0035fd6 ret      
