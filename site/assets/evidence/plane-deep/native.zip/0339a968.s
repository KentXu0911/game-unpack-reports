# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$CalculateAngleSmoothCoefficient
# Linear span to next metadata entry; not a complete CFG.
0339a968: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
0339a96c: f30300aa mov      x19, x0
0339a970: e0031faa mov      x0, xzr
0339a974: ade0ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
0339a978: 612640bd ldr      s1, [x19, #0x24]
0339a97c: 685600b0 adrp     x8, #0x3e67000
0339a980: 027d44bd ldr      s2, [x8, #0x47c]
0339a984: 03102e1e fmov     s3, #1.00000000
0339a988: 0038211e fsub     s0, s0, s1
0339a98c: 0018221e fdiv     s0, s0, s2
0339a990: 0158231e fmin     s1, s0, s3
0339a994: 6138211e fsub     s1, s3, s1
0339a998: 0820201e fcmp     s0, #0.0
0339a99c: 205c231e fcsel    s0, s1, s3, pl
0339a9a0: f37bc1a8 ldp      x19, x30, [sp], #0x10
0339a9a4: c0035fd6 ret      
