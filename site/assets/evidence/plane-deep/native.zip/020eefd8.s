# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$get_Id
# Linear span to next metadata entry; not a complete CFG.
020eefd8: a0018052 mov      w0, #0xd
020eefdc: c0035fd6 ret      
