# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$Move
# Linear span to next metadata entry; not a complete CFG.
0339cfb0: e80f1efc str      d8, [sp, #-0x20]!
0339cfb4: f40700f9 str      x20, [sp, #8]
0339cfb8: f37b01a9 stp      x19, x30, [sp, #0x10]
0339cfbc: 540f01d0 adrp     x20, #0x5586000
0339cfc0: 88d26639 ldrb     w8, [x20, #0x9b4]
0339cfc4: f30300aa mov      x19, x0
0339cfc8: c8000037 tbnz     w8, #0, #0x339cfe0
0339cfcc: 80f400f0 adrp     x0, #0x522f000
0339cfd0: 000445f9 ldr      x0, [x0, #0xa08]
0339cfd4: cb507097 bl       #0xfb1300
0339cfd8: 28008052 mov      w8, #1
0339cfdc: 88d22639 strb     w8, [x20, #0x9b4]
0339cfe0: 747a40b9 ldr      w20, [x19, #0x78]
0339cfe4: e0031faa mov      x0, xzr
0339cfe8: e0d6ce97 bl       #0x2752b68 ; Royal.Scenes.Game.Levels.LevelContext$$get_FrameCount
0339cfec: 9f02006b cmp      w20, w0
0339cff0: 20050054 b.eq     #0x339d094
0339cff4: e0031faa mov      x0, xzr
0339cff8: dcd6ce97 bl       #0x2752b68 ; Royal.Scenes.Game.Levels.LevelContext$$get_FrameCount
0339cffc: 681640bd ldr      s8, [x19, #0x14]
0339d000: 607a00b9 str      w0, [x19, #0x78]
0339d004: e0031faa mov      x0, xzr
0339d008: 72cdce97 bl       #0x27505d0 ; Royal.Scenes.Game.Levels.LevelContext$$get_DeltaTime
0339d00c: 743240f9 ldr      x20, [x19, #0x60]
0339d010: 0029201e fadd     s0, s8, s0
0339d014: 601600bd str      s0, [x19, #0x14]
0339d018: 740400b4 cbz      x20, #0x339d0a4
0339d01c: 8af400d0 adrp     x10, #0x522f000
0339d020: 880240f9 ldr      x8, [x20]
0339d024: 4a0545f9 ldr      x10, [x10, #0xa08]
0339d028: 09554279 ldrh     w9, [x8, #0x12a]
0339d02c: 410140f9 ldr      x1, [x10]
0339d030: 290100b4 cbz      x9, #0x339d054
0339d034: 0a5940f9 ldr      x10, [x8, #0xb0]
0339d038: 4a210091 add      x10, x10, #8
0339d03c: 4b815ff8 ldur     x11, [x10, #-8]
0339d040: 7f0101eb cmp      x11, x1
0339d044: 00010054 b.eq     #0x339d064
0339d048: 290500f1 subs     x9, x9, #1
0339d04c: 4a410091 add      x10, x10, #0x10
0339d050: 61ffff54 b.ne     #0x339d03c
0339d054: e00314aa mov      x0, x20
0339d058: e2031f2a mov      w2, wzr
0339d05c: 9e906f97 bl       #0xf812d4
0339d060: 04000014 b        #0x339d070
0339d064: 490180b9 ldrsw    x9, [x10]
0339d068: 0811098b add      x8, x8, x9, lsl #4
0339d06c: 00e10491 add      x0, x8, #0x138
0339d070: 080440a9 ldp      x8, x1, [x0]
0339d074: e00314aa mov      x0, x20
0339d078: 00013fd6 blr      x8
0339d07c: c0000036 tbz      w0, #0, #0x339d094
0339d080: e00313aa mov      x0, x19
0339d084: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339d088: f40740f9 ldr      x20, [sp, #8]
0339d08c: e80742fc ldr      d8, [sp], #0x20
0339d090: af010014 b        #0x339d74c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$MoveToTarget
0339d094: f37b41a9 ldp      x19, x30, [sp, #0x10]
0339d098: f40740f9 ldr      x20, [sp, #8]
0339d09c: e80742fc ldr      d8, [sp], #0x20
0339d0a0: c0035fd6 ret      
0339d0a4: e1507097 bl       #0xfb1428
