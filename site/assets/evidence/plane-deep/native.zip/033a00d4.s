# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TargetChanged
# Linear span to next metadata entry; not a complete CFG.
033a00d4: 001c40bd ldr      s0, [x0, #0x1c]
033a00d8: 098440b9 ldr      w9, [x0, #0x84]
033a00dc: 01102c1e fmov     s1, #0.50000000
033a00e0: 48008052 mov      w8, #2
033a00e4: 0058211e fmin     s0, s0, s1
033a00e8: 3f090071 cmp      w9, #2
033a00ec: 086800b9 str      w8, [x0, #0x68]
033a00f0: 001c00bd str      s0, [x0, #0x1c]
033a00f4: 81000054 b.ne     #0x33a0104
033a00f8: 28008052 mov      w8, #1
033a00fc: 088400b9 str      w8, [x0, #0x84]
033a0100: 08540239 strb     w8, [x0, #0x95]
033a0104: c0035fd6 ret      
