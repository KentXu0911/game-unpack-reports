# Royal.Scenes.Game.Levels.Units.Explode.ExplodeTargetFinder$$GetNextSortingOffset
# Linear span to next metadata entry; not a complete CFG.
020ef280: f553bea9 stp      x21, x20, [sp, #-0x20]!
020ef284: f37b01a9 stp      x19, x30, [sp, #0x10]
020ef288: 75a401d0 adrp     x21, #0x557d000
020ef28c: f4850190 adrp     x20, #0x51ab000
020ef290: a8125539 ldrb     w8, [x21, #0x544]
020ef294: 94c642f9 ldr      x20, [x20, #0x588]
020ef298: f303002a mov      w19, w0
020ef29c: c8000037 tbnz     w8, #0, #0x20ef2b4
020ef2a0: e0850190 adrp     x0, #0x51ab000
020ef2a4: 00c442f9 ldr      x0, [x0, #0x588]
020ef2a8: 1608bb97 bl       #0xfb1300
020ef2ac: 28008052 mov      w8, #1
020ef2b0: a8121539 strb     w8, [x21, #0x544]
020ef2b4: 880240f9 ldr      x8, [x20]
020ef2b8: 085d40f9 ldr      x8, [x8, #0xb8]
020ef2bc: 090140b9 ldr      w9, [x8]
020ef2c0: 29050071 subs     w9, w9, #1
020ef2c4: 090100b9 str      w9, [x8]
020ef2c8: 85010054 b.pl     #0x20ef2f8
020ef2cc: 75a401d0 adrp     x21, #0x557d000
020ef2d0: a90e5539 ldrb     w9, [x21, #0x543]
020ef2d4: e9000037 tbnz     w9, #0, #0x20ef2f0
020ef2d8: e00314aa mov      x0, x20
020ef2dc: 0908bb97 bl       #0xfb1300
020ef2e0: 880240f9 ldr      x8, [x20]
020ef2e4: 29008052 mov      w9, #1
020ef2e8: a90e1539 strb     w9, [x21, #0x543]
020ef2ec: 085d40f9 ldr      x8, [x8, #0xb8]
020ef2f0: 09e28452 mov      w9, #0x2710
020ef2f4: 090100b9 str      w9, [x8]
020ef2f8: 7f020072 tst      w19, #1
020ef2fc: f37b41a9 ldp      x19, x30, [sp, #0x10]
020ef300: 28590051 sub      w8, w9, #0x16
020ef304: 0011891a csel     w0, w8, w9, ne
020ef308: f553c2a8 ldp      x21, x20, [sp], #0x20
020ef30c: c0035fd6 ret      
