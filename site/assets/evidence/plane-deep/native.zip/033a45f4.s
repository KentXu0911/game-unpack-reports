# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$ExplodeNeighbors
# Linear span to next metadata entry; not a complete CFG.
033a45f4: fe0f1ff8 str      x30, [sp, #-0x10]!
033a45f8: 08c84039 ldrb     w8, [x0, #0x32]
033a45fc: 68000034 cbz      w8, #0x33a4608
033a4600: e0031f2a mov      w0, wzr
033a4604: 03000014 b        #0x33a4610
033a4608: 64f9ff97 bl       #0x33a2b98 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$ExplodeNeighbors
033a460c: 20008052 mov      w0, #1
033a4610: fe0741f8 ldr      x30, [sp], #0x10
033a4614: c0035fd6 ret      
