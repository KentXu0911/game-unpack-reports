# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$get_FlyState
# Linear span to next metadata entry; not a complete CFG.
0339ccc8: 006840b9 ldr      w0, [x0, #0x68]
0339cccc: c0035fd6 ret      
