# Royal.Scenes.Game.Mechanics.Items.IvyItem.IvyItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
023e7f28: f553bea9 stp      x21, x20, [sp, #-0x20]!
023e7f2c: f37b01a9 stp      x19, x30, [sp, #0x10]
023e7f30: 080040f9 ldr      x8, [x0]
023e7f34: f403012a mov      w20, w1
023e7f38: f30300aa mov      x19, x0
023e7f3c: 096542f9 ldr      x9, [x8, #0x4c8]
023e7f40: 086942f9 ldr      x8, [x8, #0x4d0]
023e7f44: e10308aa mov      x1, x8
023e7f48: 20013fd6 blr      x9
023e7f4c: f503002a mov      w21, w0
023e7f50: e00313aa mov      x0, x19
023e7f54: e103142a mov      w1, w20
023e7f58: e2031faa mov      x2, xzr
023e7f5c: 84723e94 bl       #0x338496c ; Royal.Scenes.Game.Mechanics.Items.Config.ItemModel$$GetExplodeScore
023e7f60: bf060071 cmp      w21, #1
023e7f64: f403002a mov      w20, w0
023e7f68: a1020054 b.ne     #0x23e7fbc
023e7f6c: 680240f9 ldr      x8, [x19]
023e7f70: e00313aa mov      x0, x19
023e7f74: 09bd41f9 ldr      x9, [x8, #0x378]
023e7f78: 01c141f9 ldr      x1, [x8, #0x380]
023e7f7c: 20013fd6 blr      x9
023e7f80: e1031faa mov      x1, xzr
023e7f84: 81723e94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
023e7f88: f503002a mov      w21, w0
023e7f8c: 0afdff97 bl       #0x23e73b4 ; Royal.Scenes.Game.Mechanics.Items.IvyItem.IvyItemModel$$get_ItemHelper
023e7f90: e00100b4 cbz      x0, #0x23e7fcc
023e7f94: e10313aa mov      x1, x19
023e7f98: b8f2ff97 bl       #0x23e4a78 ; Royal.Scenes.Game.Mechanics.Items.IvyItem.IvyItemHelper$$GetAffectedItemCount
023e7f9c: c9aa8a52 mov      w9, #0x5556
023e7fa0: 087c151b mul      w8, w0, w21
023e7fa4: a9aaaa72 movk     w9, #0x5555, lsl #16
023e7fa8: 087d299b smull    x8, w8, w9
023e7fac: 09fd7fd3 lsr      x9, x8, #0x3f
023e7fb0: 08fd60d3 lsr      x8, x8, #0x20
023e7fb4: 0801090b add      w8, w8, w9
023e7fb8: 1401140b add      w20, w8, w20
023e7fbc: f37b41a9 ldp      x19, x30, [sp, #0x10]
023e7fc0: e003142a mov      w0, w20
023e7fc4: f553c2a8 ldp      x21, x20, [sp], #0x20
023e7fc8: c0035fd6 ret      
023e7fcc: 1725af97 bl       #0xfb1428
