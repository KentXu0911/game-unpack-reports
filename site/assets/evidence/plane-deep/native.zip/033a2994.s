# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.FireworksRocketStrategy$$GetNewPilot
# Linear span to next metadata entry; not a complete CFG.
033a2994: ea0f1cfc str      d10, [sp, #-0x40]!
033a2998: e923016d stp      d9, d8, [sp, #0x10]
033a299c: f55302a9 stp      x21, x20, [sp, #0x20]
033a29a0: f37b03a9 stp      x19, x30, [sp, #0x30]
033a29a4: 350f0190 adrp     x21, #0x5586000
033a29a8: 34f200f0 adrp     x20, #0x51e9000
033a29ac: a81e6739 ldrb     w8, [x21, #0x9c7]
033a29b0: 94ee44f9 ldr      x20, [x20, #0x9d8]
033a29b4: f30300aa mov      x19, x0
033a29b8: c8000037 tbnz     w8, #0, #0x33a29d0
033a29bc: 20f200f0 adrp     x0, #0x51e9000
033a29c0: 00ec44f9 ldr      x0, [x0, #0x9d8]
033a29c4: 4f3a7097 bl       #0xfb1300
033a29c8: 28008052 mov      w8, #1
033a29cc: a81e2739 strb     w8, [x21, #0x9c7]
033a29d0: 800240f9 ldr      x0, [x20]
033a29d4: 68a6452d ldp      s8, s9, [x19, #0x2c]
033a29d8: 6a3640bd ldr      s10, [x19, #0x34]
033a29dc: 731e40f9 ldr      x19, [x19, #0x38]
033a29e0: 8e3a7097 bl       #0xfb1418
033a29e4: a00100b4 cbz      x0, #0x33a2a18
033a29e8: 001da84e mov      v0.16b, v8.16b
033a29ec: 211da94e mov      v1.16b, v9.16b
033a29f0: 421daa4e mov      v2.16b, v10.16b
033a29f4: e10313aa mov      x1, x19
033a29f8: f40300aa mov      x20, x0
033a29fc: 7fe8ff97 bl       #0x339cbf8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$.ctor
033a2a00: e00314aa mov      x0, x20
033a2a04: f37b43a9 ldp      x19, x30, [sp, #0x30]
033a2a08: f55342a9 ldp      x21, x20, [sp, #0x20]
033a2a0c: e923416d ldp      d9, d8, [sp, #0x10]
033a2a10: ea0744fc ldr      d10, [sp], #0x40
033a2a14: c0035fd6 ret      
033a2a18: 843a7097 bl       #0xfb1428
