# Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinConditionForHorizontalRocket
# Linear span to next metadata entry; not a complete CFG.
026a8394: ffc302d1 sub      sp, sp, #0xb0
026a8398: f75b08a9 stp      x23, x22, [sp, #0x80]
026a839c: f55309a9 stp      x21, x20, [sp, #0x90]
026a83a0: f37b0aa9 stp      x19, x30, [sp, #0xa0]
026a83a4: f30302aa mov      x19, x2
026a83a8: f403012a mov      w20, w1
026a83ac: f50300aa mov      x21, x0
026a83b0: fd000094 bl       #0x26a87a4 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$ShouldCalculateSpecificWinConditions
026a83b4: e0020036 tbz      w0, #0, #0x26a8410
026a83b8: a00e40f9 ldr      x0, [x21, #0x18]
026a83bc: 000600b4 cbz      x0, #0x26a847c
026a83c0: f6031f2a mov      w22, wzr
026a83c4: e1031faa mov      x1, xzr
026a83c8: 06bb0294 bl       #0x2756fe0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Width
026a83cc: df02006b cmp      w22, w0
026a83d0: 4a020054 b.ge     #0x26a8418
026a83d4: 681a40f9 ldr      x8, [x19, #0x30]
026a83d8: 618240ad ldp      q1, q0, [x19, #0x10]
026a83dc: 6202c03d ldr      q2, [x19]
026a83e0: e3030191 add      x3, sp, #0x40
026a83e4: e00315aa mov      x0, x21
026a83e8: e103162a mov      w1, w22
026a83ec: e203142a mov      w2, w20
026a83f0: e83b00f9 str      x8, [sp, #0x70]
026a83f4: e18302ad stp      q1, q0, [sp, #0x50]
026a83f8: e213803d str      q2, [sp, #0x40]
026a83fc: fb000094 bl       #0x26a87e8 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$AddTemporaryIncomingExploder
026a8400: a00e40f9 ldr      x0, [x21, #0x18]
026a8404: d6060011 add      w22, w22, #1
026a8408: e0fdffb5 cbnz     x0, #0x26a83c4
026a840c: 1c000014 b        #0x26a847c
026a8410: f6031f2a mov      w22, wzr
026a8414: 1b000014 b        #0x26a8480
026a8418: e00315aa mov      x0, x21
026a841c: 2c010094 bl       #0x26a88cc ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$WillNotWinDueToSpecificWinCondition
026a8420: a80e40f9 ldr      x8, [x21, #0x18]
026a8424: c80200b4 cbz      x8, #0x26a847c
026a8428: f603002a mov      w22, w0
026a842c: f7031f2a mov      w23, wzr
026a8430: e00308aa mov      x0, x8
026a8434: e1031faa mov      x1, xzr
026a8438: eaba0294 bl       #0x2756fe0 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Width
026a843c: ff02006b cmp      w23, w0
026a8440: 0a020054 b.ge     #0x26a8480
026a8444: 681a40f9 ldr      x8, [x19, #0x30]
026a8448: 618240ad ldp      q1, q0, [x19, #0x10]
026a844c: 6202c03d ldr      q2, [x19]
026a8450: e3030091 mov      x3, sp
026a8454: e00315aa mov      x0, x21
026a8458: e103172a mov      w1, w23
026a845c: e203142a mov      w2, w20
026a8460: e81b00f9 str      x8, [sp, #0x30]
026a8464: e18300ad stp      q1, q0, [sp, #0x10]
026a8468: e203803d str      q2, [sp]
026a846c: 81010094 bl       #0x26a8a70 ; Royal.Scenes.Game.Levels.Units.Explode.WinCalculationData$$RemoveTemporaryIncomingExploder
026a8470: a80e40f9 ldr      x8, [x21, #0x18]
026a8474: f7060011 add      w23, w23, #1
026a8478: c8fdffb5 cbnz     x8, #0x26a8430
026a847c: eb23a497 bl       #0xfb1428
026a8480: c0020012 and      w0, w22, #1
026a8484: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
026a8488: f55349a9 ldp      x21, x20, [sp, #0x90]
026a848c: f75b48a9 ldp      x23, x22, [sp, #0x80]
026a8490: ffc30291 add      sp, sp, #0xb0
026a8494: c0035fd6 ret      
