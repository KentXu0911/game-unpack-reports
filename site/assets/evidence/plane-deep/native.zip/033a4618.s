# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$IsComboExploder
# Linear span to next metadata entry; not a complete CFG.
033a4618: 20008052 mov      w0, #1
033a461c: c0035fd6 ret      
