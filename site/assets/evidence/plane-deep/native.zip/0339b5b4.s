# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_OutAngle
# Linear span to next metadata entry; not a complete CFG.
0339b5b4: 00b440bd ldr      s0, [x0, #0xb4]
0339b5b8: c0035fd6 ret      
