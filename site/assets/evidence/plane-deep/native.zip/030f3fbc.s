# Royal.Scenes.Game.Mechanics.Items.ColorMixerItem.ColorMixerItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
030f3fbc: f40f1ef8 str      x20, [sp, #-0x20]!
030f3fc0: f37b01a9 stp      x19, x30, [sp, #0x10]
030f3fc4: 080040f9 ldr      x8, [x0]
030f3fc8: f303012a mov      w19, w1
030f3fcc: f40300aa mov      x20, x0
030f3fd0: 096542f9 ldr      x9, [x8, #0x4c8]
030f3fd4: 086942f9 ldr      x8, [x8, #0x4d0]
030f3fd8: e10308aa mov      x1, x8
030f3fdc: 20013fd6 blr      x9
030f3fe0: 00030034 cbz      w0, #0x30f4040
030f3fe4: e003132a mov      w0, w19
030f3fe8: e1031faa mov      x1, xzr
030f3fec: 70420a94 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
030f3ff0: 80000036 tbz      w0, #0, #0x30f4000
030f3ff4: 00918f52 mov      w0, #0x7c88
030f3ff8: 6000a072 movk     w0, #3, lsl #16
030f3ffc: 11000014 b        #0x30f4040
030f4000: 880240f9 ldr      x8, [x20]
030f4004: e00314aa mov      x0, x20
030f4008: 096542f9 ldr      x9, [x8, #0x4c8]
030f400c: 016942f9 ldr      x1, [x8, #0x4d0]
030f4010: 20013fd6 blr      x9
030f4014: 1f040071 cmp      w0, #1
030f4018: a1010054 b.ne     #0x30f404c
030f401c: e003132a mov      w0, w19
030f4020: e1031faa mov      x1, xzr
030f4024: 46420a94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
030f4028: 08229f52 mov      w8, #0xf910
030f402c: 09fd9852 mov      w9, #0xc7e8
030f4030: 1f000072 tst      w0, #1
030f4034: c800a072 movk     w8, #6, lsl #16
030f4038: 2902a072 movk     w9, #0x11, lsl #16
030f403c: 2011881a csel     w0, w9, w8, ne
030f4040: f37b41a9 ldp      x19, x30, [sp, #0x10]
030f4044: f40742f8 ldr      x20, [sp], #0x20
030f4048: c0035fd6 ret      
030f404c: e103132a mov      w1, w19
030f4050: f37b41a9 ldp      x19, x30, [sp, #0x10]
030f4054: e00314aa mov      x0, x20
030f4058: e2031faa mov      x2, xzr
030f405c: f40742f8 ldr      x20, [sp], #0x20
030f4060: 0c770a14 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
