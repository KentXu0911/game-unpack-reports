# Royal.Scenes.Game.Mechanics.Items.SquirrelItem.SquirrelHorizontalItem.SquirrelHorizontalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03688f4c: f75bbda9 stp      x23, x22, [sp, #-0x30]!
03688f50: f55301a9 stp      x21, x20, [sp, #0x10]
03688f54: f37b02a9 stp      x19, x30, [sp, #0x20]
03688f58: 080040f9 ldr      x8, [x0]
03688f5c: f303012a mov      w19, w1
03688f60: f40300aa mov      x20, x0
03688f64: 096542f9 ldr      x9, [x8, #0x4c8]
03688f68: 086942f9 ldr      x8, [x8, #0x4d0]
03688f6c: e10308aa mov      x1, x8
03688f70: 20013fd6 blr      x9
03688f74: f603002a mov      w22, w0
03688f78: e003132a mov      w0, w19
03688f7c: e1031faa mov      x1, xzr
03688f80: 8beef397 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03688f84: c0000036 tbz      w0, #0, #0x3688f9c
03688f88: df0a0071 cmp      w22, #2
03688f8c: 4d030054 b.le     #0x3688ff4
03688f90: 15168b52 mov      w21, #0x58b0
03688f94: 7500a072 movk     w21, #3, lsl #16
03688f98: 26000014 b        #0x3689030
03688f9c: 17229f52 mov      w23, #0xf910
03688fa0: df0e0071 cmp      w22, #3
03688fa4: d700a072 movk     w23, #6, lsl #16
03688fa8: 40030054 b.eq     #0x3689010
03688fac: 15229f52 mov      w21, #0xf910
03688fb0: df0a0071 cmp      w22, #2
03688fb4: d500a072 movk     w21, #6, lsl #16
03688fb8: c0030054 b.eq     #0x3689030
03688fbc: df060071 cmp      w22, #1
03688fc0: a1010054 b.ne     #0x3688ff4
03688fc4: 15449e52 mov      w21, #0xf220
03688fc8: e003132a mov      w0, w19
03688fcc: e1031faa mov      x1, xzr
03688fd0: b501a072 movk     w21, #0xd, lsl #16
03688fd4: 5aeef397 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03688fd8: c0020037 tbnz     w0, #0, #0x3689030
03688fdc: e003132a mov      w0, w19
03688fe0: e1031faa mov      x1, xzr
03688fe4: e806f497 bl       #0x338ab84 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsVerticalLineExploder
03688fe8: 1f000072 tst      w0, #1
03688fec: a012971a csel     w0, w21, w23, ne
03688ff0: 11000014 b        #0x3689034
03688ff4: e00314aa mov      x0, x20
03688ff8: e103132a mov      w1, w19
03688ffc: f37b42a9 ldp      x19, x30, [sp, #0x20]
03689000: f55341a9 ldp      x21, x20, [sp, #0x10]
03689004: e2031faa mov      x2, xzr
03689008: f75bc3a8 ldp      x23, x22, [sp], #0x30
0368900c: 2123f417 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
03689010: 68021f32 orr      w8, w19, #2
03689014: 1f1d0071 cmp      w8, #7
03689018: 81000054 b.ne     #0x3689028
0368901c: 15229f52 mov      w21, #0xf910
03689020: d500a072 movk     w21, #6, lsl #16
03689024: 03000014 b        #0x3689030
03689028: 15819252 mov      w21, #0x9408
0368902c: b500a072 movk     w21, #5, lsl #16
03689030: e003152a mov      w0, w21
03689034: f37b42a9 ldp      x19, x30, [sp, #0x20]
03689038: f55341a9 ldp      x21, x20, [sp, #0x10]
0368903c: f75bc3a8 ldp      x23, x22, [sp], #0x30
03689040: c0035fd6 ret      
