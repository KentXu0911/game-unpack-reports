# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy$$OnTargetFound
# Linear span to next metadata entry; not a complete CFG.
033a4338: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a433c: 080040f9 ldr      x8, [x0]
033a4340: 131c40f9 ldr      x19, [x0, #0x38]
033a4344: 097d41f9 ldr      x9, [x8, #0x2f8]
033a4348: 018141f9 ldr      x1, [x8, #0x300]
033a434c: 20013fd6 blr      x9
033a4350: d30000b4 cbz      x19, #0x33a4368
033a4354: e103002a mov      w1, w0
033a4358: e00313aa mov      x0, x19
033a435c: e2031faa mov      x2, xzr
033a4360: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a4364: 8b1fda17 b        #0x2a2c190 ; Royal.Scenes.Game.Levels.Units.State.GameStateManager$$OperationStart
033a4368: 30347097 bl       #0xfb1428
