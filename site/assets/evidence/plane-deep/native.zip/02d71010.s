# Royal.Scenes.Game.Mechanics.Items.FurnaceItem.FurnaceItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02d71010: f553bea9 stp      x21, x20, [sp, #-0x20]!
02d71014: f37b01a9 stp      x19, x30, [sp, #0x10]
02d71018: 080040f9 ldr      x8, [x0]
02d7101c: f303012a mov      w19, w1
02d71020: f40300aa mov      x20, x0
02d71024: 096542f9 ldr      x9, [x8, #0x4c8]
02d71028: 086942f9 ldr      x8, [x8, #0x4d0]
02d7102c: e10308aa mov      x1, x8
02d71030: 20013fd6 blr      x9
02d71034: 1f040071 cmp      w0, #1
02d71038: 0b010054 b.lt     #0x2d71058
02d7103c: e003132a mov      w0, w19
02d71040: e1031faa mov      x1, xzr
02d71044: 5a4e1894 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
02d71048: c0000036 tbz      w0, #0, #0x2d71060
02d7104c: 14918f52 mov      w20, #0x7c88
02d71050: 7400a072 movk     w20, #3, lsl #16
02d71054: 14000014 b        #0x2d710a4
02d71058: f4031f2a mov      w20, wzr
02d7105c: 12000014 b        #0x2d710a4
02d71060: 803e40f9 ldr      x0, [x20, #0x78]
02d71064: 800200b4 cbz      x0, #0x2d710b4
02d71068: 956a40b9 ldr      w21, [x20, #0x68]
02d7106c: 14229f52 mov      w20, #0xf910
02d71070: e1031faa mov      x1, xzr
02d71074: d400a072 movk     w20, #6, lsl #16
02d71078: 0e25ff97 bl       #0x2d3a4b0 ; Royal.Scenes.Game.Mechanics.Explode.IncomingExploderContainer$$GetIncomingCount
02d7107c: a802004b sub      w8, w21, w0
02d71080: 1f050071 cmp      w8, #1
02d71084: 01010054 b.ne     #0x2d710a4
02d71088: e003132a mov      w0, w19
02d7108c: e1031faa mov      x1, xzr
02d71090: 2b4e1894 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
02d71094: 28f58c52 mov      w8, #0x67a9
02d71098: 1f000072 tst      w0, #1
02d7109c: 0803a072 movk     w8, #0x18, lsl #16
02d710a0: 1411941a csel     w20, w8, w20, ne
02d710a4: f37b41a9 ldp      x19, x30, [sp, #0x10]
02d710a8: e003142a mov      w0, w20
02d710ac: f553c2a8 ldp      x21, x20, [sp], #0x20
02d710b0: c0035fd6 ret      
02d710b4: dd008997 bl       #0xfb1428
