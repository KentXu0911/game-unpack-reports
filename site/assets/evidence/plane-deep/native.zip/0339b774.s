# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$IsPropSpecialCombo
# Linear span to next metadata entry; not a complete CFG.
0339b774: 20008052 mov      w0, #1
0339b778: c0035fd6 ret      
