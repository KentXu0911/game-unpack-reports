# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$InvalidateTarget
# Linear span to next metadata entry; not a complete CFG.
026a483c: 28008052 mov      w8, #1
026a4840: 09208052 mov      w9, #0x100
026a4844: 08d80339 strb     w8, [x0, #0xf6]
026a4848: 09e80179 strh     w9, [x0, #0xf4]
026a484c: 1f200439 strb     wzr, [x0, #0x108]
026a4850: c0035fd6 ret      
