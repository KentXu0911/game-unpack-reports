# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy$$NextExploder
# Linear span to next metadata entry; not a complete CFG.
033a401c: ffc302d1 sub      sp, sp, #0xb0
033a4020: f55309a9 stp      x21, x20, [sp, #0x90]
033a4024: f37b0aa9 stp      x19, x30, [sp, #0xa0]
033a4028: 55d03bd5 mrs      x21, tpidr_el0
033a402c: f30308aa mov      x19, x8
033a4030: a81640f9 ldr      x8, [x21, #0x28]
033a4034: 00e4006f movi     v0.2d, #0000000000000000
033a4038: e84700f9 str      x8, [sp, #0x88]
033a403c: ff7f04a9 stp      xzr, xzr, [sp, #0x40]
033a4040: ff5300b9 str      wzr, [sp, #0x50]
033a4044: e00303ad stp      q0, q0, [sp, #0x60]
033a4048: fff307b8 stur     wzr, [sp, #0x7f]
033a404c: 210500b4 cbz      x1, #0x33a40f0
033a4050: 084840b9 ldr      w8, [x0, #0x48]
033a4054: f40301aa mov      x20, x1
033a4058: 210c40f9 ldr      x1, [x1, #0x18]
033a405c: e2031faa mov      x2, xzr
033a4060: 1f010071 cmp      w8, #0
033a4064: 48018052 mov      w8, #0xa
033a4068: 0015881a cinc     w0, w8, eq
033a406c: e8230091 add      x8, sp, #8
033a4070: 5157e697 bl       #0x2d39db4 ; Royal.Scenes.Game.Mechanics.Explode.Exploder$$Next
033a4074: e083c03c ldur     q0, [sp, #8]
033a4078: e81b40b9 ldr      w8, [sp, #0x18]
033a407c: e1d3c13c ldur     q1, [sp, #0x1d]
033a4080: e2d3c23c ldur     q2, [sp, #0x2d]
033a4084: e93f40b9 ldr      w9, [sp, #0x3c]
033a4088: e00314aa mov      x0, x20
033a408c: e1031faa mov      x1, xzr
033a4090: e013803d str      q0, [sp, #0x40]
033a4094: e85300b9 str      w8, [sp, #0x50]
033a4098: e10b03ad stp      q1, q2, [sp, #0x60]
033a409c: e9f307b8 stur     w9, [sp, #0x7f]
033a40a0: 1a9fdc97 bl       #0x2acbd08 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$HasJellyView
033a40a4: e013c03d ldr      q0, [sp, #0x40]
033a40a8: 08000012 and      w8, w0, #1
033a40ac: e95340b9 ldr      w9, [sp, #0x50]
033a40b0: 68520039 strb     w8, [x19, #0x14]
033a40b4: 6002803d str      q0, [x19]
033a40b8: e10343ad ldp      q1, q0, [sp, #0x60]
033a40bc: e8f347b8 ldur     w8, [sp, #0x7f]
033a40c0: 691200b9 str      w9, [x19, #0x10]
033a40c4: 6152813c stur     q1, [x19, #0x15]
033a40c8: 6052823c stur     q0, [x19, #0x25]
033a40cc: 683600b9 str      w8, [x19, #0x34]
033a40d0: a81640f9 ldr      x8, [x21, #0x28]
033a40d4: e94740f9 ldr      x9, [sp, #0x88]
033a40d8: 1f0109eb cmp      x8, x9
033a40dc: c1000054 b.ne     #0x33a40f4
033a40e0: f37b4aa9 ldp      x19, x30, [sp, #0xa0]
033a40e4: f55349a9 ldp      x21, x20, [sp, #0x90]
033a40e8: ffc30291 add      sp, sp, #0xb0
033a40ec: c0035fd6 ret      
033a40f0: ce347097 bl       #0xfb1428
033a40f4: 177c6497 bl       #0xcc3150
