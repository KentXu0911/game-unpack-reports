# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerSpecialItemStrategy.<FinishOperationWithDelay>d__11$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a452c: f40f1ef8 str      x20, [sp, #-0x20]!
033a4530: f37b01a9 stp      x19, x30, [sp, #0x10]
033a4534: f303012a mov      w19, w1
033a4538: e1031faa mov      x1, xzr
033a453c: f40300aa mov      x20, x0
033a4540: 2d3cbb97 bl       #0x22735f4 ; System.Object$$.ctor
033a4544: 931200b9 str      w19, [x20, #0x10]
033a4548: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a454c: f40742f8 ldr      x20, [sp], #0x20
033a4550: c0035fd6 ret      
