# Royal.Scenes.Game.Mechanics.Items.WhackAMoleItem.WhackAMoleItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
03c187a4: f60f1df8 str      x22, [sp, #-0x30]!
03c187a8: f55301a9 stp      x21, x20, [sp, #0x10]
03c187ac: f37b02a9 stp      x19, x30, [sp, #0x20]
03c187b0: 95cb00f0 adrp     x21, #0x558b000
03c187b4: a81e4639 ldrb     w8, [x21, #0x187]
03c187b8: f303012a mov      w19, w1
03c187bc: f40300aa mov      x20, x0
03c187c0: c8000037 tbnz     w8, #0, #0x3c187d8
03c187c4: 00ad00b0 adrp     x0, #0x51b9000
03c187c8: 007045f9 ldr      x0, [x0, #0xae0]
03c187cc: cd624e97 bl       #0xfb1300
03c187d0: 28008052 mov      w8, #1
03c187d4: a81e0639 strb     w8, [x21, #0x187]
03c187d8: e003132a mov      w0, w19
03c187dc: e1031faa mov      x1, xzr
03c187e0: 50b0dd97 bl       #0x3384920 ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsMultipleExploder
03c187e4: 880240f9 ldr      x8, [x20]
03c187e8: 80000036 tbz      w0, #0, #0x3c187f8
03c187ec: 095542f9 ldr      x9, [x8, #0x4a8]
03c187f0: 015942f9 ldr      x1, [x8, #0x4b0]
03c187f4: 03000014 b        #0x3c18800
03c187f8: 096542f9 ldr      x9, [x8, #0x4c8]
03c187fc: 016942f9 ldr      x1, [x8, #0x4d0]
03c18800: e00314aa mov      x0, x20
03c18804: 20013fd6 blr      x9
03c18808: f603002a mov      w22, w0
03c1880c: e003132a mov      w0, w19
03c18810: e1031faa mov      x1, xzr
03c18814: 66b0dd97 bl       #0x33849ac ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsAreaExploderStrategy
03c18818: a0010036 tbz      w0, #0, #0x3c1884c
03c1881c: c87a1f12 and      w8, w22, #0xfffffffe
03c18820: 1f090071 cmp      w8, #2
03c18824: 80030054 b.eq     #0x3c18894
03c18828: df060071 cmp      w22, #1
03c1882c: 00020054 b.eq     #0x3c1886c
03c18830: df0a0071 cmp      w22, #2
03c18834: e0060054 b.eq     #0x3c18910
03c18838: df120071 cmp      w22, #4
03c1883c: c1020054 b.ne     #0x3c18894
03c18840: 15168b52 mov      w21, #0x58b0
03c18844: 7500a072 movk     w21, #3, lsl #16
03c18848: 34000014 b        #0x3c18918
03c1884c: 15229f52 mov      w21, #0xf910
03c18850: df120071 cmp      w22, #4
03c18854: d500a072 movk     w21, #6, lsl #16
03c18858: c0020054 b.eq     #0x3c188b0
03c1885c: df0a0071 cmp      w22, #2
03c18860: c0050054 b.eq     #0x3c18918
03c18864: df060071 cmp      w22, #1
03c18868: 61010054 b.ne     #0x3c18894
03c1886c: e003132a mov      w0, w19
03c18870: e1031faa mov      x1, xzr
03c18874: 32b0dd97 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
03c18878: 08449e52 mov      w8, #0xf220
03c1887c: 09549752 mov      w9, #0xbaa0
03c18880: 1f000072 tst      w0, #1
03c18884: a801a072 movk     w8, #0xd, lsl #16
03c18888: a908a072 movk     w9, #0x45, lsl #16
03c1888c: 2011881a csel     w0, w9, w8, ne
03c18890: 23000014 b        #0x3c1891c
03c18894: e00314aa mov      x0, x20
03c18898: e103132a mov      w1, w19
03c1889c: f37b42a9 ldp      x19, x30, [sp, #0x20]
03c188a0: f55341a9 ldp      x21, x20, [sp, #0x10]
03c188a4: e2031faa mov      x2, xzr
03c188a8: f60743f8 ldr      x22, [sp], #0x30
03c188ac: f9e4dd17 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
03c188b0: 14ad00b0 adrp     x20, #0x51b9000
03c188b4: 947245f9 ldr      x20, [x20, #0xae0]
03c188b8: 800240f9 ldr      x0, [x20]
03c188bc: 08e040b9 ldr      w8, [x0, #0xe0]
03c188c0: 48000035 cbnz     w8, #0x3c188c8
03c188c4: d0624e97 bl       #0xfb1404
03c188c8: f6ca00f0 adrp     x22, #0x5577000
03c188cc: c84e7d39 ldrb     w8, [x22, #0xf53]
03c188d0: c8000035 cbnz     w8, #0x3c188e8
03c188d4: 00ad00b0 adrp     x0, #0x51b9000
03c188d8: 007045f9 ldr      x0, [x0, #0xae0]
03c188dc: 89624e97 bl       #0xfb1300
03c188e0: 28008052 mov      w8, #1
03c188e4: c84e3d39 strb     w8, [x22, #0xf53]
03c188e8: 800240f9 ldr      x0, [x20]
03c188ec: 08e040b9 ldr      w8, [x0, #0xe0]
03c188f0: 68000035 cbnz     w8, #0x3c188fc
03c188f4: c4624e97 bl       #0xfb1404
03c188f8: 800240f9 ldr      x0, [x20]
03c188fc: 085c40f9 ldr      x8, [x0, #0xb8]
03c18900: 08514039 ldrb     w8, [x8, #0x14]
03c18904: 48010034 cbz      w8, #0x3c1892c
03c18908: 35d18852 mov      w21, #0x4689
03c1890c: 02000014 b        #0x3c18914
03c18910: 15229f52 mov      w21, #0xf910
03c18914: d500a072 movk     w21, #6, lsl #16
03c18918: e003152a mov      w0, w21
03c1891c: f37b42a9 ldp      x19, x30, [sp, #0x20]
03c18920: f55341a9 ldp      x21, x20, [sp, #0x10]
03c18924: f60743f8 ldr      x22, [sp], #0x30
03c18928: c0035fd6 ret      
03c1892c: 68021f32 orr      w8, w19, #2
03c18930: 1f1d0071 cmp      w8, #7
03c18934: 20ffff54 b.eq     #0x3c18918
03c18938: 15819252 mov      w21, #0x9408
03c1893c: b500a072 movk     w21, #5, lsl #16
03c18940: f6ffff17 b        #0x3c18918
