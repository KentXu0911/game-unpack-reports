# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$IsPropRocketCombo
# Linear span to next metadata entry; not a complete CFG.
0339b744: fe0f1ff8 str      x30, [sp, #-0x10]!
0339b748: 006440f9 ldr      x0, [x0, #0xc8]
0339b74c: 200100b4 cbz      x0, #0x339b770
0339b750: 080040f9 ldr      x8, [x0]
0339b754: 09bd41f9 ldr      x9, [x8, #0x378]
0339b758: 01c141f9 ldr      x1, [x8, #0x380]
0339b75c: 20013fd6 blr      x9
0339b760: 1f080071 cmp      w0, #2
0339b764: e0179f1a cset     w0, eq
0339b768: fe0741f8 ldr      x30, [sp], #0x10
0339b76c: c0035fd6 ret      
0339b770: 2e577097 bl       #0xfb1428
