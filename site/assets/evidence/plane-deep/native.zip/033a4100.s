# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy$$GetGameOperationType
# Linear span to next metadata entry; not a complete CFG.
033a4100: 084840b9 ldr      w8, [x0, #0x48]
033a4104: 1f010071 cmp      w8, #0
033a4108: 48018052 mov      w8, #0xa
033a410c: 0005881a cinc     w0, w8, ne
033a4110: c0035fd6 ret      
