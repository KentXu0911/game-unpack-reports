# Royal.Scenes.Game.Mechanics.Items.DrillItem.DrillItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
02dc5a0c: e0031f2a mov      w0, wzr
02dc5a10: c0035fd6 ret      
