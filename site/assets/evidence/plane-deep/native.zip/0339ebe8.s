# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.FireworkRocketPilot.FireworkRocketPilot$$GetMinFlyTime
# Linear span to next metadata entry; not a complete CFG.
0339ebe8: 00102a1e fmov     s0, #0.25000000
0339ebec: c0035fd6 ret      
