# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$FreezeColumn
# Linear span to next metadata entry; not a complete CFG.
026a34cc: ff0301d1 sub      sp, sp, #0x40
026a34d0: f75b01a9 stp      x23, x22, [sp, #0x10]
026a34d4: f55302a9 stp      x21, x20, [sp, #0x20]
026a34d8: f37b03a9 stp      x19, x30, [sp, #0x30]
026a34dc: f47601b0 adrp     x20, #0x5580000
026a34e0: 88124139 ldrb     w8, [x20, #0x44]
026a34e4: f30300aa mov      x19, x0
026a34e8: 28010037 tbnz     w8, #0, #0x26a350c
026a34ec: a05801b0 adrp     x0, #0x51b8000
026a34f0: 002840f9 ldr      x0, [x0, #0x50]
026a34f4: 8337a497 bl       #0xfb1300
026a34f8: 405c0190 adrp     x0, #0x522b000
026a34fc: 005c42f9 ldr      x0, [x0, #0x4b8]
026a3500: 8037a497 bl       #0xfb1300
026a3504: 28008052 mov      w8, #1
026a3508: 88120139 strb     w8, [x20, #0x44]
026a350c: 681641b9 ldr      w8, [x19, #0x114]
026a3510: 1f290071 cmp      w8, #0xa
026a3514: e10e0054 b.ne     #0x26a36f0
026a3518: e00313aa mov      x0, x19
026a351c: f7fdff97 bl       #0x26a2cf8 ; Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$UnFreezeCells
026a3520: 74a640f9 ldr      x20, [x19, #0x148]
026a3524: 740e00b4 cbz      x20, #0x26a36f0
026a3528: b55801b0 adrp     x21, #0x51b8000
026a352c: 880240f9 ldr      x8, [x20]
026a3530: b52a40f9 ldr      x21, [x21, #0x50]
026a3534: 09554279 ldrh     w9, [x8, #0x12a]
026a3538: a10240f9 ldr      x1, [x21]
026a353c: 290100b4 cbz      x9, #0x26a3560
026a3540: 0a5940f9 ldr      x10, [x8, #0xb0]
026a3544: 4a210091 add      x10, x10, #8
026a3548: 4b815ff8 ldur     x11, [x10, #-8]
026a354c: 7f0101eb cmp      x11, x1
026a3550: 00010054 b.eq     #0x26a3570
026a3554: 290500f1 subs     x9, x9, #1
026a3558: 4a410091 add      x10, x10, #0x10
026a355c: 61ffff54 b.ne     #0x26a3548
026a3560: 62008052 mov      w2, #3
026a3564: e00314aa mov      x0, x20
026a3568: 5b77a397 bl       #0xf812d4
026a356c: 05000014 b        #0x26a3580
026a3570: 490140b9 ldr      w9, [x10]
026a3574: 290d0011 add      w9, w9, #3
026a3578: 08d1298b add      x8, x8, w9, sxtw #4
026a357c: 00e10491 add      x0, x8, #0x138
026a3580: 080440a9 ldp      x8, x1, [x0]
026a3584: e00314aa mov      x0, x20
026a3588: 00013fd6 blr      x8
026a358c: 200b00b4 cbz      x0, #0x26a36f0
026a3590: 74a640f9 ldr      x20, [x19, #0x148]
026a3594: d40a00b4 cbz      x20, #0x26a36ec
026a3598: 880240f9 ldr      x8, [x20]
026a359c: a10240f9 ldr      x1, [x21]
026a35a0: 09554279 ldrh     w9, [x8, #0x12a]
026a35a4: 290100b4 cbz      x9, #0x26a35c8
026a35a8: 0a5940f9 ldr      x10, [x8, #0xb0]
026a35ac: 4a210091 add      x10, x10, #8
026a35b0: 4b815ff8 ldur     x11, [x10, #-8]
026a35b4: 7f0101eb cmp      x11, x1
026a35b8: 00010054 b.eq     #0x26a35d8
026a35bc: 290500f1 subs     x9, x9, #1
026a35c0: 4a410091 add      x10, x10, #0x10
026a35c4: 61ffff54 b.ne     #0x26a35b0
026a35c8: 62008052 mov      w2, #3
026a35cc: e00314aa mov      x0, x20
026a35d0: 4177a397 bl       #0xf812d4
026a35d4: 05000014 b        #0x26a35e8
026a35d8: 490140b9 ldr      w9, [x10]
026a35dc: 290d0011 add      w9, w9, #3
026a35e0: 08d1298b add      x8, x8, w9, sxtw #4
026a35e4: 00e10491 add      x0, x8, #0x138
026a35e8: 080440a9 ldp      x8, x1, [x0]
026a35ec: e00314aa mov      x0, x20
026a35f0: 00013fd6 blr      x8
026a35f4: c00700b4 cbz      x0, #0x26a36ec
026a35f8: 682a40f9 ldr      x8, [x19, #0x50]
026a35fc: 880700b4 cbz      x8, #0x26a36ec
026a3600: 141840b9 ldr      w20, [x0, #0x18]
026a3604: e00308aa mov      x0, x8
026a3608: e1031faa mov      x1, xzr
026a360c: 7ece0294 bl       #0x2757004 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_BoardStartY
026a3610: 682a40f9 ldr      x8, [x19, #0x50]
026a3614: c80600b4 cbz      x8, #0x26a36ec
026a3618: 575c0190 adrp     x23, #0x522b000
026a361c: f75e42f9 ldr      x23, [x23, #0x4b8]
026a3620: f503002a mov      w21, w0
026a3624: e00308aa mov      x0, x8
026a3628: e1031faa mov      x1, xzr
026a362c: 87ce0294 bl       #0x2757048 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_BoardEndY
026a3630: bf02006b cmp      w21, w0
026a3634: ec050054 b.gt     #0x26a36f0
026a3638: 762a40f9 ldr      x22, [x19, #0x50]
026a363c: e0230091 add      x0, sp, #8
026a3640: e103142a mov      w1, w20
026a3644: e203152a mov      w2, w21
026a3648: e3031faa mov      x3, xzr
026a364c: ff0700f9 str      xzr, [sp, #8]
026a3650: 89921094 bl       #0x2ac8074 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellPoint$$.ctor
026a3654: d60400b4 cbz      x22, #0x26a36ec
026a3658: e10740f9 ldr      x1, [sp, #8]
026a365c: e00316aa mov      x0, x22
026a3660: e2031faa mov      x2, xzr
026a3664: abc30294 bl       #0x2754510 ; Royal.Scenes.Game.Levels.Units.CellGridManager$$get_Item
026a3668: 200400b4 cbz      x0, #0x26a36ec
026a366c: e1031faa mov      x1, xzr
026a3670: f60300aa mov      x22, x0
026a3674: b3ab1094 bl       #0x2ace540 ; Royal.Scenes.Game.Mechanics.Board.Cell.CellModel$$CrossFallFreeze
026a3678: 608240f9 ldr      x0, [x19, #0x100]
026a367c: 800300b4 cbz      x0, #0x26a36ec
026a3680: 0a1c40b9 ldr      w10, [x0, #0x1c]
026a3684: 080840f9 ldr      x8, [x0, #0x10]
026a3688: e90240f9 ldr      x9, [x23]
026a368c: 4a050011 add      w10, w10, #1
026a3690: 0a1c00b9 str      w10, [x0, #0x1c]
026a3694: c80200b4 cbz      x8, #0x26a36ec
026a3698: 0a1880b9 ldrsw    x10, [x0, #0x18]
026a369c: 0b1940b9 ldr      w11, [x8, #0x18]
026a36a0: 5f010b6b cmp      w10, w11
026a36a4: 22010054 b.hs     #0x26a36c8
026a36a8: 49050011 add      w9, w10, #1
026a36ac: 080d0a8b add      x8, x8, x10, lsl #3
026a36b0: 091800b9 str      w9, [x0, #0x18]
026a36b4: 160d02f8 str      x22, [x8, #0x20]!
026a36b8: e00308aa mov      x0, x8
026a36bc: e10316aa mov      x1, x22
026a36c0: fb36a497 bl       #0xfb12ac
026a36c4: 07000014 b        #0x26a36e0
026a36c8: 281140f9 ldr      x8, [x9, #0x20]
026a36cc: e10316aa mov      x1, x22
026a36d0: 086140f9 ldr      x8, [x8, #0xc0]
026a36d4: 022d40f9 ldr      x2, [x8, #0x58]
026a36d8: 480440f9 ldr      x8, [x2, #8]
026a36dc: 00013fd6 blr      x8
026a36e0: 682a40f9 ldr      x8, [x19, #0x50]
026a36e4: b5060011 add      w21, w21, #1
026a36e8: e8f9ffb5 cbnz     x8, #0x26a3624
026a36ec: 4f37a497 bl       #0xfb1428
026a36f0: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a36f4: f55342a9 ldp      x21, x20, [sp, #0x20]
026a36f8: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a36fc: ff030191 add      sp, sp, #0x40
026a3700: c0035fd6 ret      
