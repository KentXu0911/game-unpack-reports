# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerRocketStrategy.<ExplodeWithDelay>d__4$$System.Collections.Generic.IEnumerator<System.Object>.get_Current
# Linear span to next metadata entry; not a complete CFG.
033a42e8: 000c40f9 ldr      x0, [x0, #0x18]
033a42ec: c0035fd6 ret      
