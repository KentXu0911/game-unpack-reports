# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerPropellerComboPilot$$TargetChanged
# Linear span to next metadata entry; not a complete CFG.
0339afc8: 087840b9 ldr      w8, [x0, #0x78]
0339afcc: 1f050071 cmp      w8, #1
0339afd0: 41000054 b.ne     #0x339afd8
0339afd4: c0035fd6 ret      
0339afd8: 30f7ff17 b        #0x3398c98 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.DefaultPropellerPilot$$TargetChanged
