# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$ResetAlpha
# Linear span to next metadata entry; not a complete CFG.
03398210: c0035fd6 ret      
