# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemView$$get_TakeOffAudioClipType
# Linear span to next metadata entry; not a complete CFG.
03398204: e0248052 mov      w0, #0x127
03398208: c0035fd6 ret      
