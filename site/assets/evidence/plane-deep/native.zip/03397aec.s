# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerItemAssets$$GetExplodePrefabs
# Linear span to next metadata entry; not a complete CFG.
03397aec: f40f1ef8 str      x20, [sp, #-0x20]!
03397af0: f37b01a9 stp      x19, x30, [sp, #0x10]
03397af4: 740f01f0 adrp     x20, #0x5586000
03397af8: 883a6639 ldrb     w8, [x20, #0x98e]
03397afc: f30300aa mov      x19, x0
03397b00: c8000037 tbnz     w8, #0, #0x3397b18
03397b04: 80f100d0 adrp     x0, #0x51c9000
03397b08: 006043f9 ldr      x0, [x0, #0x6c0]
03397b0c: fd657097 bl       #0xfb1300
03397b10: 28008052 mov      w8, #1
03397b14: 883a2639 strb     w8, [x20, #0x98e]
03397b18: 680e40f9 ldr      x8, [x19, #0x18]
03397b1c: e80200b4 cbz      x8, #0x3397b78
03397b20: 091940b9 ldr      w9, [x8, #0x18]
03397b24: 3f050071 cmp      w9, #1
03397b28: a9020054 b.ls     #0x3397b7c
03397b2c: 001540f9 ldr      x0, [x8, #0x28]
03397b30: c00100b4 cbz      x0, #0x3397b68
03397b34: 89f100d0 adrp     x9, #0x51c9000
03397b38: 296143f9 ldr      x9, [x9, #0x6c0]
03397b3c: 080040f9 ldr      x8, [x0]
03397b40: 210140f9 ldr      x1, [x9]
03397b44: 0ab14439 ldrb     w10, [x8, #0x12c]
03397b48: 29b04439 ldrb     w9, [x1, #0x12c]
03397b4c: 5f01096b cmp      w10, w9
03397b50: 23010054 b.lo     #0x3397b74
03397b54: 086540f9 ldr      x8, [x8, #0xc8]
03397b58: 080d098b add      x8, x8, x9, lsl #3
03397b5c: 08815ff8 ldur     x8, [x8, #-8]
03397b60: 1f0101eb cmp      x8, x1
03397b64: 81000054 b.ne     #0x3397b74
03397b68: f37b41a9 ldp      x19, x30, [sp, #0x10]
03397b6c: f40742f8 ldr      x20, [sp], #0x20
03397b70: c0035fd6 ret      
03397b74: 13677097 bl       #0xfb17c0
03397b78: 2c667097 bl       #0xfb1428
03397b7c: 2d667097 bl       #0xfb1430
