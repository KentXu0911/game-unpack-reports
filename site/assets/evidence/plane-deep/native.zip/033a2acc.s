# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$.ctor
# Linear span to next metadata entry; not a complete CFG.
033a2acc: f75bbda9 stp      x23, x22, [sp, #-0x30]!
033a2ad0: f55301a9 stp      x21, x20, [sp, #0x10]
033a2ad4: f37b02a9 stp      x19, x30, [sp, #0x20]
033a2ad8: 350f0190 adrp     x21, #0x5586000
033a2adc: 96f000b0 adrp     x22, #0x51b3000
033a2ae0: a8226739 ldrb     w8, [x21, #0x9c8]
033a2ae4: d6a241f9 ldr      x22, [x22, #0x340]
033a2ae8: f30300aa mov      x19, x0
033a2aec: 34000012 and      w20, w1, #1
033a2af0: 88010037 tbnz     w8, #0, #0x33a2b20
033a2af4: 00f100d0 adrp     x0, #0x51c4000
033a2af8: 001042f9 ldr      x0, [x0, #0x420]
033a2afc: 013a7097 bl       #0xfb1300
033a2b00: e0f300b0 adrp     x0, #0x521f000
033a2b04: 00b446f9 ldr      x0, [x0, #0xd68]
033a2b08: fe397097 bl       #0xfb1300
033a2b0c: 80f000b0 adrp     x0, #0x51b3000
033a2b10: 00a041f9 ldr      x0, [x0, #0x340]
033a2b14: fb397097 bl       #0xfb1300
033a2b18: 28008052 mov      w8, #1
033a2b1c: a8222739 strb     w8, [x21, #0x9c8]
033a2b20: 17f100d0 adrp     x23, #0x51c4000
033a2b24: f5f300b0 adrp     x21, #0x521f000
033a2b28: f71242f9 ldr      x23, [x23, #0x420]
033a2b2c: b5b646f9 ldr      x21, [x21, #0xd68]
033a2b30: e00313aa mov      x0, x19
033a2b34: e1031faa mov      x1, xzr
033a2b38: af42bb97 bl       #0x22735f4 ; System.Object$$.ctor
033a2b3c: c00240f9 ldr      x0, [x22]
033a2b40: 08e040b9 ldr      w8, [x0, #0xe0]
033a2b44: 48000035 cbnz     w8, #0x33a2b4c
033a2b48: 2f3a7097 bl       #0xfb1404
033a2b4c: e10240f9 ldr      x1, [x23]
033a2b50: 40008052 mov      w0, #2
033a2b54: 04ced297 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
033a2b58: e10300aa mov      x1, x0
033a2b5c: e00313aa mov      x0, x19
033a2b60: 010c01f8 str      x1, [x0, #0x10]!
033a2b64: d2397097 bl       #0xfb12ac
033a2b68: a10240f9 ldr      x1, [x21]
033a2b6c: a0038052 mov      w0, #0x1d
033a2b70: fdcdd297 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
033a2b74: 608e01f8 str      x0, [x19, #0x18]!
033a2b78: e10300aa mov      x1, x0
033a2b7c: e00313aa mov      x0, x19
033a2b80: cb397097 bl       #0xfb12ac
033a2b84: 74220039 strb     w20, [x19, #8]
033a2b88: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a2b8c: f55341a9 ldp      x21, x20, [sp, #0x10]
033a2b90: f75bc3a8 ldp      x23, x22, [sp], #0x30
033a2b94: c0035fd6 ret      
