# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$CalculateAngleSmoothCoefficient
# Linear span to next metadata entry; not a complete CFG.
033a2300: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a2304: f30300aa mov      x19, x0
033a2308: e0031faa mov      x0, xzr
033a230c: 47c2ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a2310: 612640bd ldr      s1, [x19, #0x24]
033a2314: 02102e1e fmov     s2, #1.00000000
033a2318: 0038211e fsub     s0, s0, s1
033a231c: 0028201e fadd     s0, s0, s0
033a2320: 0158221e fmin     s1, s0, s2
033a2324: 4138211e fsub     s1, s2, s1
033a2328: 0820201e fcmp     s0, #0.0
033a232c: 205c221e fcsel    s0, s1, s2, pl
033a2330: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a2334: c0035fd6 ret      
