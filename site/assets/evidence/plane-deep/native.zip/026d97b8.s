# Royal.Scenes.Game.Mechanics.Items.GummyItem.GummyBarVerticalItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
026d97b8: f40f1ef8 str      x20, [sp, #-0x20]!
026d97bc: f37b01a9 stp      x19, x30, [sp, #0x10]
026d97c0: f403012a mov      w20, w1
026d97c4: f30300aa mov      x19, x0
026d97c8: e003012a mov      w0, w1
026d97cc: e1031faa mov      x1, xzr
026d97d0: 5bac3294 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026d97d4: 20040036 tbz      w0, #0, #0x26d9858
026d97d8: 680240f9 ldr      x8, [x19]
026d97dc: e00313aa mov      x0, x19
026d97e0: 096542f9 ldr      x9, [x8, #0x4c8]
026d97e4: 016942f9 ldr      x1, [x8, #0x4d0]
026d97e8: 20013fd6 blr      x9
026d97ec: 1f040071 cmp      w0, #1
026d97f0: 41030054 b.ne     #0x26d9858
026d97f4: 680240f9 ldr      x8, [x19]
026d97f8: e00313aa mov      x0, x19
026d97fc: 09bd41f9 ldr      x9, [x8, #0x378]
026d9800: 01c141f9 ldr      x1, [x8, #0x380]
026d9804: 20013fd6 blr      x9
026d9808: e1031faa mov      x1, xzr
026d980c: 5fac3294 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
026d9810: 680240f9 ldr      x8, [x19]
026d9814: f403002a mov      w20, w0
026d9818: e00313aa mov      x0, x19
026d981c: 09bd41f9 ldr      x9, [x8, #0x378]
026d9820: 01c141f9 ldr      x1, [x8, #0x380]
026d9824: 20013fd6 blr      x9
026d9828: e1031faa mov      x1, xzr
026d982c: 57ac3294 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
026d9830: c8aa8a52 mov      w8, #0x5556
026d9834: a8aaaa72 movk     w8, #0x5555, lsl #16
026d9838: 087c289b smull    x8, w0, w8
026d983c: f37b41a9 ldp      x19, x30, [sp, #0x10]
026d9840: 09fd7fd3 lsr      x9, x8, #0x3f
026d9844: 08fd60d3 lsr      x8, x8, #0x20
026d9848: 0801090b add      w8, w8, w9
026d984c: 0001140b add      w0, w8, w20
026d9850: f40742f8 ldr      x20, [sp], #0x20
026d9854: c0035fd6 ret      
026d9858: e00313aa mov      x0, x19
026d985c: f37b41a9 ldp      x19, x30, [sp, #0x10]
026d9860: e103142a mov      w1, w20
026d9864: e2031faa mov      x2, xzr
026d9868: f40742f8 ldr      x20, [sp], #0x20
026d986c: 09e13214 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
