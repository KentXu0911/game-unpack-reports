# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_MaxGoSpeedConst
# Linear span to next metadata entry; not a complete CFG.
0339b598: 8846a852 mov      w8, #0x42340000
0339b59c: 0001271e fmov     s0, w8
0339b5a0: c0035fd6 ret      
