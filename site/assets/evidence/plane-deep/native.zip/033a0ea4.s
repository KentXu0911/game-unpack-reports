# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$TargetReached
# Linear span to next metadata entry; not a complete CFG.
033a0ea4: e80f1dfc str      d8, [sp, #-0x30]!
033a0ea8: f55301a9 stp      x21, x20, [sp, #0x10]
033a0eac: f37b02a9 stp      x19, x30, [sp, #0x20]
033a0eb0: 350f01d0 adrp     x21, #0x5586000
033a0eb4: a8066739 ldrb     w8, [x21, #0x9c1]
033a0eb8: f403012a mov      w20, w1
033a0ebc: f30300aa mov      x19, x0
033a0ec0: c8000037 tbnz     w8, #0, #0x33a0ed8
033a0ec4: 60f400f0 adrp     x0, #0x522f000
033a0ec8: 000445f9 ldr      x0, [x0, #0xa08]
033a0ecc: 0d417097 bl       #0xfb1300
033a0ed0: 28008052 mov      w8, #1
033a0ed4: a8062739 strb     w8, [x21, #0x9c1]
033a0ed8: 8851a852 mov      w8, #0x428c0000
033a0edc: 01d0271e fmov     s1, #30.00000000
033a0ee0: 0001271e fmov     s0, w8
033a0ee4: e0031faa mov      x0, xzr
033a0ee8: 7f020239 strb     wzr, [x19, #0x80]
033a0eec: 37b10594 bl       #0x350d3c8 ; UnityEngine.Random$$Range
033a0ef0: d50e0190 adrp     x21, #0x5578000
033a0ef4: a86e4539 ldrb     w8, [x21, #0x15b]
033a0ef8: 081ca04e mov      v8.16b, v0.16b
033a0efc: c8000035 cbnz     w8, #0x33a0f14
033a0f00: 40f400f0 adrp     x0, #0x522b000
033a0f04: 00ac43f9 ldr      x0, [x0, #0x758]
033a0f08: fe407097 bl       #0xfb1300
033a0f0c: 28008052 mov      w8, #1
033a0f10: a86e0539 strb     w8, [x21, #0x15b]
033a0f14: 48f400f0 adrp     x8, #0x522b000
033a0f18: 08ad43f9 ldr      x8, [x8, #0x758]
033a0f1c: 001da84e mov      v0.16b, v8.16b
033a0f20: e0031faa mov      x0, xzr
033a0f24: 080140f9 ldr      x8, [x8]
033a0f28: 085d40f9 ldr      x8, [x8, #0xb8]
033a0f2c: 0109492d ldp      s1, s2, [x8, #0x48]
033a0f30: 035140bd ldr      s3, [x8, #0x50]
033a0f34: 8f920594 bl       #0x3505970 ; UnityEngine.Quaternion$$AngleAxis
033a0f38: 6416482d ldp      s4, s5, [x19, #0x40]
033a0f3c: 664a40bd ldr      s6, [x19, #0x48]
033a0f40: e0031faa mov      x0, xzr
033a0f44: 1d900594 bl       #0x3504fb8 ; UnityEngine.Quaternion$$op_Multiply
033a0f48: 602a40f9 ldr      x0, [x19, #0x50]
033a0f4c: 6006082d stp      s0, s1, [x19, #0x40]
033a0f50: 624a00bd str      s2, [x19, #0x48]
033a0f54: c00800b4 cbz      x0, #0x33a106c
033a0f58: e1031faa mov      x1, xzr
033a0f5c: 74000036 tbz      w20, #0, #0x33a0f68
033a0f60: 37a30b94 bl       #0x3689c3c ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$TriggerFakeTargetReached
033a0f64: 02000014 b        #0x33a0f6c
033a0f68: 10a30b94 bl       #0x3689ba8 ; Royal.Scenes.Game.Mechanics.Items.SpecialItems.GuidedExploderItemView$$TriggerTargetReached
033a0f6c: 743240f9 ldr      x20, [x19, #0x60]
033a0f70: f40700b4 cbz      x20, #0x33a106c
033a0f74: 6af400f0 adrp     x10, #0x522f000
033a0f78: 880240f9 ldr      x8, [x20]
033a0f7c: 4a0545f9 ldr      x10, [x10, #0xa08]
033a0f80: 09554279 ldrh     w9, [x8, #0x12a]
033a0f84: 410140f9 ldr      x1, [x10]
033a0f88: 290100b4 cbz      x9, #0x33a0fac
033a0f8c: 0a5940f9 ldr      x10, [x8, #0xb0]
033a0f90: 4a210091 add      x10, x10, #8
033a0f94: 4b815ff8 ldur     x11, [x10, #-8]
033a0f98: 7f0101eb cmp      x11, x1
033a0f9c: 00010054 b.eq     #0x33a0fbc
033a0fa0: 290500f1 subs     x9, x9, #1
033a0fa4: 4a410091 add      x10, x10, #0x10
033a0fa8: 61ffff54 b.ne     #0x33a0f94
033a0fac: a2008052 mov      w2, #5
033a0fb0: e00314aa mov      x0, x20
033a0fb4: c8806f97 bl       #0xf812d4
033a0fb8: 05000014 b        #0x33a0fcc
033a0fbc: 490140b9 ldr      w9, [x10]
033a0fc0: 29150011 add      w9, w9, #5
033a0fc4: 08d1298b add      x8, x8, w9, sxtw #4
033a0fc8: 00e10491 add      x0, x8, #0x138
033a0fcc: 080440a9 ldp      x8, x1, [x0]
033a0fd0: e00314aa mov      x0, x20
033a0fd4: 00013fd6 blr      x8
033a0fd8: 20030036 tbz      w0, #0, #0x33a103c
033a0fdc: 602e40f9 ldr      x0, [x19, #0x58]
033a0fe0: 7f6a00b9 str      wzr, [x19, #0x68]
033a0fe4: 400400b4 cbz      x0, #0x33a106c
033a0fe8: 742a40f9 ldr      x20, [x19, #0x50]
033a0fec: e1031faa mov      x1, xzr
033a0ff0: 41a32594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a0ff4: d40300b4 cbz      x20, #0x33a106c
033a0ff8: e00314aa mov      x0, x20
033a0ffc: e1031faa mov      x1, xzr
033a1000: a2bcbf97 bl       #0x2390288 ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$PlayBoomerangHitParticles
033a1004: 602a40f9 ldr      x0, [x19, #0x50]
033a1008: 200300b4 cbz      x0, #0x33a106c
033a100c: e1031faa mov      x1, xzr
033a1010: c3bcbf97 bl       #0x239031c ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$PlayBoomerangExplodeParticles
033a1014: 602a40f9 ldr      x0, [x19, #0x50]
033a1018: a00200b4 cbz      x0, #0x33a106c
033a101c: 080040f9 ldr      x8, [x0]
033a1020: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a1024: f55341a9 ldp      x21, x20, [sp, #0x10]
033a1028: e1031f2a mov      w1, wzr
033a102c: 033542f9 ldr      x3, [x8, #0x468]
033a1030: 023942f9 ldr      x2, [x8, #0x470]
033a1034: e80743fc ldr      d8, [sp], #0x30
033a1038: 60001fd6 br       x3
033a103c: 602e40f9 ldr      x0, [x19, #0x58]
033a1040: 600100b4 cbz      x0, #0x33a106c
033a1044: 732a40f9 ldr      x19, [x19, #0x50]
033a1048: e1031faa mov      x1, xzr
033a104c: 2aa32594 bl       #0x3d09cf4 ; UnityEngine.Transform$$get_position
033a1050: f30000b4 cbz      x19, #0x33a106c
033a1054: e00313aa mov      x0, x19
033a1058: f37b42a9 ldp      x19, x30, [sp, #0x20]
033a105c: f55341a9 ldp      x21, x20, [sp, #0x10]
033a1060: e1031faa mov      x1, xzr
033a1064: e80743fc ldr      d8, [sp], #0x30
033a1068: 88bcbf17 b        #0x2390288 ; Royal.Scenes.Game.Mechanics.Items.BoomerangBoxItem.View.BoomerangItemView$$PlayBoomerangHitParticles
033a106c: ef407097 bl       #0xfb1428
