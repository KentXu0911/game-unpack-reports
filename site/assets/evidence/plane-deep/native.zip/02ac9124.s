# Royal.Scenes.Game.Mechanics.Board.Cell.ExplodeTargetMediator$$.ctor
# Linear span to next metadata entry; not a complete CFG.
02ac9124: f60f1df8 str      x22, [sp, #-0x30]!
02ac9128: f55301a9 stp      x21, x20, [sp, #0x10]
02ac912c: f37b02a9 stp      x19, x30, [sp, #0x20]
02ac9130: d65501b0 adrp     x22, #0x5582000
02ac9134: 553701d0 adrp     x21, #0x51b3000
02ac9138: c8b64639 ldrb     w8, [x22, #0x1ad]
02ac913c: b5a241f9 ldr      x21, [x21, #0x340]
02ac9140: f40301aa mov      x20, x1
02ac9144: f30300aa mov      x19, x0
02ac9148: 28010037 tbnz     w8, #0, #0x2ac916c
02ac914c: c03701f0 adrp     x0, #0x51c4000
02ac9150: 001042f9 ldr      x0, [x0, #0x420]
02ac9154: 6ba09397 bl       #0xfb1300
02ac9158: 403701d0 adrp     x0, #0x51b3000
02ac915c: 00a041f9 ldr      x0, [x0, #0x340]
02ac9160: 68a09397 bl       #0xfb1300
02ac9164: 28008052 mov      w8, #1
02ac9168: c8b60639 strb     w8, [x22, #0x1ad]
02ac916c: d63701f0 adrp     x22, #0x51c4000
02ac9170: d61242f9 ldr      x22, [x22, #0x420]
02ac9174: e00313aa mov      x0, x19
02ac9178: e1031faa mov      x1, xzr
02ac917c: 1ea9de97 bl       #0x22735f4 ; System.Object$$.ctor
02ac9180: e00313aa mov      x0, x19
02ac9184: 140c02f8 str      x20, [x0, #0x20]!
02ac9188: e10314aa mov      x1, x20
02ac918c: 1f001ff8 stur     xzr, [x0, #-0x10]
02ac9190: 47a09397 bl       #0xfb12ac
02ac9194: a00240f9 ldr      x0, [x21]
02ac9198: 08e040b9 ldr      w8, [x0, #0xe0]
02ac919c: 48000035 cbnz     w8, #0x2ac91a4
02ac91a0: 99a09397 bl       #0xfb1404
02ac91a4: c10240f9 ldr      x1, [x22]
02ac91a8: 40008052 mov      w0, #2
02ac91ac: 6e34f697 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
02ac91b0: 608e02f8 str      x0, [x19, #0x28]!
02ac91b4: e10300aa mov      x1, x0
02ac91b8: e00313aa mov      x0, x19
02ac91bc: f37b42a9 ldp      x19, x30, [sp, #0x20]
02ac91c0: f55341a9 ldp      x21, x20, [sp, #0x10]
02ac91c4: f60743f8 ldr      x22, [sp], #0x30
02ac91c8: 39a09317 b        #0xfb12ac
