# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$UnFreezeCells
# Linear span to next metadata entry; not a complete CFG.
026a2cf8: f75bbda9 stp      x23, x22, [sp, #-0x30]!
026a2cfc: f55301a9 stp      x21, x20, [sp, #0x10]
026a2d00: f37b02a9 stp      x19, x30, [sp, #0x20]
026a2d04: f47601d0 adrp     x20, #0x5580000
026a2d08: 88164139 ldrb     w8, [x20, #0x45]
026a2d0c: f30300aa mov      x19, x0
026a2d10: 48020037 tbnz     w8, #0, #0x26a2d58
026a2d14: 805901f0 adrp     x0, #0x51d5000
026a2d18: 005041f9 ldr      x0, [x0, #0x2a0]
026a2d1c: 7939a497 bl       #0xfb1300
026a2d20: 805c0190 adrp     x0, #0x5232000
026a2d24: 001843f9 ldr      x0, [x0, #0x630]
026a2d28: 7639a497 bl       #0xfb1300
026a2d2c: a05901f0 adrp     x0, #0x51d9000
026a2d30: 00b443f9 ldr      x0, [x0, #0x768]
026a2d34: 7339a497 bl       #0xfb1300
026a2d38: 005a01f0 adrp     x0, #0x51e5000
026a2d3c: 009442f9 ldr      x0, [x0, #0x528]
026a2d40: 7039a497 bl       #0xfb1300
026a2d44: a0590190 adrp     x0, #0x51d6000
026a2d48: 00fc41f9 ldr      x0, [x0, #0x3f8]
026a2d4c: 6d39a497 bl       #0xfb1300
026a2d50: 28008052 mov      w8, #1
026a2d54: 88160139 strb     w8, [x20, #0x45]
026a2d58: 681641b9 ldr      w8, [x19, #0x114]
026a2d5c: 1f290071 cmp      w8, #0xa
026a2d60: 01070054 b.ne     #0x26a2e40
026a2d64: b7590190 adrp     x23, #0x51d6000
026a2d68: f7fe41f9 ldr      x23, [x23, #0x3f8]
026a2d6c: 748240f9 ldr      x20, [x19, #0x100]
026a2d70: e00240f9 ldr      x0, [x23]
026a2d74: 08e040b9 ldr      w8, [x0, #0xe0]
026a2d78: 68000035 cbnz     w8, #0x26a2d84
026a2d7c: a239a497 bl       #0xfb1404
026a2d80: e00240f9 ldr      x0, [x23]
026a2d84: 085c40f9 ldr      x8, [x0, #0xb8]
026a2d88: 150540f9 ldr      x21, [x8, #8]
026a2d8c: 150300b5 cbnz     x21, #0x26a2dec
026a2d90: 955901f0 adrp     x21, #0x51d5000
026a2d94: 08e040b9 ldr      w8, [x0, #0xe0]
026a2d98: b55241f9 ldr      x21, [x21, #0x2a0]
026a2d9c: 68000035 cbnz     w8, #0x26a2da8
026a2da0: 9939a497 bl       #0xfb1404
026a2da4: e00240f9 ldr      x0, [x23]
026a2da8: 085c40f9 ldr      x8, [x0, #0xb8]
026a2dac: a00240f9 ldr      x0, [x21]
026a2db0: 160140f9 ldr      x22, [x8]
026a2db4: 9939a497 bl       #0xfb1418
026a2db8: c00400b4 cbz      x0, #0x26a2e50
026a2dbc: 085a01f0 adrp     x8, #0x51e5000
026a2dc0: 089542f9 ldr      x8, [x8, #0x528]
026a2dc4: e10316aa mov      x1, x22
026a2dc8: e3031faa mov      x3, xzr
026a2dcc: f50300aa mov      x21, x0
026a2dd0: 020140f9 ldr      x2, [x8]
026a2dd4: 23a8b597 bl       #0x140ce60 ; System.Action<object>$$.ctor
026a2dd8: e80240f9 ldr      x8, [x23]
026a2ddc: e10315aa mov      x1, x21
026a2de0: 005d40f9 ldr      x0, [x8, #0xb8]
026a2de4: 158c00f8 str      x21, [x0, #8]!
026a2de8: 3139a497 bl       #0xfb12ac
026a2dec: 340300b4 cbz      x20, #0x26a2e50
026a2df0: a85901f0 adrp     x8, #0x51d9000
026a2df4: 08b543f9 ldr      x8, [x8, #0x768]
026a2df8: e00314aa mov      x0, x20
026a2dfc: e10315aa mov      x1, x21
026a2e00: 020140f9 ldr      x2, [x8]
026a2e04: 7bb00c94 bl       #0x29ceff0 ; System.Collections.Generic.List<object>$$ForEach
026a2e08: 688240f9 ldr      x8, [x19, #0x100]
026a2e0c: 280200b4 cbz      x8, #0x26a2e50
026a2e10: 02254329 ldp      w2, w9, [x8, #0x18]
026a2e14: 29050011 add      w9, w9, #1
026a2e18: 5f040071 cmp      w2, #1
026a2e1c: 1f250329 stp      wzr, w9, [x8, #0x18]
026a2e20: 0b010054 b.lt     #0x26a2e40
026a2e24: 000940f9 ldr      x0, [x8, #0x10]
026a2e28: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a2e2c: f55341a9 ldp      x21, x20, [sp, #0x10]
026a2e30: e1031f2a mov      w1, wzr
026a2e34: e3031faa mov      x3, xzr
026a2e38: f75bc3a8 ldp      x23, x22, [sp], #0x30
026a2e3c: 0615fb17 b        #0x2568254 ; System.Array$$Clear
026a2e40: f37b42a9 ldp      x19, x30, [sp, #0x20]
026a2e44: f55341a9 ldp      x21, x20, [sp, #0x10]
026a2e48: f75bc3a8 ldp      x23, x22, [sp], #0x30
026a2e4c: c0035fd6 ret      
026a2e50: 7639a497 bl       #0xfb1428
