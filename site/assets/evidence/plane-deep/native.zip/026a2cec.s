# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$IsTargetAmountReached
# Linear span to next metadata entry; not a complete CFG.
026a2cec: 20008052 mov      w0, #1
026a2cf0: c0035fd6 ret      
