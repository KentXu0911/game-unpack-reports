# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.PropellerPilot.PropellerSpecialComboPilot$$get_MinDistanceToScaleDown
# Linear span to next metadata entry; not a complete CFG.
0339b5a4: 00102f1e fmov     s0, #1.50000000
0339b5a8: c0035fd6 ret      
