# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.View.BoomerangPilot.BoomerangPilot$$GetDurationSmoother
# Linear span to next metadata entry; not a complete CFG.
033a22c0: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
033a22c4: f30300aa mov      x19, x0
033a22c8: e0031faa mov      x0, xzr
033a22cc: 57c2ce97 bl       #0x2752c28 ; Royal.Scenes.Game.Levels.LevelContext$$get_Time
033a22d0: 612640bd ldr      s1, [x19, #0x24]
033a22d4: 285600b0 adrp     x8, #0x3e67000
033a22d8: 027d44bd ldr      s2, [x8, #0x47c]
033a22dc: 03102e1e fmov     s3, #1.00000000
033a22e0: 0038211e fsub     s0, s0, s1
033a22e4: 0158231e fmin     s1, s0, s3
033a22e8: 2108221e fmul     s1, s1, s2
033a22ec: 4138211e fsub     s1, s2, s1
033a22f0: 0820201e fcmp     s0, #0.0
033a22f4: 205c221e fcsel    s0, s1, s2, pl
033a22f8: f37bc1a8 ldp      x19, x30, [sp], #0x10
033a22fc: c0035fd6 ret      
