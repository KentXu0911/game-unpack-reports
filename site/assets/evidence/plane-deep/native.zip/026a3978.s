# Royal.Scenes.Game.Levels.Units.Explode.GuidedExploderItemModel$$TryRegisterForTargetChange
# Linear span to next metadata entry; not a complete CFG.
026a3978: f963bca9 stp      x25, x24, [sp, #-0x40]!
026a397c: f75b01a9 stp      x23, x22, [sp, #0x10]
026a3980: f55302a9 stp      x21, x20, [sp, #0x20]
026a3984: f37b03a9 stp      x19, x30, [sp, #0x30]
026a3988: f47601b0 adrp     x20, #0x5580000
026a398c: 88024139 ldrb     w8, [x20, #0x40]
026a3990: f30300aa mov      x19, x0
026a3994: c8060037 tbnz     w8, #0, #0x26a3a6c
026a3998: c0580190 adrp     x0, #0x51bb000
026a399c: 009c46f9 ldr      x0, [x0, #0xd38]
026a39a0: 5836a497 bl       #0xfb1300
026a39a4: 405c01b0 adrp     x0, #0x522c000
026a39a8: 00e443f9 ldr      x0, [x0, #0x7c8]
026a39ac: 5536a497 bl       #0xfb1300
026a39b0: 805801f0 adrp     x0, #0x51b6000
026a39b4: 00d846f9 ldr      x0, [x0, #0xdb0]
026a39b8: 5236a497 bl       #0xfb1300
026a39bc: a0580190 adrp     x0, #0x51b7000
026a39c0: 001c44f9 ldr      x0, [x0, #0x838]
026a39c4: 4f36a497 bl       #0xfb1300
026a39c8: 405c01b0 adrp     x0, #0x522c000
026a39cc: 00c040f9 ldr      x0, [x0, #0x180]
026a39d0: 4c36a497 bl       #0xfb1300
026a39d4: 405901b0 adrp     x0, #0x51cc000
026a39d8: 00bc45f9 ldr      x0, [x0, #0xb78]
026a39dc: 4936a497 bl       #0xfb1300
026a39e0: c05a01f0 adrp     x0, #0x51fe000
026a39e4: 001c44f9 ldr      x0, [x0, #0x838]
026a39e8: 4636a497 bl       #0xfb1300
026a39ec: c05801b0 adrp     x0, #0x51bc000
026a39f0: 003c45f9 ldr      x0, [x0, #0xa78]
026a39f4: 4336a497 bl       #0xfb1300
026a39f8: 805b01d0 adrp     x0, #0x5215000
026a39fc: 004445f9 ldr      x0, [x0, #0xa88]
026a3a00: 4036a497 bl       #0xfb1300
026a3a04: 405c01d0 adrp     x0, #0x522d000
026a3a08: 001447f9 ldr      x0, [x0, #0xe28]
026a3a0c: 3d36a497 bl       #0xfb1300
026a3a10: c05c01b0 adrp     x0, #0x523c000
026a3a14: 00cc44f9 ldr      x0, [x0, #0x998]
026a3a18: 3a36a497 bl       #0xfb1300
026a3a1c: a0590190 adrp     x0, #0x51d7000
026a3a20: 007840f9 ldr      x0, [x0, #0xf0]
026a3a24: 3736a497 bl       #0xfb1300
026a3a28: 605901b0 adrp     x0, #0x51d0000
026a3a2c: 007840f9 ldr      x0, [x0, #0xf0]
026a3a30: 3436a497 bl       #0xfb1300
026a3a34: 605701b0 adrp     x0, #0x5190000
026a3a38: 007444f9 ldr      x0, [x0, #0x8e8]
026a3a3c: 3136a497 bl       #0xfb1300
026a3a40: 205c01f0 adrp     x0, #0x522a000
026a3a44: 003440f9 ldr      x0, [x0, #0x68]
026a3a48: 2e36a497 bl       #0xfb1300
026a3a4c: 60590190 adrp     x0, #0x51cf000
026a3a50: 004845f9 ldr      x0, [x0, #0xa90]
026a3a54: 2b36a497 bl       #0xfb1300
026a3a58: 405a01f0 adrp     x0, #0x51ee000
026a3a5c: 00e444f9 ldr      x0, [x0, #0x9c8]
026a3a60: 2836a497 bl       #0xfb1300
026a3a64: 28008052 mov      w8, #1
026a3a68: 88020139 strb     w8, [x20, #0x40]
026a3a6c: 602640f9 ldr      x0, [x19, #0x48]
026a3a70: 803b00b4 cbz      x0, #0x26a41e0
026a3a74: d8580190 adrp     x24, #0x51bb000
026a3a78: b7580190 adrp     x23, #0x51b7000
026a3a7c: 189f46f9 ldr      x24, [x24, #0xd38]
026a3a80: f71e44f9 ldr      x23, [x23, #0x838]
026a3a84: 81058052 mov      w1, #0x2c
026a3a88: e2031faa mov      x2, xzr
026a3a8c: 30dce697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3a90: a0020036 tbz      w0, #0, #0x26a3ae4
026a3a94: c85c01b0 adrp     x8, #0x523c000
026a3a98: 08cd44f9 ldr      x8, [x8, #0x998]
026a3a9c: 40058052 mov      w0, #0x2a
026a3aa0: 010140f9 ldr      x1, [x8]
026a3aa4: f26bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3aa8: 080340f9 ldr      x8, [x24]
026a3aac: f40300aa mov      x20, x0
026a3ab0: e00308aa mov      x0, x8
026a3ab4: 5936a497 bl       #0xfb1418
026a3ab8: 403900b4 cbz      x0, #0x26a41e0
026a3abc: e20240f9 ldr      x2, [x23]
026a3ac0: e10313aa mov      x1, x19
026a3ac4: e3031faa mov      x3, xzr
026a3ac8: f50300aa mov      x21, x0
026a3acc: 6984e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3ad0: 943800b4 cbz      x20, #0x26a41e0
026a3ad4: e00314aa mov      x0, x20
026a3ad8: e10315aa mov      x1, x21
026a3adc: e2031faa mov      x2, xzr
026a3ae0: e9d90094 bl       #0x26da284 ; Royal.Scenes.Game.Mechanics.Items.GummyItem.GummyItemHelper$$add_OnItemSpawned
026a3ae4: 602640f9 ldr      x0, [x19, #0x48]
026a3ae8: c03700b4 cbz      x0, #0x26a41e0
026a3aec: a1038052 mov      w1, #0x1d
026a3af0: e2031faa mov      x2, xzr
026a3af4: 16dce697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3af8: e0020036 tbz      w0, #0, #0x26a3b54
026a3afc: c85801b0 adrp     x8, #0x51bc000
026a3b00: 083d45f9 ldr      x8, [x8, #0xa78]
026a3b04: e0038052 mov      w0, #0x1f
026a3b08: 010140f9 ldr      x1, [x8]
026a3b0c: d86bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3b10: 080340f9 ldr      x8, [x24]
026a3b14: f40300aa mov      x20, x0
026a3b18: e00308aa mov      x0, x8
026a3b1c: 3f36a497 bl       #0xfb1418
026a3b20: 003600b4 cbz      x0, #0x26a41e0
026a3b24: 885801f0 adrp     x8, #0x51b6000
026a3b28: 08d946f9 ldr      x8, [x8, #0xdb0]
026a3b2c: e10313aa mov      x1, x19
026a3b30: e3031faa mov      x3, xzr
026a3b34: f50300aa mov      x21, x0
026a3b38: 020140f9 ldr      x2, [x8]
026a3b3c: 4d84e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3b40: 143500b4 cbz      x20, #0x26a41e0
026a3b44: e00314aa mov      x0, x20
026a3b48: e10315aa mov      x1, x21
026a3b4c: e2031faa mov      x2, xzr
026a3b50: c97d1c94 bl       #0x2dc3274 ; Royal.Scenes.Game.Mechanics.Items.DrillItem.DrillHelper$$add_OnDrillActivated
026a3b54: 602640f9 ldr      x0, [x19, #0x48]
026a3b58: 403400b4 cbz      x0, #0x26a41e0
026a3b5c: 01018052 mov      w1, #8
026a3b60: e2031faa mov      x2, xzr
026a3b64: c8dbe697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3b68: c0020036 tbz      w0, #0, #0x26a3bc0
026a3b6c: 485a01f0 adrp     x8, #0x51ee000
026a3b70: 08e544f9 ldr      x8, [x8, #0x9c8]
026a3b74: c0058052 mov      w0, #0x2e
026a3b78: 010140f9 ldr      x1, [x8]
026a3b7c: bc6bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3b80: 080340f9 ldr      x8, [x24]
026a3b84: f40300aa mov      x20, x0
026a3b88: e00308aa mov      x0, x8
026a3b8c: 2336a497 bl       #0xfb1418
026a3b90: 803200b4 cbz      x0, #0x26a41e0
026a3b94: 680240f9 ldr      x8, [x19]
026a3b98: e10313aa mov      x1, x19
026a3b9c: e3031faa mov      x3, xzr
026a3ba0: f50300aa mov      x21, x0
026a3ba4: 023145f9 ldr      x2, [x8, #0xa60]
026a3ba8: 3284e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3bac: b43100b4 cbz      x20, #0x26a41e0
026a3bb0: e00314aa mov      x0, x20
026a3bb4: e10315aa mov      x1, x21
026a3bb8: e2031faa mov      x2, xzr
026a3bbc: f0ddaf97 bl       #0x129b37c ; Royal.Scenes.Game.Mechanics.Items.StaticItems.TreasureMapItem.TreasureMapHelper$$add_OnTreasureMapReveal
026a3bc0: 602640f9 ldr      x0, [x19, #0x48]
026a3bc4: e03000b4 cbz      x0, #0x26a41e0
026a3bc8: a1068052 mov      w1, #0x35
026a3bcc: e2031faa mov      x2, xzr
026a3bd0: dfdbe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3bd4: e0020036 tbz      w0, #0, #0x26a3c30
026a3bd8: 000340f9 ldr      x0, [x24]
026a3bdc: 0f36a497 bl       #0xfb1418
026a3be0: 003000b4 cbz      x0, #0x26a41e0
026a3be4: e20240f9 ldr      x2, [x23]
026a3be8: e10313aa mov      x1, x19
026a3bec: e3031faa mov      x3, xzr
026a3bf0: f40300aa mov      x20, x0
026a3bf4: 1f84e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3bf8: e00314aa mov      x0, x20
026a3bfc: e1031faa mov      x1, xzr
026a3c00: a22f1094 bl       #0x2aafa88 ; Royal.Scenes.Game.Mechanics.Items.DuckShootingItem.DuckShootingItemRegistry$$add_OnFirstSetFinished
026a3c04: 000340f9 ldr      x0, [x24]
026a3c08: 0436a497 bl       #0xfb1418
026a3c0c: a02e00b4 cbz      x0, #0x26a41e0
026a3c10: e20240f9 ldr      x2, [x23]
026a3c14: e10313aa mov      x1, x19
026a3c18: e3031faa mov      x3, xzr
026a3c1c: f40300aa mov      x20, x0
026a3c20: 1484e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3c24: e00314aa mov      x0, x20
026a3c28: e1031faa mov      x1, xzr
026a3c2c: f32f1094 bl       #0x2aafbf8 ; Royal.Scenes.Game.Mechanics.Items.DuckShootingItem.DuckShootingItemRegistry$$add_OnSecondSetStarted
026a3c30: 602640f9 ldr      x0, [x19, #0x48]
026a3c34: 602d00b4 cbz      x0, #0x26a41e0
026a3c38: a1078052 mov      w1, #0x3d
026a3c3c: e2031faa mov      x2, xzr
026a3c40: c3dbe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3c44: 80010036 tbz      w0, #0, #0x26a3c74
026a3c48: 000340f9 ldr      x0, [x24]
026a3c4c: f335a497 bl       #0xfb1418
026a3c50: 802c00b4 cbz      x0, #0x26a41e0
026a3c54: e20240f9 ldr      x2, [x23]
026a3c58: e10313aa mov      x1, x19
026a3c5c: e3031faa mov      x3, xzr
026a3c60: f40300aa mov      x20, x0
026a3c64: 0384e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3c68: e00314aa mov      x0, x20
026a3c6c: e1031faa mov      x1, xzr
026a3c70: 351a1a94 bl       #0x2d2a544 ; Royal.Scenes.Game.Mechanics.Items.CoilItem.CoilItemHelper$$add_OnDoorOpen
026a3c74: 602640f9 ldr      x0, [x19, #0x48]
026a3c78: 402b00b4 cbz      x0, #0x26a41e0
026a3c7c: 61088052 mov      w1, #0x43
026a3c80: e2031faa mov      x2, xzr
026a3c84: b2dbe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3c88: a0020036 tbz      w0, #0, #0x26a3cdc
026a3c8c: 485c01d0 adrp     x8, #0x522d000
026a3c90: 081547f9 ldr      x8, [x8, #0xe28]
026a3c94: 20088052 mov      w0, #0x41
026a3c98: 010140f9 ldr      x1, [x8]
026a3c9c: 746bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3ca0: 080340f9 ldr      x8, [x24]
026a3ca4: f40300aa mov      x20, x0
026a3ca8: e00308aa mov      x0, x8
026a3cac: db35a497 bl       #0xfb1418
026a3cb0: 802900b4 cbz      x0, #0x26a41e0
026a3cb4: e20240f9 ldr      x2, [x23]
026a3cb8: e10313aa mov      x1, x19
026a3cbc: e3031faa mov      x3, xzr
026a3cc0: f50300aa mov      x21, x0
026a3cc4: eb83e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3cc8: d42800b4 cbz      x20, #0x26a41e0
026a3ccc: e00314aa mov      x0, x20
026a3cd0: e10315aa mov      x1, x21
026a3cd4: e2031faa mov      x2, xzr
026a3cd8: 97171b94 bl       #0x2d69b34 ; Royal.Scenes.Game.Mechanics.Items.GiantPiggyItem.GiantPiggyItemHelper$$add_OnItemSpawned
026a3cdc: 602640f9 ldr      x0, [x19, #0x48]
026a3ce0: 002800b4 cbz      x0, #0x26a41e0
026a3ce4: e10d8052 mov      w1, #0x6f
026a3ce8: e2031faa mov      x2, xzr
026a3cec: 98dbe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3cf0: a0020036 tbz      w0, #0, #0x26a3d44
026a3cf4: 68590190 adrp     x8, #0x51cf000
026a3cf8: 084945f9 ldr      x8, [x8, #0xa90]
026a3cfc: 400d8052 mov      w0, #0x6a
026a3d00: 010140f9 ldr      x1, [x8]
026a3d04: 5a6bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3d08: 080340f9 ldr      x8, [x24]
026a3d0c: f40300aa mov      x20, x0
026a3d10: e00308aa mov      x0, x8
026a3d14: c135a497 bl       #0xfb1418
026a3d18: 402600b4 cbz      x0, #0x26a41e0
026a3d1c: e20240f9 ldr      x2, [x23]
026a3d20: e10313aa mov      x1, x19
026a3d24: e3031faa mov      x3, xzr
026a3d28: f50300aa mov      x21, x0
026a3d2c: d183e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3d30: 942500b4 cbz      x20, #0x26a41e0
026a3d34: e00314aa mov      x0, x20
026a3d38: e10315aa mov      x1, x21
026a3d3c: e2031faa mov      x2, xzr
026a3d40: de0b5d94 bl       #0x3de6cb8 ; Royal.Scenes.Game.Mechanics.Items.ToyBoatItem.ToyBoatItemHelper$$add_OnItemSpawned
026a3d44: 602640f9 ldr      x0, [x19, #0x48]
026a3d48: c02400b4 cbz      x0, #0x26a41e0
026a3d4c: c1088052 mov      w1, #0x46
026a3d50: e2031faa mov      x2, xzr
026a3d54: 7edbe697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3d58: a0020036 tbz      w0, #0, #0x26a3dac
026a3d5c: 685701b0 adrp     x8, #0x5190000
026a3d60: 087544f9 ldr      x8, [x8, #0x8e8]
026a3d64: e0088052 mov      w0, #0x47
026a3d68: 010140f9 ldr      x1, [x8]
026a3d6c: 406bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3d70: 080340f9 ldr      x8, [x24]
026a3d74: f40300aa mov      x20, x0
026a3d78: e00308aa mov      x0, x8
026a3d7c: a735a497 bl       #0xfb1418
026a3d80: 002300b4 cbz      x0, #0x26a41e0
026a3d84: e20240f9 ldr      x2, [x23]
026a3d88: e10313aa mov      x1, x19
026a3d8c: e3031faa mov      x3, xzr
026a3d90: f50300aa mov      x21, x0
026a3d94: b783e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3d98: 542200b4 cbz      x20, #0x26a41e0
026a3d9c: e00314aa mov      x0, x20
026a3da0: e10315aa mov      x1, x21
026a3da4: e2031faa mov      x2, xzr
026a3da8: 9eb5d597 bl       #0x1c11420 ; Royal.Scenes.Game.Mechanics.Items.PorcelainItem.PorcelainItemHelper$$add_OnItemSpawned
026a3dac: 602640f9 ldr      x0, [x19, #0x48]
026a3db0: 802100b4 cbz      x0, #0x26a41e0
026a3db4: 595c01b0 adrp     x25, #0x522c000
026a3db8: 39e743f9 ldr      x25, [x25, #0x7c8]
026a3dbc: 61018052 mov      w1, #0xb
026a3dc0: e2031faa mov      x2, xzr
026a3dc4: 30dbe697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3dc8: 00040036 tbz      w0, #0, #0x26a3e48
026a3dcc: 485c01b0 adrp     x8, #0x522c000
026a3dd0: 08c140f9 ldr      x8, [x8, #0x180]
026a3dd4: 40088052 mov      w0, #0x42
026a3dd8: 010140f9 ldr      x1, [x8]
026a3ddc: 246bfa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3de0: 681641b9 ldr      w8, [x19, #0x114]
026a3de4: f40300aa mov      x20, x0
026a3de8: e1031faa mov      x1, xzr
026a3dec: e003082a mov      w0, w8
026a3df0: 105a1a94 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
026a3df4: e1031faa mov      x1, xzr
026a3df8: d1823394 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026a3dfc: 080340f9 ldr      x8, [x24]
026a3e00: f603002a mov      w22, w0
026a3e04: e00308aa mov      x0, x8
026a3e08: 8435a497 bl       #0xfb1418
026a3e0c: a01e00b4 cbz      x0, #0x26a41e0
026a3e10: f50300aa mov      x21, x0
026a3e14: 76000036 tbz      w22, #0, #0x26a3e20
026a3e18: e20240f9 ldr      x2, [x23]
026a3e1c: 02000014 b        #0x26a3e24
026a3e20: 220340f9 ldr      x2, [x25]
026a3e24: e00315aa mov      x0, x21
026a3e28: e10313aa mov      x1, x19
026a3e2c: e3031faa mov      x3, xzr
026a3e30: 9083e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3e34: 741d00b4 cbz      x20, #0x26a41e0
026a3e38: e00314aa mov      x0, x20
026a3e3c: e10315aa mov      x1, x21
026a3e40: e2031faa mov      x2, xzr
026a3e44: c969c797 bl       #0x187e568 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.BlindsItem.BlindsItemHelper$$add_OnBlindsItemReveal
026a3e48: 602640f9 ldr      x0, [x19, #0x48]
026a3e4c: a01c00b4 cbz      x0, #0x26a41e0
026a3e50: 41028052 mov      w1, #0x12
026a3e54: e2031faa mov      x2, xzr
026a3e58: 0bdbe697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3e5c: 00040036 tbz      w0, #0, #0x26a3edc
026a3e60: 685901b0 adrp     x8, #0x51d0000
026a3e64: 087940f9 ldr      x8, [x8, #0xf0]
026a3e68: 000d8052 mov      w0, #0x68
026a3e6c: 010140f9 ldr      x1, [x8]
026a3e70: ff6afa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3e74: 681641b9 ldr      w8, [x19, #0x114]
026a3e78: f40300aa mov      x20, x0
026a3e7c: e1031faa mov      x1, xzr
026a3e80: e003082a mov      w0, w8
026a3e84: eb591a94 bl       #0x2d3a630 ; Royal.Scenes.Game.Mechanics.Explode.TriggerExtensions$$AsGuidedExploderType
026a3e88: e1031faa mov      x1, xzr
026a3e8c: ac823394 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
026a3e90: 080340f9 ldr      x8, [x24]
026a3e94: f603002a mov      w22, w0
026a3e98: e00308aa mov      x0, x8
026a3e9c: 5f35a497 bl       #0xfb1418
026a3ea0: 001a00b4 cbz      x0, #0x26a41e0
026a3ea4: f50300aa mov      x21, x0
026a3ea8: 76000036 tbz      w22, #0, #0x26a3eb4
026a3eac: e20240f9 ldr      x2, [x23]
026a3eb0: 02000014 b        #0x26a3eb8
026a3eb4: 220340f9 ldr      x2, [x25]
026a3eb8: e00315aa mov      x0, x21
026a3ebc: e10313aa mov      x1, x19
026a3ec0: e3031faa mov      x3, xzr
026a3ec4: 6b83e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3ec8: d41800b4 cbz      x20, #0x26a41e0
026a3ecc: e00314aa mov      x0, x20
026a3ed0: e10315aa mov      x1, x21
026a3ed4: e2031faa mov      x2, xzr
026a3ed8: 34d9ba97 bl       #0x155a3a8 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.MetalPlateItem.MetalPlateItemHelper$$add_OnMetalPlateItemReveal
026a3edc: 602640f9 ldr      x0, [x19, #0x48]
026a3ee0: 001800b4 cbz      x0, #0x26a41e0
026a3ee4: a1008052 mov      w1, #5
026a3ee8: e2031faa mov      x2, xzr
026a3eec: e6dae697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3ef0: c0020036 tbz      w0, #0, #0x26a3f48
026a3ef4: c85a01f0 adrp     x8, #0x51fe000
026a3ef8: 081d44f9 ldr      x8, [x8, #0x838]
026a3efc: 40038052 mov      w0, #0x1a
026a3f00: 010140f9 ldr      x1, [x8]
026a3f04: da6afa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3f08: 080340f9 ldr      x8, [x24]
026a3f0c: f40300aa mov      x20, x0
026a3f10: e00308aa mov      x0, x8
026a3f14: 4135a497 bl       #0xfb1418
026a3f18: 401600b4 cbz      x0, #0x26a41e0
026a3f1c: 680240f9 ldr      x8, [x19]
026a3f20: e10313aa mov      x1, x19
026a3f24: e3031faa mov      x3, xzr
026a3f28: f50300aa mov      x21, x0
026a3f2c: 023145f9 ldr      x2, [x8, #0xa60]
026a3f30: 5083e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3f34: 741500b4 cbz      x20, #0x26a41e0
026a3f38: e00314aa mov      x0, x20
026a3f3c: e10315aa mov      x1, x21
026a3f40: e2031faa mov      x2, xzr
026a3f44: b793bc97 bl       #0x15c8e20 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.CurtainItem.CurtainHelper$$add_OnCurtainReveal
026a3f48: 602640f9 ldr      x0, [x19, #0x48]
026a3f4c: a01400b4 cbz      x0, #0x26a41e0
026a3f50: 61098052 mov      w1, #0x4b
026a3f54: e2031faa mov      x2, xzr
026a3f58: fddae697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3f5c: 80010036 tbz      w0, #0, #0x26a3f8c
026a3f60: 000340f9 ldr      x0, [x24]
026a3f64: 2d35a497 bl       #0xfb1418
026a3f68: c01300b4 cbz      x0, #0x26a41e0
026a3f6c: e20240f9 ldr      x2, [x23]
026a3f70: e10313aa mov      x1, x19
026a3f74: e3031faa mov      x3, xzr
026a3f78: f40300aa mov      x20, x0
026a3f7c: 3d83e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3f80: e00314aa mov      x0, x20
026a3f84: e1031faa mov      x1, xzr
026a3f88: 8c5beb97 bl       #0x217adb8 ; Royal.Scenes.Game.Mechanics.Items.AncientVaultItem.AncientVaultItemHelper$$add_OnDoorOpen
026a3f8c: 602640f9 ldr      x0, [x19, #0x48]
026a3f90: 801200b4 cbz      x0, #0x26a41e0
026a3f94: 010e8052 mov      w1, #0x70
026a3f98: e2031faa mov      x2, xzr
026a3f9c: ecdae697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3fa0: 80010036 tbz      w0, #0, #0x26a3fd0
026a3fa4: 000340f9 ldr      x0, [x24]
026a3fa8: 1c35a497 bl       #0xfb1418
026a3fac: a01100b4 cbz      x0, #0x26a41e0
026a3fb0: e20240f9 ldr      x2, [x23]
026a3fb4: e10313aa mov      x1, x19
026a3fb8: e3031faa mov      x3, xzr
026a3fbc: f40300aa mov      x20, x0
026a3fc0: 2c83e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a3fc4: e00314aa mov      x0, x20
026a3fc8: e1031faa mov      x1, xzr
026a3fcc: 1e2b2994 bl       #0x30eec44 ; Royal.Scenes.Game.Mechanics.Items.ColorMixerItem.ColorMixerItemHelper$$add_OnDoorOpen
026a3fd0: 602640f9 ldr      x0, [x19, #0x48]
026a3fd4: 601000b4 cbz      x0, #0x26a41e0
026a3fd8: e1018052 mov      w1, #0xf
026a3fdc: e2031faa mov      x2, xzr
026a3fe0: a9dae697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a3fe4: c0020036 tbz      w0, #0, #0x26a403c
026a3fe8: 885b01d0 adrp     x8, #0x5215000
026a3fec: 084545f9 ldr      x8, [x8, #0xa88]
026a3ff0: a0098052 mov      w0, #0x4d
026a3ff4: 010140f9 ldr      x1, [x8]
026a3ff8: 9d6afa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a3ffc: 080340f9 ldr      x8, [x24]
026a4000: f40300aa mov      x20, x0
026a4004: e00308aa mov      x0, x8
026a4008: 0435a497 bl       #0xfb1418
026a400c: a00e00b4 cbz      x0, #0x26a41e0
026a4010: 680240f9 ldr      x8, [x19]
026a4014: e10313aa mov      x1, x19
026a4018: e3031faa mov      x3, xzr
026a401c: f50300aa mov      x21, x0
026a4020: 023145f9 ldr      x2, [x8, #0xa60]
026a4024: 1383e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a4028: d40d00b4 cbz      x20, #0x26a41e0
026a402c: e00314aa mov      x0, x20
026a4030: e10315aa mov      x1, x21
026a4034: e2031faa mov      x2, xzr
026a4038: d414d497 bl       #0x1ba9388 ; Royal.Scenes.Game.Mechanics.Items.StaticItems.ForceFieldItem.ForceFieldItemHelper$$add_OnReveal
026a403c: 602640f9 ldr      x0, [x19, #0x48]
026a4040: 000d00b4 cbz      x0, #0x26a41e0
026a4044: e1098052 mov      w1, #0x4f
026a4048: e2031faa mov      x2, xzr
026a404c: c0dae697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a4050: 80010036 tbz      w0, #0, #0x26a4080
026a4054: 000340f9 ldr      x0, [x24]
026a4058: f034a497 bl       #0xfb1418
026a405c: 200c00b4 cbz      x0, #0x26a41e0
026a4060: e20240f9 ldr      x2, [x23]
026a4064: e10313aa mov      x1, x19
026a4068: e3031faa mov      x3, xzr
026a406c: f40300aa mov      x20, x0
026a4070: 0083e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a4074: e00314aa mov      x0, x20
026a4078: e1031faa mov      x1, xzr
026a407c: 3a2cde97 bl       #0x1e2f164 ; Royal.Scenes.Game.Mechanics.Items.LogItem.LogItemHelper$$add_OnLatestReveal
026a4080: 602640f9 ldr      x0, [x19, #0x48]
026a4084: e00a00b4 cbz      x0, #0x26a41e0
026a4088: 410a8052 mov      w1, #0x52
026a408c: e2031faa mov      x2, xzr
026a4090: afdae697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a4094: a0020036 tbz      w0, #0, #0x26a40e8
026a4098: 285c01d0 adrp     x8, #0x522a000
026a409c: 083540f9 ldr      x8, [x8, #0x68]
026a40a0: 200a8052 mov      w0, #0x51
026a40a4: 010140f9 ldr      x1, [x8]
026a40a8: 716afa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a40ac: 080340f9 ldr      x8, [x24]
026a40b0: f40300aa mov      x20, x0
026a40b4: e00308aa mov      x0, x8
026a40b8: d834a497 bl       #0xfb1418
026a40bc: 200900b4 cbz      x0, #0x26a41e0
026a40c0: e20240f9 ldr      x2, [x23]
026a40c4: e10313aa mov      x1, x19
026a40c8: e3031faa mov      x3, xzr
026a40cc: f50300aa mov      x21, x0
026a40d0: e882e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a40d4: 740800b4 cbz      x20, #0x26a41e0
026a40d8: e00314aa mov      x0, x20
026a40dc: e10315aa mov      x1, x21
026a40e0: e2031faa mov      x2, xzr
026a40e4: 631beb97 bl       #0x216ae70 ; Royal.Scenes.Game.Mechanics.Items.ShuttleItem.ShuttleItemHelper$$add_OnItemSpawned
026a40e8: 602640f9 ldr      x0, [x19, #0x48]
026a40ec: a00700b4 cbz      x0, #0x26a41e0
026a40f0: 01028052 mov      w1, #0x10
026a40f4: e2031faa mov      x2, xzr
026a40f8: 63dae697 bl       #0x205aa84 ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a40fc: c0020036 tbz      w0, #0, #0x26a4154
026a4100: 48590190 adrp     x8, #0x51cc000
026a4104: 08bd45f9 ldr      x8, [x8, #0xb78]
026a4108: 400a8052 mov      w0, #0x52
026a410c: 010140f9 ldr      x1, [x8]
026a4110: 576afa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a4114: 080340f9 ldr      x8, [x24]
026a4118: f40300aa mov      x20, x0
026a411c: e00308aa mov      x0, x8
026a4120: be34a497 bl       #0xfb1418
026a4124: e00500b4 cbz      x0, #0x26a41e0
026a4128: 680240f9 ldr      x8, [x19]
026a412c: e10313aa mov      x1, x19
026a4130: e3031faa mov      x3, xzr
026a4134: f50300aa mov      x21, x0
026a4138: 023145f9 ldr      x2, [x8, #0xa60]
026a413c: cd82e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a4140: 140500b4 cbz      x20, #0x26a41e0
026a4144: e00314aa mov      x0, x20
026a4148: e10315aa mov      x1, x21
026a414c: e2031faa mov      x2, xzr
026a4150: b332c797 bl       #0x1870c1c ; Royal.Scenes.Game.Mechanics.Items.StaticItems.CryptexItem.CryptexItemHelper$$add_OnCryptexReveal
026a4154: 602640f9 ldr      x0, [x19, #0x48]
026a4158: 400400b4 cbz      x0, #0x26a41e0
026a415c: 210d8052 mov      w1, #0x69
026a4160: e2031faa mov      x2, xzr
026a4164: 7adae697 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
026a4168: 20030036 tbz      w0, #0, #0x26a41cc
026a416c: 885901f0 adrp     x8, #0x51d7000
026a4170: 087940f9 ldr      x8, [x8, #0xf0]
026a4174: 800c8052 mov      w0, #0x64
026a4178: 010140f9 ldr      x1, [x8]
026a417c: 3c6afa97 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
026a4180: 080340f9 ldr      x8, [x24]
026a4184: f40300aa mov      x20, x0
026a4188: e00308aa mov      x0, x8
026a418c: a334a497 bl       #0xfb1418
026a4190: 800200b4 cbz      x0, #0x26a41e0
026a4194: e20240f9 ldr      x2, [x23]
026a4198: e10313aa mov      x1, x19
026a419c: e3031faa mov      x3, xzr
026a41a0: f50300aa mov      x21, x0
026a41a4: b382e497 bl       #0x1fc4c70 ; System.Action$$.ctor
026a41a8: d40100b4 cbz      x20, #0x26a41e0
026a41ac: e00314aa mov      x0, x20
026a41b0: e10315aa mov      x1, x21
026a41b4: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a41b8: f55342a9 ldp      x21, x20, [sp, #0x20]
026a41bc: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a41c0: e2031faa mov      x2, xzr
026a41c4: f963c4a8 ldp      x25, x24, [sp], #0x40
026a41c8: 0afedd17 b        #0x1e239f0 ; Royal.Scenes.Game.Mechanics.Items.MagicLanternItem.MagicLanternItemHelper$$add_OnMagicLanternActivate
026a41cc: f37b43a9 ldp      x19, x30, [sp, #0x30]
026a41d0: f55342a9 ldp      x21, x20, [sp, #0x20]
026a41d4: f75b41a9 ldp      x23, x22, [sp, #0x10]
026a41d8: f963c4a8 ldp      x25, x24, [sp], #0x40
026a41dc: c0035fd6 ret      
026a41e0: 9234a497 bl       #0xfb1428
