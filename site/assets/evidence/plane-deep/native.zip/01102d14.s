# Royal.Scenes.Game.Mechanics.Items.SwordItem.SwordItemModel$$GetExplodeScore
# Linear span to next metadata entry; not a complete CFG.
01102d14: f40f1ef8 str      x20, [sp, #-0x20]!
01102d18: f37b01a9 stp      x19, x30, [sp, #0x10]
01102d1c: f403012a mov      w20, w1
01102d20: f30300aa mov      x19, x0
01102d24: e003012a mov      w0, w1
01102d28: e1031faa mov      x1, xzr
01102d2c: 04078a94 bl       #0x338493c ; Royal.Scenes.Game.Mechanics.Items.Config.GameplayExtensions$$IsSingleExploderStrategy
01102d30: 9f0a0071 cmp      w20, #2
01102d34: 40000054 b.eq     #0x1102d3c
01102d38: 20040036 tbz      w0, #0, #0x1102dbc
01102d3c: 680240f9 ldr      x8, [x19]
01102d40: e00313aa mov      x0, x19
01102d44: 096542f9 ldr      x9, [x8, #0x4c8]
01102d48: 016942f9 ldr      x1, [x8, #0x4d0]
01102d4c: 20013fd6 blr      x9
01102d50: 1f040071 cmp      w0, #1
01102d54: 41030054 b.ne     #0x1102dbc
01102d58: 680240f9 ldr      x8, [x19]
01102d5c: e00313aa mov      x0, x19
01102d60: 09bd41f9 ldr      x9, [x8, #0x378]
01102d64: 01c141f9 ldr      x1, [x8, #0x380]
01102d68: 20013fd6 blr      x9
01102d6c: e1031faa mov      x1, xzr
01102d70: 06078a94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01102d74: 680240f9 ldr      x8, [x19]
01102d78: f403002a mov      w20, w0
01102d7c: e00313aa mov      x0, x19
01102d80: 09bd41f9 ldr      x9, [x8, #0x378]
01102d84: 01c141f9 ldr      x1, [x8, #0x380]
01102d88: 20013fd6 blr      x9
01102d8c: e1031faa mov      x1, xzr
01102d90: fe068a94 bl       #0x3384988 ; Royal.Scenes.Game.Mechanics.Items.Config.ItemExtensions$$ExplodeScore
01102d94: c8aa8a52 mov      w8, #0x5556
01102d98: a8aaaa72 movk     w8, #0x5555, lsl #16
01102d9c: 087c289b smull    x8, w0, w8
01102da0: f37b41a9 ldp      x19, x30, [sp, #0x10]
01102da4: 09fd7fd3 lsr      x9, x8, #0x3f
01102da8: 08fd60d3 lsr      x8, x8, #0x20
01102dac: 0801090b add      w8, w8, w9
01102db0: 0001140b add      w0, w8, w20
01102db4: f40742f8 ldr      x20, [sp], #0x20
01102db8: c0035fd6 ret      
01102dbc: e00313aa mov      x0, x19
01102dc0: f37b41a9 ldp      x19, x30, [sp, #0x10]
01102dc4: e103142a mov      w1, w20
01102dc8: e2031faa mov      x2, xzr
01102dcc: f40742f8 ldr      x20, [sp], #0x20
01102dd0: b03b8a14 b        #0x3391c90 ; Royal.Scenes.Game.Mechanics.Items.Config.MultipleCellItemModel$$GetExplodeScore
