# Royal.Scenes.Game.Mechanics.Items.SpecialItems.PropellerItem.Strategy.PropellerDefaultStrategy$$TryRedirectForSoilWinCondition
# Linear span to next metadata entry; not a complete CFG.
033a3170: f40f1ef8 str      x20, [sp, #-0x20]!
033a3174: f37b01a9 stp      x19, x30, [sp, #0x10]
033a3178: 140f01f0 adrp     x20, #0x5586000
033a317c: 883a6739 ldrb     w8, [x20, #0x9ce]
033a3180: f30300aa mov      x19, x0
033a3184: 28010037 tbnz     w8, #0, #0x33a31a8
033a3188: e0f200f0 adrp     x0, #0x5202000
033a318c: 008840f9 ldr      x0, [x0, #0x110]
033a3190: 5c387097 bl       #0xfb1300
033a3194: 00f100f0 adrp     x0, #0x51c6000
033a3198: 00f045f9 ldr      x0, [x0, #0xbe0]
033a319c: 59387097 bl       #0xfb1300
033a31a0: 28008052 mov      w8, #1
033a31a4: 883a2739 strb     w8, [x20, #0x9ce]
033a31a8: 600a40f9 ldr      x0, [x19, #0x10]
033a31ac: 800200b4 cbz      x0, #0x33a31fc
033a31b0: 81038052 mov      w1, #0x1c
033a31b4: e2031faa mov      x2, xzr
033a31b8: 65deb297 bl       #0x205ab4c ; Royal.Player.Context.Units.LevelManager$$IsThereItemInLevel
033a31bc: 80010036 tbz      w0, #0, #0x33a31ec
033a31c0: e8f200f0 adrp     x8, #0x5202000
033a31c4: 088940f9 ldr      x8, [x8, #0x110]
033a31c8: c0038052 mov      w0, #0x1e
033a31cc: 010140f9 ldr      x1, [x8]
033a31d0: 276ec697 bl       #0x253ea6c ; Royal.Scenes.Game.Levels.LevelContext$$GetLate<object>
033a31d4: 400100b4 cbz      x0, #0x33a31fc
033a31d8: e1031faa mov      x1, xzr
033a31dc: d7f7bf97 bl       #0x23a1138 ; Royal.Scenes.Game.Mechanics.Items.SoilItem.SoilItemHelper$$TryGetLastGroupsSoilCellPointWithOneLayer
033a31e0: 1f1c0072 tst      w0, #0xff
033a31e4: e0079f1a cset     w0, ne
033a31e8: 02000014 b        #0x33a31f0
033a31ec: e0031f2a mov      w0, wzr
033a31f0: f37b41a9 ldp      x19, x30, [sp, #0x10]
033a31f4: f40742f8 ldr      x20, [sp], #0x20
033a31f8: c0035fd6 ret      
033a31fc: 8b387097 bl       #0xfb1428
