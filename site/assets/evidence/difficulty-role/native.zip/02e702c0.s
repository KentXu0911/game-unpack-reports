# Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetSyncRequiredKeyValueCounts
# Linear metadata span, not a recovered full CFG.
02e702c0: ff8304d1 sub      sp, sp, #0x120
02e702c4: fc8300f9 str      x28, [sp, #0x100]
02e702c8: f37b11a9 stp      x19, x30, [sp, #0x110]
02e702cc: f30308aa mov      x19, x8
02e702d0: 1bffff97 bl       #0x2e6ff3c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$get_DatabaseService
02e702d4: e8230091 add      x8, sp, #8
02e702d8: 2dd2ff97 bl       #0x2e64b8c ; Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$GetSyncRequiredKeyValueCounts
02e702dc: e1230091 add      x1, sp, #8
02e702e0: 021f8052 mov      w2, #0xf8
02e702e4: e00313aa mov      x0, x19
02e702e8: ba467997 bl       #0xcc1dd0 ; 
02e702ec: f37b51a9 ldp      x19, x30, [sp, #0x110]
02e702f0: fc8340f9 ldr      x28, [sp, #0x100]
02e702f4: ff830491 add      sp, sp, #0x120
02e702f8: c0035fd6 ret      
