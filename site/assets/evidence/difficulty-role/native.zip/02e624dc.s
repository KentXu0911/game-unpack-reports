# Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableScenariosTable$$DuplicateDataFromAllScenariosTable
# Linear metadata span, not a recovered full CFG.
02e624dc: ff0303d1 sub      sp, sp, #0xc0
02e624e0: f75b09a9 stp      x23, x22, [sp, #0x90]
02e624e4: f5530aa9 stp      x21, x20, [sp, #0xa0]
02e624e8: f37b0ba9 stp      x19, x30, [sp, #0xb0]
02e624ec: 143901d0 adrp     x20, #0x5584000
02e624f0: 88ea6039 ldrb     w8, [x20, #0x83a]
02e624f4: f30300aa mov      x19, x0
02e624f8: c8000037 tbnz     w8, #0, #0x2e62510
02e624fc: c0190190 adrp     x0, #0x519a000
02e62500: 006441f9 ldr      x0, [x0, #0x2c8]
02e62504: 7f3b8597 bl       #0xfb1300 ; 
02e62508: 28008052 mov      w8, #1
02e6250c: 88ea2039 strb     w8, [x20, #0x83a]
02e62510: 00e4006f movi     v0.2d, #0000000000000000
02e62514: e08303ad stp      q0, q0, [sp, #0x70]
02e62518: e08302ad stp      q0, q0, [sp, #0x50]
02e6251c: 530900b4 cbz      x19, #0x2e62644
02e62520: e00313aa mov      x0, x19
02e62524: e1031faa mov      x1, xzr
02e62528: 1ba41894 bl       #0x348b594 ; Royal.Scenes.Start.Context.Units.FeatureBundle.DragonNestScenarioBundle$$AllScenariosDataText
02e6252c: c00800b4 cbz      x0, #0x2e62644
02e62530: e1031faa mov      x1, xzr
02e62534: 17863a94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02e62538: 600800b4 cbz      x0, #0x2e62644
02e6253c: 41018052 mov      w1, #0xa
02e62540: e2031f2a mov      w2, wzr
02e62544: e3031faa mov      x3, xzr
02e62548: 8b9eba97 bl       #0x1d09f74 ; System.String$$Split
02e6254c: c00700b4 cbz      x0, #0x2e62644
02e62550: d6190190 adrp     x22, #0x519a000
02e62554: d66641f9 ldr      x22, [x22, #0x2c8]
02e62558: f30300aa mov      x19, x0
02e6255c: f5031faa mov      x21, xzr
02e62560: 17800091 add      x23, x0, #0x20
02e62564: 681a40b9 ldr      w8, [x19, #0x18]
02e62568: bf02086b cmp      w21, w8
02e6256c: a2060054 b.hs     #0x2e62640
02e62570: e07a75f8 ldr      x0, [x23, x21, lsl #3]
02e62574: 800600b4 cbz      x0, #0x2e62644
02e62578: 61078052 mov      w1, #0x3b
02e6257c: e2031f2a mov      w2, wzr
02e62580: e3031faa mov      x3, xzr
02e62584: 7c9eba97 bl       #0x1d09f74 ; System.String$$Split
02e62588: e00500b4 cbz      x0, #0x2e62644
02e6258c: 081840b9 ldr      w8, [x0, #0x18]
02e62590: 88050034 cbz      w8, #0x2e62640
02e62594: 1f050071 cmp      w8, #1
02e62598: 40050054 b.eq     #0x2e62640
02e6259c: 1f090071 cmp      w8, #2
02e625a0: 09050054 b.ls     #0x2e62640
02e625a4: 1f0d0071 cmp      w8, #3
02e625a8: c0040054 b.eq     #0x2e62640
02e625ac: 1f110071 cmp      w8, #4
02e625b0: 89040054 b.ls     #0x2e62640
02e625b4: 1f150071 cmp      w8, #5
02e625b8: 40040054 b.eq     #0x2e62640
02e625bc: 1f190071 cmp      w8, #6
02e625c0: 09040054 b.ls     #0x2e62640
02e625c4: 020c42a9 ldp      x2, x3, [x0, #0x20]
02e625c8: 041443a9 ldp      x4, x5, [x0, #0x30]
02e625cc: 061c44a9 ldp      x6, x7, [x0, #0x40]
02e625d0: 082840f9 ldr      x8, [x0, #0x50]
02e625d4: a1060011 add      w1, w21, #1
02e625d8: e0430191 add      x0, sp, #0x50
02e625dc: e80300f9 str      x8, [sp]
02e625e0: 1a000094 bl       #0x2e62648 ; Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableScenariosTableItem$$.ctor
02e625e4: 91ffff97 bl       #0x2e62428 ; Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableScenariosTable$$get_DatabaseService
02e625e8: f40300aa mov      x20, x0
02e625ec: e10343ad ldp      q1, q0, [sp, #0x60]
02e625f0: e217c03d ldr      q2, [sp, #0x50]
02e625f4: e323c03d ldr      q3, [sp, #0x80]
02e625f8: c00240f9 ldr      x0, [x22]
02e625fc: e1430091 add      x1, sp, #0x10
02e62600: e10301ad stp      q1, q0, [sp, #0x20]
02e62604: e207803d str      q2, [sp, #0x10]
02e62608: e313803d str      q3, [sp, #0x40]
02e6260c: 803b8597 bl       #0xfb140c ; 
02e62610: b40100b4 cbz      x20, #0x2e62644
02e62614: e10300aa mov      x1, x0
02e62618: e00314aa mov      x0, x20
02e6261c: 75deff97 bl       #0x2e59ff0 ; Royal.Infrastructure.Services.Storage.DatabaseService$$InsertOrReplace
02e62620: b5060091 add      x21, x21, #1
02e62624: bf2a0071 cmp      w21, #0xa
02e62628: e1f9ff54 b.ne     #0x2e62564
02e6262c: f37b4ba9 ldp      x19, x30, [sp, #0xb0]
02e62630: f5534aa9 ldp      x21, x20, [sp, #0xa0]
02e62634: f75b49a9 ldp      x23, x22, [sp, #0x90]
02e62638: ff030391 add      sp, sp, #0xc0
02e6263c: c0035fd6 ret      
02e62640: 7c3b8597 bl       #0xfb1430 ; 
02e62644: 793b8597 bl       #0xfb1428 ; 
