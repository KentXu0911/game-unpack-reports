# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ResetDifficultySeed
# Linear metadata span, not a recovered full CFG.
02a30e64: f60f1df8 str      x22, [sp, #-0x30]!
02a30e68: f55301a9 stp      x21, x20, [sp, #0x10]
02a30e6c: f37b02a9 stp      x19, x30, [sp, #0x20]
02a30e70: 945a01b0 adrp     x20, #0x5581000
02a30e74: 88ba7a39 ldrb     w8, [x20, #0xeae]
02a30e78: f30300aa mov      x19, x0
02a30e7c: a8020037 tbnz     w8, #0, #0x2a30ed0
02a30e80: a03e0190 adrp     x0, #0x5204000
02a30e84: 00bc47f9 ldr      x0, [x0, #0xf78]
02a30e88: 1e019697 bl       #0xfb1300 ; 
02a30e8c: 803b01b0 adrp     x0, #0x51a1000
02a30e90: 001c47f9 ldr      x0, [x0, #0xe38]
02a30e94: 1b019697 bl       #0xfb1300 ; 
02a30e98: a03d01b0 adrp     x0, #0x51e5000
02a30e9c: 000c44f9 ldr      x0, [x0, #0x818]
02a30ea0: 18019697 bl       #0xfb1300 ; 
02a30ea4: 004001b0 adrp     x0, #0x5231000
02a30ea8: 003841f9 ldr      x0, [x0, #0x270]
02a30eac: 15019697 bl       #0xfb1300 ; 
02a30eb0: 003c01f0 adrp     x0, #0x51b3000
02a30eb4: 00e840f9 ldr      x0, [x0, #0x1d0]
02a30eb8: 12019697 bl       #0xfb1300 ; 
02a30ebc: 604001b0 adrp     x0, #0x523d000
02a30ec0: 003845f9 ldr      x0, [x0, #0xa70]
02a30ec4: 0f019697 bl       #0xfb1300 ; 
02a30ec8: 28008052 mov      w8, #1
02a30ecc: 88ba3a39 strb     w8, [x20, #0xeae]
02a30ed0: 744001b0 adrp     x20, #0x523d000
02a30ed4: 68824039 ldrb     w8, [x19, #0x20]
02a30ed8: 943a45f9 ldr      x20, [x20, #0xa70]
02a30edc: c8000035 cbnz     w8, #0x2a30ef4
02a30ee0: 017d8052 mov      w1, #0x3e8
02a30ee4: e00313aa mov      x0, x19
02a30ee8: a1000094 bl       #0x2a3116c ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GenerateTrySeeds
02a30eec: 28008052 mov      w8, #1
02a30ef0: 68820039 strb     w8, [x19, #0x20]
02a30ef4: 800240f9 ldr      x0, [x20]
02a30ef8: e1031f2a mov      w1, wzr
02a30efc: e2031faa mov      x2, xzr
02a30f00: 6efc1094 bl       #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
02a30f04: 680a40f9 ldr      x8, [x19, #0x10]
02a30f08: 680600b4 cbz      x8, #0x2a30fd4
02a30f0c: a93d01b0 adrp     x9, #0x51e5000
02a30f10: 290d44f9 ldr      x9, [x9, #0x818]
02a30f14: 0a1940b9 ldr      w10, [x8, #0x18]
02a30f18: 144001b0 adrp     x20, #0x5231000
02a30f1c: 943a41f9 ldr      x20, [x20, #0x270]
02a30f20: 220140f9 ldr      x2, [x9]
02a30f24: b53e0190 adrp     x21, #0x5204000
02a30f28: b5be47f9 ldr      x21, [x21, #0xf78]
02a30f2c: 090cca1a sdiv     w9, w0, w10
02a30f30: 21810a1b msub     w1, w9, w10, w0
02a30f34: e00308aa mov      x0, x8
02a30f38: 28411894 bl       #0x30413d8 ; System.Collections.Generic.List<ushort>$$get_Item
02a30f3c: 013c0012 and      w1, w0, #0xffff
02a30f40: e00313aa mov      x0, x19
02a30f44: 2b010094 bl       #0x2a313f0 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$SetDifficultySeed
02a30f48: 800240f9 ldr      x0, [x20]
02a30f4c: 21008052 mov      w1, #1
02a30f50: 08019697 bl       #0xfb1370 ; 
02a30f54: f40300aa mov      x20, x0
02a30f58: 682640b9 ldr      w8, [x19, #0x24]
02a30f5c: a00240f9 ldr      x0, [x21]
02a30f60: e1330091 add      x1, sp, #0xc
02a30f64: e80f00b9 str      w8, [sp, #0xc]
02a30f68: 29019697 bl       #0xfb140c ; 
02a30f6c: 540300b4 cbz      x20, #0x2a30fd4
02a30f70: f50300aa mov      x21, x0
02a30f74: c00000b4 cbz      x0, #0x2a30f8c
02a30f78: 880240f9 ldr      x8, [x20]
02a30f7c: e00315aa mov      x0, x21
02a30f80: 012140f9 ldr      x1, [x8, #0x40]
02a30f84: 21019697 bl       #0xfb1408 ; 
02a30f88: a00200b4 cbz      x0, #0x2a30fdc
02a30f8c: 881a40b9 ldr      w8, [x20, #0x18]
02a30f90: 48020034 cbz      w8, #0x2a30fd8
02a30f94: 163c01f0 adrp     x22, #0x51b3000
02a30f98: d6ea40f9 ldr      x22, [x22, #0x1d0]
02a30f9c: e00314aa mov      x0, x20
02a30fa0: 150c02f8 str      x21, [x0, #0x20]!
02a30fa4: e10315aa mov      x1, x21
02a30fa8: c1009697 bl       #0xfb12ac ; 
02a30fac: c20240f9 ldr      x2, [x22]
02a30fb0: 41018052 mov      w1, #0xa
02a30fb4: e00313aa mov      x0, x19
02a30fb8: e30314aa mov      x3, x20
02a30fbc: e4031faa mov      x4, xzr
02a30fc0: 583ef797 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02a30fc4: f37b42a9 ldp      x19, x30, [sp, #0x20]
02a30fc8: f55341a9 ldp      x21, x20, [sp, #0x10]
02a30fcc: f60743f8 ldr      x22, [sp], #0x30
02a30fd0: c0035fd6 ret      
02a30fd4: 15019697 bl       #0xfb1428 ; 
02a30fd8: 16019697 bl       #0xfb1430 ; 
02a30fdc: 1c019697 bl       #0xfb144c ; 
02a30fe0: e1031faa mov      x1, xzr
02a30fe4: 03019697 bl       #0xfb13f0 ; 
