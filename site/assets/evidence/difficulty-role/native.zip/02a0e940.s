# Royal.Player.Context.Data.Persistent.UserInventory$$ResetDynamicDifficulty
# Linear metadata span, not a recovered full CFG.
02a0e940: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
02a0e944: f30300aa mov      x19, x0
02a0e948: 005840f9 ldr      x0, [x0, #0xb0]
02a0e94c: 62048052 mov      w2, #0x23
02a0e950: 23068052 mov      w3, #0x31
02a0e954: e1031f2a mov      w1, wzr
02a0e958: e4031faa mov      x4, xzr
02a0e95c: d3d62194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e960: e10300aa mov      x1, x0
02a0e964: e00313aa mov      x0, x19
02a0e968: 66ffff97 bl       #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
02a0e96c: 605a40f9 ldr      x0, [x19, #0xb0]
02a0e970: 42028052 mov      w2, #0x12
02a0e974: 43048052 mov      w3, #0x22
02a0e978: e1031f2a mov      w1, wzr
02a0e97c: e4031faa mov      x4, xzr
02a0e980: cad62194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e984: e10300aa mov      x1, x0
02a0e988: e00313aa mov      x0, x19
02a0e98c: 5dffff97 bl       #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
02a0e990: 605a40f9 ldr      x0, [x19, #0xb0]
02a0e994: 41018052 mov      w1, #0xa
02a0e998: a2018052 mov      w2, #0xd
02a0e99c: 23028052 mov      w3, #0x11
02a0e9a0: e4031faa mov      x4, xzr
02a0e9a4: c1d62194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e9a8: e10300aa mov      x1, x0
02a0e9ac: e00313aa mov      x0, x19
02a0e9b0: 54ffff97 bl       #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
02a0e9b4: e00313aa mov      x0, x19
02a0e9b8: e1031f2a mov      w1, wzr
02a0e9bc: f37bc1a8 ldp      x19, x30, [sp], #0x10
02a0e9c0: 06ffff17 b        #0x2a0e5d8 ; Royal.Player.Context.Data.Persistent.UserInventory$$SetTryCount2
