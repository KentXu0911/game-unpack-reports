# Royal.Player.Context.Units.RoyalPassManager$$FillFromLocal
# Linear metadata span, not a recovered full CFG.
032eec94: ff8302d1 sub      sp, sp, #0xa0
032eec98: f83300f9 str      x24, [sp, #0x60]
032eec9c: f75b07a9 stp      x23, x22, [sp, #0x70]
032eeca0: f55308a9 stp      x21, x20, [sp, #0x80]
032eeca4: f37b09a9 stp      x19, x30, [sp, #0x90]
032eeca8: d4140190 adrp     x20, #0x5586000
032eecac: 887a4e39 ldrb     w8, [x20, #0x39e]
032eecb0: f30300aa mov      x19, x0
032eecb4: e8040037 tbnz     w8, #0, #0x32eed50
032eecb8: a0f90090 adrp     x0, #0x5222000
032eecbc: 00ec42f9 ldr      x0, [x0, #0x5d8]
032eecc0: 90097397 bl       #0xfb1300 ; 
032eecc4: 80f700f0 adrp     x0, #0x51e1000
032eecc8: 00f841f9 ldr      x0, [x0, #0x3f0]
032eeccc: 8d097397 bl       #0xfb1300 ; 
032eecd0: a0f800d0 adrp     x0, #0x5204000
032eecd4: 00bc47f9 ldr      x0, [x0, #0xf78]
032eecd8: 8a097397 bl       #0xfb1300 ; 
032eecdc: 80f800d0 adrp     x0, #0x5200000
032eece0: 007440f9 ldr      x0, [x0, #0xe8]
032eece4: 87097397 bl       #0xfb1300 ; 
032eece8: 00f70090 adrp     x0, #0x51ce000
032eecec: 005840f9 ldr      x0, [x0, #0xb0]
032eecf0: 84097397 bl       #0xfb1300 ; 
032eecf4: 00fa00f0 adrp     x0, #0x5231000
032eecf8: 003841f9 ldr      x0, [x0, #0x270]
032eecfc: 81097397 bl       #0xfb1300 ; 
032eed00: 40fa00d0 adrp     x0, #0x5238000
032eed04: 009446f9 ldr      x0, [x0, #0xd28]
032eed08: 7e097397 bl       #0xfb1300 ; 
032eed0c: e0f900f0 adrp     x0, #0x522d000
032eed10: 00b840f9 ldr      x0, [x0, #0x170]
032eed14: 7b097397 bl       #0xfb1300 ; 
032eed18: a0f800f0 adrp     x0, #0x5205000
032eed1c: 00b841f9 ldr      x0, [x0, #0x370]
032eed20: 78097397 bl       #0xfb1300 ; 
032eed24: 00f500f0 adrp     x0, #0x5191000
032eed28: 001840f9 ldr      x0, [x0, #0x30]
032eed2c: 75097397 bl       #0xfb1300 ; 
032eed30: c0f700f0 adrp     x0, #0x51e9000
032eed34: 000842f9 ldr      x0, [x0, #0x410]
032eed38: 72097397 bl       #0xfb1300 ; 
032eed3c: e0f600b0 adrp     x0, #0x51cb000
032eed40: 004042f9 ldr      x0, [x0, #0x480]
032eed44: 6f097397 bl       #0xfb1300 ; 
032eed48: 28008052 mov      w8, #1
032eed4c: 887a0e39 strb     w8, [x20, #0x39e]
032eed50: f4f600b0 adrp     x20, #0x51cb000
032eed54: 944242f9 ldr      x20, [x20, #0x480]
032eed58: 00e4006f movi     v0.2d, #0000000000000000
032eed5c: e00313aa mov      x0, x19
032eed60: e1031faa mov      x1, xzr
032eed64: ff2b00f9 str      xzr, [sp, #0x50]
032eed68: e08301ad stp      q0, q0, [sp, #0x30]
032eed6c: e00b803d str      q0, [sp, #0x20]
032eed70: ff6f00b9 str      wzr, [sp, #0x6c]
032eed74: 8a4ec597 bl       #0x244279c ; Royal.Player.Context.Units.AEventManager$$FillFromLocal
032eed78: 680a4239 ldrb     w8, [x19, #0x82]
032eed7c: 48000034 cbz      w8, #0x32eed84
032eed80: 7f0a0239 strb     wzr, [x19, #0x82]
032eed84: 16f70090 adrp     x22, #0x51ce000
032eed88: 800240f9 ldr      x0, [x20]
032eed8c: d65a40f9 ldr      x22, [x22, #0xb0]
032eed90: e1031faa mov      x1, xzr
032eed94: e2031faa mov      x2, xzr
032eed98: 7dc4ed97 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
032eed9c: f40300aa mov      x20, x0
032eeda0: e1031faa mov      x1, xzr
032eeda4: 7e61a897 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
032eeda8: 80030036 tbz      w0, #0, #0x32eee18
032eedac: a8f90090 adrp     x8, #0x5222000
032eedb0: 08ed42f9 ldr      x8, [x8, #0x5d8]
032eedb4: 7f1a00b9 str      wzr, [x19, #0x18]
032eedb8: 140140f9 ldr      x20, [x8]
032eedbc: 881e40f9 ldr      x8, [x20, #0x38]
032eedc0: 000140f9 ldr      x0, [x8]
032eedc4: 08c84439 ldrb     w8, [x0, #0x132]
032eedc8: 48000037 tbnz     w8, #0, #0x32eedd0
032eedcc: 86487297 bl       #0xf80fe4 ; 
032eedd0: 08e040b9 ldr      w8, [x0, #0xe0]
032eedd4: 48000035 cbnz     w8, #0x32eeddc
032eedd8: 8b097397 bl       #0xfb1404 ; 
032eeddc: 881e40f9 ldr      x8, [x20, #0x38]
032eede0: 000140f9 ldr      x0, [x8]
032eede4: 08c84439 ldrb     w8, [x0, #0x132]
032eede8: 48000037 tbnz     w8, #0, #0x32eedf0
032eedec: 7e487297 bl       #0xf80fe4 ; 
032eedf0: c9f700f0 adrp     x9, #0x51e9000
032eedf4: 085c40f9 ldr      x8, [x0, #0xb8]
032eedf8: 290942f9 ldr      x9, [x9, #0x410]
032eedfc: 030140f9 ldr      x3, [x8]
032eee00: 220140f9 ldr      x2, [x9]
032eee04: 01038052 mov      w1, #0x18
032eee08: e00313aa mov      x0, x19
032eee0c: e4031faa mov      x4, xzr
032eee10: c446d497 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
032eee14: 18000014 b        #0x32eee74 ; 
032eee18: 142100b4 cbz      x20, #0x32ef238
032eee1c: e1148052 mov      w1, #0xa7
032eee20: e00314aa mov      x0, x20
032eee24: e2031f2a mov      w2, wzr
032eee28: e3031faa mov      x3, xzr
032eee2c: 526ca897 bl       #0x1d09f74 ; System.String$$Split
032eee30: f40300aa mov      x20, x0
032eee34: 402000b4 cbz      x0, #0x32ef23c
032eee38: 881a40b9 ldr      w8, [x20, #0x18]
032eee3c: 28200034 cbz      w8, #0x32ef240
032eee40: 801240f9 ldr      x0, [x20, #0x20]
032eee44: e1b30191 add      x1, sp, #0x6c
032eee48: e2031faa mov      x2, xzr
032eee4c: 859aca97 bl       #0x2595860 ; System.Int32$$TryParse
032eee50: 881a40b9 ldr      w8, [x20, #0x18]
032eee54: 1f050071 cmp      w8, #1
032eee58: 691f0054 b.ls     #0x32ef244
032eee5c: 801640f9 ldr      x0, [x20, #0x28]
032eee60: 61c20191 add      x1, x19, #0x70
032eee64: e2031faa mov      x2, xzr
032eee68: 5fa0ca97 bl       #0x2596fe4 ; System.Int64$$TryParse
032eee6c: e86f40b9 ldr      w8, [sp, #0x6c]
032eee70: 681a00b9 str      w8, [x19, #0x18]
032eee74: e8f900f0 adrp     x8, #0x522d000
032eee78: 08b940f9 ldr      x8, [x8, #0x170]
032eee7c: 000140f9 ldr      x0, [x8]
032eee80: e1031faa mov      x1, xzr
032eee84: e2031faa mov      x2, xzr
032eee88: 41c4ed97 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
032eee8c: c10240f9 ldr      x1, [x22]
032eee90: 4635c997 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
032eee94: e10300aa mov      x1, x0
032eee98: e00313aa mov      x0, x19
032eee9c: 018c06f8 str      x1, [x0, #0x68]!
032eeea0: 03097397 bl       #0xfb12ac ; 
032eeea4: f50313aa mov      x21, x19
032eeea8: a88e46f8 ldr      x8, [x21, #0x68]!
032eeeac: 280200b5 cbnz     x8, #0x32eeef0
032eeeb0: a8f800f0 adrp     x8, #0x5205000
032eeeb4: 49fa00d0 adrp     x9, #0x5238000
032eeeb8: 08b941f9 ldr      x8, [x8, #0x370]
032eeebc: 299546f9 ldr      x9, [x9, #0xd28]
032eeec0: 000140f9 ldr      x0, [x8]
032eeec4: 210140f9 ldr      x1, [x9]
032eeec8: 864bcb97 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
032eeecc: 002400b4 cbz      x0, #0x32ef34c
032eeed0: e1031faa mov      x1, xzr
032eeed4: af532894 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
032eeed8: c10240f9 ldr      x1, [x22]
032eeedc: 3335c997 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
032eeee0: e10300aa mov      x1, x0
032eeee4: a00200f9 str      x0, [x21]
032eeee8: e00315aa mov      x0, x21
032eeeec: f0087397 bl       #0xfb12ac ; 
032eeef0: e00313aa mov      x0, x19
032eeef4: 24010094 bl       #0x32ef384 ; Royal.Player.Context.Units.RoyalPassManager$$CheckForUnclaimedOldEvent
032eeef8: 54140190 adrp     x20, #0x5576000
032eeefc: 88ae7c39 ldrb     w8, [x20, #0xf2b]
032eef00: c8000035 cbnz     w8, #0x32eef18
032eef04: c0f800d0 adrp     x0, #0x5208000
032eef08: 00c041f9 ldr      x0, [x0, #0x380]
032eef0c: fd087397 bl       #0xfb1300 ; 
032eef10: 28008052 mov      w8, #1
032eef14: 88ae3c39 strb     w8, [x20, #0xf2b]
032eef18: c8f800d0 adrp     x8, #0x5208000
032eef1c: 08c141f9 ldr      x8, [x8, #0x380]
032eef20: 080140f9 ldr      x8, [x8]
032eef24: 085d40f9 ldr      x8, [x8, #0xb8]
032eef28: 080140f9 ldr      x8, [x8]
032eef2c: 082100b4 cbz      x8, #0x32ef34c
032eef30: 081140f9 ldr      x8, [x8, #0x20]
032eef34: c82000b4 cbz      x8, #0x32ef34c
032eef38: 09fa00f0 adrp     x9, #0x5231000
032eef3c: 293941f9 ldr      x9, [x9, #0x270]
032eef40: b7f800d0 adrp     x23, #0x5204000
032eef44: f7be47f9 ldr      x23, [x23, #0xf78]
032eef48: 0081c63c ldur     q0, [x8, #0x68]
032eef4c: 0a4d40f9 ldr      x10, [x8, #0x98]
032eef50: 0181c83c ldur     q1, [x8, #0x88]
032eef54: 0281c73c ldur     q2, [x8, #0x78]
032eef58: 200140f9 ldr      x0, [x9]
032eef5c: 01018052 mov      w1, #8
032eef60: ea2b00f9 str      x10, [sp, #0x50]
032eef64: e28701ad stp      q2, q1, [sp, #0x30]
032eef68: e00b803d str      q0, [sp, #0x20]
032eef6c: 01097397 bl       #0xfb1370 ; 
032eef70: f40300aa mov      x20, x0
032eef74: 681a40b9 ldr      w8, [x19, #0x18]
032eef78: e00240f9 ldr      x0, [x23]
032eef7c: e1a30191 add      x1, sp, #0x68
032eef80: e86b00b9 str      w8, [sp, #0x68]
032eef84: 22097397 bl       #0xfb140c ; 
032eef88: 341e00b4 cbz      x20, #0x32ef34c
032eef8c: f60300aa mov      x22, x0
032eef90: c00000b4 cbz      x0, #0x32eefa8
032eef94: 880240f9 ldr      x8, [x20]
032eef98: e00316aa mov      x0, x22
032eef9c: 012140f9 ldr      x1, [x8, #0x40]
032eefa0: 1a097397 bl       #0xfb1408 ; 
032eefa4: e01c00b4 cbz      x0, #0x32ef340
032eefa8: 881a40b9 ldr      w8, [x20, #0x18]
032eefac: 881c0034 cbz      w8, #0x32ef33c
032eefb0: e00314aa mov      x0, x20
032eefb4: 160c02f8 str      x22, [x0, #0x20]!
032eefb8: e10316aa mov      x1, x22
032eefbc: bc087397 bl       #0xfb12ac ; 
032eefc0: e83f40b9 ldr      w8, [sp, #0x3c]
032eefc4: e00240f9 ldr      x0, [x23]
032eefc8: e1730091 add      x1, sp, #0x1c
032eefcc: e81f00b9 str      w8, [sp, #0x1c]
032eefd0: 0f097397 bl       #0xfb140c ; 
032eefd4: f60300aa mov      x22, x0
032eefd8: c00000b4 cbz      x0, #0x32eeff0
032eefdc: 880240f9 ldr      x8, [x20]
032eefe0: e00316aa mov      x0, x22
032eefe4: 012140f9 ldr      x1, [x8, #0x40]
032eefe8: 08097397 bl       #0xfb1408 ; 
032eefec: a01a00b4 cbz      x0, #0x32ef340
032eeff0: 881a40b9 ldr      w8, [x20, #0x18]
032eeff4: 1f050071 cmp      w8, #1
032eeff8: 291a0054 b.ls     #0x32ef33c
032eeffc: 98f700f0 adrp     x24, #0x51e1000
032ef000: 18fb41f9 ldr      x24, [x24, #0x3f0]
032ef004: e00314aa mov      x0, x20
032ef008: 168c02f8 str      x22, [x0, #0x28]!
032ef00c: e10316aa mov      x1, x22
032ef010: a7087397 bl       #0xfb12ac ; 
032ef014: 611a40b9 ldr      w1, [x19, #0x18]
032ef018: e0830091 add      x0, sp, #0x20
032ef01c: e2031faa mov      x2, xzr
032ef020: 8fbbc197 bl       #0x235de5c ; Royal.Player.Context.Data.Persistent.RoyalPassProgress$$IsSameEvent
032ef024: 080340f9 ldr      x8, [x24]
032ef028: 09000012 and      w9, w0, #1
032ef02c: e1630091 add      x1, sp, #0x18
032ef030: e9630039 strb     w9, [sp, #0x18]
032ef034: e00308aa mov      x0, x8
032ef038: f5087397 bl       #0xfb140c ; 
032ef03c: f60300aa mov      x22, x0
032ef040: c00000b4 cbz      x0, #0x32ef058
032ef044: 880240f9 ldr      x8, [x20]
032ef048: e00316aa mov      x0, x22
032ef04c: 012140f9 ldr      x1, [x8, #0x40]
032ef050: ee087397 bl       #0xfb1408 ; 
032ef054: 601700b4 cbz      x0, #0x32ef340
032ef058: 881a40b9 ldr      w8, [x20, #0x18]
032ef05c: 1f090071 cmp      w8, #2
032ef060: e9160054 b.ls     #0x32ef33c
032ef064: e00314aa mov      x0, x20
032ef068: 160c03f8 str      x22, [x0, #0x30]!
032ef06c: e10316aa mov      x1, x22
032ef070: 8f087397 bl       #0xfb12ac ; 
032ef074: e84340b9 ldr      w8, [sp, #0x40]
032ef078: e00240f9 ldr      x0, [x23]
032ef07c: e1530091 add      x1, sp, #0x14
032ef080: e81700b9 str      w8, [sp, #0x14]
032ef084: e2087397 bl       #0xfb140c ; 
032ef088: f60300aa mov      x22, x0
032ef08c: c00000b4 cbz      x0, #0x32ef0a4
032ef090: 880240f9 ldr      x8, [x20]
032ef094: e00316aa mov      x0, x22
032ef098: 012140f9 ldr      x1, [x8, #0x40]
032ef09c: db087397 bl       #0xfb1408 ; 
032ef0a0: 001500b4 cbz      x0, #0x32ef340
032ef0a4: 881a40b9 ldr      w8, [x20, #0x18]
032ef0a8: 1f0d0071 cmp      w8, #3
032ef0ac: 89140054 b.ls     #0x32ef33c
032ef0b0: e00314aa mov      x0, x20
032ef0b4: 168c03f8 str      x22, [x0, #0x38]!
032ef0b8: e10316aa mov      x1, x22
032ef0bc: 7c087397 bl       #0xfb12ac ; 
032ef0c0: e85340b9 ldr      w8, [sp, #0x50]
032ef0c4: e00240f9 ldr      x0, [x23]
032ef0c8: e1430091 add      x1, sp, #0x10
032ef0cc: e81300b9 str      w8, [sp, #0x10]
032ef0d0: cf087397 bl       #0xfb140c ; 
032ef0d4: f60300aa mov      x22, x0
032ef0d8: c00000b4 cbz      x0, #0x32ef0f0
032ef0dc: 880240f9 ldr      x8, [x20]
032ef0e0: e00316aa mov      x0, x22
032ef0e4: 012140f9 ldr      x1, [x8, #0x40]
032ef0e8: c8087397 bl       #0xfb1408 ; 
032ef0ec: a01200b4 cbz      x0, #0x32ef340
032ef0f0: 881a40b9 ldr      w8, [x20, #0x18]
032ef0f4: 1f110071 cmp      w8, #4
032ef0f8: 29120054 b.ls     #0x32ef33c
032ef0fc: e00314aa mov      x0, x20
032ef100: 160c04f8 str      x22, [x0, #0x40]!
032ef104: e10316aa mov      x1, x22
032ef108: 69087397 bl       #0xfb12ac ; 
032ef10c: e84740b9 ldr      w8, [sp, #0x44]
032ef110: e00240f9 ldr      x0, [x23]
032ef114: e1330091 add      x1, sp, #0xc
032ef118: e80f00b9 str      w8, [sp, #0xc]
032ef11c: bc087397 bl       #0xfb140c ; 
032ef120: f60300aa mov      x22, x0
032ef124: c00000b4 cbz      x0, #0x32ef13c
032ef128: 880240f9 ldr      x8, [x20]
032ef12c: e00316aa mov      x0, x22
032ef130: 012140f9 ldr      x1, [x8, #0x40]
032ef134: b5087397 bl       #0xfb1408 ; 
032ef138: 401000b4 cbz      x0, #0x32ef340
032ef13c: 881a40b9 ldr      w8, [x20, #0x18]
032ef140: 1f150071 cmp      w8, #5
032ef144: c90f0054 b.ls     #0x32ef33c
032ef148: e00314aa mov      x0, x20
032ef14c: 168c04f8 str      x22, [x0, #0x48]!
032ef150: e10316aa mov      x1, x22
032ef154: 56087397 bl       #0xfb12ac ; 
032ef158: a80240f9 ldr      x8, [x21]
032ef15c: 880f00b4 cbz      x8, #0x32ef34c
032ef160: 081140b9 ldr      w8, [x8, #0x10]
032ef164: e00240f9 ldr      x0, [x23]
032ef168: e1230091 add      x1, sp, #8
032ef16c: e80b00b9 str      w8, [sp, #8]
032ef170: a7087397 bl       #0xfb140c ; 
032ef174: f50300aa mov      x21, x0
032ef178: c00000b4 cbz      x0, #0x32ef190
032ef17c: 880240f9 ldr      x8, [x20]
032ef180: e00315aa mov      x0, x21
032ef184: 012140f9 ldr      x1, [x8, #0x40]
032ef188: a0087397 bl       #0xfb1408 ; 
032ef18c: a00d00b4 cbz      x0, #0x32ef340
032ef190: 881a40b9 ldr      w8, [x20, #0x18]
032ef194: 1f190071 cmp      w8, #6
032ef198: 290d0054 b.ls     #0x32ef33c
032ef19c: 96f800b0 adrp     x22, #0x5200000
032ef1a0: d67640f9 ldr      x22, [x22, #0xe8]
032ef1a4: e00314aa mov      x0, x20
032ef1a8: 150c05f8 str      x21, [x0, #0x50]!
032ef1ac: e10315aa mov      x1, x21
032ef1b0: 3f087397 bl       #0xfb12ac ; 
032ef1b4: 683a40f9 ldr      x8, [x19, #0x70]
032ef1b8: c00240f9 ldr      x0, [x22]
032ef1bc: e1030091 mov      x1, sp
032ef1c0: e80300f9 str      x8, [sp]
032ef1c4: 92087397 bl       #0xfb140c ; 
032ef1c8: f50300aa mov      x21, x0
032ef1cc: c00000b4 cbz      x0, #0x32ef1e4
032ef1d0: 880240f9 ldr      x8, [x20]
032ef1d4: e00315aa mov      x0, x21
032ef1d8: 012140f9 ldr      x1, [x8, #0x40]
032ef1dc: 8b087397 bl       #0xfb1408 ; 
032ef1e0: 000b00b4 cbz      x0, #0x32ef340
032ef1e4: 881a40b9 ldr      w8, [x20, #0x18]
032ef1e8: 1f1d0071 cmp      w8, #7
032ef1ec: 890a0054 b.ls     #0x32ef33c
032ef1f0: 16f500d0 adrp     x22, #0x5191000
032ef1f4: d61a40f9 ldr      x22, [x22, #0x30]
032ef1f8: e00314aa mov      x0, x20
032ef1fc: 158c05f8 str      x21, [x0, #0x58]!
032ef200: e10315aa mov      x1, x21
032ef204: 2a087397 bl       #0xfb12ac ; 
032ef208: c20240f9 ldr      x2, [x22]
032ef20c: 01038052 mov      w1, #0x18
032ef210: e00313aa mov      x0, x19
032ef214: e30314aa mov      x3, x20
032ef218: e4031faa mov      x4, xzr
032ef21c: c145d497 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
032ef220: f37b49a9 ldp      x19, x30, [sp, #0x90]
032ef224: f55348a9 ldp      x21, x20, [sp, #0x80]
032ef228: f75b47a9 ldp      x23, x22, [sp, #0x70]
032ef22c: f83340f9 ldr      x24, [sp, #0x60]
032ef230: ff830291 add      sp, sp, #0xa0
032ef234: c0035fd6 ret      
032ef238: 7c087397 bl       #0xfb1428 ; 
032ef23c: 7b087397 bl       #0xfb1428 ; 
032ef240: 7c087397 bl       #0xfb1430 ; 
032ef244: 7b087397 bl       #0xfb1430 ; 
032ef248: 0b000014 b        #0x32ef274 ; 
032ef24c: 0a000014 b        #0x32ef274 ; 
032ef250: 09000014 b        #0x32ef274 ; 
032ef254: 08000014 b        #0x32ef274 ; 
032ef258: 07000014 b        #0x32ef274 ; 
032ef25c: 06000014 b        #0x32ef274 ; 
032ef260: 05000014 b        #0x32ef274 ; 
032ef264: 04000014 b        #0x32ef274 ; 
032ef268: 03000014 b        #0x32ef274 ; 
032ef26c: 02000014 b        #0x32ef274 ; 
032ef270: 01000014 b        #0x32ef274 ; 
032ef274: f40300aa mov      x20, x0
032ef278: 3f040071 cmp      w1, #1
032ef27c: e1070054 b.ne     #0x32ef378
032ef280: e00314aa mov      x0, x20
032ef284: d3506797 bl       #0xcc35d0 ; 
032ef288: f40300aa mov      x20, x0
032ef28c: 20f900f0 adrp     x0, #0x5216000
032ef290: 001c44f9 ldr      x0, [x0, #0x838]
032ef294: 20087397 bl       #0xfb1314 ; 
032ef298: 880240f9 ldr      x8, [x20]
032ef29c: 010140f9 ldr      x1, [x8]
032ef2a0: 62097397 bl       #0xfb1828 ; 
032ef2a4: 60050036 tbz      w0, #0, #0x32ef350
032ef2a8: 950240f9 ldr      x21, [x20]
032ef2ac: 454f6797 bl       #0xcc2fc0 ; 
032ef2b0: 00fa00d0 adrp     x0, #0x5231000
032ef2b4: 003841f9 ldr      x0, [x0, #0x270]
032ef2b8: 17087397 bl       #0xfb1314 ; 
032ef2bc: 21008052 mov      w1, #1
032ef2c0: 2c087397 bl       #0xfb1370 ; 
032ef2c4: 550400b4 cbz      x21, #0x32ef34c
032ef2c8: a80240f9 ldr      x8, [x21]
032ef2cc: f40300aa mov      x20, x0
032ef2d0: e00315aa mov      x0, x21
032ef2d4: 098558a9 ldp      x9, x1, [x8, #0x188]
032ef2d8: 20013fd6 blr      x9
032ef2dc: 940300b4 cbz      x20, #0x32ef34c
032ef2e0: f50300aa mov      x21, x0
032ef2e4: c00000b4 cbz      x0, #0x32ef2fc
032ef2e8: 880240f9 ldr      x8, [x20]
032ef2ec: e00315aa mov      x0, x21
032ef2f0: 012140f9 ldr      x1, [x8, #0x40]
032ef2f4: 45087397 bl       #0xfb1408 ; 
032ef2f8: 400200b4 cbz      x0, #0x32ef340
032ef2fc: 881a40b9 ldr      w8, [x20, #0x18]
032ef300: e8010034 cbz      w8, #0x32ef33c
032ef304: e00314aa mov      x0, x20
032ef308: 150c02f8 str      x21, [x0, #0x20]!
032ef30c: e10315aa mov      x1, x21
032ef310: e7077397 bl       #0xfb12ac ; 
032ef314: a0f500d0 adrp     x0, #0x51a5000
032ef318: 005842f9 ldr      x0, [x0, #0x4b0]
032ef31c: fe077397 bl       #0xfb1314 ; 
032ef320: e20300aa mov      x2, x0
032ef324: 01038052 mov      w1, #0x18
032ef328: e00313aa mov      x0, x19
032ef32c: e30314aa mov      x3, x20
032ef330: e4031faa mov      x4, xzr
032ef334: 7b45d497 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
032ef338: dbfeff17 b        #0x32eeea4 ; 
032ef33c: 3d087397 bl       #0xfb1430 ; 
032ef340: 43087397 bl       #0xfb144c ; 
032ef344: e1031faa mov      x1, xzr
032ef348: 2a087397 bl       #0xfb13f0 ; 
032ef34c: 37087397 bl       #0xfb1428 ; 
032ef350: 00018052 mov      w0, #8
032ef354: 1b4e6797 bl       #0xcc2bc0 ; 
032ef358: 880240f9 ldr      x8, [x20]
032ef35c: 080000f9 str      x8, [x0]
032ef360: c1e40090 adrp     x1, #0x4f87000
032ef364: 21603f91 add      x1, x1, #0xfd8
032ef368: e2031faa mov      x2, xzr
032ef36c: cd4b6797 bl       #0xcc22a0 ; 
032ef370: f40300aa mov      x20, x0
032ef374: 134f6797 bl       #0xcc2fc0 ; 
032ef378: e00314aa mov      x0, x20
032ef37c: e14e6797 bl       #0xcc2f00 ; 
032ef380: f2646797 bl       #0xcc8748 ; 
