# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$.ctor
# Linear metadata span, not a recovered full CFG.
02a3171c: f553bea9 stp      x21, x20, [sp, #-0x20]!
02a31720: f37b01a9 stp      x19, x30, [sp, #0x10]
02a31724: 945a0190 adrp     x20, #0x5581000
02a31728: 953c01d0 adrp     x21, #0x51c3000
02a3172c: 88d27a39 ldrb     w8, [x20, #0xeb4]
02a31730: b5da44f9 ldr      x21, [x21, #0x9b0]
02a31734: f30300aa mov      x19, x0
02a31738: 28010037 tbnz     w8, #0, #0x2a3175c
02a3173c: c03c0190 adrp     x0, #0x51c9000
02a31740: 00c842f9 ldr      x0, [x0, #0x590]
02a31744: effe9597 bl       #0xfb1300 ; 
02a31748: 803c01d0 adrp     x0, #0x51c3000
02a3174c: 00d844f9 ldr      x0, [x0, #0x9b0]
02a31750: ecfe9597 bl       #0xfb1300 ; 
02a31754: 28008052 mov      w8, #1
02a31758: 88d23a39 strb     w8, [x20, #0xeb4]
02a3175c: a00240f9 ldr      x0, [x21]
02a31760: 2eff9597 bl       #0xfb1418 ; 
02a31764: 000200b4 cbz      x0, #0x2a317a4
02a31768: c83c0190 adrp     x8, #0x51c9000
02a3176c: 08c942f9 ldr      x8, [x8, #0x590]
02a31770: 017d8052 mov      w1, #0x3e8
02a31774: f40300aa mov      x20, x0
02a31778: 020140f9 ldr      x2, [x8]
02a3177c: d73d1894 bl       #0x3040ed8 ; System.Collections.Generic.List<ushort>$$.ctor
02a31780: e00313aa mov      x0, x19
02a31784: 140c01f8 str      x20, [x0, #0x10]!
02a31788: e10314aa mov      x1, x20
02a3178c: c8fe9597 bl       #0xfb12ac ; 
02a31790: e00313aa mov      x0, x19
02a31794: f37b41a9 ldp      x19, x30, [sp, #0x10]
02a31798: e1031faa mov      x1, xzr
02a3179c: f553c2a8 ldp      x21, x20, [sp], #0x20
02a317a0: 9507e117 b        #0x22735f4 ; System.Object$$.ctor
02a317a4: 21ff9597 bl       #0xfb1428 ; 
