# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleCells
# Linear metadata span, not a recovered full CFG.
02a3103c: fc0f1af8 str      x28, [sp, #-0x60]!
02a31040: fb6b01a9 stp      x27, x26, [sp, #0x10]
02a31044: f96302a9 stp      x25, x24, [sp, #0x20]
02a31048: f75b03a9 stp      x23, x22, [sp, #0x30]
02a3104c: f55304a9 stp      x21, x20, [sp, #0x40]
02a31050: f37b05a9 stp      x19, x30, [sp, #0x50]
02a31054: 965a0190 adrp     x22, #0x5581000
02a31058: 5b3f01d0 adrp     x27, #0x521b000
02a3105c: f40308aa mov      x20, x8
02a31060: c8b67a39 ldrb     w8, [x22, #0xead]
02a31064: 7beb42f9 ldr      x27, [x27, #0x5d0]
02a31068: f30301aa mov      x19, x1
02a3106c: f50300aa mov      x21, x0
02a31070: c8000037 tbnz     w8, #0, #0x2a31088
02a31074: 403f01d0 adrp     x0, #0x521b000
02a31078: 00e842f9 ldr      x0, [x0, #0x5d0]
02a3107c: a1009697 bl       #0xfb1300 ; 
02a31080: 28008052 mov      w8, #1
02a31084: c8b63a39 strb     w8, [x22, #0xead]
02a31088: 600340f9 ldr      x0, [x27]
02a3108c: 08e040b9 ldr      w8, [x0, #0xe0]
02a31090: 48000035 cbnz     w8, #0x2a31098
02a31094: dc009697 bl       #0xfb1404 ; 
02a31098: 760240b9 ldr      w22, [x19]
02a3109c: c8060051 sub      w8, w22, #1
02a310a0: 1f050071 cmp      w8, #1
02a310a4: eb040054 b.lt     #0x2a31140
02a310a8: 3c008052 mov      w28, #1
02a310ac: a01a40f9 ldr      x0, [x21, #0x30]
02a310b0: c00500b4 cbz      x0, #0x2a31168
02a310b4: 080040f9 ldr      x8, [x0]
02a310b8: 97070051 sub      w23, w28, #1
02a310bc: e103172a mov      w1, w23
02a310c0: e203162a mov      w2, w22
02a310c4: 098d59a9 ldp      x9, x3, [x8, #0x198]
02a310c8: 20013fd6 blr      x9
02a310cc: 680340f9 ldr      x8, [x27]
02a310d0: f803002a mov      w24, w0
02a310d4: 09e140b9 ldr      w9, [x8, #0xe0]
02a310d8: 69000035 cbnz     w9, #0x2a310e4
02a310dc: e00308aa mov      x0, x8
02a310e0: c9009697 bl       #0xfb1404 ; 
02a310e4: e00313aa mov      x0, x19
02a310e8: e103182a mov      w1, w24
02a310ec: e2031faa mov      x2, xzr
02a310f0: f719a597 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
02a310f4: f90300aa mov      x25, x0
02a310f8: e00313aa mov      x0, x19
02a310fc: e103172a mov      w1, w23
02a31100: e2031faa mov      x2, xzr
02a31104: f219a597 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
02a31108: fa0300aa mov      x26, x0
02a3110c: e00313aa mov      x0, x19
02a31110: e103172a mov      w1, w23
02a31114: e20319aa mov      x2, x25
02a31118: e3031faa mov      x3, xzr
02a3111c: 5b1aa597 bl       #0x1377a88 ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$set_Item
02a31120: e00313aa mov      x0, x19
02a31124: e103182a mov      w1, w24
02a31128: e2031aaa mov      x2, x26
02a3112c: e3031faa mov      x3, xzr
02a31130: 561aa597 bl       #0x1377a88 ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$set_Item
02a31134: 9c070011 add      w28, w28, #1
02a31138: df021c6b cmp      w22, w28
02a3113c: 81fbff54 b.ne     #0x2a310ac
02a31140: e00314aa mov      x0, x20
02a31144: e10313aa mov      x1, x19
02a31148: f37b45a9 ldp      x19, x30, [sp, #0x50]
02a3114c: f55344a9 ldp      x21, x20, [sp, #0x40]
02a31150: f75b43a9 ldp      x23, x22, [sp, #0x30]
02a31154: f96342a9 ldp      x25, x24, [sp, #0x20]
02a31158: fb6b41a9 ldp      x27, x26, [sp, #0x10]
02a3115c: 020f8052 mov      w2, #0x78
02a31160: fc0746f8 ldr      x28, [sp], #0x60
02a31164: 1b438a17 b        #0xcc1dd0 ; 
02a31168: b0009697 bl       #0xfb1428 ; 
