# Royal.Player.Context.Units.LevelEpisodeHelper$$SetEpisodeId
# Linear metadata span, not a recovered full CFG.
02059a88: f553bea9 stp      x21, x20, [sp, #-0x20]!
02059a8c: f37b01a9 stp      x19, x30, [sp, #0x10]
02059a90: 35a90190 adrp     x21, #0x557d000
02059a94: a81e4839 ldrb     w8, [x21, #0x207]
02059a98: f303012a mov      w19, w1
02059a9c: f40300aa mov      x20, x0
02059aa0: c8000037 tbnz     w8, #0, #0x2059ab8
02059aa4: c08c01b0 adrp     x0, #0x51f2000
02059aa8: 003444f9 ldr      x0, [x0, #0x868]
02059aac: 155ebd97 bl       #0xfb1300 ; 
02059ab0: 28008052 mov      w8, #1
02059ab4: a81e0839 strb     w8, [x21, #0x207]
02059ab8: 940a40f9 ldr      x20, [x20, #0x10]
02059abc: 940300b4 cbz      x20, #0x2059b2c
02059ac0: ca8c01b0 adrp     x10, #0x51f2000
02059ac4: 880240f9 ldr      x8, [x20]
02059ac8: 4a3544f9 ldr      x10, [x10, #0x868]
02059acc: 09554279 ldrh     w9, [x8, #0x12a]
02059ad0: 410140f9 ldr      x1, [x10]
02059ad4: 290100b4 cbz      x9, #0x2059af8
02059ad8: 0a5940f9 ldr      x10, [x8, #0xb0]
02059adc: 4a210091 add      x10, x10, #8
02059ae0: 4b815ff8 ldur     x11, [x10, #-8]
02059ae4: 7f0101eb cmp      x11, x1
02059ae8: 00010054 b.eq     #0x2059b08
02059aec: 290500f1 subs     x9, x9, #1
02059af0: 4a410091 add      x10, x10, #0x10
02059af4: 61ffff54 b.ne     #0x2059ae0
02059af8: e00314aa mov      x0, x20
02059afc: e2031f2a mov      w2, wzr
02059b00: f59dbc97 bl       #0xf812d4 ; 
02059b04: 04000014 b        #0x2059b14 ; 
02059b08: 490180b9 ldrsw    x9, [x10]
02059b0c: 0811098b add      x8, x8, x9, lsl #4
02059b10: 00e10491 add      x0, x8, #0x138
02059b14: 030840a9 ldp      x3, x2, [x0]
02059b18: e103132a mov      w1, w19
02059b1c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059b20: e00314aa mov      x0, x20
02059b24: f553c2a8 ldp      x21, x20, [sp], #0x20
02059b28: 60001fd6 br       x3
02059b2c: 3f5ebd97 bl       #0xfb1428 ; 
