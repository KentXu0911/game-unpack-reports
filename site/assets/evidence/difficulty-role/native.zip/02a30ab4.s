# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$get_DeviceIdKey
# Linear metadata span, not a recovered full CFG.
02a30ab4: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
02a30ab8: f30300aa mov      x19, x0
02a30abc: 002c40b9 ldr      w0, [x0, #0x2c]
02a30ac0: 60000035 cbnz     w0, #0x2a30acc
02a30ac4: 05000094 bl       #0x2a30ad8 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDeviceIdKey
02a30ac8: 602e00b9 str      w0, [x19, #0x2c]
02a30acc: 007c4093 sxtw     x0, w0
02a30ad0: f37bc1a8 ldp      x19, x30, [sp], #0x10
02a30ad4: c0035fd6 ret      
