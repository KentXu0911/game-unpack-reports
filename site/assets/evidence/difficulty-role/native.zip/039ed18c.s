# Royal.Scenes.Home.Ui.Dialogs.InviteFriends.Scripts.InviteFriendsConfigHelper$$LoadDefaultConfig
# Linear metadata span, not a recovered full CFG.
039ed18c: f60f1df8 str      x22, [sp, #-0x30]!
039ed190: f55301a9 stp      x21, x20, [sp, #0x10]
039ed194: f37b02a9 stp      x19, x30, [sp, #0x20]
039ed198: f4dc0090 adrp     x20, #0x5589000
039ed19c: 75bf00d0 adrp     x21, #0x51db000
039ed1a0: 56c200f0 adrp     x22, #0x5238000
039ed1a4: 88967b39 ldrb     w8, [x20, #0xee5]
039ed1a8: b5b245f9 ldr      x21, [x21, #0xb60]
039ed1ac: d69646f9 ldr      x22, [x22, #0xd28]
039ed1b0: f30300aa mov      x19, x0
039ed1b4: 48020037 tbnz     w8, #0, #0x39ed1fc
039ed1b8: a0c100b0 adrp     x0, #0x5222000
039ed1bc: 00ec42f9 ldr      x0, [x0, #0x5d8]
039ed1c0: 50105797 bl       #0xfb1300 ; 
039ed1c4: a0c10090 adrp     x0, #0x5221000
039ed1c8: 008846f9 ldr      x0, [x0, #0xd10]
039ed1cc: 4d105797 bl       #0xfb1300 ; 
039ed1d0: 40c200f0 adrp     x0, #0x5238000
039ed1d4: 009446f9 ldr      x0, [x0, #0xd28]
039ed1d8: 4a105797 bl       #0xfb1300 ; 
039ed1dc: c0c000b0 adrp     x0, #0x5206000
039ed1e0: 00ac43f9 ldr      x0, [x0, #0x758]
039ed1e4: 47105797 bl       #0xfb1300 ; 
039ed1e8: 60bf00d0 adrp     x0, #0x51db000
039ed1ec: 00b045f9 ldr      x0, [x0, #0xb60]
039ed1f0: 44105797 bl       #0xfb1300 ; 
039ed1f4: 28008052 mov      w8, #1
039ed1f8: 88963b39 strb     w8, [x20, #0xee5]
039ed1fc: a00240f9 ldr      x0, [x21]
039ed200: c10240f9 ldr      x1, [x22]
039ed204: b752af97 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
039ed208: e00400b4 cbz      x0, #0x39ed2a4
039ed20c: b4c10090 adrp     x20, #0x5221000
039ed210: b5c100b0 adrp     x21, #0x5222000
039ed214: 948a46f9 ldr      x20, [x20, #0xd10]
039ed218: b5ee42f9 ldr      x21, [x21, #0x5d8]
039ed21c: e1031faa mov      x1, xzr
039ed220: dc5a0c94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
039ed224: 810240f9 ldr      x1, [x20]
039ed228: 603cad97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
039ed22c: e10300aa mov      x1, x0
039ed230: e00313aa mov      x0, x19
039ed234: 018c01f8 str      x1, [x0, #0x18]!
039ed238: 1d105797 bl       #0xfb12ac ; 
039ed23c: b40240f9 ldr      x20, [x21]
039ed240: 881e40f9 ldr      x8, [x20, #0x38]
039ed244: 000140f9 ldr      x0, [x8]
039ed248: 08c84439 ldrb     w8, [x0, #0x132]
039ed24c: 48000037 tbnz     w8, #0, #0x39ed254
039ed250: 654f5697 bl       #0xf80fe4 ; 
039ed254: 08e040b9 ldr      w8, [x0, #0xe0]
039ed258: 48000035 cbnz     w8, #0x39ed260
039ed25c: 6a105797 bl       #0xfb1404 ; 
039ed260: 881e40f9 ldr      x8, [x20, #0x38]
039ed264: d4c000b0 adrp     x20, #0x5206000
039ed268: 000140f9 ldr      x0, [x8]
039ed26c: 08c84439 ldrb     w8, [x0, #0x132]
039ed270: 94ae43f9 ldr      x20, [x20, #0x758]
039ed274: 48000037 tbnz     w8, #0, #0x39ed27c
039ed278: 5b4f5697 bl       #0xf80fe4 ; 
039ed27c: 085c40f9 ldr      x8, [x0, #0xb8]
039ed280: 820240f9 ldr      x2, [x20]
039ed284: e00313aa mov      x0, x19
039ed288: f37b42a9 ldp      x19, x30, [sp, #0x20]
039ed28c: 030140f9 ldr      x3, [x8]
039ed290: f55341a9 ldp      x21, x20, [sp, #0x10]
039ed294: e10b8052 mov      w1, #0x5f
039ed298: e4031faa mov      x4, xzr
039ed29c: f60743f8 ldr      x22, [sp], #0x30
039ed2a0: a04db817 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
039ed2a4: 61105797 bl       #0xfb1428 ; 
