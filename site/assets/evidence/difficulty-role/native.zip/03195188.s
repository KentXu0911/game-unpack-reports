# Royal.Player.Context.Units.PinataPartyManager$$MigrateConfigForOldCardCollection
# Linear metadata span, not a recovered full CFG.
03195188: f963bca9 stp      x25, x24, [sp, #-0x40]!
0319518c: f75b01a9 stp      x23, x22, [sp, #0x10]
03195190: f55302a9 stp      x21, x20, [sp, #0x20]
03195194: f37b03a9 stp      x19, x30, [sp, #0x30]
03195198: 941f0190 adrp     x20, #0x5585000
0319519c: b50401b0 adrp     x21, #0x522a000
031951a0: 160501f0 adrp     x22, #0x5238000
031951a4: 88be6839 ldrb     w8, [x20, #0xa2f]
031951a8: b58642f9 ldr      x21, [x21, #0x508]
031951ac: d69646f9 ldr      x22, [x22, #0xd28]
031951b0: f30300aa mov      x19, x0
031951b4: e8010037 tbnz     w8, #0, #0x31951f0
031951b8: e0040190 adrp     x0, #0x5231000
031951bc: 00a841f9 ldr      x0, [x0, #0x350]
031951c0: 50707897 bl       #0xfb1300 ; 
031951c4: 000501f0 adrp     x0, #0x5238000
031951c8: 009446f9 ldr      x0, [x0, #0xd28]
031951cc: 4d707897 bl       #0xfb1300 ; 
031951d0: 200201f0 adrp     x0, #0x51dc000
031951d4: 002440f9 ldr      x0, [x0, #0x48]
031951d8: 4a707897 bl       #0xfb1300 ; 
031951dc: a00401b0 adrp     x0, #0x522a000
031951e0: 008442f9 ldr      x0, [x0, #0x508]
031951e4: 47707897 bl       #0xfb1300 ; 
031951e8: 28008052 mov      w8, #1
031951ec: 88be2839 strb     w8, [x20, #0xa2f]
031951f0: a00240f9 ldr      x0, [x21]
031951f4: c10240f9 ldr      x1, [x22]
031951f8: bab2d097 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
031951fc: 200600b4 cbz      x0, #0x31952c0
03195200: f4040190 adrp     x20, #0x5231000
03195204: 94aa41f9 ldr      x20, [x20, #0x350]
03195208: e1031faa mov      x1, xzr
0319520c: f50300aa mov      x21, x0
03195210: e0ba2d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03195214: 810240f9 ldr      x1, [x20]
03195218: 649cce97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0319521c: f60313aa mov      x22, x19
03195220: c80e45f8 ldr      x8, [x22, #0x50]!
03195224: e80400b4 cbz      x8, #0x31952c0
03195228: 390201f0 adrp     x25, #0x51dc000
0319522c: 18c14039 ldrb     w24, [x8, #0x30]
03195230: 688e45f8 ldr      x8, [x19, #0x58]!
03195234: 392740f9 ldr      x25, [x25, #0x48]
03195238: f40300aa mov      x20, x0
0319523c: 680000b4 cbz      x8, #0x3195248
03195240: 17c14039 ldrb     w23, [x8, #0x30]
03195244: 02000014 b        #0x319524c ; 
03195248: f7031f2a mov      w23, wzr
0319524c: e00315aa mov      x0, x21
03195250: e1031faa mov      x1, xzr
03195254: cfba2d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03195258: 280340f9 ldr      x8, [x25]
0319525c: e10300aa mov      x1, x0
03195260: e2031faa mov      x2, xzr
03195264: e00308aa mov      x0, x8
03195268: 082bf397 bl       #0x2e5fe88 ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$SetString
0319526c: e00316aa mov      x0, x22
03195270: e10314aa mov      x1, x20
03195274: d40200f9 str      x20, [x22]
03195278: 0d707897 bl       #0xfb12ac ; 
0319527c: c80240f9 ldr      x8, [x22]
03195280: 080200b4 cbz      x8, #0x31952c0
03195284: 18c10039 strb     w24, [x8, #0x30]
03195288: 680240f9 ldr      x8, [x19]
0319528c: 080100b4 cbz      x8, #0x31952ac
03195290: e00313aa mov      x0, x19
03195294: e10314aa mov      x1, x20
03195298: 740200f9 str      x20, [x19]
0319529c: 04707897 bl       #0xfb12ac ; 
031952a0: 680240f9 ldr      x8, [x19]
031952a4: e80000b4 cbz      x8, #0x31952c0
031952a8: 17c10039 strb     w23, [x8, #0x30]
031952ac: f37b43a9 ldp      x19, x30, [sp, #0x30]
031952b0: f55342a9 ldp      x21, x20, [sp, #0x20]
031952b4: f75b41a9 ldp      x23, x22, [sp, #0x10]
031952b8: f963c4a8 ldp      x25, x24, [sp], #0x40
031952bc: c0035fd6 ret      
031952c0: 5a707897 bl       #0xfb1428 ; 
