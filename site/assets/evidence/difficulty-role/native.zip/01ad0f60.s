# UnityEngine.TextCore.Text.UnicodeLineBreakingRules$$GetCharacters
# Linear metadata span, not a recovered full CFG.
01ad0f60: f60f1df8 str      x22, [sp, #-0x30]!
01ad0f64: f55301a9 stp      x21, x20, [sp, #0x10]
01ad0f68: f37b02a9 stp      x19, x30, [sp, #0x20]
01ad0f6c: 53d501d0 adrp     x19, #0x557a000
01ad0f70: 95ba0190 adrp     x21, #0x5220000
01ad0f74: 685a7a39 ldrb     w8, [x19, #0xe96]
01ad0f78: b53241f9 ldr      x21, [x21, #0x260]
01ad0f7c: f40300aa mov      x20, x0
01ad0f80: 88010037 tbnz     w8, #0, #0x1ad0fb0
01ad0f84: 60bb01b0 adrp     x0, #0x523d000
01ad0f88: 00ac46f9 ldr      x0, [x0, #0xd58]
01ad0f8c: dd80d397 bl       #0xfb1300 ; 
01ad0f90: e0b901d0 adrp     x0, #0x520e000
01ad0f94: 00a847f9 ldr      x0, [x0, #0xf50]
01ad0f98: da80d397 bl       #0xfb1300 ; 
01ad0f9c: 80ba0190 adrp     x0, #0x5220000
01ad0fa0: 003041f9 ldr      x0, [x0, #0x260]
01ad0fa4: d780d397 bl       #0xfb1300 ; 
01ad0fa8: 28008052 mov      w8, #1
01ad0fac: 685a3a39 strb     w8, [x19, #0xe96]
01ad0fb0: a00240f9 ldr      x0, [x21]
01ad0fb4: 1981d397 bl       #0xfb1418 ; 
01ad0fb8: 600400b4 cbz      x0, #0x1ad1044
01ad0fbc: e8b901d0 adrp     x8, #0x520e000
01ad0fc0: 08a947f9 ldr      x8, [x8, #0xf50]
01ad0fc4: f30300aa mov      x19, x0
01ad0fc8: 010140f9 ldr      x1, [x8]
01ad0fcc: 8b652294 bl       #0x236a5f8 ; System.Collections.Generic.HashSet<uint>$$.ctor
01ad0fd0: b40300b4 cbz      x20, #0x1ad1044
01ad0fd4: e00314aa mov      x0, x20
01ad0fd8: e1031faa mov      x1, xzr
01ad0fdc: 6dcb8894 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01ad0fe0: 200300b4 cbz      x0, #0x1ad1044
01ad0fe4: 081040b9 ldr      w8, [x0, #0x10]
01ad0fe8: f40300aa mov      x20, x0
01ad0fec: 1f050071 cmp      w8, #1
01ad0ff0: 0b020054 b.lt     #0x1ad1030
01ad0ff4: 76bb01b0 adrp     x22, #0x523d000
01ad0ff8: d6ae46f9 ldr      x22, [x22, #0xd58]
01ad0ffc: f5031f2a mov      w21, wzr
01ad1000: e00314aa mov      x0, x20
01ad1004: e103152a mov      w1, w21
01ad1008: e2031faa mov      x2, xzr
01ad100c: b6c30894 bl       #0x1d01ee4 ; System.String$$get_Chars
01ad1010: c20240f9 ldr      x2, [x22]
01ad1014: 013c0012 and      w1, w0, #0xffff
01ad1018: e00313aa mov      x0, x19
01ad101c: 2d6a2294 bl       #0x236b8d0 ; System.Collections.Generic.HashSet<uint>$$Add
01ad1020: 881240b9 ldr      w8, [x20, #0x10]
01ad1024: b5060011 add      w21, w21, #1
01ad1028: bf02086b cmp      w21, w8
01ad102c: abfeff54 b.lt     #0x1ad1000
01ad1030: e00313aa mov      x0, x19
01ad1034: f37b42a9 ldp      x19, x30, [sp, #0x20]
01ad1038: f55341a9 ldp      x21, x20, [sp, #0x10]
01ad103c: f60743f8 ldr      x22, [sp], #0x30
01ad1040: c0035fd6 ret      
01ad1044: f980d397 bl       #0xfb1428 ; 
