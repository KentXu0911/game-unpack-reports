# Royal.Player.Context.Units.LadderOfferManager$$UpdateConfig
# Linear metadata span, not a recovered full CFG.
01dc0d84: ff8301d1 sub      sp, sp, #0x60
01dc0d88: fb6b01a9 stp      x27, x26, [sp, #0x10]
01dc0d8c: f96302a9 stp      x25, x24, [sp, #0x20]
01dc0d90: f75b03a9 stp      x23, x22, [sp, #0x30]
01dc0d94: f55304a9 stp      x21, x20, [sp, #0x40]
01dc0d98: f37b05a9 stp      x19, x30, [sp, #0x50]
01dc0d9c: d6bd01f0 adrp     x22, #0x557b000
01dc0da0: c84e7f39 ldrb     w8, [x22, #0xfd3]
01dc0da4: f40302aa mov      x20, x2
01dc0da8: f503012a mov      w21, w1
01dc0dac: f30300aa mov      x19, x0
01dc0db0: 28040037 tbnz     w8, #0, #0x1dc0e34
01dc0db4: 80a301f0 adrp     x0, #0x5233000
01dc0db8: 008c40f9 ldr      x0, [x0, #0x118]
01dc0dbc: 51c1c797 bl       #0xfb1300 ; 
01dc0dc0: 80a301b0 adrp     x0, #0x5231000
01dc0dc4: 003841f9 ldr      x0, [x0, #0x270]
01dc0dc8: 4ec1c797 bl       #0xfb1300 ; 
01dc0dcc: c0a30190 adrp     x0, #0x5238000
01dc0dd0: 009446f9 ldr      x0, [x0, #0xd28]
01dc0dd4: 4bc1c797 bl       #0xfb1300 ; 
01dc0dd8: a09e01d0 adrp     x0, #0x5196000
01dc0ddc: 000c43f9 ldr      x0, [x0, #0x618]
01dc0de0: 48c1c797 bl       #0xfb1300 ; 
01dc0de4: 809f01f0 adrp     x0, #0x51b3000
01dc0de8: 00a041f9 ldr      x0, [x0, #0x340]
01dc0dec: 45c1c797 bl       #0xfb1300 ; 
01dc0df0: a0a30190 adrp     x0, #0x5234000
01dc0df4: 008c40f9 ldr      x0, [x0, #0x118]
01dc0df8: 42c1c797 bl       #0xfb1300 ; 
01dc0dfc: e0a001d0 adrp     x0, #0x51de000
01dc0e00: 00c440f9 ldr      x0, [x0, #0x188]
01dc0e04: 3fc1c797 bl       #0xfb1300 ; 
01dc0e08: c09f01f0 adrp     x0, #0x51bb000
01dc0e0c: 00b841f9 ldr      x0, [x0, #0x370]
01dc0e10: 3cc1c797 bl       #0xfb1300 ; 
01dc0e14: c09e01f0 adrp     x0, #0x519b000
01dc0e18: 009c40f9 ldr      x0, [x0, #0x138]
01dc0e1c: 39c1c797 bl       #0xfb1300 ; 
01dc0e20: a0a301b0 adrp     x0, #0x5235000
01dc0e24: 002040f9 ldr      x0, [x0, #0x40]
01dc0e28: 36c1c797 bl       #0xfb1300 ; 
01dc0e2c: 28008052 mov      w8, #1
01dc0e30: c84e3f39 strb     w8, [x22, #0xfd3]
01dc0e34: b9bd01d0 adrp     x25, #0x5576000
01dc0e38: 28af7c39 ldrb     w8, [x25, #0xf2b]
01dc0e3c: ff0f00b9 str      wzr, [sp, #0xc]
01dc0e40: c8000035 cbnz     w8, #0x1dc0e58
01dc0e44: 40a20190 adrp     x0, #0x5208000
01dc0e48: 00c041f9 ldr      x0, [x0, #0x380]
01dc0e4c: 2dc1c797 bl       #0xfb1300 ; 
01dc0e50: 28008052 mov      w8, #1
01dc0e54: 28af3c39 strb     w8, [x25, #0xf2b]
01dc0e58: 5aa20190 adrp     x26, #0x5208000
01dc0e5c: 5ac341f9 ldr      x26, [x26, #0x380]
01dc0e60: 480340f9 ldr      x8, [x26]
01dc0e64: 085d40f9 ldr      x8, [x8, #0xb8]
01dc0e68: 080140f9 ldr      x8, [x8]
01dc0e6c: 681d00b4 cbz      x8, #0x1dc1218
01dc0e70: 001140f9 ldr      x0, [x8, #0x20]
01dc0e74: 401d00b4 cbz      x0, #0x1dc121c
01dc0e78: 21028052 mov      w1, #0x11
01dc0e7c: 82028052 mov      w2, #0x14
01dc0e80: e3031faa mov      x3, xzr
01dc0e84: a1393194 bl       #0x2a0f508 ; Royal.Player.Context.Data.Persistent.UserInventory$$GetDialogsValue
01dc0e88: f603002a mov      w22, w0
01dc0e8c: e0020034 cbz      w0, #0x1dc0ee8
01dc0e90: 28af7c39 ldrb     w8, [x25, #0xf2b]
01dc0e94: c8000035 cbnz     w8, #0x1dc0eac
01dc0e98: 40a20190 adrp     x0, #0x5208000
01dc0e9c: 00c041f9 ldr      x0, [x0, #0x380]
01dc0ea0: 18c1c797 bl       #0xfb1300 ; 
01dc0ea4: 28008052 mov      w8, #1
01dc0ea8: 28af3c39 strb     w8, [x25, #0xf2b]
01dc0eac: 480340f9 ldr      x8, [x26]
01dc0eb0: 085d40f9 ldr      x8, [x8, #0xb8]
01dc0eb4: 080140f9 ldr      x8, [x8]
01dc0eb8: 881c00b4 cbz      x8, #0x1dc1248
01dc0ebc: 001140f9 ldr      x0, [x8, #0x20]
01dc0ec0: 601c00b4 cbz      x0, #0x1dc124c
01dc0ec4: e1031faa mov      x1, xzr
01dc0ec8: f0253194 bl       #0x2a0a688 ; Royal.Player.Context.Data.Persistent.UserInventory$$GetLadderOffer
01dc0ecc: 201c00b4 cbz      x0, #0x1dc1250
01dc0ed0: 615240b9 ldr      w1, [x19, #0x50]
01dc0ed4: e2031faa mov      x2, xzr
01dc0ed8: 6aa60f94 bl       #0x21aa880 ; Royal.Player.Context.Data.Persistent.LadderOfferProgress$$IsSameEvent
01dc0edc: 60000036 tbz      w0, #0, #0x1dc0ee8
01dc0ee0: fb031f2a mov      w27, wzr
01dc0ee4: 10000014 b        #0x1dc0f24 ; 
01dc0ee8: 28af7c39 ldrb     w8, [x25, #0xf2b]
01dc0eec: c8000035 cbnz     w8, #0x1dc0f04
01dc0ef0: 40a20190 adrp     x0, #0x5208000
01dc0ef4: 00c041f9 ldr      x0, [x0, #0x380]
01dc0ef8: 02c1c797 bl       #0xfb1300 ; 
01dc0efc: 28008052 mov      w8, #1
01dc0f00: 28af3c39 strb     w8, [x25, #0xf2b]
01dc0f04: 480340f9 ldr      x8, [x26]
01dc0f08: 085d40f9 ldr      x8, [x8, #0xb8]
01dc0f0c: 080140f9 ldr      x8, [x8]
01dc0f10: 881900b4 cbz      x8, #0x1dc1240
01dc0f14: 080d40f9 ldr      x8, [x8, #0x18]
01dc0f18: 681900b4 cbz      x8, #0x1dc1244
01dc0f1c: 161d40b9 ldr      w22, [x8, #0x1c]
01dc0f20: 3b008052 mov      w27, #1
01dc0f24: 97a301f0 adrp     x23, #0x5233000
01dc0f28: f78e40f9 ldr      x23, [x23, #0x118]
01dc0f2c: f60f00b9 str      w22, [sp, #0xc]
01dc0f30: e10240f9 ldr      x1, [x23]
01dc0f34: e00314aa mov      x0, x20
01dc0f38: 1ced1d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01dc0f3c: 201700b4 cbz      x0, #0x1dc1220
01dc0f40: f60f40b9 ldr      w22, [sp, #0xc]
01dc0f44: 181440f9 ldr      x24, [x0, #0x28]
01dc0f48: df160071 cmp      w22, #5
01dc0f4c: 8d010054 b.le     #0x1dc0f7c
01dc0f50: e10318aa mov      x1, x24
01dc0f54: e203162a mov      w2, w22
01dc0f58: 72010094 bl       #0x1dc1520 ; Royal.Player.Context.Units.LadderOfferManager$$GetSegmentedLadderOfferConfigPath
01dc0f5c: c8a30190 adrp     x8, #0x5238000
01dc0f60: 089546f9 ldr      x8, [x8, #0xd28]
01dc0f64: 010140f9 ldr      x1, [x8]
01dc0f68: 5e032094 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01dc0f6c: e01800b4 cbz      x0, #0x1dc1288
01dc0f70: e1031faa mov      x1, xzr
01dc0f74: 870b7d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01dc0f78: f40300aa mov      x20, x0
01dc0f7c: e10240f9 ldr      x1, [x23]
01dc0f80: e00314aa mov      x0, x20
01dc0f84: 09ed1d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01dc0f88: e10300aa mov      x1, x0
01dc0f8c: f70313aa mov      x23, x19
01dc0f90: e10e03f8 str      x1, [x23, #0x30]!
01dc0f94: e00317aa mov      x0, x23
01dc0f98: c5c0c797 bl       #0xfb12ac ; 
01dc0f9c: d80000b4 cbz      x24, #0x1dc0fb4
01dc0fa0: e00240f9 ldr      x0, [x23]
01dc0fa4: 801500b4 cbz      x0, #0x1dc1254
01dc0fa8: 188c02f8 str      x24, [x0, #0x28]!
01dc0fac: e10318aa mov      x1, x24
01dc0fb0: bfc0c797 bl       #0xfb12ac ; 
01dc0fb4: 5b040034 cbz      w27, #0x1dc103c
01dc0fb8: 28af7c39 ldrb     w8, [x25, #0xf2b]
01dc0fbc: c8000035 cbnz     w8, #0x1dc0fd4
01dc0fc0: 40a20190 adrp     x0, #0x5208000
01dc0fc4: 00c041f9 ldr      x0, [x0, #0x380]
01dc0fc8: cec0c797 bl       #0xfb1300 ; 
01dc0fcc: 28008052 mov      w8, #1
01dc0fd0: 28af3c39 strb     w8, [x25, #0xf2b]
01dc0fd4: 480340f9 ldr      x8, [x26]
01dc0fd8: 085d40f9 ldr      x8, [x8, #0xb8]
01dc0fdc: 080140f9 ldr      x8, [x8]
01dc0fe0: c81300b4 cbz      x8, #0x1dc1258
01dc0fe4: 001140f9 ldr      x0, [x8, #0x20]
01dc0fe8: a01300b4 cbz      x0, #0x1dc125c
01dc0fec: e10f40b9 ldr      w1, [sp, #0xc]
01dc0ff0: 22028052 mov      w2, #0x11
01dc0ff4: 83028052 mov      w3, #0x14
01dc0ff8: e4031faa mov      x4, xzr
01dc0ffc: 3a393194 bl       #0x2a0f4e4 ; Royal.Player.Context.Data.Persistent.UserInventory$$SetDialogsValue
01dc1000: 889f01d0 adrp     x8, #0x51b3000
01dc1004: 08a141f9 ldr      x8, [x8, #0x340]
01dc1008: 000140f9 ldr      x0, [x8]
01dc100c: 08e040b9 ldr      w8, [x0, #0xe0]
01dc1010: 48000035 cbnz     w8, #0x1dc1018
01dc1014: fcc0c797 bl       #0xfb1404 ; 
01dc1018: a89e01b0 adrp     x8, #0x5196000
01dc101c: 080d43f9 ldr      x8, [x8, #0x618]
01dc1020: 010140f9 ldr      x1, [x8]
01dc1024: 20008052 mov      w0, #1
01dc1028: cf542a94 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
01dc102c: a01100b4 cbz      x0, #0x1dc1260
01dc1030: e1031f2a mov      w1, wzr
01dc1034: e2031faa mov      x2, xzr
01dc1038: 2b160594 bl       #0x1f068e4 ; Royal.Player.Context.Units.UserManager$$SendDataToBackend
01dc103c: e80240f9 ldr      x8, [x23]
01dc1040: 280f00b4 cbz      x8, #0x1dc1224
01dc1044: 028d4229 ldp      w2, w3, [x8, #0x14]
01dc1048: d89e01d0 adrp     x24, #0x519b000
01dc104c: 189f40f9 ldr      x24, [x24, #0x138]
01dc1050: 4900032a orr      w9, w2, w3
01dc1054: 89000035 cbnz     w9, #0x1dc1064
01dc1058: 091d40b9 ldr      w9, [x8, #0x1c]
01dc105c: 890c0034 cbz      w9, #0x1dc11ec
01dc1060: e3031f2a mov      w3, wzr
01dc1064: 000340f9 ldr      x0, [x24]
01dc1068: 041d40b9 ldr      w4, [x8, #0x1c]
01dc106c: 21008052 mov      w1, #1
01dc1070: e5031faa mov      x5, xzr
01dc1074: 6a75d297 bl       #0x125e61c ; Royal.Scenes.Home.Ui.Dialogs.Offer.Priority.PriorityDataHelper$$AddPriority
01dc1078: 9aa30190 adrp     x26, #0x5231000
01dc107c: 5a3b41f9 ldr      x26, [x26, #0x270]
01dc1080: 400340f9 ldr      x0, [x26]
01dc1084: 21008052 mov      w1, #1
01dc1088: bac0c797 bl       #0xfb1370 ; 
01dc108c: f80300aa mov      x24, x0
01dc1090: e0330091 add      x0, sp, #0xc
01dc1094: e1031faa mov      x1, xzr
01dc1098: 2d501f94 bl       #0x259514c ; System.Int32$$ToString
01dc109c: 780c00b4 cbz      x24, #0x1dc1228
01dc10a0: f90300aa mov      x25, x0
01dc10a4: c00000b4 cbz      x0, #0x1dc10bc
01dc10a8: 080340f9 ldr      x8, [x24]
01dc10ac: 012140f9 ldr      x1, [x8, #0x40]
01dc10b0: e00319aa mov      x0, x25
01dc10b4: d5c0c797 bl       #0xfb1408 ; 
01dc10b8: 600d00b4 cbz      x0, #0x1dc1264
01dc10bc: 081b40b9 ldr      w8, [x24, #0x18]
01dc10c0: 680b0034 cbz      w8, #0x1dc122c
01dc10c4: e00318aa mov      x0, x24
01dc10c8: 190c02f8 str      x25, [x0, #0x20]!
01dc10cc: e10319aa mov      x1, x25
01dc10d0: 77c0c797 bl       #0xfb12ac ; 
01dc10d4: a8a30190 adrp     x8, #0x5235000
01dc10d8: 082140f9 ldr      x8, [x8, #0x40]
01dc10dc: 020140f9 ldr      x2, [x8]
01dc10e0: 61028052 mov      w1, #0x13
01dc10e4: e00313aa mov      x0, x19
01dc10e8: e30318aa mov      x3, x24
01dc10ec: e4031faa mov      x4, xzr
01dc10f0: 0cfe2894 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01dc10f4: e00240f9 ldr      x0, [x23]
01dc10f8: c00900b4 cbz      x0, #0x1dc1230
01dc10fc: 151000b9 str      w21, [x0, #0x10]
01dc1100: e1031faa mov      x1, xzr
01dc1104: 779e4994 bl       #0x3028ae0 ; UnityEngine.JsonUtility$$ToJson
01dc1108: e10300aa mov      x1, x0
01dc110c: f7a001b0 adrp     x23, #0x51de000
01dc1110: f7c640f9 ldr      x23, [x23, #0x188]
01dc1114: e00240f9 ldr      x0, [x23]
01dc1118: e2031faa mov      x2, xzr
01dc111c: f1b54294 bl       #0x2e6e8e0 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetString
01dc1120: 400340f9 ldr      x0, [x26]
01dc1124: 41008052 mov      w1, #2
01dc1128: 92c0c797 bl       #0xfb1370 ; 
01dc112c: 88a301f0 adrp     x8, #0x5234000
01dc1130: 088d40f9 ldr      x8, [x8, #0x118]
01dc1134: df160071 cmp      w22, #5
01dc1138: f50300aa mov      x21, x0
01dc113c: 08c1979a csel     x8, x8, x23, gt
01dc1140: a00700b4 cbz      x0, #0x1dc1234
01dc1144: c99f01d0 adrp     x9, #0x51bb000
01dc1148: 29b941f9 ldr      x9, [x9, #0x370]
01dc114c: 170140f9 ldr      x23, [x8]
01dc1150: 360140f9 ldr      x22, [x9]
01dc1154: d70000b4 cbz      x23, #0x1dc116c
01dc1158: a80240f9 ldr      x8, [x21]
01dc115c: 012140f9 ldr      x1, [x8, #0x40]
01dc1160: e00317aa mov      x0, x23
01dc1164: a9c0c797 bl       #0xfb1408 ; 
01dc1168: 400800b4 cbz      x0, #0x1dc1270
01dc116c: a81a40b9 ldr      w8, [x21, #0x18]
01dc1170: 48060034 cbz      w8, #0x1dc1238
01dc1174: e00315aa mov      x0, x21
01dc1178: 170c02f8 str      x23, [x0, #0x20]!
01dc117c: e10317aa mov      x1, x23
01dc1180: 4bc0c797 bl       #0xfb12ac ; 
01dc1184: d40000b4 cbz      x20, #0x1dc119c
01dc1188: a80240f9 ldr      x8, [x21]
01dc118c: 012140f9 ldr      x1, [x8, #0x40]
01dc1190: e00314aa mov      x0, x20
01dc1194: 9dc0c797 bl       #0xfb1408 ; 
01dc1198: 200700b4 cbz      x0, #0x1dc127c
01dc119c: a81a40b9 ldr      w8, [x21, #0x18]
01dc11a0: 1f050071 cmp      w8, #1
01dc11a4: c9040054 b.ls     #0x1dc123c
01dc11a8: e00315aa mov      x0, x21
01dc11ac: 148c02f8 str      x20, [x0, #0x28]!
01dc11b0: e10314aa mov      x1, x20
01dc11b4: 3ec0c797 bl       #0xfb12ac ; 
01dc11b8: 61028052 mov      w1, #0x13
01dc11bc: e00313aa mov      x0, x19
01dc11c0: e20316aa mov      x2, x22
01dc11c4: e30315aa mov      x3, x21
01dc11c8: e4031faa mov      x4, xzr
01dc11cc: d5fd2894 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01dc11d0: f37b45a9 ldp      x19, x30, [sp, #0x50]
01dc11d4: f55344a9 ldp      x21, x20, [sp, #0x40]
01dc11d8: f75b43a9 ldp      x23, x22, [sp, #0x30]
01dc11dc: f96342a9 ldp      x25, x24, [sp, #0x20]
01dc11e0: fb6b41a9 ldp      x27, x26, [sp, #0x10]
01dc11e4: ff830191 add      sp, sp, #0x60
01dc11e8: c0035fd6 ret      
01dc11ec: 000340f9 ldr      x0, [x24]
01dc11f0: e1031faa mov      x1, xzr
01dc11f4: 4979d297 bl       #0x125f718 ; Royal.Scenes.Home.Ui.Dialogs.Offer.Priority.PriorityDataHelper$$GetDefaultShopPriority
01dc11f8: e303002a mov      w3, w0
01dc11fc: 000340f9 ldr      x0, [x24]
01dc1200: 21008052 mov      w1, #1
01dc1204: c2038052 mov      w2, #0x1e
01dc1208: e4031f2a mov      w4, wzr
01dc120c: e5031faa mov      x5, xzr
01dc1210: 0375d297 bl       #0x125e61c ; Royal.Scenes.Home.Ui.Dialogs.Offer.Priority.PriorityDataHelper$$AddPriority
01dc1214: 99ffff17 b        #0x1dc1078 ; 
01dc1218: 84c0c797 bl       #0xfb1428 ; 
01dc121c: 83c0c797 bl       #0xfb1428 ; 
01dc1220: 82c0c797 bl       #0xfb1428 ; 
01dc1224: 81c0c797 bl       #0xfb1428 ; 
01dc1228: 80c0c797 bl       #0xfb1428 ; 
01dc122c: 81c0c797 bl       #0xfb1430 ; 
01dc1230: 7ec0c797 bl       #0xfb1428 ; 
01dc1234: 7dc0c797 bl       #0xfb1428 ; 
01dc1238: 7ec0c797 bl       #0xfb1430 ; 
01dc123c: 7dc0c797 bl       #0xfb1430 ; 
01dc1240: 7ac0c797 bl       #0xfb1428 ; 
01dc1244: 79c0c797 bl       #0xfb1428 ; 
01dc1248: 78c0c797 bl       #0xfb1428 ; 
01dc124c: 77c0c797 bl       #0xfb1428 ; 
01dc1250: 76c0c797 bl       #0xfb1428 ; 
01dc1254: 75c0c797 bl       #0xfb1428 ; 
01dc1258: 74c0c797 bl       #0xfb1428 ; 
01dc125c: 73c0c797 bl       #0xfb1428 ; 
01dc1260: 72c0c797 bl       #0xfb1428 ; 
01dc1264: 7ac0c797 bl       #0xfb144c ; 
01dc1268: e1031faa mov      x1, xzr
01dc126c: 61c0c797 bl       #0xfb13f0 ; 
01dc1270: 77c0c797 bl       #0xfb144c ; 
01dc1274: e1031faa mov      x1, xzr
01dc1278: 5ec0c797 bl       #0xfb13f0 ; 
01dc127c: 74c0c797 bl       #0xfb144c ; 
01dc1280: e1031faa mov      x1, xzr
01dc1284: 5bc0c797 bl       #0xfb13f0 ; 
01dc1288: 68c0c797 bl       #0xfb1428 ; 
01dc128c: 1d000014 b        #0x1dc1300 ; 
01dc1290: 1c000014 b        #0x1dc1300 ; 
01dc1294: 1b000014 b        #0x1dc1300 ; 
01dc1298: 1a000014 b        #0x1dc1300 ; 
01dc129c: 19000014 b        #0x1dc1300 ; 
01dc12a0: 18000014 b        #0x1dc1300 ; 
01dc12a4: 17000014 b        #0x1dc1300 ; 
01dc12a8: 16000014 b        #0x1dc1300 ; 
01dc12ac: 15000014 b        #0x1dc1300 ; 
01dc12b0: 14000014 b        #0x1dc1300 ; 
01dc12b4: 13000014 b        #0x1dc1300 ; 
01dc12b8: 12000014 b        #0x1dc1300 ; 
01dc12bc: 11000014 b        #0x1dc1300 ; 
01dc12c0: 10000014 b        #0x1dc1300 ; 
01dc12c4: 0f000014 b        #0x1dc1300 ; 
01dc12c8: 0e000014 b        #0x1dc1300 ; 
01dc12cc: 0d000014 b        #0x1dc1300 ; 
01dc12d0: 0c000014 b        #0x1dc1300 ; 
01dc12d4: 0b000014 b        #0x1dc1300 ; 
01dc12d8: 0a000014 b        #0x1dc1300 ; 
01dc12dc: 09000014 b        #0x1dc1300 ; 
01dc12e0: 08000014 b        #0x1dc1300 ; 
01dc12e4: 07000014 b        #0x1dc1300 ; 
01dc12e8: 06000014 b        #0x1dc1300 ; 
01dc12ec: 05000014 b        #0x1dc1300 ; 
01dc12f0: 04000014 b        #0x1dc1300 ; 
01dc12f4: 03000014 b        #0x1dc1300 ; 
01dc12f8: 02000014 b        #0x1dc1300 ; 
01dc12fc: 01000014 b        #0x1dc1300 ; 
01dc1300: f30300aa mov      x19, x0
01dc1304: 3f040071 cmp      w1, #1
01dc1308: e1020054 b.ne     #0x1dc1364
01dc130c: e00313aa mov      x0, x19
01dc1310: b008bc97 bl       #0xcc35d0 ; 
01dc1314: f30300aa mov      x19, x0
01dc1318: a0a201b0 adrp     x0, #0x5216000
01dc131c: 001c44f9 ldr      x0, [x0, #0x838]
01dc1320: fdbfc797 bl       #0xfb1314 ; 
01dc1324: 680240f9 ldr      x8, [x19]
01dc1328: 010140f9 ldr      x1, [x8]
01dc132c: 3fc1c797 bl       #0xfb1828 ; 
01dc1330: 60000036 tbz      w0, #0, #0x1dc133c
01dc1334: 2307bc97 bl       #0xcc2fc0 ; 
01dc1338: a6ffff17 b        #0x1dc11d0 ; 
01dc133c: 00018052 mov      w0, #8
01dc1340: 2006bc97 bl       #0xcc2bc0 ; 
01dc1344: 680240f9 ldr      x8, [x19]
01dc1348: 080000f9 str      x8, [x0]
01dc134c: 218e01d0 adrp     x1, #0x4f87000
01dc1350: 21603f91 add      x1, x1, #0xfd8
01dc1354: e2031faa mov      x2, xzr
01dc1358: d203bc97 bl       #0xcc22a0 ; 
01dc135c: f30300aa mov      x19, x0
01dc1360: 1807bc97 bl       #0xcc2fc0 ; 
01dc1364: e00313aa mov      x0, x19
01dc1368: e606bc97 bl       #0xcc2f00 ; 
01dc136c: f71cbc97 bl       #0xcc8748 ; 
