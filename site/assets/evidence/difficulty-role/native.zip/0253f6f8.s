# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleList<object>
# Linear metadata span, not a recovered full CFG.
0253f6f8: 481c40f9 ldr      x8, [x2, #0x38]
0253f6fc: 020140f9 ldr      x2, [x8]
0253f700: e80300aa mov      x8, x0
0253f704: e00301aa mov      x0, x1
0253f708: e10308aa mov      x1, x8
0253f70c: 430440f9 ldr      x3, [x2, #8]
0253f710: 60001fd6 br       x3
