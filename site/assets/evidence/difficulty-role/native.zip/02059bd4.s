# Royal.Player.Context.Units.LevelEpisodeHelper$$OnEgoShownFirst
# Linear metadata span, not a recovered full CFG.
02059bd4: f40f1ef8 str      x20, [sp, #-0x20]!
02059bd8: f37b01a9 stp      x19, x30, [sp, #0x10]
02059bdc: 34a90190 adrp     x20, #0x557d000
02059be0: 88264839 ldrb     w8, [x20, #0x209]
02059be4: f30300aa mov      x19, x0
02059be8: c8000037 tbnz     w8, #0, #0x2059c00
02059bec: c08c01b0 adrp     x0, #0x51f2000
02059bf0: 003444f9 ldr      x0, [x0, #0x868]
02059bf4: c35dbd97 bl       #0xfb1300 ; 
02059bf8: 28008052 mov      w8, #1
02059bfc: 88260839 strb     w8, [x20, #0x209]
02059c00: 730a40f9 ldr      x19, [x19, #0x10]
02059c04: 930300b4 cbz      x19, #0x2059c74
02059c08: ca8c01b0 adrp     x10, #0x51f2000
02059c0c: 680240f9 ldr      x8, [x19]
02059c10: 4a3544f9 ldr      x10, [x10, #0x868]
02059c14: 09554279 ldrh     w9, [x8, #0x12a]
02059c18: 410140f9 ldr      x1, [x10]
02059c1c: 290100b4 cbz      x9, #0x2059c40
02059c20: 0a5940f9 ldr      x10, [x8, #0xb0]
02059c24: 4a210091 add      x10, x10, #8
02059c28: 4b815ff8 ldur     x11, [x10, #-8]
02059c2c: 7f0101eb cmp      x11, x1
02059c30: 00010054 b.eq     #0x2059c50
02059c34: 290500f1 subs     x9, x9, #1
02059c38: 4a410091 add      x10, x10, #0x10
02059c3c: 61ffff54 b.ne     #0x2059c28
02059c40: 62008052 mov      w2, #3
02059c44: e00313aa mov      x0, x19
02059c48: a39dbc97 bl       #0xf812d4 ; 
02059c4c: 05000014 b        #0x2059c60 ; 
02059c50: 490140b9 ldr      w9, [x10]
02059c54: 290d0011 add      w9, w9, #3
02059c58: 08d1298b add      x8, x8, w9, sxtw #4
02059c5c: 00e10491 add      x0, x8, #0x138
02059c60: 020440a9 ldp      x2, x1, [x0]
02059c64: e00313aa mov      x0, x19
02059c68: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059c6c: f40742f8 ldr      x20, [sp], #0x20
02059c70: 40001fd6 br       x2
02059c74: ed5dbd97 bl       #0xfb1428 ; 
