# Royal.Player.Context.Units.LevelEpisodeHelper$$GetSkill
# Linear metadata span, not a recovered full CFG.
02059e6c: f40f1ef8 str      x20, [sp, #-0x20]!
02059e70: f37b01a9 stp      x19, x30, [sp, #0x10]
02059e74: 34a90190 adrp     x20, #0x557d000
02059e78: 88364839 ldrb     w8, [x20, #0x20d]
02059e7c: f30300aa mov      x19, x0
02059e80: c8000037 tbnz     w8, #0, #0x2059e98
02059e84: c08c01b0 adrp     x0, #0x51f2000
02059e88: 003444f9 ldr      x0, [x0, #0x868]
02059e8c: 1d5dbd97 bl       #0xfb1300 ; 
02059e90: 28008052 mov      w8, #1
02059e94: 88360839 strb     w8, [x20, #0x20d]
02059e98: 730a40f9 ldr      x19, [x19, #0x10]
02059e9c: 930300b4 cbz      x19, #0x2059f0c
02059ea0: ca8c01b0 adrp     x10, #0x51f2000
02059ea4: 680240f9 ldr      x8, [x19]
02059ea8: 4a3544f9 ldr      x10, [x10, #0x868]
02059eac: 09554279 ldrh     w9, [x8, #0x12a]
02059eb0: 410140f9 ldr      x1, [x10]
02059eb4: 290100b4 cbz      x9, #0x2059ed8
02059eb8: 0a5940f9 ldr      x10, [x8, #0xb0]
02059ebc: 4a210091 add      x10, x10, #8
02059ec0: 4b815ff8 ldur     x11, [x10, #-8]
02059ec4: 7f0101eb cmp      x11, x1
02059ec8: 00010054 b.eq     #0x2059ee8
02059ecc: 290500f1 subs     x9, x9, #1
02059ed0: 4a410091 add      x10, x10, #0x10
02059ed4: 61ffff54 b.ne     #0x2059ec0
02059ed8: c2008052 mov      w2, #6
02059edc: e00313aa mov      x0, x19
02059ee0: fd9cbc97 bl       #0xf812d4 ; 
02059ee4: 05000014 b        #0x2059ef8 ; 
02059ee8: 490140b9 ldr      w9, [x10]
02059eec: 29190011 add      w9, w9, #6
02059ef0: 08d1298b add      x8, x8, w9, sxtw #4
02059ef4: 00e10491 add      x0, x8, #0x138
02059ef8: 020440a9 ldp      x2, x1, [x0]
02059efc: e00313aa mov      x0, x19
02059f00: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059f04: f40742f8 ldr      x20, [sp], #0x20
02059f08: 40001fd6 br       x2
02059f0c: 475dbd97 bl       #0xfb1428 ; 
