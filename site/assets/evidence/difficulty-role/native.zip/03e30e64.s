# Royal.Scenes.Home.Ui.Dialogs.BalloonRise.BalloonRiseConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
03e30e64: f60f1df8 str      x22, [sp, #-0x30]!
03e30e68: f55301a9 stp      x21, x20, [sp, #0x10]
03e30e6c: f37b02a9 stp      x19, x30, [sp, #0x20]
03e30e70: f4ba00b0 adrp     x20, #0x558d000
03e30e74: 88225e39 ldrb     w8, [x20, #0x788]
03e30e78: f30300aa mov      x19, x0
03e30e7c: c8030037 tbnz     w8, #0, #0x3e30ef4
03e30e80: 809f00d0 adrp     x0, #0x5222000
03e30e84: 00ec42f9 ldr      x0, [x0, #0x5d8]
03e30e88: 1e014697 bl       #0xfb1300 ; 
03e30e8c: 20a000f0 adrp     x0, #0x5237000
03e30e90: 00e844f9 ldr      x0, [x0, #0x9d0]
03e30e94: 1b014697 bl       #0xfb1300 ; 
03e30e98: 209d00f0 adrp     x0, #0x51d7000
03e30e9c: 00dc40f9 ldr      x0, [x0, #0x1b8]
03e30ea0: 18014697 bl       #0xfb1300 ; 
03e30ea4: a09e0090 adrp     x0, #0x5204000
03e30ea8: 00bc47f9 ldr      x0, [x0, #0xf78]
03e30eac: 15014697 bl       #0xfb1300 ; 
03e30eb0: 409b00f0 adrp     x0, #0x519b000
03e30eb4: 007847f9 ldr      x0, [x0, #0xef0]
03e30eb8: 12014697 bl       #0xfb1300 ; 
03e30ebc: 40a00090 adrp     x0, #0x5238000
03e30ec0: 009446f9 ldr      x0, [x0, #0xd28]
03e30ec4: 0f014697 bl       #0xfb1300 ; 
03e30ec8: e09b00b0 adrp     x0, #0x51ad000
03e30ecc: 002441f9 ldr      x0, [x0, #0x248]
03e30ed0: 0c014697 bl       #0xfb1300 ; 
03e30ed4: 009d00b0 adrp     x0, #0x51d1000
03e30ed8: 000c44f9 ldr      x0, [x0, #0x818]
03e30edc: 09014697 bl       #0xfb1300 ; 
03e30ee0: 209f0090 adrp     x0, #0x5214000
03e30ee4: 009045f9 ldr      x0, [x0, #0xb20]
03e30ee8: 06014697 bl       #0xfb1300 ; 
03e30eec: 28008052 mov      w8, #1
03e30ef0: 88221e39 strb     w8, [x20, #0x788]
03e30ef4: 680e40f9 ldr      x8, [x19, #0x18]
03e30ef8: e80d00b4 cbz      x8, #0x3e310b4
03e30efc: 161940f9 ldr      x22, [x8, #0x30]
03e30f00: b60d00b4 cbz      x22, #0x3e310b4
03e30f04: c00a40f9 ldr      x0, [x22, #0x10]
03e30f08: 549b00f0 adrp     x20, #0x519b000
03e30f0c: 959f00d0 adrp     x21, #0x5222000
03e30f10: 947a47f9 ldr      x20, [x20, #0xef0]
03e30f14: b5ee42f9 ldr      x21, [x21, #0x5d8]
03e30f18: e1031faa mov      x1, xzr
03e30f1c: 20597b97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
03e30f20: 60050036 tbz      w0, #0, #0x3e30fcc
03e30f24: e89b00b0 adrp     x8, #0x51ad000
03e30f28: 49a00090 adrp     x9, #0x5238000
03e30f2c: 082541f9 ldr      x8, [x8, #0x248]
03e30f30: 299546f9 ldr      x9, [x9, #0xd28]
03e30f34: 000140f9 ldr      x0, [x8]
03e30f38: 210140f9 ldr      x1, [x9]
03e30f3c: 69439e97 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03e30f40: a00b00b4 cbz      x0, #0x3e310b4
03e30f44: e1031faa mov      x1, xzr
03e30f48: 924bfb97 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03e30f4c: 810240f9 ldr      x1, [x20]
03e30f50: 162d9c97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03e30f54: e10300aa mov      x1, x0
03e30f58: e00313aa mov      x0, x19
03e30f5c: 010c02f8 str      x1, [x0, #0x20]!
03e30f60: d3004697 bl       #0xfb12ac ; 
03e30f64: b40240f9 ldr      x20, [x21]
03e30f68: 881e40f9 ldr      x8, [x20, #0x38]
03e30f6c: 000140f9 ldr      x0, [x8]
03e30f70: 08c84439 ldrb     w8, [x0, #0x132]
03e30f74: 48000037 tbnz     w8, #0, #0x3e30f7c
03e30f78: 1b404597 bl       #0xf80fe4 ; 
03e30f7c: 08e040b9 ldr      w8, [x0, #0xe0]
03e30f80: 48000035 cbnz     w8, #0x3e30f88
03e30f84: 20014697 bl       #0xfb1404 ; 
03e30f88: 881e40f9 ldr      x8, [x20, #0x38]
03e30f8c: 149d00b0 adrp     x20, #0x51d1000
03e30f90: 000140f9 ldr      x0, [x8]
03e30f94: 08c84439 ldrb     w8, [x0, #0x132]
03e30f98: 940e44f9 ldr      x20, [x20, #0x818]
03e30f9c: 48000037 tbnz     w8, #0, #0x3e30fa4
03e30fa0: 11404597 bl       #0xf80fe4 ; 
03e30fa4: 085c40f9 ldr      x8, [x0, #0xb8]
03e30fa8: 820240f9 ldr      x2, [x20]
03e30fac: e00313aa mov      x0, x19
03e30fb0: f37b42a9 ldp      x19, x30, [sp, #0x20]
03e30fb4: 030140f9 ldr      x3, [x8]
03e30fb8: f55341a9 ldp      x21, x20, [sp, #0x10]
03e30fbc: 01048052 mov      w1, #0x20
03e30fc0: e4031faa mov      x4, xzr
03e30fc4: f60743f8 ldr      x22, [sp], #0x30
03e30fc8: 563ea717 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03e30fcc: c00a40f9 ldr      x0, [x22, #0x10]
03e30fd0: 810240f9 ldr      x1, [x20]
03e30fd4: f52c9c97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03e30fd8: f40313aa mov      x20, x19
03e30fdc: 800e02f8 str      x0, [x20, #0x20]!
03e30fe0: e10300aa mov      x1, x0
03e30fe4: e00314aa mov      x0, x20
03e30fe8: b1004697 bl       #0xfb12ac ; 
03e30fec: 88825ff8 ldur     x8, [x20, #-8]
03e30ff0: 280600b4 cbz      x8, #0x3e310b4
03e30ff4: 081d40f9 ldr      x8, [x8, #0x38]
03e30ff8: e80500b4 cbz      x8, #0x3e310b4
03e30ffc: 890240f9 ldr      x9, [x20]
03e31000: a90500b4 cbz      x9, #0x3e310b4
03e31004: 081140b9 ldr      w8, [x8, #0x10]
03e31008: 8a9e00f0 adrp     x10, #0x5204000
03e3100c: 4abd47f9 ldr      x10, [x10, #0xf78]
03e31010: 149f00f0 adrp     x20, #0x5214000
03e31014: 281100b9 str      w8, [x9, #0x10]
03e31018: e1330091 add      x1, sp, #0xc
03e3101c: 400140f9 ldr      x0, [x10]
03e31020: 949245f9 ldr      x20, [x20, #0xb20]
03e31024: e80f00b9 str      w8, [sp, #0xc]
03e31028: f9004697 bl       #0xfb140c ; 
03e3102c: 880240f9 ldr      x8, [x20]
03e31030: e10300aa mov      x1, x0
03e31034: e2031faa mov      x2, xzr
03e31038: e00308aa mov      x0, x8
03e3103c: e7337b97 bl       #0x1cfdfd8 ; System.String$$Format
03e31040: b50240f9 ldr      x21, [x21]
03e31044: f40300aa mov      x20, x0
03e31048: a81e40f9 ldr      x8, [x21, #0x38]
03e3104c: 080140f9 ldr      x8, [x8]
03e31050: 09c94439 ldrb     w9, [x8, #0x132]
03e31054: 89000037 tbnz     w9, #0, #0x3e31064
03e31058: e00308aa mov      x0, x8
03e3105c: e23f4597 bl       #0xf80fe4 ; 
03e31060: e80300aa mov      x8, x0
03e31064: 09e140b9 ldr      w9, [x8, #0xe0]
03e31068: 69000035 cbnz     w9, #0x3e31074
03e3106c: e00308aa mov      x0, x8
03e31070: e5004697 bl       #0xfb1404 ; 
03e31074: a81e40f9 ldr      x8, [x21, #0x38]
03e31078: 000140f9 ldr      x0, [x8]
03e3107c: 08c84439 ldrb     w8, [x0, #0x132]
03e31080: 48000037 tbnz     w8, #0, #0x3e31088
03e31084: d83f4597 bl       #0xf80fe4 ; 
03e31088: 085c40f9 ldr      x8, [x0, #0xb8]
03e3108c: 01048052 mov      w1, #0x20
03e31090: e00313aa mov      x0, x19
03e31094: e20314aa mov      x2, x20
03e31098: 030140f9 ldr      x3, [x8]
03e3109c: e4031faa mov      x4, xzr
03e310a0: 203ea797 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03e310a4: f37b42a9 ldp      x19, x30, [sp, #0x20]
03e310a8: f55341a9 ldp      x21, x20, [sp, #0x10]
03e310ac: f60743f8 ldr      x22, [sp], #0x30
03e310b0: c0035fd6 ret      
03e310b4: dd004697 bl       #0xfb1428 ; 
