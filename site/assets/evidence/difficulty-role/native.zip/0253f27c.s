# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArrayBasedOnDifficulty<Int32Enum>
# Linear metadata span, not a recovered full CFG.
0253f27c: f60f1df8 str      x22, [sp, #-0x30]!
0253f280: f55301a9 stp      x21, x20, [sp, #0x10]
0253f284: f37b02a9 stp      x19, x30, [sp, #0x20]
0253f288: 5f080071 cmp      w2, #2
0253f28c: 6b030054 b.lt     #0x253f2f8
0253f290: f30301aa mov      x19, x1
0253f294: f40300aa mov      x20, x0
0253f298: 557c4093 sxtw     x21, w2
0253f29c: 36700091 add      x22, x1, #0x1c
0253f2a0: e00314aa mov      x0, x20
0253f2a4: e1031f2a mov      w1, wzr
0253f2a8: e203152a mov      w2, w21
0253f2ac: e3031faa mov      x3, xzr
0253f2b0: 72c81394 bl       #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
0253f2b4: d30200b4 cbz      x19, #0x253f30c
0253f2b8: 690e40f9 ldr      x9, [x19, #0x18]
0253f2bc: 1f00096b cmp      w0, w9
0253f2c0: 42020054 b.hs     #0x253f308
0253f2c4: a80600d1 sub      x8, x21, #1
0253f2c8: 297d4092 and      x9, x9, #0xffffffff
0253f2cc: 1f0109eb cmp      x8, x9
0253f2d0: c2010054 b.hs     #0x253f308
0253f2d4: 69ca208b add      x9, x19, w0, sxtw #2
0253f2d8: 2a0d42b8 ldr      w10, [x9, #0x20]!
0253f2dc: cb7a75b8 ldr      w11, [x22, x21, lsl #2]
0253f2e0: 0c050091 add      x12, x8, #1
0253f2e4: 9f0900f1 cmp      x12, #2
0253f2e8: ca7a35b8 str      w10, [x22, x21, lsl #2]
0253f2ec: f50308aa mov      x21, x8
0253f2f0: 2b0100b9 str      w11, [x9]
0253f2f4: 6cfdff54 b.gt     #0x253f2a0
0253f2f8: f37b42a9 ldp      x19, x30, [sp, #0x20]
0253f2fc: f55341a9 ldp      x21, x20, [sp, #0x10]
0253f300: f60743f8 ldr      x22, [sp], #0x30
0253f304: c0035fd6 ret      
0253f308: 4ac8a997 bl       #0xfb1430 ; 
0253f30c: 47c8a997 bl       #0xfb1428 ; 
