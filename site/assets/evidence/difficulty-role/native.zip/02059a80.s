# Royal.Player.Context.Units.LevelEpisodeHelper$$SetLevelDifficultyStrategy
# Linear metadata span, not a recovered full CFG.
02059a80: 010c01f8 str      x1, [x0, #0x10]!
02059a84: 0a5ebd17 b        #0xfb12ac ; 
