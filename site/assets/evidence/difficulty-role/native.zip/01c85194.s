# Royal.Player.Context.Units.SemiDynamicDifficulty$$get_NotApplicableForSkill
# Linear metadata span, not a recovered full CFG.
01c85194: f40f1ef8 str      x20, [sp, #-0x20]!
01c85198: f37b01a9 stp      x19, x30, [sp, #0x10]
01c8519c: 93c701b0 adrp     x19, #0x5576000
01c851a0: 68ae7c39 ldrb     w8, [x19, #0xf2b]
01c851a4: c8000035 cbnz     w8, #0x1c851bc
01c851a8: 00ac01f0 adrp     x0, #0x5208000
01c851ac: 00c041f9 ldr      x0, [x0, #0x380]
01c851b0: 54b0cc97 bl       #0xfb1300 ; 
01c851b4: 28008052 mov      w8, #1
01c851b8: 68ae3c39 strb     w8, [x19, #0xf2b]
01c851bc: 14ac01f0 adrp     x20, #0x5208000
01c851c0: 94c241f9 ldr      x20, [x20, #0x380]
01c851c4: 880240f9 ldr      x8, [x20]
01c851c8: 085d40f9 ldr      x8, [x8, #0xb8]
01c851cc: 080140f9 ldr      x8, [x8]
01c851d0: e80300b4 cbz      x8, #0x1c8524c
01c851d4: 081d40f9 ldr      x8, [x8, #0x38]
01c851d8: a80300b4 cbz      x8, #0x1c8524c
01c851dc: 000d40f9 ldr      x0, [x8, #0x18]
01c851e0: 600300b4 cbz      x0, #0x1c8524c
01c851e4: e1031faa mov      x1, xzr
01c851e8: e4581f94 bl       #0x245b578 ; Royal.Player.Context.Data.Session.UserActiveLevelData$$get_IsLeague
01c851ec: a0000036 tbz      w0, #0, #0x1c85200
01c851f0: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c851f4: 20008052 mov      w0, #1
01c851f8: f40742f8 ldr      x20, [sp], #0x20
01c851fc: c0035fd6 ret      
01c85200: 68ae7c39 ldrb     w8, [x19, #0xf2b]
01c85204: c8000035 cbnz     w8, #0x1c8521c
01c85208: 00ac01f0 adrp     x0, #0x5208000
01c8520c: 00c041f9 ldr      x0, [x0, #0x380]
01c85210: 3cb0cc97 bl       #0xfb1300 ; 
01c85214: 28008052 mov      w8, #1
01c85218: 68ae3c39 strb     w8, [x19, #0xf2b]
01c8521c: 880240f9 ldr      x8, [x20]
01c85220: 085d40f9 ldr      x8, [x8, #0xb8]
01c85224: 080140f9 ldr      x8, [x8]
01c85228: 280100b4 cbz      x8, #0x1c8524c
01c8522c: 081d40f9 ldr      x8, [x8, #0x38]
01c85230: e80000b4 cbz      x8, #0x1c8524c
01c85234: 000d40f9 ldr      x0, [x8, #0x18]
01c85238: a00000b4 cbz      x0, #0x1c8524c
01c8523c: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c85240: e1031faa mov      x1, xzr
01c85244: f40742f8 ldr      x20, [sp], #0x20
01c85248: ec581f14 b        #0x245b5f8 ; Royal.Player.Context.Data.Session.UserActiveLevelData$$get_IsStory
01c8524c: 77b0cc97 bl       #0xfb1428 ; 
