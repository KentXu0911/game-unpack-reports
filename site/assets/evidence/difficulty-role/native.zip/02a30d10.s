# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ResetSeed
# Linear metadata span, not a recovered full CFG.
02a30d10: f553bea9 stp      x21, x20, [sp, #-0x20]!
02a30d14: f37b01a9 stp      x19, x30, [sp, #0x10]
02a30d18: 955a01b0 adrp     x21, #0x5581000
02a30d1c: 543b01b0 adrp     x20, #0x5199000
02a30d20: a8ae7a39 ldrb     w8, [x21, #0xeab]
02a30d24: 942246f9 ldr      x20, [x20, #0xc40]
02a30d28: f30300aa mov      x19, x0
02a30d2c: 28010037 tbnz     w8, #0, #0x2a30d50
02a30d30: 40400190 adrp     x0, #0x5238000
02a30d34: 00bc45f9 ldr      x0, [x0, #0xb78]
02a30d38: 72019697 bl       #0xfb1300 ; 
02a30d3c: 403b01b0 adrp     x0, #0x5199000
02a30d40: 002046f9 ldr      x0, [x0, #0xc40]
02a30d44: 6f019697 bl       #0xfb1300 ; 
02a30d48: 28008052 mov      w8, #1
02a30d4c: a8ae3a39 strb     w8, [x21, #0xeab]
02a30d50: 800240f9 ldr      x0, [x20]
02a30d54: 54400190 adrp     x20, #0x5238000
02a30d58: 08e040b9 ldr      w8, [x0, #0xe0]
02a30d5c: 94be45f9 ldr      x20, [x20, #0xb78]
02a30d60: 48000035 cbnz     w8, #0x2a30d68
02a30d64: a8019697 bl       #0xfb1404 ; 
02a30d68: 810240f9 ldr      x1, [x20]
02a30d6c: a0008052 mov      w0, #5
02a30d70: c1821794 bl       #0x3011874 ; Royal.Scenes.Start.Context.ApplicationContext$$Get<object>
02a30d74: a00300b4 cbz      x0, #0x2a30de8
02a30d78: 02a08552 mov      w2, #0x2d00
02a30d7c: 2226a072 movk     w2, #0x131, lsl #16
02a30d80: e1031f2a mov      w1, wzr
02a30d84: e3031faa mov      x3, xzr
02a30d88: 2bf5f497 bl       #0x276e234 ; Royal.Infrastructure.Utils.Randoming.RandomManager$$Next
02a30d8c: e103002a mov      w1, w0
02a30d90: e00313aa mov      x0, x19
02a30d94: 16000094 bl       #0x2a30dec ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$SetSeed
02a30d98: 345a01d0 adrp     x20, #0x5576000
02a30d9c: 88ae7c39 ldrb     w8, [x20, #0xf2b]
02a30da0: c8000035 cbnz     w8, #0x2a30db8
02a30da4: c03e0190 adrp     x0, #0x5208000
02a30da8: 00c041f9 ldr      x0, [x0, #0x380]
02a30dac: 55019697 bl       #0xfb1300 ; 
02a30db0: 28008052 mov      w8, #1
02a30db4: 88ae3c39 strb     w8, [x20, #0xf2b]
02a30db8: c83e0190 adrp     x8, #0x5208000
02a30dbc: 08c141f9 ldr      x8, [x8, #0x380]
02a30dc0: 080140f9 ldr      x8, [x8]
02a30dc4: 085d40f9 ldr      x8, [x8, #0xb8]
02a30dc8: 080140f9 ldr      x8, [x8]
02a30dcc: e80000b4 cbz      x8, #0x2a30de8
02a30dd0: 081d40f9 ldr      x8, [x8, #0x38]
02a30dd4: a80000b4 cbz      x8, #0x2a30de8
02a30dd8: e00313aa mov      x0, x19
02a30ddc: f37b41a9 ldp      x19, x30, [sp, #0x10]
02a30de0: f553c2a8 ldp      x21, x20, [sp], #0x20
02a30de4: 20000014 b        #0x2a30e64 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ResetDifficultySeed
02a30de8: 90019697 bl       #0xfb1428 ; 
