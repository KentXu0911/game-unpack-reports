# Royal.Scenes.Home.Ui.Dialogs.RoyalWorldCup.Scripts.RoyalWorldCupConfigHelper$$LoadDefaultUserConfig
# Linear metadata span, not a recovered full CFG.
03db0f1c: f60f1df8 str      x22, [sp, #-0x30]!
03db0f20: f55301a9 stp      x21, x20, [sp, #0x10]
03db0f24: f37b02a9 stp      x19, x30, [sp, #0x20]
03db0f28: f4be00b0 adrp     x20, #0x558d000
03db0f2c: 95a300d0 adrp     x21, #0x5222000
03db0f30: 88724b39 ldrb     w8, [x20, #0x2dc]
03db0f34: b5ee42f9 ldr      x21, [x21, #0x5d8]
03db0f38: f30300aa mov      x19, x0
03db0f3c: 48020037 tbnz     w8, #0, #0x3db0f84
03db0f40: 80a300d0 adrp     x0, #0x5222000
03db0f44: 00ec42f9 ldr      x0, [x0, #0x5d8]
03db0f48: ee004897 bl       #0xfb1300 ; 
03db0f4c: 60a40090 adrp     x0, #0x523c000
03db0f50: 006844f9 ldr      x0, [x0, #0x8d0]
03db0f54: eb004897 bl       #0xfb1300 ; 
03db0f58: 40a40090 adrp     x0, #0x5238000
03db0f5c: 009446f9 ldr      x0, [x0, #0xd28]
03db0f60: e8004897 bl       #0xfb1300 ; 
03db0f64: 00a10090 adrp     x0, #0x51d0000
03db0f68: 004842f9 ldr      x0, [x0, #0x490]
03db0f6c: e5004897 bl       #0xfb1300 ; 
03db0f70: 00a100b0 adrp     x0, #0x51d1000
03db0f74: 000445f9 ldr      x0, [x0, #0xa08]
03db0f78: e2004897 bl       #0xfb1300 ; 
03db0f7c: 28008052 mov      w8, #1
03db0f80: 88720b39 strb     w8, [x20, #0x2dc]
03db0f84: b40240f9 ldr      x20, [x21]
03db0f88: 881e40f9 ldr      x8, [x20, #0x38]
03db0f8c: 000140f9 ldr      x0, [x8]
03db0f90: 08c84439 ldrb     w8, [x0, #0x132]
03db0f94: 48000037 tbnz     w8, #0, #0x3db0f9c
03db0f98: 13404797 bl       #0xf80fe4 ; 
03db0f9c: 08e040b9 ldr      w8, [x0, #0xe0]
03db0fa0: 48000035 cbnz     w8, #0x3db0fa8
03db0fa4: 18014897 bl       #0xfb1404 ; 
03db0fa8: 881e40f9 ldr      x8, [x20, #0x38]
03db0fac: 16a100b0 adrp     x22, #0x51d1000
03db0fb0: 15a10090 adrp     x21, #0x51d0000
03db0fb4: 54a40090 adrp     x20, #0x5238000
03db0fb8: 000140f9 ldr      x0, [x8]
03db0fbc: 08c84439 ldrb     w8, [x0, #0x132]
03db0fc0: d60645f9 ldr      x22, [x22, #0xa08]
03db0fc4: b54a42f9 ldr      x21, [x21, #0x490]
03db0fc8: 949646f9 ldr      x20, [x20, #0xd28]
03db0fcc: 48000037 tbnz     w8, #0, #0x3db0fd4
03db0fd0: 05404797 bl       #0xf80fe4 ; 
03db0fd4: 085c40f9 ldr      x8, [x0, #0xb8]
03db0fd8: c20240f9 ldr      x2, [x22]
03db0fdc: 210b8052 mov      w1, #0x59
03db0fe0: e00313aa mov      x0, x19
03db0fe4: 030140f9 ldr      x3, [x8]
03db0fe8: e4031faa mov      x4, xzr
03db0fec: 4d3ea997 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03db0ff0: a00240f9 ldr      x0, [x21]
03db0ff4: 810240f9 ldr      x1, [x20]
03db0ff8: 3a43a097 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03db0ffc: c00100b4 cbz      x0, #0x3db1034
03db1000: 54a400f0 adrp     x20, #0x523c000
03db1004: 946a44f9 ldr      x20, [x20, #0x8d0]
03db1008: e1031faa mov      x1, xzr
03db100c: 614bfd97 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03db1010: 810240f9 ldr      x1, [x20]
03db1014: e52c9e97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03db1018: 600e03f8 str      x0, [x19, #0x30]!
03db101c: e10300aa mov      x1, x0
03db1020: e00313aa mov      x0, x19
03db1024: f37b42a9 ldp      x19, x30, [sp, #0x20]
03db1028: f55341a9 ldp      x21, x20, [sp, #0x10]
03db102c: f60743f8 ldr      x22, [sp], #0x30
03db1030: 9f004817 b        #0xfb12ac ; 
03db1034: fd004897 bl       #0xfb1428 ; 
