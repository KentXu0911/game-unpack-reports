# Royal.Player.Context.Data.Persistent.UserInventory$$GetLastUpdatedSection
# Linear metadata span, not a recovered full CFG.
02a0e8a8: fe0f1ff8 str      x30, [sp, #-0x10]!
02a0e8ac: 005840f9 ldr      x0, [x0, #0xb0]
02a0e8b0: 41028052 mov      w1, #0x12
02a0e8b4: 42048052 mov      w2, #0x22
02a0e8b8: e3031faa mov      x3, xzr
02a0e8bc: bfd62194 bl       #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
02a0e8c0: fe0741f8 ldr      x30, [sp], #0x10
02a0e8c4: c0035fd6 ret      
