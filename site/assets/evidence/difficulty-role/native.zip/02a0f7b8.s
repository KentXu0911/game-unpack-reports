# Royal.Player.Context.Data.Persistent.UserInventory$$.ctor
# Linear metadata span, not a recovered full CFG.
02a0f7b8: e1031faa mov      x1, xzr
02a0f7bc: 8e8fe117 b        #0x22735f4 ; System.Object$$.ctor
