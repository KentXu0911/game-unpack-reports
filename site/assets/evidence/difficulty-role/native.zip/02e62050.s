# Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableJackpotScenariosTable$$RefillScenarioListOnTable
# Linear metadata span, not a recovered full CFG.
02e62050: ff0301d1 sub      sp, sp, #0x40
02e62054: f75b01a9 stp      x23, x22, [sp, #0x10]
02e62058: f55302a9 stp      x21, x20, [sp, #0x20]
02e6205c: f37b03a9 stp      x19, x30, [sp, #0x30]
02e62060: 153901d0 adrp     x21, #0x5584000
02e62064: a8e26039 ldrb     w8, [x21, #0x838]
02e62068: f40301aa mov      x20, x1
02e6206c: f303002a mov      w19, w0
02e62070: 88010037 tbnz     w8, #0, #0x2e620a0
02e62074: 001d01d0 adrp     x0, #0x5204000
02e62078: 00bc47f9 ldr      x0, [x0, #0xf78]
02e6207c: a13c8597 bl       #0xfb1300 ; 
02e62080: 601e01f0 adrp     x0, #0x5231000
02e62084: 003841f9 ldr      x0, [x0, #0x270]
02e62088: 9e3c8597 bl       #0xfb1300 ; 
02e6208c: 201c0190 adrp     x0, #0x51e6000
02e62090: 005c41f9 ldr      x0, [x0, #0x2b8]
02e62094: 9b3c8597 bl       #0xfb1300 ; 
02e62098: 28008052 mov      w8, #1
02e6209c: a8e22039 strb     w8, [x21, #0x838]
02e620a0: 340900b4 cbz      x20, #0x2e621c4
02e620a4: e00314aa mov      x0, x20
02e620a8: e1031faa mov      x1, xzr
02e620ac: 6aa51894 bl       #0x348b654 ; Royal.Scenes.Start.Context.Units.FeatureBundle.DragonNestScenarioBundle$$AllJackpotScenariosDataText
02e620b0: a00800b4 cbz      x0, #0x2e621c4
02e620b4: e1031faa mov      x1, xzr
02e620b8: 36873a94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02e620bc: 400800b4 cbz      x0, #0x2e621c4
02e620c0: 41018052 mov      w1, #0xa
02e620c4: e2031f2a mov      w2, wzr
02e620c8: e3031faa mov      x3, xzr
02e620cc: aa9fba97 bl       #0x1d09f74 ; System.String$$Split
02e620d0: a00700b4 cbz      x0, #0x2e621c4
02e620d4: 091840b9 ldr      w9, [x0, #0x18]
02e620d8: 68060051 sub      w8, w19, #1
02e620dc: 1f01096b cmp      w8, w9
02e620e0: 42070054 b.hs     #0x2e621c8
02e620e4: 08cc288b add      x8, x0, w8, sxtw #3
02e620e8: 741e01f0 adrp     x20, #0x5231000
02e620ec: 161140f9 ldr      x22, [x8, #0x20]
02e620f0: 943a41f9 ldr      x20, [x20, #0x270]
02e620f4: 52feff97 bl       #0x2e61a3c ; Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableJackpotScenariosTable$$get_DatabaseService
02e620f8: 880240f9 ldr      x8, [x20]
02e620fc: f40300aa mov      x20, x0
02e62100: 41008052 mov      w1, #2
02e62104: e00308aa mov      x0, x8
02e62108: 9a3c8597 bl       #0xfb1370 ; 
02e6210c: c00500b4 cbz      x0, #0x2e621c4
02e62110: f50300aa mov      x21, x0
02e62114: d60000b4 cbz      x22, #0x2e6212c
02e62118: a80240f9 ldr      x8, [x21]
02e6211c: e00316aa mov      x0, x22
02e62120: 012140f9 ldr      x1, [x8, #0x40]
02e62124: b93c8597 bl       #0xfb1408 ; 
02e62128: 200500b4 cbz      x0, #0x2e621cc
02e6212c: a81a40b9 ldr      w8, [x21, #0x18]
02e62130: c8040034 cbz      w8, #0x2e621c8
02e62134: 171d01d0 adrp     x23, #0x5204000
02e62138: f7be47f9 ldr      x23, [x23, #0xf78]
02e6213c: e00315aa mov      x0, x21
02e62140: 160c02f8 str      x22, [x0, #0x20]!
02e62144: e10316aa mov      x1, x22
02e62148: 593c8597 bl       #0xfb12ac ; 
02e6214c: e00240f9 ldr      x0, [x23]
02e62150: e1330091 add      x1, sp, #0xc
02e62154: f30f00b9 str      w19, [sp, #0xc]
02e62158: ad3c8597 bl       #0xfb140c ; 
02e6215c: f30300aa mov      x19, x0
02e62160: c00000b4 cbz      x0, #0x2e62178
02e62164: a80240f9 ldr      x8, [x21]
02e62168: e00313aa mov      x0, x19
02e6216c: 012140f9 ldr      x1, [x8, #0x40]
02e62170: a63c8597 bl       #0xfb1408 ; 
02e62174: c00200b4 cbz      x0, #0x2e621cc
02e62178: a81a40b9 ldr      w8, [x21, #0x18]
02e6217c: 1f050071 cmp      w8, #1
02e62180: 49020054 b.ls     #0x2e621c8
02e62184: e00315aa mov      x0, x21
02e62188: 138c02f8 str      x19, [x0, #0x28]!
02e6218c: e10313aa mov      x1, x19
02e62190: 473c8597 bl       #0xfb12ac ; 
02e62194: 940100b4 cbz      x20, #0x2e621c4
02e62198: 281c0190 adrp     x8, #0x51e6000
02e6219c: 085d41f9 ldr      x8, [x8, #0x2b8]
02e621a0: e00314aa mov      x0, x20
02e621a4: e20315aa mov      x2, x21
02e621a8: 010140f9 ldr      x1, [x8]
02e621ac: 51e0ff97 bl       #0x2e5a2f0 ; Royal.Infrastructure.Services.Storage.DatabaseService$$ExecuteNonQuery
02e621b0: f37b43a9 ldp      x19, x30, [sp, #0x30]
02e621b4: f55342a9 ldp      x21, x20, [sp, #0x20]
02e621b8: f75b41a9 ldp      x23, x22, [sp, #0x10]
02e621bc: ff030191 add      sp, sp, #0x40
02e621c0: c0035fd6 ret      
02e621c4: 993c8597 bl       #0xfb1428 ; 
02e621c8: 9a3c8597 bl       #0xfb1430 ; 
02e621cc: a03c8597 bl       #0xfb144c ; 
02e621d0: e1031faa mov      x1, xzr
02e621d4: 873c8597 bl       #0xfb13f0 ; 
