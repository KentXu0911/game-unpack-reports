# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetUpdatedMoveCount
# Linear metadata span, not a recovered full CFG.
01c8532c: f60f1df8 str      x22, [sp, #-0x30]!
01c85330: f55301a9 stp      x21, x20, [sp, #0x10]
01c85334: f37b02a9 stp      x19, x30, [sp, #0x20]
01c85338: b4c701d0 adrp     x20, #0x557b000
01c8533c: 88765739 ldrb     w8, [x20, #0x5dd]
01c85340: f303012a mov      w19, w1
01c85344: 28010037 tbnz     w8, #0, #0x1c85368
01c85348: 80ab01d0 adrp     x0, #0x51f7000
01c8534c: 00b045f9 ldr      x0, [x0, #0xb60]
01c85350: ecafcc97 bl       #0xfb1300 ; 
01c85354: 60a901d0 adrp     x0, #0x51b3000
01c85358: 00a041f9 ldr      x0, [x0, #0x340]
01c8535c: e9afcc97 bl       #0xfb1300 ; 
01c85360: 28008052 mov      w8, #1
01c85364: 88761739 strb     w8, [x20, #0x5dd]
01c85368: 95c701b0 adrp     x21, #0x5576000
01c8536c: a8ae7c39 ldrb     w8, [x21, #0xf2b]
01c85370: c8000035 cbnz     w8, #0x1c85388
01c85374: 00ac01f0 adrp     x0, #0x5208000
01c85378: 00c041f9 ldr      x0, [x0, #0x380]
01c8537c: e1afcc97 bl       #0xfb1300 ; 
01c85380: 28008052 mov      w8, #1
01c85384: a8ae3c39 strb     w8, [x21, #0xf2b]
01c85388: 16ac01f0 adrp     x22, #0x5208000
01c8538c: d6c241f9 ldr      x22, [x22, #0x380]
01c85390: c80240f9 ldr      x8, [x22]
01c85394: 085d40f9 ldr      x8, [x8, #0xb8]
01c85398: 080140f9 ldr      x8, [x8]
01c8539c: a80500b4 cbz      x8, #0x1c85450
01c853a0: 081d40f9 ldr      x8, [x8, #0x38]
01c853a4: 680500b4 cbz      x8, #0x1c85450
01c853a8: 000d40f9 ldr      x0, [x8, #0x18]
01c853ac: 200500b4 cbz      x0, #0x1c85450
01c853b0: e1031faa mov      x1, xzr
01c853b4: 71581f94 bl       #0x245b578 ; Royal.Player.Context.Data.Session.UserActiveLevelData$$get_IsLeague
01c853b8: 20040036 tbz      w0, #0, #0x1c8543c
01c853bc: 68a901d0 adrp     x8, #0x51b3000
01c853c0: 08a141f9 ldr      x8, [x8, #0x340]
01c853c4: 94ab01d0 adrp     x20, #0x51f7000
01c853c8: 000140f9 ldr      x0, [x8]
01c853cc: 08e040b9 ldr      w8, [x0, #0xe0]
01c853d0: 94b245f9 ldr      x20, [x20, #0xb60]
01c853d4: 48000035 cbnz     w8, #0x1c853dc
01c853d8: 0bb0cc97 bl       #0xfb1404 ; 
01c853dc: 810240f9 ldr      x1, [x20]
01c853e0: a0008052 mov      w0, #5
01c853e4: e0432f94 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
01c853e8: a8ae7c39 ldrb     w8, [x21, #0xf2b]
01c853ec: f40300aa mov      x20, x0
01c853f0: c8000035 cbnz     w8, #0x1c85408
01c853f4: 00ac01f0 adrp     x0, #0x5208000
01c853f8: 00c041f9 ldr      x0, [x0, #0x380]
01c853fc: c1afcc97 bl       #0xfb1300 ; 
01c85400: 28008052 mov      w8, #1
01c85404: a8ae3c39 strb     w8, [x21, #0xf2b]
01c85408: c80240f9 ldr      x8, [x22]
01c8540c: 085d40f9 ldr      x8, [x8, #0xb8]
01c85410: 080140f9 ldr      x8, [x8]
01c85414: e80100b4 cbz      x8, #0x1c85450
01c85418: 080d40f9 ldr      x8, [x8, #0x18]
01c8541c: a80100b4 cbz      x8, #0x1c85450
01c85420: 940100b4 cbz      x20, #0x1c85450
01c85424: 011940b9 ldr      w1, [x8, #0x18]
01c85428: e00314aa mov      x0, x20
01c8542c: e2031faa mov      x2, xzr
01c85430: 23420f94 bl       #0x2055cbc ; Royal.Player.Context.Units.LeagueManager$$GetLeagueLevel
01c85434: 08fc60d3 lsr      x8, x0, #0x20
01c85438: 1301130b add      w19, w8, w19
01c8543c: e003132a mov      w0, w19
01c85440: f37b42a9 ldp      x19, x30, [sp, #0x20]
01c85444: f55341a9 ldp      x21, x20, [sp, #0x10]
01c85448: f60743f8 ldr      x22, [sp], #0x30
01c8544c: c0035fd6 ret      
01c85450: f6afcc97 bl       #0xfb1428 ; 
