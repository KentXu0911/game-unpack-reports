# Royal.Player.Context.Data.Persistent.UserInventory$$SetTryCount2
# Linear metadata span, not a recovered full CFG.
02a0e5d8: f80f1cf8 str      x24, [sp, #-0x40]!
02a0e5dc: f75b01a9 stp      x23, x22, [sp, #0x10]
02a0e5e0: f55302a9 stp      x21, x20, [sp, #0x20]
02a0e5e4: f37b03a9 stp      x19, x30, [sp, #0x30]
02a0e5e8: 985b01f0 adrp     x24, #0x5581000
02a0e5ec: b73f01d0 adrp     x23, #0x5204000
02a0e5f0: 763c0190 adrp     x22, #0x519a000
02a0e5f4: b5400190 adrp     x21, #0x5222000
02a0e5f8: 08477539 ldrb     w8, [x24, #0xd51]
02a0e5fc: f7be47f9 ldr      x23, [x23, #0xf78]
02a0e600: d6de45f9 ldr      x22, [x22, #0xbb8]
02a0e604: b5ee42f9 ldr      x21, [x21, #0x5d8]
02a0e608: f403012a mov      w20, w1
02a0e60c: f30300aa mov      x19, x0
02a0e610: 88010037 tbnz     w8, #0, #0x2a0e640
02a0e614: a0400190 adrp     x0, #0x5222000
02a0e618: 00ec42f9 ldr      x0, [x0, #0x5d8]
02a0e61c: 398b9697 bl       #0xfb1300 ; 
02a0e620: a03f01d0 adrp     x0, #0x5204000
02a0e624: 00bc47f9 ldr      x0, [x0, #0xf78]
02a0e628: 368b9697 bl       #0xfb1300 ; 
02a0e62c: 603c0190 adrp     x0, #0x519a000
02a0e630: 00dc45f9 ldr      x0, [x0, #0xbb8]
02a0e634: 338b9697 bl       #0xfb1300 ; 
02a0e638: 28008052 mov      w8, #1
02a0e63c: 08473539 strb     w8, [x24, #0xd51]
02a0e640: e00240f9 ldr      x0, [x23]
02a0e644: e1330091 add      x1, sp, #0xc
02a0e648: f40f00b9 str      w20, [sp, #0xc]
02a0e64c: 708b9697 bl       #0xfb140c ; 
02a0e650: c80240f9 ldr      x8, [x22]
02a0e654: e10300aa mov      x1, x0
02a0e658: e2031faa mov      x2, xzr
02a0e65c: e00308aa mov      x0, x8
02a0e660: 5ebecb97 bl       #0x1cfdfd8 ; System.String$$Format
02a0e664: b60240f9 ldr      x22, [x21]
02a0e668: f50300aa mov      x21, x0
02a0e66c: c81e40f9 ldr      x8, [x22, #0x38]
02a0e670: 080140f9 ldr      x8, [x8]
02a0e674: 09c94439 ldrb     w9, [x8, #0x132]
02a0e678: 89000037 tbnz     w9, #0, #0x2a0e688
02a0e67c: e00308aa mov      x0, x8
02a0e680: 59ca9597 bl       #0xf80fe4 ; 
02a0e684: e80300aa mov      x8, x0
02a0e688: 09e140b9 ldr      w9, [x8, #0xe0]
02a0e68c: 69000035 cbnz     w9, #0x2a0e698
02a0e690: e00308aa mov      x0, x8
02a0e694: 5c8b9697 bl       #0xfb1404 ; 
02a0e698: c81e40f9 ldr      x8, [x22, #0x38]
02a0e69c: 000140f9 ldr      x0, [x8]
02a0e6a0: 08c84439 ldrb     w8, [x0, #0x132]
02a0e6a4: 48000037 tbnz     w8, #0, #0x2a0e6ac
02a0e6a8: 4fca9597 bl       #0xf80fe4 ; 
02a0e6ac: 085c40f9 ldr      x8, [x0, #0xb8]
02a0e6b0: 41018052 mov      w1, #0xa
02a0e6b4: e00313aa mov      x0, x19
02a0e6b8: e20315aa mov      x2, x21
02a0e6bc: 030140f9 ldr      x3, [x8]
02a0e6c0: e4031faa mov      x4, xzr
02a0e6c4: 97c8f797 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02a0e6c8: 605a40f9 ldr      x0, [x19, #0xb0]
02a0e6cc: 22008052 mov      w2, #1
02a0e6d0: 83018052 mov      w3, #0xc
02a0e6d4: e103142a mov      w1, w20
02a0e6d8: e4031faa mov      x4, xzr
02a0e6dc: 73d72194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e6e0: e10300aa mov      x1, x0
02a0e6e4: e00313aa mov      x0, x19
02a0e6e8: 06000094 bl       #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
02a0e6ec: f37b43a9 ldp      x19, x30, [sp, #0x30]
02a0e6f0: f55342a9 ldp      x21, x20, [sp, #0x20]
02a0e6f4: f75b41a9 ldp      x23, x22, [sp, #0x10]
02a0e6f8: f80744f8 ldr      x24, [sp], #0x40
02a0e6fc: c0035fd6 ret      
