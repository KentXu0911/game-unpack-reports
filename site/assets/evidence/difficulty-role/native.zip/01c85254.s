# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnEgoAccepted
# Linear metadata span, not a recovered full CFG.
01c85254: c0035fd6 ret      
