# Royal.Scenes.Home.Ui.Dialogs.TrainJourney.Scripts.TrainJourneyUIDataHelper$$PrepareDialogData
# Linear metadata span, not a recovered full CFG.
022206d8: f40f1ef8 str      x20, [sp, #-0x20]!
022206dc: f37b01a9 stp      x19, x30, [sp, #0x10]
022206e0: f49a01b0 adrp     x20, #0x557d000
022206e4: 88b27439 ldrb     w8, [x20, #0xd2c]
022206e8: f30301aa mov      x19, x1
022206ec: 88010037 tbnz     w8, #0, #0x222071c
022206f0: e07e0190 adrp     x0, #0x51fc000
022206f4: 004844f9 ldr      x0, [x0, #0x890]
022206f8: 0243b697 bl       #0xfb1300 ; 
022206fc: 407c01d0 adrp     x0, #0x51aa000
02220700: 00ac43f9 ldr      x0, [x0, #0x758]
02220704: ff42b697 bl       #0xfb1300 ; 
02220708: 207d01d0 adrp     x0, #0x51c6000
0222070c: 00b043f9 ldr      x0, [x0, #0x760]
02220710: fc42b697 bl       #0xfb1300 ; 
02220714: 28008052 mov      w8, #1
02220718: 88b23439 strb     w8, [x20, #0xd2c]
0222071c: 530300b4 cbz      x19, #0x2220784
02220720: 287d01d0 adrp     x8, #0x51c6000
02220724: e97e0190 adrp     x9, #0x51fc000
02220728: 08b143f9 ldr      x8, [x8, #0x760]
0222072c: 294944f9 ldr      x9, [x9, #0x890]
02220730: e00313aa mov      x0, x19
02220734: 010140f9 ldr      x1, [x8]
02220738: 220140f9 ldr      x2, [x9]
0222073c: 3d9c5b94 bl       #0x3907830 ; Royal.Scenes.Start.Context.Units.RoyalBundle.ARoyalBundle$$LoadAsset<object>
02220740: 200200b4 cbz      x0, #0x2220784
02220744: 537c01d0 adrp     x19, #0x51aa000
02220748: 73ae43f9 ldr      x19, [x19, #0x758]
0222074c: e1031faa mov      x1, xzr
02220750: 908d6b94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02220754: 610240f9 ldr      x1, [x19]
02220758: 146f0c94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0222075c: e10300aa mov      x1, x0
02220760: 0a000094 bl       #0x2220788 ; Royal.Scenes.Home.Ui.Dialogs.TrainJourney.Scripts.TrainJourneyUIDataHelper$$GetBoardData
02220764: e10300aa mov      x1, x0
02220768: e00700f9 str      x0, [sp, #8]
0222076c: e0230091 add      x0, sp, #8
02220770: cf42b697 bl       #0xfb12ac ; 
02220774: e00740f9 ldr      x0, [sp, #8]
02220778: f37b41a9 ldp      x19, x30, [sp, #0x10]
0222077c: f40742f8 ldr      x20, [sp], #0x20
02220780: c0035fd6 ret      
02220784: 2943b697 bl       #0xfb1428 ; 
