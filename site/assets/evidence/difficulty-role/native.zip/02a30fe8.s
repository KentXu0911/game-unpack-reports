# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Next
# Linear metadata span, not a recovered full CFG.
02a30fe8: fe0f1ff8 str      x30, [sp, #-0x10]!
02a30fec: 001840f9 ldr      x0, [x0, #0x30]
02a30ff0: a00000b4 cbz      x0, #0x2a31004
02a30ff4: 080040f9 ldr      x8, [x0]
02a30ff8: 048d59a9 ldp      x4, x3, [x8, #0x198]
02a30ffc: fe0741f8 ldr      x30, [sp], #0x10
02a31000: 80001fd6 br       x4
02a31004: 09019697 bl       #0xfb1428 ; 
