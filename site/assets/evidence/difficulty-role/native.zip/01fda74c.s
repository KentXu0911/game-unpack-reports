# Spine.Unity.SpineAtlasAsset$$GetAtlas
# Linear metadata span, not a recovered full CFG.
01fda74c: f75bbda9 stp      x23, x22, [sp, #-0x30]!
01fda750: f55301a9 stp      x21, x20, [sp, #0x10]
01fda754: f37b02a9 stp      x19, x30, [sp, #0x20]
01fda758: 15ad01d0 adrp     x21, #0x557c000
01fda75c: 348e01b0 adrp     x20, #0x519f000
01fda760: a8667a39 ldrb     w8, [x21, #0xe99]
01fda764: 94aa45f9 ldr      x20, [x20, #0xb50]
01fda768: f30300aa mov      x19, x0
01fda76c: 68030037 tbnz     w8, #0, #0x1fda7d8
01fda770: c09201b0 adrp     x0, #0x5233000
01fda774: 00b042f9 ldr      x0, [x0, #0x560]
01fda778: e25abf97 bl       #0xfb1300 ; 
01fda77c: 809201f0 adrp     x0, #0x522d000
01fda780: 008444f9 ldr      x0, [x0, #0x908]
01fda784: df5abf97 bl       #0xfb1300 ; 
01fda788: 408f0190 adrp     x0, #0x51c2000
01fda78c: 00d845f9 ldr      x0, [x0, #0xbb0]
01fda790: dc5abf97 bl       #0xfb1300 ; 
01fda794: 208e01b0 adrp     x0, #0x519f000
01fda798: 00a845f9 ldr      x0, [x0, #0xb50]
01fda79c: d95abf97 bl       #0xfb1300 ; 
01fda7a0: a0910190 adrp     x0, #0x520e000
01fda7a4: 001847f9 ldr      x0, [x0, #0xe30]
01fda7a8: d65abf97 bl       #0xfb1300 ; 
01fda7ac: 209201b0 adrp     x0, #0x521f000
01fda7b0: 008840f9 ldr      x0, [x0, #0x110]
01fda7b4: d35abf97 bl       #0xfb1300 ; 
01fda7b8: 209201b0 adrp     x0, #0x521f000
01fda7bc: 00a044f9 ldr      x0, [x0, #0x940]
01fda7c0: d05abf97 bl       #0xfb1300 ; 
01fda7c4: 608e01b0 adrp     x0, #0x51a7000
01fda7c8: 000441f9 ldr      x0, [x0, #0x208]
01fda7cc: cd5abf97 bl       #0xfb1300 ; 
01fda7d0: 28008052 mov      w8, #1
01fda7d4: a8663a39 strb     w8, [x21, #0xe99]
01fda7d8: 800240f9 ldr      x0, [x20]
01fda7dc: 740e40f9 ldr      x20, [x19, #0x18]
01fda7e0: 08e040b9 ldr      w8, [x0, #0xe0]
01fda7e4: 48000035 cbnz     w8, #0x1fda7ec
01fda7e8: 075bbf97 bl       #0xfb1404 ; 
01fda7ec: 959201f0 adrp     x21, #0x522d000
01fda7f0: b58644f9 ldr      x21, [x21, #0x908]
01fda7f4: e00314aa mov      x0, x20
01fda7f8: e1031faa mov      x1, xzr
01fda7fc: e2031faa mov      x2, xzr
01fda800: 5b737494 bl       #0x3cf756c ; UnityEngine.Object$$op_Equality
01fda804: 80000036 tbz      w0, #0, #0x1fda814
01fda808: 349201b0 adrp     x20, #0x521f000
01fda80c: 94a244f9 ldr      x20, [x20, #0x940]
01fda810: 3e000014 b        #0x1fda908 ; 
01fda814: 681240f9 ldr      x8, [x19, #0x20]
01fda818: 480700b4 cbz      x8, #0x1fda900
01fda81c: 080d40f9 ldr      x8, [x8, #0x18]
01fda820: 080700b4 cbz      x8, #0x1fda900
01fda824: f40313aa mov      x20, x19
01fda828: 808e42f8 ldr      x0, [x20, #0x28]!
01fda82c: c00900b5 cbnz     x0, #0x1fda964
01fda830: 600e40f9 ldr      x0, [x19, #0x18]
01fda834: 000a00b4 cbz      x0, #0x1fda974
01fda838: e1031faa mov      x1, xzr
01fda83c: 55a57494 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01fda840: a8910190 adrp     x8, #0x520e000
01fda844: 081947f9 ldr      x8, [x8, #0xe30]
01fda848: f60300aa mov      x22, x0
01fda84c: 000140f9 ldr      x0, [x8]
01fda850: f25abf97 bl       #0xfb1418 ; 
01fda854: f50300aa mov      x21, x0
01fda858: 000900b4 cbz      x0, #0x1fda978
01fda85c: e00315aa mov      x0, x21
01fda860: e10316aa mov      x1, x22
01fda864: e2031faa mov      x2, xzr
01fda868: 9fc70b94 bl       #0x22cc6e4 ; System.IO.StringReader$$.ctor
01fda86c: 488f0190 adrp     x8, #0x51c2000
01fda870: 08d945f9 ldr      x8, [x8, #0xbb0]
01fda874: 000140f9 ldr      x0, [x8]
01fda878: e85abf97 bl       #0xfb1418 ; 
01fda87c: f60300aa mov      x22, x0
01fda880: e00700b4 cbz      x0, #0x1fda97c
01fda884: e00316aa mov      x0, x22
01fda888: e1031faa mov      x1, xzr
01fda88c: 5a630a94 bl       #0x22735f4 ; System.Object$$.ctor
01fda890: e00316aa mov      x0, x22
01fda894: 130c01f8 str      x19, [x0, #0x10]!
01fda898: e10313aa mov      x1, x19
01fda89c: 845abf97 bl       #0xfb12ac ; 
01fda8a0: c89201b0 adrp     x8, #0x5233000
01fda8a4: 08b142f9 ldr      x8, [x8, #0x560]
01fda8a8: 000140f9 ldr      x0, [x8]
01fda8ac: db5abf97 bl       #0xfb1418 ; 
01fda8b0: f70300aa mov      x23, x0
01fda8b4: 600600b4 cbz      x0, #0x1fda980
01fda8b8: 688e01b0 adrp     x8, #0x51a7000
01fda8bc: 080541f9 ldr      x8, [x8, #0x208]
01fda8c0: 020140f9 ldr      x2, [x8]
01fda8c4: e00317aa mov      x0, x23
01fda8c8: e10315aa mov      x1, x21
01fda8cc: e30316aa mov      x3, x22
01fda8d0: e4031faa mov      x4, xzr
01fda8d4: ba072b94 bl       #0x2a9c7bc ; Spine.Atlas$$.ctor
01fda8d8: 970200f9 str      x23, [x20]
01fda8dc: e00314aa mov      x0, x20
01fda8e0: e10317aa mov      x1, x23
01fda8e4: 725abf97 bl       #0xfb12ac ; 
01fda8e8: 800240f9 ldr      x0, [x20]
01fda8ec: c00400b4 cbz      x0, #0x1fda984
01fda8f0: e1031faa mov      x1, xzr
01fda8f4: 910b2b94 bl       #0x2a9d738 ; Spine.Atlas$$FlipV
01fda8f8: 800240f9 ldr      x0, [x20]
01fda8fc: 1a000014 b        #0x1fda964 ; 
01fda900: 349201b0 adrp     x20, #0x521f000
01fda904: 948a40f9 ldr      x20, [x20, #0x110]
01fda908: e00313aa mov      x0, x19
01fda90c: e1031faa mov      x1, xzr
01fda910: 88627494 bl       #0x3cf3330 ; UnityEngine.Object$$get_name
01fda914: 880240f9 ldr      x8, [x20]
01fda918: e10300aa mov      x1, x0
01fda91c: e2031faa mov      x2, xzr
01fda920: e00308aa mov      x0, x8
01fda924: 948af497 bl       #0x1cfd374 ; System.String$$Concat
01fda928: a80240f9 ldr      x8, [x21]
01fda92c: f40300aa mov      x20, x0
01fda930: 09e140b9 ldr      w9, [x8, #0xe0]
01fda934: 69000035 cbnz     w9, #0x1fda940
01fda938: e00308aa mov      x0, x8
01fda93c: b25abf97 bl       #0xfb1404 ; 
01fda940: e00314aa mov      x0, x20
01fda944: e10313aa mov      x1, x19
01fda948: e2031faa mov      x2, xzr
01fda94c: 88617494 bl       #0x3cf2f6c ; UnityEngine.Debug$$LogError
01fda950: 680240f9 ldr      x8, [x19]
01fda954: e00313aa mov      x0, x19
01fda958: 09855ba9 ldp      x9, x1, [x8, #0x1b8]
01fda95c: 20013fd6 blr      x9
01fda960: e0031faa mov      x0, xzr
01fda964: f37b42a9 ldp      x19, x30, [sp, #0x20]
01fda968: f55341a9 ldp      x21, x20, [sp, #0x10]
01fda96c: f75bc3a8 ldp      x23, x22, [sp], #0x30
01fda970: c0035fd6 ret      
01fda974: ad5abf97 bl       #0xfb1428 ; 
01fda978: ac5abf97 bl       #0xfb1428 ; 
01fda97c: ab5abf97 bl       #0xfb1428 ; 
01fda980: aa5abf97 bl       #0xfb1428 ; 
01fda984: a95abf97 bl       #0xfb1428 ; 
01fda988: 05000014 b        #0x1fda99c ; 
01fda98c: 04000014 b        #0x1fda99c ; 
01fda990: 03000014 b        #0x1fda99c ; 
01fda994: 02000014 b        #0x1fda99c ; 
01fda998: 01000014 b        #0x1fda99c ; 
01fda99c: f40300aa mov      x20, x0
01fda9a0: 3f040071 cmp      w1, #1
01fda9a4: a1130054 b.ne     #0x1fdac18
01fda9a8: e00314aa mov      x0, x20
01fda9ac: 09a3b397 bl       #0xcc35d0 ; 
01fda9b0: f40300aa mov      x20, x0
01fda9b4: e0910190 adrp     x0, #0x5216000
01fda9b8: 001c44f9 ldr      x0, [x0, #0x838]
01fda9bc: 565abf97 bl       #0xfb1314 ; 
01fda9c0: 880240f9 ldr      x8, [x20]
01fda9c4: 010140f9 ldr      x1, [x8]
01fda9c8: 985bbf97 bl       #0xfb1828 ; 
01fda9cc: 20110036 tbz      w0, #0, #0x1fdabf0
01fda9d0: 950240f9 ldr      x21, [x20]
01fda9d4: 7ba1b397 bl       #0xcc2fc0 ; 
01fda9d8: 609001b0 adrp     x0, #0x51e7000
01fda9dc: 00b040f9 ldr      x0, [x0, #0x160]
01fda9e0: 4d5abf97 bl       #0xfb1314 ; 
01fda9e4: c1008052 mov      w1, #6
01fda9e8: 625abf97 bl       #0xfb1370 ; 
01fda9ec: 001000b4 cbz      x0, #0x1fdabec
01fda9f0: f40300aa mov      x20, x0
01fda9f4: c08e01f0 adrp     x0, #0x51b5000
01fda9f8: 000441f9 ldr      x0, [x0, #0x208]
01fda9fc: 465abf97 bl       #0xfb1314 ; 
01fdaa00: a00000b4 cbz      x0, #0x1fdaa14
01fdaa04: 880240f9 ldr      x8, [x20]
01fdaa08: 012140f9 ldr      x1, [x8, #0x40]
01fdaa0c: 7f5abf97 bl       #0xfb1408 ; 
01fdaa10: 800e00b4 cbz      x0, #0x1fdabe0
01fdaa14: c08e01f0 adrp     x0, #0x51b5000
01fdaa18: 000441f9 ldr      x0, [x0, #0x208]
01fdaa1c: 3e5abf97 bl       #0xfb1314 ; 
01fdaa20: 881a40b9 ldr      w8, [x20, #0x18]
01fdaa24: c80d0034 cbz      w8, #0x1fdabdc
01fdaa28: e10300aa mov      x1, x0
01fdaa2c: e00314aa mov      x0, x20
01fdaa30: 010c02f8 str      x1, [x0, #0x20]!
01fdaa34: 1e5abf97 bl       #0xfb12ac ; 
01fdaa38: e00313aa mov      x0, x19
01fdaa3c: e1031faa mov      x1, xzr
01fdaa40: 3c627494 bl       #0x3cf3330 ; UnityEngine.Object$$get_name
01fdaa44: f60300aa mov      x22, x0
01fdaa48: c00000b4 cbz      x0, #0x1fdaa60
01fdaa4c: 880240f9 ldr      x8, [x20]
01fdaa50: e00316aa mov      x0, x22
01fdaa54: 012140f9 ldr      x1, [x8, #0x40]
01fdaa58: 6c5abf97 bl       #0xfb1408 ; 
01fdaa5c: 200c00b4 cbz      x0, #0x1fdabe0
01fdaa60: 881a40b9 ldr      w8, [x20, #0x18]
01fdaa64: 1f050071 cmp      w8, #1
01fdaa68: a90b0054 b.ls     #0x1fdabdc
01fdaa6c: e00314aa mov      x0, x20
01fdaa70: 168c02f8 str      x22, [x0, #0x28]!
01fdaa74: e10316aa mov      x1, x22
01fdaa78: 0d5abf97 bl       #0xfb12ac ; 
01fdaa7c: 808d01f0 adrp     x0, #0x518d000
01fdaa80: 002447f9 ldr      x0, [x0, #0xe48]
01fdaa84: 245abf97 bl       #0xfb1314 ; 
01fdaa88: a00000b4 cbz      x0, #0x1fdaa9c
01fdaa8c: 880240f9 ldr      x8, [x20]
01fdaa90: 012140f9 ldr      x1, [x8, #0x40]
01fdaa94: 5d5abf97 bl       #0xfb1408 ; 
01fdaa98: 400a00b4 cbz      x0, #0x1fdabe0
01fdaa9c: 808d01f0 adrp     x0, #0x518d000
01fdaaa0: 002447f9 ldr      x0, [x0, #0xe48]
01fdaaa4: 1c5abf97 bl       #0xfb1314 ; 
01fdaaa8: 881a40b9 ldr      w8, [x20, #0x18]
01fdaaac: 1f090071 cmp      w8, #2
01fdaab0: 69090054 b.ls     #0x1fdabdc
01fdaab4: e10300aa mov      x1, x0
01fdaab8: e00314aa mov      x0, x20
01fdaabc: 010c03f8 str      x1, [x0, #0x30]!
01fdaac0: fb59bf97 bl       #0xfb12ac ; 
01fdaac4: 550900b4 cbz      x21, #0x1fdabec
01fdaac8: a80240f9 ldr      x8, [x21]
01fdaacc: e00315aa mov      x0, x21
01fdaad0: 098558a9 ldp      x9, x1, [x8, #0x188]
01fdaad4: 20013fd6 blr      x9
01fdaad8: f60300aa mov      x22, x0
01fdaadc: c00000b4 cbz      x0, #0x1fdaaf4
01fdaae0: 880240f9 ldr      x8, [x20]
01fdaae4: e00316aa mov      x0, x22
01fdaae8: 012140f9 ldr      x1, [x8, #0x40]
01fdaaec: 475abf97 bl       #0xfb1408 ; 
01fdaaf0: 800700b4 cbz      x0, #0x1fdabe0
01fdaaf4: 881a40b9 ldr      w8, [x20, #0x18]
01fdaaf8: 1f0d0071 cmp      w8, #3
01fdaafc: 09070054 b.ls     #0x1fdabdc
01fdab00: e00314aa mov      x0, x20
01fdab04: 168c03f8 str      x22, [x0, #0x38]!
01fdab08: e10316aa mov      x1, x22
01fdab0c: e859bf97 bl       #0xfb12ac ; 
01fdab10: 808d01f0 adrp     x0, #0x518d000
01fdab14: 002447f9 ldr      x0, [x0, #0xe48]
01fdab18: ff59bf97 bl       #0xfb1314 ; 
01fdab1c: a00000b4 cbz      x0, #0x1fdab30
01fdab20: 880240f9 ldr      x8, [x20]
01fdab24: 012140f9 ldr      x1, [x8, #0x40]
01fdab28: 385abf97 bl       #0xfb1408 ; 
01fdab2c: a00500b4 cbz      x0, #0x1fdabe0
01fdab30: 808d01f0 adrp     x0, #0x518d000
01fdab34: 002447f9 ldr      x0, [x0, #0xe48]
01fdab38: f759bf97 bl       #0xfb1314 ; 
01fdab3c: 881a40b9 ldr      w8, [x20, #0x18]
01fdab40: 1f110071 cmp      w8, #4
01fdab44: c9040054 b.ls     #0x1fdabdc
01fdab48: e10300aa mov      x1, x0
01fdab4c: e00314aa mov      x0, x20
01fdab50: 010c04f8 str      x1, [x0, #0x40]!
01fdab54: d659bf97 bl       #0xfb12ac ; 
01fdab58: a80240f9 ldr      x8, [x21]
01fdab5c: e00315aa mov      x0, x21
01fdab60: 09855da9 ldp      x9, x1, [x8, #0x1d8]
01fdab64: 20013fd6 blr      x9
01fdab68: f50300aa mov      x21, x0
01fdab6c: c00000b4 cbz      x0, #0x1fdab84
01fdab70: 880240f9 ldr      x8, [x20]
01fdab74: e00315aa mov      x0, x21
01fdab78: 012140f9 ldr      x1, [x8, #0x40]
01fdab7c: 235abf97 bl       #0xfb1408 ; 
01fdab80: 000300b4 cbz      x0, #0x1fdabe0
01fdab84: 881a40b9 ldr      w8, [x20, #0x18]
01fdab88: 1f150071 cmp      w8, #5
01fdab8c: 89020054 b.ls     #0x1fdabdc
01fdab90: e00314aa mov      x0, x20
01fdab94: 158c04f8 str      x21, [x0, #0x48]!
01fdab98: e10315aa mov      x1, x21
01fdab9c: c459bf97 bl       #0xfb12ac ; 
01fdaba0: e00314aa mov      x0, x20
01fdaba4: e1031faa mov      x1, xzr
01fdaba8: 7ab5f497 bl       #0x1d08190 ; System.String$$Concat
01fdabac: f40300aa mov      x20, x0
01fdabb0: 809201f0 adrp     x0, #0x522d000
01fdabb4: 008444f9 ldr      x0, [x0, #0x908]
01fdabb8: d759bf97 bl       #0xfb1314 ; 
01fdabbc: 08e040b9 ldr      w8, [x0, #0xe0]
01fdabc0: 48000035 cbnz     w8, #0x1fdabc8
01fdabc4: 105abf97 bl       #0xfb1404 ; 
01fdabc8: e00314aa mov      x0, x20
01fdabcc: e10313aa mov      x1, x19
01fdabd0: e2031faa mov      x2, xzr
01fdabd4: e6607494 bl       #0x3cf2f6c ; UnityEngine.Debug$$LogError
01fdabd8: 62ffff17 b        #0x1fda960 ; 
01fdabdc: 155abf97 bl       #0xfb1430 ; 
01fdabe0: 1b5abf97 bl       #0xfb144c ; 
01fdabe4: e1031faa mov      x1, xzr
01fdabe8: 025abf97 bl       #0xfb13f0 ; 
01fdabec: 0f5abf97 bl       #0xfb1428 ; 
01fdabf0: 00018052 mov      w0, #8
01fdabf4: f39fb397 bl       #0xcc2bc0 ; 
01fdabf8: 880240f9 ldr      x8, [x20]
01fdabfc: 080000f9 str      x8, [x0]
01fdac00: 617d01b0 adrp     x1, #0x4f87000
01fdac04: 21603f91 add      x1, x1, #0xfd8
01fdac08: e2031faa mov      x2, xzr
01fdac0c: a59db397 bl       #0xcc22a0 ; 
01fdac10: f40300aa mov      x20, x0
01fdac14: eba0b397 bl       #0xcc2fc0 ; 
01fdac18: e00314aa mov      x0, x20
01fdac1c: b9a0b397 bl       #0xcc2f00 ; 
01fdac20: cab6b397 bl       #0xcc8748 ; 
