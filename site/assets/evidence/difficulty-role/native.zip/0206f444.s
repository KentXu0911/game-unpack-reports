# Royal.Player.Context.Units.TeamTreasureManager$$FillFromLocal
# Linear metadata span, not a recovered full CFG.
0206f444: f553bea9 stp      x21, x20, [sp, #-0x20]!
0206f448: f37b01a9 stp      x19, x30, [sp, #0x10]
0206f44c: 74a801d0 adrp     x20, #0x557d000
0206f450: 88424b39 ldrb     w8, [x20, #0x2d0]
0206f454: f30300aa mov      x19, x0
0206f458: a8020037 tbnz     w8, #0, #0x206f4ac
0206f45c: a08a01b0 adrp     x0, #0x51c4000
0206f460: 004443f9 ldr      x0, [x0, #0x688]
0206f464: a707bd97 bl       #0xfb1300 ; 
0206f468: 008e01d0 adrp     x0, #0x5231000
0206f46c: 003841f9 ldr      x0, [x0, #0x270]
0206f470: a407bd97 bl       #0xfb1300 ; 
0206f474: 408e01b0 adrp     x0, #0x5238000
0206f478: 009446f9 ldr      x0, [x0, #0xd28]
0206f47c: a107bd97 bl       #0xfb1300 ; 
0206f480: 608b01d0 adrp     x0, #0x51dd000
0206f484: 005c42f9 ldr      x0, [x0, #0x4b8]
0206f488: 9e07bd97 bl       #0xfb1300 ; 
0206f48c: 808c01f0 adrp     x0, #0x5202000
0206f490: 00a846f9 ldr      x0, [x0, #0xd50]
0206f494: 9b07bd97 bl       #0xfb1300 ; 
0206f498: 408a01d0 adrp     x0, #0x51b9000
0206f49c: 006046f9 ldr      x0, [x0, #0xcc0]
0206f4a0: 9807bd97 bl       #0xfb1300 ; 
0206f4a4: 28008052 mov      w8, #1
0206f4a8: 88420b39 strb     w8, [x20, #0x2d0]
0206f4ac: e00313aa mov      x0, x19
0206f4b0: e1031faa mov      x1, xzr
0206f4b4: ba4c0f94 bl       #0x244279c ; Royal.Player.Context.Units.AEventManager$$FillFromLocal
0206f4b8: 600e40f9 ldr      x0, [x19, #0x18]
0206f4bc: 600900b4 cbz      x0, #0x206f5e8
0206f4c0: 9b000094 bl       #0x206f72c ; Royal.Player.Context.Units.TeamTreasureManager.TeamTreasureLocalData$$LoadData
0206f4c4: 888c01f0 adrp     x8, #0x5202000
0206f4c8: 08a946f9 ldr      x8, [x8, #0xd50]
0206f4cc: 000140f9 ldr      x0, [x8]
0206f4d0: e1031faa mov      x1, xzr
0206f4d4: e2031faa mov      x2, xzr
0206f4d8: adc23794 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
0206f4dc: b58a01b0 adrp     x21, #0x51c4000
0206f4e0: b54643f9 ldr      x21, [x21, #0x688]
0206f4e4: a10240f9 ldr      x1, [x21]
0206f4e8: b0331394 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0206f4ec: e10300aa mov      x1, x0
0206f4f0: f40313aa mov      x20, x19
0206f4f4: 810e02f8 str      x1, [x20, #0x20]!
0206f4f8: e00314aa mov      x0, x20
0206f4fc: 6c07bd97 bl       #0xfb12ac ; 
0206f500: 880240f9 ldr      x8, [x20]
0206f504: 280200b5 cbnz     x8, #0x206f548
0206f508: 488a01d0 adrp     x8, #0x51b9000
0206f50c: 498e01b0 adrp     x9, #0x5238000
0206f510: 086146f9 ldr      x8, [x8, #0xcc0]
0206f514: 299546f9 ldr      x9, [x9, #0xd28]
0206f518: 000140f9 ldr      x0, [x8]
0206f51c: 210140f9 ldr      x1, [x9]
0206f520: f0491594 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0206f524: 000700b4 cbz      x0, #0x206f604
0206f528: e1031faa mov      x1, xzr
0206f52c: 19527294 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0206f530: a10240f9 ldr      x1, [x21]
0206f534: 9d331394 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0206f538: e10300aa mov      x1, x0
0206f53c: 810200f9 str      x1, [x20]
0206f540: e00314aa mov      x0, x20
0206f544: 5a07bd97 bl       #0xfb12ac ; 
0206f548: e00313aa mov      x0, x19
0206f54c: 1affff97 bl       #0x206f1b4 ; Royal.Player.Context.Units.TeamTreasureManager$$CheckTeam
0206f550: e00313aa mov      x0, x19
0206f554: 9cfaff97 bl       #0x206dfc4 ; Royal.Player.Context.Units.TeamTreasureManager$$RestoreContributionNotification
0206f558: 088e01d0 adrp     x8, #0x5231000
0206f55c: 083941f9 ldr      x8, [x8, #0x270]
0206f560: 000140f9 ldr      x0, [x8]
0206f564: 21008052 mov      w1, #1
0206f568: 8207bd97 bl       #0xfb1370 ; 
0206f56c: f40300aa mov      x20, x0
0206f570: 600e40f9 ldr      x0, [x19, #0x18]
0206f574: c00300b4 cbz      x0, #0x206f5ec
0206f578: 080040f9 ldr      x8, [x0]
0206f57c: 098556a9 ldp      x9, x1, [x8, #0x168]
0206f580: 20013fd6 blr      x9
0206f584: 740300b4 cbz      x20, #0x206f5f0
0206f588: f50300aa mov      x21, x0
0206f58c: c00000b4 cbz      x0, #0x206f5a4
0206f590: 880240f9 ldr      x8, [x20]
0206f594: 012140f9 ldr      x1, [x8, #0x40]
0206f598: e00315aa mov      x0, x21
0206f59c: 9b07bd97 bl       #0xfb1408 ; 
0206f5a0: c00200b4 cbz      x0, #0x206f5f8
0206f5a4: 881a40b9 ldr      w8, [x20, #0x18]
0206f5a8: 68020034 cbz      w8, #0x206f5f4
0206f5ac: e00314aa mov      x0, x20
0206f5b0: 150c02f8 str      x21, [x0, #0x20]!
0206f5b4: e10315aa mov      x1, x21
0206f5b8: 3d07bd97 bl       #0xfb12ac ; 
0206f5bc: 688b01d0 adrp     x8, #0x51dd000
0206f5c0: 085d42f9 ldr      x8, [x8, #0x4b8]
0206f5c4: 020140f9 ldr      x2, [x8]
0206f5c8: 61038052 mov      w1, #0x1b
0206f5cc: e00313aa mov      x0, x19
0206f5d0: e30314aa mov      x3, x20
0206f5d4: e4031faa mov      x4, xzr
0206f5d8: d2441e94 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0206f5dc: f37b41a9 ldp      x19, x30, [sp, #0x10]
0206f5e0: f553c2a8 ldp      x21, x20, [sp], #0x20
0206f5e4: c0035fd6 ret      
0206f5e8: 9007bd97 bl       #0xfb1428 ; 
0206f5ec: 8f07bd97 bl       #0xfb1428 ; 
0206f5f0: 8e07bd97 bl       #0xfb1428 ; 
0206f5f4: 8f07bd97 bl       #0xfb1430 ; 
0206f5f8: 9507bd97 bl       #0xfb144c ; 
0206f5fc: e1031faa mov      x1, xzr
0206f600: 7c07bd97 bl       #0xfb13f0 ; 
0206f604: 8907bd97 bl       #0xfb1428 ; 
0206f608: 0a000014 b        #0x206f630 ; 
0206f60c: 09000014 b        #0x206f630 ; 
0206f610: 08000014 b        #0x206f630 ; 
0206f614: 07000014 b        #0x206f630 ; 
0206f618: 06000014 b        #0x206f630 ; 
0206f61c: 05000014 b        #0x206f630 ; 
0206f620: 04000014 b        #0x206f630 ; 
0206f624: 03000014 b        #0x206f630 ; 
0206f628: 02000014 b        #0x206f630 ; 
0206f62c: 01000014 b        #0x206f630 ; 
0206f630: f40300aa mov      x20, x0
0206f634: 3f040071 cmp      w1, #1
0206f638: 41070054 b.ne     #0x206f720
0206f63c: e00314aa mov      x0, x20
0206f640: e44fb197 bl       #0xcc35d0 ; 
0206f644: f40300aa mov      x20, x0
0206f648: 208d01f0 adrp     x0, #0x5216000
0206f64c: 001c44f9 ldr      x0, [x0, #0x838]
0206f650: 3107bd97 bl       #0xfb1314 ; 
0206f654: 880240f9 ldr      x8, [x20]
0206f658: 010140f9 ldr      x1, [x8]
0206f65c: 7308bd97 bl       #0xfb1828 ; 
0206f660: 20040036 tbz      w0, #0, #0x206f6e4
0206f664: 940240f9 ldr      x20, [x20]
0206f668: 564eb197 bl       #0xcc2fc0 ; 
0206f66c: 008e01d0 adrp     x0, #0x5231000
0206f670: 003841f9 ldr      x0, [x0, #0x270]
0206f674: 2807bd97 bl       #0xfb1314 ; 
0206f678: 21008052 mov      w1, #1
0206f67c: 3d07bd97 bl       #0xfb1370 ; 
0206f680: 200400b4 cbz      x0, #0x206f704
0206f684: f50300aa mov      x21, x0
0206f688: d40000b4 cbz      x20, #0x206f6a0
0206f68c: a80240f9 ldr      x8, [x21]
0206f690: e00314aa mov      x0, x20
0206f694: 012140f9 ldr      x1, [x8, #0x40]
0206f698: 5c07bd97 bl       #0xfb1408 ; 
0206f69c: 800300b4 cbz      x0, #0x206f70c
0206f6a0: a81a40b9 ldr      w8, [x21, #0x18]
0206f6a4: 28030034 cbz      w8, #0x206f708
0206f6a8: e00315aa mov      x0, x21
0206f6ac: 140c02f8 str      x20, [x0, #0x20]!
0206f6b0: e10314aa mov      x1, x20
0206f6b4: fe06bd97 bl       #0xfb12ac ; 
0206f6b8: e08c01d0 adrp     x0, #0x520d000
0206f6bc: 009845f9 ldr      x0, [x0, #0xb30]
0206f6c0: 1507bd97 bl       #0xfb1314 ; 
0206f6c4: e20300aa mov      x2, x0
0206f6c8: e00313aa mov      x0, x19
0206f6cc: f37b41a9 ldp      x19, x30, [sp, #0x10]
0206f6d0: 61038052 mov      w1, #0x1b
0206f6d4: e30315aa mov      x3, x21
0206f6d8: e4031faa mov      x4, xzr
0206f6dc: f553c2a8 ldp      x21, x20, [sp], #0x20
0206f6e0: 87461e14 b        #0x28010fc ; Royal.Infrastructure.Services.Logs.Log$$Error
0206f6e4: 00018052 mov      w0, #8
0206f6e8: 364db197 bl       #0xcc2bc0 ; 
0206f6ec: 880240f9 ldr      x8, [x20]
0206f6f0: 080000f9 str      x8, [x0]
0206f6f4: c1780190 adrp     x1, #0x4f87000
0206f6f8: 21603f91 add      x1, x1, #0xfd8
0206f6fc: e2031faa mov      x2, xzr
0206f700: e84ab197 bl       #0xcc22a0 ; 
0206f704: 4907bd97 bl       #0xfb1428 ; 
0206f708: 4a07bd97 bl       #0xfb1430 ; 
0206f70c: 5007bd97 bl       #0xfb144c ; 
0206f710: e1031faa mov      x1, xzr
0206f714: 3707bd97 bl       #0xfb13f0 ; 
0206f718: f40300aa mov      x20, x0
0206f71c: 294eb197 bl       #0xcc2fc0 ; 
0206f720: e00314aa mov      x0, x20
0206f724: f74db197 bl       #0xcc2f00 ; 
0206f728: 0864b197 bl       #0xcc8748 ; 
