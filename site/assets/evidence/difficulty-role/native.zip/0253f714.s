# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleListBasedOnDifficulty<object>
# Linear metadata span, not a recovered full CFG.
0253f714: fb6bbba9 stp      x27, x26, [sp, #-0x50]!
0253f718: f96301a9 stp      x25, x24, [sp, #0x10]
0253f71c: f75b02a9 stp      x23, x22, [sp, #0x20]
0253f720: f55303a9 stp      x21, x20, [sp, #0x30]
0253f724: f37b04a9 stp      x19, x30, [sp, #0x40]
0253f728: 410700b4 cbz      x1, #0x253f810
0253f72c: 481c40f9 ldr      x8, [x2, #0x38]
0253f730: f40301aa mov      x20, x1
0253f734: f50300aa mov      x21, x0
0253f738: e00314aa mov      x0, x20
0253f73c: 010540f9 ldr      x1, [x8, #8]
0253f740: f30302aa mov      x19, x2
0253f744: 280440f9 ldr      x8, [x1, #8]
0253f748: 00013fd6 blr      x8
0253f74c: 08040051 sub      w8, w0, #1
0253f750: 1f050071 cmp      w8, #1
0253f754: 2b050054 b.lt     #0x253f7f8
0253f758: f603002a mov      w22, w0
0253f75c: 3b008052 mov      w27, #1
0253f760: 77070051 sub      w23, w27, #1
0253f764: e00315aa mov      x0, x21
0253f768: e103172a mov      w1, w23
0253f76c: e203162a mov      w2, w22
0253f770: e3031faa mov      x3, xzr
0253f774: 41c71394 bl       #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
0253f778: 681e40f9 ldr      x8, [x19, #0x38]
0253f77c: f803002a mov      w24, w0
0253f780: e00314aa mov      x0, x20
0253f784: e103182a mov      w1, w24
0253f788: 020940f9 ldr      x2, [x8, #0x10]
0253f78c: 480440f9 ldr      x8, [x2, #8]
0253f790: 00013fd6 blr      x8
0253f794: 681e40f9 ldr      x8, [x19, #0x38]
0253f798: f90300aa mov      x25, x0
0253f79c: e00314aa mov      x0, x20
0253f7a0: e103172a mov      w1, w23
0253f7a4: 020940f9 ldr      x2, [x8, #0x10]
0253f7a8: 480440f9 ldr      x8, [x2, #8]
0253f7ac: 00013fd6 blr      x8
0253f7b0: 681e40f9 ldr      x8, [x19, #0x38]
0253f7b4: fa0300aa mov      x26, x0
0253f7b8: e00314aa mov      x0, x20
0253f7bc: e103172a mov      w1, w23
0253f7c0: 030d40f9 ldr      x3, [x8, #0x18]
0253f7c4: e20319aa mov      x2, x25
0253f7c8: 680440f9 ldr      x8, [x3, #8]
0253f7cc: 00013fd6 blr      x8
0253f7d0: 681e40f9 ldr      x8, [x19, #0x38]
0253f7d4: e00314aa mov      x0, x20
0253f7d8: e103182a mov      w1, w24
0253f7dc: e2031aaa mov      x2, x26
0253f7e0: 030d40f9 ldr      x3, [x8, #0x18]
0253f7e4: 680440f9 ldr      x8, [x3, #8]
0253f7e8: 00013fd6 blr      x8
0253f7ec: 7b070011 add      w27, w27, #1
0253f7f0: df021b6b cmp      w22, w27
0253f7f4: 61fbff54 b.ne     #0x253f760
0253f7f8: f37b44a9 ldp      x19, x30, [sp, #0x40]
0253f7fc: f55343a9 ldp      x21, x20, [sp, #0x30]
0253f800: f75b42a9 ldp      x23, x22, [sp, #0x20]
0253f804: f96341a9 ldp      x25, x24, [sp, #0x10]
0253f808: fb6bc5a8 ldp      x27, x26, [sp], #0x50
0253f80c: c0035fd6 ret      
0253f810: 06c7a997 bl       #0xfb1428 ; 
