# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromListBasedOnDifficulty<object>
# Linear metadata span, not a recovered full CFG.
0253efc4: f553bea9 stp      x21, x20, [sp, #-0x20]!
0253efc8: f37b01a9 stp      x19, x30, [sp, #0x10]
0253efcc: c10200b4 cbz      x1, #0x253f024
0253efd0: 481c40f9 ldr      x8, [x2, #0x38]
0253efd4: f30301aa mov      x19, x1
0253efd8: f50300aa mov      x21, x0
0253efdc: e00313aa mov      x0, x19
0253efe0: 010540f9 ldr      x1, [x8, #8]
0253efe4: f40302aa mov      x20, x2
0253efe8: 280440f9 ldr      x8, [x1, #8]
0253efec: 00013fd6 blr      x8
0253eff0: e203002a mov      w2, w0
0253eff4: e00315aa mov      x0, x21
0253eff8: e1031f2a mov      w1, wzr
0253effc: e3031faa mov      x3, xzr
0253f000: 1dc91394 bl       #0x2a31474 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$DifficultyNext
0253f004: 881e40f9 ldr      x8, [x20, #0x38]
0253f008: e103002a mov      w1, w0
0253f00c: e00313aa mov      x0, x19
0253f010: f37b41a9 ldp      x19, x30, [sp, #0x10]
0253f014: 020940f9 ldr      x2, [x8, #0x10]
0253f018: 430440f9 ldr      x3, [x2, #8]
0253f01c: f553c2a8 ldp      x21, x20, [sp], #0x20
0253f020: 60001fd6 br       x3
0253f024: 01c9a997 bl       #0xfb1428 ; 
