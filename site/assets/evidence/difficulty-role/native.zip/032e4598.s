# Royal.Player.Context.Units.ReactivationLevelsManager$$Bind
# Linear metadata span, not a recovered full CFG.
032e4598: f60f1df8 str      x22, [sp, #-0x30]!
032e459c: f55301a9 stp      x21, x20, [sp, #0x10]
032e45a0: f37b02a9 stp      x19, x30, [sp, #0x20]
032e45a4: 141501d0 adrp     x20, #0x5586000
032e45a8: 75fa00f0 adrp     x21, #0x5233000
032e45ac: b6fa0090 adrp     x22, #0x5238000
032e45b0: 883a4d39 ldrb     w8, [x20, #0x34e]
032e45b4: b5e641f9 ldr      x21, [x21, #0x3c8]
032e45b8: d69646f9 ldr      x22, [x22, #0xd28]
032e45bc: f30300aa mov      x19, x0
032e45c0: 88010037 tbnz     w8, #0, #0x32e45f0
032e45c4: 40f900f0 adrp     x0, #0x520f000
032e45c8: 009846f9 ldr      x0, [x0, #0xd30]
032e45cc: 4d337397 bl       #0xfb1300 ; 
032e45d0: a0fa0090 adrp     x0, #0x5238000
032e45d4: 009446f9 ldr      x0, [x0, #0xd28]
032e45d8: 4a337397 bl       #0xfb1300 ; 
032e45dc: 60fa00f0 adrp     x0, #0x5233000
032e45e0: 00e441f9 ldr      x0, [x0, #0x3c8]
032e45e4: 47337397 bl       #0xfb1300 ; 
032e45e8: 28008052 mov      w8, #1
032e45ec: 883a0d39 strb     w8, [x20, #0x34e]
032e45f0: a00240f9 ldr      x0, [x21]
032e45f4: c10240f9 ldr      x1, [x22]
032e45f8: ba75cb97 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
032e45fc: 600200b4 cbz      x0, #0x32e4648
032e4600: 54f900f0 adrp     x20, #0x520f000
032e4604: 949a46f9 ldr      x20, [x20, #0xd30]
032e4608: e1031faa mov      x1, xzr
032e460c: e17d2894 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
032e4610: 810240f9 ldr      x1, [x20]
032e4614: 655fc997 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
032e4618: 800100b4 cbz      x0, #0x32e4648
032e461c: 010840f9 ldr      x1, [x0, #0x10]
032e4620: 610e01f8 str      x1, [x19, #0x10]!
032e4624: e00313aa mov      x0, x19
032e4628: 21337397 bl       #0xfb12ac ; 
032e462c: 680240f9 ldr      x8, [x19]
032e4630: c80000b4 cbz      x8, #0x32e4648
032e4634: 001940b9 ldr      w0, [x8, #0x18]
032e4638: f37b42a9 ldp      x19, x30, [sp, #0x20]
032e463c: f55341a9 ldp      x21, x20, [sp, #0x10]
032e4640: f60743f8 ldr      x22, [sp], #0x30
032e4644: 02000014 b        #0x32e464c ; Royal.Player.Context.Units.ReactivationLevelsUserData$$InitReactivationData
032e4648: 78337397 bl       #0xfb1428 ; 
