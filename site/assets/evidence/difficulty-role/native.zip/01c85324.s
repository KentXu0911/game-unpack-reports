# Royal.Player.Context.Units.SemiDynamicDifficulty$$SetLevelNumber
# Linear metadata span, not a recovered full CFG.
01c85324: c0035fd6 ret      
