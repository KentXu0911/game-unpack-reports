# Royal.Scenes.Home.Ui.Dialogs.RobotRivals.Scripts.RobotRivalsConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
019dc428: ff0301d1 sub      sp, sp, #0x40
019dc42c: f75b01a9 stp      x23, x22, [sp, #0x10]
019dc430: f55302a9 stp      x21, x20, [sp, #0x20]
019dc434: f37b03a9 stp      x19, x30, [sp, #0x30]
019dc438: f4dc01d0 adrp     x20, #0x557a000
019dc43c: 88066439 ldrb     w8, [x20, #0x901]
019dc440: f30300aa mov      x19, x0
019dc444: e8040037 tbnz     w8, #0, #0x19dc4e0
019dc448: 20c201d0 adrp     x0, #0x5222000
019dc44c: 00ec42f9 ldr      x0, [x0, #0x5d8]
019dc450: ac53d797 bl       #0xfb1300 ; 
019dc454: c0c201b0 adrp     x0, #0x5235000
019dc458: 008443f9 ldr      x0, [x0, #0x708]
019dc45c: a953d797 bl       #0xfb1300 ; 
019dc460: e0c001b0 adrp     x0, #0x51f9000
019dc464: 00a047f9 ldr      x0, [x0, #0xf40]
019dc468: a653d797 bl       #0xfb1300 ; 
019dc46c: c0c101d0 adrp     x0, #0x5216000
019dc470: 001c44f9 ldr      x0, [x0, #0x838]
019dc474: a353d797 bl       #0xfb1300 ; 
019dc478: 40c001d0 adrp     x0, #0x51e6000
019dc47c: 007840f9 ldr      x0, [x0, #0xf0]
019dc480: a053d797 bl       #0xfb1300 ; 
019dc484: 40c10190 adrp     x0, #0x5204000
019dc488: 00bc47f9 ldr      x0, [x0, #0xf78]
019dc48c: 9d53d797 bl       #0xfb1300 ; 
019dc490: a0c201d0 adrp     x0, #0x5232000
019dc494: 00e843f9 ldr      x0, [x0, #0x7d0]
019dc498: 9a53d797 bl       #0xfb1300 ; 
019dc49c: e0c20190 adrp     x0, #0x5238000
019dc4a0: 009446f9 ldr      x0, [x0, #0xd28]
019dc4a4: 9753d797 bl       #0xfb1300 ; 
019dc4a8: e0c201d0 adrp     x0, #0x523a000
019dc4ac: 000c47f9 ldr      x0, [x0, #0xe18]
019dc4b0: 9453d797 bl       #0xfb1300 ; 
019dc4b4: 20c20190 adrp     x0, #0x5220000
019dc4b8: 000443f9 ldr      x0, [x0, #0x608]
019dc4bc: 9153d797 bl       #0xfb1300 ; 
019dc4c0: a0c00190 adrp     x0, #0x51f0000
019dc4c4: 00b443f9 ldr      x0, [x0, #0x768]
019dc4c8: 8e53d797 bl       #0xfb1300 ; 
019dc4cc: a0bf01b0 adrp     x0, #0x51d1000
019dc4d0: 000445f9 ldr      x0, [x0, #0xa08]
019dc4d4: 8b53d797 bl       #0xfb1300 ; 
019dc4d8: 28008052 mov      w8, #1
019dc4dc: 88062439 strb     w8, [x20, #0x901]
019dc4e0: 601640f9 ldr      x0, [x19, #0x28]
019dc4e4: 201300b4 cbz      x0, #0x19dc748
019dc4e8: e1031faa mov      x1, xzr
019dc4ec: 922b6494 bl       #0x32e7334 ; Royal.Player.Context.Units.RobotRivalsManager$$IsThereEnteredEvent
019dc4f0: e00e0036 tbz      w0, #0, #0x19dc6cc
019dc4f4: 681640f9 ldr      x8, [x19, #0x28]
019dc4f8: 881200b4 cbz      x8, #0x19dc748
019dc4fc: 081540f9 ldr      x8, [x8, #0x28]
019dc500: 481200b4 cbz      x8, #0x19dc748
019dc504: 151d40f9 ldr      x21, [x8, #0x38]
019dc508: 151200b4 cbz      x21, #0x19dc748
019dc50c: a00a40f9 ldr      x0, [x21, #0x10]
019dc510: b4c201d0 adrp     x20, #0x5232000
019dc514: 36c201d0 adrp     x22, #0x5222000
019dc518: 94ea43f9 ldr      x20, [x20, #0x7d0]
019dc51c: d6ee42f9 ldr      x22, [x22, #0x5d8]
019dc520: e1031faa mov      x1, xzr
019dc524: 9eab0c94 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
019dc528: 60050036 tbz      w0, #0, #0x19dc5d4
019dc52c: d50240f9 ldr      x21, [x22]
019dc530: a81e40f9 ldr      x8, [x21, #0x38]
019dc534: 000140f9 ldr      x0, [x8]
019dc538: 08c84439 ldrb     w8, [x0, #0x132]
019dc53c: 48000037 tbnz     w8, #0, #0x19dc544
019dc540: a992d697 bl       #0xf80fe4 ; 
019dc544: 08e040b9 ldr      w8, [x0, #0xe0]
019dc548: 48000035 cbnz     w8, #0x19dc550
019dc54c: ae53d797 bl       #0xfb1404 ; 
019dc550: a81e40f9 ldr      x8, [x21, #0x38]
019dc554: b7bf01b0 adrp     x23, #0x51d1000
019dc558: f6c201d0 adrp     x22, #0x523a000
019dc55c: f5c20190 adrp     x21, #0x5238000
019dc560: 000140f9 ldr      x0, [x8]
019dc564: 08c84439 ldrb     w8, [x0, #0x132]
019dc568: f70645f9 ldr      x23, [x23, #0xa08]
019dc56c: d60e47f9 ldr      x22, [x22, #0xe18]
019dc570: b59646f9 ldr      x21, [x21, #0xd28]
019dc574: 48000037 tbnz     w8, #0, #0x19dc57c
019dc578: 9b92d697 bl       #0xf80fe4 ; 
019dc57c: 085c40f9 ldr      x8, [x0, #0xb8]
019dc580: e20240f9 ldr      x2, [x23]
019dc584: 410a8052 mov      w1, #0x52
019dc588: e00313aa mov      x0, x19
019dc58c: 030140f9 ldr      x3, [x8]
019dc590: e4031faa mov      x4, xzr
019dc594: e3903894 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
019dc598: c00240f9 ldr      x0, [x22]
019dc59c: a10240f9 ldr      x1, [x21]
019dc5a0: d0952f94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
019dc5a4: 200d00b4 cbz      x0, #0x19dc748
019dc5a8: e1031faa mov      x1, xzr
019dc5ac: f99d8c94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
019dc5b0: 810240f9 ldr      x1, [x20]
019dc5b4: 7d7f2d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
019dc5b8: 600e02f8 str      x0, [x19, #0x20]!
019dc5bc: e10300aa mov      x1, x0
019dc5c0: e00313aa mov      x0, x19
019dc5c4: 3a53d797 bl       #0xfb12ac ; 
019dc5c8: 28008052 mov      w8, #1
019dc5cc: 68021f38 sturb    w8, [x19, #-0x10]
019dc5d0: 3f000014 b        #0x19dc6cc ; 
019dc5d4: a00a40f9 ldr      x0, [x21, #0x10]
019dc5d8: 810240f9 ldr      x1, [x20]
019dc5dc: 737f2d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
019dc5e0: e10300aa mov      x1, x0
019dc5e4: f50300aa mov      x21, x0
019dc5e8: 59000094 bl       #0x19dc74c ; Royal.Scenes.Home.Ui.Dialogs.RobotRivals.Scripts.RobotRivalsConfigHelper$$IsConfigValid
019dc5ec: a0070036 tbz      w0, #0, #0x19dc6e0
019dc5f0: f40313aa mov      x20, x19
019dc5f4: 950e02f8 str      x21, [x20, #0x20]!
019dc5f8: e00314aa mov      x0, x20
019dc5fc: e10315aa mov      x1, x21
019dc600: 2b53d797 bl       #0xfb12ac ; 
019dc604: 880640f9 ldr      x8, [x20, #8]
019dc608: 080a00b4 cbz      x8, #0x19dc748
019dc60c: 081540f9 ldr      x8, [x8, #0x28]
019dc610: c80900b4 cbz      x8, #0x19dc748
019dc614: 082140f9 ldr      x8, [x8, #0x40]
019dc618: 880900b4 cbz      x8, #0x19dc748
019dc61c: 890240f9 ldr      x9, [x20]
019dc620: 490900b4 cbz      x9, #0x19dc748
019dc624: 081140b9 ldr      w8, [x8, #0x10]
019dc628: 4ac10190 adrp     x10, #0x5204000
019dc62c: 4abd47f9 ldr      x10, [x10, #0xf78]
019dc630: 2b008052 mov      w11, #1
019dc634: 281100b9 str      w8, [x9, #0x10]
019dc638: 6b420039 strb     w11, [x19, #0x10]
019dc63c: 400140f9 ldr      x0, [x10]
019dc640: 34c20190 adrp     x20, #0x5220000
019dc644: 940643f9 ldr      x20, [x20, #0x608]
019dc648: e1330091 add      x1, sp, #0xc
019dc64c: e80f00b9 str      w8, [sp, #0xc]
019dc650: 6f53d797 bl       #0xfb140c ; 
019dc654: 880240f9 ldr      x8, [x20]
019dc658: e10300aa mov      x1, x0
019dc65c: e2031faa mov      x2, xzr
019dc660: e00308aa mov      x0, x8
019dc664: 5d860c94 bl       #0x1cfdfd8 ; System.String$$Format
019dc668: d50240f9 ldr      x21, [x22]
019dc66c: f40300aa mov      x20, x0
019dc670: a81e40f9 ldr      x8, [x21, #0x38]
019dc674: 080140f9 ldr      x8, [x8]
019dc678: 09c94439 ldrb     w9, [x8, #0x132]
019dc67c: 89000037 tbnz     w9, #0, #0x19dc68c
019dc680: e00308aa mov      x0, x8
019dc684: 5892d697 bl       #0xf80fe4 ; 
019dc688: e80300aa mov      x8, x0
019dc68c: 09e140b9 ldr      w9, [x8, #0xe0]
019dc690: 69000035 cbnz     w9, #0x19dc69c
019dc694: e00308aa mov      x0, x8
019dc698: 5b53d797 bl       #0xfb1404 ; 
019dc69c: a81e40f9 ldr      x8, [x21, #0x38]
019dc6a0: 000140f9 ldr      x0, [x8]
019dc6a4: 08c84439 ldrb     w8, [x0, #0x132]
019dc6a8: 48000037 tbnz     w8, #0, #0x19dc6b0
019dc6ac: 4e92d697 bl       #0xf80fe4 ; 
019dc6b0: 085c40f9 ldr      x8, [x0, #0xb8]
019dc6b4: 410a8052 mov      w1, #0x52
019dc6b8: e00313aa mov      x0, x19
019dc6bc: e20314aa mov      x2, x20
019dc6c0: 030140f9 ldr      x3, [x8]
019dc6c4: e4031faa mov      x4, xzr
019dc6c8: 96903894 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
019dc6cc: f37b43a9 ldp      x19, x30, [sp, #0x30]
019dc6d0: f55342a9 ldp      x21, x20, [sp, #0x20]
019dc6d4: f75b41a9 ldp      x23, x22, [sp, #0x10]
019dc6d8: ff030191 add      sp, sp, #0x40
019dc6dc: c0035fd6 ret      
019dc6e0: c8c101d0 adrp     x8, #0x5216000
019dc6e4: 081d44f9 ldr      x8, [x8, #0x838]
019dc6e8: 000140f9 ldr      x0, [x8]
019dc6ec: 4b53d797 bl       #0xfb1418 ; 
019dc6f0: c00200b4 cbz      x0, #0x19dc748
019dc6f4: a8c00190 adrp     x8, #0x51f0000
019dc6f8: 08b543f9 ldr      x8, [x8, #0x768]
019dc6fc: 54c001d0 adrp     x20, #0x51e6000
019dc700: e2031faa mov      x2, xzr
019dc704: f30300aa mov      x19, x0
019dc708: 010140f9 ldr      x1, [x8]
019dc70c: 947a40f9 ldr      x20, [x20, #0xf0]
019dc710: ec2b2294 bl       #0x22676c0 ; System.Exception$$.ctor
019dc714: 800240f9 ldr      x0, [x20]
019dc718: 08e040b9 ldr      w8, [x0, #0xe0]
019dc71c: 48000035 cbnz     w8, #0x19dc724
019dc720: 3953d797 bl       #0xfb1404 ; 
019dc724: e00313aa mov      x0, x19
019dc728: f37b43a9 ldp      x19, x30, [sp, #0x30]
019dc72c: f55342a9 ldp      x21, x20, [sp, #0x20]
019dc730: f75b41a9 ldp      x23, x22, [sp, #0x10]
019dc734: 410a8052 mov      w1, #0x52
019dc738: e2031faa mov      x2, xzr
019dc73c: e3031faa mov      x3, xzr
019dc740: ff030191 add      sp, sp, #0x40
019dc744: 28f45114 b        #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
019dc748: 3853d797 bl       #0xfb1428 ; 
