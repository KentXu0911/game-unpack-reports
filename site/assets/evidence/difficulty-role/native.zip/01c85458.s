# Royal.Player.Context.Units.SemiDynamicDifficulty$$SetTryCount
# Linear metadata span, not a recovered full CFG.
01c85458: c0035fd6 ret      
