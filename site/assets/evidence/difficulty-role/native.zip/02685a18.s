# Royal.Player.Context.Data.SyncManager$$GetUpdatedKeyValues
# Linear metadata span, not a recovered full CFG.
02685a18: f75bbda9 stp      x23, x22, [sp, #-0x30]!
02685a1c: f55301a9 stp      x21, x20, [sp, #0x10]
02685a20: f37b02a9 stp      x19, x30, [sp, #0x20]
02685a24: d47701d0 adrp     x20, #0x557f000
02685a28: 885e7a39 ldrb     w8, [x20, #0xe97]
02685a2c: f30300aa mov      x19, x0
02685a30: 48110037 tbnz     w8, #0, #0x2685c58
02685a34: a05801b0 adrp     x0, #0x519a000
02685a38: 008847f9 ldr      x0, [x0, #0xf10]
02685a3c: 31aea497 bl       #0xfb1300 ; 
02685a40: 005b01f0 adrp     x0, #0x51e8000
02685a44: 000043f9 ldr      x0, [x0, #0x600]
02685a48: 2eaea497 bl       #0xfb1300 ; 
02685a4c: 205b01d0 adrp     x0, #0x51eb000
02685a50: 00a841f9 ldr      x0, [x0, #0x350]
02685a54: 2baea497 bl       #0xfb1300 ; 
02685a58: e05c01b0 adrp     x0, #0x5222000
02685a5c: 002844f9 ldr      x0, [x0, #0x850]
02685a60: 28aea497 bl       #0xfb1300 ; 
02685a64: e0590190 adrp     x0, #0x51c1000
02685a68: 00ec47f9 ldr      x0, [x0, #0xfd8]
02685a6c: 25aea497 bl       #0xfb1300 ; 
02685a70: 605901d0 adrp     x0, #0x51b3000
02685a74: 00a041f9 ldr      x0, [x0, #0x340]
02685a78: 22aea497 bl       #0xfb1300 ; 
02685a7c: 605b01b0 adrp     x0, #0x51f2000
02685a80: 00b045f9 ldr      x0, [x0, #0xb60]
02685a84: 1faea497 bl       #0xfb1300 ; 
02685a88: 405a0190 adrp     x0, #0x51cd000
02685a8c: 00e040f9 ldr      x0, [x0, #0x1c0]
02685a90: 1caea497 bl       #0xfb1300 ; 
02685a94: 605d01d0 adrp     x0, #0x5233000
02685a98: 00d841f9 ldr      x0, [x0, #0x3b0]
02685a9c: 19aea497 bl       #0xfb1300 ; 
02685aa0: 205b01b0 adrp     x0, #0x51ea000
02685aa4: 00fc44f9 ldr      x0, [x0, #0x9f8]
02685aa8: 16aea497 bl       #0xfb1300 ; 
02685aac: 805a0190 adrp     x0, #0x51d5000
02685ab0: 007042f9 ldr      x0, [x0, #0x4e0]
02685ab4: 13aea497 bl       #0xfb1300 ; 
02685ab8: e0580190 adrp     x0, #0x51a1000
02685abc: 009443f9 ldr      x0, [x0, #0x728]
02685ac0: 10aea497 bl       #0xfb1300 ; 
02685ac4: 40590190 adrp     x0, #0x51ad000
02685ac8: 007043f9 ldr      x0, [x0, #0x6e0]
02685acc: 0daea497 bl       #0xfb1300 ; 
02685ad0: c05a0190 adrp     x0, #0x51dd000
02685ad4: 006c47f9 ldr      x0, [x0, #0xed8]
02685ad8: 0aaea497 bl       #0xfb1300 ; 
02685adc: 005c01d0 adrp     x0, #0x5207000
02685ae0: 008c46f9 ldr      x0, [x0, #0xd18]
02685ae4: 07aea497 bl       #0xfb1300 ; 
02685ae8: 805901d0 adrp     x0, #0x51b7000
02685aec: 002844f9 ldr      x0, [x0, #0x850]
02685af0: 04aea497 bl       #0xfb1300 ; 
02685af4: 805801d0 adrp     x0, #0x5197000
02685af8: 004841f9 ldr      x0, [x0, #0x290]
02685afc: 01aea497 bl       #0xfb1300 ; 
02685b00: 405c01b0 adrp     x0, #0x520e000
02685b04: 00b441f9 ldr      x0, [x0, #0x368]
02685b08: feada497 bl       #0xfb1300 ; 
02685b0c: a05a01d0 adrp     x0, #0x51db000
02685b10: 006046f9 ldr      x0, [x0, #0xcc0]
02685b14: fbada497 bl       #0xfb1300 ; 
02685b18: c05b01d0 adrp     x0, #0x51ff000
02685b1c: 000440f9 ldr      x0, [x0, #8]
02685b20: f8ada497 bl       #0xfb1300 ; 
02685b24: c05c01d0 adrp     x0, #0x521f000
02685b28: 00c846f9 ldr      x0, [x0, #0xd90]
02685b2c: f5ada497 bl       #0xfb1300 ; 
02685b30: c05901b0 adrp     x0, #0x51be000
02685b34: 00a846f9 ldr      x0, [x0, #0xd50]
02685b38: f2ada497 bl       #0xfb1300 ; 
02685b3c: c05801d0 adrp     x0, #0x519f000
02685b40: 004442f9 ldr      x0, [x0, #0x488]
02685b44: efada497 bl       #0xfb1300 ; 
02685b48: 605901d0 adrp     x0, #0x51b3000
02685b4c: 00e441f9 ldr      x0, [x0, #0x3c8]
02685b50: ecada497 bl       #0xfb1300 ; 
02685b54: 405a01d0 adrp     x0, #0x51cf000
02685b58: 008846f9 ldr      x0, [x0, #0xd10]
02685b5c: e9ada497 bl       #0xfb1300 ; 
02685b60: e05b01b0 adrp     x0, #0x5202000
02685b64: 00d843f9 ldr      x0, [x0, #0x7b0]
02685b68: e6ada497 bl       #0xfb1300 ; 
02685b6c: c05d01b0 adrp     x0, #0x523e000
02685b70: 00c842f9 ldr      x0, [x0, #0x590]
02685b74: e3ada497 bl       #0xfb1300 ; 
02685b78: a05d0190 adrp     x0, #0x5239000
02685b7c: 002840f9 ldr      x0, [x0, #0x50]
02685b80: e0ada497 bl       #0xfb1300 ; 
02685b84: a05b0190 adrp     x0, #0x51f9000
02685b88: 004841f9 ldr      x0, [x0, #0x290]
02685b8c: ddada497 bl       #0xfb1300 ; 
02685b90: 005901d0 adrp     x0, #0x51a7000
02685b94: 006445f9 ldr      x0, [x0, #0xac8]
02685b98: daada497 bl       #0xfb1300 ; 
02685b9c: c0590190 adrp     x0, #0x51bd000
02685ba0: 008044f9 ldr      x0, [x0, #0x900]
02685ba4: d7ada497 bl       #0xfb1300 ; 
02685ba8: 805801b0 adrp     x0, #0x5196000
02685bac: 00f446f9 ldr      x0, [x0, #0xde8]
02685bb0: d4ada497 bl       #0xfb1300 ; 
02685bb4: 405c01f0 adrp     x0, #0x5210000
02685bb8: 00c445f9 ldr      x0, [x0, #0xb88]
02685bbc: d1ada497 bl       #0xfb1300 ; 
02685bc0: e05a01b0 adrp     x0, #0x51e2000
02685bc4: 009c46f9 ldr      x0, [x0, #0xd38]
02685bc8: ceada497 bl       #0xfb1300 ; 
02685bcc: 205b01d0 adrp     x0, #0x51eb000
02685bd0: 009c42f9 ldr      x0, [x0, #0x538]
02685bd4: cbada497 bl       #0xfb1300 ; 
02685bd8: c05b0190 adrp     x0, #0x51fd000
02685bdc: 001445f9 ldr      x0, [x0, #0xa28]
02685be0: c8ada497 bl       #0xfb1300 ; 
02685be4: e05b0190 adrp     x0, #0x5201000
02685be8: 009844f9 ldr      x0, [x0, #0x930]
02685bec: c5ada497 bl       #0xfb1300 ; 
02685bf0: a05c0190 adrp     x0, #0x5219000
02685bf4: 006040f9 ldr      x0, [x0, #0xc0]
02685bf8: c2ada497 bl       #0xfb1300 ; 
02685bfc: c05c01f0 adrp     x0, #0x5220000
02685c00: 00b447f9 ldr      x0, [x0, #0xf68]
02685c04: bfada497 bl       #0xfb1300 ; 
02685c08: 805d01b0 adrp     x0, #0x5236000
02685c0c: 006844f9 ldr      x0, [x0, #0x8d0]
02685c10: bcada497 bl       #0xfb1300 ; 
02685c14: 805d01b0 adrp     x0, #0x5236000
02685c18: 002c47f9 ldr      x0, [x0, #0xe58]
02685c1c: b9ada497 bl       #0xfb1300 ; 
02685c20: 805a0190 adrp     x0, #0x51d5000
02685c24: 00e444f9 ldr      x0, [x0, #0x9c8]
02685c28: b6ada497 bl       #0xfb1300 ; 
02685c2c: 005b01f0 adrp     x0, #0x51e8000
02685c30: 006840f9 ldr      x0, [x0, #0xd0]
02685c34: b3ada497 bl       #0xfb1300 ; 
02685c38: c05d0190 adrp     x0, #0x523d000
02685c3c: 005440f9 ldr      x0, [x0, #0xa8]
02685c40: b0ada497 bl       #0xfb1300 ; 
02685c44: a0590190 adrp     x0, #0x51b9000
02685c48: 00fc43f9 ldr      x0, [x0, #0x7f8]
02685c4c: adada497 bl       #0xfb1300 ; 
02685c50: 28008052 mov      w8, #1
02685c54: 885e3a39 strb     w8, [x20, #0xe97]
02685c58: e00313aa mov      x0, x19
02685c5c: e1031faa mov      x1, xzr
02685c60: beaa1f94 bl       #0x2e70758 ; Royal.Infrastructure.Services.Storage.Tables.SyncRequiredKeyValueCounts$$TotalKeyValueCount
02685c64: 1f040071 cmp      w0, #1
02685c68: 6b4a0054 b.lt     #0x26865b4
02685c6c: 285b01d0 adrp     x8, #0x51eb000
02685c70: 08a941f9 ldr      x8, [x8, #0x350]
02685c74: 000140f9 ldr      x0, [x8]
02685c78: e8ada497 bl       #0xfb1418 ; 
02685c7c: 804a00b4 cbz      x0, #0x26865cc
02685c80: 085b01f0 adrp     x8, #0x51e8000
02685c84: 080143f9 ldr      x8, [x8, #0x600]
02685c88: b55801b0 adrp     x21, #0x519a000
02685c8c: f40300aa mov      x20, x0
02685c90: 010140f9 ldr      x1, [x8]
02685c94: b58a47f9 ldr      x21, [x21, #0xf10]
02685c98: 668e5594 bl       #0x3be9630 ; System.Collections.Generic.Dictionary<object, long>$$.ctor
02685c9c: 680240b9 ldr      w8, [x19]
02685ca0: 165c01f0 adrp     x22, #0x5208000
02685ca4: d6c241f9 ldr      x22, [x22, #0x380]
02685ca8: 977701b0 adrp     x23, #0x5576000
02685cac: 1f050071 cmp      w8, #1
02685cb0: ab020054 b.lt     #0x2685d04
02685cb4: e8ae7c39 ldrb     w8, [x23, #0xf2b]
02685cb8: c8000035 cbnz     w8, #0x2685cd0
02685cbc: 005c01f0 adrp     x0, #0x5208000
02685cc0: 00c041f9 ldr      x0, [x0, #0x380]
02685cc4: 8fada497 bl       #0xfb1300 ; 
02685cc8: 28008052 mov      w8, #1
02685ccc: e8ae3c39 strb     w8, [x23, #0xf2b]
02685cd0: c80240f9 ldr      x8, [x22]
02685cd4: 085d40f9 ldr      x8, [x8, #0xb8]
02685cd8: 080140f9 ldr      x8, [x8]
02685cdc: 884700b4 cbz      x8, #0x26865cc
02685ce0: 081140f9 ldr      x8, [x8, #0x20]
02685ce4: 484700b4 cbz      x8, #0x26865cc
02685ce8: 695b01b0 adrp     x9, #0x51f2000
02685cec: 29b145f9 ldr      x9, [x9, #0xb60]
02685cf0: 025540f9 ldr      x2, [x8, #0xa8]
02685cf4: a30240f9 ldr      x3, [x21]
02685cf8: e00314aa mov      x0, x20
02685cfc: 210140f9 ldr      x1, [x9]
02685d00: e0905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685d04: 680640b9 ldr      w8, [x19, #4]
02685d08: 1f050071 cmp      w8, #1
02685d0c: ab020054 b.lt     #0x2685d60
02685d10: e8ae7c39 ldrb     w8, [x23, #0xf2b]
02685d14: c8000035 cbnz     w8, #0x2685d2c
02685d18: 005c01f0 adrp     x0, #0x5208000
02685d1c: 00c041f9 ldr      x0, [x0, #0x380]
02685d20: 78ada497 bl       #0xfb1300 ; 
02685d24: 28008052 mov      w8, #1
02685d28: e8ae3c39 strb     w8, [x23, #0xf2b]
02685d2c: c80240f9 ldr      x8, [x22]
02685d30: 085d40f9 ldr      x8, [x8, #0xb8]
02685d34: 080140f9 ldr      x8, [x8]
02685d38: a84400b4 cbz      x8, #0x26865cc
02685d3c: 081140f9 ldr      x8, [x8, #0x20]
02685d40: 684400b4 cbz      x8, #0x26865cc
02685d44: c9590190 adrp     x9, #0x51bd000
02685d48: 298144f9 ldr      x9, [x9, #0x900]
02685d4c: 025940f9 ldr      x2, [x8, #0xb0]
02685d50: a30240f9 ldr      x3, [x21]
02685d54: e00314aa mov      x0, x20
02685d58: 210140f9 ldr      x1, [x9]
02685d5c: c9905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685d60: 681240b9 ldr      w8, [x19, #0x10]
02685d64: 765901d0 adrp     x22, #0x51b3000
02685d68: d6a241f9 ldr      x22, [x22, #0x340]
02685d6c: 1f050071 cmp      w8, #1
02685d70: 4b020054 b.lt     #0x2685db8
02685d74: c00240f9 ldr      x0, [x22]
02685d78: f7590190 adrp     x23, #0x51c1000
02685d7c: 08e040b9 ldr      w8, [x0, #0xe0]
02685d80: f7ee47f9 ldr      x23, [x23, #0xfd8]
02685d84: 48000035 cbnz     w8, #0x2685d8c
02685d88: 9fada497 bl       #0xfb1404 ; 
02685d8c: e10240f9 ldr      x1, [x23]
02685d90: 20038052 mov      w0, #0x19
02685d94: 74410794 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
02685d98: a04100b4 cbz      x0, #0x26865cc
02685d9c: c85901b0 adrp     x8, #0x51be000
02685da0: 08a946f9 ldr      x8, [x8, #0xd50]
02685da4: 021440f9 ldr      x2, [x0, #0x28]
02685da8: a30240f9 ldr      x3, [x21]
02685dac: e00314aa mov      x0, x20
02685db0: 010140f9 ldr      x1, [x8]
02685db4: b3905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685db8: 681640b9 ldr      w8, [x19, #0x14]
02685dbc: 1f050071 cmp      w8, #1
02685dc0: 4b020054 b.lt     #0x2685e08
02685dc4: c00240f9 ldr      x0, [x22]
02685dc8: f65c01b0 adrp     x22, #0x5222000
02685dcc: 08e040b9 ldr      w8, [x0, #0xe0]
02685dd0: d62a44f9 ldr      x22, [x22, #0x850]
02685dd4: 48000035 cbnz     w8, #0x2685ddc
02685dd8: 8bada497 bl       #0xfb1404 ; 
02685ddc: c10240f9 ldr      x1, [x22]
02685de0: e0028052 mov      w0, #0x17
02685de4: 60410794 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
02685de8: 203f00b4 cbz      x0, #0x26865cc
02685dec: a85d0190 adrp     x8, #0x5239000
02685df0: 082940f9 ldr      x8, [x8, #0x50]
02685df4: 022040f9 ldr      x2, [x0, #0x40]
02685df8: a30240f9 ldr      x3, [x21]
02685dfc: e00314aa mov      x0, x20
02685e00: 010140f9 ldr      x1, [x8]
02685e04: 9f905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685e08: 681a40b9 ldr      w8, [x19, #0x18]
02685e0c: 1f050071 cmp      w8, #1
02685e10: 8b010054 b.lt     #0x2685e40
02685e14: 965d01b0 adrp     x22, #0x5236000
02685e18: d66a44f9 ldr      x22, [x22, #0x8d0]
02685e1c: e1031faa mov      x1, xzr
02685e20: e2031faa mov      x2, xzr
02685e24: c00240f9 ldr      x0, [x22]
02685e28: cca81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685e2c: c10240f9 ldr      x1, [x22]
02685e30: a30240f9 ldr      x3, [x21]
02685e34: e20300aa mov      x2, x0
02685e38: e00314aa mov      x0, x20
02685e3c: 91905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685e40: 681e40b9 ldr      w8, [x19, #0x1c]
02685e44: 1f050071 cmp      w8, #1
02685e48: 8b010054 b.lt     #0x2685e78
02685e4c: f65a01b0 adrp     x22, #0x51e2000
02685e50: d69e46f9 ldr      x22, [x22, #0xd38]
02685e54: e1031faa mov      x1, xzr
02685e58: e2031faa mov      x2, xzr
02685e5c: c00240f9 ldr      x0, [x22]
02685e60: bea81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685e64: c10240f9 ldr      x1, [x22]
02685e68: a30240f9 ldr      x3, [x21]
02685e6c: e20300aa mov      x2, x0
02685e70: e00314aa mov      x0, x20
02685e74: 83905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685e78: 682240b9 ldr      w8, [x19, #0x20]
02685e7c: 1f050071 cmp      w8, #1
02685e80: 8b010054 b.lt     #0x2685eb0
02685e84: 565a0190 adrp     x22, #0x51cd000
02685e88: d6e240f9 ldr      x22, [x22, #0x1c0]
02685e8c: e1031faa mov      x1, xzr
02685e90: e2031faa mov      x2, xzr
02685e94: c00240f9 ldr      x0, [x22]
02685e98: b0a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685e9c: c10240f9 ldr      x1, [x22]
02685ea0: a30240f9 ldr      x3, [x21]
02685ea4: e20300aa mov      x2, x0
02685ea8: e00314aa mov      x0, x20
02685eac: 75905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685eb0: 682640b9 ldr      w8, [x19, #0x24]
02685eb4: 1f050071 cmp      w8, #1
02685eb8: 8b010054 b.lt     #0x2685ee8
02685ebc: d65b01d0 adrp     x22, #0x51ff000
02685ec0: d60640f9 ldr      x22, [x22, #8]
02685ec4: e1031faa mov      x1, xzr
02685ec8: e2031faa mov      x2, xzr
02685ecc: c00240f9 ldr      x0, [x22]
02685ed0: a2a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685ed4: c10240f9 ldr      x1, [x22]
02685ed8: a30240f9 ldr      x3, [x21]
02685edc: e20300aa mov      x2, x0
02685ee0: e00314aa mov      x0, x20
02685ee4: 67905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685ee8: 682a40b9 ldr      w8, [x19, #0x28]
02685eec: 1f050071 cmp      w8, #1
02685ef0: 8b010054 b.lt     #0x2685f20
02685ef4: b6590190 adrp     x22, #0x51b9000
02685ef8: d6fe43f9 ldr      x22, [x22, #0x7f8]
02685efc: e1031faa mov      x1, xzr
02685f00: e2031faa mov      x2, xzr
02685f04: c00240f9 ldr      x0, [x22]
02685f08: 94a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685f0c: c10240f9 ldr      x1, [x22]
02685f10: a30240f9 ldr      x3, [x21]
02685f14: e20300aa mov      x2, x0
02685f18: e00314aa mov      x0, x20
02685f1c: 59905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685f20: 682e40b9 ldr      w8, [x19, #0x2c]
02685f24: 1f050071 cmp      w8, #1
02685f28: 8b010054 b.lt     #0x2685f58
02685f2c: 965a0190 adrp     x22, #0x51d5000
02685f30: d67242f9 ldr      x22, [x22, #0x4e0]
02685f34: e1031faa mov      x1, xzr
02685f38: e2031faa mov      x2, xzr
02685f3c: c00240f9 ldr      x0, [x22]
02685f40: 86a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685f44: c10240f9 ldr      x1, [x22]
02685f48: a30240f9 ldr      x3, [x21]
02685f4c: e20300aa mov      x2, x0
02685f50: e00314aa mov      x0, x20
02685f54: 4b905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685f58: 683640b9 ldr      w8, [x19, #0x34]
02685f5c: 1f050071 cmp      w8, #1
02685f60: 8b010054 b.lt     #0x2685f90
02685f64: b65c0190 adrp     x22, #0x5219000
02685f68: d66240f9 ldr      x22, [x22, #0xc0]
02685f6c: e1031faa mov      x1, xzr
02685f70: e2031faa mov      x2, xzr
02685f74: c00240f9 ldr      x0, [x22]
02685f78: 78a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685f7c: c10240f9 ldr      x1, [x22]
02685f80: a30240f9 ldr      x3, [x21]
02685f84: e20300aa mov      x2, x0
02685f88: e00314aa mov      x0, x20
02685f8c: 3d905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685f90: 683a40b9 ldr      w8, [x19, #0x38]
02685f94: 1f050071 cmp      w8, #1
02685f98: 8b010054 b.lt     #0x2685fc8
02685f9c: 565c01f0 adrp     x22, #0x5210000
02685fa0: d6c645f9 ldr      x22, [x22, #0xb88]
02685fa4: e1031faa mov      x1, xzr
02685fa8: e2031faa mov      x2, xzr
02685fac: c00240f9 ldr      x0, [x22]
02685fb0: 6aa81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685fb4: c10240f9 ldr      x1, [x22]
02685fb8: a30240f9 ldr      x3, [x21]
02685fbc: e20300aa mov      x2, x0
02685fc0: e00314aa mov      x0, x20
02685fc4: 2f905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02685fc8: 683e40b9 ldr      w8, [x19, #0x3c]
02685fcc: 1f050071 cmp      w8, #1
02685fd0: 8b010054 b.lt     #0x2686000
02685fd4: 365b01b0 adrp     x22, #0x51ea000
02685fd8: d6fe44f9 ldr      x22, [x22, #0x9f8]
02685fdc: e1031faa mov      x1, xzr
02685fe0: e2031faa mov      x2, xzr
02685fe4: c00240f9 ldr      x0, [x22]
02685fe8: 5ca81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02685fec: c10240f9 ldr      x1, [x22]
02685ff0: a30240f9 ldr      x3, [x21]
02685ff4: e20300aa mov      x2, x0
02685ff8: e00314aa mov      x0, x20
02685ffc: 21905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686000: 684240b9 ldr      w8, [x19, #0x40]
02686004: 1f050071 cmp      w8, #1
02686008: 8b010054 b.lt     #0x2686038
0268600c: 165901b0 adrp     x22, #0x51a7000
02686010: d66645f9 ldr      x22, [x22, #0xac8]
02686014: e1031faa mov      x1, xzr
02686018: e2031faa mov      x2, xzr
0268601c: c00240f9 ldr      x0, [x22]
02686020: 4ea81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686024: c10240f9 ldr      x1, [x22]
02686028: a30240f9 ldr      x3, [x21]
0268602c: e20300aa mov      x2, x0
02686030: e00314aa mov      x0, x20
02686034: 13905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686038: 684640b9 ldr      w8, [x19, #0x44]
0268603c: 1f050071 cmp      w8, #1
02686040: 8b010054 b.lt     #0x2686070
02686044: 965d0190 adrp     x22, #0x5236000
02686048: d62e47f9 ldr      x22, [x22, #0xe58]
0268604c: e1031faa mov      x1, xzr
02686050: e2031faa mov      x2, xzr
02686054: c00240f9 ldr      x0, [x22]
02686058: 40a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268605c: c10240f9 ldr      x1, [x22]
02686060: a30240f9 ldr      x3, [x21]
02686064: e20300aa mov      x2, x0
02686068: e00314aa mov      x0, x20
0268606c: 05905594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686070: 684a40b9 ldr      w8, [x19, #0x48]
02686074: 1f050071 cmp      w8, #1
02686078: 8b010054 b.lt     #0x26860a8
0268607c: d65801f0 adrp     x22, #0x51a1000
02686080: d69643f9 ldr      x22, [x22, #0x728]
02686084: e1031faa mov      x1, xzr
02686088: e2031faa mov      x2, xzr
0268608c: c00240f9 ldr      x0, [x22]
02686090: 32a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686094: c10240f9 ldr      x1, [x22]
02686098: a30240f9 ldr      x3, [x21]
0268609c: e20300aa mov      x2, x0
026860a0: e00314aa mov      x0, x20
026860a4: f78f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026860a8: 684e40b9 ldr      w8, [x19, #0x4c]
026860ac: 1f050071 cmp      w8, #1
026860b0: 8b010054 b.lt     #0x26860e0
026860b4: 765a01f0 adrp     x22, #0x51d5000
026860b8: d6e644f9 ldr      x22, [x22, #0x9c8]
026860bc: e1031faa mov      x1, xzr
026860c0: e2031faa mov      x2, xzr
026860c4: c00240f9 ldr      x0, [x22]
026860c8: 24a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026860cc: c10240f9 ldr      x1, [x22]
026860d0: a30240f9 ldr      x3, [x21]
026860d4: e20300aa mov      x2, x0
026860d8: e00314aa mov      x0, x20
026860dc: e98f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026860e0: 685240b9 ldr      w8, [x19, #0x50]
026860e4: 1f050071 cmp      w8, #1
026860e8: 8b010054 b.lt     #0x2686118
026860ec: 96580190 adrp     x22, #0x5196000
026860f0: d6f646f9 ldr      x22, [x22, #0xde8]
026860f4: e1031faa mov      x1, xzr
026860f8: e2031faa mov      x2, xzr
026860fc: c00240f9 ldr      x0, [x22]
02686100: 16a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686104: c10240f9 ldr      x1, [x22]
02686108: a30240f9 ldr      x3, [x21]
0268610c: e20300aa mov      x2, x0
02686110: e00314aa mov      x0, x20
02686114: db8f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686118: 685640b9 ldr      w8, [x19, #0x54]
0268611c: 1f050071 cmp      w8, #1
02686120: 8b010054 b.lt     #0x2686150
02686124: 765d01b0 adrp     x22, #0x5233000
02686128: d6da41f9 ldr      x22, [x22, #0x3b0]
0268612c: e1031faa mov      x1, xzr
02686130: e2031faa mov      x2, xzr
02686134: c00240f9 ldr      x0, [x22]
02686138: 08a81f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268613c: c10240f9 ldr      x1, [x22]
02686140: a30240f9 ldr      x3, [x21]
02686144: e20300aa mov      x2, x0
02686148: e00314aa mov      x0, x20
0268614c: cd8f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686150: 685a40b9 ldr      w8, [x19, #0x58]
02686154: 1f050071 cmp      w8, #1
02686158: 8b010054 b.lt     #0x2686188
0268615c: 765901b0 adrp     x22, #0x51b3000
02686160: d6e641f9 ldr      x22, [x22, #0x3c8]
02686164: e1031faa mov      x1, xzr
02686168: e2031faa mov      x2, xzr
0268616c: c00240f9 ldr      x0, [x22]
02686170: faa71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686174: c10240f9 ldr      x1, [x22]
02686178: a30240f9 ldr      x3, [x21]
0268617c: e20300aa mov      x2, x0
02686180: e00314aa mov      x0, x20
02686184: bf8f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686188: 685e40b9 ldr      w8, [x19, #0x5c]
0268618c: 1f050071 cmp      w8, #1
02686190: 8b010054 b.lt     #0x26861c0
02686194: d65b01f0 adrp     x22, #0x5201000
02686198: d69a44f9 ldr      x22, [x22, #0x930]
0268619c: e1031faa mov      x1, xzr
026861a0: e2031faa mov      x2, xzr
026861a4: c00240f9 ldr      x0, [x22]
026861a8: eca71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026861ac: c10240f9 ldr      x1, [x22]
026861b0: a30240f9 ldr      x3, [x21]
026861b4: e20300aa mov      x2, x0
026861b8: e00314aa mov      x0, x20
026861bc: b18f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026861c0: 686240b9 ldr      w8, [x19, #0x60]
026861c4: 1f050071 cmp      w8, #1
026861c8: 8b010054 b.lt     #0x26861f8
026861cc: b65b01f0 adrp     x22, #0x51fd000
026861d0: d61645f9 ldr      x22, [x22, #0xa28]
026861d4: e1031faa mov      x1, xzr
026861d8: e2031faa mov      x2, xzr
026861dc: c00240f9 ldr      x0, [x22]
026861e0: dea71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026861e4: c10240f9 ldr      x1, [x22]
026861e8: a30240f9 ldr      x3, [x21]
026861ec: e20300aa mov      x2, x0
026861f0: e00314aa mov      x0, x20
026861f4: a38f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026861f8: 686640b9 ldr      w8, [x19, #0x64]
026861fc: 1f050071 cmp      w8, #1
02686200: 8b010054 b.lt     #0x2686230
02686204: 965901b0 adrp     x22, #0x51b7000
02686208: d62a44f9 ldr      x22, [x22, #0x850]
0268620c: e1031faa mov      x1, xzr
02686210: e2031faa mov      x2, xzr
02686214: c00240f9 ldr      x0, [x22]
02686218: d0a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268621c: c10240f9 ldr      x1, [x22]
02686220: a30240f9 ldr      x3, [x21]
02686224: e20300aa mov      x2, x0
02686228: e00314aa mov      x0, x20
0268622c: 958f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686230: 687a40b9 ldr      w8, [x19, #0x78]
02686234: 1f050071 cmp      w8, #1
02686238: 8b010054 b.lt     #0x2686268
0268623c: 965801b0 adrp     x22, #0x5197000
02686240: d64a41f9 ldr      x22, [x22, #0x290]
02686244: e1031faa mov      x1, xzr
02686248: e2031faa mov      x2, xzr
0268624c: c00240f9 ldr      x0, [x22]
02686250: c2a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686254: c10240f9 ldr      x1, [x22]
02686258: a30240f9 ldr      x3, [x21]
0268625c: e20300aa mov      x2, x0
02686260: e00314aa mov      x0, x20
02686264: 878f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686268: 686a40b9 ldr      w8, [x19, #0x68]
0268626c: 1f050071 cmp      w8, #1
02686270: 8b010054 b.lt     #0x26862a0
02686274: 165c01b0 adrp     x22, #0x5207000
02686278: d68e46f9 ldr      x22, [x22, #0xd18]
0268627c: e1031faa mov      x1, xzr
02686280: e2031faa mov      x2, xzr
02686284: c00240f9 ldr      x0, [x22]
02686288: b4a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268628c: c10240f9 ldr      x1, [x22]
02686290: a30240f9 ldr      x3, [x21]
02686294: e20300aa mov      x2, x0
02686298: e00314aa mov      x0, x20
0268629c: 798f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026862a0: 686e40b9 ldr      w8, [x19, #0x6c]
026862a4: 1f050071 cmp      w8, #1
026862a8: 8b010054 b.lt     #0x26862d8
026862ac: d65d0190 adrp     x22, #0x523e000
026862b0: d6ca42f9 ldr      x22, [x22, #0x590]
026862b4: e1031faa mov      x1, xzr
026862b8: e2031faa mov      x2, xzr
026862bc: c00240f9 ldr      x0, [x22]
026862c0: a6a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026862c4: c10240f9 ldr      x1, [x22]
026862c8: a30240f9 ldr      x3, [x21]
026862cc: e20300aa mov      x2, x0
026862d0: e00314aa mov      x0, x20
026862d4: 6b8f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026862d8: 687e40b9 ldr      w8, [x19, #0x7c]
026862dc: 1f050071 cmp      w8, #1
026862e0: 8b010054 b.lt     #0x2686310
026862e4: 565c0190 adrp     x22, #0x520e000
026862e8: d6b641f9 ldr      x22, [x22, #0x368]
026862ec: e1031faa mov      x1, xzr
026862f0: e2031faa mov      x2, xzr
026862f4: c00240f9 ldr      x0, [x22]
026862f8: 98a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026862fc: c10240f9 ldr      x1, [x22]
02686300: a30240f9 ldr      x3, [x21]
02686304: e20300aa mov      x2, x0
02686308: e00314aa mov      x0, x20
0268630c: 5d8f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686310: 688240b9 ldr      w8, [x19, #0x80]
02686314: 1f050071 cmp      w8, #1
02686318: 8b010054 b.lt     #0x2686348
0268631c: 965b01f0 adrp     x22, #0x51f9000
02686320: d64a41f9 ldr      x22, [x22, #0x290]
02686324: e1031faa mov      x1, xzr
02686328: e2031faa mov      x2, xzr
0268632c: c00240f9 ldr      x0, [x22]
02686330: 8aa71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686334: c10240f9 ldr      x1, [x22]
02686338: a30240f9 ldr      x3, [x21]
0268633c: e20300aa mov      x2, x0
02686340: e00314aa mov      x0, x20
02686344: 4f8f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686348: 688640b9 ldr      w8, [x19, #0x84]
0268634c: 1f050071 cmp      w8, #1
02686350: 8b010054 b.lt     #0x2686380
02686354: d65801b0 adrp     x22, #0x519f000
02686358: d64642f9 ldr      x22, [x22, #0x488]
0268635c: e1031faa mov      x1, xzr
02686360: e2031faa mov      x2, xzr
02686364: c00240f9 ldr      x0, [x22]
02686368: 7ca71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268636c: c10240f9 ldr      x1, [x22]
02686370: a30240f9 ldr      x3, [x21]
02686374: e20300aa mov      x2, x0
02686378: e00314aa mov      x0, x20
0268637c: 418f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686380: 688a40b9 ldr      w8, [x19, #0x88]
02686384: 1f050071 cmp      w8, #1
02686388: 8b010054 b.lt     #0x26863b8
0268638c: 365b01b0 adrp     x22, #0x51eb000
02686390: d69e42f9 ldr      x22, [x22, #0x538]
02686394: e1031faa mov      x1, xzr
02686398: e2031faa mov      x2, xzr
0268639c: c00240f9 ldr      x0, [x22]
026863a0: 6ea71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026863a4: c10240f9 ldr      x1, [x22]
026863a8: a30240f9 ldr      x3, [x21]
026863ac: e20300aa mov      x2, x0
026863b0: e00314aa mov      x0, x20
026863b4: 338f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026863b8: 688e40b9 ldr      w8, [x19, #0x8c]
026863bc: 1f050071 cmp      w8, #1
026863c0: 8b010054 b.lt     #0x26863f0
026863c4: b65a01b0 adrp     x22, #0x51db000
026863c8: d66246f9 ldr      x22, [x22, #0xcc0]
026863cc: e1031faa mov      x1, xzr
026863d0: e2031faa mov      x2, xzr
026863d4: c00240f9 ldr      x0, [x22]
026863d8: 60a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026863dc: c10240f9 ldr      x1, [x22]
026863e0: a30240f9 ldr      x3, [x21]
026863e4: e20300aa mov      x2, x0
026863e8: e00314aa mov      x0, x20
026863ec: 258f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026863f0: 689240b9 ldr      w8, [x19, #0x90]
026863f4: 1f050071 cmp      w8, #1
026863f8: 8b010054 b.lt     #0x2686428
026863fc: b65d01f0 adrp     x22, #0x523d000
02686400: d65640f9 ldr      x22, [x22, #0xa8]
02686404: e1031faa mov      x1, xzr
02686408: e2031faa mov      x2, xzr
0268640c: c00240f9 ldr      x0, [x22]
02686410: 52a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686414: c10240f9 ldr      x1, [x22]
02686418: a30240f9 ldr      x3, [x21]
0268641c: e20300aa mov      x2, x0
02686420: e00314aa mov      x0, x20
02686424: 178f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686428: 689640b9 ldr      w8, [x19, #0x94]
0268642c: 1f050071 cmp      w8, #1
02686430: 8b010054 b.lt     #0x2686460
02686434: 365901f0 adrp     x22, #0x51ad000
02686438: d67243f9 ldr      x22, [x22, #0x6e0]
0268643c: e1031faa mov      x1, xzr
02686440: e2031faa mov      x2, xzr
02686444: c00240f9 ldr      x0, [x22]
02686448: 44a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268644c: c10240f9 ldr      x1, [x22]
02686450: a30240f9 ldr      x3, [x21]
02686454: e20300aa mov      x2, x0
02686458: e00314aa mov      x0, x20
0268645c: 098f5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686460: 68a240b9 ldr      w8, [x19, #0xa0]
02686464: 1f050071 cmp      w8, #1
02686468: 8b010054 b.lt     #0x2686498
0268646c: 165b01d0 adrp     x22, #0x51e8000
02686470: d66a40f9 ldr      x22, [x22, #0xd0]
02686474: e1031faa mov      x1, xzr
02686478: e2031faa mov      x2, xzr
0268647c: c00240f9 ldr      x0, [x22]
02686480: 36a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686484: c10240f9 ldr      x1, [x22]
02686488: a30240f9 ldr      x3, [x21]
0268648c: e20300aa mov      x2, x0
02686490: e00314aa mov      x0, x20
02686494: fb8e5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686498: 68b640b9 ldr      w8, [x19, #0xb4]
0268649c: 1f050071 cmp      w8, #1
026864a0: 8b010054 b.lt     #0x26864d0
026864a4: 565a01b0 adrp     x22, #0x51cf000
026864a8: d68a46f9 ldr      x22, [x22, #0xd10]
026864ac: e1031faa mov      x1, xzr
026864b0: e2031faa mov      x2, xzr
026864b4: c00240f9 ldr      x0, [x22]
026864b8: 28a71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026864bc: c10240f9 ldr      x1, [x22]
026864c0: a30240f9 ldr      x3, [x21]
026864c4: e20300aa mov      x2, x0
026864c8: e00314aa mov      x0, x20
026864cc: ed8e5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026864d0: 68ba40b9 ldr      w8, [x19, #0xb8]
026864d4: 1f050071 cmp      w8, #1
026864d8: 8b010054 b.lt     #0x2686508
026864dc: d65c01b0 adrp     x22, #0x521f000
026864e0: d6ca46f9 ldr      x22, [x22, #0xd90]
026864e4: e1031faa mov      x1, xzr
026864e8: e2031faa mov      x2, xzr
026864ec: c00240f9 ldr      x0, [x22]
026864f0: 1aa71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
026864f4: c10240f9 ldr      x1, [x22]
026864f8: a30240f9 ldr      x3, [x21]
026864fc: e20300aa mov      x2, x0
02686500: e00314aa mov      x0, x20
02686504: df8e5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686508: 68ce40b9 ldr      w8, [x19, #0xcc]
0268650c: 1f050071 cmp      w8, #1
02686510: 8b010054 b.lt     #0x2686540
02686514: b65a01f0 adrp     x22, #0x51dd000
02686518: d66e47f9 ldr      x22, [x22, #0xed8]
0268651c: e1031faa mov      x1, xzr
02686520: e2031faa mov      x2, xzr
02686524: c00240f9 ldr      x0, [x22]
02686528: 0ca71f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268652c: c10240f9 ldr      x1, [x22]
02686530: a30240f9 ldr      x3, [x21]
02686534: e20300aa mov      x2, x0
02686538: e00314aa mov      x0, x20
0268653c: d18e5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686540: 687240b9 ldr      w8, [x19, #0x70]
02686544: 1f050071 cmp      w8, #1
02686548: 8b010054 b.lt     #0x2686578
0268654c: f65b0190 adrp     x22, #0x5202000
02686550: d6da43f9 ldr      x22, [x22, #0x7b0]
02686554: e1031faa mov      x1, xzr
02686558: e2031faa mov      x2, xzr
0268655c: c00240f9 ldr      x0, [x22]
02686560: fea61f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
02686564: c10240f9 ldr      x1, [x22]
02686568: a30240f9 ldr      x3, [x21]
0268656c: e20300aa mov      x2, x0
02686570: e00314aa mov      x0, x20
02686574: c38e5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
02686578: 687640b9 ldr      w8, [x19, #0x74]
0268657c: 1f050071 cmp      w8, #1
02686580: cb010054 b.lt     #0x26865b8
02686584: d35c01d0 adrp     x19, #0x5220000
02686588: 73b647f9 ldr      x19, [x19, #0xf68]
0268658c: e1031faa mov      x1, xzr
02686590: e2031faa mov      x2, xzr
02686594: 600240f9 ldr      x0, [x19]
02686598: f0a61f94 bl       #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
0268659c: 610240f9 ldr      x1, [x19]
026865a0: a30240f9 ldr      x3, [x21]
026865a4: e20300aa mov      x2, x0
026865a8: e00314aa mov      x0, x20
026865ac: b58e5594 bl       #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
026865b0: 02000014 b        #0x26865b8 ; 
026865b4: f4031faa mov      x20, xzr
026865b8: e00314aa mov      x0, x20
026865bc: f37b42a9 ldp      x19, x30, [sp, #0x20]
026865c0: f55341a9 ldp      x21, x20, [sp, #0x10]
026865c4: f75bc3a8 ldp      x23, x22, [sp], #0x30
026865c8: c0035fd6 ret      
026865cc: 97aba497 bl       #0xfb1428 ; 
