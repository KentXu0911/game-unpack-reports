# Royal.Scenes.Home.Ui.Dialogs.DukesFortune.Scripts.DukesFortuneConfigHelper$$LoadConfig
# Linear metadata span, not a recovered full CFG.
016c3f04: ff0301d1 sub      sp, sp, #0x40
016c3f08: f75b01a9 stp      x23, x22, [sp, #0x10]
016c3f0c: f55302a9 stp      x21, x20, [sp, #0x20]
016c3f10: f37b03a9 stp      x19, x30, [sp, #0x30]
016c3f14: b5f501d0 adrp     x21, #0x5579000
016c3f18: 14d801b0 adrp     x20, #0x51c4000
016c3f1c: a86a5b39 ldrb     w8, [x21, #0x6da]
016c3f20: 945247f9 ldr      x20, [x20, #0xea0]
016c3f24: f30300aa mov      x19, x0
016c3f28: c8030037 tbnz     w8, #0, #0x16c3fa0
016c3f2c: e0da01f0 adrp     x0, #0x5222000
016c3f30: 00ec42f9 ldr      x0, [x0, #0x5d8]
016c3f34: f3b4e397 bl       #0xfb1300 ; 
016c3f38: 00da01b0 adrp     x0, #0x5204000
016c3f3c: 00bc47f9 ldr      x0, [x0, #0xf78]
016c3f40: f0b4e397 bl       #0xfb1300 ; 
016c3f44: 80d901d0 adrp     x0, #0x51f5000
016c3f48: 002446f9 ldr      x0, [x0, #0xc48]
016c3f4c: edb4e397 bl       #0xfb1300 ; 
016c3f50: a0db01b0 adrp     x0, #0x5238000
016c3f54: 009446f9 ldr      x0, [x0, #0xd28]
016c3f58: eab4e397 bl       #0xfb1300 ; 
016c3f5c: 20d70190 adrp     x0, #0x51a7000
016c3f60: 006044f9 ldr      x0, [x0, #0x8c0]
016c3f64: e7b4e397 bl       #0xfb1300 ; 
016c3f68: c0db0190 adrp     x0, #0x523b000
016c3f6c: 003443f9 ldr      x0, [x0, #0x668]
016c3f70: e4b4e397 bl       #0xfb1300 ; 
016c3f74: 20d801b0 adrp     x0, #0x51c8000
016c3f78: 009041f9 ldr      x0, [x0, #0x320]
016c3f7c: e1b4e397 bl       #0xfb1300 ; 
016c3f80: 00d801b0 adrp     x0, #0x51c4000
016c3f84: 005047f9 ldr      x0, [x0, #0xea0]
016c3f88: deb4e397 bl       #0xfb1300 ; 
016c3f8c: 40d901f0 adrp     x0, #0x51ee000
016c3f90: 00f045f9 ldr      x0, [x0, #0xbe0]
016c3f94: dbb4e397 bl       #0xfb1300 ; 
016c3f98: 28008052 mov      w8, #1
016c3f9c: a86a1b39 strb     w8, [x21, #0x6da]
016c3fa0: 800240f9 ldr      x0, [x20]
016c3fa4: 96d901d0 adrp     x22, #0x51f5000
016c3fa8: f5da01f0 adrp     x21, #0x5222000
016c3fac: d62646f9 ldr      x22, [x22, #0xc48]
016c3fb0: b5ee42f9 ldr      x21, [x21, #0x5d8]
016c3fb4: e1031faa mov      x1, xzr
016c3fb8: e2031faa mov      x2, xzr
016c3fbc: f46f5e94 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
016c3fc0: e1031faa mov      x1, xzr
016c3fc4: f40300aa mov      x20, x0
016c3fc8: f50c1994 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
016c3fcc: 80050036 tbz      w0, #0, #0x16c407c
016c3fd0: 28d70190 adrp     x8, #0x51a7000
016c3fd4: a9db01b0 adrp     x9, #0x5238000
016c3fd8: 086144f9 ldr      x8, [x8, #0x8c0]
016c3fdc: 299546f9 ldr      x9, [x9, #0xd28]
016c3fe0: 000140f9 ldr      x0, [x8]
016c3fe4: 210140f9 ldr      x1, [x9]
016c3fe8: 3ef73b94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
016c3fec: 600c00b4 cbz      x0, #0x16c4178
016c3ff0: e1031faa mov      x1, xzr
016c3ff4: 67ff9894 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
016c3ff8: c10240f9 ldr      x1, [x22]
016c3ffc: ebe03994 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
016c4000: e10300aa mov      x1, x0
016c4004: e00313aa mov      x0, x19
016c4008: 018c02f8 str      x1, [x0, #0x28]!
016c400c: a8b4e397 bl       #0xfb12ac ; 
016c4010: b40240f9 ldr      x20, [x21]
016c4014: 881e40f9 ldr      x8, [x20, #0x38]
016c4018: 000140f9 ldr      x0, [x8]
016c401c: 08c84439 ldrb     w8, [x0, #0x132]
016c4020: 48000037 tbnz     w8, #0, #0x16c4028
016c4024: f0f3e297 bl       #0xf80fe4 ; 
016c4028: 08e040b9 ldr      w8, [x0, #0xe0]
016c402c: 48000035 cbnz     w8, #0x16c4034
016c4030: f5b4e397 bl       #0xfb1404 ; 
016c4034: 881e40f9 ldr      x8, [x20, #0x38]
016c4038: 34d80190 adrp     x20, #0x51c8000
016c403c: 000140f9 ldr      x0, [x8]
016c4040: 08c84439 ldrb     w8, [x0, #0x132]
016c4044: 949241f9 ldr      x20, [x20, #0x320]
016c4048: 48000037 tbnz     w8, #0, #0x16c4050
016c404c: e6f3e297 bl       #0xf80fe4 ; 
016c4050: 085c40f9 ldr      x8, [x0, #0xb8]
016c4054: 820240f9 ldr      x2, [x20]
016c4058: e00313aa mov      x0, x19
016c405c: f37b43a9 ldp      x19, x30, [sp, #0x30]
016c4060: 030140f9 ldr      x3, [x8]
016c4064: f55342a9 ldp      x21, x20, [sp, #0x20]
016c4068: f75b41a9 ldp      x23, x22, [sp, #0x10]
016c406c: 01078052 mov      w1, #0x38
016c4070: e4031faa mov      x4, xzr
016c4074: ff030191 add      sp, sp, #0x40
016c4078: 2af24414 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
016c407c: c10240f9 ldr      x1, [x22]
016c4080: 57d901d0 adrp     x23, #0x51ee000
016c4084: f7f245f9 ldr      x23, [x23, #0xbe0]
016c4088: e00314aa mov      x0, x20
016c408c: c7e03994 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
016c4090: f40313aa mov      x20, x19
016c4094: 808e02f8 str      x0, [x20, #0x28]!
016c4098: e10300aa mov      x1, x0
016c409c: e00314aa mov      x0, x20
016c40a0: 83b4e397 bl       #0xfb12ac ; 
016c40a4: e00240f9 ldr      x0, [x23]
016c40a8: 960240f9 ldr      x22, [x20]
016c40ac: e1031f2a mov      w1, wzr
016c40b0: e2031faa mov      x2, xzr
016c40b4: 22705e94 bl       #0x2e6013c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetInt
016c40b8: 160600b4 cbz      x22, #0x16c4178
016c40bc: c01200b9 str      w0, [x22, #0x10]
016c40c0: 880240f9 ldr      x8, [x20]
016c40c4: a80500b4 cbz      x8, #0x16c4178
016c40c8: 09da0190 adrp     x9, #0x5204000
016c40cc: 29bd47f9 ldr      x9, [x9, #0xf78]
016c40d0: 081140b9 ldr      w8, [x8, #0x10]
016c40d4: b4db01f0 adrp     x20, #0x523b000
016c40d8: e1330091 add      x1, sp, #0xc
016c40dc: 200140f9 ldr      x0, [x9]
016c40e0: 943643f9 ldr      x20, [x20, #0x668]
016c40e4: e80f00b9 str      w8, [sp, #0xc]
016c40e8: c9b4e397 bl       #0xfb140c ; 
016c40ec: 880240f9 ldr      x8, [x20]
016c40f0: e10300aa mov      x1, x0
016c40f4: e2031faa mov      x2, xzr
016c40f8: e00308aa mov      x0, x8
016c40fc: b7e71894 bl       #0x1cfdfd8 ; System.String$$Format
016c4100: b50240f9 ldr      x21, [x21]
016c4104: f40300aa mov      x20, x0
016c4108: a81e40f9 ldr      x8, [x21, #0x38]
016c410c: 080140f9 ldr      x8, [x8]
016c4110: 09c94439 ldrb     w9, [x8, #0x132]
016c4114: 89000037 tbnz     w9, #0, #0x16c4124
016c4118: e00308aa mov      x0, x8
016c411c: b2f3e297 bl       #0xf80fe4 ; 
016c4120: e80300aa mov      x8, x0
016c4124: 09e140b9 ldr      w9, [x8, #0xe0]
016c4128: 69000035 cbnz     w9, #0x16c4134
016c412c: e00308aa mov      x0, x8
016c4130: b5b4e397 bl       #0xfb1404 ; 
016c4134: a81e40f9 ldr      x8, [x21, #0x38]
016c4138: 000140f9 ldr      x0, [x8]
016c413c: 08c84439 ldrb     w8, [x0, #0x132]
016c4140: 48000037 tbnz     w8, #0, #0x16c4148
016c4144: a8f3e297 bl       #0xf80fe4 ; 
016c4148: 085c40f9 ldr      x8, [x0, #0xb8]
016c414c: 01078052 mov      w1, #0x38
016c4150: e00313aa mov      x0, x19
016c4154: e20314aa mov      x2, x20
016c4158: 030140f9 ldr      x3, [x8]
016c415c: e4031faa mov      x4, xzr
016c4160: f0f14494 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
016c4164: f37b43a9 ldp      x19, x30, [sp, #0x30]
016c4168: f55342a9 ldp      x21, x20, [sp, #0x20]
016c416c: f75b41a9 ldp      x23, x22, [sp, #0x10]
016c4170: ff030191 add      sp, sp, #0x40
016c4174: c0035fd6 ret      
016c4178: acb4e397 bl       #0xfb1428 ; 
