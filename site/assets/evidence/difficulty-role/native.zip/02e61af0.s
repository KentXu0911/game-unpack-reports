# Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableJackpotScenariosTable$$DuplicateDataFromAllJackpotScenariosTable
# Linear metadata span, not a recovered full CFG.
02e61af0: ff8301d1 sub      sp, sp, #0x60
02e61af4: f81300f9 str      x24, [sp, #0x20]
02e61af8: f75b03a9 stp      x23, x22, [sp, #0x30]
02e61afc: f55304a9 stp      x21, x20, [sp, #0x40]
02e61b00: f37b05a9 stp      x19, x30, [sp, #0x50]
02e61b04: 143901f0 adrp     x20, #0x5584000
02e61b08: 88ce6039 ldrb     w8, [x20, #0x833]
02e61b0c: f30300aa mov      x19, x0
02e61b10: c8000037 tbnz     w8, #0, #0x2e61b28
02e61b14: 001c01b0 adrp     x0, #0x51e2000
02e61b18: 00ac41f9 ldr      x0, [x0, #0x358]
02e61b1c: f93d8597 bl       #0xfb1300 ; 
02e61b20: 28008052 mov      w8, #1
02e61b24: 88ce2039 strb     w8, [x20, #0x833]
02e61b28: ff7f01a9 stp      xzr, xzr, [sp, #0x10]
02e61b2c: 330600b4 cbz      x19, #0x2e61bf0
02e61b30: e00313aa mov      x0, x19
02e61b34: e1031faa mov      x1, xzr
02e61b38: c7a61894 bl       #0x348b654 ; Royal.Scenes.Start.Context.Units.FeatureBundle.DragonNestScenarioBundle$$AllJackpotScenariosDataText
02e61b3c: a00500b4 cbz      x0, #0x2e61bf0
02e61b40: e1031faa mov      x1, xzr
02e61b44: 93883a94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02e61b48: 400500b4 cbz      x0, #0x2e61bf0
02e61b4c: 41018052 mov      w1, #0xa
02e61b50: e2031f2a mov      w2, wzr
02e61b54: e3031faa mov      x3, xzr
02e61b58: 07a1ba97 bl       #0x1d09f74 ; System.String$$Split
02e61b5c: a00400b4 cbz      x0, #0x2e61bf0
02e61b60: 171c01b0 adrp     x23, #0x51e2000
02e61b64: f7ae41f9 ldr      x23, [x23, #0x358]
02e61b68: e8430091 add      x8, sp, #0x10
02e61b6c: f30300aa mov      x19, x0
02e61b70: f6031faa mov      x22, xzr
02e61b74: 14210091 add      x20, x8, #8
02e61b78: 18800091 add      x24, x0, #0x20
02e61b7c: 681a40b9 ldr      w8, [x19, #0x18]
02e61b80: df0208eb cmp      x22, x8
02e61b84: 42030054 b.hs     #0x2e61bec
02e61b88: 017b76f8 ldr      x1, [x24, x22, lsl #3]
02e61b8c: d6060091 add      x22, x22, #1
02e61b90: e00314aa mov      x0, x20
02e61b94: f61300b9 str      w22, [sp, #0x10]
02e61b98: e10f00f9 str      x1, [sp, #0x18]
02e61b9c: c43d8597 bl       #0xfb12ac ; 
02e61ba0: a7ffff97 bl       #0x2e61a3c ; Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableJackpotScenariosTable$$get_DatabaseService
02e61ba4: f50300aa mov      x21, x0
02e61ba8: e007c03d ldr      q0, [sp, #0x10]
02e61bac: e00240f9 ldr      x0, [x23]
02e61bb0: e1030091 mov      x1, sp
02e61bb4: e003803d str      q0, [sp]
02e61bb8: 153e8597 bl       #0xfb140c ; 
02e61bbc: b50100b4 cbz      x21, #0x2e61bf0
02e61bc0: e10300aa mov      x1, x0
02e61bc4: e00315aa mov      x0, x21
02e61bc8: 0ae1ff97 bl       #0x2e59ff0 ; Royal.Infrastructure.Services.Storage.DatabaseService$$InsertOrReplace
02e61bcc: df2a00f1 cmp      x22, #0xa
02e61bd0: 61fdff54 b.ne     #0x2e61b7c
02e61bd4: f37b45a9 ldp      x19, x30, [sp, #0x50]
02e61bd8: f55344a9 ldp      x21, x20, [sp, #0x40]
02e61bdc: f75b43a9 ldp      x23, x22, [sp, #0x30]
02e61be0: f81340f9 ldr      x24, [sp, #0x20]
02e61be4: ff830191 add      sp, sp, #0x60
02e61be8: c0035fd6 ret      
02e61bec: 113e8597 bl       #0xfb1430 ; 
02e61bf0: 0e3e8597 bl       #0xfb1428 ; 
