# Royal.Player.Context.Units.SemiDynamicDifficulty$$SetAdminMode
# Linear metadata span, not a recovered full CFG.
01c854c4: c0035fd6 ret      
