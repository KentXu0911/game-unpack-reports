# Royal.Player.Context.Units.SemiDynamicDifficulty$$Reset
# Linear metadata span, not a recovered full CFG.
01c854c0: c0035fd6 ret      
