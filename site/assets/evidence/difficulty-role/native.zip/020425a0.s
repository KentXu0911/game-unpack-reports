# Royal.Scenes.Home.Ui.Dialogs.SkyRace.SkyRaceConfigHelper$$LoadConfig
# Linear metadata span, not a recovered full CFG.
020425a0: ff0301d1 sub      sp, sp, #0x40
020425a4: f75b01a9 stp      x23, x22, [sp, #0x10]
020425a8: f55302a9 stp      x21, x20, [sp, #0x20]
020425ac: f37b03a9 stp      x19, x30, [sp, #0x30]
020425b0: d4a901f0 adrp     x20, #0x557d000
020425b4: 886e4539 ldrb     w8, [x20, #0x15b]
020425b8: f30300aa mov      x19, x0
020425bc: 28040037 tbnz     w8, #0, #0x2042640
020425c0: 008f0190 adrp     x0, #0x5222000
020425c4: 00ec42f9 ldr      x0, [x0, #0x5d8]
020425c8: 4ebbbd97 bl       #0xfb1300 ; 
020425cc: a08e0190 adrp     x0, #0x5216000
020425d0: 001c44f9 ldr      x0, [x0, #0x838]
020425d4: 4bbbbd97 bl       #0xfb1300 ; 
020425d8: 208d0190 adrp     x0, #0x51e6000
020425dc: 007840f9 ldr      x0, [x0, #0xf0]
020425e0: 48bbbd97 bl       #0xfb1300 ; 
020425e4: 008e01d0 adrp     x0, #0x5204000
020425e8: 00bc47f9 ldr      x0, [x0, #0xf78]
020425ec: 45bbbd97 bl       #0xfb1300 ; 
020425f0: a08c01f0 adrp     x0, #0x51d9000
020425f4: 001043f9 ldr      x0, [x0, #0x620]
020425f8: 42bbbd97 bl       #0xfb1300 ; 
020425fc: a08f01d0 adrp     x0, #0x5238000
02042600: 009446f9 ldr      x0, [x0, #0xd28]
02042604: 3fbbbd97 bl       #0xfb1300 ; 
02042608: 208e0190 adrp     x0, #0x5206000
0204260c: 00ac43f9 ldr      x0, [x0, #0x758]
02042610: 3cbbbd97 bl       #0xfb1300 ; 
02042614: 208d01b0 adrp     x0, #0x51e7000
02042618: 002846f9 ldr      x0, [x0, #0xc50]
0204261c: 39bbbd97 bl       #0xfb1300 ; 
02042620: 808c01b0 adrp     x0, #0x51d3000
02042624: 002440f9 ldr      x0, [x0, #0x48]
02042628: 36bbbd97 bl       #0xfb1300 ; 
0204262c: a08b01d0 adrp     x0, #0x51b8000
02042630: 00f841f9 ldr      x0, [x0, #0x3f0]
02042634: 33bbbd97 bl       #0xfb1300 ; 
02042638: 28008052 mov      w8, #1
0204263c: 886e0539 strb     w8, [x20, #0x15b]
02042640: 681240f9 ldr      x8, [x19, #0x20]
02042644: a81200b4 cbz      x8, #0x2042898
02042648: 081540f9 ldr      x8, [x8, #0x28]
0204264c: 681200b4 cbz      x8, #0x2042898
02042650: 143d40f9 ldr      x20, [x8, #0x78]
02042654: b58c01f0 adrp     x21, #0x51d9000
02042658: 168f0190 adrp     x22, #0x5222000
0204265c: b51243f9 ldr      x21, [x21, #0x620]
02042660: d6ee42f9 ldr      x22, [x22, #0x5d8]
02042664: e00314aa mov      x0, x20
02042668: e1031faa mov      x1, xzr
0204266c: 4c13f397 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
02042670: e0050036 tbz      w0, #0, #0x204272c
02042674: d40240f9 ldr      x20, [x22]
02042678: 881e40f9 ldr      x8, [x20, #0x38]
0204267c: 000140f9 ldr      x0, [x8]
02042680: 08c84439 ldrb     w8, [x0, #0x132]
02042684: 48000037 tbnz     w8, #0, #0x204268c
02042688: 57fabc97 bl       #0xf80fe4 ; 
0204268c: 08e040b9 ldr      w8, [x0, #0xe0]
02042690: 48000035 cbnz     w8, #0x2042698
02042694: 5cbbbd97 bl       #0xfb1404 ; 
02042698: 881e40f9 ldr      x8, [x20, #0x38]
0204269c: 378e0190 adrp     x23, #0x5206000
020426a0: b68b01d0 adrp     x22, #0x51b8000
020426a4: b48f01d0 adrp     x20, #0x5238000
020426a8: 000140f9 ldr      x0, [x8]
020426ac: 08c84439 ldrb     w8, [x0, #0x132]
020426b0: f7ae43f9 ldr      x23, [x23, #0x758]
020426b4: d6fa41f9 ldr      x22, [x22, #0x3f0]
020426b8: 949646f9 ldr      x20, [x20, #0xd28]
020426bc: 48000037 tbnz     w8, #0, #0x20426c4
020426c0: 49fabc97 bl       #0xf80fe4 ; 
020426c4: 085c40f9 ldr      x8, [x0, #0xb8]
020426c8: e20240f9 ldr      x2, [x23]
020426cc: 21038052 mov      w1, #0x19
020426d0: e00313aa mov      x0, x19
020426d4: 030140f9 ldr      x3, [x8]
020426d8: e4031faa mov      x4, xzr
020426dc: 91f81e94 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
020426e0: c00240f9 ldr      x0, [x22]
020426e4: 810240f9 ldr      x1, [x20]
020426e8: 7efd1594 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
020426ec: 600d00b4 cbz      x0, #0x2042898
020426f0: e1031faa mov      x1, xzr
020426f4: a7057394 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
020426f8: a10240f9 ldr      x1, [x21]
020426fc: 2be71394 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02042700: 608e01f8 str      x0, [x19, #0x18]!
02042704: e10300aa mov      x1, x0
02042708: e00313aa mov      x0, x19
0204270c: e8babd97 bl       #0xfb12ac ; 
02042710: 28008052 mov      w8, #1
02042714: 68821f38 sturb    w8, [x19, #-8]
02042718: f37b43a9 ldp      x19, x30, [sp, #0x30]
0204271c: f55342a9 ldp      x21, x20, [sp, #0x20]
02042720: f75b41a9 ldp      x23, x22, [sp, #0x10]
02042724: ff030191 add      sp, sp, #0x40
02042728: c0035fd6 ret      
0204272c: a10240f9 ldr      x1, [x21]
02042730: e00314aa mov      x0, x20
02042734: 1de71394 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02042738: c00700b4 cbz      x0, #0x2042830
0204273c: 080c40f9 ldr      x8, [x0, #0x18]
02042740: e10300aa mov      x1, x0
02042744: a80a00b4 cbz      x8, #0x2042898
02042748: 080d40f9 ldr      x8, [x8, #0x18]
0204274c: 280700b4 cbz      x8, #0x2042830
02042750: 281440b9 ldr      w8, [x1, #0x14]
02042754: 1f050071 cmp      w8, #1
02042758: cb060054 b.lt     #0x2042830
0204275c: f40313aa mov      x20, x19
02042760: 818e01f8 str      x1, [x20, #0x18]!
02042764: e00314aa mov      x0, x20
02042768: d1babd97 bl       #0xfb12ac ; 
0204276c: 880640f9 ldr      x8, [x20, #8]
02042770: 480900b4 cbz      x8, #0x2042898
02042774: 081540f9 ldr      x8, [x8, #0x28]
02042778: 080900b4 cbz      x8, #0x2042898
0204277c: 890240f9 ldr      x9, [x20]
02042780: c90800b4 cbz      x9, #0x2042898
02042784: 088140b9 ldr      w8, [x8, #0x80]
02042788: 0a8e01d0 adrp     x10, #0x5204000
0204278c: 4abd47f9 ldr      x10, [x10, #0xf78]
02042790: 2b008052 mov      w11, #1
02042794: 281100b9 str      w8, [x9, #0x10]
02042798: 6b420039 strb     w11, [x19, #0x10]
0204279c: 400140f9 ldr      x0, [x10]
020427a0: 348d01b0 adrp     x20, #0x51e7000
020427a4: 942a46f9 ldr      x20, [x20, #0xc50]
020427a8: e1330091 add      x1, sp, #0xc
020427ac: e80f00b9 str      w8, [sp, #0xc]
020427b0: 17bbbd97 bl       #0xfb140c ; 
020427b4: 880240f9 ldr      x8, [x20]
020427b8: e10300aa mov      x1, x0
020427bc: e2031faa mov      x2, xzr
020427c0: e00308aa mov      x0, x8
020427c4: 05eef297 bl       #0x1cfdfd8 ; System.String$$Format
020427c8: d50240f9 ldr      x21, [x22]
020427cc: f40300aa mov      x20, x0
020427d0: a81e40f9 ldr      x8, [x21, #0x38]
020427d4: 080140f9 ldr      x8, [x8]
020427d8: 09c94439 ldrb     w9, [x8, #0x132]
020427dc: 89000037 tbnz     w9, #0, #0x20427ec
020427e0: e00308aa mov      x0, x8
020427e4: 00fabc97 bl       #0xf80fe4 ; 
020427e8: e80300aa mov      x8, x0
020427ec: 09e140b9 ldr      w9, [x8, #0xe0]
020427f0: 69000035 cbnz     w9, #0x20427fc
020427f4: e00308aa mov      x0, x8
020427f8: 03bbbd97 bl       #0xfb1404 ; 
020427fc: a81e40f9 ldr      x8, [x21, #0x38]
02042800: 000140f9 ldr      x0, [x8]
02042804: 08c84439 ldrb     w8, [x0, #0x132]
02042808: 48000037 tbnz     w8, #0, #0x2042810
0204280c: f6f9bc97 bl       #0xf80fe4 ; 
02042810: 085c40f9 ldr      x8, [x0, #0xb8]
02042814: 21038052 mov      w1, #0x19
02042818: e00313aa mov      x0, x19
0204281c: e20314aa mov      x2, x20
02042820: 030140f9 ldr      x3, [x8]
02042824: e4031faa mov      x4, xzr
02042828: 3ef81e94 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0204282c: bbffff17 b        #0x2042718 ; 
02042830: a88e0190 adrp     x8, #0x5216000
02042834: 081d44f9 ldr      x8, [x8, #0x838]
02042838: 000140f9 ldr      x0, [x8]
0204283c: f7babd97 bl       #0xfb1418 ; 
02042840: c00200b4 cbz      x0, #0x2042898
02042844: 888c01b0 adrp     x8, #0x51d3000
02042848: 082540f9 ldr      x8, [x8, #0x48]
0204284c: 348d0190 adrp     x20, #0x51e6000
02042850: e2031faa mov      x2, xzr
02042854: f30300aa mov      x19, x0
02042858: 010140f9 ldr      x1, [x8]
0204285c: 947a40f9 ldr      x20, [x20, #0xf0]
02042860: 98930894 bl       #0x22676c0 ; System.Exception$$.ctor
02042864: 800240f9 ldr      x0, [x20]
02042868: 08e040b9 ldr      w8, [x0, #0xe0]
0204286c: 48000035 cbnz     w8, #0x2042874
02042870: e5babd97 bl       #0xfb1404 ; 
02042874: e00313aa mov      x0, x19
02042878: f37b43a9 ldp      x19, x30, [sp, #0x30]
0204287c: f55342a9 ldp      x21, x20, [sp, #0x20]
02042880: f75b41a9 ldp      x23, x22, [sp, #0x10]
02042884: 21038052 mov      w1, #0x19
02042888: e2031faa mov      x2, xzr
0204288c: e3031faa mov      x3, xzr
02042890: ff030191 add      sp, sp, #0x40
02042894: d45b3814 b        #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
02042898: e4babd97 bl       #0xfb1428 ; 
