# Royal.Player.Context.Units.SpaceMissionManager$$LoadConfig
# Linear metadata span, not a recovered full CFG.
01da41f8: f60f1df8 str      x22, [sp, #-0x30]!
01da41fc: f55301a9 stp      x21, x20, [sp, #0x10]
01da4200: f37b02a9 stp      x19, x30, [sp, #0x20]
01da4204: b5be01f0 adrp     x21, #0x557b000
01da4208: 34a301b0 adrp     x20, #0x5209000
01da420c: a8567b39 ldrb     w8, [x21, #0xed5]
01da4210: 948647f9 ldr      x20, [x20, #0xf08]
01da4214: f30300aa mov      x19, x0
01da4218: c8030037 tbnz     w8, #0, #0x1da4290
01da421c: e0a301d0 adrp     x0, #0x5222000
01da4220: 00ec42f9 ldr      x0, [x0, #0x5d8]
01da4224: 3734c897 bl       #0xfb1300 ; 
01da4228: 00a30190 adrp     x0, #0x5204000
01da422c: 00bc47f9 ldr      x0, [x0, #0xf78]
01da4230: 3434c897 bl       #0xfb1300 ; 
01da4234: 00a301d0 adrp     x0, #0x5206000
01da4238: 000840f9 ldr      x0, [x0, #0x10]
01da423c: 3134c897 bl       #0xfb1300 ; 
01da4240: a0a40190 adrp     x0, #0x5238000
01da4244: 009446f9 ldr      x0, [x0, #0xd28]
01da4248: 2e34c897 bl       #0xfb1300 ; 
01da424c: 60a401f0 adrp     x0, #0x5233000
01da4250: 007845f9 ldr      x0, [x0, #0xaf0]
01da4254: 2b34c897 bl       #0xfb1300 ; 
01da4258: 20a301b0 adrp     x0, #0x5209000
01da425c: 008447f9 ldr      x0, [x0, #0xf08]
01da4260: 2834c897 bl       #0xfb1300 ; 
01da4264: a0a40190 adrp     x0, #0x5238000
01da4268: 00b041f9 ldr      x0, [x0, #0x360]
01da426c: 2534c897 bl       #0xfb1300 ; 
01da4270: e0a301f0 adrp     x0, #0x5223000
01da4274: 000040f9 ldr      x0, [x0]
01da4278: 2234c897 bl       #0xfb1300 ; 
01da427c: c0a10190 adrp     x0, #0x51dc000
01da4280: 000845f9 ldr      x0, [x0, #0xa10]
01da4284: 1f34c897 bl       #0xfb1300 ; 
01da4288: 28008052 mov      w8, #1
01da428c: a8563b39 strb     w8, [x21, #0xed5]
01da4290: 800240f9 ldr      x0, [x20]
01da4294: 15a301d0 adrp     x21, #0x5206000
01da4298: b50a40f9 ldr      x21, [x21, #0x10]
01da429c: e1031faa mov      x1, xzr
01da42a0: e2031faa mov      x2, xzr
01da42a4: 3aef4294 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
01da42a8: e1031faa mov      x1, xzr
01da42ac: f40300aa mov      x20, x0
01da42b0: 3b8cfd97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01da42b4: 40020036 tbz      w0, #0, #0x1da42fc
01da42b8: c8a10190 adrp     x8, #0x51dc000
01da42bc: a9a40190 adrp     x9, #0x5238000
01da42c0: 080945f9 ldr      x8, [x8, #0xa10]
01da42c4: 299546f9 ldr      x9, [x9, #0xd28]
01da42c8: 000140f9 ldr      x0, [x8]
01da42cc: 210140f9 ldr      x1, [x9]
01da42d0: 84762094 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01da42d4: c01200b4 cbz      x0, #0x1da452c
01da42d8: e1031faa mov      x1, xzr
01da42dc: ad7e7d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01da42e0: a10240f9 ldr      x1, [x21]
01da42e4: 31601e94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01da42e8: e10300aa mov      x1, x0
01da42ec: e00313aa mov      x0, x19
01da42f0: 010c02f8 str      x1, [x0, #0x20]!
01da42f4: ee33c897 bl       #0xfb12ac ; 
01da42f8: 08000014 b        #0x1da4318 ; 
01da42fc: a10240f9 ldr      x1, [x21]
01da4300: e00314aa mov      x0, x20
01da4304: 29601e94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01da4308: e10300aa mov      x1, x0
01da430c: e00313aa mov      x0, x19
01da4310: 010c02f8 str      x1, [x0, #0x20]!
01da4314: e633c897 bl       #0xfb12ac ; 
01da4318: 681240f9 ldr      x8, [x19, #0x20]
01da431c: 881000b4 cbz      x8, #0x1da452c
01da4320: e9a301f0 adrp     x9, #0x5223000
01da4324: 6aa401f0 adrp     x10, #0x5233000
01da4328: 290140f9 ldr      x9, [x9]
01da432c: 4a7945f9 ldr      x10, [x10, #0xaf0]
01da4330: 010940f9 ldr      x1, [x8, #0x10]
01da4334: 200140f9 ldr      x0, [x9]
01da4338: 420140f9 ldr      x2, [x10]
01da433c: a6241494 bl       #0x22ad5d4 ; System.String$$Join<int>
01da4340: 681240f9 ldr      x8, [x19, #0x20]
01da4344: 480f00b4 cbz      x8, #0x1da452c
01da4348: 09a30190 adrp     x9, #0x5204000
01da434c: 29bd47f9 ldr      x9, [x9, #0xf78]
01da4350: f40300aa mov      x20, x0
01da4354: 082140b9 ldr      w8, [x8, #0x20]
01da4358: b5a40190 adrp     x21, #0x5238000
01da435c: 200140f9 ldr      x0, [x9]
01da4360: f6a301d0 adrp     x22, #0x5222000
01da4364: b5b241f9 ldr      x21, [x21, #0x360]
01da4368: d6ee42f9 ldr      x22, [x22, #0x5d8]
01da436c: e1330091 add      x1, sp, #0xc
01da4370: e80f00b9 str      w8, [sp, #0xc]
01da4374: 2634c897 bl       #0xfb140c ; 
01da4378: a80240f9 ldr      x8, [x21]
01da437c: e10300aa mov      x1, x0
01da4380: e20314aa mov      x2, x20
01da4384: e3031faa mov      x3, xzr
01da4388: e00308aa mov      x0, x8
01da438c: 4790fd97 bl       #0x1d084a8 ; System.String$$Format
01da4390: d50240f9 ldr      x21, [x22]
01da4394: f40300aa mov      x20, x0
01da4398: a81e40f9 ldr      x8, [x21, #0x38]
01da439c: 080140f9 ldr      x8, [x8]
01da43a0: 09c94439 ldrb     w9, [x8, #0x132]
01da43a4: 89000037 tbnz     w9, #0, #0x1da43b4
01da43a8: e00308aa mov      x0, x8
01da43ac: 0e73c797 bl       #0xf80fe4 ; 
01da43b0: e80300aa mov      x8, x0
01da43b4: 09e140b9 ldr      w9, [x8, #0xe0]
01da43b8: 69000035 cbnz     w9, #0x1da43c4
01da43bc: e00308aa mov      x0, x8
01da43c0: 1134c897 bl       #0xfb1404 ; 
01da43c4: a81e40f9 ldr      x8, [x21, #0x38]
01da43c8: 000140f9 ldr      x0, [x8]
01da43cc: 08c84439 ldrb     w8, [x0, #0x132]
01da43d0: 48000037 tbnz     w8, #0, #0x1da43d8
01da43d4: 0473c797 bl       #0xf80fe4 ; 
01da43d8: 085c40f9 ldr      x8, [x0, #0xb8]
01da43dc: e1038052 mov      w1, #0x1f
01da43e0: e00313aa mov      x0, x19
01da43e4: e20314aa mov      x2, x20
01da43e8: 030140f9 ldr      x3, [x8]
01da43ec: e4031faa mov      x4, xzr
01da43f0: 4c712994 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01da43f4: f37b42a9 ldp      x19, x30, [sp, #0x20]
01da43f8: f55341a9 ldp      x21, x20, [sp, #0x10]
01da43fc: f60743f8 ldr      x22, [sp], #0x30
01da4400: c0035fd6 ret      
01da4404: 3f040071 cmp      w1, #1
01da4408: f40300aa mov      x20, x0
01da440c: e10a0054 b.ne     #0x1da4568
01da4410: e00314aa mov      x0, x20
01da4414: 6f7cbc97 bl       #0xcc35d0 ; 
01da4418: f40300aa mov      x20, x0
01da441c: 80a301d0 adrp     x0, #0x5216000
01da4420: 001c44f9 ldr      x0, [x0, #0x838]
01da4424: bc33c897 bl       #0xfb1314 ; 
01da4428: 880240f9 ldr      x8, [x20]
01da442c: 010140f9 ldr      x1, [x8]
01da4430: fe34c897 bl       #0xfb1828 ; 
01da4434: e0070036 tbz      w0, #0, #0x1da4530
01da4438: 940240f9 ldr      x20, [x20]
01da443c: e17abc97 bl       #0xcc2fc0 ; 
01da4440: c0a10190 adrp     x0, #0x51dc000
01da4444: 000845f9 ldr      x0, [x0, #0xa10]
01da4448: b333c897 bl       #0xfb1314 ; 
01da444c: f50300aa mov      x21, x0
01da4450: a0a40190 adrp     x0, #0x5238000
01da4454: 009446f9 ldr      x0, [x0, #0xd28]
01da4458: af33c897 bl       #0xfb1314 ; 
01da445c: e10300aa mov      x1, x0
01da4460: e00315aa mov      x0, x21
01da4464: 1f762094 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01da4468: 200600b4 cbz      x0, #0x1da452c
01da446c: e1031faa mov      x1, xzr
01da4470: 487e7d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01da4474: f50300aa mov      x21, x0
01da4478: 00a301d0 adrp     x0, #0x5206000
01da447c: 000840f9 ldr      x0, [x0, #0x10]
01da4480: a533c897 bl       #0xfb1314 ; 
01da4484: e10300aa mov      x1, x0
01da4488: e00315aa mov      x0, x21
01da448c: c75f1e94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01da4490: e10300aa mov      x1, x0
01da4494: e00313aa mov      x0, x19
01da4498: 010c02f8 str      x1, [x0, #0x20]!
01da449c: 8433c897 bl       #0xfb12ac ; 
01da44a0: 60a401b0 adrp     x0, #0x5231000
01da44a4: 003841f9 ldr      x0, [x0, #0x270]
01da44a8: 9b33c897 bl       #0xfb1314 ; 
01da44ac: 21008052 mov      w1, #1
01da44b0: b033c897 bl       #0xfb1370 ; 
01da44b4: d40300b4 cbz      x20, #0x1da452c
01da44b8: 880240f9 ldr      x8, [x20]
01da44bc: f50300aa mov      x21, x0
01da44c0: e00314aa mov      x0, x20
01da44c4: 098558a9 ldp      x9, x1, [x8, #0x188]
01da44c8: 20013fd6 blr      x9
01da44cc: 150300b4 cbz      x21, #0x1da452c
01da44d0: f40300aa mov      x20, x0
01da44d4: c00000b4 cbz      x0, #0x1da44ec
01da44d8: a80240f9 ldr      x8, [x21]
01da44dc: e00314aa mov      x0, x20
01da44e0: 012140f9 ldr      x1, [x8, #0x40]
01da44e4: c933c897 bl       #0xfb1408 ; 
01da44e8: 600300b4 cbz      x0, #0x1da4554
01da44ec: a81a40b9 ldr      w8, [x21, #0x18]
01da44f0: 08030034 cbz      w8, #0x1da4550
01da44f4: e00315aa mov      x0, x21
01da44f8: 140c02f8 str      x20, [x0, #0x20]!
01da44fc: e10314aa mov      x1, x20
01da4500: 6b33c897 bl       #0xfb12ac ; 
01da4504: e0a301d0 adrp     x0, #0x5222000
01da4508: 009047f9 ldr      x0, [x0, #0xf20]
01da450c: 8233c897 bl       #0xfb1314 ; 
01da4510: e20300aa mov      x2, x0
01da4514: e1038052 mov      w1, #0x1f
01da4518: e00313aa mov      x0, x19
01da451c: e30315aa mov      x3, x21
01da4520: e4031faa mov      x4, xzr
01da4524: ff702994 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01da4528: 7cffff17 b        #0x1da4318 ; 
01da452c: bf33c897 bl       #0xfb1428 ; 
01da4530: 00018052 mov      w0, #8
01da4534: a379bc97 bl       #0xcc2bc0 ; 
01da4538: 880240f9 ldr      x8, [x20]
01da453c: 080000f9 str      x8, [x0]
01da4540: 018f01f0 adrp     x1, #0x4f87000
01da4544: 21603f91 add      x1, x1, #0xfd8
01da4548: e2031faa mov      x2, xzr
01da454c: 5577bc97 bl       #0xcc22a0 ; 
01da4550: b833c897 bl       #0xfb1430 ; 
01da4554: be33c897 bl       #0xfb144c ; 
01da4558: e1031faa mov      x1, xzr
01da455c: a533c897 bl       #0xfb13f0 ; 
01da4560: f40300aa mov      x20, x0
01da4564: 977abc97 bl       #0xcc2fc0 ; 
01da4568: e00314aa mov      x0, x20
01da456c: 657abc97 bl       #0xcc2f00 ; 
01da4570: 7690bc97 bl       #0xcc8748 ; 
