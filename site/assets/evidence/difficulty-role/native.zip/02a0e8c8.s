# Royal.Player.Context.Data.Persistent.UserInventory$$SetLastUpdatedSection
# Linear metadata span, not a recovered full CFG.
02a0e8c8: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
02a0e8cc: f30300aa mov      x19, x0
02a0e8d0: 005840f9 ldr      x0, [x0, #0xb0]
02a0e8d4: 42028052 mov      w2, #0x12
02a0e8d8: 43048052 mov      w3, #0x22
02a0e8dc: e4031faa mov      x4, xzr
02a0e8e0: f2d62194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e8e4: e10300aa mov      x1, x0
02a0e8e8: e00313aa mov      x0, x19
02a0e8ec: f37bc1a8 ldp      x19, x30, [sp], #0x10
02a0e8f0: 84ffff17 b        #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
