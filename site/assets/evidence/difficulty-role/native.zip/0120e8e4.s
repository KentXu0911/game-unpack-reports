# Royal.Scenes.Home.Ui.Dialogs.MissionPursuit.Scripts.MissionPursuitConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
0120e8e4: f60f1df8 str      x22, [sp, #-0x30]!
0120e8e8: f55301a9 stp      x21, x20, [sp, #0x10]
0120e8ec: f37b02a9 stp      x19, x30, [sp, #0x20]
0120e8f0: 541b02b0 adrp     x20, #0x5577000
0120e8f4: 889a5e39 ldrb     w8, [x20, #0x7a6]
0120e8f8: f30300aa mov      x19, x0
0120e8fc: c8030037 tbnz     w8, #0, #0x120e974
0120e900: a0000290 adrp     x0, #0x5222000
0120e904: 00ec42f9 ldr      x0, [x0, #0x5d8]
0120e908: 7e8af697 bl       #0xfb1300 ; 
0120e90c: 400002b0 adrp     x0, #0x5217000
0120e910: 007443f9 ldr      x0, [x0, #0x6e8]
0120e914: 7b8af697 bl       #0xfb1300 ; 
0120e918: a0fc01b0 adrp     x0, #0x51a3000
0120e91c: 00a445f9 ldr      x0, [x0, #0xb48]
0120e920: 788af697 bl       #0xfb1300 ; 
0120e924: a0ff01d0 adrp     x0, #0x5204000
0120e928: 00bc47f9 ldr      x0, [x0, #0xf78]
0120e92c: 758af697 bl       #0xfb1300 ; 
0120e930: 400002f0 adrp     x0, #0x5219000
0120e934: 009843f9 ldr      x0, [x0, #0x730]
0120e938: 728af697 bl       #0xfb1300 ; 
0120e93c: 400102d0 adrp     x0, #0x5238000
0120e940: 009446f9 ldr      x0, [x0, #0xd28]
0120e944: 6f8af697 bl       #0xfb1300 ; 
0120e948: 00fe01f0 adrp     x0, #0x51d1000
0120e94c: 000c44f9 ldr      x0, [x0, #0x818]
0120e950: 6c8af697 bl       #0xfb1300 ; 
0120e954: 20fd0190 adrp     x0, #0x51b2000
0120e958: 00e847f9 ldr      x0, [x0, #0xfd0]
0120e95c: 698af697 bl       #0xfb1300 ; 
0120e960: 200002d0 adrp     x0, #0x5214000
0120e964: 009045f9 ldr      x0, [x0, #0xb20]
0120e968: 668af697 bl       #0xfb1300 ; 
0120e96c: 28008052 mov      w8, #1
0120e970: 889a1e39 strb     w8, [x20, #0x7a6]
0120e974: 680a40f9 ldr      x8, [x19, #0x10]
0120e978: 680e00b4 cbz      x8, #0x120eb44
0120e97c: 081140f9 ldr      x8, [x8, #0x20]
0120e980: 280e00b4 cbz      x8, #0x120eb44
0120e984: 161d40f9 ldr      x22, [x8, #0x38]
0120e988: f60d00b4 cbz      x22, #0x120eb44
0120e98c: c00a40f9 ldr      x0, [x22, #0x10]
0120e990: 540002f0 adrp     x20, #0x5219000
0120e994: b5000290 adrp     x21, #0x5222000
0120e998: 949a43f9 ldr      x20, [x20, #0x730]
0120e99c: b5ee42f9 ldr      x21, [x21, #0x5d8]
0120e9a0: e1031faa mov      x1, xzr
0120e9a4: 7ee22b94 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0120e9a8: 60050036 tbz      w0, #0, #0x120ea54
0120e9ac: 28fd0190 adrp     x8, #0x51b2000
0120e9b0: 490102d0 adrp     x9, #0x5238000
0120e9b4: 08e947f9 ldr      x8, [x8, #0xfd0]
0120e9b8: 299546f9 ldr      x9, [x9, #0xd28]
0120e9bc: 000140f9 ldr      x0, [x8]
0120e9c0: 210140f9 ldr      x1, [x9]
0120e9c4: c7cc4e94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0120e9c8: e00b00b4 cbz      x0, #0x120eb44
0120e9cc: e1031faa mov      x1, xzr
0120e9d0: f0d4ab94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0120e9d4: 810240f9 ldr      x1, [x20]
0120e9d8: 74b64c94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0120e9dc: e10300aa mov      x1, x0
0120e9e0: e00313aa mov      x0, x19
0120e9e4: 018c01f8 str      x1, [x0, #0x18]!
0120e9e8: 318af697 bl       #0xfb12ac ; 
0120e9ec: b40240f9 ldr      x20, [x21]
0120e9f0: 881e40f9 ldr      x8, [x20, #0x38]
0120e9f4: 000140f9 ldr      x0, [x8]
0120e9f8: 08c84439 ldrb     w8, [x0, #0x132]
0120e9fc: 48000037 tbnz     w8, #0, #0x120ea04
0120ea00: 79c9f597 bl       #0xf80fe4 ; 
0120ea04: 08e040b9 ldr      w8, [x0, #0xe0]
0120ea08: 48000035 cbnz     w8, #0x120ea10
0120ea0c: 7e8af697 bl       #0xfb1404 ; 
0120ea10: 881e40f9 ldr      x8, [x20, #0x38]
0120ea14: 14fe01f0 adrp     x20, #0x51d1000
0120ea18: 000140f9 ldr      x0, [x8]
0120ea1c: 08c84439 ldrb     w8, [x0, #0x132]
0120ea20: 940e44f9 ldr      x20, [x20, #0x818]
0120ea24: 48000037 tbnz     w8, #0, #0x120ea2c
0120ea28: 6fc9f597 bl       #0xf80fe4 ; 
0120ea2c: 085c40f9 ldr      x8, [x0, #0xb8]
0120ea30: 820240f9 ldr      x2, [x20]
0120ea34: e00313aa mov      x0, x19
0120ea38: f37b42a9 ldp      x19, x30, [sp, #0x20]
0120ea3c: 030140f9 ldr      x3, [x8]
0120ea40: f55341a9 ldp      x21, x20, [sp, #0x10]
0120ea44: 81078052 mov      w1, #0x3c
0120ea48: e4031faa mov      x4, xzr
0120ea4c: f60743f8 ldr      x22, [sp], #0x30
0120ea50: b4c75714 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0120ea54: c00a40f9 ldr      x0, [x22, #0x10]
0120ea58: 810240f9 ldr      x1, [x20]
0120ea5c: 53b64c94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0120ea60: f40313aa mov      x20, x19
0120ea64: 808e01f8 str      x0, [x20, #0x18]!
0120ea68: e10300aa mov      x1, x0
0120ea6c: e00314aa mov      x0, x20
0120ea70: 0f8af697 bl       #0xfb12ac ; 
0120ea74: 88825ff8 ldur     x8, [x20, #-8]
0120ea78: 680600b4 cbz      x8, #0x120eb44
0120ea7c: 081140f9 ldr      x8, [x8, #0x20]
0120ea80: 280600b4 cbz      x8, #0x120eb44
0120ea84: 082140f9 ldr      x8, [x8, #0x40]
0120ea88: e80500b4 cbz      x8, #0x120eb44
0120ea8c: 890240f9 ldr      x9, [x20]
0120ea90: a90500b4 cbz      x9, #0x120eb44
0120ea94: 081140b9 ldr      w8, [x8, #0x10]
0120ea98: aaff01d0 adrp     x10, #0x5204000
0120ea9c: 4abd47f9 ldr      x10, [x10, #0xf78]
0120eaa0: 340002d0 adrp     x20, #0x5214000
0120eaa4: 281100b9 str      w8, [x9, #0x10]
0120eaa8: e1330091 add      x1, sp, #0xc
0120eaac: 400140f9 ldr      x0, [x10]
0120eab0: 949245f9 ldr      x20, [x20, #0xb20]
0120eab4: e80f00b9 str      w8, [sp, #0xc]
0120eab8: 558af697 bl       #0xfb140c ; 
0120eabc: 880240f9 ldr      x8, [x20]
0120eac0: e10300aa mov      x1, x0
0120eac4: e2031faa mov      x2, xzr
0120eac8: e00308aa mov      x0, x8
0120eacc: 43bd2b94 bl       #0x1cfdfd8 ; System.String$$Format
0120ead0: b50240f9 ldr      x21, [x21]
0120ead4: f40300aa mov      x20, x0
0120ead8: a81e40f9 ldr      x8, [x21, #0x38]
0120eadc: 080140f9 ldr      x8, [x8]
0120eae0: 09c94439 ldrb     w9, [x8, #0x132]
0120eae4: 89000037 tbnz     w9, #0, #0x120eaf4
0120eae8: e00308aa mov      x0, x8
0120eaec: 3ec9f597 bl       #0xf80fe4 ; 
0120eaf0: e80300aa mov      x8, x0
0120eaf4: 09e140b9 ldr      w9, [x8, #0xe0]
0120eaf8: 69000035 cbnz     w9, #0x120eb04
0120eafc: e00308aa mov      x0, x8
0120eb00: 418af697 bl       #0xfb1404 ; 
0120eb04: a81e40f9 ldr      x8, [x21, #0x38]
0120eb08: 000140f9 ldr      x0, [x8]
0120eb0c: 08c84439 ldrb     w8, [x0, #0x132]
0120eb10: 48000037 tbnz     w8, #0, #0x120eb18
0120eb14: 34c9f597 bl       #0xf80fe4 ; 
0120eb18: 085c40f9 ldr      x8, [x0, #0xb8]
0120eb1c: 81078052 mov      w1, #0x3c
0120eb20: e00313aa mov      x0, x19
0120eb24: e20314aa mov      x2, x20
0120eb28: 030140f9 ldr      x3, [x8]
0120eb2c: e4031faa mov      x4, xzr
0120eb30: 7cc75794 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0120eb34: f37b42a9 ldp      x19, x30, [sp, #0x20]
0120eb38: f55341a9 ldp      x21, x20, [sp, #0x10]
0120eb3c: f60743f8 ldr      x22, [sp], #0x30
0120eb40: c0035fd6 ret      
0120eb44: 398af697 bl       #0xfb1428 ; 
