# Royal.Player.Context.Units.LevelEpisodeHelper$$OnLevelSuccess
# Linear metadata span, not a recovered full CFG.
02059b30: f40f1ef8 str      x20, [sp, #-0x20]!
02059b34: f37b01a9 stp      x19, x30, [sp, #0x10]
02059b38: 34a90190 adrp     x20, #0x557d000
02059b3c: 88224839 ldrb     w8, [x20, #0x208]
02059b40: f30300aa mov      x19, x0
02059b44: c8000037 tbnz     w8, #0, #0x2059b5c
02059b48: c08c01b0 adrp     x0, #0x51f2000
02059b4c: 003444f9 ldr      x0, [x0, #0x868]
02059b50: ec5dbd97 bl       #0xfb1300 ; 
02059b54: 28008052 mov      w8, #1
02059b58: 88220839 strb     w8, [x20, #0x208]
02059b5c: 730a40f9 ldr      x19, [x19, #0x10]
02059b60: 930300b4 cbz      x19, #0x2059bd0
02059b64: ca8c01b0 adrp     x10, #0x51f2000
02059b68: 680240f9 ldr      x8, [x19]
02059b6c: 4a3544f9 ldr      x10, [x10, #0x868]
02059b70: 09554279 ldrh     w9, [x8, #0x12a]
02059b74: 410140f9 ldr      x1, [x10]
02059b78: 290100b4 cbz      x9, #0x2059b9c
02059b7c: 0a5940f9 ldr      x10, [x8, #0xb0]
02059b80: 4a210091 add      x10, x10, #8
02059b84: 4b815ff8 ldur     x11, [x10, #-8]
02059b88: 7f0101eb cmp      x11, x1
02059b8c: 00010054 b.eq     #0x2059bac
02059b90: 290500f1 subs     x9, x9, #1
02059b94: 4a410091 add      x10, x10, #0x10
02059b98: 61ffff54 b.ne     #0x2059b84
02059b9c: 22008052 mov      w2, #1
02059ba0: e00313aa mov      x0, x19
02059ba4: cc9dbc97 bl       #0xf812d4 ; 
02059ba8: 05000014 b        #0x2059bbc ; 
02059bac: 490140b9 ldr      w9, [x10]
02059bb0: 29050011 add      w9, w9, #1
02059bb4: 08d1298b add      x8, x8, w9, sxtw #4
02059bb8: 00e10491 add      x0, x8, #0x138
02059bbc: 020440a9 ldp      x2, x1, [x0]
02059bc0: e00313aa mov      x0, x19
02059bc4: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059bc8: f40742f8 ldr      x20, [sp], #0x20
02059bcc: 40001fd6 br       x2
02059bd0: 165ebd97 bl       #0xfb1428 ; 
