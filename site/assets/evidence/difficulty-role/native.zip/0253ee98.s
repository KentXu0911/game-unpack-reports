# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromList<object>
# Linear metadata span, not a recovered full CFG.
0253ee98: f553bea9 stp      x21, x20, [sp, #-0x20]!
0253ee9c: f37b01a9 stp      x19, x30, [sp, #0x10]
0253eea0: c10200b4 cbz      x1, #0x253eef8
0253eea4: 481c40f9 ldr      x8, [x2, #0x38]
0253eea8: f30301aa mov      x19, x1
0253eeac: f50300aa mov      x21, x0
0253eeb0: e00313aa mov      x0, x19
0253eeb4: 010540f9 ldr      x1, [x8, #8]
0253eeb8: f40302aa mov      x20, x2
0253eebc: 280440f9 ldr      x8, [x1, #8]
0253eec0: 00013fd6 blr      x8
0253eec4: e203002a mov      w2, w0
0253eec8: e00315aa mov      x0, x21
0253eecc: e1031f2a mov      w1, wzr
0253eed0: e3031faa mov      x3, xzr
0253eed4: 45c81394 bl       #0x2a30fe8 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Next
0253eed8: 881e40f9 ldr      x8, [x20, #0x38]
0253eedc: e103002a mov      w1, w0
0253eee0: e00313aa mov      x0, x19
0253eee4: f37b41a9 ldp      x19, x30, [sp, #0x10]
0253eee8: 020940f9 ldr      x2, [x8, #0x10]
0253eeec: 430440f9 ldr      x3, [x2, #8]
0253eef0: f553c2a8 ldp      x21, x20, [sp], #0x20
0253eef4: 60001fd6 br       x3
0253eef8: 4cc9a997 bl       #0xfb1428 ; 
