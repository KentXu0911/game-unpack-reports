# Royal.Player.Context.Units.LavaQuestManager$$LoadConfig
# Linear metadata span, not a recovered full CFG.
01dc3ed0: ff4301d1 sub      sp, sp, #0x50
01dc3ed4: f96301a9 stp      x25, x24, [sp, #0x10]
01dc3ed8: f75b02a9 stp      x23, x22, [sp, #0x20]
01dc3edc: f55303a9 stp      x21, x20, [sp, #0x30]
01dc3ee0: f37b04a9 stp      x19, x30, [sp, #0x40]
01dc3ee4: d6bd0190 adrp     x22, #0x557b000
01dc3ee8: d5a301b0 adrp     x21, #0x523c000
01dc3eec: 949e01f0 adrp     x20, #0x5196000
01dc3ef0: c8e27f39 ldrb     w8, [x22, #0xff8]
01dc3ef4: b58647f9 ldr      x21, [x21, #0xf08]
01dc3ef8: 945a45f9 ldr      x20, [x20, #0xab0]
01dc3efc: f30300aa mov      x19, x0
01dc3f00: 68030037 tbnz     w8, #0, #0x1dc3f6c
01dc3f04: e0a201f0 adrp     x0, #0x5222000
01dc3f08: 00ec42f9 ldr      x0, [x0, #0x5d8]
01dc3f0c: fdb4c797 bl       #0xfb1300 ; 
01dc3f10: 00a201b0 adrp     x0, #0x5204000
01dc3f14: 00bc47f9 ldr      x0, [x0, #0xf78]
01dc3f18: fab4c797 bl       #0xfb1300 ; 
01dc3f1c: e0a101f0 adrp     x0, #0x5202000
01dc3f20: 00d846f9 ldr      x0, [x0, #0xdb0]
01dc3f24: f7b4c797 bl       #0xfb1300 ; 
01dc3f28: a0a301b0 adrp     x0, #0x5238000
01dc3f2c: 009446f9 ldr      x0, [x0, #0xd28]
01dc3f30: f4b4c797 bl       #0xfb1300 ; 
01dc3f34: 809e01f0 adrp     x0, #0x5196000
01dc3f38: 005845f9 ldr      x0, [x0, #0xab0]
01dc3f3c: f1b4c797 bl       #0xfb1300 ; 
01dc3f40: c0a30190 adrp     x0, #0x523b000
01dc3f44: 003443f9 ldr      x0, [x0, #0x668]
01dc3f48: eeb4c797 bl       #0xfb1300 ; 
01dc3f4c: 20a301b0 adrp     x0, #0x5228000
01dc3f50: 00ec45f9 ldr      x0, [x0, #0xbd8]
01dc3f54: ebb4c797 bl       #0xfb1300 ; 
01dc3f58: c0a301b0 adrp     x0, #0x523c000
01dc3f5c: 008447f9 ldr      x0, [x0, #0xf08]
01dc3f60: e8b4c797 bl       #0xfb1300 ; 
01dc3f64: 28008052 mov      w8, #1
01dc3f68: c8e23f39 strb     w8, [x22, #0xff8]
01dc3f6c: f9a101f0 adrp     x25, #0x5202000
01dc3f70: 39db46f9 ldr      x25, [x25, #0xdb0]
01dc3f74: a00240f9 ldr      x0, [x21]
01dc3f78: 18a201b0 adrp     x24, #0x5204000
01dc3f7c: d7a30190 adrp     x23, #0x523b000
01dc3f80: f6a201f0 adrp     x22, #0x5222000
01dc3f84: 18bf47f9 ldr      x24, [x24, #0xf78]
01dc3f88: f73643f9 ldr      x23, [x23, #0x668]
01dc3f8c: d6ee42f9 ldr      x22, [x22, #0x5d8]
01dc3f90: e1031faa mov      x1, xzr
01dc3f94: e2031faa mov      x2, xzr
01dc3f98: fd6f4294 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
01dc3f9c: 940240f9 ldr      x20, [x20]
01dc3fa0: e1031faa mov      x1, xzr
01dc3fa4: f50300aa mov      x21, x0
01dc3fa8: fd0cfd97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01dc3fac: c0060036 tbz      w0, #0, #0x1dc4084
01dc3fb0: a8a301b0 adrp     x8, #0x5238000
01dc3fb4: 089546f9 ldr      x8, [x8, #0xd28]
01dc3fb8: e00314aa mov      x0, x20
01dc3fbc: 010140f9 ldr      x1, [x8]
01dc3fc0: 48f71f94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01dc3fc4: 601500b4 cbz      x0, #0x1dc4270
01dc3fc8: e1031faa mov      x1, xzr
01dc3fcc: 71ff7c94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01dc3fd0: 210340f9 ldr      x1, [x25]
01dc3fd4: f5e01d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01dc3fd8: f40313aa mov      x20, x19
01dc3fdc: 800e07f8 str      x0, [x20, #0x70]!
01dc3fe0: e10300aa mov      x1, x0
01dc3fe4: e00314aa mov      x0, x20
01dc3fe8: b1b4c797 bl       #0xfb12ac ; 
01dc3fec: 880240f9 ldr      x8, [x20]
01dc3ff0: 081400b4 cbz      x8, #0x1dc4270
01dc3ff4: 081140b9 ldr      w8, [x8, #0x10]
01dc3ff8: 000340f9 ldr      x0, [x24]
01dc3ffc: e1330091 add      x1, sp, #0xc
01dc4000: e80f00b9 str      w8, [sp, #0xc]
01dc4004: 02b5c797 bl       #0xfb140c ; 
01dc4008: e80240f9 ldr      x8, [x23]
01dc400c: e10300aa mov      x1, x0
01dc4010: e2031faa mov      x2, xzr
01dc4014: e00308aa mov      x0, x8
01dc4018: f0e7fc97 bl       #0x1cfdfd8 ; System.String$$Format
01dc401c: d50240f9 ldr      x21, [x22]
01dc4020: f40300aa mov      x20, x0
01dc4024: a81e40f9 ldr      x8, [x21, #0x38]
01dc4028: 080140f9 ldr      x8, [x8]
01dc402c: 09c94439 ldrb     w9, [x8, #0x132]
01dc4030: 89000037 tbnz     w9, #0, #0x1dc4040
01dc4034: e00308aa mov      x0, x8
01dc4038: ebf3c697 bl       #0xf80fe4 ; 
01dc403c: e80300aa mov      x8, x0
01dc4040: 09e140b9 ldr      w9, [x8, #0xe0]
01dc4044: 69000035 cbnz     w9, #0x1dc4050
01dc4048: e00308aa mov      x0, x8
01dc404c: eeb4c797 bl       #0xfb1404 ; 
01dc4050: a81e40f9 ldr      x8, [x21, #0x38]
01dc4054: 000140f9 ldr      x0, [x8]
01dc4058: 08c84439 ldrb     w8, [x0, #0x132]
01dc405c: 48000037 tbnz     w8, #0, #0x1dc4064
01dc4060: e1f3c697 bl       #0xf80fe4 ; 
01dc4064: 085c40f9 ldr      x8, [x0, #0xb8]
01dc4068: c1048052 mov      w1, #0x26
01dc406c: e00313aa mov      x0, x19
01dc4070: e20314aa mov      x2, x20
01dc4074: 030140f9 ldr      x3, [x8]
01dc4078: e4031faa mov      x4, xzr
01dc407c: 29f22894 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01dc4080: 33000014 b        #0x1dc414c ; 
01dc4084: 210340f9 ldr      x1, [x25]
01dc4088: e00315aa mov      x0, x21
01dc408c: c7e01d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01dc4090: e10300aa mov      x1, x0
01dc4094: f50313aa mov      x21, x19
01dc4098: a10e07f8 str      x1, [x21, #0x70]!
01dc409c: e00315aa mov      x0, x21
01dc40a0: 83b4c797 bl       #0xfb12ac ; 
01dc40a4: 28a30190 adrp     x8, #0x5228000
01dc40a8: 08ed45f9 ldr      x8, [x8, #0xbd8]
01dc40ac: b90240f9 ldr      x25, [x21]
01dc40b0: 000140f9 ldr      x0, [x8]
01dc40b4: e1031f2a mov      w1, wzr
01dc40b8: e2031faa mov      x2, xzr
01dc40bc: 20704294 bl       #0x2e6013c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetInt
01dc40c0: 390500b4 cbz      x25, #0x1dc4164
01dc40c4: 201300b9 str      w0, [x25, #0x10]
01dc40c8: a80240f9 ldr      x8, [x21]
01dc40cc: e80400b4 cbz      x8, #0x1dc4168
01dc40d0: 081140b9 ldr      w8, [x8, #0x10]
01dc40d4: 000340f9 ldr      x0, [x24]
01dc40d8: e80b00b9 str      w8, [sp, #8]
01dc40dc: e1230091 add      x1, sp, #8
01dc40e0: cbb4c797 bl       #0xfb140c ; 
01dc40e4: e10300aa mov      x1, x0
01dc40e8: e00240f9 ldr      x0, [x23]
01dc40ec: e2031faa mov      x2, xzr
01dc40f0: bae7fc97 bl       #0x1cfdfd8 ; System.String$$Format
01dc40f4: d60240f9 ldr      x22, [x22]
01dc40f8: f50300aa mov      x21, x0
01dc40fc: c81e40f9 ldr      x8, [x22, #0x38]
01dc4100: 000140f9 ldr      x0, [x8]
01dc4104: 08c84439 ldrb     w8, [x0, #0x132]
01dc4108: 48000037 tbnz     w8, #0, #0x1dc4110
01dc410c: b6f3c697 bl       #0xf80fe4 ; 
01dc4110: 08e040b9 ldr      w8, [x0, #0xe0]
01dc4114: 48000035 cbnz     w8, #0x1dc411c
01dc4118: bbb4c797 bl       #0xfb1404 ; 
01dc411c: c81e40f9 ldr      x8, [x22, #0x38]
01dc4120: 000140f9 ldr      x0, [x8]
01dc4124: 08c84439 ldrb     w8, [x0, #0x132]
01dc4128: 48000037 tbnz     w8, #0, #0x1dc4130
01dc412c: aef3c697 bl       #0xf80fe4 ; 
01dc4130: 085c40f9 ldr      x8, [x0, #0xb8]
01dc4134: 030140f9 ldr      x3, [x8]
01dc4138: c1048052 mov      w1, #0x26
01dc413c: e00313aa mov      x0, x19
01dc4140: e20315aa mov      x2, x21
01dc4144: e4031faa mov      x4, xzr
01dc4148: f6f12894 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01dc414c: f37b44a9 ldp      x19, x30, [sp, #0x40]
01dc4150: f55343a9 ldp      x21, x20, [sp, #0x30]
01dc4154: f75b42a9 ldp      x23, x22, [sp, #0x20]
01dc4158: f96341a9 ldp      x25, x24, [sp, #0x10]
01dc415c: ff430191 add      sp, sp, #0x50
01dc4160: c0035fd6 ret      
01dc4164: b1b4c797 bl       #0xfb1428 ; 
01dc4168: b0b4c797 bl       #0xfb1428 ; 
01dc416c: 05000014 b        #0x1dc4180 ; 
01dc4170: 04000014 b        #0x1dc4180 ; 
01dc4174: 03000014 b        #0x1dc4180 ; 
01dc4178: 02000014 b        #0x1dc4180 ; 
01dc417c: 01000014 b        #0x1dc4180 ; 
01dc4180: f50300aa mov      x21, x0
01dc4184: 3f040071 cmp      w1, #1
01dc4188: a1080054 b.ne     #0x1dc429c
01dc418c: e00315aa mov      x0, x21
01dc4190: 10fdbb97 bl       #0xcc35d0 ; 
01dc4194: f50300aa mov      x21, x0
01dc4198: 80a201d0 adrp     x0, #0x5216000
01dc419c: 001c44f9 ldr      x0, [x0, #0x838]
01dc41a0: 5db4c797 bl       #0xfb1314 ; 
01dc41a4: a80240f9 ldr      x8, [x21]
01dc41a8: 010140f9 ldr      x1, [x8]
01dc41ac: 9fb5c797 bl       #0xfb1828 ; 
01dc41b0: 20060036 tbz      w0, #0, #0x1dc4274
01dc41b4: b50240f9 ldr      x21, [x21]
01dc41b8: 82fbbb97 bl       #0xcc2fc0 ; 
01dc41bc: a0a30190 adrp     x0, #0x5238000
01dc41c0: 009446f9 ldr      x0, [x0, #0xd28]
01dc41c4: 54b4c797 bl       #0xfb1314 ; 
01dc41c8: e10300aa mov      x1, x0
01dc41cc: e00314aa mov      x0, x20
01dc41d0: c4f61f94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01dc41d4: e00400b4 cbz      x0, #0x1dc4270
01dc41d8: e1031faa mov      x1, xzr
01dc41dc: edfe7c94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01dc41e0: f40300aa mov      x20, x0
01dc41e4: e0a101d0 adrp     x0, #0x5202000
01dc41e8: 00d846f9 ldr      x0, [x0, #0xdb0]
01dc41ec: 4ab4c797 bl       #0xfb1314 ; 
01dc41f0: e10300aa mov      x1, x0
01dc41f4: e00314aa mov      x0, x20
01dc41f8: 6ce01d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01dc41fc: e10300aa mov      x1, x0
01dc4200: e00313aa mov      x0, x19
01dc4204: 010c07f8 str      x1, [x0, #0x70]!
01dc4208: 29b4c797 bl       #0xfb12ac ; 
01dc420c: 350300b4 cbz      x21, #0x1dc4270
01dc4210: a80240f9 ldr      x8, [x21]
01dc4214: e00315aa mov      x0, x21
01dc4218: 098558a9 ldp      x9, x1, [x8, #0x188]
01dc421c: 20013fd6 blr      x9
01dc4220: f40300aa mov      x20, x0
01dc4224: 40a101b0 adrp     x0, #0x51ed000
01dc4228: 000841f9 ldr      x0, [x0, #0x210]
01dc422c: 3ab4c797 bl       #0xfb1314 ; 
01dc4230: e10314aa mov      x1, x20
01dc4234: e2031faa mov      x2, xzr
01dc4238: 4fe4fc97 bl       #0x1cfd374 ; System.String$$Concat
01dc423c: f40300aa mov      x20, x0
01dc4240: e0a201d0 adrp     x0, #0x5222000
01dc4244: 00ec42f9 ldr      x0, [x0, #0x5d8]
01dc4248: 33b4c797 bl       #0xfb1314 ; 
01dc424c: 081c40f9 ldr      x8, [x0, #0x38]
01dc4250: f50300aa mov      x21, x0
01dc4254: 000140f9 ldr      x0, [x8]
01dc4258: 08c84439 ldrb     w8, [x0, #0x132]
01dc425c: 48000037 tbnz     w8, #0, #0x1dc4264
01dc4260: 61f3c697 bl       #0xf80fe4 ; 
01dc4264: 08e040b9 ldr      w8, [x0, #0xe0]
01dc4268: 48efff35 cbnz     w8, #0x1dc4050
01dc426c: 78ffff17 b        #0x1dc404c ; 
01dc4270: 6eb4c797 bl       #0xfb1428 ; 
01dc4274: 00018052 mov      w0, #8
01dc4278: 52fabb97 bl       #0xcc2bc0 ; 
01dc427c: a80240f9 ldr      x8, [x21]
01dc4280: 080000f9 str      x8, [x0]
01dc4284: 018e01f0 adrp     x1, #0x4f87000
01dc4288: 21603f91 add      x1, x1, #0xfd8
01dc428c: e2031faa mov      x2, xzr
01dc4290: 04f8bb97 bl       #0xcc22a0 ; 
01dc4294: f50300aa mov      x21, x0
01dc4298: 4afbbb97 bl       #0xcc2fc0 ; 
01dc429c: e00315aa mov      x0, x21
01dc42a0: 18fbbb97 bl       #0xcc2f00 ; 
01dc42a4: 2911bc97 bl       #0xcc8748 ; 
