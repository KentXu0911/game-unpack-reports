# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromList<Int32Enum>
# Linear metadata span, not a recovered full CFG.
0253ee34: f553bea9 stp      x21, x20, [sp, #-0x20]!
0253ee38: f37b01a9 stp      x19, x30, [sp, #0x10]
0253ee3c: c10200b4 cbz      x1, #0x253ee94
0253ee40: 481c40f9 ldr      x8, [x2, #0x38]
0253ee44: f30301aa mov      x19, x1
0253ee48: f50300aa mov      x21, x0
0253ee4c: e00313aa mov      x0, x19
0253ee50: 010540f9 ldr      x1, [x8, #8]
0253ee54: f40302aa mov      x20, x2
0253ee58: 280440f9 ldr      x8, [x1, #8]
0253ee5c: 00013fd6 blr      x8
0253ee60: e203002a mov      w2, w0
0253ee64: e00315aa mov      x0, x21
0253ee68: e1031f2a mov      w1, wzr
0253ee6c: e3031faa mov      x3, xzr
0253ee70: 5ec81394 bl       #0x2a30fe8 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Next
0253ee74: 881e40f9 ldr      x8, [x20, #0x38]
0253ee78: e103002a mov      w1, w0
0253ee7c: e00313aa mov      x0, x19
0253ee80: f37b41a9 ldp      x19, x30, [sp, #0x10]
0253ee84: 020940f9 ldr      x2, [x8, #0x10]
0253ee88: 430440f9 ldr      x3, [x2, #8]
0253ee8c: f553c2a8 ldp      x21, x20, [sp], #0x20
0253ee90: 60001fd6 br       x3
0253ee94: 65c9a997 bl       #0xfb1428 ; 
