# Royal.Player.Context.Units.WeeklyLeaderboardManager$$MigrateConfigForOldCardCollection
# Linear metadata span, not a recovered full CFG.
01f14bd4: f60f1df8 str      x22, [sp, #-0x30]!
01f14bd8: f55301a9 stp      x21, x20, [sp, #0x10]
01f14bdc: f37b02a9 stp      x19, x30, [sp, #0x20]
01f14be0: 54b30190 adrp     x20, #0x557c000
01f14be4: 559401d0 adrp     x21, #0x519e000
01f14be8: 36990190 adrp     x22, #0x5238000
01f14bec: 884a5e39 ldrb     w8, [x20, #0x792]
01f14bf0: b54e42f9 ldr      x21, [x21, #0x498]
01f14bf4: d69646f9 ldr      x22, [x22, #0xd28]
01f14bf8: f30300aa mov      x19, x0
01f14bfc: e8010037 tbnz     w8, #0, #0x1f14c38
01f14c00: 80940190 adrp     x0, #0x51a4000
01f14c04: 00b041f9 ldr      x0, [x0, #0x360]
01f14c08: be71c297 bl       #0xfb1300 ; 
01f14c0c: 20990190 adrp     x0, #0x5238000
01f14c10: 009446f9 ldr      x0, [x0, #0xd28]
01f14c14: bb71c297 bl       #0xfb1300 ; 
01f14c18: 409401d0 adrp     x0, #0x519e000
01f14c1c: 004c42f9 ldr      x0, [x0, #0x498]
01f14c20: b871c297 bl       #0xfb1300 ; 
01f14c24: 409401f0 adrp     x0, #0x519f000
01f14c28: 003846f9 ldr      x0, [x0, #0xc70]
01f14c2c: b571c297 bl       #0xfb1300 ; 
01f14c30: 28008052 mov      w8, #1
01f14c34: 884a1e39 strb     w8, [x20, #0x792]
01f14c38: a00240f9 ldr      x0, [x21]
01f14c3c: c10240f9 ldr      x1, [x22]
01f14c40: 28b41a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01f14c44: 200300b4 cbz      x0, #0x1f14ca8
01f14c48: 559401f0 adrp     x21, #0x519f000
01f14c4c: 96940190 adrp     x22, #0x51a4000
01f14c50: b53a46f9 ldr      x21, [x21, #0xc70]
01f14c54: d6b241f9 ldr      x22, [x22, #0x360]
01f14c58: e1031faa mov      x1, xzr
01f14c5c: f40300aa mov      x20, x0
01f14c60: 4cbc7794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01f14c64: a80240f9 ldr      x8, [x21]
01f14c68: e10300aa mov      x1, x0
01f14c6c: e2031faa mov      x2, xzr
01f14c70: e00308aa mov      x0, x8
01f14c74: 852c3d94 bl       #0x2e5fe88 ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$SetString
01f14c78: e00314aa mov      x0, x20
01f14c7c: e1031faa mov      x1, xzr
01f14c80: 44bc7794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01f14c84: c10240f9 ldr      x1, [x22]
01f14c88: c89d1894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f14c8c: 608e02f8 str      x0, [x19, #0x28]!
01f14c90: e10300aa mov      x1, x0
01f14c94: e00313aa mov      x0, x19
01f14c98: f37b42a9 ldp      x19, x30, [sp, #0x20]
01f14c9c: f55341a9 ldp      x21, x20, [sp, #0x10]
01f14ca0: f60743f8 ldr      x22, [sp], #0x30
01f14ca4: 8271c217 b        #0xfb12ac ; 
01f14ca8: e071c297 bl       #0xfb1428 ; 
