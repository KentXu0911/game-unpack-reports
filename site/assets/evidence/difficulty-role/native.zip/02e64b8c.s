# Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$GetSyncRequiredKeyValueCounts
# Linear metadata span, not a recovered full CFG.
02e64b8c: ff8304d1 sub      sp, sp, #0x120
02e64b90: fc8300f9 str      x28, [sp, #0x100]
02e64b94: f37b11a9 stp      x19, x30, [sp, #0x110]
02e64b98: 800100b4 cbz      x0, #0x2e64bc8
02e64b9c: f30308aa mov      x19, x8
02e64ba0: e8230091 add      x8, sp, #8
02e64ba4: b6e5ff97 bl       #0x2e5e27c ; Royal.Infrastructure.Services.Storage.DatabaseService$$GetSyncRequiredKeyValueCounts
02e64ba8: e1230091 add      x1, sp, #8
02e64bac: 021f8052 mov      w2, #0xf8
02e64bb0: e00313aa mov      x0, x19
02e64bb4: 87747997 bl       #0xcc1dd0 ; 
02e64bb8: f37b51a9 ldp      x19, x30, [sp, #0x110]
02e64bbc: fc8340f9 ldr      x28, [sp, #0x100]
02e64bc0: ff830491 add      sp, sp, #0x120
02e64bc4: c0035fd6 ret      
02e64bc8: 18328597 bl       #0xfb1428 ; 
