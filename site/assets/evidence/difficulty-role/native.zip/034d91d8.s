# Royal.Scenes.Home.Ui.Dialogs.DragonNest.Scripts.DragonNestConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
034d91d8: f60f1df8 str      x22, [sp, #-0x30]!
034d91dc: f55301a9 stp      x21, x20, [sp, #0x10]
034d91e0: f37b02a9 stp      x19, x30, [sp, #0x20]
034d91e4: 740501d0 adrp     x20, #0x5587000
034d91e8: 887e4639 ldrb     w8, [x20, #0x19f]
034d91ec: f30300aa mov      x19, x0
034d91f0: c8030037 tbnz     w8, #0, #0x34d9268
034d91f4: 40ea00b0 adrp     x0, #0x5222000
034d91f8: 00ec42f9 ldr      x0, [x0, #0x5d8]
034d91fc: 41606b97 bl       #0xfb1300 ; 
034d9200: 80e800f0 adrp     x0, #0x51ec000
034d9204: 00b442f9 ldr      x0, [x0, #0x568]
034d9208: 3e606b97 bl       #0xfb1300 ; 
034d920c: 20e600b0 adrp     x0, #0x519e000
034d9210: 002444f9 ldr      x0, [x0, #0x848]
034d9214: 3b606b97 bl       #0xfb1300 ; 
034d9218: 40e900f0 adrp     x0, #0x5204000
034d921c: 00bc47f9 ldr      x0, [x0, #0xf78]
034d9220: 38606b97 bl       #0xfb1300 ; 
034d9224: 00eb00d0 adrp     x0, #0x523b000
034d9228: 006842f9 ldr      x0, [x0, #0x4d0]
034d922c: 35606b97 bl       #0xfb1300 ; 
034d9230: e0ea00f0 adrp     x0, #0x5238000
034d9234: 009446f9 ldr      x0, [x0, #0xd28]
034d9238: 32606b97 bl       #0xfb1300 ; 
034d923c: 00e80090 adrp     x0, #0x51d9000
034d9240: 004447f9 ldr      x0, [x0, #0xe88]
034d9244: 2f606b97 bl       #0xfb1300 ; 
034d9248: 40e700d0 adrp     x0, #0x51c3000
034d924c: 002040f9 ldr      x0, [x0, #0x40]
034d9250: 2c606b97 bl       #0xfb1300 ; 
034d9254: a0e900d0 adrp     x0, #0x520f000
034d9258: 003c47f9 ldr      x0, [x0, #0xe78]
034d925c: 29606b97 bl       #0xfb1300 ; 
034d9260: 28008052 mov      w8, #1
034d9264: 887e0639 strb     w8, [x20, #0x19f]
034d9268: 681240f9 ldr      x8, [x19, #0x20]
034d926c: 680e00b4 cbz      x8, #0x34d9438
034d9270: 081140f9 ldr      x8, [x8, #0x20]
034d9274: 280e00b4 cbz      x8, #0x34d9438
034d9278: 161140f9 ldr      x22, [x8, #0x20]
034d927c: f60d00b4 cbz      x22, #0x34d9438
034d9280: c00a40f9 ldr      x0, [x22, #0x10]
034d9284: 14eb00d0 adrp     x20, #0x523b000
034d9288: 55ea00b0 adrp     x21, #0x5222000
034d928c: 946a42f9 ldr      x20, [x20, #0x4d0]
034d9290: b5ee42f9 ldr      x21, [x21, #0x5d8]
034d9294: e1031faa mov      x1, xzr
034d9298: 41b8a097 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
034d929c: 60050036 tbz      w0, #0, #0x34d9348
034d92a0: 08e80090 adrp     x8, #0x51d9000
034d92a4: e9ea00f0 adrp     x9, #0x5238000
034d92a8: 084547f9 ldr      x8, [x8, #0xe88]
034d92ac: 299546f9 ldr      x9, [x9, #0xd28]
034d92b0: 000140f9 ldr      x0, [x8]
034d92b4: 210140f9 ldr      x1, [x9]
034d92b8: 8aa2c397 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
034d92bc: e00b00b4 cbz      x0, #0x34d9438
034d92c0: e1031faa mov      x1, xzr
034d92c4: b3aa2094 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
034d92c8: 810240f9 ldr      x1, [x20]
034d92cc: 378cc197 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
034d92d0: e10300aa mov      x1, x0
034d92d4: e00313aa mov      x0, x19
034d92d8: 018c01f8 str      x1, [x0, #0x18]!
034d92dc: f45f6b97 bl       #0xfb12ac ; 
034d92e0: b40240f9 ldr      x20, [x21]
034d92e4: 881e40f9 ldr      x8, [x20, #0x38]
034d92e8: 000140f9 ldr      x0, [x8]
034d92ec: 08c84439 ldrb     w8, [x0, #0x132]
034d92f0: 48000037 tbnz     w8, #0, #0x34d92f8
034d92f4: 3c9f6a97 bl       #0xf80fe4 ; 
034d92f8: 08e040b9 ldr      w8, [x0, #0xe0]
034d92fc: 48000035 cbnz     w8, #0x34d9304
034d9300: 41606b97 bl       #0xfb1404 ; 
034d9304: 881e40f9 ldr      x8, [x20, #0x38]
034d9308: 54e700d0 adrp     x20, #0x51c3000
034d930c: 000140f9 ldr      x0, [x8]
034d9310: 08c84439 ldrb     w8, [x0, #0x132]
034d9314: 942240f9 ldr      x20, [x20, #0x40]
034d9318: 48000037 tbnz     w8, #0, #0x34d9320
034d931c: 329f6a97 bl       #0xf80fe4 ; 
034d9320: 085c40f9 ldr      x8, [x0, #0xb8]
034d9324: 820240f9 ldr      x2, [x20]
034d9328: e00313aa mov      x0, x19
034d932c: f37b42a9 ldp      x19, x30, [sp, #0x20]
034d9330: 030140f9 ldr      x3, [x8]
034d9334: f55341a9 ldp      x21, x20, [sp, #0x10]
034d9338: c1058052 mov      w1, #0x2e
034d933c: e4031faa mov      x4, xzr
034d9340: f60743f8 ldr      x22, [sp], #0x30
034d9344: 779dcc17 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
034d9348: c00a40f9 ldr      x0, [x22, #0x10]
034d934c: 810240f9 ldr      x1, [x20]
034d9350: 168cc197 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
034d9354: f40313aa mov      x20, x19
034d9358: 808e01f8 str      x0, [x20, #0x18]!
034d935c: e10300aa mov      x1, x0
034d9360: e00314aa mov      x0, x20
034d9364: d25f6b97 bl       #0xfb12ac ; 
034d9368: 880640f9 ldr      x8, [x20, #8]
034d936c: 680600b4 cbz      x8, #0x34d9438
034d9370: 081140f9 ldr      x8, [x8, #0x20]
034d9374: 280600b4 cbz      x8, #0x34d9438
034d9378: 081540f9 ldr      x8, [x8, #0x28]
034d937c: e80500b4 cbz      x8, #0x34d9438
034d9380: 890240f9 ldr      x9, [x20]
034d9384: a90500b4 cbz      x9, #0x34d9438
034d9388: 081140b9 ldr      w8, [x8, #0x10]
034d938c: 4ae900f0 adrp     x10, #0x5204000
034d9390: 4abd47f9 ldr      x10, [x10, #0xf78]
034d9394: b4e900d0 adrp     x20, #0x520f000
034d9398: 281100b9 str      w8, [x9, #0x10]
034d939c: e1330091 add      x1, sp, #0xc
034d93a0: 400140f9 ldr      x0, [x10]
034d93a4: 943e47f9 ldr      x20, [x20, #0xe78]
034d93a8: e80f00b9 str      w8, [sp, #0xc]
034d93ac: 18606b97 bl       #0xfb140c ; 
034d93b0: 880240f9 ldr      x8, [x20]
034d93b4: e10300aa mov      x1, x0
034d93b8: e2031faa mov      x2, xzr
034d93bc: e00308aa mov      x0, x8
034d93c0: 0693a097 bl       #0x1cfdfd8 ; System.String$$Format
034d93c4: b50240f9 ldr      x21, [x21]
034d93c8: f40300aa mov      x20, x0
034d93cc: a81e40f9 ldr      x8, [x21, #0x38]
034d93d0: 080140f9 ldr      x8, [x8]
034d93d4: 09c94439 ldrb     w9, [x8, #0x132]
034d93d8: 89000037 tbnz     w9, #0, #0x34d93e8
034d93dc: e00308aa mov      x0, x8
034d93e0: 019f6a97 bl       #0xf80fe4 ; 
034d93e4: e80300aa mov      x8, x0
034d93e8: 09e140b9 ldr      w9, [x8, #0xe0]
034d93ec: 69000035 cbnz     w9, #0x34d93f8
034d93f0: e00308aa mov      x0, x8
034d93f4: 04606b97 bl       #0xfb1404 ; 
034d93f8: a81e40f9 ldr      x8, [x21, #0x38]
034d93fc: 000140f9 ldr      x0, [x8]
034d9400: 08c84439 ldrb     w8, [x0, #0x132]
034d9404: 48000037 tbnz     w8, #0, #0x34d940c
034d9408: f79e6a97 bl       #0xf80fe4 ; 
034d940c: 085c40f9 ldr      x8, [x0, #0xb8]
034d9410: c1058052 mov      w1, #0x2e
034d9414: e00313aa mov      x0, x19
034d9418: e20314aa mov      x2, x20
034d941c: 030140f9 ldr      x3, [x8]
034d9420: e4031faa mov      x4, xzr
034d9424: 3f9dcc97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
034d9428: f37b42a9 ldp      x19, x30, [sp, #0x20]
034d942c: f55341a9 ldp      x21, x20, [sp, #0x10]
034d9430: f60743f8 ldr      x22, [sp], #0x30
034d9434: c0035fd6 ret      
034d9438: fc5f6b97 bl       #0xfb1428 ; 
