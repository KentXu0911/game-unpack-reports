# Royal.Scenes.Home.Ui.Dialogs.OceanOdyssey.Scripts.OceanOdysseyConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
01b16790: f60f1df8 str      x22, [sp, #-0x30]!
01b16794: f55301a9 stp      x21, x20, [sp, #0x10]
01b16798: f37b02a9 stp      x19, x30, [sp, #0x20]
01b1679c: 34d301b0 adrp     x20, #0x557b000
01b167a0: 88aa4039 ldrb     w8, [x20, #0x2a]
01b167a4: f30300aa mov      x19, x0
01b167a8: c8030037 tbnz     w8, #0, #0x1b16820
01b167ac: 60b80190 adrp     x0, #0x5222000
01b167b0: 00ec42f9 ldr      x0, [x0, #0x5d8]
01b167b4: d36ad297 bl       #0xfb1300 ; 
01b167b8: e0b30190 adrp     x0, #0x5192000
01b167bc: 00a041f9 ldr      x0, [x0, #0x340]
01b167c0: d06ad297 bl       #0xfb1300 ; 
01b167c4: e0b401d0 adrp     x0, #0x51b4000
01b167c8: 001c47f9 ldr      x0, [x0, #0xe38]
01b167cc: cd6ad297 bl       #0xfb1300 ; 
01b167d0: 60b701d0 adrp     x0, #0x5204000
01b167d4: 00bc47f9 ldr      x0, [x0, #0xf78]
01b167d8: ca6ad297 bl       #0xfb1300 ; 
01b167dc: 60b501b0 adrp     x0, #0x51c3000
01b167e0: 00fc40f9 ldr      x0, [x0, #0x1f8]
01b167e4: c76ad297 bl       #0xfb1300 ; 
01b167e8: 00b901d0 adrp     x0, #0x5238000
01b167ec: 009446f9 ldr      x0, [x0, #0xd28]
01b167f0: c46ad297 bl       #0xfb1300 ; 
01b167f4: a0b701f0 adrp     x0, #0x520d000
01b167f8: 002847f9 ldr      x0, [x0, #0xe50]
01b167fc: c16ad297 bl       #0xfb1300 ; 
01b16800: 00b501f0 adrp     x0, #0x51b9000
01b16804: 00e840f9 ldr      x0, [x0, #0x1d0]
01b16808: be6ad297 bl       #0xfb1300 ; 
01b1680c: 00b501d0 adrp     x0, #0x51b8000
01b16810: 005846f9 ldr      x0, [x0, #0xcb0]
01b16814: bb6ad297 bl       #0xfb1300 ; 
01b16818: 28008052 mov      w8, #1
01b1681c: 88aa0039 strb     w8, [x20, #0x2a]
01b16820: 681240f9 ldr      x8, [x19, #0x20]
01b16824: 680e00b4 cbz      x8, #0x1b169f0
01b16828: 081540f9 ldr      x8, [x8, #0x28]
01b1682c: 280e00b4 cbz      x8, #0x1b169f0
01b16830: 161540f9 ldr      x22, [x8, #0x28]
01b16834: f60d00b4 cbz      x22, #0x1b169f0
01b16838: c00a40f9 ldr      x0, [x22, #0x10]
01b1683c: 74b501b0 adrp     x20, #0x51c3000
01b16840: 75b80190 adrp     x21, #0x5222000
01b16844: 94fe40f9 ldr      x20, [x20, #0x1f8]
01b16848: b5ee42f9 ldr      x21, [x21, #0x5d8]
01b1684c: e1031faa mov      x1, xzr
01b16850: d3c20794 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01b16854: 60050036 tbz      w0, #0, #0x1b16900
01b16858: 08b501d0 adrp     x8, #0x51b8000
01b1685c: 09b901d0 adrp     x9, #0x5238000
01b16860: 085946f9 ldr      x8, [x8, #0xcb0]
01b16864: 299546f9 ldr      x9, [x9, #0xd28]
01b16868: 000140f9 ldr      x0, [x8]
01b1686c: 210140f9 ldr      x1, [x9]
01b16870: 1cad2a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01b16874: e00b00b4 cbz      x0, #0x1b169f0
01b16878: e1031faa mov      x1, xzr
01b1687c: 45b58794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01b16880: 810240f9 ldr      x1, [x20]
01b16884: c9962894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01b16888: e10300aa mov      x1, x0
01b1688c: e00313aa mov      x0, x19
01b16890: 018c03f8 str      x1, [x0, #0x38]!
01b16894: 866ad297 bl       #0xfb12ac ; 
01b16898: b40240f9 ldr      x20, [x21]
01b1689c: 881e40f9 ldr      x8, [x20, #0x38]
01b168a0: 000140f9 ldr      x0, [x8]
01b168a4: 08c84439 ldrb     w8, [x0, #0x132]
01b168a8: 48000037 tbnz     w8, #0, #0x1b168b0
01b168ac: cea9d197 bl       #0xf80fe4 ; 
01b168b0: 08e040b9 ldr      w8, [x0, #0xe0]
01b168b4: 48000035 cbnz     w8, #0x1b168bc
01b168b8: d36ad297 bl       #0xfb1404 ; 
01b168bc: 881e40f9 ldr      x8, [x20, #0x38]
01b168c0: 14b501f0 adrp     x20, #0x51b9000
01b168c4: 000140f9 ldr      x0, [x8]
01b168c8: 08c84439 ldrb     w8, [x0, #0x132]
01b168cc: 94ea40f9 ldr      x20, [x20, #0x1d0]
01b168d0: 48000037 tbnz     w8, #0, #0x1b168d8
01b168d4: c4a9d197 bl       #0xf80fe4 ; 
01b168d8: 085c40f9 ldr      x8, [x0, #0xb8]
01b168dc: 820240f9 ldr      x2, [x20]
01b168e0: e00313aa mov      x0, x19
01b168e4: f37b42a9 ldp      x19, x30, [sp, #0x20]
01b168e8: 030140f9 ldr      x3, [x8]
01b168ec: f55341a9 ldp      x21, x20, [sp, #0x10]
01b168f0: a1088052 mov      w1, #0x45
01b168f4: e4031faa mov      x4, xzr
01b168f8: f60743f8 ldr      x22, [sp], #0x30
01b168fc: 09a83314 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01b16900: c00a40f9 ldr      x0, [x22, #0x10]
01b16904: 810240f9 ldr      x1, [x20]
01b16908: a8962894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01b1690c: f40313aa mov      x20, x19
01b16910: 808e03f8 str      x0, [x20, #0x38]!
01b16914: e10300aa mov      x1, x0
01b16918: e00314aa mov      x0, x20
01b1691c: 646ad297 bl       #0xfb12ac ; 
01b16920: 88825ef8 ldur     x8, [x20, #-0x18]
01b16924: 680600b4 cbz      x8, #0x1b169f0
01b16928: 081540f9 ldr      x8, [x8, #0x28]
01b1692c: 280600b4 cbz      x8, #0x1b169f0
01b16930: 081940f9 ldr      x8, [x8, #0x30]
01b16934: e80500b4 cbz      x8, #0x1b169f0
01b16938: 890240f9 ldr      x9, [x20]
01b1693c: a90500b4 cbz      x9, #0x1b169f0
01b16940: 081140b9 ldr      w8, [x8, #0x10]
01b16944: 6ab701d0 adrp     x10, #0x5204000
01b16948: 4abd47f9 ldr      x10, [x10, #0xf78]
01b1694c: b4b701f0 adrp     x20, #0x520d000
01b16950: 281100b9 str      w8, [x9, #0x10]
01b16954: e1330091 add      x1, sp, #0xc
01b16958: 400140f9 ldr      x0, [x10]
01b1695c: 942a47f9 ldr      x20, [x20, #0xe50]
01b16960: e80f00b9 str      w8, [sp, #0xc]
01b16964: aa6ad297 bl       #0xfb140c ; 
01b16968: 880240f9 ldr      x8, [x20]
01b1696c: e10300aa mov      x1, x0
01b16970: e2031faa mov      x2, xzr
01b16974: e00308aa mov      x0, x8
01b16978: 989d0794 bl       #0x1cfdfd8 ; System.String$$Format
01b1697c: b50240f9 ldr      x21, [x21]
01b16980: f40300aa mov      x20, x0
01b16984: a81e40f9 ldr      x8, [x21, #0x38]
01b16988: 080140f9 ldr      x8, [x8]
01b1698c: 09c94439 ldrb     w9, [x8, #0x132]
01b16990: 89000037 tbnz     w9, #0, #0x1b169a0
01b16994: e00308aa mov      x0, x8
01b16998: 93a9d197 bl       #0xf80fe4 ; 
01b1699c: e80300aa mov      x8, x0
01b169a0: 09e140b9 ldr      w9, [x8, #0xe0]
01b169a4: 69000035 cbnz     w9, #0x1b169b0
01b169a8: e00308aa mov      x0, x8
01b169ac: 966ad297 bl       #0xfb1404 ; 
01b169b0: a81e40f9 ldr      x8, [x21, #0x38]
01b169b4: 000140f9 ldr      x0, [x8]
01b169b8: 08c84439 ldrb     w8, [x0, #0x132]
01b169bc: 48000037 tbnz     w8, #0, #0x1b169c4
01b169c0: 89a9d197 bl       #0xf80fe4 ; 
01b169c4: 085c40f9 ldr      x8, [x0, #0xb8]
01b169c8: a1088052 mov      w1, #0x45
01b169cc: e00313aa mov      x0, x19
01b169d0: e20314aa mov      x2, x20
01b169d4: 030140f9 ldr      x3, [x8]
01b169d8: e4031faa mov      x4, xzr
01b169dc: d1a73394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01b169e0: f37b42a9 ldp      x19, x30, [sp, #0x20]
01b169e4: f55341a9 ldp      x21, x20, [sp, #0x10]
01b169e8: f60743f8 ldr      x22, [sp], #0x30
01b169ec: c0035fd6 ret      
01b169f0: 8e6ad297 bl       #0xfb1428 ; 
