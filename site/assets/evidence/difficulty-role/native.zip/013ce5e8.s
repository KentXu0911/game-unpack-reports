# Royal.Scenes.Home.Ui.Dialogs.MissionControl.Scripts.MissionControlConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
013ce5e8: f60f1df8 str      x22, [sp, #-0x30]!
013ce5ec: f55301a9 stp      x21, x20, [sp, #0x10]
013ce5f0: f37b02a9 stp      x19, x30, [sp, #0x20]
013ce5f4: 540d02d0 adrp     x20, #0x5578000
013ce5f8: 88124c39 ldrb     w8, [x20, #0x304]
013ce5fc: f30300aa mov      x19, x0
013ce600: c8030037 tbnz     w8, #0, #0x13ce678
013ce604: a0f20190 adrp     x0, #0x5222000
013ce608: 00ec42f9 ldr      x0, [x0, #0x5d8]
013ce60c: 3d8bef97 bl       #0xfb1300 ; 
013ce610: e0f00190 adrp     x0, #0x51ea000
013ce614: 009043f9 ldr      x0, [x0, #0x720]
013ce618: 3a8bef97 bl       #0xfb1300 ; 
013ce61c: c0ef01d0 adrp     x0, #0x51c8000
013ce620: 005046f9 ldr      x0, [x0, #0xca0]
013ce624: 378bef97 bl       #0xfb1300 ; 
013ce628: a0f101d0 adrp     x0, #0x5204000
013ce62c: 00bc47f9 ldr      x0, [x0, #0xf78]
013ce630: 348bef97 bl       #0xfb1300 ; 
013ce634: 20ef01b0 adrp     x0, #0x51b3000
013ce638: 00dc41f9 ldr      x0, [x0, #0x3b8]
013ce63c: 318bef97 bl       #0xfb1300 ; 
013ce640: 40f301d0 adrp     x0, #0x5238000
013ce644: 009446f9 ldr      x0, [x0, #0xd28]
013ce648: 2e8bef97 bl       #0xfb1300 ; 
013ce64c: 00f001f0 adrp     x0, #0x51d1000
013ce650: 000c44f9 ldr      x0, [x0, #0x818]
013ce654: 2b8bef97 bl       #0xfb1300 ; 
013ce658: 00f001f0 adrp     x0, #0x51d1000
013ce65c: 001843f9 ldr      x0, [x0, #0x630]
013ce660: 288bef97 bl       #0xfb1300 ; 
013ce664: 20f201d0 adrp     x0, #0x5214000
013ce668: 009045f9 ldr      x0, [x0, #0xb20]
013ce66c: 258bef97 bl       #0xfb1300 ; 
013ce670: 28008052 mov      w8, #1
013ce674: 88120c39 strb     w8, [x20, #0x304]
013ce678: 680a40f9 ldr      x8, [x19, #0x10]
013ce67c: 680e00b4 cbz      x8, #0x13ce848
013ce680: 081140f9 ldr      x8, [x8, #0x20]
013ce684: 280e00b4 cbz      x8, #0x13ce848
013ce688: 161d40f9 ldr      x22, [x8, #0x38]
013ce68c: f60d00b4 cbz      x22, #0x13ce848
013ce690: c00a40f9 ldr      x0, [x22, #0x10]
013ce694: 34ef01b0 adrp     x20, #0x51b3000
013ce698: b5f20190 adrp     x21, #0x5222000
013ce69c: 94de41f9 ldr      x20, [x20, #0x3b8]
013ce6a0: b5ee42f9 ldr      x21, [x21, #0x5d8]
013ce6a4: e1031faa mov      x1, xzr
013ce6a8: 3de32494 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
013ce6ac: 60050036 tbz      w0, #0, #0x13ce758
013ce6b0: 08f001f0 adrp     x8, #0x51d1000
013ce6b4: 49f301d0 adrp     x9, #0x5238000
013ce6b8: 081943f9 ldr      x8, [x8, #0x630]
013ce6bc: 299546f9 ldr      x9, [x9, #0xd28]
013ce6c0: 000140f9 ldr      x0, [x8]
013ce6c4: 210140f9 ldr      x1, [x9]
013ce6c8: 86cd4794 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
013ce6cc: e00b00b4 cbz      x0, #0x13ce848
013ce6d0: e1031faa mov      x1, xzr
013ce6d4: afd5a494 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
013ce6d8: 810240f9 ldr      x1, [x20]
013ce6dc: 33b74594 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
013ce6e0: e10300aa mov      x1, x0
013ce6e4: e00313aa mov      x0, x19
013ce6e8: 018c01f8 str      x1, [x0, #0x18]!
013ce6ec: f08aef97 bl       #0xfb12ac ; 
013ce6f0: b40240f9 ldr      x20, [x21]
013ce6f4: 881e40f9 ldr      x8, [x20, #0x38]
013ce6f8: 000140f9 ldr      x0, [x8]
013ce6fc: 08c84439 ldrb     w8, [x0, #0x132]
013ce700: 48000037 tbnz     w8, #0, #0x13ce708
013ce704: 38caee97 bl       #0xf80fe4 ; 
013ce708: 08e040b9 ldr      w8, [x0, #0xe0]
013ce70c: 48000035 cbnz     w8, #0x13ce714
013ce710: 3d8bef97 bl       #0xfb1404 ; 
013ce714: 881e40f9 ldr      x8, [x20, #0x38]
013ce718: 14f001f0 adrp     x20, #0x51d1000
013ce71c: 000140f9 ldr      x0, [x8]
013ce720: 08c84439 ldrb     w8, [x0, #0x132]
013ce724: 940e44f9 ldr      x20, [x20, #0x818]
013ce728: 48000037 tbnz     w8, #0, #0x13ce730
013ce72c: 2ecaee97 bl       #0xf80fe4 ; 
013ce730: 085c40f9 ldr      x8, [x0, #0xb8]
013ce734: 820240f9 ldr      x2, [x20]
013ce738: e00313aa mov      x0, x19
013ce73c: f37b42a9 ldp      x19, x30, [sp, #0x20]
013ce740: 030140f9 ldr      x3, [x8]
013ce744: f55341a9 ldp      x21, x20, [sp, #0x10]
013ce748: e1078052 mov      w1, #0x3f
013ce74c: e4031faa mov      x4, xzr
013ce750: f60743f8 ldr      x22, [sp], #0x30
013ce754: 73c85014 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
013ce758: c00a40f9 ldr      x0, [x22, #0x10]
013ce75c: 810240f9 ldr      x1, [x20]
013ce760: 12b74594 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
013ce764: f40313aa mov      x20, x19
013ce768: 808e01f8 str      x0, [x20, #0x18]!
013ce76c: e10300aa mov      x1, x0
013ce770: e00314aa mov      x0, x20
013ce774: ce8aef97 bl       #0xfb12ac ; 
013ce778: 88825ff8 ldur     x8, [x20, #-8]
013ce77c: 680600b4 cbz      x8, #0x13ce848
013ce780: 081140f9 ldr      x8, [x8, #0x20]
013ce784: 280600b4 cbz      x8, #0x13ce848
013ce788: 082140f9 ldr      x8, [x8, #0x40]
013ce78c: e80500b4 cbz      x8, #0x13ce848
013ce790: 890240f9 ldr      x9, [x20]
013ce794: a90500b4 cbz      x9, #0x13ce848
013ce798: 081140b9 ldr      w8, [x8, #0x10]
013ce79c: aaf101d0 adrp     x10, #0x5204000
013ce7a0: 4abd47f9 ldr      x10, [x10, #0xf78]
013ce7a4: 34f201d0 adrp     x20, #0x5214000
013ce7a8: 281100b9 str      w8, [x9, #0x10]
013ce7ac: e1330091 add      x1, sp, #0xc
013ce7b0: 400140f9 ldr      x0, [x10]
013ce7b4: 949245f9 ldr      x20, [x20, #0xb20]
013ce7b8: e80f00b9 str      w8, [sp, #0xc]
013ce7bc: 148bef97 bl       #0xfb140c ; 
013ce7c0: 880240f9 ldr      x8, [x20]
013ce7c4: e10300aa mov      x1, x0
013ce7c8: e2031faa mov      x2, xzr
013ce7cc: e00308aa mov      x0, x8
013ce7d0: 02be2494 bl       #0x1cfdfd8 ; System.String$$Format
013ce7d4: b50240f9 ldr      x21, [x21]
013ce7d8: f40300aa mov      x20, x0
013ce7dc: a81e40f9 ldr      x8, [x21, #0x38]
013ce7e0: 080140f9 ldr      x8, [x8]
013ce7e4: 09c94439 ldrb     w9, [x8, #0x132]
013ce7e8: 89000037 tbnz     w9, #0, #0x13ce7f8
013ce7ec: e00308aa mov      x0, x8
013ce7f0: fdc9ee97 bl       #0xf80fe4 ; 
013ce7f4: e80300aa mov      x8, x0
013ce7f8: 09e140b9 ldr      w9, [x8, #0xe0]
013ce7fc: 69000035 cbnz     w9, #0x13ce808
013ce800: e00308aa mov      x0, x8
013ce804: 008bef97 bl       #0xfb1404 ; 
013ce808: a81e40f9 ldr      x8, [x21, #0x38]
013ce80c: 000140f9 ldr      x0, [x8]
013ce810: 08c84439 ldrb     w8, [x0, #0x132]
013ce814: 48000037 tbnz     w8, #0, #0x13ce81c
013ce818: f3c9ee97 bl       #0xf80fe4 ; 
013ce81c: 085c40f9 ldr      x8, [x0, #0xb8]
013ce820: e1078052 mov      w1, #0x3f
013ce824: e00313aa mov      x0, x19
013ce828: e20314aa mov      x2, x20
013ce82c: 030140f9 ldr      x3, [x8]
013ce830: e4031faa mov      x4, xzr
013ce834: 3bc85094 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
013ce838: f37b42a9 ldp      x19, x30, [sp, #0x20]
013ce83c: f55341a9 ldp      x21, x20, [sp, #0x10]
013ce840: f60743f8 ldr      x22, [sp], #0x30
013ce844: c0035fd6 ret      
013ce848: f88aef97 bl       #0xfb1428 ; 
