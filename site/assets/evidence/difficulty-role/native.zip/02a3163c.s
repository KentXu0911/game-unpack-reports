# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$RestoreFromSaveData
# Linear metadata span, not a recovered full CFG.
02a3163c: f553bea9 stp      x21, x20, [sp, #-0x20]!
02a31640: f37b01a9 stp      x19, x30, [sp, #0x10]
02a31644: 945a0190 adrp     x20, #0x5581000
02a31648: 753d01d0 adrp     x21, #0x51df000
02a3164c: 88ce7a39 ldrb     w8, [x20, #0xeb3]
02a31650: b5e246f9 ldr      x21, [x21, #0xdc0]
02a31654: f30300aa mov      x19, x0
02a31658: c8000037 tbnz     w8, #0, #0x2a31670
02a3165c: 603d01d0 adrp     x0, #0x51df000
02a31660: 00e046f9 ldr      x0, [x0, #0xdc0]
02a31664: 27ff9597 bl       #0xfb1300 ; 
02a31668: 28008052 mov      w8, #1
02a3166c: 88ce3a39 strb     w8, [x20, #0xeb3]
02a31670: a00240f9 ldr      x0, [x21]
02a31674: 08e040b9 ldr      w8, [x0, #0xe0]
02a31678: 48000035 cbnz     w8, #0x2a31680
02a3167c: 62ff9597 bl       #0xfb1404 ; 
02a31680: e0031faa mov      x0, xzr
02a31684: b6aada97 bl       #0x20dc15c ; Royal.Scenes.Game.Levels.Units.Level.LevelRestoreManager$$get_Current
02a31688: 800400b4 cbz      x0, #0x2a31718
02a3168c: 081040f9 ldr      x8, [x0, #0x20]
02a31690: 480400b4 cbz      x8, #0x2a31718
02a31694: 001940f9 ldr      x0, [x8, #0x30]
02a31698: 000400b4 cbz      x0, #0x2a31718
02a3169c: e1031faa mov      x1, xzr
02a316a0: d9b7da97 bl       #0x20df604 ; Royal.Scenes.Game.Levels.Units.Level.DataHelpers.GameStateSaveDataHelper$$GetDifficultySeed
02a316a4: e103002a mov      w1, w0
02a316a8: e00313aa mov      x0, x19
02a316ac: 51ffff97 bl       #0x2a313f0 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$SetDifficultySeed
02a316b0: e0031faa mov      x0, xzr
02a316b4: aaaada97 bl       #0x20dc15c ; Royal.Scenes.Game.Levels.Units.Level.LevelRestoreManager$$get_Current
02a316b8: 000300b4 cbz      x0, #0x2a31718
02a316bc: 081040f9 ldr      x8, [x0, #0x20]
02a316c0: c80200b4 cbz      x8, #0x2a31718
02a316c4: 001940f9 ldr      x0, [x8, #0x30]
02a316c8: 800200b4 cbz      x0, #0x2a31718
02a316cc: e1031faa mov      x1, xzr
02a316d0: d2b7da97 bl       #0x20df618 ; Royal.Scenes.Game.Levels.Units.Level.DataHelpers.GameStateSaveDataHelper$$GetDifficultySeedGenerationCount
02a316d4: 1f040071 cmp      w0, #1
02a316d8: 602a00b9 str      w0, [x19, #0x28]
02a316dc: 8b010054 b.lt     #0x2a3170c
02a316e0: f4031f2a mov      w20, wzr
02a316e4: 601e40f9 ldr      x0, [x19, #0x38]
02a316e8: 800100b4 cbz      x0, #0x2a31718
02a316ec: 080040f9 ldr      x8, [x0]
02a316f0: 21008052 mov      w1, #1
02a316f4: 09895aa9 ldp      x9, x2, [x8, #0x1a8]
02a316f8: 20013fd6 blr      x9
02a316fc: 682a40b9 ldr      w8, [x19, #0x28]
02a31700: 94060011 add      w20, w20, #1
02a31704: 9f02086b cmp      w20, w8
02a31708: ebfeff54 b.lt     #0x2a316e4
02a3170c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02a31710: f553c2a8 ldp      x21, x20, [sp], #0x20
02a31714: c0035fd6 ret      
02a31718: 44ff9597 bl       #0xfb1428 ; 
