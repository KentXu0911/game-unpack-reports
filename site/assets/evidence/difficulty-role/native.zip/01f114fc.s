# Royal.Player.Context.Units.WeeklyLeaderboardManager$$LoadConfig
# Linear metadata span, not a recovered full CFG.
01f114fc: ffc300d1 sub      sp, sp, #0x30
01f11500: f55301a9 stp      x21, x20, [sp, #0x10]
01f11504: f37b02a9 stp      x19, x30, [sp, #0x20]
01f11508: 55b301f0 adrp     x21, #0x557c000
01f1150c: 749401d0 adrp     x20, #0x519f000
01f11510: a84e5e39 ldrb     w8, [x21, #0x793]
01f11514: 943a46f9 ldr      x20, [x20, #0xc70]
01f11518: f30300aa mov      x19, x0
01f1151c: 08030037 tbnz     w8, #0, #0x1f1157c
01f11520: 809801b0 adrp     x0, #0x5222000
01f11524: 00ec42f9 ldr      x0, [x0, #0x5d8]
01f11528: 767fc297 bl       #0xfb1300 ; 
01f1152c: 809701f0 adrp     x0, #0x5204000
01f11530: 00bc47f9 ldr      x0, [x0, #0xf78]
01f11534: 737fc297 bl       #0xfb1300 ; 
01f11538: 809401f0 adrp     x0, #0x51a4000
01f1153c: 00b041f9 ldr      x0, [x0, #0x360]
01f11540: 707fc297 bl       #0xfb1300 ; 
01f11544: 209901f0 adrp     x0, #0x5238000
01f11548: 009446f9 ldr      x0, [x0, #0xd28]
01f1154c: 6d7fc297 bl       #0xfb1300 ; 
01f11550: 609401b0 adrp     x0, #0x519e000
01f11554: 004c42f9 ldr      x0, [x0, #0x498]
01f11558: 6a7fc297 bl       #0xfb1300 ; 
01f1155c: 409901d0 adrp     x0, #0x523b000
01f11560: 003443f9 ldr      x0, [x0, #0x668]
01f11564: 677fc297 bl       #0xfb1300 ; 
01f11568: 609401d0 adrp     x0, #0x519f000
01f1156c: 003846f9 ldr      x0, [x0, #0xc70]
01f11570: 647fc297 bl       #0xfb1300 ; 
01f11574: 28008052 mov      w8, #1
01f11578: a84e1e39 strb     w8, [x21, #0x793]
01f1157c: 800240f9 ldr      x0, [x20]
01f11580: 959401f0 adrp     x21, #0x51a4000
01f11584: b5b241f9 ldr      x21, [x21, #0x360]
01f11588: e1031faa mov      x1, xzr
01f1158c: e2031faa mov      x2, xzr
01f11590: 7f3a3d94 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
01f11594: e1031faa mov      x1, xzr
01f11598: f40300aa mov      x20, x0
01f1159c: 80d7f797 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01f115a0: 40020036 tbz      w0, #0, #0x1f115e8
01f115a4: 689401b0 adrp     x8, #0x519e000
01f115a8: 299901f0 adrp     x9, #0x5238000
01f115ac: 084d42f9 ldr      x8, [x8, #0x498]
01f115b0: 299546f9 ldr      x9, [x9, #0xd28]
01f115b4: 000140f9 ldr      x0, [x8]
01f115b8: 210140f9 ldr      x1, [x9]
01f115bc: c9c11a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01f115c0: 401100b4 cbz      x0, #0x1f117e8
01f115c4: e1031faa mov      x1, xzr
01f115c8: f2c97794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01f115cc: a10240f9 ldr      x1, [x21]
01f115d0: 76ab1894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f115d4: e10300aa mov      x1, x0
01f115d8: e00313aa mov      x0, x19
01f115dc: 018c02f8 str      x1, [x0, #0x28]!
01f115e0: 337fc297 bl       #0xfb12ac ; 
01f115e4: 08000014 b        #0x1f11604 ; 
01f115e8: a10240f9 ldr      x1, [x21]
01f115ec: e00314aa mov      x0, x20
01f115f0: 6eab1894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f115f4: e10300aa mov      x1, x0
01f115f8: e00313aa mov      x0, x19
01f115fc: 018c02f8 str      x1, [x0, #0x28]!
01f11600: 2b7fc297 bl       #0xfb12ac ; 
01f11604: 681640f9 ldr      x8, [x19, #0x28]
01f11608: 080f00b4 cbz      x8, #0x1f117e8
01f1160c: 899701f0 adrp     x9, #0x5204000
01f11610: 29bd47f9 ldr      x9, [x9, #0xf78]
01f11614: 081940b9 ldr      w8, [x8, #0x18]
01f11618: 549901d0 adrp     x20, #0x523b000
01f1161c: 959801b0 adrp     x21, #0x5222000
01f11620: 200140f9 ldr      x0, [x9]
01f11624: 943643f9 ldr      x20, [x20, #0x668]
01f11628: b5ee42f9 ldr      x21, [x21, #0x5d8]
01f1162c: e1330091 add      x1, sp, #0xc
01f11630: e80f00b9 str      w8, [sp, #0xc]
01f11634: 767fc297 bl       #0xfb140c ; 
01f11638: 880240f9 ldr      x8, [x20]
01f1163c: e10300aa mov      x1, x0
01f11640: e2031faa mov      x2, xzr
01f11644: e00308aa mov      x0, x8
01f11648: 64b2f797 bl       #0x1cfdfd8 ; System.String$$Format
01f1164c: b50240f9 ldr      x21, [x21]
01f11650: f40300aa mov      x20, x0
01f11654: a81e40f9 ldr      x8, [x21, #0x38]
01f11658: 080140f9 ldr      x8, [x8]
01f1165c: 09c94439 ldrb     w9, [x8, #0x132]
01f11660: 89000037 tbnz     w9, #0, #0x1f11670
01f11664: e00308aa mov      x0, x8
01f11668: 5fbec197 bl       #0xf80fe4 ; 
01f1166c: e80300aa mov      x8, x0
01f11670: 09e140b9 ldr      w9, [x8, #0xe0]
01f11674: 69000035 cbnz     w9, #0x1f11680
01f11678: e00308aa mov      x0, x8
01f1167c: 627fc297 bl       #0xfb1404 ; 
01f11680: a81e40f9 ldr      x8, [x21, #0x38]
01f11684: 000140f9 ldr      x0, [x8]
01f11688: 08c84439 ldrb     w8, [x0, #0x132]
01f1168c: 48000037 tbnz     w8, #0, #0x1f11694
01f11690: 55bec197 bl       #0xf80fe4 ; 
01f11694: 085c40f9 ldr      x8, [x0, #0xb8]
01f11698: 61048052 mov      w1, #0x23
01f1169c: e00313aa mov      x0, x19
01f116a0: e20314aa mov      x2, x20
01f116a4: 030140f9 ldr      x3, [x8]
01f116a8: e4031faa mov      x4, xzr
01f116ac: 9dbc2394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01f116b0: f37b42a9 ldp      x19, x30, [sp, #0x20]
01f116b4: f55341a9 ldp      x21, x20, [sp, #0x10]
01f116b8: ffc30091 add      sp, sp, #0x30
01f116bc: c0035fd6 ret      
01f116c0: 3f040071 cmp      w1, #1
01f116c4: f40300aa mov      x20, x0
01f116c8: e10a0054 b.ne     #0x1f11824
01f116cc: e00314aa mov      x0, x20
01f116d0: c0c7b697 bl       #0xcc35d0 ; 
01f116d4: f40300aa mov      x20, x0
01f116d8: 209801b0 adrp     x0, #0x5216000
01f116dc: 001c44f9 ldr      x0, [x0, #0x838]
01f116e0: 0d7fc297 bl       #0xfb1314 ; 
01f116e4: 880240f9 ldr      x8, [x20]
01f116e8: 010140f9 ldr      x1, [x8]
01f116ec: 4f80c297 bl       #0xfb1828 ; 
01f116f0: e0070036 tbz      w0, #0, #0x1f117ec
01f116f4: 940240f9 ldr      x20, [x20]
01f116f8: 32c6b697 bl       #0xcc2fc0 ; 
01f116fc: 609401b0 adrp     x0, #0x519e000
01f11700: 004c42f9 ldr      x0, [x0, #0x498]
01f11704: 047fc297 bl       #0xfb1314 ; 
01f11708: f50300aa mov      x21, x0
01f1170c: 209901f0 adrp     x0, #0x5238000
01f11710: 009446f9 ldr      x0, [x0, #0xd28]
01f11714: 007fc297 bl       #0xfb1314 ; 
01f11718: e10300aa mov      x1, x0
01f1171c: e00315aa mov      x0, x21
01f11720: 70c11a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01f11724: 200600b4 cbz      x0, #0x1f117e8
01f11728: e1031faa mov      x1, xzr
01f1172c: 99c97794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01f11730: f50300aa mov      x21, x0
01f11734: 809401f0 adrp     x0, #0x51a4000
01f11738: 00b041f9 ldr      x0, [x0, #0x360]
01f1173c: f67ec297 bl       #0xfb1314 ; 
01f11740: e10300aa mov      x1, x0
01f11744: e00315aa mov      x0, x21
01f11748: 18ab1894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f1174c: e10300aa mov      x1, x0
01f11750: e00313aa mov      x0, x19
01f11754: 018c02f8 str      x1, [x0, #0x28]!
01f11758: d57ec297 bl       #0xfb12ac ; 
01f1175c: 00990190 adrp     x0, #0x5231000
01f11760: 003841f9 ldr      x0, [x0, #0x270]
01f11764: ec7ec297 bl       #0xfb1314 ; 
01f11768: 21008052 mov      w1, #1
01f1176c: 017fc297 bl       #0xfb1370 ; 
01f11770: d40300b4 cbz      x20, #0x1f117e8
01f11774: 880240f9 ldr      x8, [x20]
01f11778: f50300aa mov      x21, x0
01f1177c: e00314aa mov      x0, x20
01f11780: 098558a9 ldp      x9, x1, [x8, #0x188]
01f11784: 20013fd6 blr      x9
01f11788: 150300b4 cbz      x21, #0x1f117e8
01f1178c: f40300aa mov      x20, x0
01f11790: c00000b4 cbz      x0, #0x1f117a8
01f11794: a80240f9 ldr      x8, [x21]
01f11798: e00314aa mov      x0, x20
01f1179c: 012140f9 ldr      x1, [x8, #0x40]
01f117a0: 1a7fc297 bl       #0xfb1408 ; 
01f117a4: 600300b4 cbz      x0, #0x1f11810
01f117a8: a81a40b9 ldr      w8, [x21, #0x18]
01f117ac: 08030034 cbz      w8, #0x1f1180c
01f117b0: e00315aa mov      x0, x21
01f117b4: 140c02f8 str      x20, [x0, #0x20]!
01f117b8: e10314aa mov      x1, x20
01f117bc: bc7ec297 bl       #0xfb12ac ; 
01f117c0: 809801b0 adrp     x0, #0x5222000
01f117c4: 009047f9 ldr      x0, [x0, #0xf20]
01f117c8: d37ec297 bl       #0xfb1314 ; 
01f117cc: e20300aa mov      x2, x0
01f117d0: 61048052 mov      w1, #0x23
01f117d4: e00313aa mov      x0, x19
01f117d8: e30315aa mov      x3, x21
01f117dc: e4031faa mov      x4, xzr
01f117e0: 50bc2394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01f117e4: 88ffff17 b        #0x1f11604 ; 
01f117e8: 107fc297 bl       #0xfb1428 ; 
01f117ec: 00018052 mov      w0, #8
01f117f0: f4c4b697 bl       #0xcc2bc0 ; 
01f117f4: 880240f9 ldr      x8, [x20]
01f117f8: 080000f9 str      x8, [x0]
01f117fc: a18301d0 adrp     x1, #0x4f87000
01f11800: 21603f91 add      x1, x1, #0xfd8
01f11804: e2031faa mov      x2, xzr
01f11808: a6c2b697 bl       #0xcc22a0 ; 
01f1180c: 097fc297 bl       #0xfb1430 ; 
01f11810: 0f7fc297 bl       #0xfb144c ; 
01f11814: e1031faa mov      x1, xzr
01f11818: f67ec297 bl       #0xfb13f0 ; 
01f1181c: f40300aa mov      x20, x0
01f11820: e8c5b697 bl       #0xcc2fc0 ; 
01f11824: e00314aa mov      x0, x20
01f11828: b6c5b697 bl       #0xcc2f00 ; 
01f1182c: c7dbb697 bl       #0xcc8748 ; 
