# Spine.Unity.SkeletonDataAsset$$GetSkeletonData
# Linear metadata span, not a recovered full CFG.
01fd8b44: ff0302d1 sub      sp, sp, #0x80
01fd8b48: e82300fd str      d8, [sp, #0x40]
01fd8b4c: f82700f9 str      x24, [sp, #0x48]
01fd8b50: f75b05a9 stp      x23, x22, [sp, #0x50]
01fd8b54: f55306a9 stp      x21, x20, [sp, #0x60]
01fd8b58: f37b07a9 stp      x19, x30, [sp, #0x70]
01fd8b5c: 35ad0190 adrp     x21, #0x557c000
01fd8b60: 378e01f0 adrp     x23, #0x519f000
01fd8b64: a8427a39 ldrb     w8, [x21, #0xe90]
01fd8b68: f7aa45f9 ldr      x23, [x23, #0xb50]
01fd8b6c: f403012a mov      w20, w1
01fd8b70: f30300aa mov      x19, x0
01fd8b74: 28040037 tbnz     w8, #0, #0x1fd8bf8
01fd8b78: 209101d0 adrp     x0, #0x51fe000
01fd8b7c: 002042f9 ldr      x0, [x0, #0x440]
01fd8b80: e061bf97 bl       #0xfb1300 ; 
01fd8b84: a09201b0 adrp     x0, #0x522d000
01fd8b88: 008444f9 ldr      x0, [x0, #0x908]
01fd8b8c: dd61bf97 bl       #0xfb1300 ; 
01fd8b90: 808e01d0 adrp     x0, #0x51aa000
01fd8b94: 004c44f9 ldr      x0, [x0, #0x898]
01fd8b98: da61bf97 bl       #0xfb1300 ; 
01fd8b9c: e0920190 adrp     x0, #0x5234000
01fd8ba0: 00d044f9 ldr      x0, [x0, #0x9a0]
01fd8ba4: d761bf97 bl       #0xfb1300 ; 
01fd8ba8: c09201b0 adrp     x0, #0x5231000
01fd8bac: 003c45f9 ldr      x0, [x0, #0xa78]
01fd8bb0: d461bf97 bl       #0xfb1300 ; 
01fd8bb4: 809001d0 adrp     x0, #0x51ea000
01fd8bb8: 00d040f9 ldr      x0, [x0, #0x1a0]
01fd8bbc: d161bf97 bl       #0xfb1300 ; 
01fd8bc0: 208e01f0 adrp     x0, #0x519f000
01fd8bc4: 00a845f9 ldr      x0, [x0, #0xb50]
01fd8bc8: ce61bf97 bl       #0xfb1300 ; 
01fd8bcc: 208e01d0 adrp     x0, #0x519e000
01fd8bd0: 00e841f9 ldr      x0, [x0, #0x3d0]
01fd8bd4: cb61bf97 bl       #0xfb1300 ; 
01fd8bd8: a08e01b0 adrp     x0, #0x51ad000
01fd8bdc: 009847f9 ldr      x0, [x0, #0xf30]
01fd8be0: c861bf97 bl       #0xfb1300 ; 
01fd8be4: a09201b0 adrp     x0, #0x522d000
01fd8be8: 00fc44f9 ldr      x0, [x0, #0x9f8]
01fd8bec: c561bf97 bl       #0xfb1300 ; 
01fd8bf0: 28008052 mov      w8, #1
01fd8bf4: a8423a39 strb     w8, [x21, #0xe90]
01fd8bf8: e00240f9 ldr      x0, [x23]
01fd8bfc: ffff02a9 stp      xzr, xzr, [sp, #0x28]
01fd8c00: ff1300f9 str      xzr, [sp, #0x20]
01fd8c04: 751640f9 ldr      x21, [x19, #0x28]
01fd8c08: 08e040b9 ldr      w8, [x0, #0xe0]
01fd8c0c: 48000035 cbnz     w8, #0x1fd8c14
01fd8c10: fd61bf97 bl       #0xfb1404 ; 
01fd8c14: e00315aa mov      x0, x21
01fd8c18: e1031faa mov      x1, xzr
01fd8c1c: e2031faa mov      x2, xzr
01fd8c20: 537a7494 bl       #0x3cf756c ; UnityEngine.Object$$op_Equality
01fd8c24: 40040036 tbz      w0, #0, #0x1fd8cac
01fd8c28: f4020037 tbnz     w20, #0, #0x1fd8c84
01fd8c2c: b48e01b0 adrp     x20, #0x51ad000
01fd8c30: b59201b0 adrp     x21, #0x522d000
01fd8c34: 949a47f9 ldr      x20, [x20, #0xf30]
01fd8c38: b58644f9 ldr      x21, [x21, #0x908]
01fd8c3c: e00313aa mov      x0, x19
01fd8c40: e1031faa mov      x1, xzr
01fd8c44: bb697494 bl       #0x3cf3330 ; UnityEngine.Object$$get_name
01fd8c48: 880240f9 ldr      x8, [x20]
01fd8c4c: e10300aa mov      x1, x0
01fd8c50: e2031faa mov      x2, xzr
01fd8c54: e00308aa mov      x0, x8
01fd8c58: c791f497 bl       #0x1cfd374 ; System.String$$Concat
01fd8c5c: a80240f9 ldr      x8, [x21]
01fd8c60: f40300aa mov      x20, x0
01fd8c64: 09e140b9 ldr      w9, [x8, #0xe0]
01fd8c68: 69000035 cbnz     w9, #0x1fd8c74
01fd8c6c: e00308aa mov      x0, x8
01fd8c70: e561bf97 bl       #0xfb1404 ; 
01fd8c74: e00314aa mov      x0, x20
01fd8c78: e10313aa mov      x1, x19
01fd8c7c: e2031faa mov      x2, xzr
01fd8c80: bb687494 bl       #0x3cf2f6c ; UnityEngine.Debug$$LogError
01fd8c84: e00313aa mov      x0, x19
01fd8c88: 1f0c06f8 str      xzr, [x0, #0x60]!
01fd8c8c: e1031faa mov      x1, xzr
01fd8c90: 8761bf97 bl       #0xfb12ac ; 
01fd8c94: 7f8e06f8 str      xzr, [x19, #0x68]!
01fd8c98: e00313aa mov      x0, x19
01fd8c9c: e1031faa mov      x1, xzr
01fd8ca0: 8361bf97 bl       #0xfb12ac ; 
01fd8ca4: e0031faa mov      x0, xzr
01fd8ca8: 66000014 b        #0x1fd8e40 ; 
01fd8cac: 603240f9 ldr      x0, [x19, #0x60]
01fd8cb0: 800c00b5 cbnz     x0, #0x1fd8e40
01fd8cb4: e00313aa mov      x0, x19
01fd8cb8: 5a030094 bl       #0x1fd9a20 ; Spine.Unity.SkeletonDataAsset$$GetAtlasArray
01fd8cbc: 402000b4 cbz      x0, #0x1fd90c4
01fd8cc0: 080c40f9 ldr      x8, [x0, #0x18]
01fd8cc4: f60300aa mov      x22, x0
01fd8cc8: 680100b4 cbz      x8, #0x1fd8cf4
01fd8ccc: 289101d0 adrp     x8, #0x51fe000
01fd8cd0: 082142f9 ldr      x8, [x8, #0x440]
01fd8cd4: 000140f9 ldr      x0, [x8]
01fd8cd8: d061bf97 bl       #0xfb1418 ; 
01fd8cdc: 401f00b4 cbz      x0, #0x1fd90c4
01fd8ce0: e10316aa mov      x1, x22
01fd8ce4: e2031faa mov      x2, xzr
01fd8ce8: f50300aa mov      x21, x0
01fd8cec: 38132b94 bl       #0x2a9d9cc ; Spine.AtlasAttachmentLoader$$.ctor
01fd8cf0: 09000014 b        #0x1fd8d14 ; 
01fd8cf4: 288e01d0 adrp     x8, #0x519e000
01fd8cf8: 08e941f9 ldr      x8, [x8, #0x3d0]
01fd8cfc: 000140f9 ldr      x0, [x8]
01fd8d00: c661bf97 bl       #0xfb1418 ; 
01fd8d04: 001e00b4 cbz      x0, #0x1fd90c4
01fd8d08: e1031faa mov      x1, xzr
01fd8d0c: f50300aa mov      x21, x0
01fd8d10: 396a0a94 bl       #0x22735f4 ; System.Object$$.ctor
01fd8d14: 601640f9 ldr      x0, [x19, #0x28]
01fd8d18: 601d00b4 cbz      x0, #0x1fd90c4
01fd8d1c: 682240bd ldr      s8, [x19, #0x20]
01fd8d20: e1031faa mov      x1, xzr
01fd8d24: 83697494 bl       #0x3cf3330 ; UnityEngine.Object$$get_name
01fd8d28: e01c00b4 cbz      x0, #0x1fd90c4
01fd8d2c: e1031faa mov      x1, xzr
01fd8d30: decbf497 bl       #0x1d0bca8 ; System.String$$ToLower
01fd8d34: 801c00b4 cbz      x0, #0x1fd90c4
01fd8d38: a89201b0 adrp     x8, #0x522d000
01fd8d3c: 08fd44f9 ldr      x8, [x8, #0x9f8]
01fd8d40: e2031faa mov      x2, xzr
01fd8d44: 010140f9 ldr      x1, [x8]
01fd8d48: 8bcdf497 bl       #0x1d0c374 ; System.String$$Contains
01fd8d4c: 681640f9 ldr      x8, [x19, #0x28]
01fd8d50: 20010036 tbz      w0, #0, #0x1fd8d74
01fd8d54: 680800b4 cbz      x8, #0x1fd8e60
01fd8d58: e00308aa mov      x0, x8
01fd8d5c: e1031faa mov      x1, xzr
01fd8d60: 1cac7494 bl       #0x3d03dd0 ; UnityEngine.TextAsset$$get_bytes
01fd8d64: e10315aa mov      x1, x21
01fd8d68: 001da84e mov      v0.16b, v8.16b
01fd8d6c: 95030094 bl       #0x1fd9bc0 ; Spine.Unity.SkeletonDataAsset$$ReadSkeletonData
01fd8d70: 08000014 b        #0x1fd8d90 ; 
01fd8d74: 880700b4 cbz      x8, #0x1fd8e64
01fd8d78: e00308aa mov      x0, x8
01fd8d7c: e1031faa mov      x1, xzr
01fd8d80: 04ac7494 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01fd8d84: e10315aa mov      x1, x21
01fd8d88: 001da84e mov      v0.16b, v8.16b
01fd8d8c: 08040094 bl       #0x1fd9dac ; Spine.Unity.SkeletonDataAsset$$ReadSkeletonData
01fd8d90: f50300aa mov      x21, x0
01fd8d94: 601a40f9 ldr      x0, [x19, #0x30]
01fd8d98: c00400b4 cbz      x0, #0x1fd8e30
01fd8d9c: 889001d0 adrp     x8, #0x51ea000
01fd8da0: 08d140f9 ldr      x8, [x8, #0x1a0]
01fd8da4: f6920190 adrp     x22, #0x5234000
01fd8da8: 988e01d0 adrp     x24, #0x51aa000
01fd8dac: 010140f9 ldr      x1, [x8]
01fd8db0: d6d244f9 ldr      x22, [x22, #0x9a0]
01fd8db4: 184f44f9 ldr      x24, [x24, #0x898]
01fd8db8: e8230091 add      x8, sp, #8
01fd8dbc: bed82794 bl       #0x29cf0b4 ; System.Collections.Generic.List<object>$$GetEnumerator
01fd8dc0: e083c03c ldur     q0, [sp, #8]
01fd8dc4: e80f40f9 ldr      x8, [sp, #0x18]
01fd8dc8: e00b803d str      q0, [sp, #0x20]
01fd8dcc: e81b00f9 str      x8, [sp, #0x30]
01fd8dd0: c10240f9 ldr      x1, [x22]
01fd8dd4: e0830091 add      x0, sp, #0x20
01fd8dd8: 95682c94 bl       #0x2af302c ; System.Collections.Generic.List.Enumerator<object>$$MoveNext
01fd8ddc: 40020036 tbz      w0, #0, #0x1fd8e24
01fd8de0: e00240f9 ldr      x0, [x23]
01fd8de4: f41b40f9 ldr      x20, [sp, #0x30]
01fd8de8: 08e040b9 ldr      w8, [x0, #0xe0]
01fd8dec: 48000035 cbnz     w8, #0x1fd8df4
01fd8df0: 8561bf97 bl       #0xfb1404 ; 
01fd8df4: e00314aa mov      x0, x20
01fd8df8: e1031faa mov      x1, xzr
01fd8dfc: e2031faa mov      x2, xzr
01fd8e00: 56c17494 bl       #0x3d09358 ; UnityEngine.Object$$op_Inequality
01fd8e04: 60fe0736 tbz      w0, #0, #0x1fd8dd0
01fd8e08: b40200b4 cbz      x20, #0x1fd8e5c
01fd8e0c: 880240f9 ldr      x8, [x20]
01fd8e10: 098957a9 ldp      x9, x2, [x8, #0x178]
01fd8e14: e00314aa mov      x0, x20
01fd8e18: e10315aa mov      x1, x21
01fd8e1c: 20013fd6 blr      x9
01fd8e20: ecffff17 b        #0x1fd8dd0 ; 
01fd8e24: 010340f9 ldr      x1, [x24]
01fd8e28: e0830091 add      x0, sp, #0x20
01fd8e2c: 7f682c94 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
01fd8e30: e00313aa mov      x0, x19
01fd8e34: e10315aa mov      x1, x21
01fd8e38: 0b040094 bl       #0x1fd9e64 ; Spine.Unity.SkeletonDataAsset$$InitializeWithData
01fd8e3c: 603240f9 ldr      x0, [x19, #0x60]
01fd8e40: f37b47a9 ldp      x19, x30, [sp, #0x70]
01fd8e44: f55346a9 ldp      x21, x20, [sp, #0x60]
01fd8e48: f75b45a9 ldp      x23, x22, [sp, #0x50]
01fd8e4c: f82740f9 ldr      x24, [sp, #0x48]
01fd8e50: e82340fd ldr      d8, [sp, #0x40]
01fd8e54: ff030291 add      sp, sp, #0x80
01fd8e58: c0035fd6 ret      
01fd8e5c: 7361bf97 bl       #0xfb1428 ; 
01fd8e60: 7261bf97 bl       #0xfb1428 ; 
01fd8e64: 7161bf97 bl       #0xfb1428 ; 
01fd8e68: 06000014 b        #0x1fd8e80 ; 
01fd8e6c: 05000014 b        #0x1fd8e80 ; 
01fd8e70: a8000014 b        #0x1fd9110 ; 
01fd8e74: 03000014 b        #0x1fd8e80 ; 
01fd8e78: 02000014 b        #0x1fd8e80 ; 
01fd8e7c: 01000014 b        #0x1fd8e80 ; 
01fd8e80: f60300aa mov      x22, x0
01fd8e84: 3f040071 cmp      w1, #1
01fd8e88: c1160054 b.ne     #0x1fd9160
01fd8e8c: e00316aa mov      x0, x22
01fd8e90: d0a9b397 bl       #0xcc35d0 ; 
01fd8e94: f50300aa mov      x21, x0
01fd8e98: e09101d0 adrp     x0, #0x5216000
01fd8e9c: 001c44f9 ldr      x0, [x0, #0x838]
01fd8ea0: 1d61bf97 bl       #0xfb1314 ; 
01fd8ea4: a80240f9 ldr      x8, [x21]
01fd8ea8: 010140f9 ldr      x1, [x8]
01fd8eac: 5f62bf97 bl       #0xfb1828 ; 
01fd8eb0: 40110036 tbz      w0, #0, #0x1fd90d8
01fd8eb4: b50240f9 ldr      x21, [x21]
01fd8eb8: 42a8b397 bl       #0xcc2fc0 ; 
01fd8ebc: 54ef0737 tbnz     w20, #0, #0x1fd8ca4
01fd8ec0: 609001f0 adrp     x0, #0x51e7000
01fd8ec4: 00b040f9 ldr      x0, [x0, #0x160]
01fd8ec8: 1361bf97 bl       #0xfb1314 ; 
01fd8ecc: c1008052 mov      w1, #6
01fd8ed0: 2861bf97 bl       #0xfb1370 ; 
01fd8ed4: 800f00b4 cbz      x0, #0x1fd90c4
01fd8ed8: f40300aa mov      x20, x0
01fd8edc: 209201b0 adrp     x0, #0x521d000
01fd8ee0: 008847f9 ldr      x0, [x0, #0xf10]
01fd8ee4: 0c61bf97 bl       #0xfb1314 ; 
01fd8ee8: a00000b4 cbz      x0, #0x1fd8efc
01fd8eec: 880240f9 ldr      x8, [x20]
01fd8ef0: 012140f9 ldr      x1, [x8, #0x40]
01fd8ef4: 4561bf97 bl       #0xfb1408 ; 
01fd8ef8: a00e00b4 cbz      x0, #0x1fd90cc
01fd8efc: 209201b0 adrp     x0, #0x521d000
01fd8f00: 008847f9 ldr      x0, [x0, #0xf10]
01fd8f04: 0461bf97 bl       #0xfb1314 ; 
01fd8f08: 881a40b9 ldr      w8, [x20, #0x18]
01fd8f0c: e80d0034 cbz      w8, #0x1fd90c8
01fd8f10: e10300aa mov      x1, x0
01fd8f14: e00314aa mov      x0, x20
01fd8f18: 010c02f8 str      x1, [x0, #0x20]!
01fd8f1c: e460bf97 bl       #0xfb12ac ; 
01fd8f20: e00313aa mov      x0, x19
01fd8f24: e1031faa mov      x1, xzr
01fd8f28: 02697494 bl       #0x3cf3330 ; UnityEngine.Object$$get_name
01fd8f2c: f60300aa mov      x22, x0
01fd8f30: c00000b4 cbz      x0, #0x1fd8f48
01fd8f34: 880240f9 ldr      x8, [x20]
01fd8f38: e00316aa mov      x0, x22
01fd8f3c: 012140f9 ldr      x1, [x8, #0x40]
01fd8f40: 3261bf97 bl       #0xfb1408 ; 
01fd8f44: 400c00b4 cbz      x0, #0x1fd90cc
01fd8f48: 881a40b9 ldr      w8, [x20, #0x18]
01fd8f4c: 1f050071 cmp      w8, #1
01fd8f50: c90b0054 b.ls     #0x1fd90c8
01fd8f54: e00314aa mov      x0, x20
01fd8f58: 168c02f8 str      x22, [x0, #0x28]!
01fd8f5c: e10316aa mov      x1, x22
01fd8f60: d360bf97 bl       #0xfb12ac ; 
01fd8f64: a08d01b0 adrp     x0, #0x518d000
01fd8f68: 002447f9 ldr      x0, [x0, #0xe48]
01fd8f6c: ea60bf97 bl       #0xfb1314 ; 
01fd8f70: a00000b4 cbz      x0, #0x1fd8f84
01fd8f74: 880240f9 ldr      x8, [x20]
01fd8f78: 012140f9 ldr      x1, [x8, #0x40]
01fd8f7c: 2361bf97 bl       #0xfb1408 ; 
01fd8f80: 600a00b4 cbz      x0, #0x1fd90cc
01fd8f84: a08d01b0 adrp     x0, #0x518d000
01fd8f88: 002447f9 ldr      x0, [x0, #0xe48]
01fd8f8c: e260bf97 bl       #0xfb1314 ; 
01fd8f90: 881a40b9 ldr      w8, [x20, #0x18]
01fd8f94: 1f090071 cmp      w8, #2
01fd8f98: 89090054 b.ls     #0x1fd90c8
01fd8f9c: e10300aa mov      x1, x0
01fd8fa0: e00314aa mov      x0, x20
01fd8fa4: 010c03f8 str      x1, [x0, #0x30]!
01fd8fa8: c160bf97 bl       #0xfb12ac ; 
01fd8fac: d50800b4 cbz      x21, #0x1fd90c4
01fd8fb0: a80240f9 ldr      x8, [x21]
01fd8fb4: e00315aa mov      x0, x21
01fd8fb8: 098558a9 ldp      x9, x1, [x8, #0x188]
01fd8fbc: 20013fd6 blr      x9
01fd8fc0: f60300aa mov      x22, x0
01fd8fc4: c00000b4 cbz      x0, #0x1fd8fdc
01fd8fc8: 880240f9 ldr      x8, [x20]
01fd8fcc: e00316aa mov      x0, x22
01fd8fd0: 012140f9 ldr      x1, [x8, #0x40]
01fd8fd4: 0d61bf97 bl       #0xfb1408 ; 
01fd8fd8: a00700b4 cbz      x0, #0x1fd90cc
01fd8fdc: 881a40b9 ldr      w8, [x20, #0x18]
01fd8fe0: 1f0d0071 cmp      w8, #3
01fd8fe4: 29070054 b.ls     #0x1fd90c8
01fd8fe8: e00314aa mov      x0, x20
01fd8fec: 168c03f8 str      x22, [x0, #0x38]!
01fd8ff0: e10316aa mov      x1, x22
01fd8ff4: ae60bf97 bl       #0xfb12ac ; 
01fd8ff8: a08d01b0 adrp     x0, #0x518d000
01fd8ffc: 002447f9 ldr      x0, [x0, #0xe48]
01fd9000: c560bf97 bl       #0xfb1314 ; 
01fd9004: a00000b4 cbz      x0, #0x1fd9018
01fd9008: 880240f9 ldr      x8, [x20]
01fd900c: 012140f9 ldr      x1, [x8, #0x40]
01fd9010: fe60bf97 bl       #0xfb1408 ; 
01fd9014: c00500b4 cbz      x0, #0x1fd90cc
01fd9018: a08d0190 adrp     x0, #0x518d000
01fd901c: 002447f9 ldr      x0, [x0, #0xe48]
01fd9020: bd60bf97 bl       #0xfb1314 ; 
01fd9024: 881a40b9 ldr      w8, [x20, #0x18]
01fd9028: 1f110071 cmp      w8, #4
01fd902c: e9040054 b.ls     #0x1fd90c8
01fd9030: e10300aa mov      x1, x0
01fd9034: e00314aa mov      x0, x20
01fd9038: 010c04f8 str      x1, [x0, #0x40]!
01fd903c: 9c60bf97 bl       #0xfb12ac ; 
01fd9040: a80240f9 ldr      x8, [x21]
01fd9044: e00315aa mov      x0, x21
01fd9048: 09855da9 ldp      x9, x1, [x8, #0x1d8]
01fd904c: 20013fd6 blr      x9
01fd9050: f50300aa mov      x21, x0
01fd9054: c00000b4 cbz      x0, #0x1fd906c
01fd9058: 880240f9 ldr      x8, [x20]
01fd905c: e00315aa mov      x0, x21
01fd9060: 012140f9 ldr      x1, [x8, #0x40]
01fd9064: e960bf97 bl       #0xfb1408 ; 
01fd9068: 200300b4 cbz      x0, #0x1fd90cc
01fd906c: 881a40b9 ldr      w8, [x20, #0x18]
01fd9070: 1f150071 cmp      w8, #5
01fd9074: a9020054 b.ls     #0x1fd90c8
01fd9078: e00314aa mov      x0, x20
01fd907c: 158c04f8 str      x21, [x0, #0x48]!
01fd9080: e10315aa mov      x1, x21
01fd9084: 8a60bf97 bl       #0xfb12ac ; 
01fd9088: e00314aa mov      x0, x20
01fd908c: e1031faa mov      x1, xzr
01fd9090: 40bcf497 bl       #0x1d08190 ; System.String$$Concat
01fd9094: f40300aa mov      x20, x0
01fd9098: a0920190 adrp     x0, #0x522d000
01fd909c: 008444f9 ldr      x0, [x0, #0x908]
01fd90a0: 9d60bf97 bl       #0xfb1314 ; 
01fd90a4: 08e040b9 ldr      w8, [x0, #0xe0]
01fd90a8: 48000035 cbnz     w8, #0x1fd90b0
01fd90ac: d660bf97 bl       #0xfb1404 ; 
01fd90b0: e00314aa mov      x0, x20
01fd90b4: e10313aa mov      x1, x19
01fd90b8: e2031faa mov      x2, xzr
01fd90bc: ac677494 bl       #0x3cf2f6c ; UnityEngine.Debug$$LogError
01fd90c0: f9feff17 b        #0x1fd8ca4 ; 
01fd90c4: d960bf97 bl       #0xfb1428 ; 
01fd90c8: da60bf97 bl       #0xfb1430 ; 
01fd90cc: e060bf97 bl       #0xfb144c ; 
01fd90d0: e1031faa mov      x1, xzr
01fd90d4: c760bf97 bl       #0xfb13f0 ; 
01fd90d8: 00018052 mov      w0, #8
01fd90dc: b9a6b397 bl       #0xcc2bc0 ; 
01fd90e0: a80240f9 ldr      x8, [x21]
01fd90e4: 080000f9 str      x8, [x0]
01fd90e8: 617d01d0 adrp     x1, #0x4f87000
01fd90ec: 21603f91 add      x1, x1, #0xfd8
01fd90f0: e2031faa mov      x2, xzr
01fd90f4: 6ba4b397 bl       #0xcc22a0 ; 
01fd90f8: f60300aa mov      x22, x0
01fd90fc: b1a7b397 bl       #0xcc2fc0 ; 
01fd9100: 18000014 b        #0x1fd9160 ; 
01fd9104: 03000014 b        #0x1fd9110 ; 
01fd9108: 02000014 b        #0x1fd9110 ; 
01fd910c: 01000014 b        #0x1fd9110 ; 
01fd9110: f60300aa mov      x22, x0
01fd9114: 3f040071 cmp      w1, #1
01fd9118: 61010054 b.ne     #0x1fd9144
01fd911c: e00316aa mov      x0, x22
01fd9120: 2ca9b397 bl       #0xcc35d0 ; 
01fd9124: 140040f9 ldr      x20, [x0]
01fd9128: a6a7b397 bl       #0xcc2fc0 ; 
01fd912c: 010340f9 ldr      x1, [x24]
01fd9130: e0830091 add      x0, sp, #0x20
01fd9134: bd672c94 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
01fd9138: d4e7ffb4 cbz      x20, #0x1fd8e30
01fd913c: e00314aa mov      x0, x20
01fd9140: a610bf97 bl       #0xf9d3d8 ; 
01fd9144: f4031faa mov      x20, xzr
01fd9148: 02000014 b        #0x1fd9150 ; 
01fd914c: f60300aa mov      x22, x0
01fd9150: 010340f9 ldr      x1, [x24]
01fd9154: e0830091 add      x0, sp, #0x20
01fd9158: b4672c94 bl       #0x2af3028 ; System.Collections.Generic.List.Enumerator<object>$$Dispose
01fd915c: 740000b5 cbnz     x20, #0x1fd9168
01fd9160: e00316aa mov      x0, x22
01fd9164: 67a7b397 bl       #0xcc2f00 ; 
01fd9168: e00314aa mov      x0, x20
01fd916c: 9b10bf97 bl       #0xf9d3d8 ; 
01fd9170: 76bdb397 bl       #0xcc8748 ; 
