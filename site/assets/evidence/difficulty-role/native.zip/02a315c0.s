# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Clear
# Linear metadata span, not a recovered full CFG.
02a315c0: f40f1ef8 str      x20, [sp, #-0x20]!
02a315c4: f37b01a9 stp      x19, x30, [sp, #0x10]
02a315c8: 345a01b0 adrp     x20, #0x5576000
02a315cc: 88ae7c39 ldrb     w8, [x20, #0xf2b]
02a315d0: f30300aa mov      x19, x0
02a315d4: c8000035 cbnz     w8, #0x2a315ec
02a315d8: a03e01f0 adrp     x0, #0x5208000
02a315dc: 00c041f9 ldr      x0, [x0, #0x380]
02a315e0: 48ff9597 bl       #0xfb1300 ; 
02a315e4: 28008052 mov      w8, #1
02a315e8: 88ae3c39 strb     w8, [x20, #0xf2b]
02a315ec: a83e01f0 adrp     x8, #0x5208000
02a315f0: 08c141f9 ldr      x8, [x8, #0x380]
02a315f4: 080140f9 ldr      x8, [x8]
02a315f8: 085d40f9 ldr      x8, [x8, #0xb8]
02a315fc: 080140f9 ldr      x8, [x8]
02a31600: c80100b4 cbz      x8, #0x2a31638
02a31604: 081d40f9 ldr      x8, [x8, #0x38]
02a31608: 880100b4 cbz      x8, #0x2a31638
02a3160c: 000d40f9 ldr      x0, [x8, #0x18]
02a31610: 400100b4 cbz      x0, #0x2a31638
02a31614: e1031faa mov      x1, xzr
02a31618: e4a7e897 bl       #0x245b5a8 ; Royal.Player.Context.Data.Session.UserActiveLevelData$$get_IsWin
02a3161c: 80000036 tbz      w0, #0, #0x2a3162c
02a31620: 7f620039 strb     wzr, [x19, #0x18]
02a31624: 7f820039 strb     wzr, [x19, #0x20]
02a31628: 7f220139 strb     wzr, [x19, #0x48]
02a3162c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02a31630: f40742f8 ldr      x20, [sp], #0x20
02a31634: c0035fd6 ret      
02a31638: 7cff9597 bl       #0xfb1428 ; 
