# Royal.Player.Context.Units.MagicCauldronManager$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
01f2436c: f60f1df8 str      x22, [sp, #-0x30]!
01f24370: f55301a9 stp      x21, x20, [sp, #0x10]
01f24374: f37b02a9 stp      x19, x30, [sp, #0x20]
01f24378: d4b20190 adrp     x20, #0x557c000
01f2437c: 889e6039 ldrb     w8, [x20, #0x827]
01f24380: f30300aa mov      x19, x0
01f24384: c8030037 tbnz     w8, #0, #0x1f243fc
01f24388: e09701d0 adrp     x0, #0x5222000
01f2438c: 00ec42f9 ldr      x0, [x0, #0x5d8]
01f24390: dc33c297 bl       #0xfb1300 ; 
01f24394: e09501b0 adrp     x0, #0x51e1000
01f24398: 006c43f9 ldr      x0, [x0, #0x6d8]
01f2439c: d933c297 bl       #0xfb1300 ; 
01f243a0: 809501d0 adrp     x0, #0x51d6000
01f243a4: 00b443f9 ldr      x0, [x0, #0x768]
01f243a8: d633c297 bl       #0xfb1300 ; 
01f243ac: 00970190 adrp     x0, #0x5204000
01f243b0: 00bc47f9 ldr      x0, [x0, #0xf78]
01f243b4: d333c297 bl       #0xfb1300 ; 
01f243b8: 20950190 adrp     x0, #0x51c8000
01f243bc: 004040f9 ldr      x0, [x0, #0x80]
01f243c0: d033c297 bl       #0xfb1300 ; 
01f243c4: a0980190 adrp     x0, #0x5238000
01f243c8: 009446f9 ldr      x0, [x0, #0xd28]
01f243cc: cd33c297 bl       #0xfb1300 ; 
01f243d0: 009801f0 adrp     x0, #0x5227000
01f243d4: 007c45f9 ldr      x0, [x0, #0xaf8]
01f243d8: ca33c297 bl       #0xfb1300 ; 
01f243dc: 409701f0 adrp     x0, #0x520f000
01f243e0: 003c47f9 ldr      x0, [x0, #0xe78]
01f243e4: c733c297 bl       #0xfb1300 ; 
01f243e8: 009401b0 adrp     x0, #0x51a5000
01f243ec: 003443f9 ldr      x0, [x0, #0x668]
01f243f0: c433c297 bl       #0xfb1300 ; 
01f243f4: 28008052 mov      w8, #1
01f243f8: 889e2039 strb     w8, [x20, #0x827]
01f243fc: 683a40f9 ldr      x8, [x19, #0x70]
01f24400: e80d00b4 cbz      x8, #0x1f245bc
01f24404: 162d40f9 ldr      x22, [x8, #0x58]
01f24408: b60d00b4 cbz      x22, #0x1f245bc
01f2440c: c00a40f9 ldr      x0, [x22, #0x10]
01f24410: 34950190 adrp     x20, #0x51c8000
01f24414: f59701d0 adrp     x21, #0x5222000
01f24418: 944240f9 ldr      x20, [x20, #0x80]
01f2441c: b5ee42f9 ldr      x21, [x21, #0x5d8]
01f24420: e1031faa mov      x1, xzr
01f24424: de8bf797 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01f24428: 60050036 tbz      w0, #0, #0x1f244d4
01f2442c: 089801f0 adrp     x8, #0x5227000
01f24430: a9980190 adrp     x9, #0x5238000
01f24434: 087d45f9 ldr      x8, [x8, #0xaf8]
01f24438: 299546f9 ldr      x9, [x9, #0xd28]
01f2443c: 000140f9 ldr      x0, [x8]
01f24440: 210140f9 ldr      x1, [x9]
01f24444: 27761a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01f24448: a00b00b4 cbz      x0, #0x1f245bc
01f2444c: e1031faa mov      x1, xzr
01f24450: 507e7794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01f24454: 810240f9 ldr      x1, [x20]
01f24458: d45f1894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f2445c: e10300aa mov      x1, x0
01f24460: e00313aa mov      x0, x19
01f24464: 018c06f8 str      x1, [x0, #0x68]!
01f24468: 9133c297 bl       #0xfb12ac ; 
01f2446c: b40240f9 ldr      x20, [x21]
01f24470: 881e40f9 ldr      x8, [x20, #0x38]
01f24474: 000140f9 ldr      x0, [x8]
01f24478: 08c84439 ldrb     w8, [x0, #0x132]
01f2447c: 48000037 tbnz     w8, #0, #0x1f24484
01f24480: d972c197 bl       #0xf80fe4 ; 
01f24484: 08e040b9 ldr      w8, [x0, #0xe0]
01f24488: 48000035 cbnz     w8, #0x1f24490
01f2448c: de33c297 bl       #0xfb1404 ; 
01f24490: 881e40f9 ldr      x8, [x20, #0x38]
01f24494: 149401b0 adrp     x20, #0x51a5000
01f24498: 000140f9 ldr      x0, [x8]
01f2449c: 08c84439 ldrb     w8, [x0, #0x132]
01f244a0: 943643f9 ldr      x20, [x20, #0x668]
01f244a4: 48000037 tbnz     w8, #0, #0x1f244ac
01f244a8: cf72c197 bl       #0xf80fe4 ; 
01f244ac: 085c40f9 ldr      x8, [x0, #0xb8]
01f244b0: 820240f9 ldr      x2, [x20]
01f244b4: e00313aa mov      x0, x19
01f244b8: f37b42a9 ldp      x19, x30, [sp, #0x20]
01f244bc: 030140f9 ldr      x3, [x8]
01f244c0: f55341a9 ldp      x21, x20, [sp, #0x10]
01f244c4: a1058052 mov      w1, #0x2d
01f244c8: e4031faa mov      x4, xzr
01f244cc: f60743f8 ldr      x22, [sp], #0x30
01f244d0: 14712314 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01f244d4: c00a40f9 ldr      x0, [x22, #0x10]
01f244d8: 810240f9 ldr      x1, [x20]
01f244dc: b35f1894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f244e0: f40313aa mov      x20, x19
01f244e4: 808e06f8 str      x0, [x20, #0x68]!
01f244e8: e10300aa mov      x1, x0
01f244ec: e00314aa mov      x0, x20
01f244f0: 6f33c297 bl       #0xfb12ac ; 
01f244f4: 880640f9 ldr      x8, [x20, #8]
01f244f8: 280600b4 cbz      x8, #0x1f245bc
01f244fc: 083140f9 ldr      x8, [x8, #0x60]
01f24500: e80500b4 cbz      x8, #0x1f245bc
01f24504: 890240f9 ldr      x9, [x20]
01f24508: a90500b4 cbz      x9, #0x1f245bc
01f2450c: 081140b9 ldr      w8, [x8, #0x10]
01f24510: 0a970190 adrp     x10, #0x5204000
01f24514: 4abd47f9 ldr      x10, [x10, #0xf78]
01f24518: 549701f0 adrp     x20, #0x520f000
01f2451c: 281100b9 str      w8, [x9, #0x10]
01f24520: e1330091 add      x1, sp, #0xc
01f24524: 400140f9 ldr      x0, [x10]
01f24528: 943e47f9 ldr      x20, [x20, #0xe78]
01f2452c: e80f00b9 str      w8, [sp, #0xc]
01f24530: b733c297 bl       #0xfb140c ; 
01f24534: 880240f9 ldr      x8, [x20]
01f24538: e10300aa mov      x1, x0
01f2453c: e2031faa mov      x2, xzr
01f24540: e00308aa mov      x0, x8
01f24544: a566f797 bl       #0x1cfdfd8 ; System.String$$Format
01f24548: b50240f9 ldr      x21, [x21]
01f2454c: f40300aa mov      x20, x0
01f24550: a81e40f9 ldr      x8, [x21, #0x38]
01f24554: 080140f9 ldr      x8, [x8]
01f24558: 09c94439 ldrb     w9, [x8, #0x132]
01f2455c: 89000037 tbnz     w9, #0, #0x1f2456c
01f24560: e00308aa mov      x0, x8
01f24564: a072c197 bl       #0xf80fe4 ; 
01f24568: e80300aa mov      x8, x0
01f2456c: 09e140b9 ldr      w9, [x8, #0xe0]
01f24570: 69000035 cbnz     w9, #0x1f2457c
01f24574: e00308aa mov      x0, x8
01f24578: a333c297 bl       #0xfb1404 ; 
01f2457c: a81e40f9 ldr      x8, [x21, #0x38]
01f24580: 000140f9 ldr      x0, [x8]
01f24584: 08c84439 ldrb     w8, [x0, #0x132]
01f24588: 48000037 tbnz     w8, #0, #0x1f24590
01f2458c: 9672c197 bl       #0xf80fe4 ; 
01f24590: 085c40f9 ldr      x8, [x0, #0xb8]
01f24594: a1058052 mov      w1, #0x2d
01f24598: e00313aa mov      x0, x19
01f2459c: e20314aa mov      x2, x20
01f245a0: 030140f9 ldr      x3, [x8]
01f245a4: e4031faa mov      x4, xzr
01f245a8: de702394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01f245ac: f37b42a9 ldp      x19, x30, [sp, #0x20]
01f245b0: f55341a9 ldp      x21, x20, [sp, #0x10]
01f245b4: f60743f8 ldr      x22, [sp], #0x30
01f245b8: c0035fd6 ret      
01f245bc: 9b33c297 bl       #0xfb1428 ; 
