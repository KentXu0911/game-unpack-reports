# Royal.Scenes.Home.Ui.Dialogs.MissionPursuit.Scripts.MissionPursuitConfigHelper$$ResetUserConfig
# Linear metadata span, not a recovered full CFG.
0120ee98: f60f1df8 str      x22, [sp, #-0x30]!
0120ee9c: f55301a9 stp      x21, x20, [sp, #0x10]
0120eea0: f37b02a9 stp      x19, x30, [sp, #0x20]
0120eea4: 541b02b0 adrp     x20, #0x5577000
0120eea8: 35fd0190 adrp     x21, #0x51b2000
0120eeac: 560102d0 adrp     x22, #0x5238000
0120eeb0: 88a65e39 ldrb     w8, [x20, #0x7a9]
0120eeb4: b5ea47f9 ldr      x21, [x21, #0xfd0]
0120eeb8: d69646f9 ldr      x22, [x22, #0xd28]
0120eebc: f30300aa mov      x19, x0
0120eec0: 48020037 tbnz     w8, #0, #0x120ef08
0120eec4: a0000290 adrp     x0, #0x5222000
0120eec8: 00ec42f9 ldr      x0, [x0, #0x5d8]
0120eecc: 0d89f697 bl       #0xfb1300 ; 
0120eed0: 400002f0 adrp     x0, #0x5219000
0120eed4: 009843f9 ldr      x0, [x0, #0x730]
0120eed8: 0a89f697 bl       #0xfb1300 ; 
0120eedc: 400102d0 adrp     x0, #0x5238000
0120eee0: 009446f9 ldr      x0, [x0, #0xd28]
0120eee4: 0789f697 bl       #0xfb1300 ; 
0120eee8: 20fd0190 adrp     x0, #0x51b2000
0120eeec: 00e847f9 ldr      x0, [x0, #0xfd0]
0120eef0: 0489f697 bl       #0xfb1300 ; 
0120eef4: 40000290 adrp     x0, #0x5216000
0120eef8: 00e847f9 ldr      x0, [x0, #0xfd0]
0120eefc: 0189f697 bl       #0xfb1300 ; 
0120ef00: 28008052 mov      w8, #1
0120ef04: 88a61e39 strb     w8, [x20, #0x7a9]
0120ef08: a00240f9 ldr      x0, [x21]
0120ef0c: c10240f9 ldr      x1, [x22]
0120ef10: 74cb4e94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0120ef14: 600600b4 cbz      x0, #0x120efe0
0120ef18: 540002f0 adrp     x20, #0x5219000
0120ef1c: 949a43f9 ldr      x20, [x20, #0x730]
0120ef20: e1031faa mov      x1, xzr
0120ef24: 9bd3ab94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0120ef28: 810240f9 ldr      x1, [x20]
0120ef2c: f40300aa mov      x20, x0
0120ef30: 1eb54c94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0120ef34: f50313aa mov      x21, x19
0120ef38: a08e01f8 str      x0, [x21, #0x18]!
0120ef3c: e10300aa mov      x1, x0
0120ef40: e00315aa mov      x0, x21
0120ef44: da88f697 bl       #0xfb12ac ; 
0120ef48: a80240f9 ldr      x8, [x21]
0120ef4c: a80400b4 cbz      x8, #0x120efe0
0120ef50: 1f1100b9 str      wzr, [x8, #0x10]
0120ef54: 680a40f9 ldr      x8, [x19, #0x10]
0120ef58: 480400b4 cbz      x8, #0x120efe0
0120ef5c: 001140f9 ldr      x0, [x8, #0x20]
0120ef60: 000400b4 cbz      x0, #0x120efe0
0120ef64: b5000290 adrp     x21, #0x5222000
0120ef68: b5ee42f9 ldr      x21, [x21, #0x5d8]
0120ef6c: e1031f2a mov      w1, wzr
0120ef70: e20314aa mov      x2, x20
0120ef74: 1c000094 bl       #0x120efe4 ; Royal.Scenes.Home.Ui.Dialogs.MissionPursuit.Scripts.MissionPursuitData$$SetUserEventConfig
0120ef78: b40240f9 ldr      x20, [x21]
0120ef7c: 881e40f9 ldr      x8, [x20, #0x38]
0120ef80: 000140f9 ldr      x0, [x8]
0120ef84: 08c84439 ldrb     w8, [x0, #0x132]
0120ef88: 48000037 tbnz     w8, #0, #0x120ef90
0120ef8c: 16c8f597 bl       #0xf80fe4 ; 
0120ef90: 08e040b9 ldr      w8, [x0, #0xe0]
0120ef94: 48000035 cbnz     w8, #0x120ef9c
0120ef98: 1b89f697 bl       #0xfb1404 ; 
0120ef9c: 881e40f9 ldr      x8, [x20, #0x38]
0120efa0: 54000290 adrp     x20, #0x5216000
0120efa4: 000140f9 ldr      x0, [x8]
0120efa8: 08c84439 ldrb     w8, [x0, #0x132]
0120efac: 94ea47f9 ldr      x20, [x20, #0xfd0]
0120efb0: 48000037 tbnz     w8, #0, #0x120efb8
0120efb4: 0cc8f597 bl       #0xf80fe4 ; 
0120efb8: 085c40f9 ldr      x8, [x0, #0xb8]
0120efbc: 820240f9 ldr      x2, [x20]
0120efc0: e00313aa mov      x0, x19
0120efc4: f37b42a9 ldp      x19, x30, [sp, #0x20]
0120efc8: 030140f9 ldr      x3, [x8]
0120efcc: f55341a9 ldp      x21, x20, [sp, #0x10]
0120efd0: 81078052 mov      w1, #0x3c
0120efd4: e4031faa mov      x4, xzr
0120efd8: f60743f8 ldr      x22, [sp], #0x30
0120efdc: 51c65714 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0120efe0: 1289f697 bl       #0xfb1428 ; 
