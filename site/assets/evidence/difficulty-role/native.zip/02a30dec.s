# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$SetSeed
# Linear metadata span, not a recovered full CFG.
02a30dec: f60f1df8 str      x22, [sp, #-0x30]!
02a30df0: f55301a9 stp      x21, x20, [sp, #0x10]
02a30df4: f37b02a9 stp      x19, x30, [sp, #0x20]
02a30df8: 955a01b0 adrp     x21, #0x5581000
02a30dfc: 763f01b0 adrp     x22, #0x521d000
02a30e00: a8b27a39 ldrb     w8, [x21, #0xeac]
02a30e04: d6ee46f9 ldr      x22, [x22, #0xdd8]
02a30e08: f403012a mov      w20, w1
02a30e0c: f30300aa mov      x19, x0
02a30e10: c8000037 tbnz     w8, #0, #0x2a30e28
02a30e14: 603f01b0 adrp     x0, #0x521d000
02a30e18: 00ec46f9 ldr      x0, [x0, #0xdd8]
02a30e1c: 39019697 bl       #0xfb1300 ; 
02a30e20: 28008052 mov      w8, #1
02a30e24: a8b23a39 strb     w8, [x21, #0xeac]
02a30e28: c00240f9 ldr      x0, [x22]
02a30e2c: 7b019697 bl       #0xfb1418 ; 
02a30e30: 800100b4 cbz      x0, #0x2a30e60
02a30e34: e103142a mov      w1, w20
02a30e38: e2031faa mov      x2, xzr
02a30e3c: f50300aa mov      x21, x0
02a30e40: bd96ec97 bl       #0x2556934 ; System.Random$$.ctor
02a30e44: 750e03f8 str      x21, [x19, #0x30]!
02a30e48: e00313aa mov      x0, x19
02a30e4c: e10315aa mov      x1, x21
02a30e50: f37b42a9 ldp      x19, x30, [sp, #0x20]
02a30e54: f55341a9 ldp      x21, x20, [sp, #0x10]
02a30e58: f60743f8 ldr      x22, [sp], #0x30
02a30e5c: 14019617 b        #0xfb12ac ; 
02a30e60: 72019697 bl       #0xfb1428 ; 
