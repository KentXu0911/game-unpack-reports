# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$get_Id
# Linear metadata span, not a recovered full CFG.
02a30bfc: e0031f2a mov      w0, wzr
02a30c00: c0035fd6 ret      
