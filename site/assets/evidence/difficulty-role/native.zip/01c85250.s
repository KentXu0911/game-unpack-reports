# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnLevelFail
# Linear metadata span, not a recovered full CFG.
01c85250: c0035fd6 ret      
