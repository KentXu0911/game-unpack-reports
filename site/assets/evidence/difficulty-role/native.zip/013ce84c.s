# Royal.Scenes.Home.Ui.Dialogs.MissionControl.Scripts.MissionControlConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
013ce84c: f60f1df8 str      x22, [sp, #-0x30]!
013ce850: f55301a9 stp      x21, x20, [sp, #0x10]
013ce854: f37b02a9 stp      x19, x30, [sp, #0x20]
013ce858: 540d02d0 adrp     x20, #0x5578000
013ce85c: 88164c39 ldrb     w8, [x20, #0x305]
013ce860: f30300aa mov      x19, x0
013ce864: c8030037 tbnz     w8, #0, #0x13ce8dc
013ce868: a0f20190 adrp     x0, #0x5222000
013ce86c: 00ec42f9 ldr      x0, [x0, #0x5d8]
013ce870: a48aef97 bl       #0xfb1300 ; 
013ce874: e0f00190 adrp     x0, #0x51ea000
013ce878: 009043f9 ldr      x0, [x0, #0x720]
013ce87c: a18aef97 bl       #0xfb1300 ; 
013ce880: c0ef01d0 adrp     x0, #0x51c8000
013ce884: 005046f9 ldr      x0, [x0, #0xca0]
013ce888: 9e8aef97 bl       #0xfb1300 ; 
013ce88c: a0f101d0 adrp     x0, #0x5204000
013ce890: 00bc47f9 ldr      x0, [x0, #0xf78]
013ce894: 9b8aef97 bl       #0xfb1300 ; 
013ce898: 20ef01b0 adrp     x0, #0x51b3000
013ce89c: 00dc41f9 ldr      x0, [x0, #0x3b8]
013ce8a0: 988aef97 bl       #0xfb1300 ; 
013ce8a4: 40f301d0 adrp     x0, #0x5238000
013ce8a8: 009446f9 ldr      x0, [x0, #0xd28]
013ce8ac: 958aef97 bl       #0xfb1300 ; 
013ce8b0: 00f001f0 adrp     x0, #0x51d1000
013ce8b4: 001843f9 ldr      x0, [x0, #0x630]
013ce8b8: 928aef97 bl       #0xfb1300 ; 
013ce8bc: 00f201b0 adrp     x0, #0x520f000
013ce8c0: 003c47f9 ldr      x0, [x0, #0xe78]
013ce8c4: 8f8aef97 bl       #0xfb1300 ; 
013ce8c8: a0ee01f0 adrp     x0, #0x51a5000
013ce8cc: 003443f9 ldr      x0, [x0, #0x668]
013ce8d0: 8c8aef97 bl       #0xfb1300 ; 
013ce8d4: 28008052 mov      w8, #1
013ce8d8: 88160c39 strb     w8, [x20, #0x305]
013ce8dc: 680a40f9 ldr      x8, [x19, #0x10]
013ce8e0: 680e00b4 cbz      x8, #0x13ceaac
013ce8e4: 081140f9 ldr      x8, [x8, #0x20]
013ce8e8: 280e00b4 cbz      x8, #0x13ceaac
013ce8ec: 161540f9 ldr      x22, [x8, #0x28]
013ce8f0: f60d00b4 cbz      x22, #0x13ceaac
013ce8f4: c00a40f9 ldr      x0, [x22, #0x10]
013ce8f8: 34ef01b0 adrp     x20, #0x51b3000
013ce8fc: b5f20190 adrp     x21, #0x5222000
013ce900: 94de41f9 ldr      x20, [x20, #0x3b8]
013ce904: b5ee42f9 ldr      x21, [x21, #0x5d8]
013ce908: e1031faa mov      x1, xzr
013ce90c: a4e22494 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
013ce910: 60050036 tbz      w0, #0, #0x13ce9bc
013ce914: 08f001f0 adrp     x8, #0x51d1000
013ce918: 49f301d0 adrp     x9, #0x5238000
013ce91c: 081943f9 ldr      x8, [x8, #0x630]
013ce920: 299546f9 ldr      x9, [x9, #0xd28]
013ce924: 000140f9 ldr      x0, [x8]
013ce928: 210140f9 ldr      x1, [x9]
013ce92c: edcc4794 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
013ce930: e00b00b4 cbz      x0, #0x13ceaac
013ce934: e1031faa mov      x1, xzr
013ce938: 16d5a494 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
013ce93c: 810240f9 ldr      x1, [x20]
013ce940: 9ab64594 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
013ce944: e10300aa mov      x1, x0
013ce948: e00313aa mov      x0, x19
013ce94c: 010c02f8 str      x1, [x0, #0x20]!
013ce950: 578aef97 bl       #0xfb12ac ; 
013ce954: b40240f9 ldr      x20, [x21]
013ce958: 881e40f9 ldr      x8, [x20, #0x38]
013ce95c: 000140f9 ldr      x0, [x8]
013ce960: 08c84439 ldrb     w8, [x0, #0x132]
013ce964: 48000037 tbnz     w8, #0, #0x13ce96c
013ce968: 9fc9ee97 bl       #0xf80fe4 ; 
013ce96c: 08e040b9 ldr      w8, [x0, #0xe0]
013ce970: 48000035 cbnz     w8, #0x13ce978
013ce974: a48aef97 bl       #0xfb1404 ; 
013ce978: 881e40f9 ldr      x8, [x20, #0x38]
013ce97c: b4ee01f0 adrp     x20, #0x51a5000
013ce980: 000140f9 ldr      x0, [x8]
013ce984: 08c84439 ldrb     w8, [x0, #0x132]
013ce988: 943643f9 ldr      x20, [x20, #0x668]
013ce98c: 48000037 tbnz     w8, #0, #0x13ce994
013ce990: 95c9ee97 bl       #0xf80fe4 ; 
013ce994: 085c40f9 ldr      x8, [x0, #0xb8]
013ce998: 820240f9 ldr      x2, [x20]
013ce99c: e00313aa mov      x0, x19
013ce9a0: f37b42a9 ldp      x19, x30, [sp, #0x20]
013ce9a4: 030140f9 ldr      x3, [x8]
013ce9a8: f55341a9 ldp      x21, x20, [sp, #0x10]
013ce9ac: e1078052 mov      w1, #0x3f
013ce9b0: e4031faa mov      x4, xzr
013ce9b4: f60743f8 ldr      x22, [sp], #0x30
013ce9b8: dac75014 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
013ce9bc: c00a40f9 ldr      x0, [x22, #0x10]
013ce9c0: 810240f9 ldr      x1, [x20]
013ce9c4: 79b64594 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
013ce9c8: f40313aa mov      x20, x19
013ce9cc: 800e02f8 str      x0, [x20, #0x20]!
013ce9d0: e10300aa mov      x1, x0
013ce9d4: e00314aa mov      x0, x20
013ce9d8: 358aef97 bl       #0xfb12ac ; 
013ce9dc: 88025ff8 ldur     x8, [x20, #-0x10]
013ce9e0: 680600b4 cbz      x8, #0x13ceaac
013ce9e4: 081140f9 ldr      x8, [x8, #0x20]
013ce9e8: 280600b4 cbz      x8, #0x13ceaac
013ce9ec: 081940f9 ldr      x8, [x8, #0x30]
013ce9f0: e80500b4 cbz      x8, #0x13ceaac
013ce9f4: 890240f9 ldr      x9, [x20]
013ce9f8: a90500b4 cbz      x9, #0x13ceaac
013ce9fc: 081140b9 ldr      w8, [x8, #0x10]
013cea00: aaf101d0 adrp     x10, #0x5204000
013cea04: 4abd47f9 ldr      x10, [x10, #0xf78]
013cea08: 14f201b0 adrp     x20, #0x520f000
013cea0c: 281100b9 str      w8, [x9, #0x10]
013cea10: e1330091 add      x1, sp, #0xc
013cea14: 400140f9 ldr      x0, [x10]
013cea18: 943e47f9 ldr      x20, [x20, #0xe78]
013cea1c: e80f00b9 str      w8, [sp, #0xc]
013cea20: 7b8aef97 bl       #0xfb140c ; 
013cea24: 880240f9 ldr      x8, [x20]
013cea28: e10300aa mov      x1, x0
013cea2c: e2031faa mov      x2, xzr
013cea30: e00308aa mov      x0, x8
013cea34: 69bd2494 bl       #0x1cfdfd8 ; System.String$$Format
013cea38: b50240f9 ldr      x21, [x21]
013cea3c: f40300aa mov      x20, x0
013cea40: a81e40f9 ldr      x8, [x21, #0x38]
013cea44: 080140f9 ldr      x8, [x8]
013cea48: 09c94439 ldrb     w9, [x8, #0x132]
013cea4c: 89000037 tbnz     w9, #0, #0x13cea5c
013cea50: e00308aa mov      x0, x8
013cea54: 64c9ee97 bl       #0xf80fe4 ; 
013cea58: e80300aa mov      x8, x0
013cea5c: 09e140b9 ldr      w9, [x8, #0xe0]
013cea60: 69000035 cbnz     w9, #0x13cea6c
013cea64: e00308aa mov      x0, x8
013cea68: 678aef97 bl       #0xfb1404 ; 
013cea6c: a81e40f9 ldr      x8, [x21, #0x38]
013cea70: 000140f9 ldr      x0, [x8]
013cea74: 08c84439 ldrb     w8, [x0, #0x132]
013cea78: 48000037 tbnz     w8, #0, #0x13cea80
013cea7c: 5ac9ee97 bl       #0xf80fe4 ; 
013cea80: 085c40f9 ldr      x8, [x0, #0xb8]
013cea84: e1078052 mov      w1, #0x3f
013cea88: e00313aa mov      x0, x19
013cea8c: e20314aa mov      x2, x20
013cea90: 030140f9 ldr      x3, [x8]
013cea94: e4031faa mov      x4, xzr
013cea98: a2c75094 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
013cea9c: f37b42a9 ldp      x19, x30, [sp, #0x20]
013ceaa0: f55341a9 ldp      x21, x20, [sp, #0x10]
013ceaa4: f60743f8 ldr      x22, [sp], #0x30
013ceaa8: c0035fd6 ret      
013ceaac: 5f8aef97 bl       #0xfb1428 ; 
