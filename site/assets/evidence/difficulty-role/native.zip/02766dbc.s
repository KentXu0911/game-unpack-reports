# Royal.Infrastructure.Utils.Text.EmojiReplacement$$.ctor
# Linear metadata span, not a recovered full CFG.
02766dbc: f80f1cf8 str      x24, [sp, #-0x40]!
02766dc0: f75b01a9 stp      x23, x22, [sp, #0x10]
02766dc4: f55302a9 stp      x21, x20, [sp, #0x20]
02766dc8: f37b03a9 stp      x19, x30, [sp, #0x30]
02766dcc: d37001d0 adrp     x19, #0x5580000
02766dd0: d65301f0 adrp     x22, #0x51e1000
02766dd4: 68e25839 ldrb     w8, [x19, #0x638]
02766dd8: d62642f9 ldr      x22, [x22, #0x448]
02766ddc: f50300aa mov      x21, x0
02766de0: a8020037 tbnz     w8, #0, #0x2766e34
02766de4: 605401d0 adrp     x0, #0x51f4000
02766de8: 00d843f9 ldr      x0, [x0, #0x7b0]
02766dec: 4529a197 bl       #0xfb1300 ; 
02766df0: 80510190 adrp     x0, #0x5196000
02766df4: 002043f9 ldr      x0, [x0, #0x640]
02766df8: 4229a197 bl       #0xfb1300 ; 
02766dfc: c05301f0 adrp     x0, #0x51e1000
02766e00: 002442f9 ldr      x0, [x0, #0x448]
02766e04: 3f29a197 bl       #0xfb1300 ; 
02766e08: 805601d0 adrp     x0, #0x5238000
02766e0c: 009446f9 ldr      x0, [x0, #0xd28]
02766e10: 3c29a197 bl       #0xfb1300 ; 
02766e14: 40550190 adrp     x0, #0x520e000
02766e18: 001847f9 ldr      x0, [x0, #0xe30]
02766e1c: 3929a197 bl       #0xfb1300 ; 
02766e20: 605501d0 adrp     x0, #0x5214000
02766e24: 006440f9 ldr      x0, [x0, #0xc8]
02766e28: 3629a197 bl       #0xfb1300 ; 
02766e2c: 28008052 mov      w8, #1
02766e30: 68e21839 strb     w8, [x19, #0x638]
02766e34: c00240f9 ldr      x0, [x22]
02766e38: 7829a197 bl       #0xfb1418 ; 
02766e3c: 200b00b4 cbz      x0, #0x2766fa0
02766e40: 97510190 adrp     x23, #0x5196000
02766e44: f72243f9 ldr      x23, [x23, #0x640]
02766e48: f40300aa mov      x20, x0
02766e4c: e10240f9 ldr      x1, [x23]
02766e50: ef965a94 bl       #0x3e0ca0c ; System.Collections.Generic.Dictionary<object, object>$$.ctor
02766e54: f30315aa mov      x19, x21
02766e58: 740e01f8 str      x20, [x19, #0x10]!
02766e5c: e00313aa mov      x0, x19
02766e60: e10314aa mov      x1, x20
02766e64: 1229a197 bl       #0xfb12ac ; 
02766e68: c00240f9 ldr      x0, [x22]
02766e6c: 6b29a197 bl       #0xfb1418 ; 
02766e70: 800900b4 cbz      x0, #0x2766fa0
02766e74: e10240f9 ldr      x1, [x23]
02766e78: 775501d0 adrp     x23, #0x5214000
02766e7c: 985601d0 adrp     x24, #0x5238000
02766e80: f76640f9 ldr      x23, [x23, #0xc8]
02766e84: 189746f9 ldr      x24, [x24, #0xd28]
02766e88: f60300aa mov      x22, x0
02766e8c: e0965a94 bl       #0x3e0ca0c ; System.Collections.Generic.Dictionary<object, object>$$.ctor
02766e90: f40315aa mov      x20, x21
02766e94: 968e01f8 str      x22, [x20, #0x18]!
02766e98: e00314aa mov      x0, x20
02766e9c: e10316aa mov      x1, x22
02766ea0: 0329a197 bl       #0xfb12ac ; 
02766ea4: e00315aa mov      x0, x21
02766ea8: e1031faa mov      x1, xzr
02766eac: d231ec97 bl       #0x22735f4 ; System.Object$$.ctor
02766eb0: e00240f9 ldr      x0, [x23]
02766eb4: 010340f9 ldr      x1, [x24]
02766eb8: 8a6bf997 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
02766ebc: 200700b4 cbz      x0, #0x2766fa0
02766ec0: 55550190 adrp     x21, #0x520e000
02766ec4: b51a47f9 ldr      x21, [x21, #0xe30]
02766ec8: e1031faa mov      x1, xzr
02766ecc: b1735694 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02766ed0: a80240f9 ldr      x8, [x21]
02766ed4: f60300aa mov      x22, x0
02766ed8: e00308aa mov      x0, x8
02766edc: 4f29a197 bl       #0xfb1418 ; 
02766ee0: 000600b4 cbz      x0, #0x2766fa0
02766ee4: e10316aa mov      x1, x22
02766ee8: e2031faa mov      x2, xzr
02766eec: f50300aa mov      x21, x0
02766ef0: fd95ed97 bl       #0x22cc6e4 ; System.IO.StringReader$$.ctor
02766ef4: a80240f9 ldr      x8, [x21]
02766ef8: e00315aa mov      x0, x21
02766efc: 09855ea9 ldp      x9, x1, [x8, #0x1e8]
02766f00: 20013fd6 blr      x9
02766f04: 400400b4 cbz      x0, #0x2766f8c
02766f08: 785401d0 adrp     x24, #0x51f4000
02766f0c: 18db43f9 ldr      x24, [x24, #0x7b0]
02766f10: f60300aa mov      x22, x0
02766f14: 61078052 mov      w1, #0x3b
02766f18: e00316aa mov      x0, x22
02766f1c: e2031f2a mov      w2, wzr
02766f20: e3031faa mov      x3, xzr
02766f24: 148cd697 bl       #0x1d09f74 ; System.String$$Split
02766f28: a80240f9 ldr      x8, [x21]
02766f2c: f70300aa mov      x23, x0
02766f30: e00315aa mov      x0, x21
02766f34: 09855ea9 ldp      x9, x1, [x8, #0x1e8]
02766f38: 20013fd6 blr      x9
02766f3c: 370300b4 cbz      x23, #0x2766fa0
02766f40: e81a40b9 ldr      w8, [x23, #0x18]
02766f44: 08030034 cbz      w8, #0x2766fa4
02766f48: 1f050071 cmp      w8, #1
02766f4c: c0020054 b.eq     #0x2766fa4
02766f50: f60300aa mov      x22, x0
02766f54: 600240f9 ldr      x0, [x19]
02766f58: 400200b4 cbz      x0, #0x2766fa0
02766f5c: e10a42a9 ldp      x1, x2, [x23, #0x20]
02766f60: 030340f9 ldr      x3, [x24]
02766f64: 3e995a94 bl       #0x3e0d45c ; System.Collections.Generic.Dictionary<object, object>$$Add
02766f68: e81a40b9 ldr      w8, [x23, #0x18]
02766f6c: 1f050071 cmp      w8, #1
02766f70: a9010054 b.ls     #0x2766fa4
02766f74: 800240f9 ldr      x0, [x20]
02766f78: 400100b4 cbz      x0, #0x2766fa0
02766f7c: e20642a9 ldp      x2, x1, [x23, #0x20]
02766f80: 030340f9 ldr      x3, [x24]
02766f84: 36995a94 bl       #0x3e0d45c ; System.Collections.Generic.Dictionary<object, object>$$Add
02766f88: 76fcffb5 cbnz     x22, #0x2766f14
02766f8c: f37b43a9 ldp      x19, x30, [sp, #0x30]
02766f90: f55342a9 ldp      x21, x20, [sp, #0x20]
02766f94: f75b41a9 ldp      x23, x22, [sp, #0x10]
02766f98: f80744f8 ldr      x24, [sp], #0x40
02766f9c: c0035fd6 ret      
02766fa0: 2229a197 bl       #0xfb1428 ; 
02766fa4: 2329a197 bl       #0xfb1430 ; 
