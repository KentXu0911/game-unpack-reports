# Royal.Player.Context.Units.EventDependencyManager$$LoadConfig
# Linear metadata span, not a recovered full CFG.
0233b4f8: f80f1cf8 str      x24, [sp, #-0x40]!
0233b4fc: f75b01a9 stp      x23, x22, [sp, #0x10]
0233b500: f55302a9 stp      x21, x20, [sp, #0x20]
0233b504: f37b03a9 stp      x19, x30, [sp, #0x30]
0233b508: 159201f0 adrp     x21, #0x557e000
0233b50c: d47401d0 adrp     x20, #0x51d5000
0233b510: a83a5a39 ldrb     w8, [x21, #0x68e]
0233b514: 941e47f9 ldr      x20, [x20, #0xe38]
0233b518: f30300aa mov      x19, x0
0233b51c: c8030037 tbnz     w8, #0, #0x233b594
0233b520: 207701f0 adrp     x0, #0x5222000
0233b524: 00ec42f9 ldr      x0, [x0, #0x5d8]
0233b528: 76d7b197 bl       #0xfb1300 ; 
0233b52c: 407601b0 adrp     x0, #0x5204000
0233b530: 00bc47f9 ldr      x0, [x0, #0xf78]
0233b534: 73d7b197 bl       #0xfb1300 ; 
0233b538: c07301f0 adrp     x0, #0x51b6000
0233b53c: 001843f9 ldr      x0, [x0, #0x630]
0233b540: 70d7b197 bl       #0xfb1300 ; 
0233b544: e07701b0 adrp     x0, #0x5238000
0233b548: 009446f9 ldr      x0, [x0, #0xd28]
0233b54c: 6dd7b197 bl       #0xfb1300 ; 
0233b550: 407401b0 adrp     x0, #0x51c4000
0233b554: 008441f9 ldr      x0, [x0, #0x308]
0233b558: 6ad7b197 bl       #0xfb1300 ; 
0233b55c: 00780190 adrp     x0, #0x523b000
0233b560: 003443f9 ldr      x0, [x0, #0x668]
0233b564: 67d7b197 bl       #0xfb1300 ; 
0233b568: c07401d0 adrp     x0, #0x51d5000
0233b56c: 001c47f9 ldr      x0, [x0, #0xe38]
0233b570: 64d7b197 bl       #0xfb1300 ; 
0233b574: c07601f0 adrp     x0, #0x5216000
0233b578: 005046f9 ldr      x0, [x0, #0xca0]
0233b57c: 61d7b197 bl       #0xfb1300 ; 
0233b580: 607401b0 adrp     x0, #0x51c8000
0233b584: 009041f9 ldr      x0, [x0, #0x320]
0233b588: 5ed7b197 bl       #0xfb1300 ; 
0233b58c: 28008052 mov      w8, #1
0233b590: a83a1a39 strb     w8, [x21, #0x68e]
0233b594: d67301f0 adrp     x22, #0x51b6000
0233b598: 357701f0 adrp     x21, #0x5222000
0233b59c: d61a43f9 ldr      x22, [x22, #0x630]
0233b5a0: b5ee42f9 ldr      x21, [x21, #0x5d8]
0233b5a4: e00313aa mov      x0, x19
0233b5a8: 6e020094 bl       #0x233bf60 ; Royal.Player.Context.Units.EventDependencyManager$$TryMigrateFromKeyValueTable
0233b5ac: 800240f9 ldr      x0, [x20]
0233b5b0: e1031faa mov      x1, xzr
0233b5b4: e2031faa mov      x2, xzr
0233b5b8: a7b82c94 bl       #0x2e69854 ; Royal.Infrastructure.Services.Storage.Tables.LocalKeyValue$$GetString
0233b5bc: e1031faa mov      x1, xzr
0233b5c0: f40300aa mov      x20, x0
0233b5c4: 762fe797 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0233b5c8: a0050036 tbz      w0, #0, #0x233b67c
0233b5cc: 487401b0 adrp     x8, #0x51c4000
0233b5d0: e97701b0 adrp     x9, #0x5238000
0233b5d4: 088541f9 ldr      x8, [x8, #0x308]
0233b5d8: 299546f9 ldr      x9, [x9, #0xd28]
0233b5dc: 7f9200b9 str      wzr, [x19, #0x90]
0233b5e0: 000140f9 ldr      x0, [x8]
0233b5e4: 210140f9 ldr      x1, [x9]
0233b5e8: be190a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0233b5ec: c00b00b4 cbz      x0, #0x233b764
0233b5f0: e1031faa mov      x1, xzr
0233b5f4: e7216794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0233b5f8: c10240f9 ldr      x1, [x22]
0233b5fc: 6b030894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0233b600: e10300aa mov      x1, x0
0233b604: e00313aa mov      x0, x19
0233b608: 018c06f8 str      x1, [x0, #0x68]!
0233b60c: 28d7b197 bl       #0xfb12ac ; 
0233b610: b40240f9 ldr      x20, [x21]
0233b614: 881e40f9 ldr      x8, [x20, #0x38]
0233b618: 000140f9 ldr      x0, [x8]
0233b61c: 08c84439 ldrb     w8, [x0, #0x132]
0233b620: 48000037 tbnz     w8, #0, #0x233b628
0233b624: 7016b197 bl       #0xf80fe4 ; 
0233b628: 08e040b9 ldr      w8, [x0, #0xe0]
0233b62c: 48000035 cbnz     w8, #0x233b634
0233b630: 75d7b197 bl       #0xfb1404 ; 
0233b634: 881e40f9 ldr      x8, [x20, #0x38]
0233b638: 747401b0 adrp     x20, #0x51c8000
0233b63c: 000140f9 ldr      x0, [x8]
0233b640: 08c84439 ldrb     w8, [x0, #0x132]
0233b644: 949241f9 ldr      x20, [x20, #0x320]
0233b648: 48000037 tbnz     w8, #0, #0x233b650
0233b64c: 6616b197 bl       #0xf80fe4 ; 
0233b650: 085c40f9 ldr      x8, [x0, #0xb8]
0233b654: 820240f9 ldr      x2, [x20]
0233b658: e00313aa mov      x0, x19
0233b65c: f37b43a9 ldp      x19, x30, [sp, #0x30]
0233b660: 030140f9 ldr      x3, [x8]
0233b664: f55342a9 ldp      x21, x20, [sp, #0x20]
0233b668: f75b41a9 ldp      x23, x22, [sp, #0x10]
0233b66c: 21078052 mov      w1, #0x39
0233b670: e4031faa mov      x4, xzr
0233b674: f80744f8 ldr      x24, [sp], #0x40
0233b678: aa141314 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0233b67c: c87601f0 adrp     x8, #0x5216000
0233b680: 085146f9 ldr      x8, [x8, #0xca0]
0233b684: 577601b0 adrp     x23, #0x5204000
0233b688: 18780190 adrp     x24, #0x523b000
0233b68c: e1031f2a mov      w1, wzr
0233b690: 000140f9 ldr      x0, [x8]
0233b694: f7be47f9 ldr      x23, [x23, #0xf78]
0233b698: 183743f9 ldr      x24, [x24, #0x668]
0233b69c: e2031faa mov      x2, xzr
0233b6a0: b6b82c94 bl       #0x2e69978 ; Royal.Infrastructure.Services.Storage.Tables.LocalKeyValue$$GetInt
0233b6a4: 609200b9 str      w0, [x19, #0x90]
0233b6a8: c10240f9 ldr      x1, [x22]
0233b6ac: e00314aa mov      x0, x20
0233b6b0: 3e030894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0233b6b4: e10300aa mov      x1, x0
0233b6b8: e00313aa mov      x0, x19
0233b6bc: 018c06f8 str      x1, [x0, #0x68]!
0233b6c0: fbd6b197 bl       #0xfb12ac ; 
0233b6c4: 689240b9 ldr      w8, [x19, #0x90]
0233b6c8: e00240f9 ldr      x0, [x23]
0233b6cc: e1330091 add      x1, sp, #0xc
0233b6d0: e80f00b9 str      w8, [sp, #0xc]
0233b6d4: 4ed7b197 bl       #0xfb140c ; 
0233b6d8: 080340f9 ldr      x8, [x24]
0233b6dc: e10300aa mov      x1, x0
0233b6e0: e2031faa mov      x2, xzr
0233b6e4: e00308aa mov      x0, x8
0233b6e8: 3c0ae797 bl       #0x1cfdfd8 ; System.String$$Format
0233b6ec: b50240f9 ldr      x21, [x21]
0233b6f0: f40300aa mov      x20, x0
0233b6f4: a81e40f9 ldr      x8, [x21, #0x38]
0233b6f8: 080140f9 ldr      x8, [x8]
0233b6fc: 09c94439 ldrb     w9, [x8, #0x132]
0233b700: 89000037 tbnz     w9, #0, #0x233b710
0233b704: e00308aa mov      x0, x8
0233b708: 3716b197 bl       #0xf80fe4 ; 
0233b70c: e80300aa mov      x8, x0
0233b710: 09e140b9 ldr      w9, [x8, #0xe0]
0233b714: 69000035 cbnz     w9, #0x233b720
0233b718: e00308aa mov      x0, x8
0233b71c: 3ad7b197 bl       #0xfb1404 ; 
0233b720: a81e40f9 ldr      x8, [x21, #0x38]
0233b724: 000140f9 ldr      x0, [x8]
0233b728: 08c84439 ldrb     w8, [x0, #0x132]
0233b72c: 48000037 tbnz     w8, #0, #0x233b734
0233b730: 2d16b197 bl       #0xf80fe4 ; 
0233b734: 085c40f9 ldr      x8, [x0, #0xb8]
0233b738: 21078052 mov      w1, #0x39
0233b73c: e00313aa mov      x0, x19
0233b740: e20314aa mov      x2, x20
0233b744: 030140f9 ldr      x3, [x8]
0233b748: e4031faa mov      x4, xzr
0233b74c: 75141394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0233b750: f37b43a9 ldp      x19, x30, [sp, #0x30]
0233b754: f55342a9 ldp      x21, x20, [sp, #0x20]
0233b758: f75b41a9 ldp      x23, x22, [sp, #0x10]
0233b75c: f80744f8 ldr      x24, [sp], #0x40
0233b760: c0035fd6 ret      
0233b764: 31d7b197 bl       #0xfb1428 ; 
