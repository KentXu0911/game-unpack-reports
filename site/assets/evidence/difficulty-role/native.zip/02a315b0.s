# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ClearUserCaches
# Linear metadata span, not a recovered full CFG.
02a315b0: 1f600039 strb     wzr, [x0, #0x18]
02a315b4: 1f800039 strb     wzr, [x0, #0x20]
02a315b8: 1f200139 strb     wzr, [x0, #0x48]
02a315bc: c0035fd6 ret      
