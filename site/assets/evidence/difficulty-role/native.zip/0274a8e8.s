# Royal.Scenes.Game.MagicDuke.Charger.ChargerConfigHelper$$ReadConfig
# Linear metadata span, not a recovered full CFG.
0274a8e8: f60f1df8 str      x22, [sp, #-0x30]!
0274a8ec: f55301a9 stp      x21, x20, [sp, #0x10]
0274a8f0: f37b02a9 stp      x19, x30, [sp, #0x20]
0274a8f4: b37101d0 adrp     x19, #0x5580000
0274a8f8: b55501b0 adrp     x21, #0x51ff000
0274a8fc: 68e65439 ldrb     w8, [x19, #0x539]
0274a900: b57640f9 ldr      x21, [x21, #0xe8]
0274a904: e8010037 tbnz     w8, #0, #0x274a940
0274a908: a05501b0 adrp     x0, #0x51ff000
0274a90c: 007440f9 ldr      x0, [x0, #0xe8]
0274a910: 7c9aa197 bl       #0xfb1300 ; 
0274a914: 205401b0 adrp     x0, #0x51cf000
0274a918: 003c42f9 ldr      x0, [x0, #0x478]
0274a91c: 799aa197 bl       #0xfb1300 ; 
0274a920: 20570190 adrp     x0, #0x522e000
0274a924: 00c041f9 ldr      x0, [x0, #0x380]
0274a928: 769aa197 bl       #0xfb1300 ; 
0274a92c: 605701d0 adrp     x0, #0x5238000
0274a930: 009446f9 ldr      x0, [x0, #0xd28]
0274a934: 739aa197 bl       #0xfb1300 ; 
0274a938: 28008052 mov      w8, #1
0274a93c: 68e61439 strb     w8, [x19, #0x539]
0274a940: a00240f9 ldr      x0, [x21]
0274a944: 08e040b9 ldr      w8, [x0, #0xe0]
0274a948: 68000035 cbnz     w8, #0x274a954
0274a94c: ae9aa197 bl       #0xfb1404 ; 
0274a950: a00240f9 ldr      x0, [x21]
0274a954: 085c40f9 ldr      x8, [x0, #0xb8]
0274a958: e1031faa mov      x1, xzr
0274a95c: 000140f9 ldr      x0, [x8]
0274a960: 35d0ed97 bl       #0x22bea34 ; System.IO.Directory$$Exists
0274a964: a0050036 tbz      w0, #0, #0x274aa18
0274a968: a00240f9 ldr      x0, [x21]
0274a96c: 36570190 adrp     x22, #0x522e000
0274a970: 08e040b9 ldr      w8, [x0, #0xe0]
0274a974: d6c241f9 ldr      x22, [x22, #0x380]
0274a978: 68000035 cbnz     w8, #0x274a984
0274a97c: a29aa197 bl       #0xfb1404 ; 
0274a980: a00240f9 ldr      x0, [x21]
0274a984: 085c40f9 ldr      x8, [x0, #0xb8]
0274a988: 130140f9 ldr      x19, [x8]
0274a98c: 8efdff97 bl       #0x2749fc4 ; Royal.Scenes.Game.MagicDuke.Charger.ChargerConfigHelper$$get_Filename
0274a990: c80240f9 ldr      x8, [x22]
0274a994: f40300aa mov      x20, x0
0274a998: 09e140b9 ldr      w9, [x8, #0xe0]
0274a99c: 69000035 cbnz     w9, #0x274a9a8
0274a9a0: e00308aa mov      x0, x8
0274a9a4: 989aa197 bl       #0xfb1404 ; 
0274a9a8: e00313aa mov      x0, x19
0274a9ac: e10314aa mov      x1, x20
0274a9b0: e2031faa mov      x2, xzr
0274a9b4: 71e4ed97 bl       #0x22c3b78 ; System.IO.Path$$Combine
0274a9b8: e1031faa mov      x1, xzr
0274a9bc: 07d9ed97 bl       #0x22c0dd8 ; System.IO.File$$Exists
0274a9c0: c0020036 tbz      w0, #0, #0x274aa18
0274a9c4: a00240f9 ldr      x0, [x21]
0274a9c8: 08e040b9 ldr      w8, [x0, #0xe0]
0274a9cc: 68000035 cbnz     w8, #0x274a9d8
0274a9d0: 8d9aa197 bl       #0xfb1404 ; 
0274a9d4: a00240f9 ldr      x0, [x21]
0274a9d8: 085c40f9 ldr      x8, [x0, #0xb8]
0274a9dc: 130140f9 ldr      x19, [x8]
0274a9e0: 79fdff97 bl       #0x2749fc4 ; Royal.Scenes.Game.MagicDuke.Charger.ChargerConfigHelper$$get_Filename
0274a9e4: c80240f9 ldr      x8, [x22]
0274a9e8: f40300aa mov      x20, x0
0274a9ec: 09e140b9 ldr      w9, [x8, #0xe0]
0274a9f0: 69000035 cbnz     w9, #0x274a9fc
0274a9f4: e00308aa mov      x0, x8
0274a9f8: 839aa197 bl       #0xfb1404 ; 
0274a9fc: e00313aa mov      x0, x19
0274aa00: e10314aa mov      x1, x20
0274aa04: e2031faa mov      x2, xzr
0274aa08: 5ce4ed97 bl       #0x22c3b78 ; System.IO.Path$$Combine
0274aa0c: e1031faa mov      x1, xzr
0274aa10: 28daed97 bl       #0x22c12b0 ; System.IO.File$$ReadAllText
0274aa14: 0f000014 b        #0x274aa50 ; 
0274aa18: a00240f9 ldr      x0, [x21]
0274aa1c: 735701d0 adrp     x19, #0x5238000
0274aa20: 08e040b9 ldr      w8, [x0, #0xe0]
0274aa24: 739646f9 ldr      x19, [x19, #0xd28]
0274aa28: 68000035 cbnz     w8, #0x274aa34
0274aa2c: 769aa197 bl       #0xfb1404 ; 
0274aa30: a00240f9 ldr      x0, [x21]
0274aa34: 085c40f9 ldr      x8, [x0, #0xb8]
0274aa38: 610240f9 ldr      x1, [x19]
0274aa3c: 000540f9 ldr      x0, [x8, #8]
0274aa40: a8dcf997 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0274aa44: a00200b4 cbz      x0, #0x274aa98
0274aa48: e1031faa mov      x1, xzr
0274aa4c: d1e45694 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0274aa50: 285401b0 adrp     x8, #0x51cf000
0274aa54: 083d42f9 ldr      x8, [x8, #0x478]
0274aa58: 010140f9 ldr      x1, [x8]
0274aa5c: 53c6f797 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0274aa60: a80240f9 ldr      x8, [x21]
0274aa64: f30300aa mov      x19, x0
0274aa68: 09e140b9 ldr      w9, [x8, #0xe0]
0274aa6c: 89000035 cbnz     w9, #0x274aa7c
0274aa70: e00308aa mov      x0, x8
0274aa74: 649aa197 bl       #0xfb1404 ; 
0274aa78: a80240f9 ldr      x8, [x21]
0274aa7c: 005d40f9 ldr      x0, [x8, #0xb8]
0274aa80: e10313aa mov      x1, x19
0274aa84: 138c01f8 str      x19, [x0, #0x18]!
0274aa88: f37b42a9 ldp      x19, x30, [sp, #0x20]
0274aa8c: f55341a9 ldp      x21, x20, [sp, #0x10]
0274aa90: f60743f8 ldr      x22, [sp], #0x30
0274aa94: 069aa117 b        #0xfb12ac ; 
0274aa98: 649aa197 bl       #0xfb1428 ; 
