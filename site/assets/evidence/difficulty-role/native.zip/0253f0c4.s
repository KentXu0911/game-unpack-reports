# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArray<object>
# Linear metadata span, not a recovered full CFG.
0253f0c4: fa0f1bf8 str      x26, [sp, #-0x50]!
0253f0c8: f96301a9 stp      x25, x24, [sp, #0x10]
0253f0cc: f75b02a9 stp      x23, x22, [sp, #0x20]
0253f0d0: f55303a9 stp      x21, x20, [sp, #0x30]
0253f0d4: f37b04a9 stp      x19, x30, [sp, #0x40]
0253f0d8: 210600b4 cbz      x1, #0x253f19c
0253f0dc: 351840b9 ldr      w21, [x1, #0x18]
0253f0e0: f30301aa mov      x19, x1
0253f0e4: bf0a0071 cmp      w21, #2
0253f0e8: cb040054 b.lt     #0x253f180
0253f0ec: a87e4093 sxtw     x8, w21
0253f0f0: 69ce358b add      x9, x19, w21, sxtw #3
0253f0f4: f40300aa mov      x20, x0
0253f0f8: 1a050091 add      x26, x8, #1
0253f0fc: 36610091 add      x22, x9, #0x18
0253f100: 801a40f9 ldr      x0, [x20, #0x30]
0253f104: c00400b4 cbz      x0, #0x253f19c
0253f108: 080040f9 ldr      x8, [x0]
0253f10c: e103152a mov      w1, w21
0253f110: 09895aa9 ldp      x9, x2, [x8, #0x1a8]
0253f114: 20013fd6 blr      x9
0253f118: 680e40f9 ldr      x8, [x19, #0x18]
0253f11c: 1f00086b cmp      w0, w8
0253f120: c2030054 b.hs     #0x253f198
0253f124: 78ce208b add      x24, x19, w0, sxtw #3
0253f128: 010f42f8 ldr      x1, [x24, #0x20]!
0253f12c: 490b00d1 sub      x9, x26, #2
0253f130: 087d4092 and      x8, x8, #0xffffffff
0253f134: f703002a mov      w23, w0
0253f138: 3f0108eb cmp      x9, x8
0253f13c: e2020054 b.hs     #0x253f198
0253f140: d90240f9 ldr      x25, [x22]
0253f144: e00316aa mov      x0, x22
0253f148: c10200f9 str      x1, [x22]
0253f14c: 58c8a997 bl       #0xfb12ac ; 
0253f150: 681a40b9 ldr      w8, [x19, #0x18]
0253f154: ff02086b cmp      w23, w8
0253f158: 02020054 b.hs     #0x253f198
0253f15c: e00318aa mov      x0, x24
0253f160: e10319aa mov      x1, x25
0253f164: 190300f9 str      x25, [x24]
0253f168: 51c8a997 bl       #0xfb12ac ; 
0253f16c: 5a0700d1 sub      x26, x26, #1
0253f170: b5060051 sub      w21, w21, #1
0253f174: 5f0b00f1 cmp      x26, #2
0253f178: d62200d1 sub      x22, x22, #8
0253f17c: 2cfcff54 b.gt     #0x253f100
0253f180: f37b44a9 ldp      x19, x30, [sp, #0x40]
0253f184: f55343a9 ldp      x21, x20, [sp, #0x30]
0253f188: f75b42a9 ldp      x23, x22, [sp, #0x20]
0253f18c: f96341a9 ldp      x25, x24, [sp, #0x10]
0253f190: fa0745f8 ldr      x26, [sp], #0x50
0253f194: c0035fd6 ret      
0253f198: a6c8a997 bl       #0xfb1430 ; 
0253f19c: a3c8a997 bl       #0xfb1428 ; 
