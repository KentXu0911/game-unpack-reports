# Royal.Scenes.Home.Ui.Dialogs.DailyLightningRush.Scripts.DailyLightningRushConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
03d1fa60: ff0301d1 sub      sp, sp, #0x40
03d1fa64: f75b01a9 stp      x23, x22, [sp, #0x10]
03d1fa68: f55302a9 stp      x21, x20, [sp, #0x20]
03d1fa6c: f37b03a9 stp      x19, x30, [sp, #0x30]
03d1fa70: 74c300b0 adrp     x20, #0x558c000
03d1fa74: 88027a39 ldrb     w8, [x20, #0xe80]
03d1fa78: f30300aa mov      x19, x0
03d1fa7c: e8040037 tbnz     w8, #0, #0x3d1fb18
03d1fa80: 00a800f0 adrp     x0, #0x5222000
03d1fa84: 00ec42f9 ldr      x0, [x0, #0x5d8]
03d1fa88: 1e464a97 bl       #0xfb1300 ; 
03d1fa8c: a0a400f0 adrp     x0, #0x51b6000
03d1fa90: 00e841f9 ldr      x0, [x0, #0x3d0]
03d1fa94: 1b464a97 bl       #0xfb1300 ; 
03d1fa98: a0a300b0 adrp     x0, #0x5194000
03d1fa9c: 00f443f9 ldr      x0, [x0, #0x7e8]
03d1faa0: 18464a97 bl       #0xfb1300 ; 
03d1faa4: a0a700f0 adrp     x0, #0x5216000
03d1faa8: 001c44f9 ldr      x0, [x0, #0x838]
03d1faac: 15464a97 bl       #0xfb1300 ; 
03d1fab0: 20a600f0 adrp     x0, #0x51e6000
03d1fab4: 007840f9 ldr      x0, [x0, #0xf0]
03d1fab8: 12464a97 bl       #0xfb1300 ; 
03d1fabc: 20a700b0 adrp     x0, #0x5204000
03d1fac0: 00bc47f9 ldr      x0, [x0, #0xf78]
03d1fac4: 0f464a97 bl       #0xfb1300 ; 
03d1fac8: 40a700d0 adrp     x0, #0x5209000
03d1facc: 00c445f9 ldr      x0, [x0, #0xb88]
03d1fad0: 0c464a97 bl       #0xfb1300 ; 
03d1fad4: c0a800b0 adrp     x0, #0x5238000
03d1fad8: 009446f9 ldr      x0, [x0, #0xd28]
03d1fadc: 09464a97 bl       #0xfb1300 ; 
03d1fae0: 00a800b0 adrp     x0, #0x5220000
03d1fae4: 000443f9 ldr      x0, [x0, #0x608]
03d1fae8: 06464a97 bl       #0xfb1300 ; 
03d1faec: a0a700b0 adrp     x0, #0x5214000
03d1faf0: 00ac45f9 ldr      x0, [x0, #0xb58]
03d1faf4: 03464a97 bl       #0xfb1300 ; 
03d1faf8: 40a60090 adrp     x0, #0x51e7000
03d1fafc: 004447f9 ldr      x0, [x0, #0xe88]
03d1fb00: 00464a97 bl       #0xfb1300 ; 
03d1fb04: 80a500d0 adrp     x0, #0x51d1000
03d1fb08: 000445f9 ldr      x0, [x0, #0xa08]
03d1fb0c: fd454a97 bl       #0xfb1300 ; 
03d1fb10: 28008052 mov      w8, #1
03d1fb14: 88023a39 strb     w8, [x20, #0xe80]
03d1fb18: 681640f9 ldr      x8, [x19, #0x28]
03d1fb1c: 681300b4 cbz      x8, #0x3d1fd88
03d1fb20: 081140f9 ldr      x8, [x8, #0x20]
03d1fb24: 281300b4 cbz      x8, #0x3d1fd88
03d1fb28: 161940f9 ldr      x22, [x8, #0x30]
03d1fb2c: f61200b4 cbz      x22, #0x3d1fd88
03d1fb30: c00a40f9 ldr      x0, [x22, #0x10]
03d1fb34: 54a700d0 adrp     x20, #0x5209000
03d1fb38: 15a800f0 adrp     x21, #0x5222000
03d1fb3c: 94c645f9 ldr      x20, [x20, #0xb88]
03d1fb40: b5ee42f9 ldr      x21, [x21, #0x5d8]
03d1fb44: e1031faa mov      x1, xzr
03d1fb48: 159e7f97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
03d1fb4c: e0050036 tbz      w0, #0, #0x3d1fc08
03d1fb50: b50240f9 ldr      x21, [x21]
03d1fb54: a81e40f9 ldr      x8, [x21, #0x38]
03d1fb58: 000140f9 ldr      x0, [x8]
03d1fb5c: 08c84439 ldrb     w8, [x0, #0x132]
03d1fb60: 48000037 tbnz     w8, #0, #0x3d1fb68
03d1fb64: 20854997 bl       #0xf80fe4 ; 
03d1fb68: 08e040b9 ldr      w8, [x0, #0xe0]
03d1fb6c: 48000035 cbnz     w8, #0x3d1fb74
03d1fb70: 25464a97 bl       #0xfb1404 ; 
03d1fb74: a81e40f9 ldr      x8, [x21, #0x38]
03d1fb78: 97a500d0 adrp     x23, #0x51d1000
03d1fb7c: b6a700b0 adrp     x22, #0x5214000
03d1fb80: d5a800b0 adrp     x21, #0x5238000
03d1fb84: 000140f9 ldr      x0, [x8]
03d1fb88: 08c84439 ldrb     w8, [x0, #0x132]
03d1fb8c: f70645f9 ldr      x23, [x23, #0xa08]
03d1fb90: d6ae45f9 ldr      x22, [x22, #0xb58]
03d1fb94: b59646f9 ldr      x21, [x21, #0xd28]
03d1fb98: 48000037 tbnz     w8, #0, #0x3d1fba0
03d1fb9c: 12854997 bl       #0xf80fe4 ; 
03d1fba0: 085c40f9 ldr      x8, [x0, #0xb8]
03d1fba4: e20240f9 ldr      x2, [x23]
03d1fba8: 01098052 mov      w1, #0x48
03d1fbac: e00313aa mov      x0, x19
03d1fbb0: 030140f9 ldr      x3, [x8]
03d1fbb4: e4031faa mov      x4, xzr
03d1fbb8: 5a83ab97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03d1fbbc: c00240f9 ldr      x0, [x22]
03d1fbc0: a10240f9 ldr      x1, [x21]
03d1fbc4: 4788a297 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03d1fbc8: 000e00b4 cbz      x0, #0x3d1fd88
03d1fbcc: e1031faa mov      x1, xzr
03d1fbd0: 7090ff97 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03d1fbd4: 810240f9 ldr      x1, [x20]
03d1fbd8: f471a097 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03d1fbdc: 600e02f8 str      x0, [x19, #0x20]!
03d1fbe0: e10300aa mov      x1, x0
03d1fbe4: e00313aa mov      x0, x19
03d1fbe8: b1454a97 bl       #0xfb12ac ; 
03d1fbec: 28008052 mov      w8, #1
03d1fbf0: 68121f38 sturb    w8, [x19, #-0xf]
03d1fbf4: f37b43a9 ldp      x19, x30, [sp, #0x30]
03d1fbf8: f55342a9 ldp      x21, x20, [sp, #0x20]
03d1fbfc: f75b41a9 ldp      x23, x22, [sp, #0x10]
03d1fc00: ff030191 add      sp, sp, #0x40
03d1fc04: c0035fd6 ret      
03d1fc08: c00a40f9 ldr      x0, [x22, #0x10]
03d1fc0c: 810240f9 ldr      x1, [x20]
03d1fc10: e671a097 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03d1fc14: 600800b4 cbz      x0, #0x3d1fd20
03d1fc18: 081040f9 ldr      x8, [x0, #0x20]
03d1fc1c: e10300aa mov      x1, x0
03d1fc20: 080800b4 cbz      x8, #0x3d1fd20
03d1fc24: 081940b9 ldr      w8, [x8, #0x18]
03d1fc28: 1f0d0071 cmp      w8, #3
03d1fc2c: a1070054 b.ne     #0x3d1fd20
03d1fc30: 280c40f9 ldr      x8, [x1, #0x18]
03d1fc34: 680700b4 cbz      x8, #0x3d1fd20
03d1fc38: 081940b9 ldr      w8, [x8, #0x18]
03d1fc3c: 1f0d0071 cmp      w8, #3
03d1fc40: 01070054 b.ne     #0x3d1fd20
03d1fc44: f40313aa mov      x20, x19
03d1fc48: 810e02f8 str      x1, [x20, #0x20]!
03d1fc4c: e00314aa mov      x0, x20
03d1fc50: 97454a97 bl       #0xfb12ac ; 
03d1fc54: 880640f9 ldr      x8, [x20, #8]
03d1fc58: 880900b4 cbz      x8, #0x3d1fd88
03d1fc5c: 081140f9 ldr      x8, [x8, #0x20]
03d1fc60: 480900b4 cbz      x8, #0x3d1fd88
03d1fc64: 081d40f9 ldr      x8, [x8, #0x38]
03d1fc68: 080900b4 cbz      x8, #0x3d1fd88
03d1fc6c: 890240f9 ldr      x9, [x20]
03d1fc70: c90800b4 cbz      x9, #0x3d1fd88
03d1fc74: 081140b9 ldr      w8, [x8, #0x10]
03d1fc78: 2aa700b0 adrp     x10, #0x5204000
03d1fc7c: 4abd47f9 ldr      x10, [x10, #0xf78]
03d1fc80: 2b008052 mov      w11, #1
03d1fc84: 281100b9 str      w8, [x9, #0x10]
03d1fc88: 6b460039 strb     w11, [x19, #0x11]
03d1fc8c: 400140f9 ldr      x0, [x10]
03d1fc90: 14a800b0 adrp     x20, #0x5220000
03d1fc94: 940643f9 ldr      x20, [x20, #0x608]
03d1fc98: e1330091 add      x1, sp, #0xc
03d1fc9c: e80f00b9 str      w8, [sp, #0xc]
03d1fca0: db454a97 bl       #0xfb140c ; 
03d1fca4: 880240f9 ldr      x8, [x20]
03d1fca8: e10300aa mov      x1, x0
03d1fcac: e2031faa mov      x2, xzr
03d1fcb0: e00308aa mov      x0, x8
03d1fcb4: c9787f97 bl       #0x1cfdfd8 ; System.String$$Format
03d1fcb8: b50240f9 ldr      x21, [x21]
03d1fcbc: f40300aa mov      x20, x0
03d1fcc0: a81e40f9 ldr      x8, [x21, #0x38]
03d1fcc4: 080140f9 ldr      x8, [x8]
03d1fcc8: 09c94439 ldrb     w9, [x8, #0x132]
03d1fccc: 89000037 tbnz     w9, #0, #0x3d1fcdc
03d1fcd0: e00308aa mov      x0, x8
03d1fcd4: c4844997 bl       #0xf80fe4 ; 
03d1fcd8: e80300aa mov      x8, x0
03d1fcdc: 09e140b9 ldr      w9, [x8, #0xe0]
03d1fce0: 69000035 cbnz     w9, #0x3d1fcec
03d1fce4: e00308aa mov      x0, x8
03d1fce8: c7454a97 bl       #0xfb1404 ; 
03d1fcec: a81e40f9 ldr      x8, [x21, #0x38]
03d1fcf0: 000140f9 ldr      x0, [x8]
03d1fcf4: 08c84439 ldrb     w8, [x0, #0x132]
03d1fcf8: 48000037 tbnz     w8, #0, #0x3d1fd00
03d1fcfc: ba844997 bl       #0xf80fe4 ; 
03d1fd00: 085c40f9 ldr      x8, [x0, #0xb8]
03d1fd04: 01098052 mov      w1, #0x48
03d1fd08: e00313aa mov      x0, x19
03d1fd0c: e20314aa mov      x2, x20
03d1fd10: 030140f9 ldr      x3, [x8]
03d1fd14: e4031faa mov      x4, xzr
03d1fd18: 0283ab97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03d1fd1c: b6ffff17 b        #0x3d1fbf4 ; 
03d1fd20: a8a700f0 adrp     x8, #0x5216000
03d1fd24: 081d44f9 ldr      x8, [x8, #0x838]
03d1fd28: 000140f9 ldr      x0, [x8]
03d1fd2c: bb454a97 bl       #0xfb1418 ; 
03d1fd30: c00200b4 cbz      x0, #0x3d1fd88
03d1fd34: 48a60090 adrp     x8, #0x51e7000
03d1fd38: 084547f9 ldr      x8, [x8, #0xe88]
03d1fd3c: 34a600f0 adrp     x20, #0x51e6000
03d1fd40: e2031faa mov      x2, xzr
03d1fd44: f30300aa mov      x19, x0
03d1fd48: 010140f9 ldr      x1, [x8]
03d1fd4c: 947a40f9 ldr      x20, [x20, #0xf0]
03d1fd50: 5c1e9597 bl       #0x22676c0 ; System.Exception$$.ctor
03d1fd54: 800240f9 ldr      x0, [x20]
03d1fd58: 08e040b9 ldr      w8, [x0, #0xe0]
03d1fd5c: 48000035 cbnz     w8, #0x3d1fd64
03d1fd60: a9454a97 bl       #0xfb1404 ; 
03d1fd64: e00313aa mov      x0, x19
03d1fd68: f37b43a9 ldp      x19, x30, [sp, #0x30]
03d1fd6c: f55342a9 ldp      x21, x20, [sp, #0x20]
03d1fd70: f75b41a9 ldp      x23, x22, [sp, #0x10]
03d1fd74: 01098052 mov      w1, #0x48
03d1fd78: e2031faa mov      x2, xzr
03d1fd7c: e3031faa mov      x3, xzr
03d1fd80: ff030191 add      sp, sp, #0x40
03d1fd84: 98e6c417 b        #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
03d1fd88: a8454a97 bl       #0xfb1428 ; 
