# Royal.Player.Context.Units.SpaceMissionManager$$MigrateConfigForOldCardCollection
# Linear metadata span, not a recovered full CFG.
01da497c: f60f1df8 str      x22, [sp, #-0x30]!
01da4980: f55301a9 stp      x21, x20, [sp, #0x10]
01da4984: f37b02a9 stp      x19, x30, [sp, #0x20]
01da4988: b4be01f0 adrp     x20, #0x557b000
01da498c: d5a10190 adrp     x21, #0x51dc000
01da4990: b6a40190 adrp     x22, #0x5238000
01da4994: 885a7b39 ldrb     w8, [x20, #0xed6]
01da4998: b50a45f9 ldr      x21, [x21, #0xa10]
01da499c: d69646f9 ldr      x22, [x22, #0xd28]
01da49a0: f30300aa mov      x19, x0
01da49a4: e8010037 tbnz     w8, #0, #0x1da49e0
01da49a8: 00a301d0 adrp     x0, #0x5206000
01da49ac: 000840f9 ldr      x0, [x0, #0x10]
01da49b0: 5432c897 bl       #0xfb1300 ; 
01da49b4: a0a40190 adrp     x0, #0x5238000
01da49b8: 009446f9 ldr      x0, [x0, #0xd28]
01da49bc: 5132c897 bl       #0xfb1300 ; 
01da49c0: 20a301b0 adrp     x0, #0x5209000
01da49c4: 008447f9 ldr      x0, [x0, #0xf08]
01da49c8: 4e32c897 bl       #0xfb1300 ; 
01da49cc: c0a10190 adrp     x0, #0x51dc000
01da49d0: 000845f9 ldr      x0, [x0, #0xa10]
01da49d4: 4b32c897 bl       #0xfb1300 ; 
01da49d8: 28008052 mov      w8, #1
01da49dc: 885a3b39 strb     w8, [x20, #0xed6]
01da49e0: a00240f9 ldr      x0, [x21]
01da49e4: c10240f9 ldr      x1, [x22]
01da49e8: be742094 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01da49ec: 200300b4 cbz      x0, #0x1da4a50
01da49f0: 35a301b0 adrp     x21, #0x5209000
01da49f4: 16a301d0 adrp     x22, #0x5206000
01da49f8: b58647f9 ldr      x21, [x21, #0xf08]
01da49fc: d60a40f9 ldr      x22, [x22, #0x10]
01da4a00: e1031faa mov      x1, xzr
01da4a04: f40300aa mov      x20, x0
01da4a08: e27c7d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01da4a0c: a80240f9 ldr      x8, [x21]
01da4a10: e10300aa mov      x1, x0
01da4a14: e2031faa mov      x2, xzr
01da4a18: e00308aa mov      x0, x8
01da4a1c: 1bed4294 bl       #0x2e5fe88 ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$SetString
01da4a20: e00314aa mov      x0, x20
01da4a24: e1031faa mov      x1, xzr
01da4a28: da7c7d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01da4a2c: c10240f9 ldr      x1, [x22]
01da4a30: 5e5e1e94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01da4a34: 600e02f8 str      x0, [x19, #0x20]!
01da4a38: e10300aa mov      x1, x0
01da4a3c: e00313aa mov      x0, x19
01da4a40: f37b42a9 ldp      x19, x30, [sp, #0x20]
01da4a44: f55341a9 ldp      x21, x20, [sp, #0x10]
01da4a48: f60743f8 ldr      x22, [sp], #0x30
01da4a4c: 1832c817 b        #0xfb12ac ; 
01da4a50: 7632c897 bl       #0xfb1428 ; 
