# Royal.Player.Context.Units.LevelEpisodeHelper$$GetUpdatedMoveCount
# Linear metadata span, not a recovered full CFG.
02059c78: f553bea9 stp      x21, x20, [sp, #-0x20]!
02059c7c: f37b01a9 stp      x19, x30, [sp, #0x10]
02059c80: 35a90190 adrp     x21, #0x557d000
02059c84: a82a4839 ldrb     w8, [x21, #0x20a]
02059c88: f303012a mov      w19, w1
02059c8c: f40300aa mov      x20, x0
02059c90: c8000037 tbnz     w8, #0, #0x2059ca8
02059c94: c08c01b0 adrp     x0, #0x51f2000
02059c98: 003444f9 ldr      x0, [x0, #0x868]
02059c9c: 995dbd97 bl       #0xfb1300 ; 
02059ca0: 28008052 mov      w8, #1
02059ca4: a82a0839 strb     w8, [x21, #0x20a]
02059ca8: 940a40f9 ldr      x20, [x20, #0x10]
02059cac: b40300b4 cbz      x20, #0x2059d20
02059cb0: ca8c01b0 adrp     x10, #0x51f2000
02059cb4: 880240f9 ldr      x8, [x20]
02059cb8: 4a3544f9 ldr      x10, [x10, #0x868]
02059cbc: 09554279 ldrh     w9, [x8, #0x12a]
02059cc0: 410140f9 ldr      x1, [x10]
02059cc4: 290100b4 cbz      x9, #0x2059ce8
02059cc8: 0a5940f9 ldr      x10, [x8, #0xb0]
02059ccc: 4a210091 add      x10, x10, #8
02059cd0: 4b815ff8 ldur     x11, [x10, #-8]
02059cd4: 7f0101eb cmp      x11, x1
02059cd8: 00010054 b.eq     #0x2059cf8
02059cdc: 290500f1 subs     x9, x9, #1
02059ce0: 4a410091 add      x10, x10, #0x10
02059ce4: 61ffff54 b.ne     #0x2059cd0
02059ce8: 42008052 mov      w2, #2
02059cec: e00314aa mov      x0, x20
02059cf0: 799dbc97 bl       #0xf812d4 ; 
02059cf4: 05000014 b        #0x2059d08 ; 
02059cf8: 490140b9 ldr      w9, [x10]
02059cfc: 29090011 add      w9, w9, #2
02059d00: 08d1298b add      x8, x8, w9, sxtw #4
02059d04: 00e10491 add      x0, x8, #0x138
02059d08: 030840a9 ldp      x3, x2, [x0]
02059d0c: e103132a mov      w1, w19
02059d10: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059d14: e00314aa mov      x0, x20
02059d18: f553c2a8 ldp      x21, x20, [sp], #0x20
02059d1c: 60001fd6 br       x3
02059d20: c25dbd97 bl       #0xfb1428 ; 
