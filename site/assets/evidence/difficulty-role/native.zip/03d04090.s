# UnityEngine.TextAsset$$ToString
# Linear metadata span, not a recovered full CFG.
03d04090: 40ffff17 b        #0x3d03d90 ; UnityEngine.TextAsset$$get_text
