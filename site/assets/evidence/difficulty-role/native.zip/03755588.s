# Royal.Scenes.Home.Ui.Dialogs.PuzzleBreak.Scripts.PuzzleBreakConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
03755588: f60f1df8 str      x22, [sp, #-0x30]!
0375558c: f55301a9 stp      x21, x20, [sp, #0x10]
03755590: f37b02a9 stp      x19, x30, [sp, #0x20]
03755594: 94f100f0 adrp     x20, #0x5588000
03755598: 882e6839 ldrb     w8, [x20, #0xa0b]
0375559c: f30300aa mov      x19, x0
037555a0: c8030037 tbnz     w8, #0, #0x3755618
037555a4: 60d600b0 adrp     x0, #0x5222000
037555a8: 00ec42f9 ldr      x0, [x0, #0x5d8]
037555ac: 556f6197 bl       #0xfb1300 ; 
037555b0: c0d50090 adrp     x0, #0x520d000
037555b4: 00b042f9 ldr      x0, [x0, #0x560]
037555b8: 526f6197 bl       #0xfb1300 ; 
037555bc: c0d300d0 adrp     x0, #0x51cf000
037555c0: 009842f9 ldr      x0, [x0, #0x530]
037555c4: 4f6f6197 bl       #0xfb1300 ; 
037555c8: 60d500f0 adrp     x0, #0x5204000
037555cc: 00bc47f9 ldr      x0, [x0, #0xf78]
037555d0: 4c6f6197 bl       #0xfb1300 ; 
037555d4: 00d400b0 adrp     x0, #0x51d6000
037555d8: 002c44f9 ldr      x0, [x0, #0x858]
037555dc: 496f6197 bl       #0xfb1300 ; 
037555e0: 00d700f0 adrp     x0, #0x5238000
037555e4: 009446f9 ldr      x0, [x0, #0xd28]
037555e8: 466f6197 bl       #0xfb1300 ; 
037555ec: c0d50090 adrp     x0, #0x520d000
037555f0: 002847f9 ldr      x0, [x0, #0xe50]
037555f4: 436f6197 bl       #0xfb1300 ; 
037555f8: 20d700f0 adrp     x0, #0x523c000
037555fc: 007c41f9 ldr      x0, [x0, #0x2f8]
03755600: 406f6197 bl       #0xfb1300 ; 
03755604: 20d30090 adrp     x0, #0x51b9000
03755608: 00e840f9 ldr      x0, [x0, #0x1d0]
0375560c: 3d6f6197 bl       #0xfb1300 ; 
03755610: 28008052 mov      w8, #1
03755614: 882e2839 strb     w8, [x20, #0xa0b]
03755618: 680e40f9 ldr      x8, [x19, #0x18]
0375561c: 680e00b4 cbz      x8, #0x37557e8
03755620: 081540f9 ldr      x8, [x8, #0x28]
03755624: 280e00b4 cbz      x8, #0x37557e8
03755628: 161540f9 ldr      x22, [x8, #0x28]
0375562c: f60d00b4 cbz      x22, #0x37557e8
03755630: c00a40f9 ldr      x0, [x22, #0x10]
03755634: 14d400b0 adrp     x20, #0x51d6000
03755638: 75d600b0 adrp     x21, #0x5222000
0375563c: 942e44f9 ldr      x20, [x20, #0x858]
03755640: b5ee42f9 ldr      x21, [x21, #0x5d8]
03755644: e1031faa mov      x1, xzr
03755648: 55c79697 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0375564c: 60050036 tbz      w0, #0, #0x37556f8
03755650: 28d700f0 adrp     x8, #0x523c000
03755654: 09d700f0 adrp     x9, #0x5238000
03755658: 087d41f9 ldr      x8, [x8, #0x2f8]
0375565c: 299546f9 ldr      x9, [x9, #0xd28]
03755660: 000140f9 ldr      x0, [x8]
03755664: 210140f9 ldr      x1, [x9]
03755668: 9eb1b997 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0375566c: e00b00b4 cbz      x0, #0x37557e8
03755670: e1031faa mov      x1, xzr
03755674: c7b91694 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03755678: 810240f9 ldr      x1, [x20]
0375567c: 4b9bb797 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03755680: e10300aa mov      x1, x0
03755684: e00313aa mov      x0, x19
03755688: 010c03f8 str      x1, [x0, #0x30]!
0375568c: 086f6197 bl       #0xfb12ac ; 
03755690: b40240f9 ldr      x20, [x21]
03755694: 881e40f9 ldr      x8, [x20, #0x38]
03755698: 000140f9 ldr      x0, [x8]
0375569c: 08c84439 ldrb     w8, [x0, #0x132]
037556a0: 48000037 tbnz     w8, #0, #0x37556a8
037556a4: 50ae6097 bl       #0xf80fe4 ; 
037556a8: 08e040b9 ldr      w8, [x0, #0xe0]
037556ac: 48000035 cbnz     w8, #0x37556b4
037556b0: 556f6197 bl       #0xfb1404 ; 
037556b4: 881e40f9 ldr      x8, [x20, #0x38]
037556b8: 34d30090 adrp     x20, #0x51b9000
037556bc: 000140f9 ldr      x0, [x8]
037556c0: 08c84439 ldrb     w8, [x0, #0x132]
037556c4: 94ea40f9 ldr      x20, [x20, #0x1d0]
037556c8: 48000037 tbnz     w8, #0, #0x37556d0
037556cc: 46ae6097 bl       #0xf80fe4 ; 
037556d0: 085c40f9 ldr      x8, [x0, #0xb8]
037556d4: 820240f9 ldr      x2, [x20]
037556d8: e00313aa mov      x0, x19
037556dc: f37b42a9 ldp      x19, x30, [sp, #0x20]
037556e0: 030140f9 ldr      x3, [x8]
037556e4: f55341a9 ldp      x21, x20, [sp, #0x10]
037556e8: 61098052 mov      w1, #0x4b
037556ec: e4031faa mov      x4, xzr
037556f0: f60743f8 ldr      x22, [sp], #0x30
037556f4: 8bacc217 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
037556f8: c00a40f9 ldr      x0, [x22, #0x10]
037556fc: 810240f9 ldr      x1, [x20]
03755700: 2a9bb797 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03755704: f40313aa mov      x20, x19
03755708: 800e03f8 str      x0, [x20, #0x30]!
0375570c: e10300aa mov      x1, x0
03755710: e00314aa mov      x0, x20
03755714: e66e6197 bl       #0xfb12ac ; 
03755718: 88825ef8 ldur     x8, [x20, #-0x18]
0375571c: 680600b4 cbz      x8, #0x37557e8
03755720: 081540f9 ldr      x8, [x8, #0x28]
03755724: 280600b4 cbz      x8, #0x37557e8
03755728: 081940f9 ldr      x8, [x8, #0x30]
0375572c: e80500b4 cbz      x8, #0x37557e8
03755730: 890240f9 ldr      x9, [x20]
03755734: a90500b4 cbz      x9, #0x37557e8
03755738: 081140b9 ldr      w8, [x8, #0x10]
0375573c: 6ad500f0 adrp     x10, #0x5204000
03755740: 4abd47f9 ldr      x10, [x10, #0xf78]
03755744: d4d50090 adrp     x20, #0x520d000
03755748: 281100b9 str      w8, [x9, #0x10]
0375574c: e1330091 add      x1, sp, #0xc
03755750: 400140f9 ldr      x0, [x10]
03755754: 942a47f9 ldr      x20, [x20, #0xe50]
03755758: e80f00b9 str      w8, [sp, #0xc]
0375575c: 2c6f6197 bl       #0xfb140c ; 
03755760: 880240f9 ldr      x8, [x20]
03755764: e10300aa mov      x1, x0
03755768: e2031faa mov      x2, xzr
0375576c: e00308aa mov      x0, x8
03755770: 1aa29697 bl       #0x1cfdfd8 ; System.String$$Format
03755774: b50240f9 ldr      x21, [x21]
03755778: f40300aa mov      x20, x0
0375577c: a81e40f9 ldr      x8, [x21, #0x38]
03755780: 080140f9 ldr      x8, [x8]
03755784: 09c94439 ldrb     w9, [x8, #0x132]
03755788: 89000037 tbnz     w9, #0, #0x3755798
0375578c: e00308aa mov      x0, x8
03755790: 15ae6097 bl       #0xf80fe4 ; 
03755794: e80300aa mov      x8, x0
03755798: 09e140b9 ldr      w9, [x8, #0xe0]
0375579c: 69000035 cbnz     w9, #0x37557a8
037557a0: e00308aa mov      x0, x8
037557a4: 186f6197 bl       #0xfb1404 ; 
037557a8: a81e40f9 ldr      x8, [x21, #0x38]
037557ac: 000140f9 ldr      x0, [x8]
037557b0: 08c84439 ldrb     w8, [x0, #0x132]
037557b4: 48000037 tbnz     w8, #0, #0x37557bc
037557b8: 0bae6097 bl       #0xf80fe4 ; 
037557bc: 085c40f9 ldr      x8, [x0, #0xb8]
037557c0: 61098052 mov      w1, #0x4b
037557c4: e00313aa mov      x0, x19
037557c8: e20314aa mov      x2, x20
037557cc: 030140f9 ldr      x3, [x8]
037557d0: e4031faa mov      x4, xzr
037557d4: 53acc297 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
037557d8: f37b42a9 ldp      x19, x30, [sp, #0x20]
037557dc: f55341a9 ldp      x21, x20, [sp, #0x10]
037557e0: f60743f8 ldr      x22, [sp], #0x30
037557e4: c0035fd6 ret      
037557e8: 106f6197 bl       #0xfb1428 ; 
