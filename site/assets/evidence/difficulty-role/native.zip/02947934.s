# Royal.Scenes.Home.Ui.Dialogs.TrainJourney.Scripts.TrainJourneyConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
02947934: ff0301d1 sub      sp, sp, #0x40
02947938: f75b01a9 stp      x23, x22, [sp, #0x10]
0294793c: f55302a9 stp      x21, x20, [sp, #0x20]
02947940: f37b03a9 stp      x19, x30, [sp, #0x30]
02947944: d46101d0 adrp     x20, #0x5581000
02947948: 88a66539 ldrb     w8, [x20, #0x969]
0294794c: f30300aa mov      x19, x0
02947950: e8040037 tbnz     w8, #0, #0x29479ec
02947954: c04601f0 adrp     x0, #0x5222000
02947958: 00ec42f9 ldr      x0, [x0, #0x5d8]
0294795c: 69a69997 bl       #0xfb1300 ; 
02947960: a04701f0 adrp     x0, #0x523e000
02947964: 00b842f9 ldr      x0, [x0, #0x570]
02947968: 66a69997 bl       #0xfb1300 ; 
0294796c: 204301d0 adrp     x0, #0x51ad000
02947970: 00e847f9 ldr      x0, [x0, #0xfd0]
02947974: 63a69997 bl       #0xfb1300 ; 
02947978: 604601f0 adrp     x0, #0x5216000
0294797c: 001c44f9 ldr      x0, [x0, #0x838]
02947980: 60a69997 bl       #0xfb1300 ; 
02947984: e04401f0 adrp     x0, #0x51e6000
02947988: 007840f9 ldr      x0, [x0, #0xf0]
0294798c: 5da69997 bl       #0xfb1300 ; 
02947990: e04501b0 adrp     x0, #0x5204000
02947994: 00bc47f9 ldr      x0, [x0, #0xf78]
02947998: 5aa69997 bl       #0xfb1300 ; 
0294799c: 004401f0 adrp     x0, #0x51ca000
029479a0: 007c43f9 ldr      x0, [x0, #0x6f8]
029479a4: 57a69997 bl       #0xfb1300 ; 
029479a8: 804701b0 adrp     x0, #0x5238000
029479ac: 009446f9 ldr      x0, [x0, #0xd28]
029479b0: 54a69997 bl       #0xfb1300 ; 
029479b4: c04601b0 adrp     x0, #0x5220000
029479b8: 000443f9 ldr      x0, [x0, #0x608]
029479bc: 51a69997 bl       #0xfb1300 ; 
029479c0: 80440190 adrp     x0, #0x51d7000
029479c4: 005047f9 ldr      x0, [x0, #0xea0]
029479c8: 4ea69997 bl       #0xfb1300 ; 
029479cc: 404401d0 adrp     x0, #0x51d1000
029479d0: 000445f9 ldr      x0, [x0, #0xa08]
029479d4: 4ba69997 bl       #0xfb1300 ; 
029479d8: 604301f0 adrp     x0, #0x51b6000
029479dc: 002844f9 ldr      x0, [x0, #0x850]
029479e0: 48a69997 bl       #0xfb1300 ; 
029479e4: 28008052 mov      w8, #1
029479e8: 88a62539 strb     w8, [x20, #0x969]
029479ec: 681640f9 ldr      x8, [x19, #0x28]
029479f0: 881200b4 cbz      x8, #0x2947c40
029479f4: 081140f9 ldr      x8, [x8, #0x20]
029479f8: 481200b4 cbz      x8, #0x2947c40
029479fc: 151940f9 ldr      x21, [x8, #0x30]
02947a00: 151200b4 cbz      x21, #0x2947c40
02947a04: a00a40f9 ldr      x0, [x21, #0x10]
02947a08: 144401f0 adrp     x20, #0x51ca000
02947a0c: d64601f0 adrp     x22, #0x5222000
02947a10: 947e43f9 ldr      x20, [x20, #0x6f8]
02947a14: d6ee42f9 ldr      x22, [x22, #0x5d8]
02947a18: e1031faa mov      x1, xzr
02947a1c: 60fece97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
02947a20: 60050036 tbz      w0, #0, #0x2947acc
02947a24: d50240f9 ldr      x21, [x22]
02947a28: a81e40f9 ldr      x8, [x21, #0x38]
02947a2c: 000140f9 ldr      x0, [x8]
02947a30: 08c84439 ldrb     w8, [x0, #0x132]
02947a34: 48000037 tbnz     w8, #0, #0x2947a3c
02947a38: 6be59897 bl       #0xf80fe4 ; 
02947a3c: 08e040b9 ldr      w8, [x0, #0xe0]
02947a40: 48000035 cbnz     w8, #0x2947a48
02947a44: 70a69997 bl       #0xfb1404 ; 
02947a48: a81e40f9 ldr      x8, [x21, #0x38]
02947a4c: 574401d0 adrp     x23, #0x51d1000
02947a50: 96440190 adrp     x22, #0x51d7000
02947a54: 954701b0 adrp     x21, #0x5238000
02947a58: 000140f9 ldr      x0, [x8]
02947a5c: 08c84439 ldrb     w8, [x0, #0x132]
02947a60: f70645f9 ldr      x23, [x23, #0xa08]
02947a64: d65247f9 ldr      x22, [x22, #0xea0]
02947a68: b59646f9 ldr      x21, [x21, #0xd28]
02947a6c: 48000037 tbnz     w8, #0, #0x2947a74
02947a70: 5de59897 bl       #0xf80fe4 ; 
02947a74: 085c40f9 ldr      x8, [x0, #0xb8]
02947a78: e20240f9 ldr      x2, [x23]
02947a7c: 61088052 mov      w1, #0x43
02947a80: e00313aa mov      x0, x19
02947a84: 030140f9 ldr      x3, [x8]
02947a88: e4031faa mov      x4, xzr
02947a8c: a5e3fa97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02947a90: c00240f9 ldr      x0, [x22]
02947a94: a10240f9 ldr      x1, [x21]
02947a98: 92e8f197 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
02947a9c: 200d00b4 cbz      x0, #0x2947c40
02947aa0: e1031faa mov      x1, xzr
02947aa4: bbf04e94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02947aa8: 810240f9 ldr      x1, [x20]
02947aac: 3fd2ef97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02947ab0: 600e02f8 str      x0, [x19, #0x20]!
02947ab4: e10300aa mov      x1, x0
02947ab8: e00313aa mov      x0, x19
02947abc: fca59997 bl       #0xfb12ac ; 
02947ac0: 28008052 mov      w8, #1
02947ac4: 68121f38 sturb    w8, [x19, #-0xf]
02947ac8: 3f000014 b        #0x2947bc4 ; 
02947acc: a00a40f9 ldr      x0, [x21, #0x10]
02947ad0: 810240f9 ldr      x1, [x20]
02947ad4: 35d2ef97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02947ad8: e10300aa mov      x1, x0
02947adc: f50300aa mov      x21, x0
02947ae0: 59000094 bl       #0x2947c44 ; Royal.Scenes.Home.Ui.Dialogs.TrainJourney.Scripts.TrainJourneyConfigHelper$$IsConfigValid
02947ae4: a0070036 tbz      w0, #0, #0x2947bd8
02947ae8: f40313aa mov      x20, x19
02947aec: 950e02f8 str      x21, [x20, #0x20]!
02947af0: e00314aa mov      x0, x20
02947af4: e10315aa mov      x1, x21
02947af8: eda59997 bl       #0xfb12ac ; 
02947afc: 880640f9 ldr      x8, [x20, #8]
02947b00: 080a00b4 cbz      x8, #0x2947c40
02947b04: 081140f9 ldr      x8, [x8, #0x20]
02947b08: c80900b4 cbz      x8, #0x2947c40
02947b0c: 081d40f9 ldr      x8, [x8, #0x38]
02947b10: 880900b4 cbz      x8, #0x2947c40
02947b14: 890240f9 ldr      x9, [x20]
02947b18: 490900b4 cbz      x9, #0x2947c40
02947b1c: 081140b9 ldr      w8, [x8, #0x10]
02947b20: ea4501b0 adrp     x10, #0x5204000
02947b24: 4abd47f9 ldr      x10, [x10, #0xf78]
02947b28: 2b008052 mov      w11, #1
02947b2c: 281100b9 str      w8, [x9, #0x10]
02947b30: 6b460039 strb     w11, [x19, #0x11]
02947b34: 400140f9 ldr      x0, [x10]
02947b38: d44601b0 adrp     x20, #0x5220000
02947b3c: 940643f9 ldr      x20, [x20, #0x608]
02947b40: e1330091 add      x1, sp, #0xc
02947b44: e80f00b9 str      w8, [sp, #0xc]
02947b48: 31a69997 bl       #0xfb140c ; 
02947b4c: 880240f9 ldr      x8, [x20]
02947b50: e10300aa mov      x1, x0
02947b54: e2031faa mov      x2, xzr
02947b58: e00308aa mov      x0, x8
02947b5c: 1fd9ce97 bl       #0x1cfdfd8 ; System.String$$Format
02947b60: d50240f9 ldr      x21, [x22]
02947b64: f40300aa mov      x20, x0
02947b68: a81e40f9 ldr      x8, [x21, #0x38]
02947b6c: 080140f9 ldr      x8, [x8]
02947b70: 09c94439 ldrb     w9, [x8, #0x132]
02947b74: 89000037 tbnz     w9, #0, #0x2947b84
02947b78: e00308aa mov      x0, x8
02947b7c: 1ae59897 bl       #0xf80fe4 ; 
02947b80: e80300aa mov      x8, x0
02947b84: 09e140b9 ldr      w9, [x8, #0xe0]
02947b88: 69000035 cbnz     w9, #0x2947b94
02947b8c: e00308aa mov      x0, x8
02947b90: 1da69997 bl       #0xfb1404 ; 
02947b94: a81e40f9 ldr      x8, [x21, #0x38]
02947b98: 000140f9 ldr      x0, [x8]
02947b9c: 08c84439 ldrb     w8, [x0, #0x132]
02947ba0: 48000037 tbnz     w8, #0, #0x2947ba8
02947ba4: 10e59897 bl       #0xf80fe4 ; 
02947ba8: 085c40f9 ldr      x8, [x0, #0xb8]
02947bac: 61088052 mov      w1, #0x43
02947bb0: e00313aa mov      x0, x19
02947bb4: e20314aa mov      x2, x20
02947bb8: 030140f9 ldr      x3, [x8]
02947bbc: e4031faa mov      x4, xzr
02947bc0: 58e3fa97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02947bc4: f37b43a9 ldp      x19, x30, [sp, #0x30]
02947bc8: f55342a9 ldp      x21, x20, [sp, #0x20]
02947bcc: f75b41a9 ldp      x23, x22, [sp, #0x10]
02947bd0: ff030191 add      sp, sp, #0x40
02947bd4: c0035fd6 ret      
02947bd8: 684601f0 adrp     x8, #0x5216000
02947bdc: 081d44f9 ldr      x8, [x8, #0x838]
02947be0: 000140f9 ldr      x0, [x8]
02947be4: 0da69997 bl       #0xfb1418 ; 
02947be8: c00200b4 cbz      x0, #0x2947c40
02947bec: 684301f0 adrp     x8, #0x51b6000
02947bf0: 082944f9 ldr      x8, [x8, #0x850]
02947bf4: f44401f0 adrp     x20, #0x51e6000
02947bf8: e2031faa mov      x2, xzr
02947bfc: f30300aa mov      x19, x0
02947c00: 010140f9 ldr      x1, [x8]
02947c04: 947a40f9 ldr      x20, [x20, #0xf0]
02947c08: ae7ee497 bl       #0x22676c0 ; System.Exception$$.ctor
02947c0c: 800240f9 ldr      x0, [x20]
02947c10: 08e040b9 ldr      w8, [x0, #0xe0]
02947c14: 48000035 cbnz     w8, #0x2947c1c
02947c18: fba59997 bl       #0xfb1404 ; 
02947c1c: e00313aa mov      x0, x19
02947c20: f37b43a9 ldp      x19, x30, [sp, #0x30]
02947c24: f55342a9 ldp      x21, x20, [sp, #0x20]
02947c28: f75b41a9 ldp      x23, x22, [sp, #0x10]
02947c2c: 61088052 mov      w1, #0x43
02947c30: e2031faa mov      x2, xzr
02947c34: e3031faa mov      x3, xzr
02947c38: ff030191 add      sp, sp, #0x40
02947c3c: ea461414 b        #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
02947c40: faa59997 bl       #0xfb1428 ; 
