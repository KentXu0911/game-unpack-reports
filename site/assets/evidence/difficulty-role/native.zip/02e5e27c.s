# Royal.Infrastructure.Services.Storage.DatabaseService$$GetSyncRequiredKeyValueCounts
# Linear metadata span, not a recovered full CFG.
02e5e27c: ffc304d1 sub      sp, sp, #0x130
02e5e280: fc5b10a9 stp      x28, x22, [sp, #0x100]
02e5e284: f55311a9 stp      x21, x20, [sp, #0x110]
02e5e288: f37b12a9 stp      x19, x30, [sp, #0x120]
02e5e28c: 343901d0 adrp     x20, #0x5584000
02e5e290: 89fe5f39 ldrb     w9, [x20, #0x7ff]
02e5e294: f50300aa mov      x21, x0
02e5e298: f30308aa mov      x19, x8
02e5e29c: 89010037 tbnz     w9, #0, #0x2e5e2cc
02e5e2a0: 201e0190 adrp     x0, #0x5222000
02e5e2a4: 00ec42f9 ldr      x0, [x0, #0x5d8]
02e5e2a8: 164c8597 bl       #0xfb1300 ; 
02e5e2ac: 201a01d0 adrp     x0, #0x51a4000
02e5e2b0: 00f846f9 ldr      x0, [x0, #0xdf0]
02e5e2b4: 134c8597 bl       #0xfb1300 ; 
02e5e2b8: 601c01f0 adrp     x0, #0x51ed000
02e5e2bc: 00c446f9 ldr      x0, [x0, #0xd88]
02e5e2c0: 104c8597 bl       #0xfb1300 ; 
02e5e2c4: 28008052 mov      w8, #1
02e5e2c8: 88fe1f39 strb     w8, [x20, #0x7ff]
02e5e2cc: e00315aa mov      x0, x21
02e5e2d0: 38000094 bl       #0x2e5e3b0 ; Royal.Infrastructure.Services.Storage.DatabaseService$$BuildKeyValueQuery
02e5e2d4: e1031faa mov      x1, xzr
02e5e2d8: f40300aa mov      x20, x0
02e5e2dc: 30a4ba97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
02e5e2e0: c0000036 tbz      w0, #0, #0x2e5e2f8
02e5e2e4: 021f8052 mov      w2, #0xf8
02e5e2e8: e00313aa mov      x0, x19
02e5e2ec: e1031f2a mov      w1, wzr
02e5e2f0: c8937997 bl       #0xcc3210 ; 
02e5e2f4: 29000014 b        #0x2e5e398 ; 
02e5e2f8: 281e0190 adrp     x8, #0x5222000
02e5e2fc: 08ed42f9 ldr      x8, [x8, #0x5d8]
02e5e300: b50a40f9 ldr      x21, [x21, #0x10]
02e5e304: 160140f9 ldr      x22, [x8]
02e5e308: c81e40f9 ldr      x8, [x22, #0x38]
02e5e30c: 000140f9 ldr      x0, [x8]
02e5e310: 08c84439 ldrb     w8, [x0, #0x132]
02e5e314: 48000037 tbnz     w8, #0, #0x2e5e31c
02e5e318: 338b8497 bl       #0xf80fe4 ; 
02e5e31c: 08e040b9 ldr      w8, [x0, #0xe0]
02e5e320: 48000035 cbnz     w8, #0x2e5e328
02e5e324: 384c8597 bl       #0xfb1404 ; 
02e5e328: c81e40f9 ldr      x8, [x22, #0x38]
02e5e32c: 000140f9 ldr      x0, [x8]
02e5e330: 08c84439 ldrb     w8, [x0, #0x132]
02e5e334: 48000037 tbnz     w8, #0, #0x2e5e33c
02e5e338: 2b8b8497 bl       #0xf80fe4 ; 
02e5e33c: 950300b4 cbz      x21, #0x2e5e3ac
02e5e340: 085c40f9 ldr      x8, [x0, #0xb8]
02e5e344: e00315aa mov      x0, x21
02e5e348: e10314aa mov      x1, x20
02e5e34c: e3031faa mov      x3, xzr
02e5e350: 020140f9 ldr      x2, [x8]
02e5e354: d1900b94 bl       #0x3142698 ; Plugins.Sqlite.SQLiteConnection$$CreateCommand
02e5e358: a00200b4 cbz      x0, #0x2e5e3ac
02e5e35c: 681c01f0 adrp     x8, #0x51ed000
02e5e360: 08c546f9 ldr      x8, [x8, #0xd88]
02e5e364: 010140f9 ldr      x1, [x8]
02e5e368: a817d197 bl       #0x22a4208 ; Plugins.Sqlite.SQLiteCommand$$ExecuteQuery<SyncRequiredKeyValueCounts>
02e5e36c: 000200b4 cbz      x0, #0x2e5e3ac
02e5e370: 281a01d0 adrp     x8, #0x51a4000
02e5e374: 08f946f9 ldr      x8, [x8, #0xdf0]
02e5e378: e1031f2a mov      w1, wzr
02e5e37c: 020140f9 ldr      x2, [x8]
02e5e380: e8230091 add      x8, sp, #8
02e5e384: 8e291394 bl       #0x33289bc ; System.Collections.Generic.List<SyncRequiredKeyValueCounts>$$get_Item
02e5e388: e1230091 add      x1, sp, #8
02e5e38c: 021f8052 mov      w2, #0xf8
02e5e390: e00313aa mov      x0, x19
02e5e394: 8f8e7997 bl       #0xcc1dd0 ; 
02e5e398: f37b52a9 ldp      x19, x30, [sp, #0x120]
02e5e39c: f55351a9 ldp      x21, x20, [sp, #0x110]
02e5e3a0: fc5b50a9 ldp      x28, x22, [sp, #0x100]
02e5e3a4: ffc30491 add      sp, sp, #0x130
02e5e3a8: c0035fd6 ret      
02e5e3ac: 1f4c8597 bl       #0xfb1428 ; 
