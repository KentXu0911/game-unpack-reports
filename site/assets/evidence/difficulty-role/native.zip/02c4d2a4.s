# Royal.Scenes.Home.Ui.Dialogs.WeeklyPass.Scripts.WeeklyPassConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
02c4d2a4: f60f1df8 str      x22, [sp, #-0x30]!
02c4d2a8: f55301a9 stp      x21, x20, [sp, #0x10]
02c4d2ac: f37b02a9 stp      x19, x30, [sp, #0x20]
02c4d2b0: b44901d0 adrp     x20, #0x5583000
02c4d2b4: 88d67639 ldrb     w8, [x20, #0xdb5]
02c4d2b8: f30300aa mov      x19, x0
02c4d2bc: c8030037 tbnz     w8, #0, #0x2c4d334
02c4d2c0: a02e01b0 adrp     x0, #0x5222000
02c4d2c4: 00ec42f9 ldr      x0, [x0, #0x5d8]
02c4d2c8: 0e908d97 bl       #0xfb1300 ; 
02c4d2cc: c02e01f0 adrp     x0, #0x5228000
02c4d2d0: 001840f9 ldr      x0, [x0, #0x30]
02c4d2d4: 0b908d97 bl       #0xfb1300 ; 
02c4d2d8: 202a01f0 adrp     x0, #0x5194000
02c4d2dc: 002443f9 ldr      x0, [x0, #0x648]
02c4d2e0: 08908d97 bl       #0xfb1300 ; 
02c4d2e4: a02d01f0 adrp     x0, #0x5204000
02c4d2e8: 00bc47f9 ldr      x0, [x0, #0xf78]
02c4d2ec: 05908d97 bl       #0xfb1300 ; 
02c4d2f0: 402e01b0 adrp     x0, #0x5216000
02c4d2f4: 003842f9 ldr      x0, [x0, #0x470]
02c4d2f8: 02908d97 bl       #0xfb1300 ; 
02c4d2fc: 402f01f0 adrp     x0, #0x5238000
02c4d300: 009446f9 ldr      x0, [x0, #0xd28]
02c4d304: ff8f8d97 bl       #0xfb1300 ; 
02c4d308: 802e01f0 adrp     x0, #0x5220000
02c4d30c: 000443f9 ldr      x0, [x0, #0x608]
02c4d310: fc8f8d97 bl       #0xfb1300 ; 
02c4d314: 402e0190 adrp     x0, #0x5215000
02c4d318: 000846f9 ldr      x0, [x0, #0xc10]
02c4d31c: f98f8d97 bl       #0xfb1300 ; 
02c4d320: 802e01d0 adrp     x0, #0x521f000
02c4d324: 003443f9 ldr      x0, [x0, #0x668]
02c4d328: f68f8d97 bl       #0xfb1300 ; 
02c4d32c: 28008052 mov      w8, #1
02c4d330: 88d63639 strb     w8, [x20, #0xdb5]
02c4d334: 680a40f9 ldr      x8, [x19, #0x10]
02c4d338: e80d00b4 cbz      x8, #0x2c4d4f4
02c4d33c: 161d40f9 ldr      x22, [x8, #0x38]
02c4d340: b60d00b4 cbz      x22, #0x2c4d4f4
02c4d344: c00a40f9 ldr      x0, [x22, #0x10]
02c4d348: 542e01b0 adrp     x20, #0x5216000
02c4d34c: b52e01b0 adrp     x21, #0x5222000
02c4d350: 943a42f9 ldr      x20, [x20, #0x470]
02c4d354: b5ee42f9 ldr      x21, [x21, #0x5d8]
02c4d358: e1031faa mov      x1, xzr
02c4d35c: 10e8c297 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
02c4d360: 60050036 tbz      w0, #0, #0x2c4d40c
02c4d364: 882e01d0 adrp     x8, #0x521f000
02c4d368: 492f01f0 adrp     x9, #0x5238000
02c4d36c: 083543f9 ldr      x8, [x8, #0x668]
02c4d370: 299546f9 ldr      x9, [x9, #0xd28]
02c4d374: 000140f9 ldr      x0, [x8]
02c4d378: 210140f9 ldr      x1, [x9]
02c4d37c: 59d2e597 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
02c4d380: a00b00b4 cbz      x0, #0x2c4d4f4
02c4d384: e1031faa mov      x1, xzr
02c4d388: 82da4294 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02c4d38c: 810240f9 ldr      x1, [x20]
02c4d390: 06bce397 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02c4d394: e10300aa mov      x1, x0
02c4d398: e00313aa mov      x0, x19
02c4d39c: 018c01f8 str      x1, [x0, #0x18]!
02c4d3a0: c38f8d97 bl       #0xfb12ac ; 
02c4d3a4: b40240f9 ldr      x20, [x21]
02c4d3a8: 881e40f9 ldr      x8, [x20, #0x38]
02c4d3ac: 000140f9 ldr      x0, [x8]
02c4d3b0: 08c84439 ldrb     w8, [x0, #0x132]
02c4d3b4: 48000037 tbnz     w8, #0, #0x2c4d3bc
02c4d3b8: 0bcf8c97 bl       #0xf80fe4 ; 
02c4d3bc: 08e040b9 ldr      w8, [x0, #0xe0]
02c4d3c0: 48000035 cbnz     w8, #0x2c4d3c8
02c4d3c4: 10908d97 bl       #0xfb1404 ; 
02c4d3c8: 881e40f9 ldr      x8, [x20, #0x38]
02c4d3cc: 542e0190 adrp     x20, #0x5215000
02c4d3d0: 000140f9 ldr      x0, [x8]
02c4d3d4: 08c84439 ldrb     w8, [x0, #0x132]
02c4d3d8: 940a46f9 ldr      x20, [x20, #0xc10]
02c4d3dc: 48000037 tbnz     w8, #0, #0x2c4d3e4
02c4d3e0: 01cf8c97 bl       #0xf80fe4 ; 
02c4d3e4: 085c40f9 ldr      x8, [x0, #0xb8]
02c4d3e8: 820240f9 ldr      x2, [x20]
02c4d3ec: e00313aa mov      x0, x19
02c4d3f0: f37b42a9 ldp      x19, x30, [sp, #0x20]
02c4d3f4: 030140f9 ldr      x3, [x8]
02c4d3f8: f55341a9 ldp      x21, x20, [sp, #0x10]
02c4d3fc: 81098052 mov      w1, #0x4c
02c4d400: e4031faa mov      x4, xzr
02c4d404: f60743f8 ldr      x22, [sp], #0x30
02c4d408: 46cdee17 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02c4d40c: c00a40f9 ldr      x0, [x22, #0x10]
02c4d410: 810240f9 ldr      x1, [x20]
02c4d414: e5bbe397 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02c4d418: f40313aa mov      x20, x19
02c4d41c: 808e01f8 str      x0, [x20, #0x18]!
02c4d420: e10300aa mov      x1, x0
02c4d424: e00314aa mov      x0, x20
02c4d428: a18f8d97 bl       #0xfb12ac ; 
02c4d42c: 88825ff8 ldur     x8, [x20, #-8]
02c4d430: 280600b4 cbz      x8, #0x2c4d4f4
02c4d434: 082140f9 ldr      x8, [x8, #0x40]
02c4d438: e80500b4 cbz      x8, #0x2c4d4f4
02c4d43c: 890240f9 ldr      x9, [x20]
02c4d440: a90500b4 cbz      x9, #0x2c4d4f4
02c4d444: 081140b9 ldr      w8, [x8, #0x10]
02c4d448: aa2d01f0 adrp     x10, #0x5204000
02c4d44c: 4abd47f9 ldr      x10, [x10, #0xf78]
02c4d450: 942e01f0 adrp     x20, #0x5220000
02c4d454: 281100b9 str      w8, [x9, #0x10]
02c4d458: e1330091 add      x1, sp, #0xc
02c4d45c: 400140f9 ldr      x0, [x10]
02c4d460: 940643f9 ldr      x20, [x20, #0x608]
02c4d464: e80f00b9 str      w8, [sp, #0xc]
02c4d468: e98f8d97 bl       #0xfb140c ; 
02c4d46c: 880240f9 ldr      x8, [x20]
02c4d470: e10300aa mov      x1, x0
02c4d474: e2031faa mov      x2, xzr
02c4d478: e00308aa mov      x0, x8
02c4d47c: d7c2c297 bl       #0x1cfdfd8 ; System.String$$Format
02c4d480: b50240f9 ldr      x21, [x21]
02c4d484: f40300aa mov      x20, x0
02c4d488: a81e40f9 ldr      x8, [x21, #0x38]
02c4d48c: 080140f9 ldr      x8, [x8]
02c4d490: 09c94439 ldrb     w9, [x8, #0x132]
02c4d494: 89000037 tbnz     w9, #0, #0x2c4d4a4
02c4d498: e00308aa mov      x0, x8
02c4d49c: d2ce8c97 bl       #0xf80fe4 ; 
02c4d4a0: e80300aa mov      x8, x0
02c4d4a4: 09e140b9 ldr      w9, [x8, #0xe0]
02c4d4a8: 69000035 cbnz     w9, #0x2c4d4b4
02c4d4ac: e00308aa mov      x0, x8
02c4d4b0: d58f8d97 bl       #0xfb1404 ; 
02c4d4b4: a81e40f9 ldr      x8, [x21, #0x38]
02c4d4b8: 000140f9 ldr      x0, [x8]
02c4d4bc: 08c84439 ldrb     w8, [x0, #0x132]
02c4d4c0: 48000037 tbnz     w8, #0, #0x2c4d4c8
02c4d4c4: c8ce8c97 bl       #0xf80fe4 ; 
02c4d4c8: 085c40f9 ldr      x8, [x0, #0xb8]
02c4d4cc: 81098052 mov      w1, #0x4c
02c4d4d0: e00313aa mov      x0, x19
02c4d4d4: e20314aa mov      x2, x20
02c4d4d8: 030140f9 ldr      x3, [x8]
02c4d4dc: e4031faa mov      x4, xzr
02c4d4e0: 10cdee97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02c4d4e4: f37b42a9 ldp      x19, x30, [sp, #0x20]
02c4d4e8: f55341a9 ldp      x21, x20, [sp, #0x10]
02c4d4ec: f60743f8 ldr      x22, [sp], #0x30
02c4d4f0: c0035fd6 ret      
02c4d4f4: cd8f8d97 bl       #0xfb1428 ; 
