# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnEgoShownFirst
# Linear metadata span, not a recovered full CFG.
01c85454: 1cffff17 b        #0x1c850c4 ; Royal.Player.Context.Units.SemiDynamicDifficulty$$IncrementTryCount
