# Royal.Scenes.Home.Ui.Dialogs.BalloonRise.BalloonRiseConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
03e310b8: f60f1df8 str      x22, [sp, #-0x30]!
03e310bc: f55301a9 stp      x21, x20, [sp, #0x10]
03e310c0: f37b02a9 stp      x19, x30, [sp, #0x20]
03e310c4: f4ba0090 adrp     x20, #0x558d000
03e310c8: 88265e39 ldrb     w8, [x20, #0x789]
03e310cc: f30300aa mov      x19, x0
03e310d0: c8030037 tbnz     w8, #0, #0x3e31148
03e310d4: 809f00b0 adrp     x0, #0x5222000
03e310d8: 00ec42f9 ldr      x0, [x0, #0x5d8]
03e310dc: 89004697 bl       #0xfb1300 ; 
03e310e0: 20a000d0 adrp     x0, #0x5237000
03e310e4: 00e844f9 ldr      x0, [x0, #0x9d0]
03e310e8: 86004697 bl       #0xfb1300 ; 
03e310ec: 209d00d0 adrp     x0, #0x51d7000
03e310f0: 00dc40f9 ldr      x0, [x0, #0x1b8]
03e310f4: 83004697 bl       #0xfb1300 ; 
03e310f8: 809e00f0 adrp     x0, #0x5204000
03e310fc: 00bc47f9 ldr      x0, [x0, #0xf78]
03e31100: 80004697 bl       #0xfb1300 ; 
03e31104: 409b00d0 adrp     x0, #0x519b000
03e31108: 007847f9 ldr      x0, [x0, #0xef0]
03e3110c: 7d004697 bl       #0xfb1300 ; 
03e31110: 20a000f0 adrp     x0, #0x5238000
03e31114: 009446f9 ldr      x0, [x0, #0xd28]
03e31118: 7a004697 bl       #0xfb1300 ; 
03e3111c: e09b0090 adrp     x0, #0x51ad000
03e31120: 002441f9 ldr      x0, [x0, #0x248]
03e31124: 77004697 bl       #0xfb1300 ; 
03e31128: e09e00d0 adrp     x0, #0x520f000
03e3112c: 003c47f9 ldr      x0, [x0, #0xe78]
03e31130: 74004697 bl       #0xfb1300 ; 
03e31134: a09b0090 adrp     x0, #0x51a5000
03e31138: 003443f9 ldr      x0, [x0, #0x668]
03e3113c: 71004697 bl       #0xfb1300 ; 
03e31140: 28008052 mov      w8, #1
03e31144: 88261e39 strb     w8, [x20, #0x789]
03e31148: 680e40f9 ldr      x8, [x19, #0x18]
03e3114c: e80d00b4 cbz      x8, #0x3e31308
03e31150: 161140f9 ldr      x22, [x8, #0x20]
03e31154: b60d00b4 cbz      x22, #0x3e31308
03e31158: c00a40f9 ldr      x0, [x22, #0x10]
03e3115c: 549b00d0 adrp     x20, #0x519b000
03e31160: 959f00b0 adrp     x21, #0x5222000
03e31164: 947a47f9 ldr      x20, [x20, #0xef0]
03e31168: b5ee42f9 ldr      x21, [x21, #0x5d8]
03e3116c: e1031faa mov      x1, xzr
03e31170: 8b587b97 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
03e31174: 60050036 tbz      w0, #0, #0x3e31220
03e31178: e89b0090 adrp     x8, #0x51ad000
03e3117c: 29a000f0 adrp     x9, #0x5238000
03e31180: 082541f9 ldr      x8, [x8, #0x248]
03e31184: 299546f9 ldr      x9, [x9, #0xd28]
03e31188: 000140f9 ldr      x0, [x8]
03e3118c: 210140f9 ldr      x1, [x9]
03e31190: d4429e97 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03e31194: a00b00b4 cbz      x0, #0x3e31308
03e31198: e1031faa mov      x1, xzr
03e3119c: fd4afb97 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03e311a0: 810240f9 ldr      x1, [x20]
03e311a4: 812c9c97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03e311a8: e10300aa mov      x1, x0
03e311ac: e00313aa mov      x0, x19
03e311b0: 018c02f8 str      x1, [x0, #0x28]!
03e311b4: 3e004697 bl       #0xfb12ac ; 
03e311b8: b40240f9 ldr      x20, [x21]
03e311bc: 881e40f9 ldr      x8, [x20, #0x38]
03e311c0: 000140f9 ldr      x0, [x8]
03e311c4: 08c84439 ldrb     w8, [x0, #0x132]
03e311c8: 48000037 tbnz     w8, #0, #0x3e311d0
03e311cc: 863f4597 bl       #0xf80fe4 ; 
03e311d0: 08e040b9 ldr      w8, [x0, #0xe0]
03e311d4: 48000035 cbnz     w8, #0x3e311dc
03e311d8: 8b004697 bl       #0xfb1404 ; 
03e311dc: 881e40f9 ldr      x8, [x20, #0x38]
03e311e0: b49b0090 adrp     x20, #0x51a5000
03e311e4: 000140f9 ldr      x0, [x8]
03e311e8: 08c84439 ldrb     w8, [x0, #0x132]
03e311ec: 943643f9 ldr      x20, [x20, #0x668]
03e311f0: 48000037 tbnz     w8, #0, #0x3e311f8
03e311f4: 7c3f4597 bl       #0xf80fe4 ; 
03e311f8: 085c40f9 ldr      x8, [x0, #0xb8]
03e311fc: 820240f9 ldr      x2, [x20]
03e31200: e00313aa mov      x0, x19
03e31204: f37b42a9 ldp      x19, x30, [sp, #0x20]
03e31208: 030140f9 ldr      x3, [x8]
03e3120c: f55341a9 ldp      x21, x20, [sp, #0x10]
03e31210: 01048052 mov      w1, #0x20
03e31214: e4031faa mov      x4, xzr
03e31218: f60743f8 ldr      x22, [sp], #0x30
03e3121c: c13da717 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03e31220: c00a40f9 ldr      x0, [x22, #0x10]
03e31224: 810240f9 ldr      x1, [x20]
03e31228: 602c9c97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03e3122c: f40313aa mov      x20, x19
03e31230: 808e02f8 str      x0, [x20, #0x28]!
03e31234: e10300aa mov      x1, x0
03e31238: e00314aa mov      x0, x20
03e3123c: 1c004697 bl       #0xfb12ac ; 
03e31240: 88025ff8 ldur     x8, [x20, #-0x10]
03e31244: 280600b4 cbz      x8, #0x3e31308
03e31248: 081540f9 ldr      x8, [x8, #0x28]
03e3124c: e80500b4 cbz      x8, #0x3e31308
03e31250: 890240f9 ldr      x9, [x20]
03e31254: a90500b4 cbz      x9, #0x3e31308
03e31258: 081140b9 ldr      w8, [x8, #0x10]
03e3125c: 8a9e00f0 adrp     x10, #0x5204000
03e31260: 4abd47f9 ldr      x10, [x10, #0xf78]
03e31264: f49e00d0 adrp     x20, #0x520f000
03e31268: 281100b9 str      w8, [x9, #0x10]
03e3126c: e1330091 add      x1, sp, #0xc
03e31270: 400140f9 ldr      x0, [x10]
03e31274: 943e47f9 ldr      x20, [x20, #0xe78]
03e31278: e80f00b9 str      w8, [sp, #0xc]
03e3127c: 64004697 bl       #0xfb140c ; 
03e31280: 880240f9 ldr      x8, [x20]
03e31284: e10300aa mov      x1, x0
03e31288: e2031faa mov      x2, xzr
03e3128c: e00308aa mov      x0, x8
03e31290: 52337b97 bl       #0x1cfdfd8 ; System.String$$Format
03e31294: b50240f9 ldr      x21, [x21]
03e31298: f40300aa mov      x20, x0
03e3129c: a81e40f9 ldr      x8, [x21, #0x38]
03e312a0: 080140f9 ldr      x8, [x8]
03e312a4: 09c94439 ldrb     w9, [x8, #0x132]
03e312a8: 89000037 tbnz     w9, #0, #0x3e312b8
03e312ac: e00308aa mov      x0, x8
03e312b0: 4d3f4597 bl       #0xf80fe4 ; 
03e312b4: e80300aa mov      x8, x0
03e312b8: 09e140b9 ldr      w9, [x8, #0xe0]
03e312bc: 69000035 cbnz     w9, #0x3e312c8
03e312c0: e00308aa mov      x0, x8
03e312c4: 50004697 bl       #0xfb1404 ; 
03e312c8: a81e40f9 ldr      x8, [x21, #0x38]
03e312cc: 000140f9 ldr      x0, [x8]
03e312d0: 08c84439 ldrb     w8, [x0, #0x132]
03e312d4: 48000037 tbnz     w8, #0, #0x3e312dc
03e312d8: 433f4597 bl       #0xf80fe4 ; 
03e312dc: 085c40f9 ldr      x8, [x0, #0xb8]
03e312e0: 01048052 mov      w1, #0x20
03e312e4: e00313aa mov      x0, x19
03e312e8: e20314aa mov      x2, x20
03e312ec: 030140f9 ldr      x3, [x8]
03e312f0: e4031faa mov      x4, xzr
03e312f4: 8b3da797 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03e312f8: f37b42a9 ldp      x19, x30, [sp, #0x20]
03e312fc: f55341a9 ldp      x21, x20, [sp, #0x10]
03e31300: f60743f8 ldr      x22, [sp], #0x30
03e31304: c0035fd6 ret      
03e31308: 48004697 bl       #0xfb1428 ; 
