# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$DifficultyNext
# Linear metadata span, not a recovered full CFG.
02a31474: 01000014 b        #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
