# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArray<int>
# Linear metadata span, not a recovered full CFG.
0253f028: f60f1df8 str      x22, [sp, #-0x30]!
0253f02c: f55301a9 stp      x21, x20, [sp, #0x10]
0253f030: f37b02a9 stp      x19, x30, [sp, #0x20]
0253f034: 610400b4 cbz      x1, #0x253f0c0
0253f038: 280c40f9 ldr      x8, [x1, #0x18]
0253f03c: f30301aa mov      x19, x1
0253f040: 1f090071 cmp      w8, #2
0253f044: 4b030054 b.lt     #0x253f0ac
0253f048: f40300aa mov      x20, x0
0253f04c: 157d4093 sxtw     x21, w8
0253f050: 76720091 add      x22, x19, #0x1c
0253f054: 801a40f9 ldr      x0, [x20, #0x30]
0253f058: 400300b4 cbz      x0, #0x253f0c0
0253f05c: 080040f9 ldr      x8, [x0]
0253f060: e103152a mov      w1, w21
0253f064: 09895aa9 ldp      x9, x2, [x8, #0x1a8]
0253f068: 20013fd6 blr      x9
0253f06c: 690e40f9 ldr      x9, [x19, #0x18]
0253f070: 1f00096b cmp      w0, w9
0253f074: 42020054 b.hs     #0x253f0bc
0253f078: a80600d1 sub      x8, x21, #1
0253f07c: 297d4092 and      x9, x9, #0xffffffff
0253f080: 1f0109eb cmp      x8, x9
0253f084: c2010054 b.hs     #0x253f0bc
0253f088: 69ca208b add      x9, x19, w0, sxtw #2
0253f08c: 2a0d42b8 ldr      w10, [x9, #0x20]!
0253f090: cb7a75b8 ldr      w11, [x22, x21, lsl #2]
0253f094: 0c050091 add      x12, x8, #1
0253f098: 9f0900f1 cmp      x12, #2
0253f09c: ca7a35b8 str      w10, [x22, x21, lsl #2]
0253f0a0: f50308aa mov      x21, x8
0253f0a4: 2b0100b9 str      w11, [x9]
0253f0a8: 6cfdff54 b.gt     #0x253f054
0253f0ac: f37b42a9 ldp      x19, x30, [sp, #0x20]
0253f0b0: f55341a9 ldp      x21, x20, [sp, #0x10]
0253f0b4: f60743f8 ldr      x22, [sp], #0x30
0253f0b8: c0035fd6 ret      
0253f0bc: ddc8a997 bl       #0xfb1430 ; 
0253f0c0: dac8a997 bl       #0xfb1428 ; 
