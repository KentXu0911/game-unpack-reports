# Royal.Scenes.Home.Ui.Dialogs.OceanOdyssey.Scripts.OceanOdysseyConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
01b1652c: f60f1df8 str      x22, [sp, #-0x30]!
01b16530: f55301a9 stp      x21, x20, [sp, #0x10]
01b16534: f37b02a9 stp      x19, x30, [sp, #0x20]
01b16538: 34d301b0 adrp     x20, #0x557b000
01b1653c: 88a64039 ldrb     w8, [x20, #0x29]
01b16540: f30300aa mov      x19, x0
01b16544: c8030037 tbnz     w8, #0, #0x1b165bc
01b16548: 60b80190 adrp     x0, #0x5222000
01b1654c: 00ec42f9 ldr      x0, [x0, #0x5d8]
01b16550: 6c6bd297 bl       #0xfb1300 ; 
01b16554: e0b30190 adrp     x0, #0x5192000
01b16558: 00a041f9 ldr      x0, [x0, #0x340]
01b1655c: 696bd297 bl       #0xfb1300 ; 
01b16560: e0b401d0 adrp     x0, #0x51b4000
01b16564: 001c47f9 ldr      x0, [x0, #0xe38]
01b16568: 666bd297 bl       #0xfb1300 ; 
01b1656c: 60b701d0 adrp     x0, #0x5204000
01b16570: 00bc47f9 ldr      x0, [x0, #0xf78]
01b16574: 636bd297 bl       #0xfb1300 ; 
01b16578: 60b501b0 adrp     x0, #0x51c3000
01b1657c: 00fc40f9 ldr      x0, [x0, #0x1f8]
01b16580: 606bd297 bl       #0xfb1300 ; 
01b16584: 00b901d0 adrp     x0, #0x5238000
01b16588: 009446f9 ldr      x0, [x0, #0xd28]
01b1658c: 5d6bd297 bl       #0xfb1300 ; 
01b16590: 40b801d0 adrp     x0, #0x5220000
01b16594: 000443f9 ldr      x0, [x0, #0x608]
01b16598: 5a6bd297 bl       #0xfb1300 ; 
01b1659c: e0b701f0 adrp     x0, #0x5215000
01b165a0: 000846f9 ldr      x0, [x0, #0xc10]
01b165a4: 576bd297 bl       #0xfb1300 ; 
01b165a8: 00b501d0 adrp     x0, #0x51b8000
01b165ac: 005846f9 ldr      x0, [x0, #0xcb0]
01b165b0: 546bd297 bl       #0xfb1300 ; 
01b165b4: 28008052 mov      w8, #1
01b165b8: 88a60039 strb     w8, [x20, #0x29]
01b165bc: 681240f9 ldr      x8, [x19, #0x20]
01b165c0: 680e00b4 cbz      x8, #0x1b1678c
01b165c4: 081540f9 ldr      x8, [x8, #0x28]
01b165c8: 280e00b4 cbz      x8, #0x1b1678c
01b165cc: 161d40f9 ldr      x22, [x8, #0x38]
01b165d0: f60d00b4 cbz      x22, #0x1b1678c
01b165d4: c00a40f9 ldr      x0, [x22, #0x10]
01b165d8: 74b501b0 adrp     x20, #0x51c3000
01b165dc: 75b80190 adrp     x21, #0x5222000
01b165e0: 94fe40f9 ldr      x20, [x20, #0x1f8]
01b165e4: b5ee42f9 ldr      x21, [x21, #0x5d8]
01b165e8: e1031faa mov      x1, xzr
01b165ec: 6cc30794 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01b165f0: 60050036 tbz      w0, #0, #0x1b1669c
01b165f4: 08b501d0 adrp     x8, #0x51b8000
01b165f8: 09b901d0 adrp     x9, #0x5238000
01b165fc: 085946f9 ldr      x8, [x8, #0xcb0]
01b16600: 299546f9 ldr      x9, [x9, #0xd28]
01b16604: 000140f9 ldr      x0, [x8]
01b16608: 210140f9 ldr      x1, [x9]
01b1660c: b5ad2a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01b16610: e00b00b4 cbz      x0, #0x1b1678c
01b16614: e1031faa mov      x1, xzr
01b16618: deb58794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01b1661c: 810240f9 ldr      x1, [x20]
01b16620: 62972894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01b16624: e10300aa mov      x1, x0
01b16628: e00313aa mov      x0, x19
01b1662c: 010c03f8 str      x1, [x0, #0x30]!
01b16630: 1f6bd297 bl       #0xfb12ac ; 
01b16634: b40240f9 ldr      x20, [x21]
01b16638: 881e40f9 ldr      x8, [x20, #0x38]
01b1663c: 000140f9 ldr      x0, [x8]
01b16640: 08c84439 ldrb     w8, [x0, #0x132]
01b16644: 48000037 tbnz     w8, #0, #0x1b1664c
01b16648: 67aad197 bl       #0xf80fe4 ; 
01b1664c: 08e040b9 ldr      w8, [x0, #0xe0]
01b16650: 48000035 cbnz     w8, #0x1b16658
01b16654: 6c6bd297 bl       #0xfb1404 ; 
01b16658: 881e40f9 ldr      x8, [x20, #0x38]
01b1665c: f4b701f0 adrp     x20, #0x5215000
01b16660: 000140f9 ldr      x0, [x8]
01b16664: 08c84439 ldrb     w8, [x0, #0x132]
01b16668: 940a46f9 ldr      x20, [x20, #0xc10]
01b1666c: 48000037 tbnz     w8, #0, #0x1b16674
01b16670: 5daad197 bl       #0xf80fe4 ; 
01b16674: 085c40f9 ldr      x8, [x0, #0xb8]
01b16678: 820240f9 ldr      x2, [x20]
01b1667c: e00313aa mov      x0, x19
01b16680: f37b42a9 ldp      x19, x30, [sp, #0x20]
01b16684: 030140f9 ldr      x3, [x8]
01b16688: f55341a9 ldp      x21, x20, [sp, #0x10]
01b1668c: a1088052 mov      w1, #0x45
01b16690: e4031faa mov      x4, xzr
01b16694: f60743f8 ldr      x22, [sp], #0x30
01b16698: a2a83314 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01b1669c: c00a40f9 ldr      x0, [x22, #0x10]
01b166a0: 810240f9 ldr      x1, [x20]
01b166a4: 41972894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01b166a8: f40313aa mov      x20, x19
01b166ac: 800e03f8 str      x0, [x20, #0x30]!
01b166b0: e10300aa mov      x1, x0
01b166b4: e00314aa mov      x0, x20
01b166b8: fd6ad297 bl       #0xfb12ac ; 
01b166bc: 88025ff8 ldur     x8, [x20, #-0x10]
01b166c0: 680600b4 cbz      x8, #0x1b1678c
01b166c4: 081540f9 ldr      x8, [x8, #0x28]
01b166c8: 280600b4 cbz      x8, #0x1b1678c
01b166cc: 082140f9 ldr      x8, [x8, #0x40]
01b166d0: e80500b4 cbz      x8, #0x1b1678c
01b166d4: 890240f9 ldr      x9, [x20]
01b166d8: a90500b4 cbz      x9, #0x1b1678c
01b166dc: 081140b9 ldr      w8, [x8, #0x10]
01b166e0: 6ab701d0 adrp     x10, #0x5204000
01b166e4: 4abd47f9 ldr      x10, [x10, #0xf78]
01b166e8: 54b801d0 adrp     x20, #0x5220000
01b166ec: 281100b9 str      w8, [x9, #0x10]
01b166f0: e1330091 add      x1, sp, #0xc
01b166f4: 400140f9 ldr      x0, [x10]
01b166f8: 940643f9 ldr      x20, [x20, #0x608]
01b166fc: e80f00b9 str      w8, [sp, #0xc]
01b16700: 436bd297 bl       #0xfb140c ; 
01b16704: 880240f9 ldr      x8, [x20]
01b16708: e10300aa mov      x1, x0
01b1670c: e2031faa mov      x2, xzr
01b16710: e00308aa mov      x0, x8
01b16714: 319e0794 bl       #0x1cfdfd8 ; System.String$$Format
01b16718: b50240f9 ldr      x21, [x21]
01b1671c: f40300aa mov      x20, x0
01b16720: a81e40f9 ldr      x8, [x21, #0x38]
01b16724: 080140f9 ldr      x8, [x8]
01b16728: 09c94439 ldrb     w9, [x8, #0x132]
01b1672c: 89000037 tbnz     w9, #0, #0x1b1673c
01b16730: e00308aa mov      x0, x8
01b16734: 2caad197 bl       #0xf80fe4 ; 
01b16738: e80300aa mov      x8, x0
01b1673c: 09e140b9 ldr      w9, [x8, #0xe0]
01b16740: 69000035 cbnz     w9, #0x1b1674c
01b16744: e00308aa mov      x0, x8
01b16748: 2f6bd297 bl       #0xfb1404 ; 
01b1674c: a81e40f9 ldr      x8, [x21, #0x38]
01b16750: 000140f9 ldr      x0, [x8]
01b16754: 08c84439 ldrb     w8, [x0, #0x132]
01b16758: 48000037 tbnz     w8, #0, #0x1b16760
01b1675c: 22aad197 bl       #0xf80fe4 ; 
01b16760: 085c40f9 ldr      x8, [x0, #0xb8]
01b16764: a1088052 mov      w1, #0x45
01b16768: e00313aa mov      x0, x19
01b1676c: e20314aa mov      x2, x20
01b16770: 030140f9 ldr      x3, [x8]
01b16774: e4031faa mov      x4, xzr
01b16778: 6aa83394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01b1677c: f37b42a9 ldp      x19, x30, [sp, #0x20]
01b16780: f55341a9 ldp      x21, x20, [sp, #0x10]
01b16784: f60743f8 ldr      x22, [sp], #0x30
01b16788: c0035fd6 ret      
01b1678c: 276bd297 bl       #0xfb1428 ; 
