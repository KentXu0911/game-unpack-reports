# Royal.Player.Context.Units.LevelEpisodeHelper$$OnEgoAccepted
# Linear metadata span, not a recovered full CFG.
02059dc8: f40f1ef8 str      x20, [sp, #-0x20]!
02059dcc: f37b01a9 stp      x19, x30, [sp, #0x10]
02059dd0: 34a90190 adrp     x20, #0x557d000
02059dd4: 88324839 ldrb     w8, [x20, #0x20c]
02059dd8: f30300aa mov      x19, x0
02059ddc: c8000037 tbnz     w8, #0, #0x2059df4
02059de0: c08c01b0 adrp     x0, #0x51f2000
02059de4: 003444f9 ldr      x0, [x0, #0x868]
02059de8: 465dbd97 bl       #0xfb1300 ; 
02059dec: 28008052 mov      w8, #1
02059df0: 88320839 strb     w8, [x20, #0x20c]
02059df4: 730a40f9 ldr      x19, [x19, #0x10]
02059df8: 930300b4 cbz      x19, #0x2059e68
02059dfc: ca8c01b0 adrp     x10, #0x51f2000
02059e00: 680240f9 ldr      x8, [x19]
02059e04: 4a3544f9 ldr      x10, [x10, #0x868]
02059e08: 09554279 ldrh     w9, [x8, #0x12a]
02059e0c: 410140f9 ldr      x1, [x10]
02059e10: 290100b4 cbz      x9, #0x2059e34
02059e14: 0a5940f9 ldr      x10, [x8, #0xb0]
02059e18: 4a210091 add      x10, x10, #8
02059e1c: 4b815ff8 ldur     x11, [x10, #-8]
02059e20: 7f0101eb cmp      x11, x1
02059e24: 00010054 b.eq     #0x2059e44
02059e28: 290500f1 subs     x9, x9, #1
02059e2c: 4a410091 add      x10, x10, #0x10
02059e30: 61ffff54 b.ne     #0x2059e1c
02059e34: a2008052 mov      w2, #5
02059e38: e00313aa mov      x0, x19
02059e3c: 269dbc97 bl       #0xf812d4 ; 
02059e40: 05000014 b        #0x2059e54 ; 
02059e44: 490140b9 ldr      w9, [x10]
02059e48: 29150011 add      w9, w9, #5
02059e4c: 08d1298b add      x8, x8, w9, sxtw #4
02059e50: 00e10491 add      x0, x8, #0x138
02059e54: 020440a9 ldp      x2, x1, [x0]
02059e58: e00313aa mov      x0, x19
02059e5c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059e60: f40742f8 ldr      x20, [sp], #0x20
02059e64: 40001fd6 br       x2
02059e68: 705dbd97 bl       #0xfb1428 ; 
