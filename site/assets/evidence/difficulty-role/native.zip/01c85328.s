# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnLevelSuccess
# Linear metadata span, not a recovered full CFG.
01c85328: 67ffff17 b        #0x1c850c4 ; Royal.Player.Context.Units.SemiDynamicDifficulty$$IncrementTryCount
