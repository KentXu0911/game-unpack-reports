# Royal.Player.Context.Data.Persistent.UserInventory$$GetTryCount2
# Linear metadata span, not a recovered full CFG.
02a0e82c: fe0f1ff8 str      x30, [sp, #-0x10]!
02a0e830: 005840f9 ldr      x0, [x0, #0xb0]
02a0e834: 21008052 mov      w1, #1
02a0e838: 82018052 mov      w2, #0xc
02a0e83c: e3031faa mov      x3, xzr
02a0e840: ded62194 bl       #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
02a0e844: fe0741f8 ldr      x30, [sp], #0x10
02a0e848: c0035fd6 ret      
