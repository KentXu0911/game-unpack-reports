# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromList<int>
# Linear metadata span, not a recovered full CFG.
0253edd0: f553bea9 stp      x21, x20, [sp, #-0x20]!
0253edd4: f37b01a9 stp      x19, x30, [sp, #0x10]
0253edd8: c10200b4 cbz      x1, #0x253ee30
0253eddc: 481c40f9 ldr      x8, [x2, #0x38]
0253ede0: f30301aa mov      x19, x1
0253ede4: f50300aa mov      x21, x0
0253ede8: e00313aa mov      x0, x19
0253edec: 010540f9 ldr      x1, [x8, #8]
0253edf0: f40302aa mov      x20, x2
0253edf4: 280440f9 ldr      x8, [x1, #8]
0253edf8: 00013fd6 blr      x8
0253edfc: e203002a mov      w2, w0
0253ee00: e00315aa mov      x0, x21
0253ee04: e1031f2a mov      w1, wzr
0253ee08: e3031faa mov      x3, xzr
0253ee0c: 77c81394 bl       #0x2a30fe8 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Next
0253ee10: 881e40f9 ldr      x8, [x20, #0x38]
0253ee14: e103002a mov      w1, w0
0253ee18: e00313aa mov      x0, x19
0253ee1c: f37b41a9 ldp      x19, x30, [sp, #0x10]
0253ee20: 020940f9 ldr      x2, [x8, #0x10]
0253ee24: 430440f9 ldr      x3, [x2, #8]
0253ee28: f553c2a8 ldp      x21, x20, [sp], #0x20
0253ee2c: 60001fd6 br       x3
0253ee30: 7ec9a997 bl       #0xfb1428 ; 
