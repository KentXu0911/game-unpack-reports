# Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableScenariosTable$$RefillScenarioListOnTable
# Linear metadata span, not a recovered full CFG.
02e62c58: ff4301d1 sub      sp, sp, #0x50
02e62c5c: f96301a9 stp      x25, x24, [sp, #0x10]
02e62c60: f75b02a9 stp      x23, x22, [sp, #0x20]
02e62c64: f55303a9 stp      x21, x20, [sp, #0x30]
02e62c68: f37b04a9 stp      x19, x30, [sp, #0x40]
02e62c6c: 163901d0 adrp     x22, #0x5584000
02e62c70: c8fe6039 ldrb     w8, [x22, #0x83f]
02e62c74: f50302aa mov      x21, x2
02e62c78: f403012a mov      w20, w1
02e62c7c: f303002a mov      w19, w0
02e62c80: 88010037 tbnz     w8, #0, #0x2e62cb0
02e62c84: 001d01d0 adrp     x0, #0x5204000
02e62c88: 00bc47f9 ldr      x0, [x0, #0xf78]
02e62c8c: 9d398597 bl       #0xfb1300 ; 
02e62c90: 601e01f0 adrp     x0, #0x5231000
02e62c94: 003841f9 ldr      x0, [x0, #0x270]
02e62c98: 9a398597 bl       #0xfb1300 ; 
02e62c9c: 801c01b0 adrp     x0, #0x51f3000
02e62ca0: 007440f9 ldr      x0, [x0, #0xe8]
02e62ca4: 97398597 bl       #0xfb1300 ; 
02e62ca8: 28008052 mov      w8, #1
02e62cac: c8fe2039 strb     w8, [x22, #0x83f]
02e62cb0: 150c00b4 cbz      x21, #0x2e62e30
02e62cb4: e00315aa mov      x0, x21
02e62cb8: e1031faa mov      x1, xzr
02e62cbc: 36a21894 bl       #0x348b594 ; Royal.Scenes.Start.Context.Units.FeatureBundle.DragonNestScenarioBundle$$AllScenariosDataText
02e62cc0: 800b00b4 cbz      x0, #0x2e62e30
02e62cc4: e1031faa mov      x1, xzr
02e62cc8: 32843a94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02e62ccc: 200b00b4 cbz      x0, #0x2e62e30
02e62cd0: 41018052 mov      w1, #0xa
02e62cd4: e2031f2a mov      w2, wzr
02e62cd8: e3031faa mov      x3, xzr
02e62cdc: a69cba97 bl       #0x1d09f74 ; System.String$$Split
02e62ce0: 800a00b4 cbz      x0, #0x2e62e30
02e62ce4: 091840b9 ldr      w9, [x0, #0x18]
02e62ce8: 68060051 sub      w8, w19, #1
02e62cec: 1f01096b cmp      w8, w9
02e62cf0: 220a0054 b.hs     #0x2e62e34
02e62cf4: 08cc288b add      x8, x0, w8, sxtw #3
02e62cf8: 001140f9 ldr      x0, [x8, #0x20]
02e62cfc: a00900b4 cbz      x0, #0x2e62e30
02e62d00: 61078052 mov      w1, #0x3b
02e62d04: e2031f2a mov      w2, wzr
02e62d08: e3031faa mov      x3, xzr
02e62d0c: 9a9cba97 bl       #0x1d09f74 ; System.String$$Split
02e62d10: 000900b4 cbz      x0, #0x2e62e30
02e62d14: 091840b9 ldr      w9, [x0, #0x18]
02e62d18: 88060051 sub      w8, w20, #1
02e62d1c: 1f01096b cmp      w8, w9
02e62d20: a2080054 b.hs     #0x2e62e34
02e62d24: 08cc288b add      x8, x0, w8, sxtw #3
02e62d28: 181d01d0 adrp     x24, #0x5204000
02e62d2c: 961c01b0 adrp     x22, #0x51f3000
02e62d30: 791e01f0 adrp     x25, #0x5231000
02e62d34: 171140f9 ldr      x23, [x8, #0x20]
02e62d38: 18bf47f9 ldr      x24, [x24, #0xf78]
02e62d3c: d67640f9 ldr      x22, [x22, #0xe8]
02e62d40: 393b41f9 ldr      x25, [x25, #0x270]
02e62d44: b9fdff97 bl       #0x2e62428 ; Royal.Infrastructure.Services.Storage.Tables.DragonNestAvailableScenariosTable$$get_DatabaseService
02e62d48: f50300aa mov      x21, x0
02e62d4c: 000340f9 ldr      x0, [x24]
02e62d50: e1330091 add      x1, sp, #0xc
02e62d54: f40f00b9 str      w20, [sp, #0xc]
02e62d58: ad398597 bl       #0xfb140c ; 
02e62d5c: c80240f9 ldr      x8, [x22]
02e62d60: e10300aa mov      x1, x0
02e62d64: e2031faa mov      x2, xzr
02e62d68: e00308aa mov      x0, x8
02e62d6c: 9b6cba97 bl       #0x1cfdfd8 ; System.String$$Format
02e62d70: 280340f9 ldr      x8, [x25]
02e62d74: f40300aa mov      x20, x0
02e62d78: 41008052 mov      w1, #2
02e62d7c: e00308aa mov      x0, x8
02e62d80: 7c398597 bl       #0xfb1370 ; 
02e62d84: 600500b4 cbz      x0, #0x2e62e30
02e62d88: f60300aa mov      x22, x0
02e62d8c: d70000b4 cbz      x23, #0x2e62da4
02e62d90: c80240f9 ldr      x8, [x22]
02e62d94: e00317aa mov      x0, x23
02e62d98: 012140f9 ldr      x1, [x8, #0x40]
02e62d9c: 9b398597 bl       #0xfb1408 ; 
02e62da0: c00400b4 cbz      x0, #0x2e62e38
02e62da4: c81a40b9 ldr      w8, [x22, #0x18]
02e62da8: 68040034 cbz      w8, #0x2e62e34
02e62dac: e00316aa mov      x0, x22
02e62db0: 170c02f8 str      x23, [x0, #0x20]!
02e62db4: e10317aa mov      x1, x23
02e62db8: 3d398597 bl       #0xfb12ac ; 
02e62dbc: 000340f9 ldr      x0, [x24]
02e62dc0: e1230091 add      x1, sp, #8
02e62dc4: f30b00b9 str      w19, [sp, #8]
02e62dc8: 91398597 bl       #0xfb140c ; 
02e62dcc: f30300aa mov      x19, x0
02e62dd0: c00000b4 cbz      x0, #0x2e62de8
02e62dd4: c80240f9 ldr      x8, [x22]
02e62dd8: e00313aa mov      x0, x19
02e62ddc: 012140f9 ldr      x1, [x8, #0x40]
02e62de0: 8a398597 bl       #0xfb1408 ; 
02e62de4: a00200b4 cbz      x0, #0x2e62e38
02e62de8: c81a40b9 ldr      w8, [x22, #0x18]
02e62dec: 1f050071 cmp      w8, #1
02e62df0: 29020054 b.ls     #0x2e62e34
02e62df4: e00316aa mov      x0, x22
02e62df8: 138c02f8 str      x19, [x0, #0x28]!
02e62dfc: e10313aa mov      x1, x19
02e62e00: 2b398597 bl       #0xfb12ac ; 
02e62e04: 750100b4 cbz      x21, #0x2e62e30
02e62e08: e00315aa mov      x0, x21
02e62e0c: e10314aa mov      x1, x20
02e62e10: e20316aa mov      x2, x22
02e62e14: 37ddff97 bl       #0x2e5a2f0 ; Royal.Infrastructure.Services.Storage.DatabaseService$$ExecuteNonQuery
02e62e18: f37b44a9 ldp      x19, x30, [sp, #0x40]
02e62e1c: f55343a9 ldp      x21, x20, [sp, #0x30]
02e62e20: f75b42a9 ldp      x23, x22, [sp, #0x20]
02e62e24: f96341a9 ldp      x25, x24, [sp, #0x10]
02e62e28: ff430191 add      sp, sp, #0x50
02e62e2c: c0035fd6 ret      
02e62e30: 7e398597 bl       #0xfb1428 ; 
02e62e34: 7f398597 bl       #0xfb1430 ; 
02e62e38: 85398597 bl       #0xfb144c ; 
02e62e3c: e1031faa mov      x1, xzr
02e62e40: 6c398597 bl       #0xfb13f0 ; 
