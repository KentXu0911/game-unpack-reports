# TMPro.TMP_Settings$$GetCharacters
# Linear metadata span, not a recovered full CFG.
039fef50: f80f1cf8 str      x24, [sp, #-0x40]!
039fef54: f75b01a9 stp      x23, x22, [sp, #0x10]
039fef58: f55302a9 stp      x21, x20, [sp, #0x20]
039fef5c: f37b03a9 stp      x19, x30, [sp, #0x30]
039fef60: 53dc00f0 adrp     x19, #0x5589000
039fef64: 75bf0090 adrp     x21, #0x51ea000
039fef68: 68567e39 ldrb     w8, [x19, #0xf95]
039fef6c: b5c246f9 ldr      x21, [x21, #0xd80]
039fef70: f40300aa mov      x20, x0
039fef74: e8010037 tbnz     w8, #0, #0x39fefb0
039fef78: e0c10090 adrp     x0, #0x523a000
039fef7c: 00c846f9 ldr      x0, [x0, #0xd90]
039fef80: e0c85697 bl       #0xfb1300 ; 
039fef84: 80bf00f0 adrp     x0, #0x51f1000
039fef88: 00dc47f9 ldr      x0, [x0, #0xfb8]
039fef8c: ddc85697 bl       #0xfb1300 ; 
039fef90: e0c000b0 adrp     x0, #0x521b000
039fef94: 006c45f9 ldr      x0, [x0, #0xad8]
039fef98: dac85697 bl       #0xfb1300 ; 
039fef9c: 60bf0090 adrp     x0, #0x51ea000
039fefa0: 00c046f9 ldr      x0, [x0, #0xd80]
039fefa4: d7c85697 bl       #0xfb1300 ; 
039fefa8: 28008052 mov      w8, #1
039fefac: 68563e39 strb     w8, [x19, #0xf95]
039fefb0: a00240f9 ldr      x0, [x21]
039fefb4: 19c95697 bl       #0xfb1418 ; 
039fefb8: a00500b4 cbz      x0, #0x39ff06c
039fefbc: e8c000b0 adrp     x8, #0x521b000
039fefc0: 086d45f9 ldr      x8, [x8, #0xad8]
039fefc4: f30300aa mov      x19, x0
039fefc8: 010140f9 ldr      x1, [x8]
039fefcc: e5b4f397 bl       #0x36ec360 ; System.Collections.Generic.Dictionary<int, char>$$.ctor
039fefd0: f40400b4 cbz      x20, #0x39ff06c
039fefd4: e00314aa mov      x0, x20
039fefd8: e1031faa mov      x1, xzr
039fefdc: 6d130c94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
039fefe0: 600400b4 cbz      x0, #0x39ff06c
039fefe4: 081040b9 ldr      w8, [x0, #0x10]
039fefe8: f40300aa mov      x20, x0
039fefec: 1f050071 cmp      w8, #1
039feff0: 2b030054 b.lt     #0x39ff054
039feff4: 97bf00f0 adrp     x23, #0x51f1000
039feff8: f8c10090 adrp     x24, #0x523a000
039feffc: f7de47f9 ldr      x23, [x23, #0xfb8]
039ff000: e82a0014 b        #0x3a09ba0 ; 
039ff004: f5031f2a mov      w21, wzr
039ff008: e00314aa mov      x0, x20
039ff00c: e103152a mov      w1, w21
039ff010: e2031faa mov      x2, xzr
039ff014: b40b8c97 bl       #0x1d01ee4 ; System.String$$get_Chars
039ff018: e20240f9 ldr      x2, [x23]
039ff01c: 163c0012 and      w22, w0, #0xffff
039ff020: e00313aa mov      x0, x19
039ff024: e103162a mov      w1, w22
039ff028: e9b7f397 bl       #0x36ecfcc ; System.Collections.Generic.Dictionary<int, char>$$ContainsKey
039ff02c: c0000037 tbnz     w0, #0, #0x39ff044
039ff030: 030340f9 ldr      x3, [x24]
039ff034: e00313aa mov      x0, x19
039ff038: e103162a mov      w1, w22
039ff03c: e203162a mov      w2, w22
039ff040: 65b7f397 bl       #0x36ecdd4 ; System.Collections.Generic.Dictionary<int, char>$$Add
039ff044: 881240b9 ldr      w8, [x20, #0x10]
039ff048: b5060011 add      w21, w21, #1
039ff04c: bf02086b cmp      w21, w8
039ff050: cbfdff54 b.lt     #0x39ff008
039ff054: e00313aa mov      x0, x19
039ff058: f37b43a9 ldp      x19, x30, [sp, #0x30]
039ff05c: f55342a9 ldp      x21, x20, [sp, #0x20]
039ff060: f75b41a9 ldp      x23, x22, [sp, #0x10]
039ff064: f80744f8 ldr      x24, [sp], #0x40
039ff068: c0035fd6 ret      
039ff06c: efc85697 bl       #0xfb1428 ; 
