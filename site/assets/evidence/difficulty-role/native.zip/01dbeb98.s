# Royal.Player.Context.Units.KingWorkshopManager$$GetGoalCount
# Linear metadata span, not a recovered full CFG.
01dbeb98: f553bea9 stp      x21, x20, [sp, #-0x20]!
01dbeb9c: f37b01a9 stp      x19, x30, [sp, #0x10]
01dbeba0: f4bd01b0 adrp     x20, #0x557b000
01dbeba4: 159f01b0 adrp     x21, #0x519f000
01dbeba8: 88127f39 ldrb     w8, [x20, #0xfc4]
01dbebac: b5aa45f9 ldr      x21, [x21, #0xb50]
01dbebb0: f30300aa mov      x19, x0
01dbebb4: 28010037 tbnz     w8, #0, #0x1dbebd8
01dbebb8: 60a301b0 adrp     x0, #0x522b000
01dbebbc: 006445f9 ldr      x0, [x0, #0xac8]
01dbebc0: d0c9c797 bl       #0xfb1300 ; 
01dbebc4: 009f01b0 adrp     x0, #0x519f000
01dbebc8: 00a845f9 ldr      x0, [x0, #0xb50]
01dbebcc: cdc9c797 bl       #0xfb1300 ; 
01dbebd0: 28008052 mov      w8, #1
01dbebd4: 88123f39 strb     w8, [x20, #0xfc4]
01dbebd8: a00240f9 ldr      x0, [x21]
01dbebdc: 08e040b9 ldr      w8, [x0, #0xe0]
01dbebe0: 48000035 cbnz     w8, #0x1dbebe8
01dbebe4: 08cac797 bl       #0xfb1404 ; 
01dbebe8: e00313aa mov      x0, x19
01dbebec: e1031faa mov      x1, xzr
01dbebf0: e2031faa mov      x2, xzr
01dbebf4: 5ee27c94 bl       #0x3cf756c ; UnityEngine.Object$$op_Equality
01dbebf8: 80040037 tbnz     w0, #0, #0x1dbec88
01dbebfc: 130200b4 cbz      x19, #0x1dbec3c
01dbec00: e00313aa mov      x0, x19
01dbec04: e1031faa mov      x1, xzr
01dbec08: 62147d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01dbec0c: 68a301b0 adrp     x8, #0x522b000
01dbec10: 086545f9 ldr      x8, [x8, #0xac8]
01dbec14: 010140f9 ldr      x1, [x8]
01dbec18: e4f51d94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01dbec1c: f30300aa mov      x19, x0
01dbec20: 400300b4 cbz      x0, #0x1dbec88
01dbec24: e00313aa mov      x0, x19
01dbec28: e1031faa mov      x1, xzr
01dbec2c: 0e816894 bl       #0x37df064 ; Royal.Scenes.TableGame.Config.TableGameLevelConfig$$Normalize
01dbec30: e00313aa mov      x0, x19
01dbec34: 43000094 bl       #0x1dbed40 ; Royal.Player.Context.Units.KingWorkshopManager$$GetGoalCount
01dbec38: 15000014 b        #0x1dbec8c ; 
01dbec3c: fbc9c797 bl       #0xfb1428 ; 
01dbec40: 04000014 b        #0x1dbec50 ; 
01dbec44: 03000014 b        #0x1dbec50 ; 
01dbec48: 02000014 b        #0x1dbec50 ; 
01dbec4c: 01000014 b        #0x1dbec50 ; 
01dbec50: f30300aa mov      x19, x0
01dbec54: 3f040071 cmp      w1, #1
01dbec58: 41030054 b.ne     #0x1dbecc0
01dbec5c: e00313aa mov      x0, x19
01dbec60: 5c12bc97 bl       #0xcc35d0 ; 
01dbec64: f30300aa mov      x19, x0
01dbec68: 00a301b0 adrp     x0, #0x521f000
01dbec6c: 001840f9 ldr      x0, [x0, #0x30]
01dbec70: a9c9c797 bl       #0xfb1314 ; 
01dbec74: 680240f9 ldr      x8, [x19]
01dbec78: 010140f9 ldr      x1, [x8]
01dbec7c: ebcac797 bl       #0xfb1828 ; 
01dbec80: c0000036 tbz      w0, #0, #0x1dbec98
01dbec84: cf10bc97 bl       #0xcc2fc0 ; 
01dbec88: e0031f2a mov      w0, wzr
01dbec8c: f37b41a9 ldp      x19, x30, [sp, #0x10]
01dbec90: f553c2a8 ldp      x21, x20, [sp], #0x20
01dbec94: c0035fd6 ret      
01dbec98: 00018052 mov      w0, #8
01dbec9c: c90fbc97 bl       #0xcc2bc0 ; 
01dbeca0: 680240f9 ldr      x8, [x19]
01dbeca4: 080000f9 str      x8, [x0]
01dbeca8: 418e01b0 adrp     x1, #0x4f87000
01dbecac: 21603f91 add      x1, x1, #0xfd8
01dbecb0: e2031faa mov      x2, xzr
01dbecb4: 7b0dbc97 bl       #0xcc22a0 ; 
01dbecb8: f30300aa mov      x19, x0
01dbecbc: c110bc97 bl       #0xcc2fc0 ; 
01dbecc0: e00313aa mov      x0, x19
01dbecc4: 8f10bc97 bl       #0xcc2f00 ; 
01dbecc8: a026bc97 bl       #0xcc8748 ; 
