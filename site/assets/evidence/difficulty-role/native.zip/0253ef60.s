# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromListBasedOnDifficulty<byte>
# Linear metadata span, not a recovered full CFG.
0253ef60: f553bea9 stp      x21, x20, [sp, #-0x20]!
0253ef64: f37b01a9 stp      x19, x30, [sp, #0x10]
0253ef68: c10200b4 cbz      x1, #0x253efc0
0253ef6c: 481c40f9 ldr      x8, [x2, #0x38]
0253ef70: f30301aa mov      x19, x1
0253ef74: f50300aa mov      x21, x0
0253ef78: e00313aa mov      x0, x19
0253ef7c: 010540f9 ldr      x1, [x8, #8]
0253ef80: f40302aa mov      x20, x2
0253ef84: 280440f9 ldr      x8, [x1, #8]
0253ef88: 00013fd6 blr      x8
0253ef8c: e203002a mov      w2, w0
0253ef90: e00315aa mov      x0, x21
0253ef94: e1031f2a mov      w1, wzr
0253ef98: e3031faa mov      x3, xzr
0253ef9c: 36c91394 bl       #0x2a31474 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$DifficultyNext
0253efa0: 881e40f9 ldr      x8, [x20, #0x38]
0253efa4: e103002a mov      w1, w0
0253efa8: e00313aa mov      x0, x19
0253efac: f37b41a9 ldp      x19, x30, [sp, #0x10]
0253efb0: 020940f9 ldr      x2, [x8, #0x10]
0253efb4: 430440f9 ldr      x3, [x2, #8]
0253efb8: f553c2a8 ldp      x21, x20, [sp], #0x20
0253efbc: 60001fd6 br       x3
0253efc0: 1ac9a997 bl       #0xfb1428 ; 
