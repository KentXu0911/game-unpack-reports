# Spine.Unity.SpineAtlasAsset$$CreateRuntimeInstance
# Linear metadata span, not a recovered full CFG.
01fda230: ff0302d1 sub      sp, sp, #0x80
01fda234: fc6f02a9 stp      x28, x27, [sp, #0x20]
01fda238: fa6703a9 stp      x26, x25, [sp, #0x30]
01fda23c: f85f04a9 stp      x24, x23, [sp, #0x40]
01fda240: f65705a9 stp      x22, x21, [sp, #0x50]
01fda244: f44f06a9 stp      x20, x19, [sp, #0x60]
01fda248: fd7b07a9 stp      x29, x30, [sp, #0x70]
01fda24c: 13ad01d0 adrp     x19, #0x557c000
01fda250: 685e7a39 ldrb     w8, [x19, #0xe97]
01fda254: f403032a mov      w20, w3
01fda258: f50301aa mov      x21, x1
01fda25c: f60300aa mov      x22, x0
01fda260: e20f00f9 str      x2, [sp, #0x18]
01fda264: 88040037 tbnz     w8, #0, #0x1fda2f4
01fda268: 609201b0 adrp     x0, #0x5227000
01fda26c: 003444f9 ldr      x0, [x0, #0x868]
01fda270: 245cbf97 bl       #0xfb1300 ; 
01fda274: 008e0190 adrp     x0, #0x519a000
01fda278: 007c45f9 ldr      x0, [x0, #0xaf8]
01fda27c: 215cbf97 bl       #0xfb1300 ; 
01fda280: 409101f0 adrp     x0, #0x5205000
01fda284: 009441f9 ldr      x0, [x0, #0x328]
01fda288: 1e5cbf97 bl       #0xfb1300 ; 
01fda28c: 208e01d0 adrp     x0, #0x51a0000
01fda290: 00fc42f9 ldr      x0, [x0, #0x5f8]
01fda294: 1b5cbf97 bl       #0xfb1300 ; 
01fda298: 808e01b0 adrp     x0, #0x51ab000
01fda29c: 008841f9 ldr      x0, [x0, #0x310]
01fda2a0: 185cbf97 bl       #0xfb1300 ; 
01fda2a4: c08d01d0 adrp     x0, #0x5194000
01fda2a8: 006c46f9 ldr      x0, [x0, #0xcd8]
01fda2ac: 155cbf97 bl       #0xfb1300 ; 
01fda2b0: 409001b0 adrp     x0, #0x51e3000
01fda2b4: 00f040f9 ldr      x0, [x0, #0x1e0]
01fda2b8: 125cbf97 bl       #0xfb1300 ; 
01fda2bc: 208e01b0 adrp     x0, #0x519f000
01fda2c0: 00a845f9 ldr      x0, [x0, #0xb50]
01fda2c4: 0f5cbf97 bl       #0xfb1300 ; 
01fda2c8: a08f0190 adrp     x0, #0x51ce000
01fda2cc: 003444f9 ldr      x0, [x0, #0x868]
01fda2d0: 0c5cbf97 bl       #0xfb1300 ; 
01fda2d4: 608e01b0 adrp     x0, #0x51a7000
01fda2d8: 000441f9 ldr      x0, [x0, #0x208]
01fda2dc: 095cbf97 bl       #0xfb1300 ; 
01fda2e0: 209001f0 adrp     x0, #0x51e1000
01fda2e4: 007c44f9 ldr      x0, [x0, #0x8f8]
01fda2e8: 065cbf97 bl       #0xfb1300 ; 
01fda2ec: 28008052 mov      w8, #1
01fda2f0: 685e3a39 strb     w8, [x19, #0xe97]
01fda2f4: 361800b4 cbz      x22, #0x1fda5f8
01fda2f8: e00316aa mov      x0, x22
01fda2fc: e1031faa mov      x1, xzr
01fda300: a4a67494 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01fda304: a01700b4 cbz      x0, #0x1fda5f8
01fda308: 289001f0 adrp     x8, #0x51e1000
01fda30c: 798e01b0 adrp     x25, #0x51a7000
01fda310: 087d44f9 ldr      x8, [x8, #0x8f8]
01fda314: 390741f9 ldr      x25, [x25, #0x208]
01fda318: e3031faa mov      x3, xzr
01fda31c: 010140f9 ldr      x1, [x8]
01fda320: 220340f9 ldr      x2, [x25]
01fda324: 7abdf497 bl       #0x1d0990c ; System.String$$Replace
01fda328: 801600b4 cbz      x0, #0x1fda5f8
01fda32c: 938e01b0 adrp     x19, #0x51ab000
01fda330: 738a41f9 ldr      x19, [x19, #0x310]
01fda334: 41018052 mov      w1, #0xa
01fda338: e2031f2a mov      w2, wzr
01fda33c: e3031faa mov      x3, xzr
01fda340: 0dbff497 bl       #0x1d09f74 ; System.String$$Split
01fda344: 680240f9 ldr      x8, [x19]
01fda348: f80300aa mov      x24, x0
01fda34c: e00308aa mov      x0, x8
01fda350: 325cbf97 bl       #0xfb1418 ; 
01fda354: 201500b4 cbz      x0, #0x1fda5f8
01fda358: 088e0190 adrp     x8, #0x519a000
01fda35c: 087d45f9 ldr      x8, [x8, #0xaf8]
01fda360: f70300aa mov      x23, x0
01fda364: 010140f9 ldr      x1, [x8]
01fda368: c5ce2794 bl       #0x29cde7c ; System.Collections.Generic.List<object>$$.ctor
01fda36c: 781400b4 cbz      x24, #0x1fda5f8
01fda370: 081b40b9 ldr      w8, [x24, #0x18]
01fda374: f60700f9 str      x22, [sp, #8]
01fda378: f41700b9 str      w20, [sp, #0x14]
01fda37c: 09050051 sub      w9, w8, #1
01fda380: 3f050071 cmp      w9, #1
01fda384: 4b070054 b.lt     #0x1fda46c
01fda388: b38f0190 adrp     x19, #0x51ce000
01fda38c: 7a9201b0 adrp     x26, #0x5227000
01fda390: 733644f9 ldr      x19, [x19, #0x868]
01fda394: 5a3744f9 ldr      x26, [x26, #0x868]
01fda398: f6031faa mov      x22, xzr
01fda39c: 1ba30091 add      x27, x24, #0x28
01fda3a0: df02086b cmp      w22, w8
01fda3a4: c2120054 b.hs     #0x1fda5fc
01fda3a8: 08cf368b add      x8, x24, w22, sxtw #3
01fda3ac: 001140f9 ldr      x0, [x8, #0x20]
01fda3b0: 401200b4 cbz      x0, #0x1fda5f8
01fda3b4: e1031faa mov      x1, xzr
01fda3b8: fcc6f497 bl       #0x1d0bfa8 ; System.String$$Trim
01fda3bc: e01100b4 cbz      x0, #0x1fda5f8
01fda3c0: 081040b9 ldr      w8, [x0, #0x10]
01fda3c4: dc060091 add      x28, x22, #1
01fda3c8: 88040035 cbnz     w8, #0x1fda458
01fda3cc: 081b40b9 ldr      w8, [x24, #0x18]
01fda3d0: 9f03086b cmp      w28, w8
01fda3d4: 42110054 b.hs     #0x1fda5fc
01fda3d8: 607b76f8 ldr      x0, [x27, x22, lsl #3]
01fda3dc: e01000b4 cbz      x0, #0x1fda5f8
01fda3e0: e1031faa mov      x1, xzr
01fda3e4: f1c6f497 bl       #0x1d0bfa8 ; System.String$$Trim
01fda3e8: 801000b4 cbz      x0, #0x1fda5f8
01fda3ec: 610240f9 ldr      x1, [x19]
01fda3f0: 220340f9 ldr      x2, [x25]
01fda3f4: e3031faa mov      x3, xzr
01fda3f8: 45bdf497 bl       #0x1d0990c ; System.String$$Replace
01fda3fc: ea1e40b9 ldr      w10, [x23, #0x1c]
01fda400: e80a40f9 ldr      x8, [x23, #0x10]
01fda404: 490340f9 ldr      x9, [x26]
01fda408: 4a050011 add      w10, w10, #1
01fda40c: ea1e00b9 str      w10, [x23, #0x1c]
01fda410: 480f00b4 cbz      x8, #0x1fda5f8
01fda414: ea1a80b9 ldrsw    x10, [x23, #0x18]
01fda418: 0b1940b9 ldr      w11, [x8, #0x18]
01fda41c: e10300aa mov      x1, x0
01fda420: 5f010b6b cmp      w10, w11
01fda424: e2000054 b.hs     #0x1fda440
01fda428: 49050011 add      w9, w10, #1
01fda42c: 000d0a8b add      x0, x8, x10, lsl #3
01fda430: e91a00b9 str      w9, [x23, #0x18]
01fda434: 010c02f8 str      x1, [x0, #0x20]!
01fda438: 9d5bbf97 bl       #0xfb12ac ; 
01fda43c: 07000014 b        #0x1fda458 ; 
01fda440: 281140f9 ldr      x8, [x9, #0x20]
01fda444: e00317aa mov      x0, x23
01fda448: 086140f9 ldr      x8, [x8, #0xc0]
01fda44c: 022d40f9 ldr      x2, [x8, #0x58]
01fda450: 480440f9 ldr      x8, [x2, #8]
01fda454: 00013fd6 blr      x8
01fda458: 081b40b9 ldr      w8, [x24, #0x18]
01fda45c: f6031caa mov      x22, x28
01fda460: 09050051 sub      w9, w8, #1
01fda464: 9f03096b cmp      w28, w9
01fda468: cbf9ff54 b.lt     #0x1fda3a0
01fda46c: c88d01d0 adrp     x8, #0x5194000
01fda470: 086d46f9 ldr      x8, [x8, #0xcd8]
01fda474: e11a40b9 ldr      w1, [x23, #0x18]
01fda478: 000140f9 ldr      x0, [x8]
01fda47c: bd5bbf97 bl       #0xfb1370 ; 
01fda480: fb1a40b9 ldr      w27, [x23, #0x18]
01fda484: f80300aa mov      x24, x0
01fda488: 7f070071 cmp      w27, #1
01fda48c: eb090054 b.lt     #0x1fda5c8
01fda490: 3c8e01d0 adrp     x28, #0x51a0000
01fda494: 338e01b0 adrp     x19, #0x519f000
01fda498: 9cff42f9 ldr      x28, [x28, #0x5f8]
01fda49c: 73aa45f9 ldr      x19, [x19, #0xb50]
01fda4a0: f9031faa mov      x25, xzr
01fda4a4: 820340f9 ldr      x2, [x28]
01fda4a8: e00317aa mov      x0, x23
01fda4ac: e103192a mov      w1, w25
01fda4b0: cfcf2794 bl       #0x29ce3ec ; System.Collections.Generic.List<object>$$get_Item
01fda4b4: 350a00b4 cbz      x21, #0x1fda5f8
01fda4b8: a80e40f9 ldr      x8, [x21, #0x18]
01fda4bc: 14050071 subs     w20, w8, #1
01fda4c0: cb020054 b.lt     #0x1fda518
01fda4c4: c8090034 cbz      w8, #0x1fda5fc
01fda4c8: fa0300aa mov      x26, x0
01fda4cc: f6031f2a mov      w22, wzr
01fda4d0: bdce368b add      x29, x21, w22, sxtw #3
01fda4d4: a00f42f8 ldr      x0, [x29, #0x20]!
01fda4d8: 000900b4 cbz      x0, #0x1fda5f8
01fda4dc: e1031faa mov      x1, xzr
01fda4e0: 94637494 bl       #0x3cf3330 ; UnityEngine.Object$$get_name
01fda4e4: e10300aa mov      x1, x0
01fda4e8: a2008052 mov      w2, #5
01fda4ec: e0031aaa mov      x0, x26
01fda4f0: e3031faa mov      x3, xzr
01fda4f4: 0faff497 bl       #0x1d06130 ; System.String$$Equals
01fda4f8: 40010037 tbnz     w0, #0, #0x1fda520
01fda4fc: 9f02166b cmp      w20, w22
01fda500: c0000054 b.eq     #0x1fda518
01fda504: a81a40b9 ldr      w8, [x21, #0x18]
01fda508: d6060011 add      w22, w22, #1
01fda50c: df02086b cmp      w22, w8
01fda510: 03feff54 b.lo     #0x1fda4d0
01fda514: 3a000014 b        #0x1fda5fc ; 
01fda518: fa031faa mov      x26, xzr
01fda51c: 11000014 b        #0x1fda560 ; 
01fda520: 489001b0 adrp     x8, #0x51e3000
01fda524: 08f140f9 ldr      x8, [x8, #0x1e0]
01fda528: 000140f9 ldr      x0, [x8]
01fda52c: bb5bbf97 bl       #0xfb1418 ; 
01fda530: 400600b4 cbz      x0, #0x1fda5f8
01fda534: e10f40f9 ldr      x1, [sp, #0x18]
01fda538: e2031faa mov      x2, xzr
01fda53c: fa0300aa mov      x26, x0
01fda540: e8dc5494 bl       #0x35118e0 ; UnityEngine.Material$$.ctor
01fda544: a81a40b9 ldr      w8, [x21, #0x18]
01fda548: df02086b cmp      w22, w8
01fda54c: 82050054 b.hs     #0x1fda5fc
01fda550: a10340f9 ldr      x1, [x29]
01fda554: e0031aaa mov      x0, x26
01fda558: e2031faa mov      x2, xzr
01fda55c: c9dd5494 bl       #0x3511c80 ; UnityEngine.Material$$set_mainTexture
01fda560: 600240f9 ldr      x0, [x19]
01fda564: 08e040b9 ldr      w8, [x0, #0xe0]
01fda568: 48000035 cbnz     w8, #0x1fda570
01fda56c: a65bbf97 bl       #0xfb1404 ; 
01fda570: e0031aaa mov      x0, x26
01fda574: e1031faa mov      x1, xzr
01fda578: e2031faa mov      x2, xzr
01fda57c: 77bb7494 bl       #0x3d09358 ; UnityEngine.Object$$op_Inequality
01fda580: 00040036 tbz      w0, #0, #0x1fda600
01fda584: b80300b4 cbz      x24, #0x1fda5f8
01fda588: da0000b4 cbz      x26, #0x1fda5a0
01fda58c: 080340f9 ldr      x8, [x24]
01fda590: e0031aaa mov      x0, x26
01fda594: 012140f9 ldr      x1, [x8, #0x40]
01fda598: 9c5bbf97 bl       #0xfb1408 ; 
01fda59c: 800500b4 cbz      x0, #0x1fda64c
01fda5a0: 081b40b9 ldr      w8, [x24, #0x18]
01fda5a4: 3f0308eb cmp      x25, x8
01fda5a8: a2020054 b.hs     #0x1fda5fc
01fda5ac: 000f198b add      x0, x24, x25, lsl #3
01fda5b0: 1a0c02f8 str      x26, [x0, #0x20]!
01fda5b4: e1031aaa mov      x1, x26
01fda5b8: 3d5bbf97 bl       #0xfb12ac ; 
01fda5bc: 39070091 add      x25, x25, #1
01fda5c0: 3f031beb cmp      x25, x27
01fda5c4: 01f7ff54 b.ne     #0x1fda4a4
01fda5c8: e81740b9 ldr      w8, [sp, #0x14]
01fda5cc: e00740f9 ldr      x0, [sp, #8]
01fda5d0: e10318aa mov      x1, x24
01fda5d4: fd7b47a9 ldp      x29, x30, [sp, #0x70]
01fda5d8: f44f46a9 ldp      x20, x19, [sp, #0x60]
01fda5dc: f65745a9 ldp      x22, x21, [sp, #0x50]
01fda5e0: f85f44a9 ldp      x24, x23, [sp, #0x40]
01fda5e4: fa6743a9 ldp      x26, x25, [sp, #0x30]
01fda5e8: fc6f42a9 ldp      x28, x27, [sp, #0x20]
01fda5ec: 02010012 and      w2, w8, #1
01fda5f0: ff030291 add      sp, sp, #0x80
01fda5f4: e2feff17 b        #0x1fda17c ; Spine.Unity.SpineAtlasAsset$$CreateRuntimeInstance
01fda5f8: 8c5bbf97 bl       #0xfb1428 ; 
01fda5fc: 8d5bbf97 bl       #0xfb1430 ; 
01fda600: a08f01f0 adrp     x0, #0x51d1000
01fda604: 000443f9 ldr      x0, [x0, #0x608]
01fda608: 435bbf97 bl       #0xfb1314 ; 
01fda60c: 835bbf97 bl       #0xfb1418 ; 
01fda610: f30300aa mov      x19, x0
01fda614: 50b8b397 bl       #0xcc8754 ; 
01fda618: 208e01f0 adrp     x0, #0x51a1000
01fda61c: 004445f9 ldr      x0, [x0, #0xa88]
01fda620: 3d5bbf97 bl       #0xfb1314 ; 
01fda624: e10300aa mov      x1, x0
01fda628: e00313aa mov      x0, x19
01fda62c: e2031faa mov      x2, xzr
01fda630: 5fabff97 bl       #0x1fc53ac ; System.ArgumentException$$.ctor
01fda634: 008f01f0 adrp     x0, #0x51bd000
01fda638: 008042f9 ldr      x0, [x0, #0x500]
01fda63c: 365bbf97 bl       #0xfb1314 ; 
01fda640: e10300aa mov      x1, x0
01fda644: e00313aa mov      x0, x19
01fda648: 6a5bbf97 bl       #0xfb13f0 ; 
01fda64c: 805bbf97 bl       #0xfb144c ; 
01fda650: e1031faa mov      x1, xzr
01fda654: 675bbf97 bl       #0xfb13f0 ; 
