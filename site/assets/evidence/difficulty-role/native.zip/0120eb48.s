# Royal.Scenes.Home.Ui.Dialogs.MissionPursuit.Scripts.MissionPursuitConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
0120eb48: f60f1df8 str      x22, [sp, #-0x30]!
0120eb4c: f55301a9 stp      x21, x20, [sp, #0x10]
0120eb50: f37b02a9 stp      x19, x30, [sp, #0x20]
0120eb54: 541b02b0 adrp     x20, #0x5577000
0120eb58: 889e5e39 ldrb     w8, [x20, #0x7a7]
0120eb5c: f30300aa mov      x19, x0
0120eb60: c8030037 tbnz     w8, #0, #0x120ebd8
0120eb64: a0000290 adrp     x0, #0x5222000
0120eb68: 00ec42f9 ldr      x0, [x0, #0x5d8]
0120eb6c: e589f697 bl       #0xfb1300 ; 
0120eb70: 400002b0 adrp     x0, #0x5217000
0120eb74: 007443f9 ldr      x0, [x0, #0x6e8]
0120eb78: e289f697 bl       #0xfb1300 ; 
0120eb7c: a0fc01b0 adrp     x0, #0x51a3000
0120eb80: 00a445f9 ldr      x0, [x0, #0xb48]
0120eb84: df89f697 bl       #0xfb1300 ; 
0120eb88: a0ff01d0 adrp     x0, #0x5204000
0120eb8c: 00bc47f9 ldr      x0, [x0, #0xf78]
0120eb90: dc89f697 bl       #0xfb1300 ; 
0120eb94: 400002f0 adrp     x0, #0x5219000
0120eb98: 009843f9 ldr      x0, [x0, #0x730]
0120eb9c: d989f697 bl       #0xfb1300 ; 
0120eba0: 400102d0 adrp     x0, #0x5238000
0120eba4: 009446f9 ldr      x0, [x0, #0xd28]
0120eba8: d689f697 bl       #0xfb1300 ; 
0120ebac: 20fd0190 adrp     x0, #0x51b2000
0120ebb0: 00e847f9 ldr      x0, [x0, #0xfd0]
0120ebb4: d389f697 bl       #0xfb1300 ; 
0120ebb8: 000002b0 adrp     x0, #0x520f000
0120ebbc: 003c47f9 ldr      x0, [x0, #0xe78]
0120ebc0: d089f697 bl       #0xfb1300 ; 
0120ebc4: a0fc01f0 adrp     x0, #0x51a5000
0120ebc8: 003443f9 ldr      x0, [x0, #0x668]
0120ebcc: cd89f697 bl       #0xfb1300 ; 
0120ebd0: 28008052 mov      w8, #1
0120ebd4: 889e1e39 strb     w8, [x20, #0x7a7]
0120ebd8: 680a40f9 ldr      x8, [x19, #0x10]
0120ebdc: 680e00b4 cbz      x8, #0x120eda8
0120ebe0: 081140f9 ldr      x8, [x8, #0x20]
0120ebe4: 280e00b4 cbz      x8, #0x120eda8
0120ebe8: 161540f9 ldr      x22, [x8, #0x28]
0120ebec: f60d00b4 cbz      x22, #0x120eda8
0120ebf0: c00a40f9 ldr      x0, [x22, #0x10]
0120ebf4: 540002f0 adrp     x20, #0x5219000
0120ebf8: b5000290 adrp     x21, #0x5222000
0120ebfc: 949a43f9 ldr      x20, [x20, #0x730]
0120ec00: b5ee42f9 ldr      x21, [x21, #0x5d8]
0120ec04: e1031faa mov      x1, xzr
0120ec08: e5e12b94 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0120ec0c: 60050036 tbz      w0, #0, #0x120ecb8
0120ec10: 28fd0190 adrp     x8, #0x51b2000
0120ec14: 490102d0 adrp     x9, #0x5238000
0120ec18: 08e947f9 ldr      x8, [x8, #0xfd0]
0120ec1c: 299546f9 ldr      x9, [x9, #0xd28]
0120ec20: 000140f9 ldr      x0, [x8]
0120ec24: 210140f9 ldr      x1, [x9]
0120ec28: 2ecc4e94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
0120ec2c: e00b00b4 cbz      x0, #0x120eda8
0120ec30: e1031faa mov      x1, xzr
0120ec34: 57d4ab94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0120ec38: 810240f9 ldr      x1, [x20]
0120ec3c: dbb54c94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0120ec40: e10300aa mov      x1, x0
0120ec44: e00313aa mov      x0, x19
0120ec48: 010c02f8 str      x1, [x0, #0x20]!
0120ec4c: 9889f697 bl       #0xfb12ac ; 
0120ec50: b40240f9 ldr      x20, [x21]
0120ec54: 881e40f9 ldr      x8, [x20, #0x38]
0120ec58: 000140f9 ldr      x0, [x8]
0120ec5c: 08c84439 ldrb     w8, [x0, #0x132]
0120ec60: 48000037 tbnz     w8, #0, #0x120ec68
0120ec64: e0c8f597 bl       #0xf80fe4 ; 
0120ec68: 08e040b9 ldr      w8, [x0, #0xe0]
0120ec6c: 48000035 cbnz     w8, #0x120ec74
0120ec70: e589f697 bl       #0xfb1404 ; 
0120ec74: 881e40f9 ldr      x8, [x20, #0x38]
0120ec78: b4fc01f0 adrp     x20, #0x51a5000
0120ec7c: 000140f9 ldr      x0, [x8]
0120ec80: 08c84439 ldrb     w8, [x0, #0x132]
0120ec84: 943643f9 ldr      x20, [x20, #0x668]
0120ec88: 48000037 tbnz     w8, #0, #0x120ec90
0120ec8c: d6c8f597 bl       #0xf80fe4 ; 
0120ec90: 085c40f9 ldr      x8, [x0, #0xb8]
0120ec94: 820240f9 ldr      x2, [x20]
0120ec98: e00313aa mov      x0, x19
0120ec9c: f37b42a9 ldp      x19, x30, [sp, #0x20]
0120eca0: 030140f9 ldr      x3, [x8]
0120eca4: f55341a9 ldp      x21, x20, [sp, #0x10]
0120eca8: 81078052 mov      w1, #0x3c
0120ecac: e4031faa mov      x4, xzr
0120ecb0: f60743f8 ldr      x22, [sp], #0x30
0120ecb4: 1bc75714 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0120ecb8: c00a40f9 ldr      x0, [x22, #0x10]
0120ecbc: 810240f9 ldr      x1, [x20]
0120ecc0: bab54c94 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0120ecc4: f40313aa mov      x20, x19
0120ecc8: 800e02f8 str      x0, [x20, #0x20]!
0120eccc: e10300aa mov      x1, x0
0120ecd0: e00314aa mov      x0, x20
0120ecd4: 7689f697 bl       #0xfb12ac ; 
0120ecd8: 88025ff8 ldur     x8, [x20, #-0x10]
0120ecdc: 680600b4 cbz      x8, #0x120eda8
0120ece0: 081140f9 ldr      x8, [x8, #0x20]
0120ece4: 280600b4 cbz      x8, #0x120eda8
0120ece8: 081940f9 ldr      x8, [x8, #0x30]
0120ecec: e80500b4 cbz      x8, #0x120eda8
0120ecf0: 890240f9 ldr      x9, [x20]
0120ecf4: a90500b4 cbz      x9, #0x120eda8
0120ecf8: 081140b9 ldr      w8, [x8, #0x10]
0120ecfc: aaff01d0 adrp     x10, #0x5204000
0120ed00: 4abd47f9 ldr      x10, [x10, #0xf78]
0120ed04: 140002b0 adrp     x20, #0x520f000
0120ed08: 281100b9 str      w8, [x9, #0x10]
0120ed0c: e1330091 add      x1, sp, #0xc
0120ed10: 400140f9 ldr      x0, [x10]
0120ed14: 943e47f9 ldr      x20, [x20, #0xe78]
0120ed18: e80f00b9 str      w8, [sp, #0xc]
0120ed1c: bc89f697 bl       #0xfb140c ; 
0120ed20: 880240f9 ldr      x8, [x20]
0120ed24: e10300aa mov      x1, x0
0120ed28: e2031faa mov      x2, xzr
0120ed2c: e00308aa mov      x0, x8
0120ed30: aabc2b94 bl       #0x1cfdfd8 ; System.String$$Format
0120ed34: b50240f9 ldr      x21, [x21]
0120ed38: f40300aa mov      x20, x0
0120ed3c: a81e40f9 ldr      x8, [x21, #0x38]
0120ed40: 080140f9 ldr      x8, [x8]
0120ed44: 09c94439 ldrb     w9, [x8, #0x132]
0120ed48: 89000037 tbnz     w9, #0, #0x120ed58
0120ed4c: e00308aa mov      x0, x8
0120ed50: a5c8f597 bl       #0xf80fe4 ; 
0120ed54: e80300aa mov      x8, x0
0120ed58: 09e140b9 ldr      w9, [x8, #0xe0]
0120ed5c: 69000035 cbnz     w9, #0x120ed68
0120ed60: e00308aa mov      x0, x8
0120ed64: a889f697 bl       #0xfb1404 ; 
0120ed68: a81e40f9 ldr      x8, [x21, #0x38]
0120ed6c: 000140f9 ldr      x0, [x8]
0120ed70: 08c84439 ldrb     w8, [x0, #0x132]
0120ed74: 48000037 tbnz     w8, #0, #0x120ed7c
0120ed78: 9bc8f597 bl       #0xf80fe4 ; 
0120ed7c: 085c40f9 ldr      x8, [x0, #0xb8]
0120ed80: 81078052 mov      w1, #0x3c
0120ed84: e00313aa mov      x0, x19
0120ed88: e20314aa mov      x2, x20
0120ed8c: 030140f9 ldr      x3, [x8]
0120ed90: e4031faa mov      x4, xzr
0120ed94: e3c65794 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
0120ed98: f37b42a9 ldp      x19, x30, [sp, #0x20]
0120ed9c: f55341a9 ldp      x21, x20, [sp, #0x10]
0120eda0: f60743f8 ldr      x22, [sp], #0x30
0120eda4: c0035fd6 ret      
0120eda8: a089f697 bl       #0xfb1428 ; 
