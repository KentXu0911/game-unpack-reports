# Royal.Scenes.Home.Ui.Dialogs.PuzzleBreak.Scripts.PuzzleBreakConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
03755324: f60f1df8 str      x22, [sp, #-0x30]!
03755328: f55301a9 stp      x21, x20, [sp, #0x10]
0375532c: f37b02a9 stp      x19, x30, [sp, #0x20]
03755330: 94f100f0 adrp     x20, #0x5588000
03755334: 882a6839 ldrb     w8, [x20, #0xa0a]
03755338: f30300aa mov      x19, x0
0375533c: c8030037 tbnz     w8, #0, #0x37553b4
03755340: 60d600b0 adrp     x0, #0x5222000
03755344: 00ec42f9 ldr      x0, [x0, #0x5d8]
03755348: ee6f6197 bl       #0xfb1300 ; 
0375534c: c0d50090 adrp     x0, #0x520d000
03755350: 00b042f9 ldr      x0, [x0, #0x560]
03755354: eb6f6197 bl       #0xfb1300 ; 
03755358: c0d300d0 adrp     x0, #0x51cf000
0375535c: 009842f9 ldr      x0, [x0, #0x530]
03755360: e86f6197 bl       #0xfb1300 ; 
03755364: 60d500f0 adrp     x0, #0x5204000
03755368: 00bc47f9 ldr      x0, [x0, #0xf78]
0375536c: e56f6197 bl       #0xfb1300 ; 
03755370: 00d400b0 adrp     x0, #0x51d6000
03755374: 002c44f9 ldr      x0, [x0, #0x858]
03755378: e26f6197 bl       #0xfb1300 ; 
0375537c: 00d700f0 adrp     x0, #0x5238000
03755380: 009446f9 ldr      x0, [x0, #0xd28]
03755384: df6f6197 bl       #0xfb1300 ; 
03755388: 40d600f0 adrp     x0, #0x5220000
0375538c: 000443f9 ldr      x0, [x0, #0x608]
03755390: dc6f6197 bl       #0xfb1300 ; 
03755394: 00d60090 adrp     x0, #0x5215000
03755398: 000846f9 ldr      x0, [x0, #0xc10]
0375539c: d96f6197 bl       #0xfb1300 ; 
037553a0: 20d700f0 adrp     x0, #0x523c000
037553a4: 007c41f9 ldr      x0, [x0, #0x2f8]
037553a8: d66f6197 bl       #0xfb1300 ; 
037553ac: 28008052 mov      w8, #1
037553b0: 882a2839 strb     w8, [x20, #0xa0a]
037553b4: 680e40f9 ldr      x8, [x19, #0x18]
037553b8: 680e00b4 cbz      x8, #0x3755584
037553bc: 081540f9 ldr      x8, [x8, #0x28]
037553c0: 280e00b4 cbz      x8, #0x3755584
037553c4: 161d40f9 ldr      x22, [x8, #0x38]
037553c8: f60d00b4 cbz      x22, #0x3755584
037553cc: c00a40f9 ldr      x0, [x22, #0x10]
037553d0: 14d400b0 adrp     x20, #0x51d6000
037553d4: 75d600b0 adrp     x21, #0x5222000
037553d8: 942e44f9 ldr      x20, [x20, #0x858]
037553dc: b5ee42f9 ldr      x21, [x21, #0x5d8]
037553e0: e1031faa mov      x1, xzr
037553e4: eec79697 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
037553e8: 60050036 tbz      w0, #0, #0x3755494
037553ec: 28d700f0 adrp     x8, #0x523c000
037553f0: 09d700f0 adrp     x9, #0x5238000
037553f4: 087d41f9 ldr      x8, [x8, #0x2f8]
037553f8: 299546f9 ldr      x9, [x9, #0xd28]
037553fc: 000140f9 ldr      x0, [x8]
03755400: 210140f9 ldr      x1, [x9]
03755404: 37b2b997 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03755408: e00b00b4 cbz      x0, #0x3755584
0375540c: e1031faa mov      x1, xzr
03755410: 60ba1694 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03755414: 810240f9 ldr      x1, [x20]
03755418: e49bb797 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0375541c: e10300aa mov      x1, x0
03755420: e00313aa mov      x0, x19
03755424: 018c02f8 str      x1, [x0, #0x28]!
03755428: a16f6197 bl       #0xfb12ac ; 
0375542c: b40240f9 ldr      x20, [x21]
03755430: 881e40f9 ldr      x8, [x20, #0x38]
03755434: 000140f9 ldr      x0, [x8]
03755438: 08c84439 ldrb     w8, [x0, #0x132]
0375543c: 48000037 tbnz     w8, #0, #0x3755444
03755440: e9ae6097 bl       #0xf80fe4 ; 
03755444: 08e040b9 ldr      w8, [x0, #0xe0]
03755448: 48000035 cbnz     w8, #0x3755450
0375544c: ee6f6197 bl       #0xfb1404 ; 
03755450: 881e40f9 ldr      x8, [x20, #0x38]
03755454: 14d60090 adrp     x20, #0x5215000
03755458: 000140f9 ldr      x0, [x8]
0375545c: 08c84439 ldrb     w8, [x0, #0x132]
03755460: 940a46f9 ldr      x20, [x20, #0xc10]
03755464: 48000037 tbnz     w8, #0, #0x375546c
03755468: dfae6097 bl       #0xf80fe4 ; 
0375546c: 085c40f9 ldr      x8, [x0, #0xb8]
03755470: 820240f9 ldr      x2, [x20]
03755474: e00313aa mov      x0, x19
03755478: f37b42a9 ldp      x19, x30, [sp, #0x20]
0375547c: 030140f9 ldr      x3, [x8]
03755480: f55341a9 ldp      x21, x20, [sp, #0x10]
03755484: 61098052 mov      w1, #0x4b
03755488: e4031faa mov      x4, xzr
0375548c: f60743f8 ldr      x22, [sp], #0x30
03755490: 24adc217 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03755494: c00a40f9 ldr      x0, [x22, #0x10]
03755498: 810240f9 ldr      x1, [x20]
0375549c: c39bb797 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
037554a0: f40313aa mov      x20, x19
037554a4: 808e02f8 str      x0, [x20, #0x28]!
037554a8: e10300aa mov      x1, x0
037554ac: e00314aa mov      x0, x20
037554b0: 7f6f6197 bl       #0xfb12ac ; 
037554b4: 88025ff8 ldur     x8, [x20, #-0x10]
037554b8: 680600b4 cbz      x8, #0x3755584
037554bc: 081540f9 ldr      x8, [x8, #0x28]
037554c0: 280600b4 cbz      x8, #0x3755584
037554c4: 082140f9 ldr      x8, [x8, #0x40]
037554c8: e80500b4 cbz      x8, #0x3755584
037554cc: 890240f9 ldr      x9, [x20]
037554d0: a90500b4 cbz      x9, #0x3755584
037554d4: 081140b9 ldr      w8, [x8, #0x10]
037554d8: 6ad500f0 adrp     x10, #0x5204000
037554dc: 4abd47f9 ldr      x10, [x10, #0xf78]
037554e0: 54d600f0 adrp     x20, #0x5220000
037554e4: 281100b9 str      w8, [x9, #0x10]
037554e8: e1330091 add      x1, sp, #0xc
037554ec: 400140f9 ldr      x0, [x10]
037554f0: 940643f9 ldr      x20, [x20, #0x608]
037554f4: e80f00b9 str      w8, [sp, #0xc]
037554f8: c56f6197 bl       #0xfb140c ; 
037554fc: 880240f9 ldr      x8, [x20]
03755500: e10300aa mov      x1, x0
03755504: e2031faa mov      x2, xzr
03755508: e00308aa mov      x0, x8
0375550c: b3a29697 bl       #0x1cfdfd8 ; System.String$$Format
03755510: b50240f9 ldr      x21, [x21]
03755514: f40300aa mov      x20, x0
03755518: a81e40f9 ldr      x8, [x21, #0x38]
0375551c: 080140f9 ldr      x8, [x8]
03755520: 09c94439 ldrb     w9, [x8, #0x132]
03755524: 89000037 tbnz     w9, #0, #0x3755534
03755528: e00308aa mov      x0, x8
0375552c: aeae6097 bl       #0xf80fe4 ; 
03755530: e80300aa mov      x8, x0
03755534: 09e140b9 ldr      w9, [x8, #0xe0]
03755538: 69000035 cbnz     w9, #0x3755544
0375553c: e00308aa mov      x0, x8
03755540: b16f6197 bl       #0xfb1404 ; 
03755544: a81e40f9 ldr      x8, [x21, #0x38]
03755548: 000140f9 ldr      x0, [x8]
0375554c: 08c84439 ldrb     w8, [x0, #0x132]
03755550: 48000037 tbnz     w8, #0, #0x3755558
03755554: a4ae6097 bl       #0xf80fe4 ; 
03755558: 085c40f9 ldr      x8, [x0, #0xb8]
0375555c: 61098052 mov      w1, #0x4b
03755560: e00313aa mov      x0, x19
03755564: e20314aa mov      x2, x20
03755568: 030140f9 ldr      x3, [x8]
0375556c: e4031faa mov      x4, xzr
03755570: ecacc297 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03755574: f37b42a9 ldp      x19, x30, [sp, #0x20]
03755578: f55341a9 ldp      x21, x20, [sp, #0x10]
0375557c: f60743f8 ldr      x22, [sp], #0x30
03755580: c0035fd6 ret      
03755584: a96f6197 bl       #0xfb1428 ; 
