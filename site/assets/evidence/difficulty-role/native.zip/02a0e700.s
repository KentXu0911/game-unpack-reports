# Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
# Linear metadata span, not a recovered full CFG.
02a0e700: f80f1cf8 str      x24, [sp, #-0x40]!
02a0e704: f75b01a9 stp      x23, x22, [sp, #0x10]
02a0e708: f55302a9 stp      x21, x20, [sp, #0x20]
02a0e70c: f37b03a9 stp      x19, x30, [sp, #0x30]
02a0e710: 985b01f0 adrp     x24, #0x5581000
02a0e714: 973f01d0 adrp     x23, #0x5200000
02a0e718: 963f01b0 adrp     x22, #0x51ff000
02a0e71c: b5400190 adrp     x21, #0x5222000
02a0e720: 084b7539 ldrb     w8, [x24, #0xd52]
02a0e724: f77640f9 ldr      x23, [x23, #0xe8]
02a0e728: d64e46f9 ldr      x22, [x22, #0xc98]
02a0e72c: b5ee42f9 ldr      x21, [x21, #0x5d8]
02a0e730: f30301aa mov      x19, x1
02a0e734: f40300aa mov      x20, x0
02a0e738: e8010037 tbnz     w8, #0, #0x2a0e774
02a0e73c: a0400190 adrp     x0, #0x5222000
02a0e740: 00ec42f9 ldr      x0, [x0, #0x5d8]
02a0e744: ef8a9697 bl       #0xfb1300 ; 
02a0e748: 803f01d0 adrp     x0, #0x5200000
02a0e74c: 007440f9 ldr      x0, [x0, #0xe8]
02a0e750: ec8a9697 bl       #0xfb1300 ; 
02a0e754: 603d01f0 adrp     x0, #0x51bd000
02a0e758: 008044f9 ldr      x0, [x0, #0x900]
02a0e75c: e98a9697 bl       #0xfb1300 ; 
02a0e760: 803f01b0 adrp     x0, #0x51ff000
02a0e764: 004c46f9 ldr      x0, [x0, #0xc98]
02a0e768: e68a9697 bl       #0xfb1300 ; 
02a0e76c: 28008052 mov      w8, #1
02a0e770: 084b3539 strb     w8, [x24, #0xd52]
02a0e774: e00240f9 ldr      x0, [x23]
02a0e778: e1230091 add      x1, sp, #8
02a0e77c: f30700f9 str      x19, [sp, #8]
02a0e780: 238b9697 bl       #0xfb140c ; 
02a0e784: c80240f9 ldr      x8, [x22]
02a0e788: e10300aa mov      x1, x0
02a0e78c: e2031faa mov      x2, xzr
02a0e790: e00308aa mov      x0, x8
02a0e794: 11becb97 bl       #0x1cfdfd8 ; System.String$$Format
02a0e798: b60240f9 ldr      x22, [x21]
02a0e79c: f50300aa mov      x21, x0
02a0e7a0: c81e40f9 ldr      x8, [x22, #0x38]
02a0e7a4: 080140f9 ldr      x8, [x8]
02a0e7a8: 09c94439 ldrb     w9, [x8, #0x132]
02a0e7ac: 89000037 tbnz     w9, #0, #0x2a0e7bc
02a0e7b0: e00308aa mov      x0, x8
02a0e7b4: 0cca9597 bl       #0xf80fe4 ; 
02a0e7b8: e80300aa mov      x8, x0
02a0e7bc: 09e140b9 ldr      w9, [x8, #0xe0]
02a0e7c0: 69000035 cbnz     w9, #0x2a0e7cc
02a0e7c4: e00308aa mov      x0, x8
02a0e7c8: 0f8b9697 bl       #0xfb1404 ; 
02a0e7cc: c81e40f9 ldr      x8, [x22, #0x38]
02a0e7d0: 763d01f0 adrp     x22, #0x51bd000
02a0e7d4: 000140f9 ldr      x0, [x8]
02a0e7d8: 08c84439 ldrb     w8, [x0, #0x132]
02a0e7dc: d68244f9 ldr      x22, [x22, #0x900]
02a0e7e0: 48000037 tbnz     w8, #0, #0x2a0e7e8
02a0e7e4: 00ca9597 bl       #0xf80fe4 ; 
02a0e7e8: 085c40f9 ldr      x8, [x0, #0xb8]
02a0e7ec: 41018052 mov      w1, #0xa
02a0e7f0: e00314aa mov      x0, x20
02a0e7f4: e20315aa mov      x2, x21
02a0e7f8: 030140f9 ldr      x3, [x8]
02a0e7fc: e4031faa mov      x4, xzr
02a0e800: 48c8f797 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02a0e804: 935a00f9 str      x19, [x20, #0xb0]
02a0e808: c00240f9 ldr      x0, [x22]
02a0e80c: e10313aa mov      x1, x19
02a0e810: e2031faa mov      x2, xzr
02a0e814: 46861194 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
02a0e818: f37b43a9 ldp      x19, x30, [sp, #0x30]
02a0e81c: f55342a9 ldp      x21, x20, [sp, #0x20]
02a0e820: f75b41a9 ldp      x23, x22, [sp, #0x10]
02a0e824: f80744f8 ldr      x24, [sp], #0x40
02a0e828: c0035fd6 ret      
