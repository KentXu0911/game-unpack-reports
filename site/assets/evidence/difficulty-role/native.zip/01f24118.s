# Royal.Player.Context.Units.MagicCauldronManager$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
01f24118: f60f1df8 str      x22, [sp, #-0x30]!
01f2411c: f55301a9 stp      x21, x20, [sp, #0x10]
01f24120: f37b02a9 stp      x19, x30, [sp, #0x20]
01f24124: d4b20190 adrp     x20, #0x557c000
01f24128: 889a6039 ldrb     w8, [x20, #0x826]
01f2412c: f30300aa mov      x19, x0
01f24130: c8030037 tbnz     w8, #0, #0x1f241a8
01f24134: e09701d0 adrp     x0, #0x5222000
01f24138: 00ec42f9 ldr      x0, [x0, #0x5d8]
01f2413c: 7134c297 bl       #0xfb1300 ; 
01f24140: e09501b0 adrp     x0, #0x51e1000
01f24144: 006c43f9 ldr      x0, [x0, #0x6d8]
01f24148: 6e34c297 bl       #0xfb1300 ; 
01f2414c: 809501d0 adrp     x0, #0x51d6000
01f24150: 00b443f9 ldr      x0, [x0, #0x768]
01f24154: 6b34c297 bl       #0xfb1300 ; 
01f24158: 00970190 adrp     x0, #0x5204000
01f2415c: 00bc47f9 ldr      x0, [x0, #0xf78]
01f24160: 6834c297 bl       #0xfb1300 ; 
01f24164: 20950190 adrp     x0, #0x51c8000
01f24168: 004040f9 ldr      x0, [x0, #0x80]
01f2416c: 6534c297 bl       #0xfb1300 ; 
01f24170: a0980190 adrp     x0, #0x5238000
01f24174: 009446f9 ldr      x0, [x0, #0xd28]
01f24178: 6234c297 bl       #0xfb1300 ; 
01f2417c: 009801f0 adrp     x0, #0x5227000
01f24180: 007c45f9 ldr      x0, [x0, #0xaf8]
01f24184: 5f34c297 bl       #0xfb1300 ; 
01f24188: 609501b0 adrp     x0, #0x51d1000
01f2418c: 000c44f9 ldr      x0, [x0, #0x818]
01f24190: 5c34c297 bl       #0xfb1300 ; 
01f24194: 80970190 adrp     x0, #0x5214000
01f24198: 009045f9 ldr      x0, [x0, #0xb20]
01f2419c: 5934c297 bl       #0xfb1300 ; 
01f241a0: 28008052 mov      w8, #1
01f241a4: 889a2039 strb     w8, [x20, #0x826]
01f241a8: 683a40f9 ldr      x8, [x19, #0x70]
01f241ac: e80d00b4 cbz      x8, #0x1f24368
01f241b0: 162540f9 ldr      x22, [x8, #0x48]
01f241b4: b60d00b4 cbz      x22, #0x1f24368
01f241b8: c00a40f9 ldr      x0, [x22, #0x10]
01f241bc: 34950190 adrp     x20, #0x51c8000
01f241c0: f59701d0 adrp     x21, #0x5222000
01f241c4: 944240f9 ldr      x20, [x20, #0x80]
01f241c8: b5ee42f9 ldr      x21, [x21, #0x5d8]
01f241cc: e1031faa mov      x1, xzr
01f241d0: 738cf797 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
01f241d4: 60050036 tbz      w0, #0, #0x1f24280
01f241d8: 089801f0 adrp     x8, #0x5227000
01f241dc: a9980190 adrp     x9, #0x5238000
01f241e0: 087d45f9 ldr      x8, [x8, #0xaf8]
01f241e4: 299546f9 ldr      x9, [x9, #0xd28]
01f241e8: 000140f9 ldr      x0, [x8]
01f241ec: 210140f9 ldr      x1, [x9]
01f241f0: bc761a94 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01f241f4: a00b00b4 cbz      x0, #0x1f24368
01f241f8: e1031faa mov      x1, xzr
01f241fc: e57e7794 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01f24200: 810240f9 ldr      x1, [x20]
01f24204: 69601894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f24208: e10300aa mov      x1, x0
01f2420c: e00313aa mov      x0, x19
01f24210: 010c06f8 str      x1, [x0, #0x60]!
01f24214: 2634c297 bl       #0xfb12ac ; 
01f24218: b40240f9 ldr      x20, [x21]
01f2421c: 881e40f9 ldr      x8, [x20, #0x38]
01f24220: 000140f9 ldr      x0, [x8]
01f24224: 08c84439 ldrb     w8, [x0, #0x132]
01f24228: 48000037 tbnz     w8, #0, #0x1f24230
01f2422c: 6e73c197 bl       #0xf80fe4 ; 
01f24230: 08e040b9 ldr      w8, [x0, #0xe0]
01f24234: 48000035 cbnz     w8, #0x1f2423c
01f24238: 7334c297 bl       #0xfb1404 ; 
01f2423c: 881e40f9 ldr      x8, [x20, #0x38]
01f24240: 749501b0 adrp     x20, #0x51d1000
01f24244: 000140f9 ldr      x0, [x8]
01f24248: 08c84439 ldrb     w8, [x0, #0x132]
01f2424c: 940e44f9 ldr      x20, [x20, #0x818]
01f24250: 48000037 tbnz     w8, #0, #0x1f24258
01f24254: 6473c197 bl       #0xf80fe4 ; 
01f24258: 085c40f9 ldr      x8, [x0, #0xb8]
01f2425c: 820240f9 ldr      x2, [x20]
01f24260: e00313aa mov      x0, x19
01f24264: f37b42a9 ldp      x19, x30, [sp, #0x20]
01f24268: 030140f9 ldr      x3, [x8]
01f2426c: f55341a9 ldp      x21, x20, [sp, #0x10]
01f24270: a1058052 mov      w1, #0x2d
01f24274: e4031faa mov      x4, xzr
01f24278: f60743f8 ldr      x22, [sp], #0x30
01f2427c: a9712314 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01f24280: c00a40f9 ldr      x0, [x22, #0x10]
01f24284: 810240f9 ldr      x1, [x20]
01f24288: 48601894 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
01f2428c: f40313aa mov      x20, x19
01f24290: 800e06f8 str      x0, [x20, #0x60]!
01f24294: e10300aa mov      x1, x0
01f24298: e00314aa mov      x0, x20
01f2429c: 0434c297 bl       #0xfb12ac ; 
01f242a0: 880a40f9 ldr      x8, [x20, #0x10]
01f242a4: 280600b4 cbz      x8, #0x1f24368
01f242a8: 082940f9 ldr      x8, [x8, #0x50]
01f242ac: e80500b4 cbz      x8, #0x1f24368
01f242b0: 890240f9 ldr      x9, [x20]
01f242b4: a90500b4 cbz      x9, #0x1f24368
01f242b8: 081140b9 ldr      w8, [x8, #0x10]
01f242bc: 0a970190 adrp     x10, #0x5204000
01f242c0: 4abd47f9 ldr      x10, [x10, #0xf78]
01f242c4: 94970190 adrp     x20, #0x5214000
01f242c8: 281100b9 str      w8, [x9, #0x10]
01f242cc: e1330091 add      x1, sp, #0xc
01f242d0: 400140f9 ldr      x0, [x10]
01f242d4: 949245f9 ldr      x20, [x20, #0xb20]
01f242d8: e80f00b9 str      w8, [sp, #0xc]
01f242dc: 4c34c297 bl       #0xfb140c ; 
01f242e0: 880240f9 ldr      x8, [x20]
01f242e4: e10300aa mov      x1, x0
01f242e8: e2031faa mov      x2, xzr
01f242ec: e00308aa mov      x0, x8
01f242f0: 3a67f797 bl       #0x1cfdfd8 ; System.String$$Format
01f242f4: b50240f9 ldr      x21, [x21]
01f242f8: f40300aa mov      x20, x0
01f242fc: a81e40f9 ldr      x8, [x21, #0x38]
01f24300: 080140f9 ldr      x8, [x8]
01f24304: 09c94439 ldrb     w9, [x8, #0x132]
01f24308: 89000037 tbnz     w9, #0, #0x1f24318
01f2430c: e00308aa mov      x0, x8
01f24310: 3573c197 bl       #0xf80fe4 ; 
01f24314: e80300aa mov      x8, x0
01f24318: 09e140b9 ldr      w9, [x8, #0xe0]
01f2431c: 69000035 cbnz     w9, #0x1f24328
01f24320: e00308aa mov      x0, x8
01f24324: 3834c297 bl       #0xfb1404 ; 
01f24328: a81e40f9 ldr      x8, [x21, #0x38]
01f2432c: 000140f9 ldr      x0, [x8]
01f24330: 08c84439 ldrb     w8, [x0, #0x132]
01f24334: 48000037 tbnz     w8, #0, #0x1f2433c
01f24338: 2b73c197 bl       #0xf80fe4 ; 
01f2433c: 085c40f9 ldr      x8, [x0, #0xb8]
01f24340: a1058052 mov      w1, #0x2d
01f24344: e00313aa mov      x0, x19
01f24348: e20314aa mov      x2, x20
01f2434c: 030140f9 ldr      x3, [x8]
01f24350: e4031faa mov      x4, xzr
01f24354: 73712394 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01f24358: f37b42a9 ldp      x19, x30, [sp, #0x20]
01f2435c: f55341a9 ldp      x21, x20, [sp, #0x10]
01f24360: f60743f8 ldr      x22, [sp], #0x30
01f24364: c0035fd6 ret      
01f24368: 3034c297 bl       #0xfb1428 ; 
