# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Bind
# Linear metadata span, not a recovered full CFG.
02a30c04: f75bbda9 stp      x23, x22, [sp, #-0x30]!
02a30c08: f55301a9 stp      x21, x20, [sp, #0x10]
02a30c0c: f37b02a9 stp      x19, x30, [sp, #0x20]
02a30c10: 955a01b0 adrp     x21, #0x5581000
02a30c14: 143c01f0 adrp     x20, #0x51b3000
02a30c18: a8aa7a39 ldrb     w8, [x21, #0xeaa]
02a30c1c: 94a241f9 ldr      x20, [x20, #0x340]
02a30c20: f30300aa mov      x19, x0
02a30c24: e8010037 tbnz     w8, #0, #0x2a30c60
02a30c28: 403c01f0 adrp     x0, #0x51bb000
02a30c2c: 009c46f9 ldr      x0, [x0, #0xd38]
02a30c30: b4019697 bl       #0xfb1300 ; 
02a30c34: 60400190 adrp     x0, #0x523c000
02a30c38: 002840f9 ldr      x0, [x0, #0x50]
02a30c3c: b1019697 bl       #0xfb1300 ; 
02a30c40: 203b01d0 adrp     x0, #0x5196000
02a30c44: 000c43f9 ldr      x0, [x0, #0x618]
02a30c48: ae019697 bl       #0xfb1300 ; 
02a30c4c: 003c01f0 adrp     x0, #0x51b3000
02a30c50: 00a041f9 ldr      x0, [x0, #0x340]
02a30c54: ab019697 bl       #0xfb1300 ; 
02a30c58: 28008052 mov      w8, #1
02a30c5c: a8aa3a39 strb     w8, [x21, #0xeaa]
02a30c60: 800240f9 ldr      x0, [x20]
02a30c64: 343b01d0 adrp     x20, #0x5196000
02a30c68: 563c01f0 adrp     x22, #0x51bb000
02a30c6c: 08e040b9 ldr      w8, [x0, #0xe0]
02a30c70: 940e43f9 ldr      x20, [x20, #0x618]
02a30c74: d69e46f9 ldr      x22, [x22, #0xd38]
02a30c78: 48000035 cbnz     w8, #0x2a30c80
02a30c7c: e2019697 bl       #0xfb1404 ; 
02a30c80: 810240f9 ldr      x1, [x20]
02a30c84: 20008052 mov      w0, #1
02a30c88: b795f897 bl       #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
02a30c8c: c80240f9 ldr      x8, [x22]
02a30c90: f40300aa mov      x20, x0
02a30c94: e00308aa mov      x0, x8
02a30c98: e0019697 bl       #0xfb1418 ; 
02a30c9c: 800300b4 cbz      x0, #0x2a30d0c
02a30ca0: 77400190 adrp     x23, #0x523c000
02a30ca4: f72a40f9 ldr      x23, [x23, #0x50]
02a30ca8: e10313aa mov      x1, x19
02a30cac: e3031faa mov      x3, xzr
02a30cb0: f50300aa mov      x21, x0
02a30cb4: e20240f9 ldr      x2, [x23]
02a30cb8: ee4fd697 bl       #0x1fc4c70 ; System.Action$$.ctor
02a30cbc: 940200b4 cbz      x20, #0x2a30d0c
02a30cc0: e00314aa mov      x0, x20
02a30cc4: e10315aa mov      x1, x21
02a30cc8: e2031faa mov      x2, xzr
02a30ccc: 0b45d397 bl       #0x1f020f8 ; Royal.Player.Context.Units.UserManager$$remove_OnUserChanged
02a30cd0: c00240f9 ldr      x0, [x22]
02a30cd4: d1019697 bl       #0xfb1418 ; 
02a30cd8: a00100b4 cbz      x0, #0x2a30d0c
02a30cdc: e20240f9 ldr      x2, [x23]
02a30ce0: e10313aa mov      x1, x19
02a30ce4: e3031faa mov      x3, xzr
02a30ce8: f50300aa mov      x21, x0
02a30cec: e14fd697 bl       #0x1fc4c70 ; System.Action$$.ctor
02a30cf0: e00314aa mov      x0, x20
02a30cf4: e10315aa mov      x1, x21
02a30cf8: f37b42a9 ldp      x19, x30, [sp, #0x20]
02a30cfc: f55341a9 ldp      x21, x20, [sp, #0x10]
02a30d00: e2031faa mov      x2, xzr
02a30d04: f75bc3a8 ldp      x23, x22, [sp], #0x30
02a30d08: 6741d317 b        #0x1f012a4 ; Royal.Player.Context.Units.UserManager$$add_OnUserChanged
02a30d0c: c7019697 bl       #0xfb1428 ; 
