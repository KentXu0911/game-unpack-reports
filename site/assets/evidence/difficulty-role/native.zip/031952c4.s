# Royal.Player.Context.Units.PinataPartyManager$$FillFromLocal
# Linear metadata span, not a recovered full CFG.
031952c4: f40f1ef8 str      x20, [sp, #-0x20]!
031952c8: f37b01a9 stp      x19, x30, [sp, #0x10]
031952cc: 941f0190 adrp     x20, #0x5585000
031952d0: 88c26839 ldrb     w8, [x20, #0xa30]
031952d4: f30300aa mov      x19, x0
031952d8: e8010037 tbnz     w8, #0, #0x3195314
031952dc: e0040190 adrp     x0, #0x5231000
031952e0: 00a841f9 ldr      x0, [x0, #0x350]
031952e4: 07707897 bl       #0xfb1300 ; 
031952e8: 000501f0 adrp     x0, #0x5238000
031952ec: 009446f9 ldr      x0, [x0, #0xd28]
031952f0: 04707897 bl       #0xfb1300 ; 
031952f4: 200201f0 adrp     x0, #0x51dc000
031952f8: 002440f9 ldr      x0, [x0, #0x48]
031952fc: 01707897 bl       #0xfb1300 ; 
03195300: a00401b0 adrp     x0, #0x522a000
03195304: 008442f9 ldr      x0, [x0, #0x508]
03195308: fe6f7897 bl       #0xfb1300 ; 
0319530c: 28008052 mov      w8, #1
03195310: 88c22839 strb     w8, [x20, #0xa30]
03195314: e00313aa mov      x0, x19
03195318: e1031faa mov      x1, xzr
0319531c: 20b5ca97 bl       #0x244279c ; Royal.Player.Context.Units.AEventManager$$FillFromLocal
03195320: 602640f9 ldr      x0, [x19, #0x48]
03195324: a00400b4 cbz      x0, #0x31953b8
03195328: 49000094 bl       #0x319544c ; Royal.Player.Context.Units.PinataLocalData$$LoadData
0319532c: 280201f0 adrp     x8, #0x51dc000
03195330: 082540f9 ldr      x8, [x8, #0x48]
03195334: 000140f9 ldr      x0, [x8]
03195338: e1031faa mov      x1, xzr
0319533c: e2031faa mov      x2, xzr
03195340: 132bf397 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
03195344: f4040190 adrp     x20, #0x5231000
03195348: 94aa41f9 ldr      x20, [x20, #0x350]
0319534c: 810240f9 ldr      x1, [x20]
03195350: 169cce97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03195354: e10300aa mov      x1, x0
03195358: 610e05f8 str      x1, [x19, #0x50]!
0319535c: e00313aa mov      x0, x19
03195360: d36f7897 bl       #0xfb12ac ; 
03195364: 680240f9 ldr      x8, [x19]
03195368: 280200b5 cbnz     x8, #0x31953ac
0319536c: a80401b0 adrp     x8, #0x522a000
03195370: 090501f0 adrp     x9, #0x5238000
03195374: 088542f9 ldr      x8, [x8, #0x508]
03195378: 299546f9 ldr      x9, [x9, #0xd28]
0319537c: 000140f9 ldr      x0, [x8]
03195380: 210140f9 ldr      x1, [x9]
03195384: 57b2d097 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03195388: a00100b4 cbz      x0, #0x31953bc
0319538c: e1031faa mov      x1, xzr
03195390: 80ba2d94 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03195394: 810240f9 ldr      x1, [x20]
03195398: 049cce97 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0319539c: e10300aa mov      x1, x0
031953a0: 610200f9 str      x1, [x19]
031953a4: e00313aa mov      x0, x19
031953a8: c16f7897 bl       #0xfb12ac ; 
031953ac: f37b41a9 ldp      x19, x30, [sp, #0x10]
031953b0: f40742f8 ldr      x20, [sp], #0x20
031953b4: c0035fd6 ret      
031953b8: 1c707897 bl       #0xfb1428 ; 
031953bc: 1b707897 bl       #0xfb1428 ; 
031953c0: 06000014 b        #0x31953d8 ; 
031953c4: 05000014 b        #0x31953d8 ; 
031953c8: 04000014 b        #0x31953d8 ; 
031953cc: 03000014 b        #0x31953d8 ; 
031953d0: 02000014 b        #0x31953d8 ; 
031953d4: 01000014 b        #0x31953d8 ; 
031953d8: f30300aa mov      x19, x0
031953dc: 3f040071 cmp      w1, #1
031953e0: 01030054 b.ne     #0x3195440
031953e4: e00313aa mov      x0, x19
031953e8: 7ab86c97 bl       #0xcc35d0 ; 
031953ec: f30300aa mov      x19, x0
031953f0: 000401b0 adrp     x0, #0x5216000
031953f4: 001c44f9 ldr      x0, [x0, #0x838]
031953f8: c76f7897 bl       #0xfb1314 ; 
031953fc: 680240f9 ldr      x8, [x19]
03195400: 010140f9 ldr      x1, [x8]
03195404: 09717897 bl       #0xfb1828 ; 
03195408: 80000036 tbz      w0, #0, #0x3195418
0319540c: f37b41a9 ldp      x19, x30, [sp, #0x10]
03195410: f40742f8 ldr      x20, [sp], #0x20
03195414: ebb66c17 b        #0xcc2fc0 ; 
03195418: 00018052 mov      w0, #8
0319541c: e9b56c97 bl       #0xcc2bc0 ; 
03195420: 680240f9 ldr      x8, [x19]
03195424: 080000f9 str      x8, [x0]
03195428: 81ef00d0 adrp     x1, #0x4f87000
0319542c: 21603f91 add      x1, x1, #0xfd8
03195430: e2031faa mov      x2, xzr
03195434: 9bb36c97 bl       #0xcc22a0 ; 
03195438: f30300aa mov      x19, x0
0319543c: e1b66c97 bl       #0xcc2fc0 ; 
03195440: e00313aa mov      x0, x19
03195444: afb66c97 bl       #0xcc2f00 ; 
03195448: c0cc6c97 bl       #0xcc8748 ; 
