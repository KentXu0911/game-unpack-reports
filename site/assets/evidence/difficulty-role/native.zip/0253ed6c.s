# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetRandomItemFromList<CellPoint>
# Linear metadata span, not a recovered full CFG.
0253ed6c: f553bea9 stp      x21, x20, [sp, #-0x20]!
0253ed70: f37b01a9 stp      x19, x30, [sp, #0x10]
0253ed74: c10200b4 cbz      x1, #0x253edcc
0253ed78: 481c40f9 ldr      x8, [x2, #0x38]
0253ed7c: f30301aa mov      x19, x1
0253ed80: f50300aa mov      x21, x0
0253ed84: e00313aa mov      x0, x19
0253ed88: 010540f9 ldr      x1, [x8, #8]
0253ed8c: f40302aa mov      x20, x2
0253ed90: 280440f9 ldr      x8, [x1, #8]
0253ed94: 00013fd6 blr      x8
0253ed98: e203002a mov      w2, w0
0253ed9c: e00315aa mov      x0, x21
0253eda0: e1031f2a mov      w1, wzr
0253eda4: e3031faa mov      x3, xzr
0253eda8: 90c81394 bl       #0x2a30fe8 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$Next
0253edac: 881e40f9 ldr      x8, [x20, #0x38]
0253edb0: e103002a mov      w1, w0
0253edb4: e00313aa mov      x0, x19
0253edb8: f37b41a9 ldp      x19, x30, [sp, #0x10]
0253edbc: 020940f9 ldr      x2, [x8, #0x10]
0253edc0: 430440f9 ldr      x3, [x2, #8]
0253edc4: f553c2a8 ldp      x21, x20, [sp], #0x20
0253edc8: 60001fd6 br       x3
0253edcc: 97c9a997 bl       #0xfb1428 ; 
