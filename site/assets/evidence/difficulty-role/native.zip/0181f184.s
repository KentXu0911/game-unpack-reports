# Royal.Scenes.TableGame.Systems.TableGameController$$TryGetLevelConfig
# Linear metadata span, not a recovered full CFG.
0181f184: f963bca9 stp      x25, x24, [sp, #-0x40]!
0181f188: f75b01a9 stp      x23, x22, [sp, #0x10]
0181f18c: f55302a9 stp      x21, x20, [sp, #0x20]
0181f190: f37b03a9 stp      x19, x30, [sp, #0x30]
0181f194: d5ea01d0 adrp     x21, #0x5579000
0181f198: a84a7b39 ldrb     w8, [x21, #0xed2]
0181f19c: f40301aa mov      x20, x1
0181f1a0: f30300aa mov      x19, x0
0181f1a4: c8030037 tbnz     w8, #0, #0x181f21c
0181f1a8: 00d001f0 adrp     x0, #0x5222000
0181f1ac: 00ec42f9 ldr      x0, [x0, #0x5d8]
0181f1b0: 5448de97 bl       #0xfb1300 ; 
0181f1b4: 60d00190 adrp     x0, #0x522b000
0181f1b8: 006445f9 ldr      x0, [x0, #0xac8]
0181f1bc: 5148de97 bl       #0xfb1300 ; 
0181f1c0: 80d001d0 adrp     x0, #0x5231000
0181f1c4: 003841f9 ldr      x0, [x0, #0x270]
0181f1c8: 4e48de97 bl       #0xfb1300 ; 
0181f1cc: 00cc0190 adrp     x0, #0x519f000
0181f1d0: 00a845f9 ldr      x0, [x0, #0xb50]
0181f1d4: 4b48de97 bl       #0xfb1300 ; 
0181f1d8: 00ce0190 adrp     x0, #0x51df000
0181f1dc: 00d445f9 ldr      x0, [x0, #0xba8]
0181f1e0: 4848de97 bl       #0xfb1300 ; 
0181f1e4: 00ce01b0 adrp     x0, #0x51e0000
0181f1e8: 003845f9 ldr      x0, [x0, #0xa70]
0181f1ec: 4548de97 bl       #0xfb1300 ; 
0181f1f0: 40cc01b0 adrp     x0, #0x51a8000
0181f1f4: 007c44f9 ldr      x0, [x0, #0x8f8]
0181f1f8: 4248de97 bl       #0xfb1300 ; 
0181f1fc: c0ce01d0 adrp     x0, #0x51f9000
0181f200: 002c46f9 ldr      x0, [x0, #0xc58]
0181f204: 3f48de97 bl       #0xfb1300 ; 
0181f208: 20cd01b0 adrp     x0, #0x51c4000
0181f20c: 00e441f9 ldr      x0, [x0, #0x3c8]
0181f210: 3c48de97 bl       #0xfb1300 ; 
0181f214: 28008052 mov      w8, #1
0181f218: a84a3b39 strb     w8, [x21, #0xed2]
0181f21c: e00314aa mov      x0, x20
0181f220: e1031faa mov      x1, xzr
0181f224: 9f0200f9 str      xzr, [x20]
0181f228: 2148de97 bl       #0xfb12ac ; 
0181f22c: e0031faa mov      x0, xzr
0181f230: 6c791694 bl       #0x1dbd7e0 ; Royal.Player.Context.Units.KingWorkshopManager$$get_Current
0181f234: 601e00b4 cbz      x0, #0x181f600
0181f238: f50300aa mov      x21, x0
0181f23c: 002040f9 ldr      x0, [x0, #0x40]
0181f240: e1031faa mov      x1, xzr
0181f244: 56a01394 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0181f248: 80000036 tbz      w0, #0, #0x181f258
0181f24c: e00315aa mov      x0, x21
0181f250: e1031faa mov      x1, xzr
0181f254: 5f7d1694 bl       #0x1dbe7d0 ; Royal.Player.Context.Units.KingWorkshopManager$$PrepareLevelSession
0181f258: a8264139 ldrb     w8, [x21, #0x49]
0181f25c: 58cc01b0 adrp     x24, #0x51a8000
0181f260: e1031faa mov      x1, xzr
0181f264: 68520639 strb     w8, [x19, #0x194]
0181f268: a8224139 ldrb     w8, [x21, #0x48]
0181f26c: 684e0639 strb     w8, [x19, #0x193]
0181f270: b52240f9 ldr      x21, [x21, #0x40]
0181f274: 187f44f9 ldr      x24, [x24, #0x8f8]
0181f278: e00315aa mov      x0, x21
0181f27c: 48a01394 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0181f280: 60030036 tbz      w0, #0, #0x181f2ec
0181f284: 08d001f0 adrp     x8, #0x5222000
0181f288: 08ed42f9 ldr      x8, [x8, #0x5d8]
0181f28c: 150140f9 ldr      x21, [x8]
0181f290: a81e40f9 ldr      x8, [x21, #0x38]
0181f294: 000140f9 ldr      x0, [x8]
0181f298: 08c84439 ldrb     w8, [x0, #0x132]
0181f29c: 48000037 tbnz     w8, #0, #0x181f2a4
0181f2a0: 5187dd97 bl       #0xf80fe4 ; 
0181f2a4: 08e040b9 ldr      w8, [x0, #0xe0]
0181f2a8: 48000035 cbnz     w8, #0x181f2b0
0181f2ac: 5648de97 bl       #0xfb1404 ; 
0181f2b0: a81e40f9 ldr      x8, [x21, #0x38]
0181f2b4: d5ce01d0 adrp     x21, #0x51f9000
0181f2b8: 000140f9 ldr      x0, [x8]
0181f2bc: 08c84439 ldrb     w8, [x0, #0x132]
0181f2c0: b52e46f9 ldr      x21, [x21, #0xc58]
0181f2c4: 48000037 tbnz     w8, #0, #0x181f2cc
0181f2c8: 4787dd97 bl       #0xf80fe4 ; 
0181f2cc: 085c40f9 ldr      x8, [x0, #0xb8]
0181f2d0: a20240f9 ldr      x2, [x21]
0181f2d4: c10b8052 mov      w1, #0x5e
0181f2d8: e00313aa mov      x0, x19
0181f2dc: 030140f9 ldr      x3, [x8]
0181f2e0: e4031faa mov      x4, xzr
0181f2e4: 4fb33f94 bl       #0x280c020 ; Royal.Infrastructure.Services.Logs.Log$$Warning
0181f2e8: 150340f9 ldr      x21, [x24]
0181f2ec: 97d001d0 adrp     x23, #0x5231000
0181f2f0: f73a41f9 ldr      x23, [x23, #0x270]
0181f2f4: e0031faa mov      x0, xzr
0181f2f8: e1031faa mov      x1, xzr
0181f2fc: 28a01394 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
0181f300: e803002a mov      w8, w0
0181f304: 20060036 tbz      w0, #0, #0x181f3c8
0181f308: 19cc0190 adrp     x25, #0x519f000
0181f30c: 39ab45f9 ldr      x25, [x25, #0xb50]
0181f310: e00315aa mov      x0, x21
0181f314: cfefff97 bl       #0x181b250 ; Royal.Scenes.TableGame.Systems.TableGameBundleAccess$$LoadLevelText
0181f318: 280340f9 ldr      x8, [x25]
0181f31c: f60300aa mov      x22, x0
0181f320: 09e140b9 ldr      w9, [x8, #0xe0]
0181f324: 69000035 cbnz     w9, #0x181f330
0181f328: e00308aa mov      x0, x8
0181f32c: 3648de97 bl       #0xfb1404 ; 
0181f330: e00316aa mov      x0, x22
0181f334: e1031faa mov      x1, xzr
0181f338: e2031faa mov      x2, xzr
0181f33c: 8c609394 bl       #0x3cf756c ; UnityEngine.Object$$op_Equality
0181f340: e0060036 tbz      w0, #0, #0x181f41c
0181f344: 010340f9 ldr      x1, [x24]
0181f348: e00315aa mov      x0, x21
0181f34c: e2031faa mov      x2, xzr
0181f350: 1a9c1394 bl       #0x1d063b8 ; System.String$$op_Inequality
0181f354: 40060036 tbz      w0, #0, #0x181f41c
0181f358: e00240f9 ldr      x0, [x23]
0181f35c: 41008052 mov      w1, #2
0181f360: 0448de97 bl       #0xfb1370 ; 
0181f364: e01400b4 cbz      x0, #0x181f600
0181f368: f60300aa mov      x22, x0
0181f36c: d50000b4 cbz      x21, #0x181f384
0181f370: c80240f9 ldr      x8, [x22]
0181f374: e00315aa mov      x0, x21
0181f378: 012140f9 ldr      x1, [x8, #0x40]
0181f37c: 2348de97 bl       #0xfb1408 ; 
0181f380: 401400b4 cbz      x0, #0x181f608
0181f384: c81a40b9 ldr      w8, [x22, #0x18]
0181f388: e8130034 cbz      w8, #0x181f604
0181f38c: e00316aa mov      x0, x22
0181f390: 150c02f8 str      x21, [x0, #0x20]!
0181f394: e10315aa mov      x1, x21
0181f398: c547de97 bl       #0xfb12ac ; 
0181f39c: 010340f9 ldr      x1, [x24]
0181f3a0: 810100b4 cbz      x1, #0x181f3d0
0181f3a4: c80240f9 ldr      x8, [x22]
0181f3a8: e00301aa mov      x0, x1
0181f3ac: 082140f9 ldr      x8, [x8, #0x40]
0181f3b0: e10308aa mov      x1, x8
0181f3b4: 1548de97 bl       #0xfb1408 ; 
0181f3b8: 801200b4 cbz      x0, #0x181f608
0181f3bc: 080340f9 ldr      x8, [x24]
0181f3c0: e10308aa mov      x1, x8
0181f3c4: 04000014 b        #0x181f3d4 ; 
0181f3c8: e0031faa mov      x0, xzr
0181f3cc: 31000014 b        #0x181f490 ; 
0181f3d0: e8031faa mov      x8, xzr
0181f3d4: c91a40b9 ldr      w9, [x22, #0x18]
0181f3d8: 3f050071 cmp      w9, #1
0181f3dc: 49110054 b.ls     #0x181f604
0181f3e0: 15ce0190 adrp     x21, #0x51df000
0181f3e4: b5d645f9 ldr      x21, [x21, #0xba8]
0181f3e8: e00316aa mov      x0, x22
0181f3ec: 088c02f8 str      x8, [x0, #0x28]!
0181f3f0: af47de97 bl       #0xfb12ac ; 
0181f3f4: a20240f9 ldr      x2, [x21]
0181f3f8: c10b8052 mov      w1, #0x5e
0181f3fc: e00313aa mov      x0, x19
0181f400: e30316aa mov      x3, x22
0181f404: e4031faa mov      x4, xzr
0181f408: 06b33f94 bl       #0x280c020 ; Royal.Infrastructure.Services.Logs.Log$$Warning
0181f40c: 150340f9 ldr      x21, [x24]
0181f410: e00315aa mov      x0, x21
0181f414: 8fefff97 bl       #0x181b250 ; Royal.Scenes.TableGame.Systems.TableGameBundleAccess$$LoadLevelText
0181f418: f60300aa mov      x22, x0
0181f41c: 200340f9 ldr      x0, [x25]
0181f420: 08e040b9 ldr      w8, [x0, #0xe0]
0181f424: 48000035 cbnz     w8, #0x181f42c
0181f428: f747de97 bl       #0xfb1404 ; 
0181f42c: e00316aa mov      x0, x22
0181f430: e1031faa mov      x1, xzr
0181f434: e2031faa mov      x2, xzr
0181f438: 4d609394 bl       #0x3cf756c ; UnityEngine.Object$$op_Equality
0181f43c: 20020036 tbz      w0, #0, #0x181f480
0181f440: e00240f9 ldr      x0, [x23]
0181f444: 21008052 mov      w1, #1
0181f448: ca47de97 bl       #0xfb1370 ; 
0181f44c: a00d00b4 cbz      x0, #0x181f600
0181f450: f40300aa mov      x20, x0
0181f454: d50000b4 cbz      x21, #0x181f46c
0181f458: 880240f9 ldr      x8, [x20]
0181f45c: e00315aa mov      x0, x21
0181f460: 012140f9 ldr      x1, [x8, #0x40]
0181f464: e947de97 bl       #0xfb1408 ; 
0181f468: 000d00b4 cbz      x0, #0x181f608
0181f46c: 881a40b9 ldr      w8, [x20, #0x18]
0181f470: a80c0034 cbz      w8, #0x181f604
0181f474: 16ce01b0 adrp     x22, #0x51e0000
0181f478: d63a45f9 ldr      x22, [x22, #0xa70]
0181f47c: 2b000014 b        #0x181f528 ; 
0181f480: 160c00b4 cbz      x22, #0x181f600
0181f484: e00316aa mov      x0, x22
0181f488: e1031faa mov      x1, xzr
0181f48c: 41929394 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
0181f490: 68d00190 adrp     x8, #0x522b000
0181f494: 086545f9 ldr      x8, [x8, #0xac8]
0181f498: 010140f9 ldr      x1, [x8]
0181f49c: c3733494 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
0181f4a0: e10300aa mov      x1, x0
0181f4a4: 810200f9 str      x1, [x20]
0181f4a8: e00314aa mov      x0, x20
0181f4ac: 8047de97 bl       #0xfb12ac ; 
0181f4b0: 800240f9 ldr      x0, [x20]
0181f4b4: c00100b4 cbz      x0, #0x181f4ec
0181f4b8: e1031faa mov      x1, xzr
0181f4bc: eafe7e94 bl       #0x37df064 ; Royal.Scenes.TableGame.Config.TableGameLevelConfig$$Normalize
0181f4c0: e0031faa mov      x0, xzr
0181f4c4: c7781694 bl       #0x1dbd7e0 ; Royal.Player.Context.Units.KingWorkshopManager$$get_Current
0181f4c8: c00900b4 cbz      x0, #0x181f600
0181f4cc: 644e4639 ldrb     w4, [x19, #0x193]
0181f4d0: 63524639 ldrb     w3, [x19, #0x194]
0181f4d4: 820240f9 ldr      x2, [x20]
0181f4d8: e10315aa mov      x1, x21
0181f4dc: e5031faa mov      x5, xzr
0181f4e0: fb7d1694 bl       #0x1dbeccc ; Royal.Player.Context.Units.KingWorkshopManager$$UpdatePreparedLevel
0181f4e4: 20008052 mov      w0, #1
0181f4e8: 1b000014 b        #0x181f554 ; 
0181f4ec: e00240f9 ldr      x0, [x23]
0181f4f0: 21008052 mov      w1, #1
0181f4f4: 9f47de97 bl       #0xfb1370 ; 
0181f4f8: 400800b4 cbz      x0, #0x181f600
0181f4fc: f40300aa mov      x20, x0
0181f500: d50000b4 cbz      x21, #0x181f518
0181f504: 880240f9 ldr      x8, [x20]
0181f508: e00315aa mov      x0, x21
0181f50c: 012140f9 ldr      x1, [x8, #0x40]
0181f510: be47de97 bl       #0xfb1408 ; 
0181f514: a00700b4 cbz      x0, #0x181f608
0181f518: 881a40b9 ldr      w8, [x20, #0x18]
0181f51c: 48070034 cbz      w8, #0x181f604
0181f520: 36cd01b0 adrp     x22, #0x51c4000
0181f524: d6e641f9 ldr      x22, [x22, #0x3c8]
0181f528: e00314aa mov      x0, x20
0181f52c: 150c02f8 str      x21, [x0, #0x20]!
0181f530: e10315aa mov      x1, x21
0181f534: 5e47de97 bl       #0xfb12ac ; 
0181f538: c20240f9 ldr      x2, [x22]
0181f53c: c10b8052 mov      w1, #0x5e
0181f540: e00313aa mov      x0, x19
0181f544: e30314aa mov      x3, x20
0181f548: e4031faa mov      x4, xzr
0181f54c: b5b23f94 bl       #0x280c020 ; Royal.Infrastructure.Services.Logs.Log$$Warning
0181f550: e0031f2a mov      w0, wzr
0181f554: f37b43a9 ldp      x19, x30, [sp, #0x30]
0181f558: f55342a9 ldp      x21, x20, [sp, #0x20]
0181f55c: f75b41a9 ldp      x23, x22, [sp, #0x10]
0181f560: f963c4a8 ldp      x25, x24, [sp], #0x40
0181f564: c0035fd6 ret      
0181f568: 3f040071 cmp      w1, #1
0181f56c: f40300aa mov      x20, x0
0181f570: 61060054 b.ne     #0x181f63c
0181f574: e00314aa mov      x0, x20
0181f578: 1690d297 bl       #0xcc35d0 ; 
0181f57c: f40300aa mov      x20, x0
0181f580: 00d00190 adrp     x0, #0x521f000
0181f584: 001840f9 ldr      x0, [x0, #0x30]
0181f588: 6347de97 bl       #0xfb1314 ; 
0181f58c: 880240f9 ldr      x8, [x20]
0181f590: 010140f9 ldr      x1, [x8]
0181f594: a548de97 bl       #0xfb1828 ; 
0181f598: e0030036 tbz      w0, #0, #0x181f614
0181f59c: 898ed297 bl       #0xcc2fc0 ; 
0181f5a0: 80d001d0 adrp     x0, #0x5231000
0181f5a4: 003841f9 ldr      x0, [x0, #0x270]
0181f5a8: 5b47de97 bl       #0xfb1314 ; 
0181f5ac: 21008052 mov      w1, #1
0181f5b0: 7047de97 bl       #0xfb1370 ; 
0181f5b4: 600200b4 cbz      x0, #0x181f600
0181f5b8: f40300aa mov      x20, x0
0181f5bc: d50000b4 cbz      x21, #0x181f5d4
0181f5c0: 880240f9 ldr      x8, [x20]
0181f5c4: e00315aa mov      x0, x21
0181f5c8: 012140f9 ldr      x1, [x8, #0x40]
0181f5cc: 8f47de97 bl       #0xfb1408 ; 
0181f5d0: c00100b4 cbz      x0, #0x181f608
0181f5d4: 881a40b9 ldr      w8, [x20, #0x18]
0181f5d8: 68010034 cbz      w8, #0x181f604
0181f5dc: e00314aa mov      x0, x20
0181f5e0: 150c02f8 str      x21, [x0, #0x20]!
0181f5e4: e10315aa mov      x1, x21
0181f5e8: 3147de97 bl       #0xfb12ac ; 
0181f5ec: e0cb01d0 adrp     x0, #0x519d000
0181f5f0: 002841f9 ldr      x0, [x0, #0x250]
0181f5f4: 4847de97 bl       #0xfb1314 ; 
0181f5f8: e20300aa mov      x2, x0
0181f5fc: d0ffff17 b        #0x181f53c ; 
0181f600: 8a47de97 bl       #0xfb1428 ; 
0181f604: 8b47de97 bl       #0xfb1430 ; 
0181f608: 9147de97 bl       #0xfb144c ; 
0181f60c: e1031faa mov      x1, xzr
0181f610: 7847de97 bl       #0xfb13f0 ; 
0181f614: 00018052 mov      w0, #8
0181f618: 6a8dd297 bl       #0xcc2bc0 ; 
0181f61c: 880240f9 ldr      x8, [x20]
0181f620: 080000f9 str      x8, [x0]
0181f624: 41bb0190 adrp     x1, #0x4f87000
0181f628: 21603f91 add      x1, x1, #0xfd8
0181f62c: e2031faa mov      x2, xzr
0181f630: 1c8bd297 bl       #0xcc22a0 ; 
0181f634: f40300aa mov      x20, x0
0181f638: 628ed297 bl       #0xcc2fc0 ; 
0181f63c: e00314aa mov      x0, x20
0181f640: 308ed297 bl       #0xcc2f00 ; 
0181f644: 41a4d297 bl       #0xcc8748 ; 
