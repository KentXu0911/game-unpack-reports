# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleCellsBasedOnDifficulty
# Linear metadata span, not a recovered full CFG.
02a314a8: fb6bbba9 stp      x27, x26, [sp, #-0x50]!
02a314ac: f96301a9 stp      x25, x24, [sp, #0x10]
02a314b0: f75b02a9 stp      x23, x22, [sp, #0x20]
02a314b4: f55303a9 stp      x21, x20, [sp, #0x30]
02a314b8: f37b04a9 stp      x19, x30, [sp, #0x40]
02a314bc: 955a0190 adrp     x21, #0x5581000
02a314c0: 5a3f01d0 adrp     x26, #0x521b000
02a314c4: a8ca7a39 ldrb     w8, [x21, #0xeb2]
02a314c8: 5aeb42f9 ldr      x26, [x26, #0x5d0]
02a314cc: f30301aa mov      x19, x1
02a314d0: f40300aa mov      x20, x0
02a314d4: c8000037 tbnz     w8, #0, #0x2a314ec
02a314d8: 403f01d0 adrp     x0, #0x521b000
02a314dc: 00e842f9 ldr      x0, [x0, #0x5d0]
02a314e0: 88ff9597 bl       #0xfb1300 ; 
02a314e4: 28008052 mov      w8, #1
02a314e8: a8ca3a39 strb     w8, [x21, #0xeb2]
02a314ec: 400340f9 ldr      x0, [x26]
02a314f0: 08e040b9 ldr      w8, [x0, #0xe0]
02a314f4: 48000035 cbnz     w8, #0x2a314fc
02a314f8: c3ff9597 bl       #0xfb1404 ; 
02a314fc: 750240b9 ldr      w21, [x19]
02a31500: a8060051 sub      w8, w21, #1
02a31504: 1f050071 cmp      w8, #1
02a31508: 8b040054 b.lt     #0x2a31598
02a3150c: 3b008052 mov      w27, #1
02a31510: 76070051 sub      w22, w27, #1
02a31514: e00314aa mov      x0, x20
02a31518: e103162a mov      w1, w22
02a3151c: e203152a mov      w2, w21
02a31520: d6ffff97 bl       #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
02a31524: 480340f9 ldr      x8, [x26]
02a31528: f703002a mov      w23, w0
02a3152c: 09e140b9 ldr      w9, [x8, #0xe0]
02a31530: 69000035 cbnz     w9, #0x2a3153c
02a31534: e00308aa mov      x0, x8
02a31538: b3ff9597 bl       #0xfb1404 ; 
02a3153c: e00313aa mov      x0, x19
02a31540: e103172a mov      w1, w23
02a31544: e2031faa mov      x2, xzr
02a31548: e118a597 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
02a3154c: f80300aa mov      x24, x0
02a31550: e00313aa mov      x0, x19
02a31554: e103162a mov      w1, w22
02a31558: e2031faa mov      x2, xzr
02a3155c: dc18a597 bl       #0x13778cc ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$get_Item
02a31560: f90300aa mov      x25, x0
02a31564: e00313aa mov      x0, x19
02a31568: e103162a mov      w1, w22
02a3156c: e20318aa mov      x2, x24
02a31570: e3031faa mov      x3, xzr
02a31574: 4519a597 bl       #0x1377a88 ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$set_Item
02a31578: e00313aa mov      x0, x19
02a3157c: e103172a mov      w1, w23
02a31580: e20319aa mov      x2, x25
02a31584: e3031faa mov      x3, xzr
02a31588: 4019a597 bl       #0x1377a88 ; Royal.Scenes.Game.Mechanics.Matches.Cell14$$set_Item
02a3158c: 7b070011 add      w27, w27, #1
02a31590: bf021b6b cmp      w21, w27
02a31594: e1fbff54 b.ne     #0x2a31510
02a31598: f37b44a9 ldp      x19, x30, [sp, #0x40]
02a3159c: f55343a9 ldp      x21, x20, [sp, #0x30]
02a315a0: f75b42a9 ldp      x23, x22, [sp, #0x20]
02a315a4: f96341a9 ldp      x25, x24, [sp, #0x10]
02a315a8: fb6bc5a8 ldp      x27, x26, [sp], #0x50
02a315ac: c0035fd6 ret      
