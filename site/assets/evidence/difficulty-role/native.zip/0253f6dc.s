# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleList<int>
# Linear metadata span, not a recovered full CFG.
0253f6dc: 481c40f9 ldr      x8, [x2, #0x38]
0253f6e0: 020140f9 ldr      x2, [x8]
0253f6e4: e80300aa mov      x8, x0
0253f6e8: e00301aa mov      x0, x1
0253f6ec: e10308aa mov      x1, x8
0253f6f0: 430440f9 ldr      x3, [x2, #8]
0253f6f4: 60001fd6 br       x3
