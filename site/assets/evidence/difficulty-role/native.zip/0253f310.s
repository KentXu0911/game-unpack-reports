# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArrayBasedOnDifficulty<object>
# Linear metadata span, not a recovered full CFG.
0253f310: fa0f1bf8 str      x26, [sp, #-0x50]!
0253f314: f96301a9 stp      x25, x24, [sp, #0x10]
0253f318: f75b02a9 stp      x23, x22, [sp, #0x20]
0253f31c: f55303a9 stp      x21, x20, [sp, #0x30]
0253f320: f37b04a9 stp      x19, x30, [sp, #0x40]
0253f324: 5f080071 cmp      w2, #2
0253f328: 0b050054 b.lt     #0x253f3c8
0253f32c: f303022a mov      w19, w2
0253f330: 687e4093 sxtw     x8, w19
0253f334: 29cc228b add      x9, x1, w2, sxtw #3
0253f338: f40301aa mov      x20, x1
0253f33c: f50300aa mov      x21, x0
0253f340: 1a050091 add      x26, x8, #1
0253f344: 36610091 add      x22, x9, #0x18
0253f348: e00315aa mov      x0, x21
0253f34c: e1031f2a mov      w1, wzr
0253f350: e203132a mov      w2, w19
0253f354: e3031faa mov      x3, xzr
0253f358: 48c81394 bl       #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
0253f35c: 540400b4 cbz      x20, #0x253f3e4
0253f360: 880e40f9 ldr      x8, [x20, #0x18]
0253f364: f703002a mov      w23, w0
0253f368: 1f00086b cmp      w0, w8
0253f36c: a2030054 b.hs     #0x253f3e0
0253f370: 98ce378b add      x24, x20, w23, sxtw #3
0253f374: 010f42f8 ldr      x1, [x24, #0x20]!
0253f378: 490b00d1 sub      x9, x26, #2
0253f37c: 087d4092 and      x8, x8, #0xffffffff
0253f380: 3f0108eb cmp      x9, x8
0253f384: e2020054 b.hs     #0x253f3e0
0253f388: d90240f9 ldr      x25, [x22]
0253f38c: e00316aa mov      x0, x22
0253f390: c10200f9 str      x1, [x22]
0253f394: c6c7a997 bl       #0xfb12ac ; 
0253f398: 881a40b9 ldr      w8, [x20, #0x18]
0253f39c: ff02086b cmp      w23, w8
0253f3a0: 02020054 b.hs     #0x253f3e0
0253f3a4: e00318aa mov      x0, x24
0253f3a8: e10319aa mov      x1, x25
0253f3ac: 190300f9 str      x25, [x24]
0253f3b0: bfc7a997 bl       #0xfb12ac ; 
0253f3b4: 5a0700d1 sub      x26, x26, #1
0253f3b8: 73060051 sub      w19, w19, #1
0253f3bc: 5f0b00f1 cmp      x26, #2
0253f3c0: d62200d1 sub      x22, x22, #8
0253f3c4: 2cfcff54 b.gt     #0x253f348
0253f3c8: f37b44a9 ldp      x19, x30, [sp, #0x40]
0253f3cc: f55343a9 ldp      x21, x20, [sp, #0x30]
0253f3d0: f75b42a9 ldp      x23, x22, [sp, #0x20]
0253f3d4: f96341a9 ldp      x25, x24, [sp, #0x10]
0253f3d8: fa0745f8 ldr      x26, [sp], #0x50
0253f3dc: c0035fd6 ret      
0253f3e0: 14c8a997 bl       #0xfb1430 ; 
0253f3e4: 11c8a997 bl       #0xfb1428 ; 
