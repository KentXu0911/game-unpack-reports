# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleListBasedOnDifficulty<ushort>
# Linear metadata span, not a recovered full CFG.
0253f814: fb6bbba9 stp      x27, x26, [sp, #-0x50]!
0253f818: f96301a9 stp      x25, x24, [sp, #0x10]
0253f81c: f75b02a9 stp      x23, x22, [sp, #0x20]
0253f820: f55303a9 stp      x21, x20, [sp, #0x30]
0253f824: f37b04a9 stp      x19, x30, [sp, #0x40]
0253f828: 410700b4 cbz      x1, #0x253f910
0253f82c: 481c40f9 ldr      x8, [x2, #0x38]
0253f830: f40301aa mov      x20, x1
0253f834: f50300aa mov      x21, x0
0253f838: e00314aa mov      x0, x20
0253f83c: 010540f9 ldr      x1, [x8, #8]
0253f840: f30302aa mov      x19, x2
0253f844: 280440f9 ldr      x8, [x1, #8]
0253f848: 00013fd6 blr      x8
0253f84c: 08040051 sub      w8, w0, #1
0253f850: 1f050071 cmp      w8, #1
0253f854: 2b050054 b.lt     #0x253f8f8
0253f858: f603002a mov      w22, w0
0253f85c: 3b008052 mov      w27, #1
0253f860: 77070051 sub      w23, w27, #1
0253f864: e00315aa mov      x0, x21
0253f868: e103172a mov      w1, w23
0253f86c: e203162a mov      w2, w22
0253f870: e3031faa mov      x3, xzr
0253f874: 01c71394 bl       #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
0253f878: 681e40f9 ldr      x8, [x19, #0x38]
0253f87c: f803002a mov      w24, w0
0253f880: e00314aa mov      x0, x20
0253f884: e103182a mov      w1, w24
0253f888: 020940f9 ldr      x2, [x8, #0x10]
0253f88c: 480440f9 ldr      x8, [x2, #8]
0253f890: 00013fd6 blr      x8
0253f894: 681e40f9 ldr      x8, [x19, #0x38]
0253f898: f903002a mov      w25, w0
0253f89c: e00314aa mov      x0, x20
0253f8a0: e103172a mov      w1, w23
0253f8a4: 020940f9 ldr      x2, [x8, #0x10]
0253f8a8: 480440f9 ldr      x8, [x2, #8]
0253f8ac: 00013fd6 blr      x8
0253f8b0: 681e40f9 ldr      x8, [x19, #0x38]
0253f8b4: fa03002a mov      w26, w0
0253f8b8: e00314aa mov      x0, x20
0253f8bc: e103172a mov      w1, w23
0253f8c0: 030d40f9 ldr      x3, [x8, #0x18]
0253f8c4: e203192a mov      w2, w25
0253f8c8: 680440f9 ldr      x8, [x3, #8]
0253f8cc: 00013fd6 blr      x8
0253f8d0: 681e40f9 ldr      x8, [x19, #0x38]
0253f8d4: e00314aa mov      x0, x20
0253f8d8: e103182a mov      w1, w24
0253f8dc: e2031a2a mov      w2, w26
0253f8e0: 030d40f9 ldr      x3, [x8, #0x18]
0253f8e4: 680440f9 ldr      x8, [x3, #8]
0253f8e8: 00013fd6 blr      x8
0253f8ec: 7b070011 add      w27, w27, #1
0253f8f0: df021b6b cmp      w22, w27
0253f8f4: 61fbff54 b.ne     #0x253f860
0253f8f8: f37b44a9 ldp      x19, x30, [sp, #0x40]
0253f8fc: f55343a9 ldp      x21, x20, [sp, #0x30]
0253f900: f75b42a9 ldp      x23, x22, [sp, #0x20]
0253f904: f96341a9 ldp      x25, x24, [sp, #0x10]
0253f908: fb6bc5a8 ldp      x27, x26, [sp], #0x50
0253f90c: c0035fd6 ret      
0253f910: c6c6a997 bl       #0xfb1428 ; 
