# Royal.Player.Context.Data.Persistent.UserInventory$$SetDeltaMove
# Linear metadata span, not a recovered full CFG.
02a0e878: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
02a0e87c: f30300aa mov      x19, x0
02a0e880: 005840f9 ldr      x0, [x0, #0xb0]
02a0e884: 21280011 add      w1, w1, #0xa
02a0e888: a2018052 mov      w2, #0xd
02a0e88c: 23028052 mov      w3, #0x11
02a0e890: e4031faa mov      x4, xzr
02a0e894: 05d72194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e898: e10300aa mov      x1, x0
02a0e89c: e00313aa mov      x0, x19
02a0e8a0: f37bc1a8 ldp      x19, x30, [sp], #0x10
02a0e8a4: 97ffff17 b        #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
