# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArrays<object, object>
# Linear metadata span, not a recovered full CFG.
0253f55c: ff0302d1 sub      sp, sp, #0x80
0253f560: fc6f02a9 stp      x28, x27, [sp, #0x20]
0253f564: fa6703a9 stp      x26, x25, [sp, #0x30]
0253f568: f85f04a9 stp      x24, x23, [sp, #0x40]
0253f56c: f65705a9 stp      x22, x21, [sp, #0x50]
0253f570: f44f06a9 stp      x20, x19, [sp, #0x60]
0253f574: fd7b07a9 stp      x29, x30, [sp, #0x70]
0253f578: 7f080071 cmp      w3, #2
0253f57c: e00b00f9 str      x0, [sp, #0x10]
0253f580: ab090054 b.lt     #0x253f6b4
0253f584: e803032a mov      w8, w3
0253f588: e80700f9 str      x8, [sp, #8]
0253f58c: 687c7d93 sbfiz    x8, x3, #3, #0x20
0253f590: 08610091 add      x8, x8, #0x18
0253f594: f30302aa mov      x19, x2
0253f598: f40301aa mov      x20, x1
0253f59c: fb031faa mov      x27, xzr
0253f5a0: fc031faa mov      x28, xzr
0253f5a4: 7d7c4093 sxtw     x29, w3
0253f5a8: 2900088b add      x9, x1, x8
0253f5ac: 4800088b add      x8, x2, x8
0253f5b0: e90300f9 str      x9, [sp]
0253f5b4: e80f00f9 str      x8, [sp, #0x18]
0253f5b8: e80b40f9 ldr      x8, [sp, #0x10]
0253f5bc: 001940f9 ldr      x0, [x8, #0x30]
0253f5c0: c00800b4 cbz      x0, #0x253f6d8
0253f5c4: 080040f9 ldr      x8, [x0]
0253f5c8: 09895aa9 ldp      x9, x2, [x8, #0x1a8]
0253f5cc: e80740f9 ldr      x8, [sp, #8]
0253f5d0: 01011c0b add      w1, w8, w28
0253f5d4: 20013fd6 blr      x9
0253f5d8: 140800b4 cbz      x20, #0x253f6d8
0253f5dc: 880e40f9 ldr      x8, [x20, #0x18]
0253f5e0: a9031c8b add      x9, x29, x28
0253f5e4: 350500d1 sub      x21, x9, #1
0253f5e8: bf4228eb cmp      x21, w8, uxtw
0253f5ec: 42070054 b.hs     #0x253f6d4
0253f5f0: 530700b4 cbz      x19, #0x253f6d8
0253f5f4: 691a40b9 ldr      w9, [x19, #0x18]
0253f5f8: bf0209eb cmp      x21, x9
0253f5fc: c2060054 b.hs     #0x253f6d4
0253f600: f603002a mov      w22, w0
0253f604: 1f00086b cmp      w0, w8
0253f608: 62060054 b.hs     #0x253f6d4
0253f60c: e80340f9 ldr      x8, [sp]
0253f610: e90f40f9 ldr      x9, [sp, #0x18]
0253f614: da7e4093 sxtw     x26, w22
0253f618: 990e1a8b add      x25, x20, x26, lsl #3
0253f61c: 18797cf8 ldr      x24, [x8, x28, lsl #3]
0253f620: 37797cf8 ldr      x23, [x9, x28, lsl #3]
0253f624: 210f42f8 ldr      x1, [x25, #0x20]!
0253f628: 00011b8b add      x0, x8, x27
0253f62c: 01793cf8 str      x1, [x8, x28, lsl #3]
0253f630: 1fc7a997 bl       #0xfb12ac ; 
0253f634: 680e40f9 ldr      x8, [x19, #0x18]
0253f638: df02086b cmp      w22, w8
0253f63c: c2040054 b.hs     #0x253f6d4
0253f640: 7a0e1a8b add      x26, x19, x26, lsl #3
0253f644: 410f42f8 ldr      x1, [x26, #0x20]!
0253f648: 087d4092 and      x8, x8, #0xffffffff
0253f64c: bf0208eb cmp      x21, x8
0253f650: 22040054 b.hs     #0x253f6d4
0253f654: e80f40f9 ldr      x8, [sp, #0x18]
0253f658: 00011b8b add      x0, x8, x27
0253f65c: 01793cf8 str      x1, [x8, x28, lsl #3]
0253f660: 13c7a997 bl       #0xfb12ac ; 
0253f664: 881a40b9 ldr      w8, [x20, #0x18]
0253f668: df02086b cmp      w22, w8
0253f66c: 42030054 b.hs     #0x253f6d4
0253f670: e00319aa mov      x0, x25
0253f674: e10318aa mov      x1, x24
0253f678: 380300f9 str      x24, [x25]
0253f67c: 0cc7a997 bl       #0xfb12ac ; 
0253f680: 681a40b9 ldr      w8, [x19, #0x18]
0253f684: df02086b cmp      w22, w8
0253f688: 62020054 b.hs     #0x253f6d4
0253f68c: e0031aaa mov      x0, x26
0253f690: e10317aa mov      x1, x23
0253f694: 570300f9 str      x23, [x26]
0253f698: 05c7a997 bl       #0xfb12ac ; 
0253f69c: 9c0700d1 sub      x28, x28, #1
0253f6a0: a8031c8b add      x8, x29, x28
0253f6a4: 08050091 add      x8, x8, #1
0253f6a8: 1f0900f1 cmp      x8, #2
0253f6ac: 7b2300d1 sub      x27, x27, #8
0253f6b0: 4cf8ff54 b.gt     #0x253f5b8
0253f6b4: fd7b47a9 ldp      x29, x30, [sp, #0x70]
0253f6b8: f44f46a9 ldp      x20, x19, [sp, #0x60]
0253f6bc: f65745a9 ldp      x22, x21, [sp, #0x50]
0253f6c0: f85f44a9 ldp      x24, x23, [sp, #0x40]
0253f6c4: fa6743a9 ldp      x26, x25, [sp, #0x30]
0253f6c8: fc6f42a9 ldp      x28, x27, [sp, #0x20]
0253f6cc: ff030291 add      sp, sp, #0x80
0253f6d0: c0035fd6 ret      
0253f6d4: 57c7a997 bl       #0xfb1430 ; 
0253f6d8: 54c7a997 bl       #0xfb1428 ; 
