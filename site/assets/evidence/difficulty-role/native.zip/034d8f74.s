# Royal.Scenes.Home.Ui.Dialogs.DragonNest.Scripts.DragonNestConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
034d8f74: f60f1df8 str      x22, [sp, #-0x30]!
034d8f78: f55301a9 stp      x21, x20, [sp, #0x10]
034d8f7c: f37b02a9 stp      x19, x30, [sp, #0x20]
034d8f80: 740501f0 adrp     x20, #0x5587000
034d8f84: 887a4639 ldrb     w8, [x20, #0x19e]
034d8f88: f30300aa mov      x19, x0
034d8f8c: c8030037 tbnz     w8, #0, #0x34d9004
034d8f90: 40ea00d0 adrp     x0, #0x5222000
034d8f94: 00ec42f9 ldr      x0, [x0, #0x5d8]
034d8f98: da606b97 bl       #0xfb1300 ; 
034d8f9c: a0e80090 adrp     x0, #0x51ec000
034d8fa0: 00b442f9 ldr      x0, [x0, #0x568]
034d8fa4: d7606b97 bl       #0xfb1300 ; 
034d8fa8: 20e600d0 adrp     x0, #0x519e000
034d8fac: 002444f9 ldr      x0, [x0, #0x848]
034d8fb0: d4606b97 bl       #0xfb1300 ; 
034d8fb4: 60e90090 adrp     x0, #0x5204000
034d8fb8: 00bc47f9 ldr      x0, [x0, #0xf78]
034d8fbc: d1606b97 bl       #0xfb1300 ; 
034d8fc0: 00eb00f0 adrp     x0, #0x523b000
034d8fc4: 006842f9 ldr      x0, [x0, #0x4d0]
034d8fc8: ce606b97 bl       #0xfb1300 ; 
034d8fcc: 00eb0090 adrp     x0, #0x5238000
034d8fd0: 009446f9 ldr      x0, [x0, #0xd28]
034d8fd4: cb606b97 bl       #0xfb1300 ; 
034d8fd8: 00e800b0 adrp     x0, #0x51d9000
034d8fdc: 004447f9 ldr      x0, [x0, #0xe88]
034d8fe0: c8606b97 bl       #0xfb1300 ; 
034d8fe4: 00ea0090 adrp     x0, #0x5218000
034d8fe8: 008c41f9 ldr      x0, [x0, #0x318]
034d8fec: c5606b97 bl       #0xfb1300 ; 
034d8ff0: e0e90090 adrp     x0, #0x5214000
034d8ff4: 009045f9 ldr      x0, [x0, #0xb20]
034d8ff8: c2606b97 bl       #0xfb1300 ; 
034d8ffc: 28008052 mov      w8, #1
034d9000: 887a0639 strb     w8, [x20, #0x19e]
034d9004: 681240f9 ldr      x8, [x19, #0x20]
034d9008: 680e00b4 cbz      x8, #0x34d91d4
034d900c: 081140f9 ldr      x8, [x8, #0x20]
034d9010: 280e00b4 cbz      x8, #0x34d91d4
034d9014: 161940f9 ldr      x22, [x8, #0x30]
034d9018: f60d00b4 cbz      x22, #0x34d91d4
034d901c: c00a40f9 ldr      x0, [x22, #0x10]
034d9020: 14eb00d0 adrp     x20, #0x523b000
034d9024: 55ea00b0 adrp     x21, #0x5222000
034d9028: 946a42f9 ldr      x20, [x20, #0x4d0]
034d902c: b5ee42f9 ldr      x21, [x21, #0x5d8]
034d9030: e1031faa mov      x1, xzr
034d9034: dab8a097 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
034d9038: 60050036 tbz      w0, #0, #0x34d90e4
034d903c: 08e80090 adrp     x8, #0x51d9000
034d9040: e9ea00f0 adrp     x9, #0x5238000
034d9044: 084547f9 ldr      x8, [x8, #0xe88]
034d9048: 299546f9 ldr      x9, [x9, #0xd28]
034d904c: 000140f9 ldr      x0, [x8]
034d9050: 210140f9 ldr      x1, [x9]
034d9054: 23a3c397 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
034d9058: e00b00b4 cbz      x0, #0x34d91d4
034d905c: e1031faa mov      x1, xzr
034d9060: 4cab2094 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
034d9064: 810240f9 ldr      x1, [x20]
034d9068: d08cc197 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
034d906c: e10300aa mov      x1, x0
034d9070: e00313aa mov      x0, x19
034d9074: 010c01f8 str      x1, [x0, #0x10]!
034d9078: 8d606b97 bl       #0xfb12ac ; 
034d907c: b40240f9 ldr      x20, [x21]
034d9080: 881e40f9 ldr      x8, [x20, #0x38]
034d9084: 000140f9 ldr      x0, [x8]
034d9088: 08c84439 ldrb     w8, [x0, #0x132]
034d908c: 48000037 tbnz     w8, #0, #0x34d9094
034d9090: d59f6a97 bl       #0xf80fe4 ; 
034d9094: 08e040b9 ldr      w8, [x0, #0xe0]
034d9098: 48000035 cbnz     w8, #0x34d90a0
034d909c: da606b97 bl       #0xfb1404 ; 
034d90a0: 881e40f9 ldr      x8, [x20, #0x38]
034d90a4: f4e900f0 adrp     x20, #0x5218000
034d90a8: 000140f9 ldr      x0, [x8]
034d90ac: 08c84439 ldrb     w8, [x0, #0x132]
034d90b0: 948e41f9 ldr      x20, [x20, #0x318]
034d90b4: 48000037 tbnz     w8, #0, #0x34d90bc
034d90b8: cb9f6a97 bl       #0xf80fe4 ; 
034d90bc: 085c40f9 ldr      x8, [x0, #0xb8]
034d90c0: 820240f9 ldr      x2, [x20]
034d90c4: e00313aa mov      x0, x19
034d90c8: f37b42a9 ldp      x19, x30, [sp, #0x20]
034d90cc: 030140f9 ldr      x3, [x8]
034d90d0: f55341a9 ldp      x21, x20, [sp, #0x10]
034d90d4: c1058052 mov      w1, #0x2e
034d90d8: e4031faa mov      x4, xzr
034d90dc: f60743f8 ldr      x22, [sp], #0x30
034d90e0: 109ecc17 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
034d90e4: c00a40f9 ldr      x0, [x22, #0x10]
034d90e8: 810240f9 ldr      x1, [x20]
034d90ec: af8cc197 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
034d90f0: f40313aa mov      x20, x19
034d90f4: 800e01f8 str      x0, [x20, #0x10]!
034d90f8: e10300aa mov      x1, x0
034d90fc: e00314aa mov      x0, x20
034d9100: 6b606b97 bl       #0xfb12ac ; 
034d9104: 880a40f9 ldr      x8, [x20, #0x10]
034d9108: 680600b4 cbz      x8, #0x34d91d4
034d910c: 081140f9 ldr      x8, [x8, #0x20]
034d9110: 280600b4 cbz      x8, #0x34d91d4
034d9114: 081d40f9 ldr      x8, [x8, #0x38]
034d9118: e80500b4 cbz      x8, #0x34d91d4
034d911c: 890240f9 ldr      x9, [x20]
034d9120: a90500b4 cbz      x9, #0x34d91d4
034d9124: 081140b9 ldr      w8, [x8, #0x10]
034d9128: 4ae900f0 adrp     x10, #0x5204000
034d912c: 4abd47f9 ldr      x10, [x10, #0xf78]
034d9130: d4e900f0 adrp     x20, #0x5214000
034d9134: 281100b9 str      w8, [x9, #0x10]
034d9138: e1330091 add      x1, sp, #0xc
034d913c: 400140f9 ldr      x0, [x10]
034d9140: 949245f9 ldr      x20, [x20, #0xb20]
034d9144: e80f00b9 str      w8, [sp, #0xc]
034d9148: b1606b97 bl       #0xfb140c ; 
034d914c: 880240f9 ldr      x8, [x20]
034d9150: e10300aa mov      x1, x0
034d9154: e2031faa mov      x2, xzr
034d9158: e00308aa mov      x0, x8
034d915c: 9f93a097 bl       #0x1cfdfd8 ; System.String$$Format
034d9160: b50240f9 ldr      x21, [x21]
034d9164: f40300aa mov      x20, x0
034d9168: a81e40f9 ldr      x8, [x21, #0x38]
034d916c: 080140f9 ldr      x8, [x8]
034d9170: 09c94439 ldrb     w9, [x8, #0x132]
034d9174: 89000037 tbnz     w9, #0, #0x34d9184
034d9178: e00308aa mov      x0, x8
034d917c: 9a9f6a97 bl       #0xf80fe4 ; 
034d9180: e80300aa mov      x8, x0
034d9184: 09e140b9 ldr      w9, [x8, #0xe0]
034d9188: 69000035 cbnz     w9, #0x34d9194
034d918c: e00308aa mov      x0, x8
034d9190: 9d606b97 bl       #0xfb1404 ; 
034d9194: a81e40f9 ldr      x8, [x21, #0x38]
034d9198: 000140f9 ldr      x0, [x8]
034d919c: 08c84439 ldrb     w8, [x0, #0x132]
034d91a0: 48000037 tbnz     w8, #0, #0x34d91a8
034d91a4: 909f6a97 bl       #0xf80fe4 ; 
034d91a8: 085c40f9 ldr      x8, [x0, #0xb8]
034d91ac: c1058052 mov      w1, #0x2e
034d91b0: e00313aa mov      x0, x19
034d91b4: e20314aa mov      x2, x20
034d91b8: 030140f9 ldr      x3, [x8]
034d91bc: e4031faa mov      x4, xzr
034d91c0: d89dcc97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
034d91c4: f37b42a9 ldp      x19, x30, [sp, #0x20]
034d91c8: f55341a9 ldp      x21, x20, [sp, #0x10]
034d91cc: f60743f8 ldr      x22, [sp], #0x30
034d91d0: c0035fd6 ret      
034d91d4: 95606b97 bl       #0xfb1428 ; 
