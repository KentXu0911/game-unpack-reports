# Royal.Scenes.Home.Ui.Dialogs.PropellerRush.Scripts.PropellerRushConfigHelper$$LoadUserConfig
# Linear metadata span, not a recovered full CFG.
03c56da4: ff0301d1 sub      sp, sp, #0x40
03c56da8: f75b01a9 stp      x23, x22, [sp, #0x10]
03c56dac: f55302a9 stp      x21, x20, [sp, #0x20]
03c56db0: f37b03a9 stp      x19, x30, [sp, #0x30]
03c56db4: b4c900b0 adrp     x20, #0x558b000
03c56db8: 884e6039 ldrb     w8, [x20, #0x813]
03c56dbc: f30300aa mov      x19, x0
03c56dc0: e8040037 tbnz     w8, #0, #0x3c56e5c
03c56dc4: 60ae0090 adrp     x0, #0x5222000
03c56dc8: 00ec42f9 ldr      x0, [x0, #0x5d8]
03c56dcc: 4d694d97 bl       #0xfb1300 ; 
03c56dd0: 40ad0090 adrp     x0, #0x51fe000
03c56dd4: 004042f9 ldr      x0, [x0, #0x480]
03c56dd8: 4a694d97 bl       #0xfb1300 ; 
03c56ddc: 80ad00f0 adrp     x0, #0x5209000
03c56de0: 006845f9 ldr      x0, [x0, #0xad0]
03c56de4: 47694d97 bl       #0xfb1300 ; 
03c56de8: 00ae0090 adrp     x0, #0x5216000
03c56dec: 001c44f9 ldr      x0, [x0, #0x838]
03c56df0: 44694d97 bl       #0xfb1300 ; 
03c56df4: 80ac0090 adrp     x0, #0x51e6000
03c56df8: 007840f9 ldr      x0, [x0, #0xf0]
03c56dfc: 41694d97 bl       #0xfb1300 ; 
03c56e00: 60ad00d0 adrp     x0, #0x5204000
03c56e04: 00bc47f9 ldr      x0, [x0, #0xf78]
03c56e08: 3e694d97 bl       #0xfb1300 ; 
03c56e0c: e0aa00d0 adrp     x0, #0x51b4000
03c56e10: 008443f9 ldr      x0, [x0, #0x708]
03c56e14: 3b694d97 bl       #0xfb1300 ; 
03c56e18: 00af00d0 adrp     x0, #0x5238000
03c56e1c: 009446f9 ldr      x0, [x0, #0xd28]
03c56e20: 38694d97 bl       #0xfb1300 ; 
03c56e24: c0ae00d0 adrp     x0, #0x5230000
03c56e28: 009043f9 ldr      x0, [x0, #0x720]
03c56e2c: 35694d97 bl       #0xfb1300 ; 
03c56e30: 40ae00d0 adrp     x0, #0x5220000
03c56e34: 000443f9 ldr      x0, [x0, #0x608]
03c56e38: 32694d97 bl       #0xfb1300 ; 
03c56e3c: a0ad00d0 adrp     x0, #0x520c000
03c56e40: 00d043f9 ldr      x0, [x0, #0x7a0]
03c56e44: 2f694d97 bl       #0xfb1300 ; 
03c56e48: c0ab00f0 adrp     x0, #0x51d1000
03c56e4c: 000445f9 ldr      x0, [x0, #0xa08]
03c56e50: 2c694d97 bl       #0xfb1300 ; 
03c56e54: 28008052 mov      w8, #1
03c56e58: 884e2039 strb     w8, [x20, #0x813]
03c56e5c: 601640f9 ldr      x0, [x19, #0x28]
03c56e60: 001400b4 cbz      x0, #0x3c570e0
03c56e64: e1031faa mov      x1, xzr
03c56e68: 4e12d597 bl       #0x319b7a0 ; Royal.Player.Context.Units.PropellerRushManager$$IsThereEnteredEvent
03c56e6c: 00070036 tbz      w0, #0, #0x3c56f4c
03c56e70: 681640f9 ldr      x8, [x19, #0x28]
03c56e74: 681300b4 cbz      x8, #0x3c570e0
03c56e78: 081140f9 ldr      x8, [x8, #0x20]
03c56e7c: 281300b4 cbz      x8, #0x3c570e0
03c56e80: 161940f9 ldr      x22, [x8, #0x30]
03c56e84: f61200b4 cbz      x22, #0x3c570e0
03c56e88: c00a40f9 ldr      x0, [x22, #0x10]
03c56e8c: f4aa00d0 adrp     x20, #0x51b4000
03c56e90: 75ae0090 adrp     x21, #0x5222000
03c56e94: 948643f9 ldr      x20, [x20, #0x708]
03c56e98: b5ee42f9 ldr      x21, [x21, #0x5d8]
03c56e9c: e1031faa mov      x1, xzr
03c56ea0: 3fc18297 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
03c56ea4: e0050036 tbz      w0, #0, #0x3c56f60
03c56ea8: b50240f9 ldr      x21, [x21]
03c56eac: a81e40f9 ldr      x8, [x21, #0x38]
03c56eb0: 000140f9 ldr      x0, [x8]
03c56eb4: 08c84439 ldrb     w8, [x0, #0x132]
03c56eb8: 48000037 tbnz     w8, #0, #0x3c56ec0
03c56ebc: 4aa84c97 bl       #0xf80fe4 ; 
03c56ec0: 08e040b9 ldr      w8, [x0, #0xe0]
03c56ec4: 48000035 cbnz     w8, #0x3c56ecc
03c56ec8: 4f694d97 bl       #0xfb1404 ; 
03c56ecc: a81e40f9 ldr      x8, [x21, #0x38]
03c56ed0: d7ab00f0 adrp     x23, #0x51d1000
03c56ed4: b6ad00d0 adrp     x22, #0x520c000
03c56ed8: 15af00d0 adrp     x21, #0x5238000
03c56edc: 000140f9 ldr      x0, [x8]
03c56ee0: 08c84439 ldrb     w8, [x0, #0x132]
03c56ee4: f70645f9 ldr      x23, [x23, #0xa08]
03c56ee8: d6d243f9 ldr      x22, [x22, #0x7a0]
03c56eec: b59646f9 ldr      x21, [x21, #0xd28]
03c56ef0: 48000037 tbnz     w8, #0, #0x3c56ef8
03c56ef4: 3ca84c97 bl       #0xf80fe4 ; 
03c56ef8: 085c40f9 ldr      x8, [x0, #0xb8]
03c56efc: e20240f9 ldr      x2, [x23]
03c56f00: a1098052 mov      w1, #0x4d
03c56f04: e00313aa mov      x0, x19
03c56f08: 030140f9 ldr      x3, [x8]
03c56f0c: e4031faa mov      x4, xzr
03c56f10: 84a6ae97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03c56f14: c00240f9 ldr      x0, [x22]
03c56f18: a10240f9 ldr      x1, [x21]
03c56f1c: 71aba597 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
03c56f20: 000e00b4 cbz      x0, #0x3c570e0
03c56f24: e1031faa mov      x1, xzr
03c56f28: 9ab30294 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
03c56f2c: 810240f9 ldr      x1, [x20]
03c56f30: 1e95a397 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03c56f34: 600e02f8 str      x0, [x19, #0x20]!
03c56f38: e10300aa mov      x1, x0
03c56f3c: e00313aa mov      x0, x19
03c56f40: db684d97 bl       #0xfb12ac ; 
03c56f44: 28008052 mov      w8, #1
03c56f48: 68121f38 sturb    w8, [x19, #-0xf]
03c56f4c: f37b43a9 ldp      x19, x30, [sp, #0x30]
03c56f50: f55342a9 ldp      x21, x20, [sp, #0x20]
03c56f54: f75b41a9 ldp      x23, x22, [sp, #0x10]
03c56f58: ff030191 add      sp, sp, #0x40
03c56f5c: c0035fd6 ret      
03c56f60: c00a40f9 ldr      x0, [x22, #0x10]
03c56f64: 810240f9 ldr      x1, [x20]
03c56f68: 1095a397 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
03c56f6c: 600800b4 cbz      x0, #0x3c57078
03c56f70: 080c40f9 ldr      x8, [x0, #0x18]
03c56f74: e10300aa mov      x1, x0
03c56f78: 080800b4 cbz      x8, #0x3c57078
03c56f7c: 081940b9 ldr      w8, [x8, #0x18]
03c56f80: 1f090071 cmp      w8, #2
03c56f84: a1070054 b.ne     #0x3c57078
03c56f88: 281040f9 ldr      x8, [x1, #0x20]
03c56f8c: 680700b4 cbz      x8, #0x3c57078
03c56f90: 081940b9 ldr      w8, [x8, #0x18]
03c56f94: 1f090071 cmp      w8, #2
03c56f98: 01070054 b.ne     #0x3c57078
03c56f9c: f40313aa mov      x20, x19
03c56fa0: 810e02f8 str      x1, [x20, #0x20]!
03c56fa4: e00314aa mov      x0, x20
03c56fa8: c1684d97 bl       #0xfb12ac ; 
03c56fac: 880640f9 ldr      x8, [x20, #8]
03c56fb0: 880900b4 cbz      x8, #0x3c570e0
03c56fb4: 081140f9 ldr      x8, [x8, #0x20]
03c56fb8: 480900b4 cbz      x8, #0x3c570e0
03c56fbc: 081d40f9 ldr      x8, [x8, #0x38]
03c56fc0: 080900b4 cbz      x8, #0x3c570e0
03c56fc4: 890240f9 ldr      x9, [x20]
03c56fc8: c90800b4 cbz      x9, #0x3c570e0
03c56fcc: 081140b9 ldr      w8, [x8, #0x10]
03c56fd0: 6aad00d0 adrp     x10, #0x5204000
03c56fd4: 4abd47f9 ldr      x10, [x10, #0xf78]
03c56fd8: 2b008052 mov      w11, #1
03c56fdc: 281100b9 str      w8, [x9, #0x10]
03c56fe0: 6b460039 strb     w11, [x19, #0x11]
03c56fe4: 400140f9 ldr      x0, [x10]
03c56fe8: 54ae00d0 adrp     x20, #0x5220000
03c56fec: 940643f9 ldr      x20, [x20, #0x608]
03c56ff0: e1330091 add      x1, sp, #0xc
03c56ff4: e80f00b9 str      w8, [sp, #0xc]
03c56ff8: 05694d97 bl       #0xfb140c ; 
03c56ffc: 880240f9 ldr      x8, [x20]
03c57000: e10300aa mov      x1, x0
03c57004: e2031faa mov      x2, xzr
03c57008: e00308aa mov      x0, x8
03c5700c: f39b8297 bl       #0x1cfdfd8 ; System.String$$Format
03c57010: b50240f9 ldr      x21, [x21]
03c57014: f40300aa mov      x20, x0
03c57018: a81e40f9 ldr      x8, [x21, #0x38]
03c5701c: 080140f9 ldr      x8, [x8]
03c57020: 09c94439 ldrb     w9, [x8, #0x132]
03c57024: 89000037 tbnz     w9, #0, #0x3c57034
03c57028: e00308aa mov      x0, x8
03c5702c: eea74c97 bl       #0xf80fe4 ; 
03c57030: e80300aa mov      x8, x0
03c57034: 09e140b9 ldr      w9, [x8, #0xe0]
03c57038: 69000035 cbnz     w9, #0x3c57044
03c5703c: e00308aa mov      x0, x8
03c57040: f1684d97 bl       #0xfb1404 ; 
03c57044: a81e40f9 ldr      x8, [x21, #0x38]
03c57048: 000140f9 ldr      x0, [x8]
03c5704c: 08c84439 ldrb     w8, [x0, #0x132]
03c57050: 48000037 tbnz     w8, #0, #0x3c57058
03c57054: e4a74c97 bl       #0xf80fe4 ; 
03c57058: 085c40f9 ldr      x8, [x0, #0xb8]
03c5705c: a1098052 mov      w1, #0x4d
03c57060: e00313aa mov      x0, x19
03c57064: e20314aa mov      x2, x20
03c57068: 030140f9 ldr      x3, [x8]
03c5706c: e4031faa mov      x4, xzr
03c57070: 2ca6ae97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
03c57074: b6ffff17 b        #0x3c56f4c ; 
03c57078: e8ad00f0 adrp     x8, #0x5216000
03c5707c: 081d44f9 ldr      x8, [x8, #0x838]
03c57080: 000140f9 ldr      x0, [x8]
03c57084: e5684d97 bl       #0xfb1418 ; 
03c57088: c00200b4 cbz      x0, #0x3c570e0
03c5708c: c8ae00b0 adrp     x8, #0x5230000
03c57090: 089143f9 ldr      x8, [x8, #0x720]
03c57094: 74ac00f0 adrp     x20, #0x51e6000
03c57098: e2031faa mov      x2, xzr
03c5709c: f30300aa mov      x19, x0
03c570a0: 010140f9 ldr      x1, [x8]
03c570a4: 947a40f9 ldr      x20, [x20, #0xf0]
03c570a8: 86419897 bl       #0x22676c0 ; System.Exception$$.ctor
03c570ac: 800240f9 ldr      x0, [x20]
03c570b0: 08e040b9 ldr      w8, [x0, #0xe0]
03c570b4: 48000035 cbnz     w8, #0x3c570bc
03c570b8: d3684d97 bl       #0xfb1404 ; 
03c570bc: e00313aa mov      x0, x19
03c570c0: f37b43a9 ldp      x19, x30, [sp, #0x30]
03c570c4: f55342a9 ldp      x21, x20, [sp, #0x20]
03c570c8: f75b41a9 ldp      x23, x22, [sp, #0x10]
03c570cc: a1098052 mov      w1, #0x4d
03c570d0: e2031faa mov      x2, xzr
03c570d4: e3031faa mov      x3, xzr
03c570d8: ff030191 add      sp, sp, #0x40
03c570dc: c209c817 b        #0x2e597e4 ; Royal.Infrastructure.Services.Remote.FirebaseHelper$$LogException
03c570e0: d2684d97 bl       #0xfb1428 ; 
