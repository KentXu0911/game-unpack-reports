# Royal.Scenes.Home.Ui.Dialogs.WeeklyPass.Scripts.WeeklyPassConfigHelper$$LoadServerConfig
# Linear metadata span, not a recovered full CFG.
02c4d4f8: f60f1df8 str      x22, [sp, #-0x30]!
02c4d4fc: f55301a9 stp      x21, x20, [sp, #0x10]
02c4d500: f37b02a9 stp      x19, x30, [sp, #0x20]
02c4d504: b44901d0 adrp     x20, #0x5583000
02c4d508: 88da7639 ldrb     w8, [x20, #0xdb6]
02c4d50c: f30300aa mov      x19, x0
02c4d510: c8030037 tbnz     w8, #0, #0x2c4d588
02c4d514: a02e01b0 adrp     x0, #0x5222000
02c4d518: 00ec42f9 ldr      x0, [x0, #0x5d8]
02c4d51c: 798f8d97 bl       #0xfb1300 ; 
02c4d520: c02e01f0 adrp     x0, #0x5228000
02c4d524: 001840f9 ldr      x0, [x0, #0x30]
02c4d528: 768f8d97 bl       #0xfb1300 ; 
02c4d52c: 202a01f0 adrp     x0, #0x5194000
02c4d530: 002443f9 ldr      x0, [x0, #0x648]
02c4d534: 738f8d97 bl       #0xfb1300 ; 
02c4d538: a02d01f0 adrp     x0, #0x5204000
02c4d53c: 00bc47f9 ldr      x0, [x0, #0xf78]
02c4d540: 708f8d97 bl       #0xfb1300 ; 
02c4d544: 402e01b0 adrp     x0, #0x5216000
02c4d548: 003842f9 ldr      x0, [x0, #0x470]
02c4d54c: 6d8f8d97 bl       #0xfb1300 ; 
02c4d550: 402f01f0 adrp     x0, #0x5238000
02c4d554: 009446f9 ldr      x0, [x0, #0xd28]
02c4d558: 6a8f8d97 bl       #0xfb1300 ; 
02c4d55c: 802e01d0 adrp     x0, #0x521f000
02c4d560: 003443f9 ldr      x0, [x0, #0x668]
02c4d564: 678f8d97 bl       #0xfb1300 ; 
02c4d568: 002e0190 adrp     x0, #0x520d000
02c4d56c: 002847f9 ldr      x0, [x0, #0xe50]
02c4d570: 648f8d97 bl       #0xfb1300 ; 
02c4d574: 602b0190 adrp     x0, #0x51b9000
02c4d578: 00e840f9 ldr      x0, [x0, #0x1d0]
02c4d57c: 618f8d97 bl       #0xfb1300 ; 
02c4d580: 28008052 mov      w8, #1
02c4d584: 88da3639 strb     w8, [x20, #0xdb6]
02c4d588: 680a40f9 ldr      x8, [x19, #0x10]
02c4d58c: e80d00b4 cbz      x8, #0x2c4d748
02c4d590: 161540f9 ldr      x22, [x8, #0x28]
02c4d594: b60d00b4 cbz      x22, #0x2c4d748
02c4d598: c00a40f9 ldr      x0, [x22, #0x10]
02c4d59c: 542e01b0 adrp     x20, #0x5216000
02c4d5a0: b52e01b0 adrp     x21, #0x5222000
02c4d5a4: 943a42f9 ldr      x20, [x20, #0x470]
02c4d5a8: b5ee42f9 ldr      x21, [x21, #0x5d8]
02c4d5ac: e1031faa mov      x1, xzr
02c4d5b0: 7be7c297 bl       #0x1d0739c ; System.String$$IsNullOrEmpty
02c4d5b4: 60050036 tbz      w0, #0, #0x2c4d660
02c4d5b8: 882e01d0 adrp     x8, #0x521f000
02c4d5bc: 492f01f0 adrp     x9, #0x5238000
02c4d5c0: 083543f9 ldr      x8, [x8, #0x668]
02c4d5c4: 299546f9 ldr      x9, [x9, #0xd28]
02c4d5c8: 000140f9 ldr      x0, [x8]
02c4d5cc: 210140f9 ldr      x1, [x9]
02c4d5d0: c4d1e597 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
02c4d5d4: a00b00b4 cbz      x0, #0x2c4d748
02c4d5d8: e1031faa mov      x1, xzr
02c4d5dc: edd94294 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
02c4d5e0: 810240f9 ldr      x1, [x20]
02c4d5e4: 71bbe397 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02c4d5e8: e10300aa mov      x1, x0
02c4d5ec: e00313aa mov      x0, x19
02c4d5f0: 010c02f8 str      x1, [x0, #0x20]!
02c4d5f4: 2e8f8d97 bl       #0xfb12ac ; 
02c4d5f8: b40240f9 ldr      x20, [x21]
02c4d5fc: 881e40f9 ldr      x8, [x20, #0x38]
02c4d600: 000140f9 ldr      x0, [x8]
02c4d604: 08c84439 ldrb     w8, [x0, #0x132]
02c4d608: 48000037 tbnz     w8, #0, #0x2c4d610
02c4d60c: 76ce8c97 bl       #0xf80fe4 ; 
02c4d610: 08e040b9 ldr      w8, [x0, #0xe0]
02c4d614: 48000035 cbnz     w8, #0x2c4d61c
02c4d618: 7b8f8d97 bl       #0xfb1404 ; 
02c4d61c: 881e40f9 ldr      x8, [x20, #0x38]
02c4d620: 742b0190 adrp     x20, #0x51b9000
02c4d624: 000140f9 ldr      x0, [x8]
02c4d628: 08c84439 ldrb     w8, [x0, #0x132]
02c4d62c: 94ea40f9 ldr      x20, [x20, #0x1d0]
02c4d630: 48000037 tbnz     w8, #0, #0x2c4d638
02c4d634: 6cce8c97 bl       #0xf80fe4 ; 
02c4d638: 085c40f9 ldr      x8, [x0, #0xb8]
02c4d63c: 820240f9 ldr      x2, [x20]
02c4d640: e00313aa mov      x0, x19
02c4d644: f37b42a9 ldp      x19, x30, [sp, #0x20]
02c4d648: 030140f9 ldr      x3, [x8]
02c4d64c: f55341a9 ldp      x21, x20, [sp, #0x10]
02c4d650: 81098052 mov      w1, #0x4c
02c4d654: e4031faa mov      x4, xzr
02c4d658: f60743f8 ldr      x22, [sp], #0x30
02c4d65c: b1ccee17 b        #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02c4d660: c00a40f9 ldr      x0, [x22, #0x10]
02c4d664: 810240f9 ldr      x1, [x20]
02c4d668: 50bbe397 bl       #0x253c3a8 ; UnityEngine.JsonUtility$$FromJson<object>
02c4d66c: f40313aa mov      x20, x19
02c4d670: 800e02f8 str      x0, [x20, #0x20]!
02c4d674: e10300aa mov      x1, x0
02c4d678: e00314aa mov      x0, x20
02c4d67c: 0c8f8d97 bl       #0xfb12ac ; 
02c4d680: 88025ff8 ldur     x8, [x20, #-0x10]
02c4d684: 280600b4 cbz      x8, #0x2c4d748
02c4d688: 081940f9 ldr      x8, [x8, #0x30]
02c4d68c: e80500b4 cbz      x8, #0x2c4d748
02c4d690: 890240f9 ldr      x9, [x20]
02c4d694: a90500b4 cbz      x9, #0x2c4d748
02c4d698: 081140b9 ldr      w8, [x8, #0x10]
02c4d69c: aa2d01f0 adrp     x10, #0x5204000
02c4d6a0: 4abd47f9 ldr      x10, [x10, #0xf78]
02c4d6a4: 142e0190 adrp     x20, #0x520d000
02c4d6a8: 281100b9 str      w8, [x9, #0x10]
02c4d6ac: e1330091 add      x1, sp, #0xc
02c4d6b0: 400140f9 ldr      x0, [x10]
02c4d6b4: 942a47f9 ldr      x20, [x20, #0xe50]
02c4d6b8: e80f00b9 str      w8, [sp, #0xc]
02c4d6bc: 548f8d97 bl       #0xfb140c ; 
02c4d6c0: 880240f9 ldr      x8, [x20]
02c4d6c4: e10300aa mov      x1, x0
02c4d6c8: e2031faa mov      x2, xzr
02c4d6cc: e00308aa mov      x0, x8
02c4d6d0: 42c2c297 bl       #0x1cfdfd8 ; System.String$$Format
02c4d6d4: b50240f9 ldr      x21, [x21]
02c4d6d8: f40300aa mov      x20, x0
02c4d6dc: a81e40f9 ldr      x8, [x21, #0x38]
02c4d6e0: 080140f9 ldr      x8, [x8]
02c4d6e4: 09c94439 ldrb     w9, [x8, #0x132]
02c4d6e8: 89000037 tbnz     w9, #0, #0x2c4d6f8
02c4d6ec: e00308aa mov      x0, x8
02c4d6f0: 3dce8c97 bl       #0xf80fe4 ; 
02c4d6f4: e80300aa mov      x8, x0
02c4d6f8: 09e140b9 ldr      w9, [x8, #0xe0]
02c4d6fc: 69000035 cbnz     w9, #0x2c4d708
02c4d700: e00308aa mov      x0, x8
02c4d704: 408f8d97 bl       #0xfb1404 ; 
02c4d708: a81e40f9 ldr      x8, [x21, #0x38]
02c4d70c: 000140f9 ldr      x0, [x8]
02c4d710: 08c84439 ldrb     w8, [x0, #0x132]
02c4d714: 48000037 tbnz     w8, #0, #0x2c4d71c
02c4d718: 33ce8c97 bl       #0xf80fe4 ; 
02c4d71c: 085c40f9 ldr      x8, [x0, #0xb8]
02c4d720: 81098052 mov      w1, #0x4c
02c4d724: e00313aa mov      x0, x19
02c4d728: e20314aa mov      x2, x20
02c4d72c: 030140f9 ldr      x3, [x8]
02c4d730: e4031faa mov      x4, xzr
02c4d734: 7bccee97 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02c4d738: f37b42a9 ldp      x19, x30, [sp, #0x20]
02c4d73c: f55341a9 ldp      x21, x20, [sp, #0x10]
02c4d740: f60743f8 ldr      x22, [sp], #0x30
02c4d744: c0035fd6 ret      
02c4d748: 388f8d97 bl       #0xfb1428 ; 
