# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$NextBool
# Linear metadata span, not a recovered full CFG.
02a31008: fe0f1ff8 str      x30, [sp, #-0x10]!
02a3100c: 001840f9 ldr      x0, [x0, #0x30]
02a31010: 400100b4 cbz      x0, #0x2a31038
02a31014: 080040f9 ldr      x8, [x0]
02a31018: 42008052 mov      w2, #2
02a3101c: e1031f2a mov      w1, wzr
02a31020: 098d59a9 ldp      x9, x3, [x8, #0x198]
02a31024: 20013fd6 blr      x9
02a31028: 1f000071 cmp      w0, #0
02a3102c: e0179f1a cset     w0, eq
02a31030: fe0741f8 ldr      x30, [sp], #0x10
02a31034: c0035fd6 ret      
02a31038: fc009697 bl       #0xfb1428 ; 
