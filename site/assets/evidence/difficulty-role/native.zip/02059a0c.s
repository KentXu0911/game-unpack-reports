# Royal.Player.Context.Units.LevelEpisodeHelper$$.ctor
# Linear metadata span, not a recovered full CFG.
02059a0c: f553bea9 stp      x21, x20, [sp, #-0x20]!
02059a10: f37b01a9 stp      x19, x30, [sp, #0x10]
02059a14: 35a90190 adrp     x21, #0x557d000
02059a18: b48b01f0 adrp     x20, #0x51d0000
02059a1c: a81a4839 ldrb     w8, [x21, #0x206]
02059a20: 94ca41f9 ldr      x20, [x20, #0x390]
02059a24: f30300aa mov      x19, x0
02059a28: c8000037 tbnz     w8, #0, #0x2059a40
02059a2c: a08b01f0 adrp     x0, #0x51d0000
02059a30: 00c841f9 ldr      x0, [x0, #0x390]
02059a34: 335ebd97 bl       #0xfb1300 ; 
02059a38: 28008052 mov      w8, #1
02059a3c: a81a0839 strb     w8, [x21, #0x206]
02059a40: e00313aa mov      x0, x19
02059a44: e1031faa mov      x1, xzr
02059a48: eb660894 bl       #0x22735f4 ; System.Object$$.ctor
02059a4c: 800240f9 ldr      x0, [x20]
02059a50: 725ebd97 bl       #0xfb1418 ; 
02059a54: 400100b4 cbz      x0, #0x2059a7c
02059a58: e1031faa mov      x1, xzr
02059a5c: f40300aa mov      x20, x0
02059a60: 9aaef097 bl       #0x1c854c8 ; Royal.Player.Context.Units.SemiDynamicDifficulty$$.ctor
02059a64: 740e01f8 str      x20, [x19, #0x10]!
02059a68: e00313aa mov      x0, x19
02059a6c: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059a70: e10314aa mov      x1, x20
02059a74: f553c2a8 ldp      x21, x20, [sp], #0x20
02059a78: 0d5ebd17 b        #0xfb12ac ; 
02059a7c: 6b5ebd97 bl       #0xfb1428 ; 
