# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArrays<object, int>
# Linear metadata span, not a recovered full CFG.
0253f3e8: ff4302d1 sub      sp, sp, #0x90
0253f3ec: fc6f03a9 stp      x28, x27, [sp, #0x30]
0253f3f0: fa6704a9 stp      x26, x25, [sp, #0x40]
0253f3f4: f85f05a9 stp      x24, x23, [sp, #0x50]
0253f3f8: f65706a9 stp      x22, x21, [sp, #0x60]
0253f3fc: f44f07a9 stp      x20, x19, [sp, #0x70]
0253f400: fd7b08a9 stp      x29, x30, [sp, #0x80]
0253f404: 7f080071 cmp      w3, #2
0253f408: e01300f9 str      x0, [sp, #0x20]
0253f40c: 4b090054 b.lt     #0x253f534
0253f410: 6a7c4093 sxtw     x10, w3
0253f414: e803032a mov      w8, w3
0253f418: e82b01a9 stp      x8, x10, [sp, #0x10]
0253f41c: 28cc238b add      x8, x1, w3, sxtw #3
0253f420: 49c8238b add      x9, x2, w3, sxtw #2
0253f424: f30302aa mov      x19, x2
0253f428: f40301aa mov      x20, x1
0253f42c: f9031faa mov      x25, xzr
0253f430: fa031faa mov      x26, xzr
0253f434: 4a050091 add      x10, x10, #1
0253f438: 15610091 add      x21, x8, #0x18
0253f43c: 28710091 add      x8, x9, #0x1c
0253f440: ea0700f9 str      x10, [sp, #8]
0253f444: e81700f9 str      x8, [sp, #0x28]
0253f448: e81340f9 ldr      x8, [sp, #0x20]
0253f44c: 001940f9 ldr      x0, [x8, #0x30]
0253f450: 400800b4 cbz      x0, #0x253f558
0253f454: 080040f9 ldr      x8, [x0]
0253f458: 09895aa9 ldp      x9, x2, [x8, #0x1a8]
0253f45c: e80b40f9 ldr      x8, [sp, #0x10]
0253f460: 01011a0b add      w1, w8, w26
0253f464: 20013fd6 blr      x9
0253f468: 940700b4 cbz      x20, #0x253f558
0253f46c: e90f40f9 ldr      x9, [sp, #0x18]
0253f470: 880e40f9 ldr      x8, [x20, #0x18]
0253f474: 29011a8b add      x9, x9, x26
0253f478: 3d0500d1 sub      x29, x9, #1
0253f47c: bf4328eb cmp      x29, w8, uxtw
0253f480: a2060054 b.hs     #0x253f554
0253f484: b30600b4 cbz      x19, #0x253f558
0253f488: 691a40b9 ldr      w9, [x19, #0x18]
0253f48c: bf0309eb cmp      x29, x9
0253f490: 22060054 b.hs     #0x253f554
0253f494: f603002a mov      w22, w0
0253f498: 1f00086b cmp      w0, w8
0253f49c: c2050054 b.hs     #0x253f554
0253f4a0: e81740f9 ldr      x8, [sp, #0x28]
0253f4a4: dc7e4093 sxtw     x28, w22
0253f4a8: 980e1c8b add      x24, x20, x28, lsl #3
0253f4ac: b77a7af8 ldr      x23, [x21, x26, lsl #3]
0253f4b0: 1b797ab8 ldr      w27, [x8, x26, lsl #2]
0253f4b4: 010f42f8 ldr      x1, [x24, #0x20]!
0253f4b8: a002198b add      x0, x21, x25
0253f4bc: a17a3af8 str      x1, [x21, x26, lsl #3]
0253f4c0: 7bc7a997 bl       #0xfb12ac ; 
0253f4c4: 680e40f9 ldr      x8, [x19, #0x18]
0253f4c8: df02086b cmp      w22, w8
0253f4cc: 42040054 b.hs     #0x253f554
0253f4d0: 087d4092 and      x8, x8, #0xffffffff
0253f4d4: bf0308eb cmp      x29, x8
0253f4d8: e2030054 b.hs     #0x253f554
0253f4dc: 680a1c8b add      x8, x19, x28, lsl #2
0253f4e0: 1c810091 add      x28, x8, #0x20
0253f4e4: 880340b9 ldr      w8, [x28]
0253f4e8: e91740f9 ldr      x9, [sp, #0x28]
0253f4ec: 28793ab8 str      w8, [x9, x26, lsl #2]
0253f4f0: 881a40b9 ldr      w8, [x20, #0x18]
0253f4f4: df02086b cmp      w22, w8
0253f4f8: e2020054 b.hs     #0x253f554
0253f4fc: e00318aa mov      x0, x24
0253f500: e10317aa mov      x1, x23
0253f504: 170300f9 str      x23, [x24]
0253f508: 69c7a997 bl       #0xfb12ac ; 
0253f50c: 681a40b9 ldr      w8, [x19, #0x18]
0253f510: df02086b cmp      w22, w8
0253f514: 02020054 b.hs     #0x253f554
0253f518: e80740f9 ldr      x8, [sp, #8]
0253f51c: 5a0700d1 sub      x26, x26, #1
0253f520: 392300d1 sub      x25, x25, #8
0253f524: 9b0300b9 str      w27, [x28]
0253f528: 08011a8b add      x8, x8, x26
0253f52c: 1f0900f1 cmp      x8, #2
0253f530: ccf8ff54 b.gt     #0x253f448
0253f534: fd7b48a9 ldp      x29, x30, [sp, #0x80]
0253f538: f44f47a9 ldp      x20, x19, [sp, #0x70]
0253f53c: f65746a9 ldp      x22, x21, [sp, #0x60]
0253f540: f85f45a9 ldp      x24, x23, [sp, #0x50]
0253f544: fa6744a9 ldp      x26, x25, [sp, #0x40]
0253f548: fc6f43a9 ldp      x28, x27, [sp, #0x30]
0253f54c: ff430291 add      sp, sp, #0x90
0253f550: c0035fd6 ret      
0253f554: b7c7a997 bl       #0xfb1430 ; 
0253f558: b4c7a997 bl       #0xfb1428 ; 
