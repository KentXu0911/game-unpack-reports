# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GenerateTrySeeds
# Linear metadata span, not a recovered full CFG.
02a3116c: ff4301d1 sub      sp, sp, #0x50
02a31170: f96301a9 stp      x25, x24, [sp, #0x10]
02a31174: f75b02a9 stp      x23, x22, [sp, #0x20]
02a31178: f55303a9 stp      x21, x20, [sp, #0x30]
02a3117c: f37b04a9 stp      x19, x30, [sp, #0x40]
02a31180: 955a0190 adrp     x21, #0x5581000
02a31184: a8be7a39 ldrb     w8, [x21, #0xeaf]
02a31188: f403012a mov      w20, w1
02a3118c: f30300aa mov      x19, x0
02a31190: a8020037 tbnz     w8, #0, #0x2a311e4
02a31194: 803e01f0 adrp     x0, #0x5204000
02a31198: 00bc47f9 ldr      x0, [x0, #0xf78]
02a3119c: 59009697 bl       #0xfb1300 ; 
02a311a0: a03e01b0 adrp     x0, #0x5206000
02a311a4: 004c46f9 ldr      x0, [x0, #0xc98]
02a311a8: 56009697 bl       #0xfb1300 ; 
02a311ac: c03b0190 adrp     x0, #0x51a9000
02a311b0: 00c443f9 ldr      x0, [x0, #0x788]
02a311b4: 53009697 bl       #0xfb1300 ; 
02a311b8: 803f01f0 adrp     x0, #0x5224000
02a311bc: 001847f9 ldr      x0, [x0, #0xe30]
02a311c0: 50009697 bl       #0xfb1300 ; 
02a311c4: 00400190 adrp     x0, #0x5231000
02a311c8: 003841f9 ldr      x0, [x0, #0x270]
02a311cc: 4d009697 bl       #0xfb1300 ; 
02a311d0: c03f01f0 adrp     x0, #0x522c000
02a311d4: 00e045f9 ldr      x0, [x0, #0xbc0]
02a311d8: 4a009697 bl       #0xfb1300 ; 
02a311dc: 28008052 mov      w8, #1
02a311e0: a8be3a39 strb     w8, [x21, #0xeaf]
02a311e4: 365a01b0 adrp     x22, #0x5576000
02a311e8: c8ae7c39 ldrb     w8, [x22, #0xf2b]
02a311ec: c8000035 cbnz     w8, #0x2a31204
02a311f0: a03e01f0 adrp     x0, #0x5208000
02a311f4: 00c041f9 ldr      x0, [x0, #0x380]
02a311f8: 42009697 bl       #0xfb1300 ; 
02a311fc: 28008052 mov      w8, #1
02a31200: c8ae3c39 strb     w8, [x22, #0xf2b]
02a31204: b83e01f0 adrp     x24, #0x5208000
02a31208: 18c341f9 ldr      x24, [x24, #0x380]
02a3120c: 080340f9 ldr      x8, [x24]
02a31210: 085d40f9 ldr      x8, [x8, #0xb8]
02a31214: 080140f9 ldr      x8, [x8]
02a31218: 480500b4 cbz      x8, #0x2a312c0
02a3121c: 081d40f9 ldr      x8, [x8, #0x38]
02a31220: 080500b4 cbz      x8, #0x2a312c0
02a31224: 080d40f9 ldr      x8, [x8, #0x18]
02a31228: c80400b4 cbz      x8, #0x2a312c0
02a3122c: 600a40f9 ldr      x0, [x19, #0x10]
02a31230: 800400b4 cbz      x0, #0x2a312c0
02a31234: 091c40b9 ldr      w9, [x0, #0x1c]
02a31238: 171540b9 ldr      w23, [x8, #0x14]
02a3123c: 9f060071 cmp      w20, #1
02a31240: 28050011 add      w8, w9, #1
02a31244: 1f200329 stp      wzr, w8, [x0, #0x18]
02a31248: cb040054 b.lt     #0x2a312e0
02a3124c: d93b0190 adrp     x25, #0x51a9000
02a31250: 39c743f9 ldr      x25, [x25, #0x788]
02a31254: f5031f2a mov      w21, wzr
02a31258: 0a1c40b9 ldr      w10, [x0, #0x1c]
02a3125c: 080840f9 ldr      x8, [x0, #0x10]
02a31260: 290340f9 ldr      x9, [x25]
02a31264: 4a050011 add      w10, w10, #1
02a31268: 0a1c00b9 str      w10, [x0, #0x1c]
02a3126c: a80200b4 cbz      x8, #0x2a312c0
02a31270: 0a1880b9 ldrsw    x10, [x0, #0x18]
02a31274: 0b1940b9 ldr      w11, [x8, #0x18]
02a31278: 5f010b6b cmp      w10, w11
02a3127c: c2000054 b.hs     #0x2a31294
02a31280: 49050011 add      w9, w10, #1
02a31284: 08050a8b add      x8, x8, x10, lsl #1
02a31288: 091800b9 str      w9, [x0, #0x18]
02a3128c: 15410079 strh     w21, [x8, #0x20]
02a31290: 07000014 b        #0x2a312ac ; 
02a31294: 281140f9 ldr      x8, [x9, #0x20]
02a31298: e103152a mov      w1, w21
02a3129c: 086140f9 ldr      x8, [x8, #0xc0]
02a312a0: 022d40f9 ldr      x2, [x8, #0x58]
02a312a4: 480440f9 ldr      x8, [x2, #8]
02a312a8: 00013fd6 blr      x8
02a312ac: b5060011 add      w21, w21, #1
02a312b0: 9f22356b cmp      w20, w21, uxth
02a312b4: 8d000054 b.le     #0x2a312c4
02a312b8: 600a40f9 ldr      x0, [x19, #0x10]
02a312bc: e0fcffb5 cbnz     x0, #0x2a31258
02a312c0: 5a009697 bl       #0xfb1428 ; 
02a312c4: c8ae7c39 ldrb     w8, [x22, #0xf2b]
02a312c8: c8000035 cbnz     w8, #0x2a312e0
02a312cc: a03e01f0 adrp     x0, #0x5208000
02a312d0: 00c041f9 ldr      x0, [x0, #0x380]
02a312d4: 0b009697 bl       #0xfb1300 ; 
02a312d8: 28008052 mov      w8, #1
02a312dc: c8ae3c39 strb     w8, [x22, #0xf2b]
02a312e0: 080340f9 ldr      x8, [x24]
02a312e4: 085d40f9 ldr      x8, [x8, #0xb8]
02a312e8: 080140f9 ldr      x8, [x8]
02a312ec: a8feffb4 cbz      x8, #0x2a312c0
02a312f0: 080940f9 ldr      x8, [x8, #0x10]
02a312f4: 68feffb4 cbz      x8, #0x2a312c0
02a312f8: 14400190 adrp     x20, #0x5231000
02a312fc: 953e01f0 adrp     x21, #0x5204000
02a31300: 602e40b9 ldr      w0, [x19, #0x2c]
02a31304: 160940f9 ldr      x22, [x8, #0x10]
02a31308: 943a41f9 ldr      x20, [x20, #0x270]
02a3130c: b5be47f9 ldr      x21, [x21, #0xf78]
02a31310: 60000035 cbnz     w0, #0x2a3131c
02a31314: f1fdff97 bl       #0x2a30ad8 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDeviceIdKey
02a31318: 602e00b9 str      w0, [x19, #0x2c]
02a3131c: e802160b add      w8, w23, w22
02a31320: 0801000b add      w8, w8, w0
02a31324: 682600b9 str      w8, [x19, #0x24]
02a31328: 800240f9 ldr      x0, [x20]
02a3132c: 21008052 mov      w1, #1
02a31330: 10009697 bl       #0xfb1370 ; 
02a31334: f40300aa mov      x20, x0
02a31338: 682640b9 ldr      w8, [x19, #0x24]
02a3133c: a00240f9 ldr      x0, [x21]
02a31340: e1330091 add      x1, sp, #0xc
02a31344: e80f00b9 str      w8, [sp, #0xc]
02a31348: 31009697 bl       #0xfb140c ; 
02a3134c: b4fbffb4 cbz      x20, #0x2a312c0
02a31350: f50300aa mov      x21, x0
02a31354: c00000b4 cbz      x0, #0x2a3136c
02a31358: 880240f9 ldr      x8, [x20]
02a3135c: e00315aa mov      x0, x21
02a31360: 012140f9 ldr      x1, [x8, #0x40]
02a31364: 29009697 bl       #0xfb1408 ; 
02a31368: e00300b4 cbz      x0, #0x2a313e4
02a3136c: 881a40b9 ldr      w8, [x20, #0x18]
02a31370: 88030034 cbz      w8, #0x2a313e0
02a31374: d63f01f0 adrp     x22, #0x522c000
02a31378: b73e01b0 adrp     x23, #0x5206000
02a3137c: d6e245f9 ldr      x22, [x22, #0xbc0]
02a31380: f74e46f9 ldr      x23, [x23, #0xc98]
02a31384: e00314aa mov      x0, x20
02a31388: 150c02f8 str      x21, [x0, #0x20]!
02a3138c: e10315aa mov      x1, x21
02a31390: c7ff9597 bl       #0xfb12ac ; 
02a31394: c20240f9 ldr      x2, [x22]
02a31398: 41018052 mov      w1, #0xa
02a3139c: e00313aa mov      x0, x19
02a313a0: e30314aa mov      x3, x20
02a313a4: e4031faa mov      x4, xzr
02a313a8: 5e3df797 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
02a313ac: 612640b9 ldr      w1, [x19, #0x24]
02a313b0: e00313aa mov      x0, x19
02a313b4: 0f000094 bl       #0x2a313f0 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$SetDifficultySeed
02a313b8: 610a40f9 ldr      x1, [x19, #0x10]
02a313bc: e20240f9 ldr      x2, [x23]
02a313c0: e00313aa mov      x0, x19
02a313c4: 1439ec97 bl       #0x253f814 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleListBasedOnDifficulty<ushort>
02a313c8: f37b44a9 ldp      x19, x30, [sp, #0x40]
02a313cc: f55343a9 ldp      x21, x20, [sp, #0x30]
02a313d0: f75b42a9 ldp      x23, x22, [sp, #0x20]
02a313d4: f96341a9 ldp      x25, x24, [sp, #0x10]
02a313d8: ff430191 add      sp, sp, #0x50
02a313dc: c0035fd6 ret      
02a313e0: 14009697 bl       #0xfb1430 ; 
02a313e4: 1a009697 bl       #0xfb144c ; 
02a313e8: e1031faa mov      x1, xzr
02a313ec: 01009697 bl       #0xfb13f0 ; 
