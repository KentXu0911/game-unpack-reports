# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDeviceIdKey
# Linear metadata span, not a recovered full CFG.
02a30ad8: ff0301d1 sub      sp, sp, #0x40
02a30adc: f75b01a9 stp      x23, x22, [sp, #0x10]
02a30ae0: f55302a9 stp      x21, x20, [sp, #0x20]
02a30ae4: f37b03a9 stp      x19, x30, [sp, #0x30]
02a30ae8: 945a01b0 adrp     x20, #0x5581000
02a30aec: b33b01f0 adrp     x19, #0x51a7000
02a30af0: 88c27a39 ldrb     w8, [x20, #0xeb0]
02a30af4: 730641f9 ldr      x19, [x19, #0x208]
02a30af8: 28010037 tbnz     w8, #0, #0x2a30b1c
02a30afc: 603e01f0 adrp     x0, #0x51ff000
02a30b00: 001840f9 ldr      x0, [x0, #0x30]
02a30b04: ff019697 bl       #0xfb1300 ; 
02a30b08: a03b01f0 adrp     x0, #0x51a7000
02a30b0c: 000441f9 ldr      x0, [x0, #0x208]
02a30b10: fc019697 bl       #0xfb1300 ; 
02a30b14: 28008052 mov      w8, #1
02a30b18: 88c23a39 strb     w8, [x20, #0xeb0]
02a30b1c: 730240f9 ldr      x19, [x19]
02a30b20: e0031faa mov      x0, xzr
02a30b24: ff1b0079 strh     wzr, [sp, #0xc]
02a30b28: fb432194 bl       #0x3281b14 ; Royal.Infrastructure.Utils.Native.DeviceHelper$$DeviceId
02a30b2c: 600600b4 cbz      x0, #0x2a30bf8
02a30b30: 081040b9 ldr      w8, [x0, #0x10]
02a30b34: f40300aa mov      x20, x0
02a30b38: 1f050071 cmp      w8, #1
02a30b3c: eb040054 b.lt     #0x2a30bd8
02a30b40: 773e01f0 adrp     x23, #0x51ff000
02a30b44: f71a40f9 ldr      x23, [x23, #0x30]
02a30b48: f5031f2a mov      w21, wzr
02a30b4c: e00314aa mov      x0, x20
02a30b50: e103152a mov      w1, w21
02a30b54: e2031faa mov      x2, xzr
02a30b58: e344cb97 bl       #0x1d01ee4 ; System.String$$get_Chars
02a30b5c: e80240f9 ldr      x8, [x23]
02a30b60: e01b0079 strh     w0, [sp, #0xc]
02a30b64: f603002a mov      w22, w0
02a30b68: 09e140b9 ldr      w9, [x8, #0xe0]
02a30b6c: 69000035 cbnz     w9, #0x2a30b78
02a30b70: e00308aa mov      x0, x8
02a30b74: 24029697 bl       #0xfb1404 ; 
02a30b78: e003162a mov      w0, w22
02a30b7c: e1031faa mov      x1, xzr
02a30b80: b34fd697 bl       #0x1fc4a4c ; System.Char$$IsDigit
02a30b84: a0010036 tbz      w0, #0, #0x2a30bb8
02a30b88: e00240f9 ldr      x0, [x23]
02a30b8c: 08e040b9 ldr      w8, [x0, #0xe0]
02a30b90: 48000035 cbnz     w8, #0x2a30b98
02a30b94: 1c029697 bl       #0xfb1404 ; 
02a30b98: e0330091 add      x0, sp, #0xc
02a30b9c: e1031faa mov      x1, xzr
02a30ba0: 9128d697 bl       #0x1fbade4 ; System.Char$$ToString
02a30ba4: e10300aa mov      x1, x0
02a30ba8: e00313aa mov      x0, x19
02a30bac: e2031faa mov      x2, xzr
02a30bb0: f131cb97 bl       #0x1cfd374 ; System.String$$Concat
02a30bb4: f30300aa mov      x19, x0
02a30bb8: 130200b4 cbz      x19, #0x2a30bf8
02a30bbc: 681240b9 ldr      w8, [x19, #0x10]
02a30bc0: 1f110071 cmp      w8, #4
02a30bc4: ac000054 b.gt     #0x2a30bd8
02a30bc8: 881240b9 ldr      w8, [x20, #0x10]
02a30bcc: b5060011 add      w21, w21, #1
02a30bd0: bf02086b cmp      w21, w8
02a30bd4: cbfbff54 b.lt     #0x2a30b4c
02a30bd8: e00313aa mov      x0, x19
02a30bdc: e1031faa mov      x1, xzr
02a30be0: 2792ed97 bl       #0x259547c ; System.Int32$$Parse
02a30be4: f37b43a9 ldp      x19, x30, [sp, #0x30]
02a30be8: f55342a9 ldp      x21, x20, [sp, #0x20]
02a30bec: f75b41a9 ldp      x23, x22, [sp, #0x10]
02a30bf0: ff030191 add      sp, sp, #0x40
02a30bf4: c0035fd6 ret      
02a30bf8: 0c029697 bl       #0xfb1428 ; 
