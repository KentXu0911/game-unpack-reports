# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultySeed
# Linear metadata span, not a recovered full CFG.
02a3146c: 002440b9 ldr      w0, [x0, #0x24]
02a31470: c0035fd6 ret      
