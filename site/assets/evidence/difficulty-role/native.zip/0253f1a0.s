# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$ShuffleArray<object>
# Linear metadata span, not a recovered full CFG.
0253f1a0: fa0f1bf8 str      x26, [sp, #-0x50]!
0253f1a4: f96301a9 stp      x25, x24, [sp, #0x10]
0253f1a8: f75b02a9 stp      x23, x22, [sp, #0x20]
0253f1ac: f55303a9 stp      x21, x20, [sp, #0x30]
0253f1b0: f37b04a9 stp      x19, x30, [sp, #0x40]
0253f1b4: 5f080071 cmp      w2, #2
0253f1b8: 2b050054 b.lt     #0x253f25c
0253f1bc: f303022a mov      w19, w2
0253f1c0: 687e4093 sxtw     x8, w19
0253f1c4: 29cc228b add      x9, x1, w2, sxtw #3
0253f1c8: f40301aa mov      x20, x1
0253f1cc: f50300aa mov      x21, x0
0253f1d0: 1a050091 add      x26, x8, #1
0253f1d4: 36610091 add      x22, x9, #0x18
0253f1d8: a01a40f9 ldr      x0, [x21, #0x30]
0253f1dc: e00400b4 cbz      x0, #0x253f278
0253f1e0: 080040f9 ldr      x8, [x0]
0253f1e4: e103132a mov      w1, w19
0253f1e8: 09895aa9 ldp      x9, x2, [x8, #0x1a8]
0253f1ec: 20013fd6 blr      x9
0253f1f0: 540400b4 cbz      x20, #0x253f278
0253f1f4: 880e40f9 ldr      x8, [x20, #0x18]
0253f1f8: f703002a mov      w23, w0
0253f1fc: 1f00086b cmp      w0, w8
0253f200: a2030054 b.hs     #0x253f274
0253f204: 98ce378b add      x24, x20, w23, sxtw #3
0253f208: 010f42f8 ldr      x1, [x24, #0x20]!
0253f20c: 490b00d1 sub      x9, x26, #2
0253f210: 087d4092 and      x8, x8, #0xffffffff
0253f214: 3f0108eb cmp      x9, x8
0253f218: e2020054 b.hs     #0x253f274
0253f21c: d90240f9 ldr      x25, [x22]
0253f220: e00316aa mov      x0, x22
0253f224: c10200f9 str      x1, [x22]
0253f228: 21c8a997 bl       #0xfb12ac ; 
0253f22c: 881a40b9 ldr      w8, [x20, #0x18]
0253f230: ff02086b cmp      w23, w8
0253f234: 02020054 b.hs     #0x253f274
0253f238: e00318aa mov      x0, x24
0253f23c: e10319aa mov      x1, x25
0253f240: 190300f9 str      x25, [x24]
0253f244: 1ac8a997 bl       #0xfb12ac ; 
0253f248: 5a0700d1 sub      x26, x26, #1
0253f24c: 73060051 sub      w19, w19, #1
0253f250: 5f0b00f1 cmp      x26, #2
0253f254: d62200d1 sub      x22, x22, #8
0253f258: 0cfcff54 b.gt     #0x253f1d8
0253f25c: f37b44a9 ldp      x19, x30, [sp, #0x40]
0253f260: f55343a9 ldp      x21, x20, [sp, #0x30]
0253f264: f75b42a9 ldp      x23, x22, [sp, #0x20]
0253f268: f96341a9 ldp      x25, x24, [sp, #0x10]
0253f26c: fa0745f8 ldr      x26, [sp], #0x50
0253f270: c0035fd6 ret      
0253f274: 6fc8a997 bl       #0xfb1430 ; 
0253f278: 6cc8a997 bl       #0xfb1428 ; 
