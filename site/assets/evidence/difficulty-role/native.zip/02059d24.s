# Royal.Player.Context.Units.LevelEpisodeHelper$$OnLevelFail
# Linear metadata span, not a recovered full CFG.
02059d24: f40f1ef8 str      x20, [sp, #-0x20]!
02059d28: f37b01a9 stp      x19, x30, [sp, #0x10]
02059d2c: 34a90190 adrp     x20, #0x557d000
02059d30: 882e4839 ldrb     w8, [x20, #0x20b]
02059d34: f30300aa mov      x19, x0
02059d38: c8000037 tbnz     w8, #0, #0x2059d50
02059d3c: c08c01b0 adrp     x0, #0x51f2000
02059d40: 003444f9 ldr      x0, [x0, #0x868]
02059d44: 6f5dbd97 bl       #0xfb1300 ; 
02059d48: 28008052 mov      w8, #1
02059d4c: 882e0839 strb     w8, [x20, #0x20b]
02059d50: 730a40f9 ldr      x19, [x19, #0x10]
02059d54: 930300b4 cbz      x19, #0x2059dc4
02059d58: ca8c01b0 adrp     x10, #0x51f2000
02059d5c: 680240f9 ldr      x8, [x19]
02059d60: 4a3544f9 ldr      x10, [x10, #0x868]
02059d64: 09554279 ldrh     w9, [x8, #0x12a]
02059d68: 410140f9 ldr      x1, [x10]
02059d6c: 290100b4 cbz      x9, #0x2059d90
02059d70: 0a5940f9 ldr      x10, [x8, #0xb0]
02059d74: 4a210091 add      x10, x10, #8
02059d78: 4b815ff8 ldur     x11, [x10, #-8]
02059d7c: 7f0101eb cmp      x11, x1
02059d80: 00010054 b.eq     #0x2059da0
02059d84: 290500f1 subs     x9, x9, #1
02059d88: 4a410091 add      x10, x10, #0x10
02059d8c: 61ffff54 b.ne     #0x2059d78
02059d90: 82008052 mov      w2, #4
02059d94: e00313aa mov      x0, x19
02059d98: 4f9dbc97 bl       #0xf812d4 ; 
02059d9c: 05000014 b        #0x2059db0 ; 
02059da0: 490140b9 ldr      w9, [x10]
02059da4: 29110011 add      w9, w9, #4
02059da8: 08d1298b add      x8, x8, w9, sxtw #4
02059dac: 00e10491 add      x0, x8, #0x138
02059db0: 020440a9 ldp      x2, x1, [x0]
02059db4: e00313aa mov      x0, x19
02059db8: f37b41a9 ldp      x19, x30, [sp, #0x10]
02059dbc: f40742f8 ldr      x20, [sp], #0x20
02059dc0: 40001fd6 br       x2
02059dc4: 995dbd97 bl       #0xfb1428 ; 
