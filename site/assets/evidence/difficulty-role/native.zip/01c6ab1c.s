# Royal.Player.Context.Units.HiddenTempleManager$$TryMigrateConfigForDynamicStageSize
# Linear metadata span, not a recovered full CFG.
01c6ab1c: ff4301d1 sub      sp, sp, #0x50
01c6ab20: f96301a9 stp      x25, x24, [sp, #0x10]
01c6ab24: f75b02a9 stp      x23, x22, [sp, #0x20]
01c6ab28: f55303a9 stp      x21, x20, [sp, #0x30]
01c6ab2c: f37b04a9 stp      x19, x30, [sp, #0x40]
01c6ab30: 94c801b0 adrp     x20, #0x557b000
01c6ab34: 888e5339 ldrb     w8, [x20, #0x4e3]
01c6ab38: f30300aa mov      x19, x0
01c6ab3c: 88040037 tbnz     w8, #0, #0x1c6abcc
01c6ab40: c0ad0190 adrp     x0, #0x5222000
01c6ab44: 00ec42f9 ldr      x0, [x0, #0x5d8]
01c6ab48: ee19cd97 bl       #0xfb1300 ; 
01c6ab4c: 80ac01f0 adrp     x0, #0x51fd000
01c6ab50: 00e846f9 ldr      x0, [x0, #0xdd0]
01c6ab54: eb19cd97 bl       #0xfb1300 ; 
01c6ab58: 80ad01d0 adrp     x0, #0x521c000
01c6ab5c: 007840f9 ldr      x0, [x0, #0xf0]
01c6ab60: e819cd97 bl       #0xfb1300 ; 
01c6ab64: c0ac01d0 adrp     x0, #0x5204000
01c6ab68: 00bc47f9 ldr      x0, [x0, #0xf78]
01c6ab6c: e519cd97 bl       #0xfb1300 ; 
01c6ab70: 60ae01d0 adrp     x0, #0x5238000
01c6ab74: 009446f9 ldr      x0, [x0, #0xd28]
01c6ab78: e219cd97 bl       #0xfb1300 ; 
01c6ab7c: 00ae01b0 adrp     x0, #0x522b000
01c6ab80: 00e844f9 ldr      x0, [x0, #0x9d0]
01c6ab84: df19cd97 bl       #0xfb1300 ; 
01c6ab88: a0a90190 adrp     x0, #0x519e000
01c6ab8c: 004847f9 ldr      x0, [x0, #0xe90]
01c6ab90: dc19cd97 bl       #0xfb1300 ; 
01c6ab94: a0ab0190 adrp     x0, #0x51de000
01c6ab98: 002045f9 ldr      x0, [x0, #0xa40]
01c6ab9c: d919cd97 bl       #0xfb1300 ; 
01c6aba0: a0aa01d0 adrp     x0, #0x51c0000
01c6aba4: 007847f9 ldr      x0, [x0, #0xef0]
01c6aba8: d619cd97 bl       #0xfb1300 ; 
01c6abac: c0aa01b0 adrp     x0, #0x51c3000
01c6abb0: 00b444f9 ldr      x0, [x0, #0x968]
01c6abb4: d319cd97 bl       #0xfb1300 ; 
01c6abb8: 20ad01f0 adrp     x0, #0x5211000
01c6abbc: 000444f9 ldr      x0, [x0, #0x808]
01c6abc0: d019cd97 bl       #0xfb1300 ; 
01c6abc4: 28008052 mov      w8, #1
01c6abc8: 888e1339 strb     w8, [x20, #0x4e3]
01c6abcc: e00313aa mov      x0, x19
01c6abd0: c2fbff97 bl       #0x1c69ad8 ; Royal.Player.Context.Units.HiddenTempleManager$$get_IsInAnEvent
01c6abd4: 00160036 tbz      w0, #0, #0x1c6ae94
01c6abd8: 601240f9 ldr      x0, [x19, #0x20]
01c6abdc: 801600b4 cbz      x0, #0x1c6aeac
01c6abe0: e1031faa mov      x1, xzr
01c6abe4: e8e81494 bl       #0x21a4f84 ; Royal.Player.Context.Data.Persistent.HiddenTempleProgress$$get_UserConfigVersion
01c6abe8: 1f000071 cmp      w0, #0
01c6abec: 4c150054 b.gt     #0x1c6ae94
01c6abf0: 601240f9 ldr      x0, [x19, #0x20]
01c6abf4: c01500b4 cbz      x0, #0x1c6aeac
01c6abf8: e1031faa mov      x1, xzr
01c6abfc: dde81494 bl       #0x21a4f70 ; Royal.Player.Context.Data.Persistent.HiddenTempleProgress$$get_EventId
01c6ac00: 682240f9 ldr      x8, [x19, #0x40]
01c6ac04: 481500b4 cbz      x8, #0x1c6aeac
01c6ac08: 080d40f9 ldr      x8, [x8, #0x18]
01c6ac0c: 081500b4 cbz      x8, #0x1c6aeac
01c6ac10: 081140b9 ldr      w8, [x8, #0x10]
01c6ac14: d8ac01d0 adrp     x24, #0x5204000
01c6ac18: d7ad0190 adrp     x23, #0x5222000
01c6ac1c: 18bf47f9 ldr      x24, [x24, #0xf78]
01c6ac20: f7ee42f9 ldr      x23, [x23, #0x5d8]
01c6ac24: 1f00086b cmp      w0, w8
01c6ac28: 610a0054 b.ne     #0x1c6ad74
01c6ac2c: e00313aa mov      x0, x19
01c6ac30: f6fcff97 bl       #0x1c6a008 ; Royal.Player.Context.Units.HiddenTempleManager$$get_RemainingTimeInMs
01c6ac34: 1f0400f1 cmp      x0, #1
01c6ac38: eb090054 b.lt     #0x1c6ad74
01c6ac3c: 692240f9 ldr      x9, [x19, #0x40]
01c6ac40: 691300b4 cbz      x9, #0x1c6aeac
01c6ac44: 282140f9 ldr      x8, [x9, #0x40]
01c6ac48: 281300b4 cbz      x8, #0x1c6aeac
01c6ac4c: 292540f9 ldr      x9, [x9, #0x48]
01c6ac50: e91200b4 cbz      x9, #0x1c6aeac
01c6ac54: 351140b9 ldr      w21, [x9, #0x10]
01c6ac58: bf060071 cmp      w21, #1
01c6ac5c: 6b010054 b.lt     #0x1c6ac88
01c6ac60: 000340f9 ldr      x0, [x24]
01c6ac64: 140940f9 ldr      x20, [x8, #0x10]
01c6ac68: e1330091 add      x1, sp, #0xc
01c6ac6c: f50f00b9 str      w21, [sp, #0xc]
01c6ac70: e719cd97 bl       #0xfb140c ; 
01c6ac74: 681240f9 ldr      x8, [x19, #0x20]
01c6ac78: a81100b4 cbz      x8, #0x1c6aeac
01c6ac7c: 19ae01b0 adrp     x25, #0x522b000
01c6ac80: 39eb44f9 ldr      x25, [x25, #0x9d0]
01c6ac84: 1a000014 b        #0x1c6acec ; 
01c6ac88: a8ab0190 adrp     x8, #0x51de000
01c6ac8c: 082145f9 ldr      x8, [x8, #0xa40]
01c6ac90: b4aa01d0 adrp     x20, #0x51c0000
01c6ac94: e1031faa mov      x1, xzr
01c6ac98: e2031faa mov      x2, xzr
01c6ac9c: 000140f9 ldr      x0, [x8]
01c6aca0: 947a47f9 ldr      x20, [x20, #0xef0]
01c6aca4: bad44794 bl       #0x2e5ff8c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetString
01c6aca8: 880240f9 ldr      x8, [x20]
01c6acac: f40300aa mov      x20, x0
01c6acb0: e1031f2a mov      w1, wzr
01c6acb4: e2031faa mov      x2, xzr
01c6acb8: e00308aa mov      x0, x8
01c6acbc: 20d54794 bl       #0x2e6013c ; Royal.Infrastructure.Services.Storage.Tables.AppKeyValue$$GetInt
01c6acc0: 1f040071 cmp      w0, #1
01c6acc4: 8b050054 b.lt     #0x1c6ad74
01c6acc8: f503002a mov      w21, w0
01c6accc: 000340f9 ldr      x0, [x24]
01c6acd0: e1330091 add      x1, sp, #0xc
01c6acd4: f50f00b9 str      w21, [sp, #0xc]
01c6acd8: cd19cd97 bl       #0xfb140c ; 
01c6acdc: 681240f9 ldr      x8, [x19, #0x20]
01c6ace0: 680e00b4 cbz      x8, #0x1c6aeac
01c6ace4: d9aa01b0 adrp     x25, #0x51c3000
01c6ace8: 39b744f9 ldr      x25, [x25, #0x968]
01c6acec: f60300aa mov      x22, x0
01c6acf0: e00308aa mov      x0, x8
01c6acf4: e1031faa mov      x1, xzr
01c6acf8: 9ee81494 bl       #0x21a4f70 ; Royal.Player.Context.Data.Persistent.HiddenTempleProgress$$get_EventId
01c6acfc: 080340f9 ldr      x8, [x24]
01c6ad00: e00b00b9 str      w0, [sp, #8]
01c6ad04: e1230091 add      x1, sp, #8
01c6ad08: e00308aa mov      x0, x8
01c6ad0c: c019cd97 bl       #0xfb140c ; 
01c6ad10: 280340f9 ldr      x8, [x25]
01c6ad14: e20300aa mov      x2, x0
01c6ad18: e10316aa mov      x1, x22
01c6ad1c: e3031faa mov      x3, xzr
01c6ad20: e00308aa mov      x0, x8
01c6ad24: e1750294 bl       #0x1d084a8 ; System.String$$Format
01c6ad28: f70240f9 ldr      x23, [x23]
01c6ad2c: f60300aa mov      x22, x0
01c6ad30: e81e40f9 ldr      x8, [x23, #0x38]
01c6ad34: 080140f9 ldr      x8, [x8]
01c6ad38: 09c94439 ldrb     w9, [x8, #0x132]
01c6ad3c: 89000037 tbnz     w9, #0, #0x1c6ad4c
01c6ad40: e00308aa mov      x0, x8
01c6ad44: a858cc97 bl       #0xf80fe4 ; 
01c6ad48: e80300aa mov      x8, x0
01c6ad4c: 09e140b9 ldr      w9, [x8, #0xe0]
01c6ad50: 69000035 cbnz     w9, #0x1c6ad5c
01c6ad54: e00308aa mov      x0, x8
01c6ad58: ab19cd97 bl       #0xfb1404 ; 
01c6ad5c: e81e40f9 ldr      x8, [x23, #0x38]
01c6ad60: 000140f9 ldr      x0, [x8]
01c6ad64: 08c84439 ldrb     w8, [x0, #0x132]
01c6ad68: 28070037 tbnz     w8, #0, #0x1c6ae4c
01c6ad6c: 9e58cc97 bl       #0xf80fe4 ; 
01c6ad70: 37000014 b        #0x1c6ae4c ; 
01c6ad74: a8a90190 adrp     x8, #0x519e000
01c6ad78: 69ae01d0 adrp     x9, #0x5238000
01c6ad7c: 084947f9 ldr      x8, [x8, #0xe90]
01c6ad80: 299546f9 ldr      x9, [x9, #0xd28]
01c6ad84: 000140f9 ldr      x0, [x8]
01c6ad88: 210140f9 ldr      x1, [x9]
01c6ad8c: d55b2594 bl       #0x25c1ce0 ; UnityEngine.Resources$$Load<object>
01c6ad90: e00800b4 cbz      x0, #0x1c6aeac
01c6ad94: e1031faa mov      x1, xzr
01c6ad98: fe638294 bl       #0x3d03d90 ; UnityEngine.TextAsset$$get_text
01c6ad9c: f40300aa mov      x20, x0
01c6ada0: 000340f9 ldr      x0, [x24]
01c6ada4: a8098052 mov      w8, #0x4d
01c6ada8: e1330091 add      x1, sp, #0xc
01c6adac: e80f00b9 str      w8, [sp, #0xc]
01c6adb0: 9719cd97 bl       #0xfb140c ; 
01c6adb4: 681240f9 ldr      x8, [x19, #0x20]
01c6adb8: a80700b4 cbz      x8, #0x1c6aeac
01c6adbc: 36ad01f0 adrp     x22, #0x5211000
01c6adc0: d60644f9 ldr      x22, [x22, #0x808]
01c6adc4: f50300aa mov      x21, x0
01c6adc8: e00308aa mov      x0, x8
01c6adcc: e1031faa mov      x1, xzr
01c6add0: 68e81494 bl       #0x21a4f70 ; Royal.Player.Context.Data.Persistent.HiddenTempleProgress$$get_EventId
01c6add4: 080340f9 ldr      x8, [x24]
01c6add8: e00b00b9 str      w0, [sp, #8]
01c6addc: e1230091 add      x1, sp, #8
01c6ade0: e00308aa mov      x0, x8
01c6ade4: 8a19cd97 bl       #0xfb140c ; 
01c6ade8: c80240f9 ldr      x8, [x22]
01c6adec: e20300aa mov      x2, x0
01c6adf0: e10315aa mov      x1, x21
01c6adf4: e3031faa mov      x3, xzr
01c6adf8: e00308aa mov      x0, x8
01c6adfc: ab750294 bl       #0x1d084a8 ; System.String$$Format
01c6ae00: f50240f9 ldr      x21, [x23]
01c6ae04: f60300aa mov      x22, x0
01c6ae08: a81e40f9 ldr      x8, [x21, #0x38]
01c6ae0c: 080140f9 ldr      x8, [x8]
01c6ae10: 09c94439 ldrb     w9, [x8, #0x132]
01c6ae14: 89000037 tbnz     w9, #0, #0x1c6ae24
01c6ae18: e00308aa mov      x0, x8
01c6ae1c: 7258cc97 bl       #0xf80fe4 ; 
01c6ae20: e80300aa mov      x8, x0
01c6ae24: 09e140b9 ldr      w9, [x8, #0xe0]
01c6ae28: 69000035 cbnz     w9, #0x1c6ae34
01c6ae2c: e00308aa mov      x0, x8
01c6ae30: 7519cd97 bl       #0xfb1404 ; 
01c6ae34: a81e40f9 ldr      x8, [x21, #0x38]
01c6ae38: 000140f9 ldr      x0, [x8]
01c6ae3c: 08c84439 ldrb     w8, [x0, #0x132]
01c6ae40: 48000037 tbnz     w8, #0, #0x1c6ae48
01c6ae44: 6858cc97 bl       #0xf80fe4 ; 
01c6ae48: b5098052 mov      w21, #0x4d
01c6ae4c: 085c40f9 ldr      x8, [x0, #0xb8]
01c6ae50: 61058052 mov      w1, #0x2b
01c6ae54: e00313aa mov      x0, x19
01c6ae58: e20316aa mov      x2, x22
01c6ae5c: 030140f9 ldr      x3, [x8]
01c6ae60: e4031faa mov      x4, xzr
01c6ae64: af562e94 bl       #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
01c6ae68: 602640f9 ldr      x0, [x19, #0x48]
01c6ae6c: 000200b4 cbz      x0, #0x1c6aeac
01c6ae70: e103152a mov      w1, w21
01c6ae74: e20314aa mov      x2, x20
01c6ae78: e3031faa mov      x3, xzr
01c6ae7c: abd67894 bl       #0x3aa0928 ; Royal.Scenes.Home.Ui.Dialogs.HiddenTemple.HiddenTempleConfigHelper$$UpdateUserConfig
01c6ae80: 601240f9 ldr      x0, [x19, #0x20]
01c6ae84: 400100b4 cbz      x0, #0x1c6aeac
01c6ae88: e103152a mov      w1, w21
01c6ae8c: e2031faa mov      x2, xzr
01c6ae90: 54ea1494 bl       #0x21a57e0 ; Royal.Player.Context.Data.Persistent.HiddenTempleProgress$$SetUserConfigVersion
01c6ae94: f37b44a9 ldp      x19, x30, [sp, #0x40]
01c6ae98: f55343a9 ldp      x21, x20, [sp, #0x30]
01c6ae9c: f75b42a9 ldp      x23, x22, [sp, #0x20]
01c6aea0: f96341a9 ldp      x25, x24, [sp, #0x10]
01c6aea4: ff430191 add      sp, sp, #0x50
01c6aea8: c0035fd6 ret      
01c6aeac: 5f19cd97 bl       #0xfb1428 ; 
