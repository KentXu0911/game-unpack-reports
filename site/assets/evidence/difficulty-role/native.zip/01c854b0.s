# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetSection
# Linear metadata span, not a recovered full CFG.
01c854b0: e0031f2a mov      w0, wzr
01c854b4: c0035fd6 ret      
