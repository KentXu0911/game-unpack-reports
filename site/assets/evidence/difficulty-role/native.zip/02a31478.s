# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
# Linear metadata span, not a recovered full CFG.
02a31478: fe0f1ff8 str      x30, [sp, #-0x10]!
02a3147c: 092840b9 ldr      w9, [x0, #0x28]
02a31480: e80300aa mov      x8, x0
02a31484: 001c40f9 ldr      x0, [x0, #0x38]
02a31488: 29050011 add      w9, w9, #1
02a3148c: 092900b9 str      w9, [x8, #0x28]
02a31490: a00000b4 cbz      x0, #0x2a314a4
02a31494: 080040f9 ldr      x8, [x0]
02a31498: 048d59a9 ldp      x4, x3, [x8, #0x198]
02a3149c: fe0741f8 ldr      x30, [sp], #0x10
02a314a0: 80001fd6 br       x4
02a314a4: e1ff9597 bl       #0xfb1428 ; 
