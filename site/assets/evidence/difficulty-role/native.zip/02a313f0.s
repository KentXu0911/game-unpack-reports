# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$SetDifficultySeed
# Linear metadata span, not a recovered full CFG.
02a313f0: f60f1df8 str      x22, [sp, #-0x30]!
02a313f4: f55301a9 stp      x21, x20, [sp, #0x10]
02a313f8: f37b02a9 stp      x19, x30, [sp, #0x20]
02a313fc: 965a0190 adrp     x22, #0x5581000
02a31400: 753f0190 adrp     x21, #0x521d000
02a31404: c8c67a39 ldrb     w8, [x22, #0xeb1]
02a31408: b5ee46f9 ldr      x21, [x21, #0xdd8]
02a3140c: f403012a mov      w20, w1
02a31410: f30300aa mov      x19, x0
02a31414: c8000037 tbnz     w8, #0, #0x2a3142c
02a31418: 603f0190 adrp     x0, #0x521d000
02a3141c: 00ec46f9 ldr      x0, [x0, #0xdd8]
02a31420: b8ff9597 bl       #0xfb1300 ; 
02a31424: 28008052 mov      w8, #1
02a31428: c8c63a39 strb     w8, [x22, #0xeb1]
02a3142c: 74fe0429 stp      w20, wzr, [x19, #0x24]
02a31430: a00240f9 ldr      x0, [x21]
02a31434: f9ff9597 bl       #0xfb1418 ; 
02a31438: 800100b4 cbz      x0, #0x2a31468
02a3143c: e103142a mov      w1, w20
02a31440: e2031faa mov      x2, xzr
02a31444: f50300aa mov      x21, x0
02a31448: 3b95ec97 bl       #0x2556934 ; System.Random$$.ctor
02a3144c: 758e03f8 str      x21, [x19, #0x38]!
02a31450: e00313aa mov      x0, x19
02a31454: e10315aa mov      x1, x21
02a31458: f37b42a9 ldp      x19, x30, [sp, #0x20]
02a3145c: f55341a9 ldp      x21, x20, [sp, #0x10]
02a31460: f60743f8 ldr      x22, [sp], #0x30
02a31464: 92ff9517 b        #0xfb12ac ; 
02a31468: f0ff9597 bl       #0xfb1428 ; 
