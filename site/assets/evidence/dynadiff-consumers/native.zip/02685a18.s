# Royal.Player.Context.Data.SyncManager$$GetUpdatedKeyValues
# Linear metadata span; not complete CFG.
2685a18: stp x23, x22, [sp, #-0x30]!
2685a1c: stp x21, x20, [sp, #0x10]
2685a20: stp x19, x30, [sp, #0x20]
2685a24: adrp x20, #0x557f000
2685a28: ldrb w8, [x20, #0xe97]
2685a2c: mov x19, x0
2685a30: tbnz w8, #0, #0x2685c58
2685a34: adrp x0, #0x519a000
2685a38: ldr x0, [x0, #0xf10]
2685a3c: bl #0xfb1300 ; 
2685a40: adrp x0, #0x51e8000
2685a44: ldr x0, [x0, #0x600]
2685a48: bl #0xfb1300 ; 
2685a4c: adrp x0, #0x51eb000
2685a50: ldr x0, [x0, #0x350]
2685a54: bl #0xfb1300 ; 
2685a58: adrp x0, #0x5222000
2685a5c: ldr x0, [x0, #0x850]
2685a60: bl #0xfb1300 ; 
2685a64: adrp x0, #0x51c1000
2685a68: ldr x0, [x0, #0xfd8]
2685a6c: bl #0xfb1300 ; 
2685a70: adrp x0, #0x51b3000
2685a74: ldr x0, [x0, #0x340]
2685a78: bl #0xfb1300 ; 
2685a7c: adrp x0, #0x51f2000
2685a80: ldr x0, [x0, #0xb60]
2685a84: bl #0xfb1300 ; 
2685a88: adrp x0, #0x51cd000
2685a8c: ldr x0, [x0, #0x1c0]
2685a90: bl #0xfb1300 ; 
2685a94: adrp x0, #0x5233000
2685a98: ldr x0, [x0, #0x3b0]
2685a9c: bl #0xfb1300 ; 
2685aa0: adrp x0, #0x51ea000
2685aa4: ldr x0, [x0, #0x9f8]
2685aa8: bl #0xfb1300 ; 
2685aac: adrp x0, #0x51d5000
2685ab0: ldr x0, [x0, #0x4e0]
2685ab4: bl #0xfb1300 ; 
2685ab8: adrp x0, #0x51a1000
2685abc: ldr x0, [x0, #0x728]
2685ac0: bl #0xfb1300 ; 
2685ac4: adrp x0, #0x51ad000
2685ac8: ldr x0, [x0, #0x6e0]
2685acc: bl #0xfb1300 ; 
2685ad0: adrp x0, #0x51dd000
2685ad4: ldr x0, [x0, #0xed8]
2685ad8: bl #0xfb1300 ; 
2685adc: adrp x0, #0x5207000
2685ae0: ldr x0, [x0, #0xd18]
2685ae4: bl #0xfb1300 ; 
2685ae8: adrp x0, #0x51b7000
2685aec: ldr x0, [x0, #0x850]
2685af0: bl #0xfb1300 ; 
2685af4: adrp x0, #0x5197000
2685af8: ldr x0, [x0, #0x290]
2685afc: bl #0xfb1300 ; 
2685b00: adrp x0, #0x520e000
2685b04: ldr x0, [x0, #0x368]
2685b08: bl #0xfb1300 ; 
2685b0c: adrp x0, #0x51db000
2685b10: ldr x0, [x0, #0xcc0]
2685b14: bl #0xfb1300 ; 
2685b18: adrp x0, #0x51ff000
2685b1c: ldr x0, [x0, #8]
2685b20: bl #0xfb1300 ; 
2685b24: adrp x0, #0x521f000
2685b28: ldr x0, [x0, #0xd90]
2685b2c: bl #0xfb1300 ; 
2685b30: adrp x0, #0x51be000
2685b34: ldr x0, [x0, #0xd50]
2685b38: bl #0xfb1300 ; 
2685b3c: adrp x0, #0x519f000
2685b40: ldr x0, [x0, #0x488]
2685b44: bl #0xfb1300 ; 
2685b48: adrp x0, #0x51b3000
2685b4c: ldr x0, [x0, #0x3c8]
2685b50: bl #0xfb1300 ; 
2685b54: adrp x0, #0x51cf000
2685b58: ldr x0, [x0, #0xd10]
2685b5c: bl #0xfb1300 ; 
2685b60: adrp x0, #0x5202000
2685b64: ldr x0, [x0, #0x7b0]
2685b68: bl #0xfb1300 ; 
2685b6c: adrp x0, #0x523e000
2685b70: ldr x0, [x0, #0x590]
2685b74: bl #0xfb1300 ; 
2685b78: adrp x0, #0x5239000
2685b7c: ldr x0, [x0, #0x50]
2685b80: bl #0xfb1300 ; 
2685b84: adrp x0, #0x51f9000
2685b88: ldr x0, [x0, #0x290]
2685b8c: bl #0xfb1300 ; 
2685b90: adrp x0, #0x51a7000
2685b94: ldr x0, [x0, #0xac8]
2685b98: bl #0xfb1300 ; 
2685b9c: adrp x0, #0x51bd000
2685ba0: ldr x0, [x0, #0x900]
2685ba4: bl #0xfb1300 ; 
2685ba8: adrp x0, #0x5196000
2685bac: ldr x0, [x0, #0xde8]
2685bb0: bl #0xfb1300 ; 
2685bb4: adrp x0, #0x5210000
2685bb8: ldr x0, [x0, #0xb88]
2685bbc: bl #0xfb1300 ; 
2685bc0: adrp x0, #0x51e2000
2685bc4: ldr x0, [x0, #0xd38]
2685bc8: bl #0xfb1300 ; 
2685bcc: adrp x0, #0x51eb000
2685bd0: ldr x0, [x0, #0x538]
2685bd4: bl #0xfb1300 ; 
2685bd8: adrp x0, #0x51fd000
2685bdc: ldr x0, [x0, #0xa28]
2685be0: bl #0xfb1300 ; 
2685be4: adrp x0, #0x5201000
2685be8: ldr x0, [x0, #0x930]
2685bec: bl #0xfb1300 ; 
2685bf0: adrp x0, #0x5219000
2685bf4: ldr x0, [x0, #0xc0]
2685bf8: bl #0xfb1300 ; 
2685bfc: adrp x0, #0x5220000
2685c00: ldr x0, [x0, #0xf68]
2685c04: bl #0xfb1300 ; 
2685c08: adrp x0, #0x5236000
2685c0c: ldr x0, [x0, #0x8d0]
2685c10: bl #0xfb1300 ; 
2685c14: adrp x0, #0x5236000
2685c18: ldr x0, [x0, #0xe58]
2685c1c: bl #0xfb1300 ; 
2685c20: adrp x0, #0x51d5000
2685c24: ldr x0, [x0, #0x9c8]
2685c28: bl #0xfb1300 ; 
2685c2c: adrp x0, #0x51e8000
2685c30: ldr x0, [x0, #0xd0]
2685c34: bl #0xfb1300 ; 
2685c38: adrp x0, #0x523d000
2685c3c: ldr x0, [x0, #0xa8]
2685c40: bl #0xfb1300 ; 
2685c44: adrp x0, #0x51b9000
2685c48: ldr x0, [x0, #0x7f8]
2685c4c: bl #0xfb1300 ; 
2685c50: mov w8, #1
2685c54: strb w8, [x20, #0xe97]
2685c58: mov x0, x19
2685c5c: mov x1, xzr
2685c60: bl #0x2e70758 ; Royal.Infrastructure.Services.Storage.Tables.SyncRequiredKeyValueCounts$$TotalKeyValueCount
2685c64: cmp w0, #1
2685c68: b.lt #0x26865b4
2685c6c: adrp x8, #0x51eb000
2685c70: ldr x8, [x8, #0x350]
2685c74: ldr x0, [x8]
2685c78: bl #0xfb1418 ; 
2685c7c: cbz x0, #0x26865cc
2685c80: adrp x8, #0x51e8000
2685c84: ldr x8, [x8, #0x600]
2685c88: adrp x21, #0x519a000
2685c8c: mov x20, x0
2685c90: ldr x1, [x8]
2685c94: ldr x21, [x21, #0xf10]
2685c98: bl #0x3be9630 ; System.Collections.Generic.Dictionary<object, long>$$.ctor
2685c9c: ldr w8, [x19]
2685ca0: adrp x22, #0x5208000
2685ca4: ldr x22, [x22, #0x380]
2685ca8: adrp x23, #0x5576000
2685cac: cmp w8, #1
2685cb0: b.lt #0x2685d04
2685cb4: ldrb w8, [x23, #0xf2b]
2685cb8: cbnz w8, #0x2685cd0
2685cbc: adrp x0, #0x5208000
2685cc0: ldr x0, [x0, #0x380]
2685cc4: bl #0xfb1300 ; 
2685cc8: mov w8, #1
2685ccc: strb w8, [x23, #0xf2b]
2685cd0: ldr x8, [x22]
2685cd4: ldr x8, [x8, #0xb8]
2685cd8: ldr x8, [x8]
2685cdc: cbz x8, #0x26865cc
2685ce0: ldr x8, [x8, #0x20]
2685ce4: cbz x8, #0x26865cc
2685ce8: adrp x9, #0x51f2000
2685cec: ldr x9, [x9, #0xb60]
2685cf0: ldr x2, [x8, #0xa8]
2685cf4: ldr x3, [x21]
2685cf8: mov x0, x20
2685cfc: ldr x1, [x9]
2685d00: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685d04: ldr w8, [x19, #4]
2685d08: cmp w8, #1
2685d0c: b.lt #0x2685d60
2685d10: ldrb w8, [x23, #0xf2b]
2685d14: cbnz w8, #0x2685d2c
2685d18: adrp x0, #0x5208000
2685d1c: ldr x0, [x0, #0x380]
2685d20: bl #0xfb1300 ; 
2685d24: mov w8, #1
2685d28: strb w8, [x23, #0xf2b]
2685d2c: ldr x8, [x22]
2685d30: ldr x8, [x8, #0xb8]
2685d34: ldr x8, [x8]
2685d38: cbz x8, #0x26865cc
2685d3c: ldr x8, [x8, #0x20]
2685d40: cbz x8, #0x26865cc
2685d44: adrp x9, #0x51bd000
2685d48: ldr x9, [x9, #0x900]
2685d4c: ldr x2, [x8, #0xb0]
2685d50: ldr x3, [x21]
2685d54: mov x0, x20
2685d58: ldr x1, [x9]
2685d5c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685d60: ldr w8, [x19, #0x10]
2685d64: adrp x22, #0x51b3000
2685d68: ldr x22, [x22, #0x340]
2685d6c: cmp w8, #1
2685d70: b.lt #0x2685db8
2685d74: ldr x0, [x22]
2685d78: adrp x23, #0x51c1000
2685d7c: ldr w8, [x0, #0xe0]
2685d80: ldr x23, [x23, #0xfd8]
2685d84: cbnz w8, #0x2685d8c
2685d88: bl #0xfb1404 ; 
2685d8c: ldr x1, [x23]
2685d90: mov w0, #0x19
2685d94: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2685d98: cbz x0, #0x26865cc
2685d9c: adrp x8, #0x51be000
2685da0: ldr x8, [x8, #0xd50]
2685da4: ldr x2, [x0, #0x28]
2685da8: ldr x3, [x21]
2685dac: mov x0, x20
2685db0: ldr x1, [x8]
2685db4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685db8: ldr w8, [x19, #0x14]
2685dbc: cmp w8, #1
2685dc0: b.lt #0x2685e08
2685dc4: ldr x0, [x22]
2685dc8: adrp x22, #0x5222000
2685dcc: ldr w8, [x0, #0xe0]
2685dd0: ldr x22, [x22, #0x850]
2685dd4: cbnz w8, #0x2685ddc
2685dd8: bl #0xfb1404 ; 
2685ddc: ldr x1, [x22]
2685de0: mov w0, #0x17
2685de4: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2685de8: cbz x0, #0x26865cc
2685dec: adrp x8, #0x5239000
2685df0: ldr x8, [x8, #0x50]
2685df4: ldr x2, [x0, #0x40]
2685df8: ldr x3, [x21]
2685dfc: mov x0, x20
2685e00: ldr x1, [x8]
2685e04: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685e08: ldr w8, [x19, #0x18]
2685e0c: cmp w8, #1
2685e10: b.lt #0x2685e40
2685e14: adrp x22, #0x5236000
2685e18: ldr x22, [x22, #0x8d0]
2685e1c: mov x1, xzr
2685e20: mov x2, xzr
2685e24: ldr x0, [x22]
2685e28: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685e2c: ldr x1, [x22]
2685e30: ldr x3, [x21]
2685e34: mov x2, x0
2685e38: mov x0, x20
2685e3c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685e40: ldr w8, [x19, #0x1c]
2685e44: cmp w8, #1
2685e48: b.lt #0x2685e78
2685e4c: adrp x22, #0x51e2000
2685e50: ldr x22, [x22, #0xd38]
2685e54: mov x1, xzr
2685e58: mov x2, xzr
2685e5c: ldr x0, [x22]
2685e60: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685e64: ldr x1, [x22]
2685e68: ldr x3, [x21]
2685e6c: mov x2, x0
2685e70: mov x0, x20
2685e74: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685e78: ldr w8, [x19, #0x20]
2685e7c: cmp w8, #1
2685e80: b.lt #0x2685eb0
2685e84: adrp x22, #0x51cd000
2685e88: ldr x22, [x22, #0x1c0]
2685e8c: mov x1, xzr
2685e90: mov x2, xzr
2685e94: ldr x0, [x22]
2685e98: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685e9c: ldr x1, [x22]
2685ea0: ldr x3, [x21]
2685ea4: mov x2, x0
2685ea8: mov x0, x20
2685eac: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685eb0: ldr w8, [x19, #0x24]
2685eb4: cmp w8, #1
2685eb8: b.lt #0x2685ee8
2685ebc: adrp x22, #0x51ff000
2685ec0: ldr x22, [x22, #8]
2685ec4: mov x1, xzr
2685ec8: mov x2, xzr
2685ecc: ldr x0, [x22]
2685ed0: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685ed4: ldr x1, [x22]
2685ed8: ldr x3, [x21]
2685edc: mov x2, x0
2685ee0: mov x0, x20
2685ee4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685ee8: ldr w8, [x19, #0x28]
2685eec: cmp w8, #1
2685ef0: b.lt #0x2685f20
2685ef4: adrp x22, #0x51b9000
2685ef8: ldr x22, [x22, #0x7f8]
2685efc: mov x1, xzr
2685f00: mov x2, xzr
2685f04: ldr x0, [x22]
2685f08: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685f0c: ldr x1, [x22]
2685f10: ldr x3, [x21]
2685f14: mov x2, x0
2685f18: mov x0, x20
2685f1c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685f20: ldr w8, [x19, #0x2c]
2685f24: cmp w8, #1
2685f28: b.lt #0x2685f58
2685f2c: adrp x22, #0x51d5000
2685f30: ldr x22, [x22, #0x4e0]
2685f34: mov x1, xzr
2685f38: mov x2, xzr
2685f3c: ldr x0, [x22]
2685f40: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685f44: ldr x1, [x22]
2685f48: ldr x3, [x21]
2685f4c: mov x2, x0
2685f50: mov x0, x20
2685f54: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685f58: ldr w8, [x19, #0x34]
2685f5c: cmp w8, #1
2685f60: b.lt #0x2685f90
2685f64: adrp x22, #0x5219000
2685f68: ldr x22, [x22, #0xc0]
2685f6c: mov x1, xzr
2685f70: mov x2, xzr
2685f74: ldr x0, [x22]
2685f78: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685f7c: ldr x1, [x22]
2685f80: ldr x3, [x21]
2685f84: mov x2, x0
2685f88: mov x0, x20
2685f8c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685f90: ldr w8, [x19, #0x38]
2685f94: cmp w8, #1
2685f98: b.lt #0x2685fc8
2685f9c: adrp x22, #0x5210000
2685fa0: ldr x22, [x22, #0xb88]
2685fa4: mov x1, xzr
2685fa8: mov x2, xzr
2685fac: ldr x0, [x22]
2685fb0: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685fb4: ldr x1, [x22]
2685fb8: ldr x3, [x21]
2685fbc: mov x2, x0
2685fc0: mov x0, x20
2685fc4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2685fc8: ldr w8, [x19, #0x3c]
2685fcc: cmp w8, #1
2685fd0: b.lt #0x2686000
2685fd4: adrp x22, #0x51ea000
2685fd8: ldr x22, [x22, #0x9f8]
2685fdc: mov x1, xzr
2685fe0: mov x2, xzr
2685fe4: ldr x0, [x22]
2685fe8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2685fec: ldr x1, [x22]
2685ff0: ldr x3, [x21]
2685ff4: mov x2, x0
2685ff8: mov x0, x20
2685ffc: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686000: ldr w8, [x19, #0x40]
2686004: cmp w8, #1
2686008: b.lt #0x2686038
268600c: adrp x22, #0x51a7000
2686010: ldr x22, [x22, #0xac8]
2686014: mov x1, xzr
2686018: mov x2, xzr
268601c: ldr x0, [x22]
2686020: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686024: ldr x1, [x22]
2686028: ldr x3, [x21]
268602c: mov x2, x0
2686030: mov x0, x20
2686034: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686038: ldr w8, [x19, #0x44]
268603c: cmp w8, #1
2686040: b.lt #0x2686070
2686044: adrp x22, #0x5236000
2686048: ldr x22, [x22, #0xe58]
268604c: mov x1, xzr
2686050: mov x2, xzr
2686054: ldr x0, [x22]
2686058: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268605c: ldr x1, [x22]
2686060: ldr x3, [x21]
2686064: mov x2, x0
2686068: mov x0, x20
268606c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686070: ldr w8, [x19, #0x48]
2686074: cmp w8, #1
2686078: b.lt #0x26860a8
268607c: adrp x22, #0x51a1000
2686080: ldr x22, [x22, #0x728]
2686084: mov x1, xzr
2686088: mov x2, xzr
268608c: ldr x0, [x22]
2686090: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686094: ldr x1, [x22]
2686098: ldr x3, [x21]
268609c: mov x2, x0
26860a0: mov x0, x20
26860a4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26860a8: ldr w8, [x19, #0x4c]
26860ac: cmp w8, #1
26860b0: b.lt #0x26860e0
26860b4: adrp x22, #0x51d5000
26860b8: ldr x22, [x22, #0x9c8]
26860bc: mov x1, xzr
26860c0: mov x2, xzr
26860c4: ldr x0, [x22]
26860c8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26860cc: ldr x1, [x22]
26860d0: ldr x3, [x21]
26860d4: mov x2, x0
26860d8: mov x0, x20
26860dc: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26860e0: ldr w8, [x19, #0x50]
26860e4: cmp w8, #1
26860e8: b.lt #0x2686118
26860ec: adrp x22, #0x5196000
26860f0: ldr x22, [x22, #0xde8]
26860f4: mov x1, xzr
26860f8: mov x2, xzr
26860fc: ldr x0, [x22]
2686100: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686104: ldr x1, [x22]
2686108: ldr x3, [x21]
268610c: mov x2, x0
2686110: mov x0, x20
2686114: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686118: ldr w8, [x19, #0x54]
268611c: cmp w8, #1
2686120: b.lt #0x2686150
2686124: adrp x22, #0x5233000
2686128: ldr x22, [x22, #0x3b0]
268612c: mov x1, xzr
2686130: mov x2, xzr
2686134: ldr x0, [x22]
2686138: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268613c: ldr x1, [x22]
2686140: ldr x3, [x21]
2686144: mov x2, x0
2686148: mov x0, x20
268614c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686150: ldr w8, [x19, #0x58]
2686154: cmp w8, #1
2686158: b.lt #0x2686188
268615c: adrp x22, #0x51b3000
2686160: ldr x22, [x22, #0x3c8]
2686164: mov x1, xzr
2686168: mov x2, xzr
268616c: ldr x0, [x22]
2686170: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686174: ldr x1, [x22]
2686178: ldr x3, [x21]
268617c: mov x2, x0
2686180: mov x0, x20
2686184: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686188: ldr w8, [x19, #0x5c]
268618c: cmp w8, #1
2686190: b.lt #0x26861c0
2686194: adrp x22, #0x5201000
2686198: ldr x22, [x22, #0x930]
268619c: mov x1, xzr
26861a0: mov x2, xzr
26861a4: ldr x0, [x22]
26861a8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26861ac: ldr x1, [x22]
26861b0: ldr x3, [x21]
26861b4: mov x2, x0
26861b8: mov x0, x20
26861bc: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26861c0: ldr w8, [x19, #0x60]
26861c4: cmp w8, #1
26861c8: b.lt #0x26861f8
26861cc: adrp x22, #0x51fd000
26861d0: ldr x22, [x22, #0xa28]
26861d4: mov x1, xzr
26861d8: mov x2, xzr
26861dc: ldr x0, [x22]
26861e0: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26861e4: ldr x1, [x22]
26861e8: ldr x3, [x21]
26861ec: mov x2, x0
26861f0: mov x0, x20
26861f4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26861f8: ldr w8, [x19, #0x64]
26861fc: cmp w8, #1
2686200: b.lt #0x2686230
2686204: adrp x22, #0x51b7000
2686208: ldr x22, [x22, #0x850]
268620c: mov x1, xzr
2686210: mov x2, xzr
2686214: ldr x0, [x22]
2686218: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268621c: ldr x1, [x22]
2686220: ldr x3, [x21]
2686224: mov x2, x0
2686228: mov x0, x20
268622c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686230: ldr w8, [x19, #0x78]
2686234: cmp w8, #1
2686238: b.lt #0x2686268
268623c: adrp x22, #0x5197000
2686240: ldr x22, [x22, #0x290]
2686244: mov x1, xzr
2686248: mov x2, xzr
268624c: ldr x0, [x22]
2686250: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686254: ldr x1, [x22]
2686258: ldr x3, [x21]
268625c: mov x2, x0
2686260: mov x0, x20
2686264: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686268: ldr w8, [x19, #0x68]
268626c: cmp w8, #1
2686270: b.lt #0x26862a0
2686274: adrp x22, #0x5207000
2686278: ldr x22, [x22, #0xd18]
268627c: mov x1, xzr
2686280: mov x2, xzr
2686284: ldr x0, [x22]
2686288: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268628c: ldr x1, [x22]
2686290: ldr x3, [x21]
2686294: mov x2, x0
2686298: mov x0, x20
268629c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26862a0: ldr w8, [x19, #0x6c]
26862a4: cmp w8, #1
26862a8: b.lt #0x26862d8
26862ac: adrp x22, #0x523e000
26862b0: ldr x22, [x22, #0x590]
26862b4: mov x1, xzr
26862b8: mov x2, xzr
26862bc: ldr x0, [x22]
26862c0: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26862c4: ldr x1, [x22]
26862c8: ldr x3, [x21]
26862cc: mov x2, x0
26862d0: mov x0, x20
26862d4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26862d8: ldr w8, [x19, #0x7c]
26862dc: cmp w8, #1
26862e0: b.lt #0x2686310
26862e4: adrp x22, #0x520e000
26862e8: ldr x22, [x22, #0x368]
26862ec: mov x1, xzr
26862f0: mov x2, xzr
26862f4: ldr x0, [x22]
26862f8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26862fc: ldr x1, [x22]
2686300: ldr x3, [x21]
2686304: mov x2, x0
2686308: mov x0, x20
268630c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686310: ldr w8, [x19, #0x80]
2686314: cmp w8, #1
2686318: b.lt #0x2686348
268631c: adrp x22, #0x51f9000
2686320: ldr x22, [x22, #0x290]
2686324: mov x1, xzr
2686328: mov x2, xzr
268632c: ldr x0, [x22]
2686330: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686334: ldr x1, [x22]
2686338: ldr x3, [x21]
268633c: mov x2, x0
2686340: mov x0, x20
2686344: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686348: ldr w8, [x19, #0x84]
268634c: cmp w8, #1
2686350: b.lt #0x2686380
2686354: adrp x22, #0x519f000
2686358: ldr x22, [x22, #0x488]
268635c: mov x1, xzr
2686360: mov x2, xzr
2686364: ldr x0, [x22]
2686368: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268636c: ldr x1, [x22]
2686370: ldr x3, [x21]
2686374: mov x2, x0
2686378: mov x0, x20
268637c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686380: ldr w8, [x19, #0x88]
2686384: cmp w8, #1
2686388: b.lt #0x26863b8
268638c: adrp x22, #0x51eb000
2686390: ldr x22, [x22, #0x538]
2686394: mov x1, xzr
2686398: mov x2, xzr
268639c: ldr x0, [x22]
26863a0: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26863a4: ldr x1, [x22]
26863a8: ldr x3, [x21]
26863ac: mov x2, x0
26863b0: mov x0, x20
26863b4: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26863b8: ldr w8, [x19, #0x8c]
26863bc: cmp w8, #1
26863c0: b.lt #0x26863f0
26863c4: adrp x22, #0x51db000
26863c8: ldr x22, [x22, #0xcc0]
26863cc: mov x1, xzr
26863d0: mov x2, xzr
26863d4: ldr x0, [x22]
26863d8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26863dc: ldr x1, [x22]
26863e0: ldr x3, [x21]
26863e4: mov x2, x0
26863e8: mov x0, x20
26863ec: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26863f0: ldr w8, [x19, #0x90]
26863f4: cmp w8, #1
26863f8: b.lt #0x2686428
26863fc: adrp x22, #0x523d000
2686400: ldr x22, [x22, #0xa8]
2686404: mov x1, xzr
2686408: mov x2, xzr
268640c: ldr x0, [x22]
2686410: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686414: ldr x1, [x22]
2686418: ldr x3, [x21]
268641c: mov x2, x0
2686420: mov x0, x20
2686424: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686428: ldr w8, [x19, #0x94]
268642c: cmp w8, #1
2686430: b.lt #0x2686460
2686434: adrp x22, #0x51ad000
2686438: ldr x22, [x22, #0x6e0]
268643c: mov x1, xzr
2686440: mov x2, xzr
2686444: ldr x0, [x22]
2686448: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268644c: ldr x1, [x22]
2686450: ldr x3, [x21]
2686454: mov x2, x0
2686458: mov x0, x20
268645c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686460: ldr w8, [x19, #0xa0]
2686464: cmp w8, #1
2686468: b.lt #0x2686498
268646c: adrp x22, #0x51e8000
2686470: ldr x22, [x22, #0xd0]
2686474: mov x1, xzr
2686478: mov x2, xzr
268647c: ldr x0, [x22]
2686480: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686484: ldr x1, [x22]
2686488: ldr x3, [x21]
268648c: mov x2, x0
2686490: mov x0, x20
2686494: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686498: ldr w8, [x19, #0xb4]
268649c: cmp w8, #1
26864a0: b.lt #0x26864d0
26864a4: adrp x22, #0x51cf000
26864a8: ldr x22, [x22, #0xd10]
26864ac: mov x1, xzr
26864b0: mov x2, xzr
26864b4: ldr x0, [x22]
26864b8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26864bc: ldr x1, [x22]
26864c0: ldr x3, [x21]
26864c4: mov x2, x0
26864c8: mov x0, x20
26864cc: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26864d0: ldr w8, [x19, #0xb8]
26864d4: cmp w8, #1
26864d8: b.lt #0x2686508
26864dc: adrp x22, #0x521f000
26864e0: ldr x22, [x22, #0xd90]
26864e4: mov x1, xzr
26864e8: mov x2, xzr
26864ec: ldr x0, [x22]
26864f0: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
26864f4: ldr x1, [x22]
26864f8: ldr x3, [x21]
26864fc: mov x2, x0
2686500: mov x0, x20
2686504: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686508: ldr w8, [x19, #0xcc]
268650c: cmp w8, #1
2686510: b.lt #0x2686540
2686514: adrp x22, #0x51dd000
2686518: ldr x22, [x22, #0xed8]
268651c: mov x1, xzr
2686520: mov x2, xzr
2686524: ldr x0, [x22]
2686528: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268652c: ldr x1, [x22]
2686530: ldr x3, [x21]
2686534: mov x2, x0
2686538: mov x0, x20
268653c: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686540: ldr w8, [x19, #0x70]
2686544: cmp w8, #1
2686548: b.lt #0x2686578
268654c: adrp x22, #0x5202000
2686550: ldr x22, [x22, #0x7b0]
2686554: mov x1, xzr
2686558: mov x2, xzr
268655c: ldr x0, [x22]
2686560: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2686564: ldr x1, [x22]
2686568: ldr x3, [x21]
268656c: mov x2, x0
2686570: mov x0, x20
2686574: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
2686578: ldr w8, [x19, #0x74]
268657c: cmp w8, #1
2686580: b.lt #0x26865b8
2686584: adrp x19, #0x5220000
2686588: ldr x19, [x19, #0xf68]
268658c: mov x1, xzr
2686590: mov x2, xzr
2686594: ldr x0, [x19]
2686598: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
268659c: ldr x1, [x19]
26865a0: ldr x3, [x21]
26865a4: mov x2, x0
26865a8: mov x0, x20
26865ac: bl #0x3bea080 ; System.Collections.Generic.Dictionary<object, long>$$Add
26865b0: b #0x26865b8 ; 
26865b4: mov x20, xzr
26865b8: mov x0, x20
26865bc: ldp x19, x30, [sp, #0x20]
26865c0: ldp x21, x20, [sp, #0x10]
26865c4: ldp x23, x22, [sp], #0x30
26865c8: ret 
26865cc: bl #0xfb1428 ; 
