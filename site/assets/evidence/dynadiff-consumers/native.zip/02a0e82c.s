# Royal.Player.Context.Data.Persistent.UserInventory$$GetTryCount2
# Linear metadata span; not complete CFG.
2a0e82c: str x30, [sp, #-0x10]!
2a0e830: ldr x0, [x0, #0xb0]
2a0e834: mov w1, #1
2a0e838: mov w2, #0xc
2a0e83c: mov x3, xzr
2a0e840: bl #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
2a0e844: ldr x30, [sp], #0x10
2a0e848: ret 
