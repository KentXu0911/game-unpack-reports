# Royal.Player.Context.Data.Persistent.UserInventory$$get_DynamicDifficultyInventory
# Linear metadata span; not complete CFG.
2a097f4: ldr x0, [x0, #0xb0]
2a097f8: ret 
