# Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$SetLong
# Linear metadata span; not complete CFG.
2e60270: sub sp, sp, #0x70
2e60274: stp x23, x22, [sp, #0x40]
2e60278: stp x21, x20, [sp, #0x50]
2e6027c: stp x19, x30, [sp, #0x60]
2e60280: adrp x22, #0x5584000
2e60284: str x2, [sp, #0x38]
2e60288: adrp x23, #0x51af000
2e6028c: ldrb w8, [x22, #0x862]
2e60290: ldr x23, [x23, #0x1d8]
2e60294: mov w20, w3
2e60298: mov x21, x1
2e6029c: mov x19, x0
2e602a0: tbnz w8, #0, #0x2e602b8
2e602a4: adrp x0, #0x51af000
2e602a8: ldr x0, [x0, #0x1d8]
2e602ac: bl #0xfb1300 ; 
2e602b0: mov w8, #1
2e602b4: strb w8, [x22, #0x862]
2e602b8: add x8, sp, #0x20
2e602bc: add x0, sp, #0x20
2e602c0: mov x1, x21
2e602c4: stp xzr, xzr, [sp, #0x28]
2e602c8: add x22, x8, #8
2e602cc: str x21, [sp, #0x20]
2e602d0: bl #0xfb12ac ; 
2e602d4: add x0, sp, #0x38
2e602d8: mov x1, xzr
2e602dc: bl #0x2596260 ; System.Int64$$ToString
2e602e0: mov x1, x0
2e602e4: str x0, [sp, #0x28]
2e602e8: mov x0, x22
2e602ec: bl #0xfb12ac ; 
2e602f0: mvn w9, w20
2e602f4: and w8, w20, #1
2e602f8: and w9, w9, #1
2e602fc: stp w8, w9, [sp, #0x30]
2e60300: ldr q0, [sp, #0x20]
2e60304: ldr x8, [sp, #0x30]
2e60308: ldr x0, [x23]
2e6030c: mov x1, sp
2e60310: str q0, [sp]
2e60314: str x8, [sp, #0x10]
2e60318: bl #0xfb140c ; 
2e6031c: cbz x19, #0x2e60348
2e60320: mov x1, x0
2e60324: mov x0, x19
2e60328: bl #0x2e59ff0 ; Royal.Infrastructure.Services.Storage.DatabaseService$$InsertOrReplace
2e6032c: ldp x19, x30, [sp, #0x60]
2e60330: ldp x21, x20, [sp, #0x50]
2e60334: ldp x23, x22, [sp, #0x40]
2e60338: cmp w0, #0
2e6033c: cset w0, gt
2e60340: add sp, sp, #0x70
2e60344: ret 
2e60348: bl #0xfb1428 ; 
