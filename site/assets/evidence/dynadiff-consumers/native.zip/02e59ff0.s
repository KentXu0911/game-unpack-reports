# Royal.Infrastructure.Services.Storage.DatabaseService$$InsertOrReplace
# Linear metadata span; not complete CFG.
2e59ff0: str x30, [sp, #-0x10]!
2e59ff4: mov x8, x0
2e59ff8: ldr x0, [x0, #0x10]
2e59ffc: mov w9, #1
2e5a000: strb w9, [x8, #0x1c]
2e5a004: cbz x0, #0x2e5a014
2e5a008: mov x2, xzr
2e5a00c: ldr x30, [sp], #0x10
2e5a010: b #0x314387c ; Plugins.Sqlite.SQLiteConnection$$InsertOrReplace
2e5a014: bl #0xfb1428 ; 
