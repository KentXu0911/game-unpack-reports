# Royal.Player.Context.Data.Persistent.UserInventory$$set_DynamicDifficultyInventory
# Linear metadata span; not complete CFG.
2a097fc: str x1, [x0, #0xb0]
2a09800: ret 
