# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetUpdatedMoveCount
# Linear metadata span; not complete CFG.
1c8532c: str x22, [sp, #-0x30]!
1c85330: stp x21, x20, [sp, #0x10]
1c85334: stp x19, x30, [sp, #0x20]
1c85338: adrp x20, #0x557b000
1c8533c: ldrb w8, [x20, #0x5dd]
1c85340: mov w19, w1
1c85344: tbnz w8, #0, #0x1c85368
1c85348: adrp x0, #0x51f7000
1c8534c: ldr x0, [x0, #0xb60]
1c85350: bl #0xfb1300 ; 
1c85354: adrp x0, #0x51b3000
1c85358: ldr x0, [x0, #0x340]
1c8535c: bl #0xfb1300 ; 
1c85360: mov w8, #1
1c85364: strb w8, [x20, #0x5dd]
1c85368: adrp x21, #0x5576000
1c8536c: ldrb w8, [x21, #0xf2b]
1c85370: cbnz w8, #0x1c85388
1c85374: adrp x0, #0x5208000
1c85378: ldr x0, [x0, #0x380]
1c8537c: bl #0xfb1300 ; 
1c85380: mov w8, #1
1c85384: strb w8, [x21, #0xf2b]
1c85388: adrp x22, #0x5208000
1c8538c: ldr x22, [x22, #0x380]
1c85390: ldr x8, [x22]
1c85394: ldr x8, [x8, #0xb8]
1c85398: ldr x8, [x8]
1c8539c: cbz x8, #0x1c85450
1c853a0: ldr x8, [x8, #0x38]
1c853a4: cbz x8, #0x1c85450
1c853a8: ldr x0, [x8, #0x18]
1c853ac: cbz x0, #0x1c85450
1c853b0: mov x1, xzr
1c853b4: bl #0x245b578 ; Royal.Player.Context.Data.Session.UserActiveLevelData$$get_IsLeague
1c853b8: tbz w0, #0, #0x1c8543c
1c853bc: adrp x8, #0x51b3000
1c853c0: ldr x8, [x8, #0x340]
1c853c4: adrp x20, #0x51f7000
1c853c8: ldr x0, [x8]
1c853cc: ldr w8, [x0, #0xe0]
1c853d0: ldr x20, [x20, #0xb60]
1c853d4: cbnz w8, #0x1c853dc
1c853d8: bl #0xfb1404 ; 
1c853dc: ldr x1, [x20]
1c853e0: mov w0, #5
1c853e4: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
1c853e8: ldrb w8, [x21, #0xf2b]
1c853ec: mov x20, x0
1c853f0: cbnz w8, #0x1c85408
1c853f4: adrp x0, #0x5208000
1c853f8: ldr x0, [x0, #0x380]
1c853fc: bl #0xfb1300 ; 
1c85400: mov w8, #1
1c85404: strb w8, [x21, #0xf2b]
1c85408: ldr x8, [x22]
1c8540c: ldr x8, [x8, #0xb8]
1c85410: ldr x8, [x8]
1c85414: cbz x8, #0x1c85450
1c85418: ldr x8, [x8, #0x18]
1c8541c: cbz x8, #0x1c85450
1c85420: cbz x20, #0x1c85450
1c85424: ldr w1, [x8, #0x18]
1c85428: mov x0, x20
1c8542c: mov x2, xzr
1c85430: bl #0x2055cbc ; Royal.Player.Context.Units.LeagueManager$$GetLeagueLevel
1c85434: lsr x8, x0, #0x20
1c85438: add w19, w8, w19
1c8543c: mov w0, w19
1c85440: ldp x19, x30, [sp, #0x20]
1c85444: ldp x21, x20, [sp, #0x10]
1c85448: ldr x22, [sp], #0x30
1c8544c: ret 
1c85450: bl #0xfb1428 ; 
