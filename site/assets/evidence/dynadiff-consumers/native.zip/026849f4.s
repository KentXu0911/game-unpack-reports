# Royal.Player.Context.Data.SyncManager$$UpdateDataFromLocalStorage
# Linear metadata span; not complete CFG.
26849f4: sub sp, sp, #0xb0
26849f8: str x22, [sp, #0x80]
26849fc: stp x21, x20, [sp, #0x90]
2684a00: stp x19, x30, [sp, #0xa0]
2684a04: adrp x19, #0x557f000
2684a08: ldrb w8, [x19, #0xe92]
2684a0c: tbnz w8, #0, #0x2684b68
2684a10: adrp x0, #0x51f4000
2684a14: ldr x0, [x0, #0x640]
2684a18: bl #0xfb1300 ; 
2684a1c: adrp x0, #0x5206000
2684a20: ldr x0, [x0, #0x558]
2684a24: bl #0xfb1300 ; 
2684a28: adrp x0, #0x51f2000
2684a2c: ldr x0, [x0, #0xb60]
2684a30: bl #0xfb1300 ; 
2684a34: adrp x0, #0x51f0000
2684a38: ldr x0, [x0, #0x4c0]
2684a3c: bl #0xfb1300 ; 
2684a40: adrp x0, #0x51e6000
2684a44: ldr x0, [x0, #0x398]
2684a48: bl #0xfb1300 ; 
2684a4c: adrp x0, #0x51ad000
2684a50: ldr x0, [x0, #0x6b8]
2684a54: bl #0xfb1300 ; 
2684a58: adrp x0, #0x51ed000
2684a5c: ldr x0, [x0, #0x280]
2684a60: bl #0xfb1300 ; 
2684a64: adrp x0, #0x51b6000
2684a68: ldr x0, [x0, #0xab0]
2684a6c: bl #0xfb1300 ; 
2684a70: adrp x0, #0x5193000
2684a74: ldr x0, [x0, #0x738]
2684a78: bl #0xfb1300 ; 
2684a7c: adrp x0, #0x51c8000
2684a80: ldr x0, [x0, #0xf98]
2684a84: bl #0xfb1300 ; 
2684a88: adrp x0, #0x51fa000
2684a8c: ldr x0, [x0, #0xd80]
2684a90: bl #0xfb1300 ; 
2684a94: adrp x0, #0x5224000
2684a98: ldr x0, [x0, #0x258]
2684a9c: bl #0xfb1300 ; 
2684aa0: adrp x0, #0x51f6000
2684aa4: ldr x0, [x0, #0x548]
2684aa8: bl #0xfb1300 ; 
2684aac: adrp x0, #0x5226000
2684ab0: ldr x0, [x0, #0x1e0]
2684ab4: bl #0xfb1300 ; 
2684ab8: adrp x0, #0x51b9000
2684abc: ldr x0, [x0, #0x840]
2684ac0: bl #0xfb1300 ; 
2684ac4: adrp x0, #0x5190000
2684ac8: ldr x0, [x0, #0x4e8]
2684acc: bl #0xfb1300 ; 
2684ad0: adrp x0, #0x51d0000
2684ad4: ldr x0, [x0, #0x1a8]
2684ad8: bl #0xfb1300 ; 
2684adc: adrp x0, #0x519e000
2684ae0: ldr x0, [x0, #0xf80]
2684ae4: bl #0xfb1300 ; 
2684ae8: adrp x0, #0x51fe000
2684aec: ldr x0, [x0, #0xa80]
2684af0: bl #0xfb1300 ; 
2684af4: adrp x0, #0x51e1000
2684af8: ldr x0, [x0, #0xba0]
2684afc: bl #0xfb1300 ; 
2684b00: adrp x0, #0x51bd000
2684b04: ldr x0, [x0, #0x900]
2684b08: bl #0xfb1300 ; 
2684b0c: adrp x0, #0x51f2000
2684b10: ldr x0, [x0, #0xe8]
2684b14: bl #0xfb1300 ; 
2684b18: adrp x0, #0x519a000
2684b1c: ldr x0, [x0, #0x530]
2684b20: bl #0xfb1300 ; 
2684b24: adrp x0, #0x51c0000
2684b28: ldr x0, [x0, #0x9f0]
2684b2c: bl #0xfb1300 ; 
2684b30: adrp x0, #0x5234000
2684b34: ldr x0, [x0, #0x688]
2684b38: bl #0xfb1300 ; 
2684b3c: adrp x0, #0x519e000
2684b40: ldr x0, [x0, #0xa20]
2684b44: bl #0xfb1300 ; 
2684b48: adrp x0, #0x5236000
2684b4c: ldr x0, [x0, #0x8d0]
2684b50: bl #0xfb1300 ; 
2684b54: adrp x0, #0x51d7000
2684b58: ldr x0, [x0, #0x6d0]
2684b5c: bl #0xfb1300 ; 
2684b60: mov w8, #1
2684b64: strb w8, [x19, #0xe92]
2684b68: adrp x19, #0x5576000
2684b6c: ldrb w8, [x19, #0xf2b]
2684b70: cbnz w8, #0x2684b88
2684b74: adrp x0, #0x5208000
2684b78: ldr x0, [x0, #0x380]
2684b7c: bl #0xfb1300 ; 
2684b80: mov w8, #1
2684b84: strb w8, [x19, #0xf2b]
2684b88: adrp x8, #0x5208000
2684b8c: ldr x8, [x8, #0x380]
2684b90: ldr x8, [x8]
2684b94: ldr x8, [x8, #0xb8]
2684b98: ldr x20, [x8]
2684b9c: cbz x20, #0x2685060
2684ba0: ldr x0, [x20, #0x10]
2684ba4: cbz x0, #0x2685060
2684ba8: adrp x21, #0x51b6000
2684bac: ldr x21, [x21, #0xab0]
2684bb0: bl #0x2685064 ; Royal.Player.Context.Data.UserId$$FillFromLocal
2684bb4: ldr x0, [x21]
2684bb8: ldr x19, [x20, #0x18]
2684bbc: mov w1, wzr
2684bc0: mov x2, xzr
2684bc4: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684bc8: cbz x19, #0x2685060
2684bcc: adrp x8, #0x519a000
2684bd0: ldr x8, [x8, #0x530]
2684bd4: str w0, [x19, #0x10]
2684bd8: ldr x19, [x20, #0x18]
2684bdc: mov w1, #1
2684be0: ldr x0, [x8]
2684be4: mov x2, xzr
2684be8: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684bec: cbz x19, #0x2685060
2684bf0: adrp x8, #0x51e1000
2684bf4: ldr x8, [x8, #0xba0]
2684bf8: str w0, [x19, #0x14]
2684bfc: ldr x19, [x20, #0x18]
2684c00: mov w1, wzr
2684c04: ldr x0, [x8]
2684c08: mov x2, xzr
2684c0c: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684c10: cbz x19, #0x2685060
2684c14: adrp x8, #0x5206000
2684c18: ldr x8, [x8, #0x558]
2684c1c: str w0, [x19, #0x18]
2684c20: adrp x21, #0x519e000
2684c24: ldr x19, [x20, #0x18]
2684c28: ldr x0, [x8]
2684c2c: ldr w8, [x0, #0xe0]
2684c30: ldr x21, [x21, #0xf80]
2684c34: cbnz w8, #0x2684c3c
2684c38: bl #0xfb1404 ; 
2684c3c: mov x0, xzr
2684c40: bl #0x2763134 ; Royal.Infrastructure.Utils.Time.TimeUtil$$CurrentTimeInMs
2684c44: ldr x8, [x21]
2684c48: mov x1, x0
2684c4c: mov x2, xzr
2684c50: mov x0, x8
2684c54: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684c58: cbz x19, #0x2685060
2684c5c: adrp x8, #0x51fe000
2684c60: ldr x8, [x8, #0xa80]
2684c64: str x0, [x19, #0x28]
2684c68: ldr x19, [x20, #0x18]
2684c6c: mov x1, xzr
2684c70: ldr x0, [x8]
2684c74: mov x2, xzr
2684c78: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684c7c: cbz x19, #0x2685060
2684c80: adrp x8, #0x5224000
2684c84: ldr x8, [x8, #0x258]
2684c88: str x0, [x19, #0x30]
2684c8c: ldr x19, [x20, #0x18]
2684c90: mov w1, wzr
2684c94: ldr x0, [x8]
2684c98: mov x2, xzr
2684c9c: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684ca0: cbz x19, #0x2685060
2684ca4: adrp x8, #0x51f2000
2684ca8: ldr x8, [x8, #0xe8]
2684cac: sxtw x9, w0
2684cb0: str x9, [x19, #0x38]
2684cb4: ldr x19, [x20, #0x18]
2684cb8: ldr x0, [x8]
2684cbc: mov w1, wzr
2684cc0: mov x2, xzr
2684cc4: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684cc8: cbz x19, #0x2685060
2684ccc: adrp x8, #0x51ad000
2684cd0: ldr x8, [x8, #0x6b8]
2684cd4: str w0, [x19, #0x1c]
2684cd8: ldr x19, [x20, #0x20]
2684cdc: mov w1, #0x7d0
2684ce0: ldr x0, [x8]
2684ce4: mov x2, xzr
2684ce8: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684cec: cbz x19, #0x2685060
2684cf0: adrp x8, #0x51e6000
2684cf4: ldr x8, [x8, #0x398]
2684cf8: str w0, [x19, #0x10]
2684cfc: ldr x19, [x20, #0x20]
2684d00: mov w1, wzr
2684d04: ldr x0, [x8]
2684d08: mov x2, xzr
2684d0c: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684d10: cbz x19, #0x2685060
2684d14: adrp x8, #0x51ed000
2684d18: ldr x8, [x8, #0x280]
2684d1c: str w0, [x19, #0x14]
2684d20: ldr x19, [x20, #0x20]
2684d24: mov w1, wzr
2684d28: ldr x0, [x8]
2684d2c: mov x2, xzr
2684d30: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684d34: cbz x19, #0x2685060
2684d38: adrp x8, #0x519e000
2684d3c: ldr x8, [x8, #0xa20]
2684d40: str w0, [x19, #0x18]
2684d44: ldr x19, [x20, #0x20]
2684d48: mov w1, wzr
2684d4c: ldr x0, [x8]
2684d50: mov x2, xzr
2684d54: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684d58: cbz x19, #0x2685060
2684d5c: adrp x8, #0x51f0000
2684d60: ldr x8, [x8, #0x4c0]
2684d64: str w0, [x19, #0x1c]
2684d68: ldr x19, [x20, #0x20]
2684d6c: mov x1, xzr
2684d70: ldr x0, [x8]
2684d74: mov x2, xzr
2684d78: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684d7c: cbz x19, #0x2685060
2684d80: str x0, [x19, #0x50]
2684d84: ldr x19, [x20, #0x20]
2684d88: bl #0x26853a8 ; Royal.Player.Context.Data.SyncManager$$InitFeature2Progress
2684d8c: cbz x19, #0x2685060
2684d90: adrp x8, #0x51fa000
2684d94: ldr x8, [x8, #0xd80]
2684d98: str x0, [x19, #0x58]
2684d9c: ldr x19, [x20, #0x20]
2684da0: mov w1, wzr
2684da4: ldr x0, [x8]
2684da8: mov x2, xzr
2684dac: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684db0: cbz x19, #0x2685060
2684db4: adrp x8, #0x5190000
2684db8: ldr x8, [x8, #0x4e8]
2684dbc: str w0, [x19, #0x38]
2684dc0: ldr x19, [x20, #0x20]
2684dc4: mov w1, wzr
2684dc8: ldr x0, [x8]
2684dcc: mov x2, xzr
2684dd0: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684dd4: cbz x19, #0x2685060
2684dd8: adrp x8, #0x5234000
2684ddc: ldr x8, [x8, #0x688]
2684de0: str w0, [x19, #0x3c]
2684de4: ldr x19, [x20, #0x20]
2684de8: mov w1, wzr
2684dec: ldr x0, [x8]
2684df0: mov x2, xzr
2684df4: bl #0x2e700b8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetInt
2684df8: cbz x19, #0x2685060
2684dfc: str w0, [x19, #0x40]
2684e00: ldr x0, [x20, #0x20]
2684e04: cbz x0, #0x2685060
2684e08: adrp x21, #0x51d0000
2684e0c: ldr x21, [x21, #0x1a8]
2684e10: mov x1, xzr
2684e14: bl #0x2a0f514 ; Royal.Player.Context.Data.Persistent.UserInventory$$InitUnlimitedInGameBoosterInventory
2684e18: ldr x0, [x21]
2684e1c: ldr x19, [x20, #0x20]
2684e20: mov x1, xzr
2684e24: mov x2, xzr
2684e28: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684e2c: mov x1, xzr
2684e30: bl #0x2a0a724 ; Royal.Player.Context.Data.Persistent.UserInventory$$InitEventInventory
2684e34: cbz x19, #0x2685060
2684e38: adrp x8, #0x51c8000
2684e3c: ldr x8, [x8, #0xf98]
2684e40: str x0, [x19, #0x20]
2684e44: ldr x19, [x20, #0x20]
2684e48: mov x1, xzr
2684e4c: ldr x0, [x8]
2684e50: mov x2, xzr
2684e54: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684e58: cbz x19, #0x2685060
2684e5c: adrp x8, #0x51d7000
2684e60: ldr x8, [x8, #0x6d0]
2684e64: str x0, [x19, #0x28]
2684e68: ldr x19, [x20, #0x20]
2684e6c: mov x1, xzr
2684e70: ldr x0, [x8]
2684e74: mov x2, xzr
2684e78: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684e7c: cbz x19, #0x2685060
2684e80: adrp x8, #0x51c0000
2684e84: ldr x8, [x8, #0x9f0]
2684e88: str x0, [x19, #0x30]
2684e8c: ldr x19, [x20, #0x20]
2684e90: mov x1, xzr
2684e94: ldr x0, [x8]
2684e98: mov x2, xzr
2684e9c: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684ea0: cbz x19, #0x2685060
2684ea4: str x0, [x19, #0x48]
2684ea8: ldr x19, [x20, #0x20]
2684eac: mov x8, sp
2684eb0: bl #0x2685404 ; Royal.Player.Context.Data.SyncManager$$InitRoyalPassProgress
2684eb4: ldp q1, q0, [sp]
2684eb8: ldr q2, [sp, #0x20]
2684ebc: ldr x8, [sp, #0x30]
2684ec0: stp q1, q0, [sp, #0x40]
2684ec4: str q2, [sp, #0x60]
2684ec8: str x8, [sp, #0x70]
2684ecc: cbz x19, #0x2685060
2684ed0: adrp x8, #0x51b9000
2684ed4: ldr x8, [x8, #0x840]
2684ed8: ldr x9, [sp, #0x70]
2684edc: ldp q1, q0, [sp, #0x50]
2684ee0: ldr q2, [sp, #0x40]
2684ee4: mov x1, xzr
2684ee8: str x9, [x19, #0x98]
2684eec: stur q0, [x19, #0x88]
2684ef0: stur q1, [x19, #0x78]
2684ef4: stur q2, [x19, #0x68]
2684ef8: ldr x0, [x8]
2684efc: ldr x19, [x20, #0x20]
2684f00: mov x2, xzr
2684f04: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684f08: cbz x19, #0x2685060
2684f0c: adrp x21, #0x51f4000
2684f10: ldr x21, [x21, #0x640]
2684f14: str x0, [x19, #0x60]
2684f18: adrp x9, #0x5193000
2684f1c: mov x2, xzr
2684f20: ldr x8, [x21]
2684f24: ldr x8, [x8, #0xb8]
2684f28: ldr x9, [x9, #0x738]
2684f2c: ldr x19, [x20, #0x30]
2684f30: ldr x1, [x8]
2684f34: ldr x0, [x9]
2684f38: bl #0x2e6dca8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetString
2684f3c: cbz x19, #0x2685060
2684f40: adrp x22, #0x51f2000
2684f44: ldr x22, [x22, #0xb60]
2684f48: str x0, [x19, #0x10]!
2684f4c: mov x1, x0
2684f50: mov x0, x19
2684f54: bl #0xfb12ac ; 
2684f58: ldr x0, [x22]
2684f5c: ldr x19, [x20, #0x20]
2684f60: mov x1, xzr
2684f64: mov x2, xzr
2684f68: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684f6c: mov x1, x0
2684f70: mov x0, sp
2684f74: mov x2, xzr
2684f78: stp xzr, xzr, [sp]
2684f7c: bl #0x2a016a4 ; Royal.Player.Context.Data.Persistent.TeamOfferProgress$$.ctor
2684f80: cbz x19, #0x2685060
2684f84: ldr q0, [sp]
2684f88: adrp x8, #0x51bd000
2684f8c: ldr x8, [x8, #0x900]
2684f90: mov x1, xzr
2684f94: str q0, [x19, #0xa0]
2684f98: ldr x19, [x20, #0x20]
2684f9c: ldr x0, [x8]
2684fa0: mov x2, xzr
2684fa4: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684fa8: cbz x19, #0x2685060
2684fac: adrp x8, #0x5236000
2684fb0: ldr x8, [x8, #0x8d0]
2684fb4: str x0, [x19, #0xb0]
2684fb8: ldr x19, [x20, #0x20]
2684fbc: mov x1, xzr
2684fc0: ldr x0, [x8]
2684fc4: mov x2, xzr
2684fc8: bl #0x2e70158 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
2684fcc: cbz x19, #0x2685060
2684fd0: adrp x22, #0x5226000
2684fd4: ldr x22, [x22, #0x1e0]
2684fd8: str x0, [x19, #0xb8]
2684fdc: mov x0, xzr
2684fe0: bl #0x33f96ac ; Royal.Scenes.Home.Context.Units.Area.Data.AreaDataParser$$ParseAndSetFromLocalStorage
2684fe4: ldr x8, [x21]
2684fe8: ldr x0, [x22]
2684fec: ldr x19, [x20, #0x48]
2684ff0: mov x2, xzr
2684ff4: ldr x8, [x8, #0xb8]
2684ff8: ldr x1, [x8]
2684ffc: bl #0x2e6dca8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetString
2685000: cbz x19, #0x2685060
2685004: adrp x22, #0x51f6000
2685008: ldr x22, [x22, #0x548]
268500c: str x0, [x19, #0x10]!
2685010: mov x1, x0
2685014: mov x0, x19
2685018: bl #0xfb12ac ; 
268501c: ldr x8, [x21]
2685020: ldr x0, [x22]
2685024: ldr x19, [x20, #0x48]
2685028: mov x2, xzr
268502c: ldr x8, [x8, #0xb8]
2685030: ldr x1, [x8]
2685034: bl #0x2e6dca8 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetString
2685038: cbz x19, #0x2685060
268503c: str x0, [x19, #0x18]!
2685040: mov x1, x0
2685044: mov x0, x19
2685048: bl #0xfb12ac ; 
268504c: ldp x19, x30, [sp, #0xa0]
2685050: ldp x21, x20, [sp, #0x90]
2685054: ldr x22, [sp, #0x80]
2685058: add sp, sp, #0xb0
268505c: ret 
2685060: bl #0xfb1428 ; 
