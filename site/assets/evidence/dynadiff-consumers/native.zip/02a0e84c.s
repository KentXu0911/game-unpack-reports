# Royal.Player.Context.Data.Persistent.UserInventory$$GetDeltaMove
# Linear metadata span; not complete CFG.
2a0e84c: str x30, [sp, #-0x10]!
2a0e850: ldr x0, [x0, #0xb0]
2a0e854: mov w1, #0xd
2a0e858: mov w2, #0x11
2a0e85c: mov x3, xzr
2a0e860: bl #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
2a0e864: sub w8, w0, #0xa
2a0e868: cmp w0, #0
2a0e86c: csel w0, wzr, w8, eq
2a0e870: ldr x30, [sp], #0x10
2a0e874: ret 
