# Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
# Linear metadata span; not complete CFG.
2a0e700: str x24, [sp, #-0x40]!
2a0e704: stp x23, x22, [sp, #0x10]
2a0e708: stp x21, x20, [sp, #0x20]
2a0e70c: stp x19, x30, [sp, #0x30]
2a0e710: adrp x24, #0x5581000
2a0e714: adrp x23, #0x5200000
2a0e718: adrp x22, #0x51ff000
2a0e71c: adrp x21, #0x5222000
2a0e720: ldrb w8, [x24, #0xd52]
2a0e724: ldr x23, [x23, #0xe8]
2a0e728: ldr x22, [x22, #0xc98]
2a0e72c: ldr x21, [x21, #0x5d8]
2a0e730: mov x19, x1
2a0e734: mov x20, x0
2a0e738: tbnz w8, #0, #0x2a0e774
2a0e73c: adrp x0, #0x5222000
2a0e740: ldr x0, [x0, #0x5d8]
2a0e744: bl #0xfb1300 ; 
2a0e748: adrp x0, #0x5200000
2a0e74c: ldr x0, [x0, #0xe8]
2a0e750: bl #0xfb1300 ; 
2a0e754: adrp x0, #0x51bd000
2a0e758: ldr x0, [x0, #0x900]
2a0e75c: bl #0xfb1300 ; 
2a0e760: adrp x0, #0x51ff000
2a0e764: ldr x0, [x0, #0xc98]
2a0e768: bl #0xfb1300 ; 
2a0e76c: mov w8, #1
2a0e770: strb w8, [x24, #0xd52]
2a0e774: ldr x0, [x23]
2a0e778: add x1, sp, #8
2a0e77c: str x19, [sp, #8]
2a0e780: bl #0xfb140c ; 
2a0e784: ldr x8, [x22]
2a0e788: mov x1, x0
2a0e78c: mov x2, xzr
2a0e790: mov x0, x8
2a0e794: bl #0x1cfdfd8 ; System.String$$Format
2a0e798: ldr x22, [x21]
2a0e79c: mov x21, x0
2a0e7a0: ldr x8, [x22, #0x38]
2a0e7a4: ldr x8, [x8]
2a0e7a8: ldrb w9, [x8, #0x132]
2a0e7ac: tbnz w9, #0, #0x2a0e7bc
2a0e7b0: mov x0, x8
2a0e7b4: bl #0xf80fe4 ; 
2a0e7b8: mov x8, x0
2a0e7bc: ldr w9, [x8, #0xe0]
2a0e7c0: cbnz w9, #0x2a0e7cc
2a0e7c4: mov x0, x8
2a0e7c8: bl #0xfb1404 ; 
2a0e7cc: ldr x8, [x22, #0x38]
2a0e7d0: adrp x22, #0x51bd000
2a0e7d4: ldr x0, [x8]
2a0e7d8: ldrb w8, [x0, #0x132]
2a0e7dc: ldr x22, [x22, #0x900]
2a0e7e0: tbnz w8, #0, #0x2a0e7e8
2a0e7e4: bl #0xf80fe4 ; 
2a0e7e8: ldr x8, [x0, #0xb8]
2a0e7ec: mov w1, #0xa
2a0e7f0: mov x0, x20
2a0e7f4: mov x2, x21
2a0e7f8: ldr x3, [x8]
2a0e7fc: mov x4, xzr
2a0e800: bl #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
2a0e804: str x19, [x20, #0xb0]
2a0e808: ldr x0, [x22]
2a0e80c: mov x1, x19
2a0e810: mov x2, xzr
2a0e814: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
2a0e818: ldp x19, x30, [sp, #0x30]
2a0e81c: ldp x21, x20, [sp, #0x20]
2a0e820: ldp x23, x22, [sp, #0x10]
2a0e824: ldr x24, [sp], #0x40
2a0e828: ret 
