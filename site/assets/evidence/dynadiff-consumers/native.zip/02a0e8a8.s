# Royal.Player.Context.Data.Persistent.UserInventory$$GetLastUpdatedSection
# Linear metadata span; not complete CFG.
2a0e8a8: str x30, [sp, #-0x10]!
2a0e8ac: ldr x0, [x0, #0xb0]
2a0e8b0: mov w1, #0x12
2a0e8b4: mov w2, #0x22
2a0e8b8: mov x3, xzr
2a0e8bc: bl #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
2a0e8c0: ldr x30, [sp], #0x10
2a0e8c4: ret 
