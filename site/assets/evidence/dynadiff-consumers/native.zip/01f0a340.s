# Royal.Player.Context.Units.UserManager$$ProcessKeyValueResponse
# Linear metadata span; not complete CFG.
1f0a340: sub sp, sp, #0x140
1f0a344: stp x28, x27, [sp, #0xe0]
1f0a348: stp x26, x25, [sp, #0xf0]
1f0a34c: stp x24, x23, [sp, #0x100]
1f0a350: stp x22, x21, [sp, #0x110]
1f0a354: stp x20, x19, [sp, #0x120]
1f0a358: stp x29, x30, [sp, #0x130]
1f0a35c: adrp x20, #0x557c000
1f0a360: ldrb w8, [x20, #0x732]
1f0a364: mov x26, x0
1f0a368: stp x1, x2, [sp, #0xd0]
1f0a36c: tbnz w8, #0, #0x1f0a570
1f0a370: adrp x0, #0x51e9000
1f0a374: ldr x0, [x0, #0xed0]
1f0a378: bl #0xfb1300 ; 
1f0a37c: adrp x0, #0x51c3000
1f0a380: ldr x0, [x0, #0xe70]
1f0a384: bl #0xfb1300 ; 
1f0a388: adrp x0, #0x5201000
1f0a38c: ldr x0, [x0, #0x510]
1f0a390: bl #0xfb1300 ; 
1f0a394: adrp x0, #0x51f2000
1f0a398: ldr x0, [x0, #0xb60]
1f0a39c: bl #0xfb1300 ; 
1f0a3a0: adrp x0, #0x51cd000
1f0a3a4: ldr x0, [x0, #0x1c0]
1f0a3a8: bl #0xfb1300 ; 
1f0a3ac: adrp x0, #0x5233000
1f0a3b0: ldr x0, [x0, #0x3b0]
1f0a3b4: bl #0xfb1300 ; 
1f0a3b8: adrp x0, #0x51ea000
1f0a3bc: ldr x0, [x0, #0x9f8]
1f0a3c0: bl #0xfb1300 ; 
1f0a3c4: adrp x0, #0x51d5000
1f0a3c8: ldr x0, [x0, #0x4e0]
1f0a3cc: bl #0xfb1300 ; 
1f0a3d0: adrp x0, #0x51a1000
1f0a3d4: ldr x0, [x0, #0x728]
1f0a3d8: bl #0xfb1300 ; 
1f0a3dc: adrp x0, #0x51ad000
1f0a3e0: ldr x0, [x0, #0x6e0]
1f0a3e4: bl #0xfb1300 ; 
1f0a3e8: adrp x0, #0x51dd000
1f0a3ec: ldr x0, [x0, #0xed8]
1f0a3f0: bl #0xfb1300 ; 
1f0a3f4: adrp x0, #0x5207000
1f0a3f8: ldr x0, [x0, #0xd18]
1f0a3fc: bl #0xfb1300 ; 
1f0a400: adrp x0, #0x51b7000
1f0a404: ldr x0, [x0, #0x850]
1f0a408: bl #0xfb1300 ; 
1f0a40c: adrp x0, #0x5197000
1f0a410: ldr x0, [x0, #0x290]
1f0a414: bl #0xfb1300 ; 
1f0a418: adrp x0, #0x520e000
1f0a41c: ldr x0, [x0, #0x368]
1f0a420: bl #0xfb1300 ; 
1f0a424: adrp x0, #0x51db000
1f0a428: ldr x0, [x0, #0xcc0]
1f0a42c: bl #0xfb1300 ; 
1f0a430: adrp x0, #0x51ff000
1f0a434: ldr x0, [x0, #8]
1f0a438: bl #0xfb1300 ; 
1f0a43c: adrp x0, #0x521f000
1f0a440: ldr x0, [x0, #0xd90]
1f0a444: bl #0xfb1300 ; 
1f0a448: adrp x0, #0x51be000
1f0a44c: ldr x0, [x0, #0xd50]
1f0a450: bl #0xfb1300 ; 
1f0a454: adrp x0, #0x519f000
1f0a458: ldr x0, [x0, #0x488]
1f0a45c: bl #0xfb1300 ; 
1f0a460: adrp x0, #0x51b3000
1f0a464: ldr x0, [x0, #0x3c8]
1f0a468: bl #0xfb1300 ; 
1f0a46c: adrp x0, #0x51cf000
1f0a470: ldr x0, [x0, #0xd10]
1f0a474: bl #0xfb1300 ; 
1f0a478: adrp x0, #0x5202000
1f0a47c: ldr x0, [x0, #0x7b0]
1f0a480: bl #0xfb1300 ; 
1f0a484: adrp x0, #0x523e000
1f0a488: ldr x0, [x0, #0x590]
1f0a48c: bl #0xfb1300 ; 
1f0a490: adrp x0, #0x5239000
1f0a494: ldr x0, [x0, #0x50]
1f0a498: bl #0xfb1300 ; 
1f0a49c: adrp x0, #0x51f9000
1f0a4a0: ldr x0, [x0, #0x290]
1f0a4a4: bl #0xfb1300 ; 
1f0a4a8: adrp x0, #0x51a7000
1f0a4ac: ldr x0, [x0, #0xac8]
1f0a4b0: bl #0xfb1300 ; 
1f0a4b4: adrp x0, #0x51bd000
1f0a4b8: ldr x0, [x0, #0x900]
1f0a4bc: bl #0xfb1300 ; 
1f0a4c0: adrp x0, #0x5196000
1f0a4c4: ldr x0, [x0, #0xde8]
1f0a4c8: bl #0xfb1300 ; 
1f0a4cc: adrp x0, #0x5210000
1f0a4d0: ldr x0, [x0, #0xb88]
1f0a4d4: bl #0xfb1300 ; 
1f0a4d8: adrp x0, #0x51e2000
1f0a4dc: ldr x0, [x0, #0xd38]
1f0a4e0: bl #0xfb1300 ; 
1f0a4e4: adrp x0, #0x51eb000
1f0a4e8: ldr x0, [x0, #0x538]
1f0a4ec: bl #0xfb1300 ; 
1f0a4f0: adrp x0, #0x51fd000
1f0a4f4: ldr x0, [x0, #0xa28]
1f0a4f8: bl #0xfb1300 ; 
1f0a4fc: adrp x0, #0x5201000
1f0a500: ldr x0, [x0, #0x930]
1f0a504: bl #0xfb1300 ; 
1f0a508: adrp x0, #0x5219000
1f0a50c: ldr x0, [x0, #0xc0]
1f0a510: bl #0xfb1300 ; 
1f0a514: adrp x0, #0x5220000
1f0a518: ldr x0, [x0, #0xf68]
1f0a51c: bl #0xfb1300 ; 
1f0a520: adrp x0, #0x5236000
1f0a524: ldr x0, [x0, #0x8d0]
1f0a528: bl #0xfb1300 ; 
1f0a52c: adrp x0, #0x5236000
1f0a530: ldr x0, [x0, #0xe58]
1f0a534: bl #0xfb1300 ; 
1f0a538: adrp x0, #0x51d5000
1f0a53c: ldr x0, [x0, #0x9c8]
1f0a540: bl #0xfb1300 ; 
1f0a544: adrp x0, #0x51e8000
1f0a548: ldr x0, [x0, #0xd0]
1f0a54c: bl #0xfb1300 ; 
1f0a550: adrp x0, #0x523d000
1f0a554: ldr x0, [x0, #0xa8]
1f0a558: bl #0xfb1300 ; 
1f0a55c: adrp x0, #0x51b9000
1f0a560: ldr x0, [x0, #0x7f8]
1f0a564: bl #0xfb1300 ; 
1f0a568: mov w8, #1
1f0a56c: strb w8, [x20, #0x732]
1f0a570: add x0, sp, #0xd0
1f0a574: mov x1, xzr
1f0a578: stp xzr, xzr, [sp, #0xc0]
1f0a57c: stp xzr, xzr, [sp, #0xa8]
1f0a580: stp xzr, xzr, [sp, #0x98]
1f0a584: stp xzr, xzr, [sp, #0x88]
1f0a588: str xzr, [sp, #0x80]
1f0a58c: stp xzr, xzr, [sp, #0x68]
1f0a590: str xzr, [sp, #0x60]
1f0a594: bl #0x3295ecc ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_KeyValueListLength
1f0a598: cmp w0, #1
1f0a59c: b.lt #0x1f0ba70
1f0a5a0: adrp x21, #0x51e8000
1f0a5a4: adrp x19, #0x5220000
1f0a5a8: adrp x27, #0x51bd000
1f0a5ac: adrp x29, #0x5202000
1f0a5b0: adrp x23, #0x5197000
1f0a5b4: adrp x24, #0x51b7000
1f0a5b8: ldr x21, [x21, #0xd0]
1f0a5bc: ldr x19, [x19, #0xf68]
1f0a5c0: ldr x27, [x27, #0x900]
1f0a5c4: ldr x29, [x29, #0x7b0]
1f0a5c8: ldr x23, [x23, #0x290]
1f0a5cc: ldr x24, [x24, #0x850]
1f0a5d0: mov w25, #0xa763
1f0a5d4: mov w28, #0xf916
1f0a5d8: mov w20, wzr
1f0a5dc: movk w25, #0x4fd8, lsl #16
1f0a5e0: movk w28, #0x2aac, lsl #16
1f0a5e4: add x8, sp, #0x40
1f0a5e8: add x0, sp, #0xd0
1f0a5ec: mov w1, w20
1f0a5f0: mov x2, xzr
1f0a5f4: bl #0x3295df4 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$KeyValueList
1f0a5f8: adrp x9, #0x51c3000
1f0a5fc: ldr q0, [sp, #0x40]
1f0a600: ldr x8, [sp, #0x50]
1f0a604: ldr x9, [x9, #0xe70]
1f0a608: add x0, sp, #0xa0
1f0a60c: str q0, [sp, #0xa0]
1f0a610: str x8, [sp, #0xb0]
1f0a614: ldr x1, [x9]
1f0a618: bl #0x279f788 ; System.Nullable<KeyValue>$$get_Value
1f0a61c: stp x0, x1, [sp, #0xc0]
1f0a620: add x0, sp, #0xc0
1f0a624: mov x1, xzr
1f0a628: bl #0x27f3508 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Key
1f0a62c: mov x1, xzr
1f0a630: mov x22, x0
1f0a634: bl #0x22f70a4 ; <PrivateImplementationDetails>$$ComputeStringHash
1f0a638: cmp w0, w25
1f0a63c: b.hi #0x1f0a704
1f0a640: cmp w0, w28
1f0a644: b.hi #0x1f0a7cc
1f0a648: mov w8, #0x5907
1f0a64c: movk w8, #0x17d8, lsl #16
1f0a650: cmp w0, w8
1f0a654: adrp x8, #0x5201000
1f0a658: ldr x8, [x8, #0x930]
1f0a65c: b.hi #0x1f0a944
1f0a660: mov w9, #0xc2d6
1f0a664: movk w9, #0x889, lsl #16
1f0a668: cmp w0, w9
1f0a66c: b.hi #0x1f0abb8
1f0a670: mov w9, #0xc143
1f0a674: movk w9, #0x789, lsl #16
1f0a678: cmp w0, w9
1f0a67c: b.eq #0x1f0aff4
1f0a680: mov w8, #0xc2d6
1f0a684: movk w8, #0x889, lsl #16
1f0a688: cmp w0, w8
1f0a68c: b.ne #0x1f0ba14
1f0a690: adrp x8, #0x51fd000
1f0a694: ldr x8, [x8, #0xa28]
1f0a698: mov x0, x22
1f0a69c: mov x2, xzr
1f0a6a0: ldr x1, [x8]
1f0a6a4: bl #0x1d063b4 ; System.String$$op_Equality
1f0a6a8: tbz w0, #0, #0x1f0ba14
1f0a6ac: add x0, sp, #0xc0
1f0a6b0: mov x1, xzr
1f0a6b4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a6b8: adrp x8, #0x51fd000
1f0a6bc: ldr x8, [x8, #0xa28]
1f0a6c0: mov x1, x0
1f0a6c4: mov x2, xzr
1f0a6c8: ldr x8, [x8]
1f0a6cc: mov x0, x8
1f0a6d0: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0a6d4: ldr x22, [x26, #0xb8]
1f0a6d8: add x0, sp, #0xc0
1f0a6dc: mov x1, xzr
1f0a6e0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a6e4: cbz x22, #0x1f0bc1c
1f0a6e8: mov x1, x0
1f0a6ec: mov x0, x22
1f0a6f0: mov x2, xzr
1f0a6f4: bl #0x2067128 ; Royal.Player.Context.Units.TeamTournamentManager$$UpdateProgressValue2
1f0a6f8: adrp x8, #0x51fd000
1f0a6fc: ldr x8, [x8, #0xa28]
1f0a700: b #0x1f0ba0c ; 
1f0a704: mov w8, #0x6002
1f0a708: movk w8, #0x94a5, lsl #16
1f0a70c: cmp w0, w8
1f0a710: b.hi #0x1f0a898
1f0a714: mov w8, #0xd595
1f0a718: movk w8, #0x872e, lsl #16
1f0a71c: cmp w0, w8
1f0a720: b.hi #0x1f0a9e4
1f0a724: mov w8, #0x8af8
1f0a728: movk w8, #0x7863, lsl #16
1f0a72c: cmp w0, w8
1f0a730: b.hi #0x1f0ac14
1f0a734: mov w8, #0x228
1f0a738: movk w8, #0x5cb9, lsl #16
1f0a73c: cmp w0, w8
1f0a740: b.eq #0x1f0b080
1f0a744: mov w8, #0x8af8
1f0a748: movk w8, #0x7863, lsl #16
1f0a74c: cmp w0, w8
1f0a750: b.ne #0x1f0ba14
1f0a754: adrp x8, #0x51dd000
1f0a758: ldr x8, [x8, #0xed8]
1f0a75c: mov x0, x22
1f0a760: mov x2, xzr
1f0a764: ldr x1, [x8]
1f0a768: bl #0x1d063b4 ; System.String$$op_Equality
1f0a76c: tbz w0, #0, #0x1f0ba14
1f0a770: add x0, sp, #0xc0
1f0a774: mov x1, xzr
1f0a778: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a77c: adrp x8, #0x51dd000
1f0a780: ldr x8, [x8, #0xed8]
1f0a784: mov x1, x0
1f0a788: mov x2, xzr
1f0a78c: ldr x8, [x8]
1f0a790: mov x0, x8
1f0a794: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0a798: ldr x22, [x26, #0x128]
1f0a79c: add x0, sp, #0xc0
1f0a7a0: mov x1, xzr
1f0a7a4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a7a8: cbz x22, #0x1f0bc1c
1f0a7ac: mov x1, x0
1f0a7b0: mov x0, x22
1f0a7b4: mov w2, wzr
1f0a7b8: mov x3, xzr
1f0a7bc: bl #0x1c74dc4 ; Royal.Player.Context.Units.JourneyOfferManager$$UpdateProgress
1f0a7c0: adrp x8, #0x51dd000
1f0a7c4: ldr x8, [x8, #0xed8]
1f0a7c8: b #0x1f0ba0c ; 
1f0a7cc: mov w8, #0xe0e2
1f0a7d0: movk w8, #0x40c9, lsl #16
1f0a7d4: cmp w0, w8
1f0a7d8: b.hi #0x1f0aa84
1f0a7dc: mov w8, #0x7d9f
1f0a7e0: movk w8, #0x349f, lsl #16
1f0a7e4: cmp w0, w8
1f0a7e8: adrp x8, #0x523e000
1f0a7ec: ldr x8, [x8, #0x590]
1f0a7f0: b.hi #0x1f0acb8
1f0a7f4: mov w9, #0xd859
1f0a7f8: movk w9, #0x32dd, lsl #16
1f0a7fc: cmp w0, w9
1f0a800: b.eq #0x1f0b0f8
1f0a804: mov w8, #0x7d9f
1f0a808: movk w8, #0x349f, lsl #16
1f0a80c: cmp w0, w8
1f0a810: b.ne #0x1f0ba14
1f0a814: adrp x8, #0x51ea000
1f0a818: ldr x8, [x8, #0x9f8]
1f0a81c: mov x0, x22
1f0a820: mov x2, xzr
1f0a824: ldr x1, [x8]
1f0a828: bl #0x1d063b4 ; System.String$$op_Equality
1f0a82c: tbz w0, #0, #0x1f0ba14
1f0a830: add x0, sp, #0xc0
1f0a834: mov x1, xzr
1f0a838: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a83c: adrp x8, #0x51ea000
1f0a840: ldr x8, [x8, #0x9f8]
1f0a844: mov x1, x0
1f0a848: mov x2, xzr
1f0a84c: ldr x8, [x8]
1f0a850: mov x0, x8
1f0a854: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0a858: ldr x22, [x26, #0x80]
1f0a85c: add x0, sp, #0xc0
1f0a860: mov x1, xzr
1f0a864: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a868: cbz x22, #0x1f0bc1c
1f0a86c: mov x1, x0
1f0a870: mov x0, x22
1f0a874: mov x2, xzr
1f0a878: bl #0x1dc6c8c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateProgress1
1f0a87c: ldr x0, [x26, #0x80]
1f0a880: cbz x0, #0x1f0bc1c
1f0a884: mov x1, xzr
1f0a888: bl #0x1dc6f1c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateLocalData
1f0a88c: adrp x8, #0x51ea000
1f0a890: ldr x8, [x8, #0x9f8]
1f0a894: b #0x1f0ba0c ; 
1f0a898: mov w8, #0xd99c
1f0a89c: movk w8, #0xe5f5, lsl #16
1f0a8a0: cmp w0, w8
1f0a8a4: adrp x8, #0x51b3000
1f0a8a8: ldr x8, [x8, #0x3c8]
1f0a8ac: b.hi #0x1f0ab28
1f0a8b0: mov w9, #0x4bf2
1f0a8b4: movk w9, #0x9a0c, lsl #16
1f0a8b8: cmp w0, w9
1f0a8bc: b.hi #0x1f0ad34
1f0a8c0: mov w8, #0xe5d3
1f0a8c4: movk w8, #0x953b, lsl #16
1f0a8c8: cmp w0, w8
1f0a8cc: b.eq #0x1f0b180
1f0a8d0: mov w8, #0x4bf2
1f0a8d4: movk w8, #0x9a0c, lsl #16
1f0a8d8: cmp w0, w8
1f0a8dc: b.ne #0x1f0ba14
1f0a8e0: ldr x1, [x19]
1f0a8e4: mov x0, x22
1f0a8e8: mov x2, xzr
1f0a8ec: bl #0x1d063b4 ; System.String$$op_Equality
1f0a8f0: tbz w0, #0, #0x1f0ba14
1f0a8f4: add x0, sp, #0xc0
1f0a8f8: mov x1, xzr
1f0a8fc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a900: ldr x8, [x19]
1f0a904: mov x1, x0
1f0a908: mov x2, xzr
1f0a90c: mov x0, x8
1f0a910: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0a914: ldr x22, [x26, #0x140]
1f0a918: add x0, sp, #0xc0
1f0a91c: mov x1, xzr
1f0a920: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a924: cbz x22, #0x1f0bc1c
1f0a928: mov x1, x0
1f0a92c: mov x0, x22
1f0a930: mov w2, wzr
1f0a934: mov x3, xzr
1f0a938: bl #0x21b54bc ; Royal.Player.Context.Units.ClashOfChampionsManager$$UpdateProgressOnRefresh
1f0a93c: ldr x0, [x19]
1f0a940: b #0x1f0ba4c ; 
1f0a944: mov w8, #0x9bcf
1f0a948: movk w8, #0x19d1, lsl #16
1f0a94c: cmp w0, w8
1f0a950: b.hi #0x1f0add8
1f0a954: mov w8, #0x5a9a
1f0a958: movk w8, #0x18d8, lsl #16
1f0a95c: cmp w0, w8
1f0a960: b.eq #0x1f0b1d0
1f0a964: mov w8, #0x9bcf
1f0a968: movk w8, #0x19d1, lsl #16
1f0a96c: cmp w0, w8
1f0a970: b.ne #0x1f0ba14
1f0a974: adrp x8, #0x519f000
1f0a978: ldr x8, [x8, #0x488]
1f0a97c: mov x0, x22
1f0a980: mov x2, xzr
1f0a984: ldr x1, [x8]
1f0a988: bl #0x1d063b4 ; System.String$$op_Equality
1f0a98c: tbz w0, #0, #0x1f0ba14
1f0a990: add x0, sp, #0xc0
1f0a994: mov x1, xzr
1f0a998: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a99c: adrp x8, #0x519f000
1f0a9a0: ldr x8, [x8, #0x488]
1f0a9a4: mov x1, x0
1f0a9a8: mov x2, xzr
1f0a9ac: ldr x8, [x8]
1f0a9b0: mov x0, x8
1f0a9b4: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0a9b8: ldr x22, [x26, #0xe8]
1f0a9bc: add x0, sp, #0xc0
1f0a9c0: mov x1, xzr
1f0a9c4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0a9c8: cbz x22, #0x1f0bc1c
1f0a9cc: mov x1, x0
1f0a9d0: mov x0, x22
1f0a9d4: bl #0x1f0c148 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress4
1f0a9d8: adrp x8, #0x519f000
1f0a9dc: ldr x8, [x8, #0x488]
1f0a9e0: b #0x1f0ba0c ; 
1f0a9e4: mov w8, #0xd449
1f0a9e8: movk w8, #0x9134, lsl #16
1f0a9ec: cmp w0, w8
1f0a9f0: b.hi #0x1f0ae3c
1f0a9f4: mov w8, #0x6711
1f0a9f8: movk w8, #0x8f1d, lsl #16
1f0a9fc: cmp w0, w8
1f0aa00: b.eq #0x1f0b20c
1f0aa04: mov w8, #0xd449
1f0aa08: movk w8, #0x9134, lsl #16
1f0aa0c: cmp w0, w8
1f0aa10: b.ne #0x1f0ba14
1f0aa14: adrp x8, #0x51ff000
1f0aa18: ldr x8, [x8, #8]
1f0aa1c: mov x0, x22
1f0aa20: mov x2, xzr
1f0aa24: ldr x1, [x8]
1f0aa28: bl #0x1d063b4 ; System.String$$op_Equality
1f0aa2c: tbz w0, #0, #0x1f0ba14
1f0aa30: add x0, sp, #0xc0
1f0aa34: mov x1, xzr
1f0aa38: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0aa3c: adrp x8, #0x51ff000
1f0aa40: ldr x8, [x8, #8]
1f0aa44: mov x1, x0
1f0aa48: mov x2, xzr
1f0aa4c: ldr x8, [x8]
1f0aa50: mov x0, x8
1f0aa54: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0aa58: ldr x22, [x26, #0x68]
1f0aa5c: add x0, sp, #0xc0
1f0aa60: mov x1, xzr
1f0aa64: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0aa68: cbz x22, #0x1f0bc1c
1f0aa6c: mov x1, x0
1f0aa70: mov x0, x22
1f0aa74: bl #0x1f0bc20 ; Royal.Player.Context.Units.WeeklyLeaderboardManager$$UpdateProgress
1f0aa78: adrp x8, #0x51ff000
1f0aa7c: ldr x8, [x8, #8]
1f0aa80: b #0x1f0ba0c ; 
1f0aa84: mov w8, #0xf1ab
1f0aa88: movk w8, #0x44f8, lsl #16
1f0aa8c: cmp w0, w8
1f0aa90: b.hi #0x1f0aecc
1f0aa94: mov w8, #0xf018
1f0aa98: movk w8, #0x43f8, lsl #16
1f0aa9c: cmp w0, w8
1f0aaa0: b.eq #0x1f0b27c
1f0aaa4: mov w8, #0xf1ab
1f0aaa8: movk w8, #0x44f8, lsl #16
1f0aaac: cmp w0, w8
1f0aab0: b.ne #0x1f0ba14
1f0aab4: adrp x8, #0x5196000
1f0aab8: ldr x8, [x8, #0xde8]
1f0aabc: mov x0, x22
1f0aac0: mov x2, xzr
1f0aac4: ldr x1, [x8]
1f0aac8: bl #0x1d063b4 ; System.String$$op_Equality
1f0aacc: tbz w0, #0, #0x1f0ba14
1f0aad0: add x0, sp, #0xc0
1f0aad4: mov x1, xzr
1f0aad8: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0aadc: adrp x8, #0x5196000
1f0aae0: ldr x8, [x8, #0xde8]
1f0aae4: mov x1, x0
1f0aae8: mov x2, xzr
1f0aaec: ldr x8, [x8]
1f0aaf0: mov x0, x8
1f0aaf4: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0aaf8: ldr x22, [x26, #0x88]
1f0aafc: add x0, sp, #0xc0
1f0ab00: mov x1, xzr
1f0ab04: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ab08: cbz x22, #0x1f0bc1c
1f0ab0c: mov x1, x0
1f0ab10: mov x0, x22
1f0ab14: mov x2, xzr
1f0ab18: bl #0x1c6b760 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress2
1f0ab1c: adrp x8, #0x5196000
1f0ab20: ldr x8, [x8, #0xde8]
1f0ab24: b #0x1f0ba0c ; 
1f0ab28: mov w8, #0xf261
1f0ab2c: movk w8, #0xeba0, lsl #16
1f0ab30: cmp w0, w8
1f0ab34: b.hi #0x1f0af64
1f0ab38: mov w8, #0x97c0
1f0ab3c: movk w8, #0xe970, lsl #16
1f0ab40: cmp w0, w8
1f0ab44: b.eq #0x1f0b2f4
1f0ab48: mov w8, #0xf261
1f0ab4c: movk w8, #0xeba0, lsl #16
1f0ab50: cmp w0, w8
1f0ab54: b.ne #0x1f0ba14
1f0ab58: ldr x1, [x29]
1f0ab5c: mov x0, x22
1f0ab60: mov x2, xzr
1f0ab64: bl #0x1d063b4 ; System.String$$op_Equality
1f0ab68: tbz w0, #0, #0x1f0ba14
1f0ab6c: add x0, sp, #0xc0
1f0ab70: mov x1, xzr
1f0ab74: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ab78: ldr x8, [x29]
1f0ab7c: mov x1, x0
1f0ab80: mov x2, xzr
1f0ab84: mov x0, x8
1f0ab88: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0ab8c: ldr x22, [x26, #0x130]
1f0ab90: add x0, sp, #0xc0
1f0ab94: mov x1, xzr
1f0ab98: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ab9c: cbz x22, #0x1f0bc1c
1f0aba0: mov x1, x0
1f0aba4: mov x0, x22
1f0aba8: mov x2, xzr
1f0abac: bl #0x32ebcbc ; Royal.Player.Context.Units.RobotRivalsManager$$UpdateProgress
1f0abb0: ldr x0, [x29]
1f0abb4: b #0x1f0ba4c ; 
1f0abb8: mov w8, #0x4e2a
1f0abbc: movk w8, #0x10c4, lsl #16
1f0abc0: cmp w0, w8
1f0abc4: b.eq #0x1f0b370
1f0abc8: mov w8, #0x5907
1f0abcc: movk w8, #0x17d8, lsl #16
1f0abd0: cmp w0, w8
1f0abd4: b.ne #0x1f0ba14
1f0abd8: adrp x8, #0x521f000
1f0abdc: ldr x8, [x8, #0xd90]
1f0abe0: mov x0, x22
1f0abe4: mov x2, xzr
1f0abe8: ldr x1, [x8]
1f0abec: bl #0x1d063b4 ; System.String$$op_Equality
1f0abf0: tbz w0, #0, #0x1f0ba14
1f0abf4: add x0, sp, #0xc0
1f0abf8: mov x1, xzr
1f0abfc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ac00: mov x1, xzr
1f0ac04: bl #0x1c67764 ; Royal.Player.Context.Units.GameplayGenericBackendSyncHandler$$SetGameplayCommonUseData2FromBackend
1f0ac08: adrp x8, #0x521f000
1f0ac0c: ldr x8, [x8, #0xd90]
1f0ac10: b #0x1f0ba0c ; 
1f0ac14: mov w8, #0x7241
1f0ac18: movk w8, #0x82ca, lsl #16
1f0ac1c: cmp w0, w8
1f0ac20: b.eq #0x1f0b734
1f0ac24: mov w8, #0xd595
1f0ac28: movk w8, #0x872e, lsl #16
1f0ac2c: cmp w0, w8
1f0ac30: b.eq #0x1f0b404
1f0ac34: mov w8, #0x131
1f0ac38: movk w8, #0x7991, lsl #16
1f0ac3c: cmp w0, w8
1f0ac40: b.ne #0x1f0ba14
1f0ac44: adrp x8, #0x5207000
1f0ac48: ldr x8, [x8, #0xd18]
1f0ac4c: mov x0, x22
1f0ac50: mov x2, xzr
1f0ac54: ldr x1, [x8]
1f0ac58: bl #0x1d063b4 ; System.String$$op_Equality
1f0ac5c: tbz w0, #0, #0x1f0ba14
1f0ac60: add x0, sp, #0xc0
1f0ac64: mov x1, xzr
1f0ac68: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ac6c: adrp x8, #0x5207000
1f0ac70: ldr x8, [x8, #0xd18]
1f0ac74: mov x1, x0
1f0ac78: mov x2, xzr
1f0ac7c: ldr x8, [x8]
1f0ac80: mov x0, x8
1f0ac84: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0ac88: ldr x22, [x26, #0x100]
1f0ac8c: add x0, sp, #0xc0
1f0ac90: mov x1, xzr
1f0ac94: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ac98: cbz x22, #0x1f0bc1c
1f0ac9c: mov x1, x0
1f0aca0: mov x0, x22
1f0aca4: mov x2, xzr
1f0aca8: bl #0x21bf008 ; Royal.Player.Context.Units.DailyLightningRushManager$$UpdateProgress
1f0acac: adrp x8, #0x5207000
1f0acb0: ldr x8, [x8, #0xd18]
1f0acb4: b #0x1f0ba0c ; 
1f0acb8: mov w8, #0x7f32
1f0acbc: movk w8, #0x359f, lsl #16
1f0acc0: cmp w0, w8
1f0acc4: b.eq #0x1f0b770
1f0acc8: mov w8, #0x2c8d
1f0accc: movk w8, #0x3b82, lsl #16
1f0acd0: cmp w0, w8
1f0acd4: b.eq #0x1f0b478
1f0acd8: mov w8, #0xe0e2
1f0acdc: movk w8, #0x40c9, lsl #16
1f0ace0: cmp w0, w8
1f0ace4: b.ne #0x1f0ba14
1f0ace8: adrp x8, #0x5239000
1f0acec: ldr x8, [x8, #0x50]
1f0acf0: mov x0, x22
1f0acf4: mov x2, xzr
1f0acf8: ldr x1, [x8]
1f0acfc: bl #0x1d063b4 ; System.String$$op_Equality
1f0ad00: tbz w0, #0, #0x1f0ba14
1f0ad04: ldr x22, [x26, #0xa0]
1f0ad08: add x0, sp, #0xc0
1f0ad0c: mov x1, xzr
1f0ad10: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ad14: cbz x22, #0x1f0bc1c
1f0ad18: mov x1, x0
1f0ad1c: mov x0, x22
1f0ad20: mov x2, xzr
1f0ad24: bl #0x1db7be0 ; Royal.Player.Context.Units.KingNightmareManager$$UpdateNightmareEvent
1f0ad28: adrp x8, #0x5239000
1f0ad2c: ldr x8, [x8, #0x50]
1f0ad30: b #0x1f0ba0c ; 
1f0ad34: mov w9, #0x599e
1f0ad38: movk w9, #0xa776, lsl #16
1f0ad3c: cmp w0, w9
1f0ad40: b.eq #0x1f0b7f4
1f0ad44: mov w9, #0xace7
1f0ad48: movk w9, #0xbe09, lsl #16
1f0ad4c: cmp w0, w9
1f0ad50: b.eq #0x1f0b4f4
1f0ad54: mov w8, #0xd99c
1f0ad58: movk w8, #0xe5f5, lsl #16
1f0ad5c: cmp w0, w8
1f0ad60: b.ne #0x1f0ba14
1f0ad64: adrp x8, #0x51cf000
1f0ad68: ldr x8, [x8, #0xd10]
1f0ad6c: mov x0, x22
1f0ad70: mov x2, xzr
1f0ad74: ldr x1, [x8]
1f0ad78: bl #0x1d063b4 ; System.String$$op_Equality
1f0ad7c: tbz w0, #0, #0x1f0ba14
1f0ad80: add x0, sp, #0xc0
1f0ad84: mov x1, xzr
1f0ad88: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ad8c: adrp x8, #0x51cf000
1f0ad90: ldr x8, [x8, #0xd10]
1f0ad94: mov x1, x0
1f0ad98: mov x2, xzr
1f0ad9c: ldr x8, [x8]
1f0ada0: mov x0, x8
1f0ada4: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0ada8: ldr x22, [x26, #0xf8]
1f0adac: add x0, sp, #0xc0
1f0adb0: mov x1, xzr
1f0adb4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0adb8: cbz x22, #0x1f0bc1c
1f0adbc: mov x1, x0
1f0adc0: mov x0, x22
1f0adc4: mov x2, xzr
1f0adc8: bl #0x21b9efc ; Royal.Player.Context.Units.CoinShopManager$$UpdateProgress
1f0adcc: adrp x8, #0x51cf000
1f0add0: ldr x8, [x8, #0xd10]
1f0add4: b #0x1f0ba0c ; 
1f0add8: mov w8, #0xfe3
1f0addc: movk w8, #0x2463, lsl #16
1f0ade0: cmp w0, w8
1f0ade4: b.eq #0x1f0b87c
1f0ade8: mov w8, #0x1176
1f0adec: movk w8, #0x2563, lsl #16
1f0adf0: cmp w0, w8
1f0adf4: b.eq #0x1f0b58c
1f0adf8: cmp w0, w28
1f0adfc: b.ne #0x1f0ba14
1f0ae00: adrp x8, #0x5210000
1f0ae04: ldr x8, [x8, #0xb88]
1f0ae08: mov x0, x22
1f0ae0c: mov x2, xzr
1f0ae10: ldr x1, [x8]
1f0ae14: bl #0x1d063b4 ; System.String$$op_Equality
1f0ae18: tbz w0, #0, #0x1f0ba14
1f0ae1c: add x0, sp, #0xc0
1f0ae20: mov x1, xzr
1f0ae24: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ae28: mov x1, xzr
1f0ae2c: bl #0x1f1ba20 ; Royal.Player.Context.Units.LiveOpsCommonKeyValueHandler$$UpdateCommonUseDataFromBackend
1f0ae30: adrp x8, #0x5210000
1f0ae34: ldr x8, [x8, #0xb88]
1f0ae38: b #0x1f0ba0c ; 
1f0ae3c: mov w8, #0x5cdc
1f0ae40: movk w8, #0x92a5, lsl #16
1f0ae44: cmp w0, w8
1f0ae48: b.eq #0x1f0b8f0
1f0ae4c: mov w8, #0x5e6f
1f0ae50: movk w8, #0x93a5, lsl #16
1f0ae54: cmp w0, w8
1f0ae58: b.eq #0x1f0b600
1f0ae5c: mov w8, #0x6002
1f0ae60: movk w8, #0x94a5, lsl #16
1f0ae64: cmp w0, w8
1f0ae68: b.ne #0x1f0ba14
1f0ae6c: adrp x8, #0x51db000
1f0ae70: ldr x8, [x8, #0xcc0]
1f0ae74: mov x0, x22
1f0ae78: mov x2, xzr
1f0ae7c: ldr x1, [x8]
1f0ae80: bl #0x1d063b4 ; System.String$$op_Equality
1f0ae84: tbz w0, #0, #0x1f0ba14
1f0ae88: add x0, sp, #0xc0
1f0ae8c: mov x1, xzr
1f0ae90: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ae94: adrp x8, #0x51db000
1f0ae98: ldr x8, [x8, #0xcc0]
1f0ae9c: mov x1, x0
1f0aea0: mov x2, xzr
1f0aea4: mov x22, x8
1f0aea8: ldr x8, [x8]
1f0aeac: mov x0, x8
1f0aeb0: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0aeb4: add x0, sp, #0xc0
1f0aeb8: mov x1, xzr
1f0aebc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0aec0: mov x1, xzr
1f0aec4: bl #0x1265d58 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue1FromBackend
1f0aec8: b #0x1f0b94c ; 
1f0aecc: mov w8, #0x74c0
1f0aed0: movk w8, #0x4582, lsl #16
1f0aed4: cmp w0, w8
1f0aed8: b.eq #0x1f0b954
1f0aedc: mov w8, #0xf33e
1f0aee0: movk w8, #0x45f8, lsl #16
1f0aee4: cmp w0, w8
1f0aee8: b.eq #0x1f0b660
1f0aeec: cmp w0, w25
1f0aef0: b.ne #0x1f0ba14
1f0aef4: adrp x8, #0x51f9000
1f0aef8: ldr x8, [x8, #0x290]
1f0aefc: mov x0, x22
1f0af00: mov x2, xzr
1f0af04: ldr x1, [x8]
1f0af08: bl #0x1d063b4 ; System.String$$op_Equality
1f0af0c: tbz w0, #0, #0x1f0ba14
1f0af10: add x0, sp, #0xc0
1f0af14: mov x1, xzr
1f0af18: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0af1c: adrp x8, #0x51f9000
1f0af20: ldr x8, [x8, #0x290]
1f0af24: mov x1, x0
1f0af28: mov x2, xzr
1f0af2c: ldr x8, [x8]
1f0af30: mov x0, x8
1f0af34: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0af38: ldr x22, [x26, #0xe8]
1f0af3c: add x0, sp, #0xc0
1f0af40: mov x1, xzr
1f0af44: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0af48: cbz x22, #0x1f0bc1c
1f0af4c: mov x1, x0
1f0af50: mov x0, x22
1f0af54: bl #0x1f0beb8 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress2
1f0af58: adrp x8, #0x51f9000
1f0af5c: ldr x8, [x8, #0x290]
1f0af60: b #0x1f0ba0c ; 
1f0af64: mov w8, #0xb5d6
1f0af68: movk w8, #0xf77d, lsl #16
1f0af6c: cmp w0, w8
1f0af70: b.eq #0x1f0b9c4
1f0af74: mov w8, #0xc72b
1f0af78: movk w8, #0xfb7b, lsl #16
1f0af7c: cmp w0, w8
1f0af80: b.eq #0x1f0b6d4
1f0af84: mov w8, #0xc8be
1f0af88: movk w8, #0xfc7b, lsl #16
1f0af8c: cmp w0, w8
1f0af90: b.ne #0x1f0ba14
1f0af94: ldr x1, [x24]
1f0af98: mov x0, x22
1f0af9c: mov x2, xzr
1f0afa0: bl #0x1d063b4 ; System.String$$op_Equality
1f0afa4: tbz w0, #0, #0x1f0ba14
1f0afa8: add x0, sp, #0xc0
1f0afac: mov x1, xzr
1f0afb0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0afb4: ldr x8, [x24]
1f0afb8: mov x1, x0
1f0afbc: mov x2, xzr
1f0afc0: mov x0, x8
1f0afc4: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0afc8: ldr x22, [x26, #0xc0]
1f0afcc: add x0, sp, #0xc0
1f0afd0: mov x1, xzr
1f0afd4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0afd8: cbz x22, #0x1f0bc1c
1f0afdc: mov x1, x0
1f0afe0: mov x0, x22
1f0afe4: mov x2, xzr
1f0afe8: bl #0x23350c4 ; Royal.Player.Context.Units.DukesFortuneManager$$UpdateProgress1
1f0afec: ldr x0, [x24]
1f0aff0: b #0x1f0ba4c ; 
1f0aff4: ldr x1, [x8]
1f0aff8: mov x0, x22
1f0affc: mov x2, xzr
1f0b000: bl #0x1d063b4 ; System.String$$op_Equality
1f0b004: tbz w0, #0, #0x1f0ba14
1f0b008: add x0, sp, #0xc0
1f0b00c: mov x1, xzr
1f0b010: mov x25, x24
1f0b014: mov x24, x23
1f0b018: mov x28, x29
1f0b01c: mov x29, x27
1f0b020: mov x22, x26
1f0b024: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b028: adrp x26, #0x5201000
1f0b02c: ldr x26, [x26, #0x930]
1f0b030: mov x1, x0
1f0b034: mov x2, xzr
1f0b038: ldr x8, [x26]
1f0b03c: mov x0, x8
1f0b040: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b044: mov x23, x22
1f0b048: ldr x22, [x22, #0xb8]
1f0b04c: add x0, sp, #0xc0
1f0b050: mov x1, xzr
1f0b054: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b058: cbz x22, #0x1f0bc1c
1f0b05c: mov x1, x0
1f0b060: mov x0, x22
1f0b064: mov x2, xzr
1f0b068: bl #0x2066fe0 ; Royal.Player.Context.Units.TeamTournamentManager$$UpdateProgressValue1
1f0b06c: adrp x21, #0x51e8000
1f0b070: ldr x0, [x26]
1f0b074: ldr x21, [x21, #0xd0]
1f0b078: mov x26, x23
1f0b07c: b #0x1f0b568 ; 
1f0b080: adrp x8, #0x51b9000
1f0b084: ldr x8, [x8, #0x7f8]
1f0b088: mov x0, x22
1f0b08c: mov x2, xzr
1f0b090: ldr x1, [x8]
1f0b094: bl #0x1d063b4 ; System.String$$op_Equality
1f0b098: tbz w0, #0, #0x1f0ba14
1f0b09c: add x0, sp, #0xc0
1f0b0a0: mov x1, xzr
1f0b0a4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b0a8: adrp x8, #0x51b9000
1f0b0ac: ldr x8, [x8, #0x7f8]
1f0b0b0: mov x1, x0
1f0b0b4: mov x2, xzr
1f0b0b8: ldr x8, [x8]
1f0b0bc: mov x0, x8
1f0b0c0: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b0c4: ldr x22, [x26, #0xa8]
1f0b0c8: add x0, sp, #0xc0
1f0b0cc: mov x1, xzr
1f0b0d0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b0d4: cbz x22, #0x1f0bc1c
1f0b0d8: mov x1, x0
1f0b0dc: mov x0, x22
1f0b0e0: mov w2, wzr
1f0b0e4: mov x3, xzr
1f0b0e8: bl #0x244d7bc ; Royal.Player.Context.Units.BalloonRiseManager$$UpdateProgress
1f0b0ec: adrp x8, #0x51b9000
1f0b0f0: ldr x8, [x8, #0x7f8]
1f0b0f4: b #0x1f0ba0c ; 
1f0b0f8: ldr x1, [x8]
1f0b0fc: mov x0, x22
1f0b100: mov x2, xzr
1f0b104: bl #0x1d063b4 ; System.String$$op_Equality
1f0b108: tbz w0, #0, #0x1f0ba14
1f0b10c: add x0, sp, #0xc0
1f0b110: mov x1, xzr
1f0b114: mov x25, x24
1f0b118: mov x24, x23
1f0b11c: mov x23, x29
1f0b120: mov x29, x27
1f0b124: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b128: adrp x28, #0x523e000
1f0b12c: ldr x28, [x28, #0x590]
1f0b130: mov x1, x0
1f0b134: mov x2, xzr
1f0b138: ldr x8, [x28]
1f0b13c: mov x0, x8
1f0b140: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b144: ldr x22, [x26, #0x118]
1f0b148: add x0, sp, #0xc0
1f0b14c: mov x1, xzr
1f0b150: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b154: cbz x22, #0x1f0bc1c
1f0b158: mov x1, x0
1f0b15c: mov x0, x22
1f0b160: mov x2, xzr
1f0b164: bl #0x319e704 ; Royal.Player.Context.Units.PropellerRushManager$$UpdateProgress
1f0b168: adrp x21, #0x51e8000
1f0b16c: ldr x0, [x28]
1f0b170: ldr x21, [x21, #0xd0]
1f0b174: mov x27, x29
1f0b178: mov x29, x23
1f0b17c: b #0x1f0b570 ; 
1f0b180: ldr x1, [x21]
1f0b184: mov x0, x22
1f0b188: mov x2, xzr
1f0b18c: bl #0x1d063b4 ; System.String$$op_Equality
1f0b190: tbz w0, #0, #0x1f0ba14
1f0b194: add x0, sp, #0xc0
1f0b198: mov x1, xzr
1f0b19c: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b1a0: ldr x8, [x21]
1f0b1a4: mov x1, x0
1f0b1a8: mov x2, xzr
1f0b1ac: mov x0, x8
1f0b1b0: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b1b4: add x0, sp, #0xc0
1f0b1b8: mov x1, xzr
1f0b1bc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b1c0: mov x1, xzr
1f0b1c4: bl #0x3187a68 ; Royal.Player.Context.Units.MonetizationCommonKeyValueHandler$$UpdateCommonUseDataFromBackend
1f0b1c8: ldr x0, [x21]
1f0b1cc: b #0x1f0ba4c ; 
1f0b1d0: adrp x8, #0x5219000
1f0b1d4: ldr x8, [x8, #0xc0]
1f0b1d8: mov x0, x22
1f0b1dc: mov x2, xzr
1f0b1e0: ldr x1, [x8]
1f0b1e4: bl #0x1d063b4 ; System.String$$op_Equality
1f0b1e8: tbz w0, #0, #0x1f0ba14
1f0b1ec: add x0, sp, #0xc0
1f0b1f0: mov x1, xzr
1f0b1f4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b1f8: mov x1, xzr
1f0b1fc: bl #0x1c6767c ; Royal.Player.Context.Units.GameplayGenericBackendSyncHandler$$SetGameplayCommonUseDataFromBackend
1f0b200: adrp x8, #0x5219000
1f0b204: ldr x8, [x8, #0xc0]
1f0b208: b #0x1f0ba0c ; 
1f0b20c: adrp x8, #0x51eb000
1f0b210: ldr x8, [x8, #0x538]
1f0b214: mov x0, x22
1f0b218: mov x2, xzr
1f0b21c: ldr x1, [x8]
1f0b220: bl #0x1d063b4 ; System.String$$op_Equality
1f0b224: tbz w0, #0, #0x1f0ba14
1f0b228: add x0, sp, #0xc0
1f0b22c: mov x1, xzr
1f0b230: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b234: adrp x8, #0x51eb000
1f0b238: ldr x8, [x8, #0x538]
1f0b23c: mov x1, x0
1f0b240: mov x2, xzr
1f0b244: ldr x8, [x8]
1f0b248: mov x0, x8
1f0b24c: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b250: ldr x22, [x26, #0xe8]
1f0b254: add x0, sp, #0xc0
1f0b258: mov x1, xzr
1f0b25c: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b260: cbz x22, #0x1f0bc1c
1f0b264: mov x1, x0
1f0b268: mov x0, x22
1f0b26c: bl #0x1f0c000 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress3
1f0b270: adrp x8, #0x51eb000
1f0b274: ldr x8, [x8, #0x538]
1f0b278: b #0x1f0ba0c ; 
1f0b27c: adrp x8, #0x5233000
1f0b280: ldr x8, [x8, #0x3b0]
1f0b284: mov x0, x22
1f0b288: mov x2, xzr
1f0b28c: ldr x1, [x8]
1f0b290: bl #0x1d063b4 ; System.String$$op_Equality
1f0b294: tbz w0, #0, #0x1f0ba14
1f0b298: add x0, sp, #0xc0
1f0b29c: mov x1, xzr
1f0b2a0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b2a4: adrp x8, #0x5233000
1f0b2a8: ldr x8, [x8, #0x3b0]
1f0b2ac: mov x1, x0
1f0b2b0: mov x2, xzr
1f0b2b4: ldr x8, [x8]
1f0b2b8: mov x0, x8
1f0b2bc: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b2c0: ldr x22, [x26, #0x88]
1f0b2c4: add x0, sp, #0xc0
1f0b2c8: mov x1, xzr
1f0b2cc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b2d0: cbz x22, #0x1f0bc1c
1f0b2d4: mov x1, x0
1f0b2d8: mov x0, x22
1f0b2dc: mov w2, wzr
1f0b2e0: mov x3, xzr
1f0b2e4: bl #0x1c6b8a8 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress3
1f0b2e8: adrp x8, #0x5233000
1f0b2ec: ldr x8, [x8, #0x3b0]
1f0b2f0: b #0x1f0ba0c ; 
1f0b2f4: ldr x1, [x27]
1f0b2f8: mov x0, x22
1f0b2fc: mov x2, xzr
1f0b300: bl #0x1d063b4 ; System.String$$op_Equality
1f0b304: tbz w0, #0, #0x1f0ba14
1f0b308: adrp x8, #0x5576000
1f0b30c: ldrb w8, [x8, #0xf2b]
1f0b310: cbnz w8, #0x1f0b32c
1f0b314: adrp x0, #0x5208000
1f0b318: ldr x0, [x0, #0x380]
1f0b31c: bl #0xfb1300 ; 
1f0b320: adrp x8, #0x5576000
1f0b324: mov w9, #1
1f0b328: strb w9, [x8, #0xf2b]
1f0b32c: adrp x8, #0x5208000
1f0b330: ldr x8, [x8, #0x380]
1f0b334: ldr x8, [x8]
1f0b338: ldr x8, [x8, #0xb8]
1f0b33c: ldr x8, [x8]
1f0b340: cbz x8, #0x1f0bc1c
1f0b344: ldr x22, [x8, #0x20]
1f0b348: add x0, sp, #0xc0
1f0b34c: mov x1, xzr
1f0b350: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b354: cbz x22, #0x1f0bc1c
1f0b358: mov x1, x0
1f0b35c: mov x0, x22
1f0b360: mov x2, xzr
1f0b364: bl #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
1f0b368: ldr x0, [x27]
1f0b36c: b #0x1f0ba4c ; 
1f0b370: adrp x8, #0x51f2000
1f0b374: ldr x8, [x8, #0xb60]
1f0b378: mov x0, x22
1f0b37c: mov x2, xzr
1f0b380: ldr x1, [x8]
1f0b384: bl #0x1d063b4 ; System.String$$op_Equality
1f0b388: tbz w0, #0, #0x1f0ba14
1f0b38c: add x0, sp, #0xc0
1f0b390: mov x1, xzr
1f0b394: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b398: mov x1, x0
1f0b39c: add x0, sp, #0x90
1f0b3a0: mov x2, xzr
1f0b3a4: bl #0x2a016a4 ; Royal.Player.Context.Data.Persistent.TeamOfferProgress$$.ctor
1f0b3a8: adrp x8, #0x5576000
1f0b3ac: ldrb w8, [x8, #0xf2b]
1f0b3b0: cbnz w8, #0x1f0b3cc
1f0b3b4: adrp x0, #0x5208000
1f0b3b8: ldr x0, [x0, #0x380]
1f0b3bc: bl #0xfb1300 ; 
1f0b3c0: adrp x8, #0x5576000
1f0b3c4: mov w9, #1
1f0b3c8: strb w9, [x8, #0xf2b]
1f0b3cc: adrp x8, #0x5208000
1f0b3d0: ldr x8, [x8, #0x380]
1f0b3d4: ldr x8, [x8]
1f0b3d8: ldr x8, [x8, #0xb8]
1f0b3dc: ldr x8, [x8]
1f0b3e0: cbz x8, #0x1f0bc1c
1f0b3e4: ldr x0, [x8, #0x20]
1f0b3e8: cbz x0, #0x1f0bc1c
1f0b3ec: ldp x1, x2, [sp, #0x90]
1f0b3f0: mov x3, xzr
1f0b3f4: bl #0x2a0e3c4 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateTeamOfferProgress
1f0b3f8: adrp x8, #0x51f2000
1f0b3fc: ldr x8, [x8, #0xb60]
1f0b400: b #0x1f0ba0c ; 
1f0b404: adrp x8, #0x51d5000
1f0b408: ldr x8, [x8, #0x4e0]
1f0b40c: mov x0, x22
1f0b410: mov x2, xzr
1f0b414: ldr x1, [x8]
1f0b418: bl #0x1d063b4 ; System.String$$op_Equality
1f0b41c: tbz w0, #0, #0x1f0ba14
1f0b420: add x0, sp, #0xc0
1f0b424: mov x1, xzr
1f0b428: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b42c: adrp x8, #0x51d5000
1f0b430: ldr x8, [x8, #0x4e0]
1f0b434: mov x1, x0
1f0b438: mov x2, xzr
1f0b43c: ldr x8, [x8]
1f0b440: mov x0, x8
1f0b444: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b448: ldr x22, [x26, #0xe0]
1f0b44c: add x0, sp, #0xc0
1f0b450: mov x1, xzr
1f0b454: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b458: cbz x22, #0x1f0bc1c
1f0b45c: mov x1, x0
1f0b460: mov x0, x22
1f0b464: mov x2, xzr
1f0b468: bl #0x267c924 ; Royal.Player.Context.Units.WelcomeBackGiftManager$$UpdateProgress
1f0b46c: adrp x8, #0x51d5000
1f0b470: ldr x8, [x8, #0x4e0]
1f0b474: b #0x1f0ba0c ; 
1f0b478: adrp x8, #0x51e2000
1f0b47c: ldr x8, [x8, #0xd38]
1f0b480: mov x0, x22
1f0b484: mov x2, xzr
1f0b488: ldr x1, [x8]
1f0b48c: bl #0x1d063b4 ; System.String$$op_Equality
1f0b490: tbz w0, #0, #0x1f0ba14
1f0b494: add x0, sp, #0xc0
1f0b498: mov x1, xzr
1f0b49c: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b4a0: adrp x8, #0x51e2000
1f0b4a4: ldr x8, [x8, #0xd38]
1f0b4a8: mov x1, x0
1f0b4ac: mov x2, xzr
1f0b4b0: ldr x8, [x8]
1f0b4b4: mov x0, x8
1f0b4b8: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b4bc: ldr x8, [x26, #0x20]
1f0b4c0: cbz x8, #0x1f0bc1c
1f0b4c4: ldr x22, [x8, #0x18]
1f0b4c8: add x0, sp, #0xc0
1f0b4cc: mov x1, xzr
1f0b4d0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b4d4: cbz x22, #0x1f0bc1c
1f0b4d8: mov x1, x0
1f0b4dc: mov x0, x22
1f0b4e0: mov x2, xzr
1f0b4e4: bl #0x318bf48 ; Royal.Player.Context.Units.NewUserNewUxHelper$$UpdateData
1f0b4e8: adrp x8, #0x51e2000
1f0b4ec: ldr x8, [x8, #0xd38]
1f0b4f0: b #0x1f0ba0c ; 
1f0b4f4: ldr x1, [x8]
1f0b4f8: mov x0, x22
1f0b4fc: mov x2, xzr
1f0b500: bl #0x1d063b4 ; System.String$$op_Equality
1f0b504: tbz w0, #0, #0x1f0ba14
1f0b508: add x0, sp, #0xc0
1f0b50c: mov x1, xzr
1f0b510: mov x25, x24
1f0b514: mov x24, x23
1f0b518: mov x28, x29
1f0b51c: mov x29, x27
1f0b520: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b524: adrp x23, #0x51b3000
1f0b528: ldr x23, [x23, #0x3c8]
1f0b52c: mov x1, x0
1f0b530: mov x2, xzr
1f0b534: ldr x8, [x23]
1f0b538: mov x0, x8
1f0b53c: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b540: ldr x22, [x26, #0xb0]
1f0b544: add x0, sp, #0xc0
1f0b548: mov x1, xzr
1f0b54c: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b550: cbz x22, #0x1f0bc1c
1f0b554: mov x1, x0
1f0b558: mov x0, x22
1f0b55c: mov x2, xzr
1f0b560: bl #0x24468b4 ; Royal.Player.Context.Units.ArcheryArenaManager$$UpdateProgress
1f0b564: ldr x0, [x23]
1f0b568: mov x27, x29
1f0b56c: mov x29, x28
1f0b570: mov x23, x24
1f0b574: mov x24, x25
1f0b578: mov w25, #0xa763
1f0b57c: mov w28, #0xf916
1f0b580: movk w25, #0x4fd8, lsl #16
1f0b584: movk w28, #0x2aac, lsl #16
1f0b588: b #0x1f0ba4c ; 
1f0b58c: adrp x8, #0x5236000
1f0b590: ldr x8, [x8, #0xe58]
1f0b594: mov x0, x22
1f0b598: mov x2, xzr
1f0b59c: ldr x1, [x8]
1f0b5a0: bl #0x1d063b4 ; System.String$$op_Equality
1f0b5a4: tbz w0, #0, #0x1f0ba14
1f0b5a8: add x0, sp, #0xc0
1f0b5ac: mov x1, xzr
1f0b5b0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b5b4: adrp x8, #0x5236000
1f0b5b8: ldr x8, [x8, #0xe58]
1f0b5bc: mov x1, x0
1f0b5c0: mov x2, xzr
1f0b5c4: ldr x8, [x8]
1f0b5c8: mov x0, x8
1f0b5cc: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b5d0: ldr x22, [x26, #0x70]
1f0b5d4: add x0, sp, #0xc0
1f0b5d8: mov x1, xzr
1f0b5dc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b5e0: cbz x22, #0x1f0bc1c
1f0b5e4: mov x1, x0
1f0b5e8: mov x0, x22
1f0b5ec: mov x2, xzr
1f0b5f0: bl #0x21c5e38 ; Royal.Player.Context.Units.DragonNestManager$$UpdateProgress1
1f0b5f4: adrp x8, #0x5236000
1f0b5f8: ldr x8, [x8, #0xe58]
1f0b5fc: b #0x1f0ba0c ; 
1f0b600: adrp x8, #0x523d000
1f0b604: ldr x8, [x8, #0xa8]
1f0b608: mov x0, x22
1f0b60c: mov x2, xzr
1f0b610: ldr x1, [x8]
1f0b614: bl #0x1d063b4 ; System.String$$op_Equality
1f0b618: tbz w0, #0, #0x1f0ba14
1f0b61c: add x0, sp, #0xc0
1f0b620: mov x1, xzr
1f0b624: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b628: adrp x8, #0x523d000
1f0b62c: ldr x8, [x8, #0xa8]
1f0b630: mov x1, x0
1f0b634: mov x2, xzr
1f0b638: mov x22, x8
1f0b63c: ldr x8, [x8]
1f0b640: mov x0, x8
1f0b644: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b648: add x0, sp, #0xc0
1f0b64c: mov x1, xzr
1f0b650: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b654: mov x1, xzr
1f0b658: bl #0x1265f14 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue2FromBackend
1f0b65c: b #0x1f0b94c ; 
1f0b660: adrp x8, #0x51d5000
1f0b664: ldr x8, [x8, #0x9c8]
1f0b668: mov x0, x22
1f0b66c: mov x2, xzr
1f0b670: ldr x1, [x8]
1f0b674: bl #0x1d063b4 ; System.String$$op_Equality
1f0b678: tbz w0, #0, #0x1f0ba14
1f0b67c: add x0, sp, #0xc0
1f0b680: mov x1, xzr
1f0b684: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b688: adrp x8, #0x51d5000
1f0b68c: ldr x8, [x8, #0x9c8]
1f0b690: mov x1, x0
1f0b694: mov x2, xzr
1f0b698: ldr x8, [x8]
1f0b69c: mov x0, x8
1f0b6a0: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b6a4: ldr x22, [x26, #0x88]
1f0b6a8: add x0, sp, #0xc0
1f0b6ac: mov x1, xzr
1f0b6b0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b6b4: cbz x22, #0x1f0bc1c
1f0b6b8: mov x1, x0
1f0b6bc: mov x0, x22
1f0b6c0: mov x2, xzr
1f0b6c4: bl #0x1c6b618 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress1
1f0b6c8: adrp x8, #0x51d5000
1f0b6cc: ldr x8, [x8, #0x9c8]
1f0b6d0: b #0x1f0ba0c ; 
1f0b6d4: ldr x1, [x23]
1f0b6d8: mov x0, x22
1f0b6dc: mov x2, xzr
1f0b6e0: bl #0x1d063b4 ; System.String$$op_Equality
1f0b6e4: tbz w0, #0, #0x1f0ba14
1f0b6e8: add x0, sp, #0xc0
1f0b6ec: mov x1, xzr
1f0b6f0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b6f4: ldr x8, [x23]
1f0b6f8: mov x1, x0
1f0b6fc: mov x2, xzr
1f0b700: mov x0, x8
1f0b704: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b708: ldr x22, [x26, #0xc0]
1f0b70c: add x0, sp, #0xc0
1f0b710: mov x1, xzr
1f0b714: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b718: cbz x22, #0x1f0bc1c
1f0b71c: mov x1, x0
1f0b720: mov x0, x22
1f0b724: mov x2, xzr
1f0b728: bl #0x233520c ; Royal.Player.Context.Units.DukesFortuneManager$$UpdateProgress2
1f0b72c: ldr x0, [x23]
1f0b730: b #0x1f0ba4c ; 
1f0b734: adrp x8, #0x51cd000
1f0b738: ldr x8, [x8, #0x1c0]
1f0b73c: mov x0, x22
1f0b740: mov x2, xzr
1f0b744: ldr x1, [x8]
1f0b748: bl #0x1d063b4 ; System.String$$op_Equality
1f0b74c: tbz w0, #0, #0x1f0ba14
1f0b750: add x0, sp, #0xc0
1f0b754: mov x1, xzr
1f0b758: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b75c: mov x1, xzr
1f0b760: bl #0x21aa6a4 ; Royal.Player.Context.Data.Persistent.KeyValueAbTestIds$$UpdateData
1f0b764: adrp x8, #0x51cd000
1f0b768: ldr x8, [x8, #0x1c0]
1f0b76c: b #0x1f0ba0c ; 
1f0b770: adrp x8, #0x51a7000
1f0b774: ldr x8, [x8, #0xac8]
1f0b778: mov x0, x22
1f0b77c: mov x2, xzr
1f0b780: ldr x1, [x8]
1f0b784: bl #0x1d063b4 ; System.String$$op_Equality
1f0b788: tbz w0, #0, #0x1f0ba14
1f0b78c: add x0, sp, #0xc0
1f0b790: mov x1, xzr
1f0b794: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b798: adrp x8, #0x51a7000
1f0b79c: ldr x8, [x8, #0xac8]
1f0b7a0: mov x1, x0
1f0b7a4: mov x2, xzr
1f0b7a8: ldr x8, [x8]
1f0b7ac: mov x0, x8
1f0b7b0: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b7b4: ldr x22, [x26, #0x80]
1f0b7b8: add x0, sp, #0xc0
1f0b7bc: mov x1, xzr
1f0b7c0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b7c4: cbz x22, #0x1f0bc1c
1f0b7c8: mov x1, x0
1f0b7cc: mov x0, x22
1f0b7d0: mov x2, xzr
1f0b7d4: bl #0x1dc6dd4 ; Royal.Player.Context.Units.LavaQuestManager$$UpdateProgress2
1f0b7d8: ldr x0, [x26, #0x80]
1f0b7dc: cbz x0, #0x1f0bc1c
1f0b7e0: mov x1, xzr
1f0b7e4: bl #0x1dc6f1c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateLocalData
1f0b7e8: adrp x8, #0x51a7000
1f0b7ec: ldr x8, [x8, #0xac8]
1f0b7f0: b #0x1f0ba0c ; 
1f0b7f4: adrp x8, #0x5236000
1f0b7f8: ldr x8, [x8, #0x8d0]
1f0b7fc: mov x0, x22
1f0b800: mov x2, xzr
1f0b804: ldr x1, [x8]
1f0b808: bl #0x1d063b4 ; System.String$$op_Equality
1f0b80c: tbz w0, #0, #0x1f0ba14
1f0b810: adrp x8, #0x5576000
1f0b814: ldrb w8, [x8, #0xf2b]
1f0b818: cbnz w8, #0x1f0b834
1f0b81c: adrp x0, #0x5208000
1f0b820: ldr x0, [x0, #0x380]
1f0b824: bl #0xfb1300 ; 
1f0b828: adrp x8, #0x5576000
1f0b82c: mov w9, #1
1f0b830: strb w9, [x8, #0xf2b]
1f0b834: adrp x8, #0x5208000
1f0b838: ldr x8, [x8, #0x380]
1f0b83c: ldr x8, [x8]
1f0b840: ldr x8, [x8, #0xb8]
1f0b844: ldr x8, [x8]
1f0b848: cbz x8, #0x1f0bc1c
1f0b84c: ldr x22, [x8, #0x20]
1f0b850: add x0, sp, #0xc0
1f0b854: mov x1, xzr
1f0b858: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b85c: cbz x22, #0x1f0bc1c
1f0b860: mov x1, x0
1f0b864: mov x0, x22
1f0b868: mov x2, xzr
1f0b86c: bl #0x2a0f194 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDialogs
1f0b870: adrp x8, #0x5236000
1f0b874: ldr x8, [x8, #0x8d0]
1f0b878: b #0x1f0ba0c ; 
1f0b87c: adrp x8, #0x51a1000
1f0b880: ldr x8, [x8, #0x728]
1f0b884: mov x0, x22
1f0b888: mov x2, xzr
1f0b88c: ldr x1, [x8]
1f0b890: bl #0x1d063b4 ; System.String$$op_Equality
1f0b894: tbz w0, #0, #0x1f0ba14
1f0b898: add x0, sp, #0xc0
1f0b89c: mov x1, xzr
1f0b8a0: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b8a4: adrp x8, #0x51a1000
1f0b8a8: ldr x8, [x8, #0x728]
1f0b8ac: mov x1, x0
1f0b8b0: mov x2, xzr
1f0b8b4: ldr x8, [x8]
1f0b8b8: mov x0, x8
1f0b8bc: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b8c0: ldr x22, [x26, #0x70]
1f0b8c4: add x0, sp, #0xc0
1f0b8c8: mov x1, xzr
1f0b8cc: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b8d0: cbz x22, #0x1f0bc1c
1f0b8d4: mov x1, x0
1f0b8d8: mov x0, x22
1f0b8dc: mov x2, xzr
1f0b8e0: bl #0x21c5f80 ; Royal.Player.Context.Units.DragonNestManager$$UpdateProgress2
1f0b8e4: adrp x8, #0x51a1000
1f0b8e8: ldr x8, [x8, #0x728]
1f0b8ec: b #0x1f0ba0c ; 
1f0b8f0: adrp x8, #0x51ad000
1f0b8f4: ldr x8, [x8, #0x6e0]
1f0b8f8: mov x0, x22
1f0b8fc: mov x2, xzr
1f0b900: ldr x1, [x8]
1f0b904: bl #0x1d063b4 ; System.String$$op_Equality
1f0b908: tbz w0, #0, #0x1f0ba14
1f0b90c: add x0, sp, #0xc0
1f0b910: mov x1, xzr
1f0b914: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b918: adrp x8, #0x51ad000
1f0b91c: ldr x8, [x8, #0x6e0]
1f0b920: mov x1, x0
1f0b924: mov x2, xzr
1f0b928: mov x22, x8
1f0b92c: ldr x8, [x8]
1f0b930: mov x0, x8
1f0b934: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b938: add x0, sp, #0xc0
1f0b93c: mov x1, xzr
1f0b940: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b944: mov x1, xzr
1f0b948: bl #0x12660d0 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue3FromBackend
1f0b94c: ldr x0, [x22]
1f0b950: b #0x1f0ba4c ; 
1f0b954: adrp x8, #0x520e000
1f0b958: ldr x8, [x8, #0x368]
1f0b95c: mov x0, x22
1f0b960: mov x2, xzr
1f0b964: ldr x1, [x8]
1f0b968: bl #0x1d063b4 ; System.String$$op_Equality
1f0b96c: tbz w0, #0, #0x1f0ba14
1f0b970: add x0, sp, #0xc0
1f0b974: mov x1, xzr
1f0b978: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b97c: adrp x8, #0x520e000
1f0b980: ldr x8, [x8, #0x368]
1f0b984: mov x1, x0
1f0b988: mov x2, xzr
1f0b98c: ldr x8, [x8]
1f0b990: mov x0, x8
1f0b994: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0b998: ldr x22, [x26, #0xe8]
1f0b99c: add x0, sp, #0xc0
1f0b9a0: mov x1, xzr
1f0b9a4: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b9a8: cbz x22, #0x1f0bc1c
1f0b9ac: mov x1, x0
1f0b9b0: mov x0, x22
1f0b9b4: bl #0x1f0bd70 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress1
1f0b9b8: adrp x8, #0x520e000
1f0b9bc: ldr x8, [x8, #0x368]
1f0b9c0: b #0x1f0ba0c ; 
1f0b9c4: adrp x8, #0x51be000
1f0b9c8: ldr x8, [x8, #0xd50]
1f0b9cc: mov x0, x22
1f0b9d0: mov x2, xzr
1f0b9d4: ldr x1, [x8]
1f0b9d8: bl #0x1d063b4 ; System.String$$op_Equality
1f0b9dc: tbz w0, #0, #0x1f0ba14
1f0b9e0: ldr x22, [x26, #0x98]
1f0b9e4: add x0, sp, #0xc0
1f0b9e8: mov x1, xzr
1f0b9ec: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0b9f0: cbz x22, #0x1f0bc1c
1f0b9f4: mov x1, x0
1f0b9f8: mov x0, x22
1f0b9fc: mov x2, xzr
1f0ba00: bl #0x1daded4 ; Royal.Player.Context.Units.SystemMessageManager$$UpdateLastClaimedMessages
1f0ba04: adrp x8, #0x51be000
1f0ba08: ldr x8, [x8, #0xd50]
1f0ba0c: ldr x0, [x8]
1f0ba10: b #0x1f0ba4c ; 
1f0ba14: add x0, sp, #0xc0
1f0ba18: mov x1, xzr
1f0ba1c: bl #0x27f3508 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Key
1f0ba20: mov x22, x0
1f0ba24: add x0, sp, #0xc0
1f0ba28: mov x1, xzr
1f0ba2c: bl #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
1f0ba30: mov x1, x0
1f0ba34: mov x0, x22
1f0ba38: mov x2, xzr
1f0ba3c: bl #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
1f0ba40: add x0, sp, #0xc0
1f0ba44: mov x1, xzr
1f0ba48: bl #0x27f3508 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Key
1f0ba4c: mov w1, #1
1f0ba50: mov x2, xzr
1f0ba54: bl #0x2e70220 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetSynced
1f0ba58: add x0, sp, #0xd0
1f0ba5c: mov x1, xzr
1f0ba60: add w20, w20, #1
1f0ba64: bl #0x3295ecc ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_KeyValueListLength
1f0ba68: cmp w20, w0
1f0ba6c: b.lt #0x1f0a5e4
1f0ba70: add x0, sp, #0xd0
1f0ba74: mov x1, xzr
1f0ba78: bl #0x3296474 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_ByteArrayKeyValueListLength
1f0ba7c: cmp w0, #1
1f0ba80: b.lt #0x1f0bb34
1f0ba84: adrp x23, #0x5201000
1f0ba88: adrp x24, #0x51e9000
1f0ba8c: ldr x23, [x23, #0x510]
1f0ba90: ldr x24, [x24, #0xed0]
1f0ba94: mov w20, wzr
1f0ba98: add x8, sp, #0x40
1f0ba9c: add x0, sp, #0xd0
1f0baa0: mov w1, w20
1f0baa4: mov x2, xzr
1f0baa8: bl #0x329639c ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$ByteArrayKeyValueList
1f0baac: ldr q0, [sp, #0x40]
1f0bab0: ldr x8, [sp, #0x50]
1f0bab4: ldr x1, [x23]
1f0bab8: add x0, sp, #0x60
1f0babc: str q0, [sp, #0x60]
1f0bac0: str x8, [sp, #0x70]
1f0bac4: bl #0x2e241f0 ; System.Nullable<ByteArrayKeyValue>$$get_Value
1f0bac8: stp x0, x1, [sp, #0x80]
1f0bacc: add x0, sp, #0x80
1f0bad0: mov x1, xzr
1f0bad4: bl #0x2c746fc ; Royal.Infrastructure.Services.Backend.Protocol.ByteArrayKeyValue$$get_Key
1f0bad8: mov w21, w0
1f0badc: add x0, sp, #0x80
1f0bae0: mov x1, xzr
1f0bae4: bl #0x2c7480c ; Royal.Infrastructure.Services.Backend.Protocol.ByteArrayKeyValue$$GetValueArray
1f0bae8: ldr x8, [x24]
1f0baec: mov x22, x0
1f0baf0: ldr w9, [x8, #0xe0]
1f0baf4: cbnz w9, #0x1f0bb00
1f0baf8: mov x0, x8
1f0bafc: bl #0xfb1404 ; 
1f0bb00: mov x0, x22
1f0bb04: mov x1, xzr
1f0bb08: bl #0x3283ed0 ; Royal.Infrastructure.Utils.Math.BitArrayOperations$$ToString
1f0bb0c: mov x2, x0
1f0bb10: mov x0, x26
1f0bb14: mov w1, w21
1f0bb18: bl #0x1f0c290 ; Royal.Player.Context.Units.UserManager$$ProcessByteArrayKeyValue
1f0bb1c: add x0, sp, #0xd0
1f0bb20: mov x1, xzr
1f0bb24: add w20, w20, #1
1f0bb28: bl #0x3296474 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_ByteArrayKeyValueListLength
1f0bb2c: cmp w20, w0
1f0bb30: b.lt #0x1f0ba98
1f0bb34: ldr x20, [x26, #0x168]
1f0bb38: add x8, sp, #0x28
1f0bb3c: add x0, sp, #0xd0
1f0bb40: mov x1, xzr
1f0bb44: bl #0x3297b64 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_InviteFriendRefreshInfo
1f0bb48: ldur q0, [sp, #0x28]
1f0bb4c: ldr x8, [sp, #0x38]
1f0bb50: str q0, [sp, #0x40]
1f0bb54: str x8, [sp, #0x50]
1f0bb58: cbz x20, #0x1f0bc1c
1f0bb5c: ldr q0, [sp, #0x40]
1f0bb60: ldr x8, [sp, #0x50]
1f0bb64: add x1, sp, #0x10
1f0bb68: mov x0, x20
1f0bb6c: mov x2, xzr
1f0bb70: str q0, [sp, #0x10]
1f0bb74: str x8, [sp, #0x20]
1f0bb78: bl #0x1c727ac ; Royal.Player.Context.Units.InviteFriendsManager$$UpdateRefreshInfo
1f0bb7c: ldr x0, [x26, #0x70]
1f0bb80: cbz x0, #0x1f0bc1c
1f0bb84: mov x1, xzr
1f0bb88: bl #0x21c60c8 ; Royal.Player.Context.Units.DragonNestManager$$ProgressUpdated
1f0bb8c: ldr x0, [x26, #0x78]
1f0bb90: cbz x0, #0x1f0bc1c
1f0bb94: mov x1, xzr
1f0bb98: bl #0x2075878 ; Royal.Player.Context.Units.TrainJourneyManager$$ProgressUpdated
1f0bb9c: ldr x0, [x26, #0x80]
1f0bba0: cbz x0, #0x1f0bc1c
1f0bba4: mov x1, xzr
1f0bba8: bl #0x1dc5d54 ; Royal.Player.Context.Units.LavaQuestManager$$TryGetEventInfo
1f0bbac: ldr x0, [x26, #0x80]
1f0bbb0: cbz x0, #0x1f0bc1c
1f0bbb4: mov x1, xzr
1f0bbb8: bl #0x1dc4b64 ; Royal.Player.Context.Units.LavaQuestManager$$TryGetFacebookIds
1f0bbbc: ldr x0, [x26, #0x88]
1f0bbc0: cbz x0, #0x1f0bc1c
1f0bbc4: mov x1, xzr
1f0bbc8: bl #0x1c6d328 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateEventState
1f0bbcc: ldr x0, [x26, #0x100]
1f0bbd0: cbz x0, #0x1f0bc1c
1f0bbd4: mov x1, xzr
1f0bbd8: bl #0x21befec ; Royal.Player.Context.Units.DailyLightningRushManager$$ProgressUpdated
1f0bbdc: ldr x0, [x26, #0x118]
1f0bbe0: cbz x0, #0x1f0bc1c
1f0bbe4: mov x1, xzr
1f0bbe8: bl #0x319e6e8 ; Royal.Player.Context.Units.PropellerRushManager$$ProgressUpdated
1f0bbec: ldr x0, [x26, #0x130]
1f0bbf0: cbz x0, #0x1f0bc1c
1f0bbf4: mov x1, xzr
1f0bbf8: bl #0x32ebe04 ; Royal.Player.Context.Units.RobotRivalsManager$$ProgressUpdated
1f0bbfc: ldp x29, x30, [sp, #0x130]
1f0bc00: ldp x20, x19, [sp, #0x120]
1f0bc04: ldp x22, x21, [sp, #0x110]
1f0bc08: ldp x24, x23, [sp, #0x100]
1f0bc0c: ldp x26, x25, [sp, #0xf0]
1f0bc10: ldp x28, x27, [sp, #0xe0]
1f0bc14: add sp, sp, #0x140
1f0bc18: ret 
1f0bc1c: bl #0xfb1428 ; 
