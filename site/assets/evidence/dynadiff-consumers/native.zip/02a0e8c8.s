# Royal.Player.Context.Data.Persistent.UserInventory$$SetLastUpdatedSection
# Linear metadata span; not complete CFG.
2a0e8c8: stp x19, x30, [sp, #-0x10]!
2a0e8cc: mov x19, x0
2a0e8d0: ldr x0, [x0, #0xb0]
2a0e8d4: mov w2, #0x12
2a0e8d8: mov w3, #0x22
2a0e8dc: mov x4, xzr
2a0e8e0: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e8e4: mov x1, x0
2a0e8e8: mov x0, x19
2a0e8ec: ldp x19, x30, [sp], #0x10
2a0e8f0: b #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
