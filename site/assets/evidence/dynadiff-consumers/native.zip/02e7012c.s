# Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
# Linear metadata span; not complete CFG.
2e7012c: str x20, [sp, #-0x20]!
2e70130: stp x19, x30, [sp, #0x10]
2e70134: mov x19, x1
2e70138: mov x20, x0
2e7013c: bl #0x2e6ff3c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$get_DatabaseService
2e70140: mov x2, x19
2e70144: ldp x19, x30, [sp, #0x10]
2e70148: mov x1, x20
2e7014c: mov w3, wzr
2e70150: ldr x20, [sp], #0x20
2e70154: b #0x2e60270 ; Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$SetLong
