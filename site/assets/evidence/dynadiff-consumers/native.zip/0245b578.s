# Royal.Player.Context.Data.Session.UserActiveLevelData$$get_IsLeague
# Linear metadata span; not complete CFG.
245b578: ldr w8, [x0, #0x2c]
245b57c: cmp w8, #0
245b580: cset w0, gt
245b584: ret 
