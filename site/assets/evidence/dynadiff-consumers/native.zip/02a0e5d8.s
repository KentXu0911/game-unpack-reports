# Royal.Player.Context.Data.Persistent.UserInventory$$SetTryCount2
# Linear metadata span; not complete CFG.
2a0e5d8: str x24, [sp, #-0x40]!
2a0e5dc: stp x23, x22, [sp, #0x10]
2a0e5e0: stp x21, x20, [sp, #0x20]
2a0e5e4: stp x19, x30, [sp, #0x30]
2a0e5e8: adrp x24, #0x5581000
2a0e5ec: adrp x23, #0x5204000
2a0e5f0: adrp x22, #0x519a000
2a0e5f4: adrp x21, #0x5222000
2a0e5f8: ldrb w8, [x24, #0xd51]
2a0e5fc: ldr x23, [x23, #0xf78]
2a0e600: ldr x22, [x22, #0xbb8]
2a0e604: ldr x21, [x21, #0x5d8]
2a0e608: mov w20, w1
2a0e60c: mov x19, x0
2a0e610: tbnz w8, #0, #0x2a0e640
2a0e614: adrp x0, #0x5222000
2a0e618: ldr x0, [x0, #0x5d8]
2a0e61c: bl #0xfb1300 ; 
2a0e620: adrp x0, #0x5204000
2a0e624: ldr x0, [x0, #0xf78]
2a0e628: bl #0xfb1300 ; 
2a0e62c: adrp x0, #0x519a000
2a0e630: ldr x0, [x0, #0xbb8]
2a0e634: bl #0xfb1300 ; 
2a0e638: mov w8, #1
2a0e63c: strb w8, [x24, #0xd51]
2a0e640: ldr x0, [x23]
2a0e644: add x1, sp, #0xc
2a0e648: str w20, [sp, #0xc]
2a0e64c: bl #0xfb140c ; 
2a0e650: ldr x8, [x22]
2a0e654: mov x1, x0
2a0e658: mov x2, xzr
2a0e65c: mov x0, x8
2a0e660: bl #0x1cfdfd8 ; System.String$$Format
2a0e664: ldr x22, [x21]
2a0e668: mov x21, x0
2a0e66c: ldr x8, [x22, #0x38]
2a0e670: ldr x8, [x8]
2a0e674: ldrb w9, [x8, #0x132]
2a0e678: tbnz w9, #0, #0x2a0e688
2a0e67c: mov x0, x8
2a0e680: bl #0xf80fe4 ; 
2a0e684: mov x8, x0
2a0e688: ldr w9, [x8, #0xe0]
2a0e68c: cbnz w9, #0x2a0e698
2a0e690: mov x0, x8
2a0e694: bl #0xfb1404 ; 
2a0e698: ldr x8, [x22, #0x38]
2a0e69c: ldr x0, [x8]
2a0e6a0: ldrb w8, [x0, #0x132]
2a0e6a4: tbnz w8, #0, #0x2a0e6ac
2a0e6a8: bl #0xf80fe4 ; 
2a0e6ac: ldr x8, [x0, #0xb8]
2a0e6b0: mov w1, #0xa
2a0e6b4: mov x0, x19
2a0e6b8: mov x2, x21
2a0e6bc: ldr x3, [x8]
2a0e6c0: mov x4, xzr
2a0e6c4: bl #0x2800920 ; Royal.Infrastructure.Services.Logs.Log$$Debug
2a0e6c8: ldr x0, [x19, #0xb0]
2a0e6cc: mov w2, #1
2a0e6d0: mov w3, #0xc
2a0e6d4: mov w1, w20
2a0e6d8: mov x4, xzr
2a0e6dc: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e6e0: mov x1, x0
2a0e6e4: mov x0, x19
2a0e6e8: bl #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
2a0e6ec: ldp x19, x30, [sp, #0x30]
2a0e6f0: ldp x21, x20, [sp, #0x20]
2a0e6f4: ldp x23, x22, [sp, #0x10]
2a0e6f8: ldr x24, [sp], #0x40
2a0e6fc: ret 
