# Royal.Infrastructure.Services.Storage.DatabaseService$$.ctor
# Linear metadata span; not complete CFG.
2e5a504: stp x23, x22, [sp, #-0x30]!
2e5a508: stp x21, x20, [sp, #0x10]
2e5a50c: stp x19, x30, [sp, #0x20]
2e5a510: adrp x20, #0x5584000
2e5a514: adrp x21, #0x51ab000
2e5a518: ldrb w8, [x20, #0x7f3]
2e5a51c: ldr x21, [x21, #0xf80]
2e5a520: mov x19, x0
2e5a524: tbnz w8, #0, #0x2e5a728
2e5a528: adrp x0, #0x5213000
2e5a52c: ldr x0, [x0, #0x390]
2e5a530: bl #0xfb1300 ; 
2e5a534: adrp x0, #0x51ab000
2e5a538: ldr x0, [x0, #0xf80]
2e5a53c: bl #0xfb1300 ; 
2e5a540: adrp x0, #0x51e7000
2e5a544: ldr x0, [x0, #0x160]
2e5a548: bl #0xfb1300 ; 
2e5a54c: adrp x0, #0x51fc000
2e5a550: ldr x0, [x0, #0x580]
2e5a554: bl #0xfb1300 ; 
2e5a558: adrp x0, #0x51f2000
2e5a55c: ldr x0, [x0, #0xb60]
2e5a560: bl #0xfb1300 ; 
2e5a564: adrp x0, #0x5233000
2e5a568: ldr x0, [x0, #0x3b0]
2e5a56c: bl #0xfb1300 ; 
2e5a570: adrp x0, #0x51ea000
2e5a574: ldr x0, [x0, #0x9f8]
2e5a578: bl #0xfb1300 ; 
2e5a57c: adrp x0, #0x51d5000
2e5a580: ldr x0, [x0, #0x4e0]
2e5a584: bl #0xfb1300 ; 
2e5a588: adrp x0, #0x51a1000
2e5a58c: ldr x0, [x0, #0x728]
2e5a590: bl #0xfb1300 ; 
2e5a594: adrp x0, #0x51ad000
2e5a598: ldr x0, [x0, #0x6e0]
2e5a59c: bl #0xfb1300 ; 
2e5a5a0: adrp x0, #0x51dd000
2e5a5a4: ldr x0, [x0, #0xed8]
2e5a5a8: bl #0xfb1300 ; 
2e5a5ac: adrp x0, #0x5207000
2e5a5b0: ldr x0, [x0, #0xd18]
2e5a5b4: bl #0xfb1300 ; 
2e5a5b8: adrp x0, #0x51b7000
2e5a5bc: ldr x0, [x0, #0x850]
2e5a5c0: bl #0xfb1300 ; 
2e5a5c4: adrp x0, #0x5197000
2e5a5c8: ldr x0, [x0, #0x290]
2e5a5cc: bl #0xfb1300 ; 
2e5a5d0: adrp x0, #0x520e000
2e5a5d4: ldr x0, [x0, #0x368]
2e5a5d8: bl #0xfb1300 ; 
2e5a5dc: adrp x0, #0x51db000
2e5a5e0: ldr x0, [x0, #0xcc0]
2e5a5e4: bl #0xfb1300 ; 
2e5a5e8: adrp x0, #0x51ff000
2e5a5ec: ldr x0, [x0, #8]
2e5a5f0: bl #0xfb1300 ; 
2e5a5f4: adrp x0, #0x521f000
2e5a5f8: ldr x0, [x0, #0xd90]
2e5a5fc: bl #0xfb1300 ; 
2e5a600: adrp x0, #0x51be000
2e5a604: ldr x0, [x0, #0xd50]
2e5a608: bl #0xfb1300 ; 
2e5a60c: adrp x0, #0x519f000
2e5a610: ldr x0, [x0, #0x488]
2e5a614: bl #0xfb1300 ; 
2e5a618: adrp x0, #0x51b3000
2e5a61c: ldr x0, [x0, #0x3c8]
2e5a620: bl #0xfb1300 ; 
2e5a624: adrp x0, #0x51cf000
2e5a628: ldr x0, [x0, #0xd10]
2e5a62c: bl #0xfb1300 ; 
2e5a630: adrp x0, #0x5202000
2e5a634: ldr x0, [x0, #0x7b0]
2e5a638: bl #0xfb1300 ; 
2e5a63c: adrp x0, #0x523e000
2e5a640: ldr x0, [x0, #0x590]
2e5a644: bl #0xfb1300 ; 
2e5a648: adrp x0, #0x5239000
2e5a64c: ldr x0, [x0, #0x50]
2e5a650: bl #0xfb1300 ; 
2e5a654: adrp x0, #0x51f9000
2e5a658: ldr x0, [x0, #0x290]
2e5a65c: bl #0xfb1300 ; 
2e5a660: adrp x0, #0x51a7000
2e5a664: ldr x0, [x0, #0xac8]
2e5a668: bl #0xfb1300 ; 
2e5a66c: adrp x0, #0x51bd000
2e5a670: ldr x0, [x0, #0x900]
2e5a674: bl #0xfb1300 ; 
2e5a678: adrp x0, #0x5196000
2e5a67c: ldr x0, [x0, #0xde8]
2e5a680: bl #0xfb1300 ; 
2e5a684: adrp x0, #0x5210000
2e5a688: ldr x0, [x0, #0xb88]
2e5a68c: bl #0xfb1300 ; 
2e5a690: adrp x0, #0x51e2000
2e5a694: ldr x0, [x0, #0xd38]
2e5a698: bl #0xfb1300 ; 
2e5a69c: adrp x0, #0x51eb000
2e5a6a0: ldr x0, [x0, #0x538]
2e5a6a4: bl #0xfb1300 ; 
2e5a6a8: adrp x0, #0x51fd000
2e5a6ac: ldr x0, [x0, #0xa28]
2e5a6b0: bl #0xfb1300 ; 
2e5a6b4: adrp x0, #0x5201000
2e5a6b8: ldr x0, [x0, #0x930]
2e5a6bc: bl #0xfb1300 ; 
2e5a6c0: adrp x0, #0x5219000
2e5a6c4: ldr x0, [x0, #0xc0]
2e5a6c8: bl #0xfb1300 ; 
2e5a6cc: adrp x0, #0x5220000
2e5a6d0: ldr x0, [x0, #0xf68]
2e5a6d4: bl #0xfb1300 ; 
2e5a6d8: adrp x0, #0x5236000
2e5a6dc: ldr x0, [x0, #0x8d0]
2e5a6e0: bl #0xfb1300 ; 
2e5a6e4: adrp x0, #0x5236000
2e5a6e8: ldr x0, [x0, #0xe58]
2e5a6ec: bl #0xfb1300 ; 
2e5a6f0: adrp x0, #0x51d5000
2e5a6f4: ldr x0, [x0, #0x9c8]
2e5a6f8: bl #0xfb1300 ; 
2e5a6fc: adrp x0, #0x51e8000
2e5a700: ldr x0, [x0, #0xd0]
2e5a704: bl #0xfb1300 ; 
2e5a708: adrp x0, #0x523d000
2e5a70c: ldr x0, [x0, #0xa8]
2e5a710: bl #0xfb1300 ; 
2e5a714: adrp x0, #0x51b9000
2e5a718: ldr x0, [x0, #0x7f8]
2e5a71c: bl #0xfb1300 ; 
2e5a720: mov w8, #1
2e5a724: strb w8, [x20, #0x7f3]
2e5a728: ldr x0, [x21]
2e5a72c: bl #0xfb1418 ; 
2e5a730: cbz x0, #0x2e5b8f0
2e5a734: adrp x21, #0x51e7000
2e5a738: ldr x21, [x21, #0x160]
2e5a73c: mov x1, xzr
2e5a740: mov x20, x0
2e5a744: bl #0x1c94d08 ; System.Text.StringBuilder$$.ctor
2e5a748: mov x0, x19
2e5a74c: str x20, [x0, #0x20]!
2e5a750: mov x1, x20
2e5a754: bl #0xfb12ac ; 
2e5a758: ldr x0, [x21]
2e5a75c: mov w1, #0x3a
2e5a760: bl #0xfb1370 ; 
2e5a764: cbz x0, #0x2e5b8f0
2e5a768: adrp x21, #0x51f2000
2e5a76c: ldr x21, [x21, #0xb60]
2e5a770: mov x20, x0
2e5a774: ldr x1, [x21]
2e5a778: cbz x1, #0x2e5a7a0
2e5a77c: ldr x8, [x20]
2e5a780: mov x0, x1
2e5a784: ldr x8, [x8, #0x40]
2e5a788: mov x1, x8
2e5a78c: bl #0xfb1408 ; 
2e5a790: cbz x0, #0x2e5b8e4
2e5a794: ldr x8, [x21]
2e5a798: mov x1, x8
2e5a79c: b #0x2e5a7a4 ; 
2e5a7a0: mov x8, xzr
2e5a7a4: mov x22, x20
2e5a7a8: ldr w9, [x22, #0x18]!
2e5a7ac: cbz w9, #0x2e5b8e0
2e5a7b0: adrp x21, #0x51bd000
2e5a7b4: ldr x21, [x21, #0x900]
2e5a7b8: mov x0, x20
2e5a7bc: str x8, [x0, #0x20]!
2e5a7c0: bl #0xfb12ac ; 
2e5a7c4: ldr x1, [x21]
2e5a7c8: cbz x1, #0x2e5a7f0
2e5a7cc: ldr x8, [x20]
2e5a7d0: mov x0, x1
2e5a7d4: ldr x8, [x8, #0x40]
2e5a7d8: mov x1, x8
2e5a7dc: bl #0xfb1408 ; 
2e5a7e0: cbz x0, #0x2e5b8e4
2e5a7e4: ldr x8, [x21]
2e5a7e8: mov x1, x8
2e5a7ec: b #0x2e5a7f4 ; 
2e5a7f0: mov x8, xzr
2e5a7f4: ldr w9, [x22]
2e5a7f8: cmp w9, #1
2e5a7fc: b.ls #0x2e5b8e0
2e5a800: adrp x21, #0x5239000
2e5a804: ldr x21, [x21, #0x50]
2e5a808: mov x0, x20
2e5a80c: str x8, [x0, #0x28]!
2e5a810: bl #0xfb12ac ; 
2e5a814: ldr x1, [x21]
2e5a818: cbz x1, #0x2e5a840
2e5a81c: ldr x8, [x20]
2e5a820: mov x0, x1
2e5a824: ldr x8, [x8, #0x40]
2e5a828: mov x1, x8
2e5a82c: bl #0xfb1408 ; 
2e5a830: cbz x0, #0x2e5b8e4
2e5a834: ldr x8, [x21]
2e5a838: mov x1, x8
2e5a83c: b #0x2e5a844 ; 
2e5a840: mov x8, xzr
2e5a844: ldr w9, [x22]
2e5a848: cmp w9, #2
2e5a84c: b.ls #0x2e5b8e0
2e5a850: adrp x21, #0x51fc000
2e5a854: ldr x21, [x21, #0x580]
2e5a858: mov x0, x20
2e5a85c: str x8, [x0, #0x30]!
2e5a860: bl #0xfb12ac ; 
2e5a864: ldr x1, [x21]
2e5a868: cbz x1, #0x2e5a890
2e5a86c: ldr x8, [x20]
2e5a870: mov x0, x1
2e5a874: ldr x8, [x8, #0x40]
2e5a878: mov x1, x8
2e5a87c: bl #0xfb1408 ; 
2e5a880: cbz x0, #0x2e5b8e4
2e5a884: ldr x8, [x21]
2e5a888: mov x1, x8
2e5a88c: b #0x2e5a894 ; 
2e5a890: mov x8, xzr
2e5a894: ldr w9, [x22]
2e5a898: cmp w9, #3
2e5a89c: b.ls #0x2e5b8e0
2e5a8a0: adrp x21, #0x51be000
2e5a8a4: ldr x21, [x21, #0xd50]
2e5a8a8: mov x0, x20
2e5a8ac: str x8, [x0, #0x38]!
2e5a8b0: bl #0xfb12ac ; 
2e5a8b4: ldr x1, [x21]
2e5a8b8: cbz x1, #0x2e5a8e0
2e5a8bc: ldr x8, [x20]
2e5a8c0: mov x0, x1
2e5a8c4: ldr x8, [x8, #0x40]
2e5a8c8: mov x1, x8
2e5a8cc: bl #0xfb1408 ; 
2e5a8d0: cbz x0, #0x2e5b8e4
2e5a8d4: ldr x8, [x21]
2e5a8d8: mov x1, x8
2e5a8dc: b #0x2e5a8e4 ; 
2e5a8e0: mov x8, xzr
2e5a8e4: ldr w9, [x22]
2e5a8e8: cmp w9, #4
2e5a8ec: b.ls #0x2e5b8e0
2e5a8f0: adrp x21, #0x5236000
2e5a8f4: ldr x21, [x21, #0x8d0]
2e5a8f8: mov x0, x20
2e5a8fc: str x8, [x0, #0x40]!
2e5a900: bl #0xfb12ac ; 
2e5a904: ldr x1, [x21]
2e5a908: cbz x1, #0x2e5a930
2e5a90c: ldr x8, [x20]
2e5a910: mov x0, x1
2e5a914: ldr x8, [x8, #0x40]
2e5a918: mov x1, x8
2e5a91c: bl #0xfb1408 ; 
2e5a920: cbz x0, #0x2e5b8e4
2e5a924: ldr x8, [x21]
2e5a928: mov x1, x8
2e5a92c: b #0x2e5a934 ; 
2e5a930: mov x8, xzr
2e5a934: ldr w9, [x22]
2e5a938: cmp w9, #5
2e5a93c: b.ls #0x2e5b8e0
2e5a940: adrp x21, #0x51e2000
2e5a944: ldr x21, [x21, #0xd38]
2e5a948: mov x0, x20
2e5a94c: str x8, [x0, #0x48]!
2e5a950: bl #0xfb12ac ; 
2e5a954: ldr x1, [x21]
2e5a958: cbz x1, #0x2e5a980
2e5a95c: ldr x8, [x20]
2e5a960: mov x0, x1
2e5a964: ldr x8, [x8, #0x40]
2e5a968: mov x1, x8
2e5a96c: bl #0xfb1408 ; 
2e5a970: cbz x0, #0x2e5b8e4
2e5a974: ldr x8, [x21]
2e5a978: mov x1, x8
2e5a97c: b #0x2e5a984 ; 
2e5a980: mov x8, xzr
2e5a984: ldr w9, [x22]
2e5a988: cmp w9, #6
2e5a98c: b.ls #0x2e5b8e0
2e5a990: adrp x21, #0x51ff000
2e5a994: ldr x21, [x21, #8]
2e5a998: mov x0, x20
2e5a99c: str x8, [x0, #0x50]!
2e5a9a0: bl #0xfb12ac ; 
2e5a9a4: ldr x1, [x21]
2e5a9a8: cbz x1, #0x2e5a9d0
2e5a9ac: ldr x8, [x20]
2e5a9b0: mov x0, x1
2e5a9b4: ldr x8, [x8, #0x40]
2e5a9b8: mov x1, x8
2e5a9bc: bl #0xfb1408 ; 
2e5a9c0: cbz x0, #0x2e5b8e4
2e5a9c4: ldr x8, [x21]
2e5a9c8: mov x1, x8
2e5a9cc: b #0x2e5a9d4 ; 
2e5a9d0: mov x8, xzr
2e5a9d4: ldr w9, [x22]
2e5a9d8: cmp w9, #7
2e5a9dc: b.ls #0x2e5b8e0
2e5a9e0: adrp x21, #0x51b9000
2e5a9e4: ldr x21, [x21, #0x7f8]
2e5a9e8: mov x0, x20
2e5a9ec: str x8, [x0, #0x58]!
2e5a9f0: bl #0xfb12ac ; 
2e5a9f4: ldr x1, [x21]
2e5a9f8: cbz x1, #0x2e5aa20
2e5a9fc: ldr x8, [x20]
2e5aa00: mov x0, x1
2e5aa04: ldr x8, [x8, #0x40]
2e5aa08: mov x1, x8
2e5aa0c: bl #0xfb1408 ; 
2e5aa10: cbz x0, #0x2e5b8e4
2e5aa14: ldr x8, [x21]
2e5aa18: mov x1, x8
2e5aa1c: b #0x2e5aa24 ; 
2e5aa20: mov x8, xzr
2e5aa24: ldr w9, [x22]
2e5aa28: cmp w9, #8
2e5aa2c: b.ls #0x2e5b8e0
2e5aa30: adrp x21, #0x51d5000
2e5aa34: ldr x21, [x21, #0x4e0]
2e5aa38: mov x0, x20
2e5aa3c: str x8, [x0, #0x60]!
2e5aa40: bl #0xfb12ac ; 
2e5aa44: ldr x1, [x21]
2e5aa48: cbz x1, #0x2e5aa70
2e5aa4c: ldr x8, [x20]
2e5aa50: mov x0, x1
2e5aa54: ldr x8, [x8, #0x40]
2e5aa58: mov x1, x8
2e5aa5c: bl #0xfb1408 ; 
2e5aa60: cbz x0, #0x2e5b8e4
2e5aa64: ldr x8, [x21]
2e5aa68: mov x1, x8
2e5aa6c: b #0x2e5aa74 ; 
2e5aa70: mov x8, xzr
2e5aa74: ldr w9, [x22]
2e5aa78: cmp w9, #9
2e5aa7c: b.ls #0x2e5b8e0
2e5aa80: adrp x21, #0x5219000
2e5aa84: ldr x21, [x21, #0xc0]
2e5aa88: mov x0, x20
2e5aa8c: str x8, [x0, #0x68]!
2e5aa90: bl #0xfb12ac ; 
2e5aa94: ldr x1, [x21]
2e5aa98: cbz x1, #0x2e5aac0
2e5aa9c: ldr x8, [x20]
2e5aaa0: mov x0, x1
2e5aaa4: ldr x8, [x8, #0x40]
2e5aaa8: mov x1, x8
2e5aaac: bl #0xfb1408 ; 
2e5aab0: cbz x0, #0x2e5b8e4
2e5aab4: ldr x8, [x21]
2e5aab8: mov x1, x8
2e5aabc: b #0x2e5aac4 ; 
2e5aac0: mov x8, xzr
2e5aac4: ldr w9, [x22]
2e5aac8: cmp w9, #0xa
2e5aacc: b.ls #0x2e5b8e0
2e5aad0: adrp x21, #0x5210000
2e5aad4: ldr x21, [x21, #0xb88]
2e5aad8: mov x0, x20
2e5aadc: str x8, [x0, #0x70]!
2e5aae0: bl #0xfb12ac ; 
2e5aae4: ldr x1, [x21]
2e5aae8: cbz x1, #0x2e5ab10
2e5aaec: ldr x8, [x20]
2e5aaf0: mov x0, x1
2e5aaf4: ldr x8, [x8, #0x40]
2e5aaf8: mov x1, x8
2e5aafc: bl #0xfb1408 ; 
2e5ab00: cbz x0, #0x2e5b8e4
2e5ab04: ldr x8, [x21]
2e5ab08: mov x1, x8
2e5ab0c: b #0x2e5ab14 ; 
2e5ab10: mov x8, xzr
2e5ab14: ldr w9, [x22]
2e5ab18: cmp w9, #0xb
2e5ab1c: b.ls #0x2e5b8e0
2e5ab20: adrp x21, #0x51e8000
2e5ab24: ldr x21, [x21, #0xd0]
2e5ab28: mov x0, x20
2e5ab2c: str x8, [x0, #0x78]!
2e5ab30: bl #0xfb12ac ; 
2e5ab34: ldr x1, [x21]
2e5ab38: cbz x1, #0x2e5ab60
2e5ab3c: ldr x8, [x20]
2e5ab40: mov x0, x1
2e5ab44: ldr x8, [x8, #0x40]
2e5ab48: mov x1, x8
2e5ab4c: bl #0xfb1408 ; 
2e5ab50: cbz x0, #0x2e5b8e4
2e5ab54: ldr x8, [x21]
2e5ab58: mov x1, x8
2e5ab5c: b #0x2e5ab64 ; 
2e5ab60: mov x8, xzr
2e5ab64: ldr w9, [x22]
2e5ab68: cmp w9, #0xc
2e5ab6c: b.ls #0x2e5b8e0
2e5ab70: adrp x21, #0x51ea000
2e5ab74: ldr x21, [x21, #0x9f8]
2e5ab78: mov x0, x20
2e5ab7c: str x8, [x0, #0x80]!
2e5ab80: bl #0xfb12ac ; 
2e5ab84: ldr x1, [x21]
2e5ab88: cbz x1, #0x2e5abb0
2e5ab8c: ldr x8, [x20]
2e5ab90: mov x0, x1
2e5ab94: ldr x8, [x8, #0x40]
2e5ab98: mov x1, x8
2e5ab9c: bl #0xfb1408 ; 
2e5aba0: cbz x0, #0x2e5b8e4
2e5aba4: ldr x8, [x21]
2e5aba8: mov x1, x8
2e5abac: b #0x2e5abb4 ; 
2e5abb0: mov x8, xzr
2e5abb4: ldr w9, [x22]
2e5abb8: cmp w9, #0xd
2e5abbc: b.ls #0x2e5b8e0
2e5abc0: adrp x21, #0x51a7000
2e5abc4: ldr x21, [x21, #0xac8]
2e5abc8: mov x0, x20
2e5abcc: str x8, [x0, #0x88]!
2e5abd0: bl #0xfb12ac ; 
2e5abd4: ldr x1, [x21]
2e5abd8: cbz x1, #0x2e5ac00
2e5abdc: ldr x8, [x20]
2e5abe0: mov x0, x1
2e5abe4: ldr x8, [x8, #0x40]
2e5abe8: mov x1, x8
2e5abec: bl #0xfb1408 ; 
2e5abf0: cbz x0, #0x2e5b8e4
2e5abf4: ldr x8, [x21]
2e5abf8: mov x1, x8
2e5abfc: b #0x2e5ac04 ; 
2e5ac00: mov x8, xzr
2e5ac04: ldr w9, [x22]
2e5ac08: cmp w9, #0xe
2e5ac0c: b.ls #0x2e5b8e0
2e5ac10: adrp x21, #0x51d5000
2e5ac14: ldr x21, [x21, #0x9c8]
2e5ac18: mov x0, x20
2e5ac1c: str x8, [x0, #0x90]!
2e5ac20: bl #0xfb12ac ; 
2e5ac24: ldr x1, [x21]
2e5ac28: cbz x1, #0x2e5ac50
2e5ac2c: ldr x8, [x20]
2e5ac30: mov x0, x1
2e5ac34: ldr x8, [x8, #0x40]
2e5ac38: mov x1, x8
2e5ac3c: bl #0xfb1408 ; 
2e5ac40: cbz x0, #0x2e5b8e4
2e5ac44: ldr x8, [x21]
2e5ac48: mov x1, x8
2e5ac4c: b #0x2e5ac54 ; 
2e5ac50: mov x8, xzr
2e5ac54: ldr w9, [x22]
2e5ac58: cmp w9, #0xf
2e5ac5c: b.ls #0x2e5b8e0
2e5ac60: adrp x21, #0x5196000
2e5ac64: ldr x21, [x21, #0xde8]
2e5ac68: mov x0, x20
2e5ac6c: str x8, [x0, #0x98]!
2e5ac70: bl #0xfb12ac ; 
2e5ac74: ldr x1, [x21]
2e5ac78: cbz x1, #0x2e5aca0
2e5ac7c: ldr x8, [x20]
2e5ac80: mov x0, x1
2e5ac84: ldr x8, [x8, #0x40]
2e5ac88: mov x1, x8
2e5ac8c: bl #0xfb1408 ; 
2e5ac90: cbz x0, #0x2e5b8e4
2e5ac94: ldr x8, [x21]
2e5ac98: mov x1, x8
2e5ac9c: b #0x2e5aca4 ; 
2e5aca0: mov x8, xzr
2e5aca4: ldr w9, [x22]
2e5aca8: cmp w9, #0x10
2e5acac: b.ls #0x2e5b8e0
2e5acb0: adrp x21, #0x5233000
2e5acb4: ldr x21, [x21, #0x3b0]
2e5acb8: mov x0, x20
2e5acbc: str x8, [x0, #0xa0]!
2e5acc0: bl #0xfb12ac ; 
2e5acc4: ldr x1, [x21]
2e5acc8: cbz x1, #0x2e5acf0
2e5accc: ldr x8, [x20]
2e5acd0: mov x0, x1
2e5acd4: ldr x8, [x8, #0x40]
2e5acd8: mov x1, x8
2e5acdc: bl #0xfb1408 ; 
2e5ace0: cbz x0, #0x2e5b8e4
2e5ace4: ldr x8, [x21]
2e5ace8: mov x1, x8
2e5acec: b #0x2e5acf4 ; 
2e5acf0: mov x8, xzr
2e5acf4: ldr w9, [x22]
2e5acf8: cmp w9, #0x11
2e5acfc: b.ls #0x2e5b8e0
2e5ad00: adrp x21, #0x520e000
2e5ad04: ldr x21, [x21, #0x368]
2e5ad08: mov x0, x20
2e5ad0c: str x8, [x0, #0xa8]!
2e5ad10: bl #0xfb12ac ; 
2e5ad14: ldr x1, [x21]
2e5ad18: cbz x1, #0x2e5ad40
2e5ad1c: ldr x8, [x20]
2e5ad20: mov x0, x1
2e5ad24: ldr x8, [x8, #0x40]
2e5ad28: mov x1, x8
2e5ad2c: bl #0xfb1408 ; 
2e5ad30: cbz x0, #0x2e5b8e4
2e5ad34: ldr x8, [x21]
2e5ad38: mov x1, x8
2e5ad3c: b #0x2e5ad44 ; 
2e5ad40: mov x8, xzr
2e5ad44: ldr w9, [x22]
2e5ad48: cmp w9, #0x12
2e5ad4c: b.ls #0x2e5b8e0
2e5ad50: adrp x21, #0x51f9000
2e5ad54: ldr x21, [x21, #0x290]
2e5ad58: mov x0, x20
2e5ad5c: str x8, [x0, #0xb0]!
2e5ad60: bl #0xfb12ac ; 
2e5ad64: ldr x1, [x21]
2e5ad68: cbz x1, #0x2e5ad90
2e5ad6c: ldr x8, [x20]
2e5ad70: mov x0, x1
2e5ad74: ldr x8, [x8, #0x40]
2e5ad78: mov x1, x8
2e5ad7c: bl #0xfb1408 ; 
2e5ad80: cbz x0, #0x2e5b8e4
2e5ad84: ldr x8, [x21]
2e5ad88: mov x1, x8
2e5ad8c: b #0x2e5ad94 ; 
2e5ad90: mov x8, xzr
2e5ad94: ldr w9, [x22]
2e5ad98: cmp w9, #0x13
2e5ad9c: b.ls #0x2e5b8e0
2e5ada0: adrp x21, #0x519f000
2e5ada4: ldr x21, [x21, #0x488]
2e5ada8: mov x0, x20
2e5adac: str x8, [x0, #0xb8]!
2e5adb0: bl #0xfb12ac ; 
2e5adb4: ldr x1, [x21]
2e5adb8: cbz x1, #0x2e5ade0
2e5adbc: ldr x8, [x20]
2e5adc0: mov x0, x1
2e5adc4: ldr x8, [x8, #0x40]
2e5adc8: mov x1, x8
2e5adcc: bl #0xfb1408 ; 
2e5add0: cbz x0, #0x2e5b8e4
2e5add4: ldr x8, [x21]
2e5add8: mov x1, x8
2e5addc: b #0x2e5ade4 ; 
2e5ade0: mov x8, xzr
2e5ade4: ldr w9, [x22]
2e5ade8: cmp w9, #0x14
2e5adec: b.ls #0x2e5b8e0
2e5adf0: adrp x21, #0x51eb000
2e5adf4: ldr x21, [x21, #0x538]
2e5adf8: mov x0, x20
2e5adfc: str x8, [x0, #0xc0]!
2e5ae00: bl #0xfb12ac ; 
2e5ae04: ldr x1, [x21]
2e5ae08: cbz x1, #0x2e5ae30
2e5ae0c: ldr x8, [x20]
2e5ae10: mov x0, x1
2e5ae14: ldr x8, [x8, #0x40]
2e5ae18: mov x1, x8
2e5ae1c: bl #0xfb1408 ; 
2e5ae20: cbz x0, #0x2e5b8e4
2e5ae24: ldr x8, [x21]
2e5ae28: mov x1, x8
2e5ae2c: b #0x2e5ae34 ; 
2e5ae30: mov x8, xzr
2e5ae34: ldr w9, [x22]
2e5ae38: cmp w9, #0x15
2e5ae3c: b.ls #0x2e5b8e0
2e5ae40: adrp x21, #0x51db000
2e5ae44: ldr x21, [x21, #0xcc0]
2e5ae48: mov x0, x20
2e5ae4c: str x8, [x0, #0xc8]!
2e5ae50: bl #0xfb12ac ; 
2e5ae54: ldr x1, [x21]
2e5ae58: cbz x1, #0x2e5ae80
2e5ae5c: ldr x8, [x20]
2e5ae60: mov x0, x1
2e5ae64: ldr x8, [x8, #0x40]
2e5ae68: mov x1, x8
2e5ae6c: bl #0xfb1408 ; 
2e5ae70: cbz x0, #0x2e5b8e4
2e5ae74: ldr x8, [x21]
2e5ae78: mov x1, x8
2e5ae7c: b #0x2e5ae84 ; 
2e5ae80: mov x8, xzr
2e5ae84: ldr w9, [x22]
2e5ae88: cmp w9, #0x16
2e5ae8c: b.ls #0x2e5b8e0
2e5ae90: adrp x21, #0x523d000
2e5ae94: ldr x21, [x21, #0xa8]
2e5ae98: mov x0, x20
2e5ae9c: str x8, [x0, #0xd0]!
2e5aea0: bl #0xfb12ac ; 
2e5aea4: ldr x1, [x21]
2e5aea8: cbz x1, #0x2e5aed0
2e5aeac: ldr x8, [x20]
2e5aeb0: mov x0, x1
2e5aeb4: ldr x8, [x8, #0x40]
2e5aeb8: mov x1, x8
2e5aebc: bl #0xfb1408 ; 
2e5aec0: cbz x0, #0x2e5b8e4
2e5aec4: ldr x8, [x21]
2e5aec8: mov x1, x8
2e5aecc: b #0x2e5aed4 ; 
2e5aed0: mov x8, xzr
2e5aed4: ldr w9, [x22]
2e5aed8: cmp w9, #0x17
2e5aedc: b.ls #0x2e5b8e0
2e5aee0: mov x0, x20
2e5aee4: str x8, [x0, #0xd8]!
2e5aee8: bl #0xfb12ac ; 
2e5aeec: mov w0, #1
2e5aef0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5aef4: mov x21, x0
2e5aef8: cbz x0, #0x2e5af10
2e5aefc: ldr x8, [x20]
2e5af00: mov x0, x21
2e5af04: ldr x1, [x8, #0x40]
2e5af08: bl #0xfb1408 ; 
2e5af0c: cbz x0, #0x2e5b8e4
2e5af10: ldr w8, [x22]
2e5af14: cmp w8, #0x18
2e5af18: b.ls #0x2e5b8e0
2e5af1c: adrp x23, #0x5236000
2e5af20: ldr x23, [x23, #0xe58]
2e5af24: mov x0, x20
2e5af28: str x21, [x0, #0xe0]!
2e5af2c: mov x1, x21
2e5af30: bl #0xfb12ac ; 
2e5af34: ldr x1, [x23]
2e5af38: cbz x1, #0x2e5af60
2e5af3c: ldr x8, [x20]
2e5af40: mov x0, x1
2e5af44: ldr x8, [x8, #0x40]
2e5af48: mov x1, x8
2e5af4c: bl #0xfb1408 ; 
2e5af50: cbz x0, #0x2e5b8e4
2e5af54: ldr x8, [x23]
2e5af58: mov x1, x8
2e5af5c: b #0x2e5af64 ; 
2e5af60: mov x8, xzr
2e5af64: ldr w9, [x22]
2e5af68: cmp w9, #0x19
2e5af6c: b.ls #0x2e5b8e0
2e5af70: adrp x21, #0x51a1000
2e5af74: ldr x21, [x21, #0x728]
2e5af78: mov x0, x20
2e5af7c: str x8, [x0, #0xe8]!
2e5af80: bl #0xfb12ac ; 
2e5af84: ldr x1, [x21]
2e5af88: cbz x1, #0x2e5afb0
2e5af8c: ldr x8, [x20]
2e5af90: mov x0, x1
2e5af94: ldr x8, [x8, #0x40]
2e5af98: mov x1, x8
2e5af9c: bl #0xfb1408 ; 
2e5afa0: cbz x0, #0x2e5b8e4
2e5afa4: ldr x8, [x21]
2e5afa8: mov x1, x8
2e5afac: b #0x2e5afb4 ; 
2e5afb0: mov x8, xzr
2e5afb4: ldr w9, [x22]
2e5afb8: cmp w9, #0x1a
2e5afbc: b.ls #0x2e5b8e0
2e5afc0: adrp x21, #0x51b3000
2e5afc4: ldr x21, [x21, #0x3c8]
2e5afc8: mov x0, x20
2e5afcc: str x8, [x0, #0xf0]!
2e5afd0: bl #0xfb12ac ; 
2e5afd4: ldr x1, [x21]
2e5afd8: cbz x1, #0x2e5b000
2e5afdc: ldr x8, [x20]
2e5afe0: mov x0, x1
2e5afe4: ldr x8, [x8, #0x40]
2e5afe8: mov x1, x8
2e5afec: bl #0xfb1408 ; 
2e5aff0: cbz x0, #0x2e5b8e4
2e5aff4: ldr x8, [x21]
2e5aff8: mov x1, x8
2e5affc: b #0x2e5b004 ; 
2e5b000: mov x8, xzr
2e5b004: ldr w9, [x22]
2e5b008: cmp w9, #0x1b
2e5b00c: b.ls #0x2e5b8e0
2e5b010: adrp x21, #0x51b7000
2e5b014: ldr x21, [x21, #0x850]
2e5b018: mov x0, x20
2e5b01c: str x8, [x0, #0xf8]!
2e5b020: bl #0xfb12ac ; 
2e5b024: ldr x1, [x21]
2e5b028: cbz x1, #0x2e5b050
2e5b02c: ldr x8, [x20]
2e5b030: mov x0, x1
2e5b034: ldr x8, [x8, #0x40]
2e5b038: mov x1, x8
2e5b03c: bl #0xfb1408 ; 
2e5b040: cbz x0, #0x2e5b8e4
2e5b044: ldr x8, [x21]
2e5b048: mov x1, x8
2e5b04c: b #0x2e5b054 ; 
2e5b050: mov x8, xzr
2e5b054: ldr w9, [x22]
2e5b058: cmp w9, #0x1c
2e5b05c: b.ls #0x2e5b8e0
2e5b060: adrp x21, #0x5197000
2e5b064: ldr x21, [x21, #0x290]
2e5b068: add x0, x20, #0x100
2e5b06c: str x8, [x20, #0x100]
2e5b070: bl #0xfb12ac ; 
2e5b074: ldr x1, [x21]
2e5b078: cbz x1, #0x2e5b0a0
2e5b07c: ldr x8, [x20]
2e5b080: mov x0, x1
2e5b084: ldr x8, [x8, #0x40]
2e5b088: mov x1, x8
2e5b08c: bl #0xfb1408 ; 
2e5b090: cbz x0, #0x2e5b8e4
2e5b094: ldr x8, [x21]
2e5b098: mov x1, x8
2e5b09c: b #0x2e5b0a4 ; 
2e5b0a0: mov x8, xzr
2e5b0a4: ldr w9, [x22]
2e5b0a8: cmp w9, #0x1d
2e5b0ac: b.ls #0x2e5b8e0
2e5b0b0: add x0, x20, #0x108
2e5b0b4: str x8, [x20, #0x108]
2e5b0b8: bl #0xfb12ac ; 
2e5b0bc: mov w0, #2
2e5b0c0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b0c4: mov x21, x0
2e5b0c8: cbz x0, #0x2e5b0e0
2e5b0cc: ldr x8, [x20]
2e5b0d0: mov x0, x21
2e5b0d4: ldr x1, [x8, #0x40]
2e5b0d8: bl #0xfb1408 ; 
2e5b0dc: cbz x0, #0x2e5b8e4
2e5b0e0: ldr w8, [x22]
2e5b0e4: cmp w8, #0x1e
2e5b0e8: b.ls #0x2e5b8e0
2e5b0ec: adrp x23, #0x5201000
2e5b0f0: ldr x23, [x23, #0x930]
2e5b0f4: add x0, x20, #0x110
2e5b0f8: mov x1, x21
2e5b0fc: str x21, [x20, #0x110]
2e5b100: bl #0xfb12ac ; 
2e5b104: ldr x1, [x23]
2e5b108: cbz x1, #0x2e5b130
2e5b10c: ldr x8, [x20]
2e5b110: mov x0, x1
2e5b114: ldr x8, [x8, #0x40]
2e5b118: mov x1, x8
2e5b11c: bl #0xfb1408 ; 
2e5b120: cbz x0, #0x2e5b8e4
2e5b124: ldr x8, [x23]
2e5b128: mov x1, x8
2e5b12c: b #0x2e5b134 ; 
2e5b130: mov x8, xzr
2e5b134: ldr w9, [x22]
2e5b138: cmp w9, #0x1f
2e5b13c: b.ls #0x2e5b8e0
2e5b140: adrp x21, #0x51fd000
2e5b144: ldr x21, [x21, #0xa28]
2e5b148: add x0, x20, #0x118
2e5b14c: str x8, [x20, #0x118]
2e5b150: bl #0xfb12ac ; 
2e5b154: ldr x1, [x21]
2e5b158: cbz x1, #0x2e5b180
2e5b15c: ldr x8, [x20]
2e5b160: mov x0, x1
2e5b164: ldr x8, [x8, #0x40]
2e5b168: mov x1, x8
2e5b16c: bl #0xfb1408 ; 
2e5b170: cbz x0, #0x2e5b8e4
2e5b174: ldr x8, [x21]
2e5b178: mov x1, x8
2e5b17c: b #0x2e5b184 ; 
2e5b180: mov x8, xzr
2e5b184: ldr w9, [x22]
2e5b188: cmp w9, #0x20
2e5b18c: b.ls #0x2e5b8e0
2e5b190: adrp x21, #0x5207000
2e5b194: ldr x21, [x21, #0xd18]
2e5b198: add x0, x20, #0x120
2e5b19c: str x8, [x20, #0x120]
2e5b1a0: bl #0xfb12ac ; 
2e5b1a4: ldr x1, [x21]
2e5b1a8: cbz x1, #0x2e5b1d0
2e5b1ac: ldr x8, [x20]
2e5b1b0: mov x0, x1
2e5b1b4: ldr x8, [x8, #0x40]
2e5b1b8: mov x1, x8
2e5b1bc: bl #0xfb1408 ; 
2e5b1c0: cbz x0, #0x2e5b8e4
2e5b1c4: ldr x8, [x21]
2e5b1c8: mov x1, x8
2e5b1cc: b #0x2e5b1d4 ; 
2e5b1d0: mov x8, xzr
2e5b1d4: ldr w9, [x22]
2e5b1d8: cmp w9, #0x21
2e5b1dc: b.ls #0x2e5b8e0
2e5b1e0: adrp x21, #0x523e000
2e5b1e4: ldr x21, [x21, #0x590]
2e5b1e8: add x0, x20, #0x128
2e5b1ec: str x8, [x20, #0x128]
2e5b1f0: bl #0xfb12ac ; 
2e5b1f4: ldr x1, [x21]
2e5b1f8: cbz x1, #0x2e5b220
2e5b1fc: ldr x8, [x20]
2e5b200: mov x0, x1
2e5b204: ldr x8, [x8, #0x40]
2e5b208: mov x1, x8
2e5b20c: bl #0xfb1408 ; 
2e5b210: cbz x0, #0x2e5b8e4
2e5b214: ldr x8, [x21]
2e5b218: mov x1, x8
2e5b21c: b #0x2e5b224 ; 
2e5b220: mov x8, xzr
2e5b224: ldr w9, [x22]
2e5b228: cmp w9, #0x22
2e5b22c: b.ls #0x2e5b8e0
2e5b230: adrp x21, #0x5202000
2e5b234: ldr x21, [x21, #0x7b0]
2e5b238: add x0, x20, #0x130
2e5b23c: str x8, [x20, #0x130]
2e5b240: bl #0xfb12ac ; 
2e5b244: ldr x1, [x21]
2e5b248: cbz x1, #0x2e5b270
2e5b24c: ldr x8, [x20]
2e5b250: mov x0, x1
2e5b254: ldr x8, [x8, #0x40]
2e5b258: mov x1, x8
2e5b25c: bl #0xfb1408 ; 
2e5b260: cbz x0, #0x2e5b8e4
2e5b264: ldr x8, [x21]
2e5b268: mov x1, x8
2e5b26c: b #0x2e5b274 ; 
2e5b270: mov x8, xzr
2e5b274: ldr w9, [x22]
2e5b278: cmp w9, #0x23
2e5b27c: b.ls #0x2e5b8e0
2e5b280: adrp x21, #0x5220000
2e5b284: ldr x21, [x21, #0xf68]
2e5b288: add x0, x20, #0x138
2e5b28c: str x8, [x20, #0x138]
2e5b290: bl #0xfb12ac ; 
2e5b294: ldr x1, [x21]
2e5b298: cbz x1, #0x2e5b2c0
2e5b29c: ldr x8, [x20]
2e5b2a0: mov x0, x1
2e5b2a4: ldr x8, [x8, #0x40]
2e5b2a8: mov x1, x8
2e5b2ac: bl #0xfb1408 ; 
2e5b2b0: cbz x0, #0x2e5b8e4
2e5b2b4: ldr x8, [x21]
2e5b2b8: mov x1, x8
2e5b2bc: b #0x2e5b2c4 ; 
2e5b2c0: mov x8, xzr
2e5b2c4: ldr w9, [x22]
2e5b2c8: cmp w9, #0x24
2e5b2cc: b.ls #0x2e5b8e0
2e5b2d0: add x0, x20, #0x140
2e5b2d4: str x8, [x20, #0x140]
2e5b2d8: bl #0xfb12ac ; 
2e5b2dc: mov w0, #3
2e5b2e0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b2e4: mov x21, x0
2e5b2e8: cbz x0, #0x2e5b300
2e5b2ec: ldr x8, [x20]
2e5b2f0: mov x0, x21
2e5b2f4: ldr x1, [x8, #0x40]
2e5b2f8: bl #0xfb1408 ; 
2e5b2fc: cbz x0, #0x2e5b8e4
2e5b300: ldr w8, [x22]
2e5b304: cmp w8, #0x25
2e5b308: b.ls #0x2e5b8e0
2e5b30c: add x0, x20, #0x148
2e5b310: mov x1, x21
2e5b314: str x21, [x20, #0x148]
2e5b318: bl #0xfb12ac ; 
2e5b31c: mov w0, #4
2e5b320: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b324: mov x21, x0
2e5b328: cbz x0, #0x2e5b340
2e5b32c: ldr x8, [x20]
2e5b330: mov x0, x21
2e5b334: ldr x1, [x8, #0x40]
2e5b338: bl #0xfb1408 ; 
2e5b33c: cbz x0, #0x2e5b8e4
2e5b340: ldr w8, [x22]
2e5b344: cmp w8, #0x26
2e5b348: b.ls #0x2e5b8e0
2e5b34c: add x0, x20, #0x150
2e5b350: mov x1, x21
2e5b354: str x21, [x20, #0x150]
2e5b358: bl #0xfb12ac ; 
2e5b35c: mov w0, #5
2e5b360: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b364: mov x21, x0
2e5b368: cbz x0, #0x2e5b380
2e5b36c: ldr x8, [x20]
2e5b370: mov x0, x21
2e5b374: ldr x1, [x8, #0x40]
2e5b378: bl #0xfb1408 ; 
2e5b37c: cbz x0, #0x2e5b8e4
2e5b380: ldr w8, [x22]
2e5b384: cmp w8, #0x27
2e5b388: b.ls #0x2e5b8e0
2e5b38c: adrp x23, #0x51cf000
2e5b390: ldr x23, [x23, #0xd10]
2e5b394: add x0, x20, #0x158
2e5b398: mov x1, x21
2e5b39c: str x21, [x20, #0x158]
2e5b3a0: bl #0xfb12ac ; 
2e5b3a4: ldr x1, [x23]
2e5b3a8: cbz x1, #0x2e5b3d0
2e5b3ac: ldr x8, [x20]
2e5b3b0: mov x0, x1
2e5b3b4: ldr x8, [x8, #0x40]
2e5b3b8: mov x1, x8
2e5b3bc: bl #0xfb1408 ; 
2e5b3c0: cbz x0, #0x2e5b8e4
2e5b3c4: ldr x8, [x23]
2e5b3c8: mov x1, x8
2e5b3cc: b #0x2e5b3d4 ; 
2e5b3d0: mov x8, xzr
2e5b3d4: ldr w9, [x22]
2e5b3d8: cmp w9, #0x28
2e5b3dc: b.ls #0x2e5b8e0
2e5b3e0: add x0, x20, #0x160
2e5b3e4: str x8, [x20, #0x160]
2e5b3e8: bl #0xfb12ac ; 
2e5b3ec: mov w0, #6
2e5b3f0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b3f4: mov x21, x0
2e5b3f8: cbz x0, #0x2e5b410
2e5b3fc: ldr x8, [x20]
2e5b400: mov x0, x21
2e5b404: ldr x1, [x8, #0x40]
2e5b408: bl #0xfb1408 ; 
2e5b40c: cbz x0, #0x2e5b8e4
2e5b410: ldr w8, [x22]
2e5b414: cmp w8, #0x29
2e5b418: b.ls #0x2e5b8e0
2e5b41c: adrp x23, #0x521f000
2e5b420: ldr x23, [x23, #0xd90]
2e5b424: add x0, x20, #0x168
2e5b428: mov x1, x21
2e5b42c: str x21, [x20, #0x168]
2e5b430: bl #0xfb12ac ; 
2e5b434: ldr x1, [x23]
2e5b438: cbz x1, #0x2e5b460
2e5b43c: ldr x8, [x20]
2e5b440: mov x0, x1
2e5b444: ldr x8, [x8, #0x40]
2e5b448: mov x1, x8
2e5b44c: bl #0xfb1408 ; 
2e5b450: cbz x0, #0x2e5b8e4
2e5b454: ldr x8, [x23]
2e5b458: mov x1, x8
2e5b45c: b #0x2e5b464 ; 
2e5b460: mov x8, xzr
2e5b464: ldr w9, [x22]
2e5b468: cmp w9, #0x2a
2e5b46c: b.ls #0x2e5b8e0
2e5b470: add x0, x20, #0x170
2e5b474: str x8, [x20, #0x170]
2e5b478: bl #0xfb12ac ; 
2e5b47c: mov w0, #7
2e5b480: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b484: mov x21, x0
2e5b488: cbz x0, #0x2e5b4a0
2e5b48c: ldr x8, [x20]
2e5b490: mov x0, x21
2e5b494: ldr x1, [x8, #0x40]
2e5b498: bl #0xfb1408 ; 
2e5b49c: cbz x0, #0x2e5b8e4
2e5b4a0: ldr w8, [x22]
2e5b4a4: cmp w8, #0x2b
2e5b4a8: b.ls #0x2e5b8e0
2e5b4ac: add x0, x20, #0x178
2e5b4b0: mov x1, x21
2e5b4b4: str x21, [x20, #0x178]
2e5b4b8: bl #0xfb12ac ; 
2e5b4bc: mov w0, #0xd
2e5b4c0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b4c4: mov x21, x0
2e5b4c8: cbz x0, #0x2e5b4e0
2e5b4cc: ldr x8, [x20]
2e5b4d0: mov x0, x21
2e5b4d4: ldr x1, [x8, #0x40]
2e5b4d8: bl #0xfb1408 ; 
2e5b4dc: cbz x0, #0x2e5b8e4
2e5b4e0: ldr w8, [x22]
2e5b4e4: cmp w8, #0x2c
2e5b4e8: b.ls #0x2e5b8e0
2e5b4ec: add x0, x20, #0x180
2e5b4f0: mov x1, x21
2e5b4f4: str x21, [x20, #0x180]
2e5b4f8: bl #0xfb12ac ; 
2e5b4fc: mov w0, #9
2e5b500: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b504: mov x21, x0
2e5b508: cbz x0, #0x2e5b520
2e5b50c: ldr x8, [x20]
2e5b510: mov x0, x21
2e5b514: ldr x1, [x8, #0x40]
2e5b518: bl #0xfb1408 ; 
2e5b51c: cbz x0, #0x2e5b8e4
2e5b520: ldr w8, [x22]
2e5b524: cmp w8, #0x2d
2e5b528: b.ls #0x2e5b8e0
2e5b52c: add x0, x20, #0x188
2e5b530: mov x1, x21
2e5b534: str x21, [x20, #0x188]
2e5b538: bl #0xfb12ac ; 
2e5b53c: mov w0, #0xa
2e5b540: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b544: mov x21, x0
2e5b548: cbz x0, #0x2e5b560
2e5b54c: ldr x8, [x20]
2e5b550: mov x0, x21
2e5b554: ldr x1, [x8, #0x40]
2e5b558: bl #0xfb1408 ; 
2e5b55c: cbz x0, #0x2e5b8e4
2e5b560: ldr w8, [x22]
2e5b564: cmp w8, #0x2e
2e5b568: b.ls #0x2e5b8e0
2e5b56c: adrp x23, #0x51dd000
2e5b570: ldr x23, [x23, #0xed8]
2e5b574: add x0, x20, #0x190
2e5b578: mov x1, x21
2e5b57c: str x21, [x20, #0x190]
2e5b580: bl #0xfb12ac ; 
2e5b584: ldr x1, [x23]
2e5b588: cbz x1, #0x2e5b5b0
2e5b58c: ldr x8, [x20]
2e5b590: mov x0, x1
2e5b594: ldr x8, [x8, #0x40]
2e5b598: mov x1, x8
2e5b59c: bl #0xfb1408 ; 
2e5b5a0: cbz x0, #0x2e5b8e4
2e5b5a4: ldr x8, [x23]
2e5b5a8: mov x1, x8
2e5b5ac: b #0x2e5b5b4 ; 
2e5b5b0: mov x8, xzr
2e5b5b4: ldr w9, [x22]
2e5b5b8: cmp w9, #0x2f
2e5b5bc: b.ls #0x2e5b8e0
2e5b5c0: add x0, x20, #0x198
2e5b5c4: str x8, [x20, #0x198]
2e5b5c8: bl #0xfb12ac ; 
2e5b5cc: mov w0, #0xe
2e5b5d0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b5d4: mov x21, x0
2e5b5d8: cbz x0, #0x2e5b5f0
2e5b5dc: ldr x8, [x20]
2e5b5e0: mov x0, x21
2e5b5e4: ldr x1, [x8, #0x40]
2e5b5e8: bl #0xfb1408 ; 
2e5b5ec: cbz x0, #0x2e5b8e4
2e5b5f0: ldr w8, [x22]
2e5b5f4: cmp w8, #0x30
2e5b5f8: b.ls #0x2e5b8e0
2e5b5fc: add x0, x20, #0x1a0
2e5b600: mov x1, x21
2e5b604: str x21, [x20, #0x1a0]
2e5b608: bl #0xfb12ac ; 
2e5b60c: mov w0, #0xc
2e5b610: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b614: mov x21, x0
2e5b618: cbz x0, #0x2e5b630
2e5b61c: ldr x8, [x20]
2e5b620: mov x0, x21
2e5b624: ldr x1, [x8, #0x40]
2e5b628: bl #0xfb1408 ; 
2e5b62c: cbz x0, #0x2e5b8e4
2e5b630: ldr w8, [x22]
2e5b634: cmp w8, #0x31
2e5b638: b.ls #0x2e5b8e0
2e5b63c: adrp x23, #0x51ad000
2e5b640: ldr x23, [x23, #0x6e0]
2e5b644: add x0, x20, #0x1a8
2e5b648: mov x1, x21
2e5b64c: str x21, [x20, #0x1a8]
2e5b650: bl #0xfb12ac ; 
2e5b654: ldr x1, [x23]
2e5b658: cbz x1, #0x2e5b680
2e5b65c: ldr x8, [x20]
2e5b660: mov x0, x1
2e5b664: ldr x8, [x8, #0x40]
2e5b668: mov x1, x8
2e5b66c: bl #0xfb1408 ; 
2e5b670: cbz x0, #0x2e5b8e4
2e5b674: ldr x8, [x23]
2e5b678: mov x1, x8
2e5b67c: b #0x2e5b684 ; 
2e5b680: mov x8, xzr
2e5b684: ldr w9, [x22]
2e5b688: cmp w9, #0x32
2e5b68c: b.ls #0x2e5b8e0
2e5b690: add x0, x20, #0x1b0
2e5b694: str x8, [x20, #0x1b0]
2e5b698: bl #0xfb12ac ; 
2e5b69c: mov w0, #0xf
2e5b6a0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b6a4: mov x21, x0
2e5b6a8: cbz x0, #0x2e5b6c0
2e5b6ac: ldr x8, [x20]
2e5b6b0: mov x0, x21
2e5b6b4: ldr x1, [x8, #0x40]
2e5b6b8: bl #0xfb1408 ; 
2e5b6bc: cbz x0, #0x2e5b8e4
2e5b6c0: ldr w8, [x22]
2e5b6c4: cmp w8, #0x33
2e5b6c8: b.ls #0x2e5b8e0
2e5b6cc: add x0, x20, #0x1b8
2e5b6d0: mov x1, x21
2e5b6d4: str x21, [x20, #0x1b8]
2e5b6d8: bl #0xfb12ac ; 
2e5b6dc: mov w0, #0x10
2e5b6e0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b6e4: mov x21, x0
2e5b6e8: cbz x0, #0x2e5b700
2e5b6ec: ldr x8, [x20]
2e5b6f0: mov x0, x21
2e5b6f4: ldr x1, [x8, #0x40]
2e5b6f8: bl #0xfb1408 ; 
2e5b6fc: cbz x0, #0x2e5b8e4
2e5b700: ldr w8, [x22]
2e5b704: cmp w8, #0x34
2e5b708: b.ls #0x2e5b8e0
2e5b70c: add x0, x20, #0x1c0
2e5b710: mov x1, x21
2e5b714: str x21, [x20, #0x1c0]
2e5b718: bl #0xfb12ac ; 
2e5b71c: mov w0, #0x11
2e5b720: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b724: mov x21, x0
2e5b728: cbz x0, #0x2e5b740
2e5b72c: ldr x8, [x20]
2e5b730: mov x0, x21
2e5b734: ldr x1, [x8, #0x40]
2e5b738: bl #0xfb1408 ; 
2e5b73c: cbz x0, #0x2e5b8e4
2e5b740: ldr w8, [x22]
2e5b744: cmp w8, #0x35
2e5b748: b.ls #0x2e5b8e0
2e5b74c: add x0, x20, #0x1c8
2e5b750: mov x1, x21
2e5b754: str x21, [x20, #0x1c8]
2e5b758: bl #0xfb12ac ; 
2e5b75c: mov w0, #0x12
2e5b760: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b764: mov x21, x0
2e5b768: cbz x0, #0x2e5b780
2e5b76c: ldr x8, [x20]
2e5b770: mov x0, x21
2e5b774: ldr x1, [x8, #0x40]
2e5b778: bl #0xfb1408 ; 
2e5b77c: cbz x0, #0x2e5b8e4
2e5b780: ldr w8, [x22]
2e5b784: cmp w8, #0x36
2e5b788: b.ls #0x2e5b8e0
2e5b78c: add x0, x20, #0x1d0
2e5b790: mov x1, x21
2e5b794: str x21, [x20, #0x1d0]
2e5b798: bl #0xfb12ac ; 
2e5b79c: mov w0, #0x13
2e5b7a0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b7a4: mov x21, x0
2e5b7a8: cbz x0, #0x2e5b7c0
2e5b7ac: ldr x8, [x20]
2e5b7b0: mov x0, x21
2e5b7b4: ldr x1, [x8, #0x40]
2e5b7b8: bl #0xfb1408 ; 
2e5b7bc: cbz x0, #0x2e5b8e4
2e5b7c0: ldr w8, [x22]
2e5b7c4: cmp w8, #0x37
2e5b7c8: b.ls #0x2e5b8e0
2e5b7cc: add x0, x20, #0x1d8
2e5b7d0: mov x1, x21
2e5b7d4: str x21, [x20, #0x1d8]
2e5b7d8: bl #0xfb12ac ; 
2e5b7dc: mov w0, #0x14
2e5b7e0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b7e4: mov x21, x0
2e5b7e8: cbz x0, #0x2e5b800
2e5b7ec: ldr x8, [x20]
2e5b7f0: mov x0, x21
2e5b7f4: ldr x1, [x8, #0x40]
2e5b7f8: bl #0xfb1408 ; 
2e5b7fc: cbz x0, #0x2e5b8e4
2e5b800: ldr w8, [x22]
2e5b804: cmp w8, #0x38
2e5b808: b.ls #0x2e5b8e0
2e5b80c: add x0, x20, #0x1e0
2e5b810: mov x1, x21
2e5b814: str x21, [x20, #0x1e0]
2e5b818: bl #0xfb12ac ; 
2e5b81c: mov w0, #0x15
2e5b820: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5b824: mov x21, x0
2e5b828: cbz x0, #0x2e5b840
2e5b82c: ldr x8, [x20]
2e5b830: mov x0, x21
2e5b834: ldr x1, [x8, #0x40]
2e5b838: bl #0xfb1408 ; 
2e5b83c: cbz x0, #0x2e5b8e4
2e5b840: ldr w8, [x22]
2e5b844: cmp w8, #0x39
2e5b848: b.ls #0x2e5b8e0
2e5b84c: adrp x22, #0x5213000
2e5b850: ldr x22, [x22, #0x390]
2e5b854: add x0, x20, #0x1e8
2e5b858: mov x1, x21
2e5b85c: str x21, [x20, #0x1e8]
2e5b860: bl #0xfb12ac ; 
2e5b864: mov x0, x19
2e5b868: str x20, [x0, #0x28]!
2e5b86c: mov x1, x20
2e5b870: bl #0xfb12ac ; 
2e5b874: mov x0, x19
2e5b878: mov x1, xzr
2e5b87c: bl #0x22735f4 ; System.Object$$.ctor
2e5b880: mov w8, #4
2e5b884: str w8, [x19, #0x30]
2e5b888: bl #0x2e5b984 ; Royal.Infrastructure.Services.Storage.DbFileHelper$$GetAppDbPath
2e5b88c: ldr x8, [x22]
2e5b890: mov x21, x0
2e5b894: mov x0, x8
2e5b898: bl #0xfb1418 ; 
2e5b89c: cbz x0, #0x2e5b8f0
2e5b8a0: mov x1, x21
2e5b8a4: mov w2, wzr
2e5b8a8: mov x3, xzr
2e5b8ac: mov x20, x0
2e5b8b0: bl #0x313fee0 ; Plugins.Sqlite.SQLiteConnection$$.ctor
2e5b8b4: mov x0, x19
2e5b8b8: str x20, [x0, #0x10]!
2e5b8bc: mov x1, x20
2e5b8c0: bl #0xfb12ac ; 
2e5b8c4: mov w8, #0x43
2e5b8c8: str w8, [x19, #0x18]
2e5b8cc: mov x0, x19
2e5b8d0: ldp x19, x30, [sp, #0x20]
2e5b8d4: ldp x21, x20, [sp, #0x10]
2e5b8d8: ldp x23, x22, [sp], #0x30
2e5b8dc: b #0x2e5ba24 ; Royal.Infrastructure.Services.Storage.DatabaseService$$CreateAppTables
2e5b8e0: bl #0xfb1430 ; 
2e5b8e4: bl #0xfb144c ; 
2e5b8e8: mov x1, xzr
2e5b8ec: bl #0xfb13f0 ; 
2e5b8f0: bl #0xfb1428 ; 
