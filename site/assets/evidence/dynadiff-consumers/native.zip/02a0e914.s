# Royal.Player.Context.Data.Persistent.UserInventory$$SetCurrentLevel
# Linear metadata span; not complete CFG.
2a0e914: stp x19, x30, [sp, #-0x10]!
2a0e918: mov x19, x0
2a0e91c: ldr x0, [x0, #0xb0]
2a0e920: mov w2, #0x23
2a0e924: mov w3, #0x31
2a0e928: mov x4, xzr
2a0e92c: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e930: mov x1, x0
2a0e934: mov x0, x19
2a0e938: ldp x19, x30, [sp], #0x10
2a0e93c: b #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
