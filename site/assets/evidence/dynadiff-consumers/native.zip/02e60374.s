# Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$GetLong
# Linear metadata span; not complete CFG.
2e60374: sub sp, sp, #0x50
2e60378: str x22, [sp, #0x20]
2e6037c: stp x21, x20, [sp, #0x30]
2e60380: stp x19, x30, [sp, #0x40]
2e60384: adrp x22, #0x5584000
2e60388: ldrb w8, [x22, #0x863]
2e6038c: mov x19, x2
2e60390: mov x20, x1
2e60394: mov x21, x0
2e60398: tbnz w8, #0, #0x2e603b0
2e6039c: adrp x0, #0x5205000
2e603a0: ldr x0, [x0, #0x590]
2e603a4: bl #0xfb1300 ; 
2e603a8: mov w8, #1
2e603ac: strb w8, [x22, #0x863]
2e603b0: str xzr, [sp, #0x28]
2e603b4: cbz x21, #0x2e60400
2e603b8: adrp x8, #0x5205000
2e603bc: ldr x8, [x8, #0x590]
2e603c0: mov x0, x21
2e603c4: mov x1, x20
2e603c8: ldr x2, [x8]
2e603cc: add x8, sp, #8
2e603d0: bl #0x1f647ac ; Royal.Infrastructure.Services.Storage.DatabaseService$$Find<KeyValue>
2e603d4: ldr x0, [sp, #0x10]
2e603d8: add x1, sp, #0x28
2e603dc: mov x2, xzr
2e603e0: bl #0x2596fe4 ; System.Int64$$TryParse
2e603e4: ldp x22, x8, [sp, #0x20]
2e603e8: tst w0, #1
2e603ec: ldp x21, x20, [sp, #0x30]
2e603f0: csel x0, x8, x19, ne
2e603f4: ldp x19, x30, [sp, #0x40]
2e603f8: add sp, sp, #0x50
2e603fc: ret 
2e60400: bl #0xfb1428 ; 
