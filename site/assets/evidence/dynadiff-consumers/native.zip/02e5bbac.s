# Royal.Infrastructure.Services.Storage.DatabaseService$$.ctor
# Linear metadata span; not complete CFG.
2e5bbac: str x24, [sp, #-0x40]!
2e5bbb0: stp x23, x22, [sp, #0x10]
2e5bbb4: stp x21, x20, [sp, #0x20]
2e5bbb8: stp x19, x30, [sp, #0x30]
2e5bbbc: adrp x21, #0x5584000
2e5bbc0: adrp x22, #0x51ab000
2e5bbc4: ldrb w8, [x21, #0x7f4]
2e5bbc8: ldr x22, [x22, #0xf80]
2e5bbcc: mov x20, x1
2e5bbd0: mov x19, x0
2e5bbd4: tbnz w8, #0, #0x2e5bdd8
2e5bbd8: adrp x0, #0x5213000
2e5bbdc: ldr x0, [x0, #0x390]
2e5bbe0: bl #0xfb1300 ; 
2e5bbe4: adrp x0, #0x51ab000
2e5bbe8: ldr x0, [x0, #0xf80]
2e5bbec: bl #0xfb1300 ; 
2e5bbf0: adrp x0, #0x51e7000
2e5bbf4: ldr x0, [x0, #0x160]
2e5bbf8: bl #0xfb1300 ; 
2e5bbfc: adrp x0, #0x51fc000
2e5bc00: ldr x0, [x0, #0x580]
2e5bc04: bl #0xfb1300 ; 
2e5bc08: adrp x0, #0x51f2000
2e5bc0c: ldr x0, [x0, #0xb60]
2e5bc10: bl #0xfb1300 ; 
2e5bc14: adrp x0, #0x5233000
2e5bc18: ldr x0, [x0, #0x3b0]
2e5bc1c: bl #0xfb1300 ; 
2e5bc20: adrp x0, #0x51ea000
2e5bc24: ldr x0, [x0, #0x9f8]
2e5bc28: bl #0xfb1300 ; 
2e5bc2c: adrp x0, #0x51d5000
2e5bc30: ldr x0, [x0, #0x4e0]
2e5bc34: bl #0xfb1300 ; 
2e5bc38: adrp x0, #0x51a1000
2e5bc3c: ldr x0, [x0, #0x728]
2e5bc40: bl #0xfb1300 ; 
2e5bc44: adrp x0, #0x51ad000
2e5bc48: ldr x0, [x0, #0x6e0]
2e5bc4c: bl #0xfb1300 ; 
2e5bc50: adrp x0, #0x51dd000
2e5bc54: ldr x0, [x0, #0xed8]
2e5bc58: bl #0xfb1300 ; 
2e5bc5c: adrp x0, #0x5207000
2e5bc60: ldr x0, [x0, #0xd18]
2e5bc64: bl #0xfb1300 ; 
2e5bc68: adrp x0, #0x51b7000
2e5bc6c: ldr x0, [x0, #0x850]
2e5bc70: bl #0xfb1300 ; 
2e5bc74: adrp x0, #0x5197000
2e5bc78: ldr x0, [x0, #0x290]
2e5bc7c: bl #0xfb1300 ; 
2e5bc80: adrp x0, #0x520e000
2e5bc84: ldr x0, [x0, #0x368]
2e5bc88: bl #0xfb1300 ; 
2e5bc8c: adrp x0, #0x51db000
2e5bc90: ldr x0, [x0, #0xcc0]
2e5bc94: bl #0xfb1300 ; 
2e5bc98: adrp x0, #0x51ff000
2e5bc9c: ldr x0, [x0, #8]
2e5bca0: bl #0xfb1300 ; 
2e5bca4: adrp x0, #0x521f000
2e5bca8: ldr x0, [x0, #0xd90]
2e5bcac: bl #0xfb1300 ; 
2e5bcb0: adrp x0, #0x51be000
2e5bcb4: ldr x0, [x0, #0xd50]
2e5bcb8: bl #0xfb1300 ; 
2e5bcbc: adrp x0, #0x519f000
2e5bcc0: ldr x0, [x0, #0x488]
2e5bcc4: bl #0xfb1300 ; 
2e5bcc8: adrp x0, #0x51b3000
2e5bccc: ldr x0, [x0, #0x3c8]
2e5bcd0: bl #0xfb1300 ; 
2e5bcd4: adrp x0, #0x51cf000
2e5bcd8: ldr x0, [x0, #0xd10]
2e5bcdc: bl #0xfb1300 ; 
2e5bce0: adrp x0, #0x5202000
2e5bce4: ldr x0, [x0, #0x7b0]
2e5bce8: bl #0xfb1300 ; 
2e5bcec: adrp x0, #0x523e000
2e5bcf0: ldr x0, [x0, #0x590]
2e5bcf4: bl #0xfb1300 ; 
2e5bcf8: adrp x0, #0x5239000
2e5bcfc: ldr x0, [x0, #0x50]
2e5bd00: bl #0xfb1300 ; 
2e5bd04: adrp x0, #0x51f9000
2e5bd08: ldr x0, [x0, #0x290]
2e5bd0c: bl #0xfb1300 ; 
2e5bd10: adrp x0, #0x51a7000
2e5bd14: ldr x0, [x0, #0xac8]
2e5bd18: bl #0xfb1300 ; 
2e5bd1c: adrp x0, #0x51bd000
2e5bd20: ldr x0, [x0, #0x900]
2e5bd24: bl #0xfb1300 ; 
2e5bd28: adrp x0, #0x5196000
2e5bd2c: ldr x0, [x0, #0xde8]
2e5bd30: bl #0xfb1300 ; 
2e5bd34: adrp x0, #0x5210000
2e5bd38: ldr x0, [x0, #0xb88]
2e5bd3c: bl #0xfb1300 ; 
2e5bd40: adrp x0, #0x51e2000
2e5bd44: ldr x0, [x0, #0xd38]
2e5bd48: bl #0xfb1300 ; 
2e5bd4c: adrp x0, #0x51eb000
2e5bd50: ldr x0, [x0, #0x538]
2e5bd54: bl #0xfb1300 ; 
2e5bd58: adrp x0, #0x51fd000
2e5bd5c: ldr x0, [x0, #0xa28]
2e5bd60: bl #0xfb1300 ; 
2e5bd64: adrp x0, #0x5201000
2e5bd68: ldr x0, [x0, #0x930]
2e5bd6c: bl #0xfb1300 ; 
2e5bd70: adrp x0, #0x5219000
2e5bd74: ldr x0, [x0, #0xc0]
2e5bd78: bl #0xfb1300 ; 
2e5bd7c: adrp x0, #0x5220000
2e5bd80: ldr x0, [x0, #0xf68]
2e5bd84: bl #0xfb1300 ; 
2e5bd88: adrp x0, #0x5236000
2e5bd8c: ldr x0, [x0, #0x8d0]
2e5bd90: bl #0xfb1300 ; 
2e5bd94: adrp x0, #0x5236000
2e5bd98: ldr x0, [x0, #0xe58]
2e5bd9c: bl #0xfb1300 ; 
2e5bda0: adrp x0, #0x51d5000
2e5bda4: ldr x0, [x0, #0x9c8]
2e5bda8: bl #0xfb1300 ; 
2e5bdac: adrp x0, #0x51e8000
2e5bdb0: ldr x0, [x0, #0xd0]
2e5bdb4: bl #0xfb1300 ; 
2e5bdb8: adrp x0, #0x523d000
2e5bdbc: ldr x0, [x0, #0xa8]
2e5bdc0: bl #0xfb1300 ; 
2e5bdc4: adrp x0, #0x51b9000
2e5bdc8: ldr x0, [x0, #0x7f8]
2e5bdcc: bl #0xfb1300 ; 
2e5bdd0: mov w8, #1
2e5bdd4: strb w8, [x21, #0x7f4]
2e5bdd8: ldr x0, [x22]
2e5bddc: bl #0xfb1418 ; 
2e5bde0: cbz x0, #0x2e5cfa4
2e5bde4: adrp x22, #0x51e7000
2e5bde8: ldr x22, [x22, #0x160]
2e5bdec: mov x1, xzr
2e5bdf0: mov x21, x0
2e5bdf4: bl #0x1c94d08 ; System.Text.StringBuilder$$.ctor
2e5bdf8: mov x0, x19
2e5bdfc: str x21, [x0, #0x20]!
2e5be00: mov x1, x21
2e5be04: bl #0xfb12ac ; 
2e5be08: ldr x0, [x22]
2e5be0c: mov w1, #0x3a
2e5be10: bl #0xfb1370 ; 
2e5be14: cbz x0, #0x2e5cfa4
2e5be18: adrp x22, #0x51f2000
2e5be1c: ldr x22, [x22, #0xb60]
2e5be20: mov x21, x0
2e5be24: ldr x1, [x22]
2e5be28: cbz x1, #0x2e5be50
2e5be2c: ldr x8, [x21]
2e5be30: mov x0, x1
2e5be34: ldr x8, [x8, #0x40]
2e5be38: mov x1, x8
2e5be3c: bl #0xfb1408 ; 
2e5be40: cbz x0, #0x2e5cf98
2e5be44: ldr x8, [x22]
2e5be48: mov x1, x8
2e5be4c: b #0x2e5be54 ; 
2e5be50: mov x8, xzr
2e5be54: mov x23, x21
2e5be58: ldr w9, [x23, #0x18]!
2e5be5c: cbz w9, #0x2e5cf94
2e5be60: adrp x22, #0x51bd000
2e5be64: ldr x22, [x22, #0x900]
2e5be68: mov x0, x21
2e5be6c: str x8, [x0, #0x20]!
2e5be70: bl #0xfb12ac ; 
2e5be74: ldr x1, [x22]
2e5be78: cbz x1, #0x2e5bea0
2e5be7c: ldr x8, [x21]
2e5be80: mov x0, x1
2e5be84: ldr x8, [x8, #0x40]
2e5be88: mov x1, x8
2e5be8c: bl #0xfb1408 ; 
2e5be90: cbz x0, #0x2e5cf98
2e5be94: ldr x8, [x22]
2e5be98: mov x1, x8
2e5be9c: b #0x2e5bea4 ; 
2e5bea0: mov x8, xzr
2e5bea4: ldr w9, [x23]
2e5bea8: cmp w9, #1
2e5beac: b.ls #0x2e5cf94
2e5beb0: adrp x22, #0x5239000
2e5beb4: ldr x22, [x22, #0x50]
2e5beb8: mov x0, x21
2e5bebc: str x8, [x0, #0x28]!
2e5bec0: bl #0xfb12ac ; 
2e5bec4: ldr x1, [x22]
2e5bec8: cbz x1, #0x2e5bef0
2e5becc: ldr x8, [x21]
2e5bed0: mov x0, x1
2e5bed4: ldr x8, [x8, #0x40]
2e5bed8: mov x1, x8
2e5bedc: bl #0xfb1408 ; 
2e5bee0: cbz x0, #0x2e5cf98
2e5bee4: ldr x8, [x22]
2e5bee8: mov x1, x8
2e5beec: b #0x2e5bef4 ; 
2e5bef0: mov x8, xzr
2e5bef4: ldr w9, [x23]
2e5bef8: cmp w9, #2
2e5befc: b.ls #0x2e5cf94
2e5bf00: adrp x22, #0x51fc000
2e5bf04: ldr x22, [x22, #0x580]
2e5bf08: mov x0, x21
2e5bf0c: str x8, [x0, #0x30]!
2e5bf10: bl #0xfb12ac ; 
2e5bf14: ldr x1, [x22]
2e5bf18: cbz x1, #0x2e5bf40
2e5bf1c: ldr x8, [x21]
2e5bf20: mov x0, x1
2e5bf24: ldr x8, [x8, #0x40]
2e5bf28: mov x1, x8
2e5bf2c: bl #0xfb1408 ; 
2e5bf30: cbz x0, #0x2e5cf98
2e5bf34: ldr x8, [x22]
2e5bf38: mov x1, x8
2e5bf3c: b #0x2e5bf44 ; 
2e5bf40: mov x8, xzr
2e5bf44: ldr w9, [x23]
2e5bf48: cmp w9, #3
2e5bf4c: b.ls #0x2e5cf94
2e5bf50: adrp x22, #0x51be000
2e5bf54: ldr x22, [x22, #0xd50]
2e5bf58: mov x0, x21
2e5bf5c: str x8, [x0, #0x38]!
2e5bf60: bl #0xfb12ac ; 
2e5bf64: ldr x1, [x22]
2e5bf68: cbz x1, #0x2e5bf90
2e5bf6c: ldr x8, [x21]
2e5bf70: mov x0, x1
2e5bf74: ldr x8, [x8, #0x40]
2e5bf78: mov x1, x8
2e5bf7c: bl #0xfb1408 ; 
2e5bf80: cbz x0, #0x2e5cf98
2e5bf84: ldr x8, [x22]
2e5bf88: mov x1, x8
2e5bf8c: b #0x2e5bf94 ; 
2e5bf90: mov x8, xzr
2e5bf94: ldr w9, [x23]
2e5bf98: cmp w9, #4
2e5bf9c: b.ls #0x2e5cf94
2e5bfa0: adrp x22, #0x5236000
2e5bfa4: ldr x22, [x22, #0x8d0]
2e5bfa8: mov x0, x21
2e5bfac: str x8, [x0, #0x40]!
2e5bfb0: bl #0xfb12ac ; 
2e5bfb4: ldr x1, [x22]
2e5bfb8: cbz x1, #0x2e5bfe0
2e5bfbc: ldr x8, [x21]
2e5bfc0: mov x0, x1
2e5bfc4: ldr x8, [x8, #0x40]
2e5bfc8: mov x1, x8
2e5bfcc: bl #0xfb1408 ; 
2e5bfd0: cbz x0, #0x2e5cf98
2e5bfd4: ldr x8, [x22]
2e5bfd8: mov x1, x8
2e5bfdc: b #0x2e5bfe4 ; 
2e5bfe0: mov x8, xzr
2e5bfe4: ldr w9, [x23]
2e5bfe8: cmp w9, #5
2e5bfec: b.ls #0x2e5cf94
2e5bff0: adrp x22, #0x51e2000
2e5bff4: ldr x22, [x22, #0xd38]
2e5bff8: mov x0, x21
2e5bffc: str x8, [x0, #0x48]!
2e5c000: bl #0xfb12ac ; 
2e5c004: ldr x1, [x22]
2e5c008: cbz x1, #0x2e5c030
2e5c00c: ldr x8, [x21]
2e5c010: mov x0, x1
2e5c014: ldr x8, [x8, #0x40]
2e5c018: mov x1, x8
2e5c01c: bl #0xfb1408 ; 
2e5c020: cbz x0, #0x2e5cf98
2e5c024: ldr x8, [x22]
2e5c028: mov x1, x8
2e5c02c: b #0x2e5c034 ; 
2e5c030: mov x8, xzr
2e5c034: ldr w9, [x23]
2e5c038: cmp w9, #6
2e5c03c: b.ls #0x2e5cf94
2e5c040: adrp x22, #0x51ff000
2e5c044: ldr x22, [x22, #8]
2e5c048: mov x0, x21
2e5c04c: str x8, [x0, #0x50]!
2e5c050: bl #0xfb12ac ; 
2e5c054: ldr x1, [x22]
2e5c058: cbz x1, #0x2e5c080
2e5c05c: ldr x8, [x21]
2e5c060: mov x0, x1
2e5c064: ldr x8, [x8, #0x40]
2e5c068: mov x1, x8
2e5c06c: bl #0xfb1408 ; 
2e5c070: cbz x0, #0x2e5cf98
2e5c074: ldr x8, [x22]
2e5c078: mov x1, x8
2e5c07c: b #0x2e5c084 ; 
2e5c080: mov x8, xzr
2e5c084: ldr w9, [x23]
2e5c088: cmp w9, #7
2e5c08c: b.ls #0x2e5cf94
2e5c090: adrp x22, #0x51b9000
2e5c094: ldr x22, [x22, #0x7f8]
2e5c098: mov x0, x21
2e5c09c: str x8, [x0, #0x58]!
2e5c0a0: bl #0xfb12ac ; 
2e5c0a4: ldr x1, [x22]
2e5c0a8: cbz x1, #0x2e5c0d0
2e5c0ac: ldr x8, [x21]
2e5c0b0: mov x0, x1
2e5c0b4: ldr x8, [x8, #0x40]
2e5c0b8: mov x1, x8
2e5c0bc: bl #0xfb1408 ; 
2e5c0c0: cbz x0, #0x2e5cf98
2e5c0c4: ldr x8, [x22]
2e5c0c8: mov x1, x8
2e5c0cc: b #0x2e5c0d4 ; 
2e5c0d0: mov x8, xzr
2e5c0d4: ldr w9, [x23]
2e5c0d8: cmp w9, #8
2e5c0dc: b.ls #0x2e5cf94
2e5c0e0: adrp x22, #0x51d5000
2e5c0e4: ldr x22, [x22, #0x4e0]
2e5c0e8: mov x0, x21
2e5c0ec: str x8, [x0, #0x60]!
2e5c0f0: bl #0xfb12ac ; 
2e5c0f4: ldr x1, [x22]
2e5c0f8: cbz x1, #0x2e5c120
2e5c0fc: ldr x8, [x21]
2e5c100: mov x0, x1
2e5c104: ldr x8, [x8, #0x40]
2e5c108: mov x1, x8
2e5c10c: bl #0xfb1408 ; 
2e5c110: cbz x0, #0x2e5cf98
2e5c114: ldr x8, [x22]
2e5c118: mov x1, x8
2e5c11c: b #0x2e5c124 ; 
2e5c120: mov x8, xzr
2e5c124: ldr w9, [x23]
2e5c128: cmp w9, #9
2e5c12c: b.ls #0x2e5cf94
2e5c130: adrp x22, #0x5219000
2e5c134: ldr x22, [x22, #0xc0]
2e5c138: mov x0, x21
2e5c13c: str x8, [x0, #0x68]!
2e5c140: bl #0xfb12ac ; 
2e5c144: ldr x1, [x22]
2e5c148: cbz x1, #0x2e5c170
2e5c14c: ldr x8, [x21]
2e5c150: mov x0, x1
2e5c154: ldr x8, [x8, #0x40]
2e5c158: mov x1, x8
2e5c15c: bl #0xfb1408 ; 
2e5c160: cbz x0, #0x2e5cf98
2e5c164: ldr x8, [x22]
2e5c168: mov x1, x8
2e5c16c: b #0x2e5c174 ; 
2e5c170: mov x8, xzr
2e5c174: ldr w9, [x23]
2e5c178: cmp w9, #0xa
2e5c17c: b.ls #0x2e5cf94
2e5c180: adrp x22, #0x5210000
2e5c184: ldr x22, [x22, #0xb88]
2e5c188: mov x0, x21
2e5c18c: str x8, [x0, #0x70]!
2e5c190: bl #0xfb12ac ; 
2e5c194: ldr x1, [x22]
2e5c198: cbz x1, #0x2e5c1c0
2e5c19c: ldr x8, [x21]
2e5c1a0: mov x0, x1
2e5c1a4: ldr x8, [x8, #0x40]
2e5c1a8: mov x1, x8
2e5c1ac: bl #0xfb1408 ; 
2e5c1b0: cbz x0, #0x2e5cf98
2e5c1b4: ldr x8, [x22]
2e5c1b8: mov x1, x8
2e5c1bc: b #0x2e5c1c4 ; 
2e5c1c0: mov x8, xzr
2e5c1c4: ldr w9, [x23]
2e5c1c8: cmp w9, #0xb
2e5c1cc: b.ls #0x2e5cf94
2e5c1d0: adrp x22, #0x51e8000
2e5c1d4: ldr x22, [x22, #0xd0]
2e5c1d8: mov x0, x21
2e5c1dc: str x8, [x0, #0x78]!
2e5c1e0: bl #0xfb12ac ; 
2e5c1e4: ldr x1, [x22]
2e5c1e8: cbz x1, #0x2e5c210
2e5c1ec: ldr x8, [x21]
2e5c1f0: mov x0, x1
2e5c1f4: ldr x8, [x8, #0x40]
2e5c1f8: mov x1, x8
2e5c1fc: bl #0xfb1408 ; 
2e5c200: cbz x0, #0x2e5cf98
2e5c204: ldr x8, [x22]
2e5c208: mov x1, x8
2e5c20c: b #0x2e5c214 ; 
2e5c210: mov x8, xzr
2e5c214: ldr w9, [x23]
2e5c218: cmp w9, #0xc
2e5c21c: b.ls #0x2e5cf94
2e5c220: adrp x22, #0x51ea000
2e5c224: ldr x22, [x22, #0x9f8]
2e5c228: mov x0, x21
2e5c22c: str x8, [x0, #0x80]!
2e5c230: bl #0xfb12ac ; 
2e5c234: ldr x1, [x22]
2e5c238: cbz x1, #0x2e5c260
2e5c23c: ldr x8, [x21]
2e5c240: mov x0, x1
2e5c244: ldr x8, [x8, #0x40]
2e5c248: mov x1, x8
2e5c24c: bl #0xfb1408 ; 
2e5c250: cbz x0, #0x2e5cf98
2e5c254: ldr x8, [x22]
2e5c258: mov x1, x8
2e5c25c: b #0x2e5c264 ; 
2e5c260: mov x8, xzr
2e5c264: ldr w9, [x23]
2e5c268: cmp w9, #0xd
2e5c26c: b.ls #0x2e5cf94
2e5c270: adrp x22, #0x51a7000
2e5c274: ldr x22, [x22, #0xac8]
2e5c278: mov x0, x21
2e5c27c: str x8, [x0, #0x88]!
2e5c280: bl #0xfb12ac ; 
2e5c284: ldr x1, [x22]
2e5c288: cbz x1, #0x2e5c2b0
2e5c28c: ldr x8, [x21]
2e5c290: mov x0, x1
2e5c294: ldr x8, [x8, #0x40]
2e5c298: mov x1, x8
2e5c29c: bl #0xfb1408 ; 
2e5c2a0: cbz x0, #0x2e5cf98
2e5c2a4: ldr x8, [x22]
2e5c2a8: mov x1, x8
2e5c2ac: b #0x2e5c2b4 ; 
2e5c2b0: mov x8, xzr
2e5c2b4: ldr w9, [x23]
2e5c2b8: cmp w9, #0xe
2e5c2bc: b.ls #0x2e5cf94
2e5c2c0: adrp x22, #0x51d5000
2e5c2c4: ldr x22, [x22, #0x9c8]
2e5c2c8: mov x0, x21
2e5c2cc: str x8, [x0, #0x90]!
2e5c2d0: bl #0xfb12ac ; 
2e5c2d4: ldr x1, [x22]
2e5c2d8: cbz x1, #0x2e5c300
2e5c2dc: ldr x8, [x21]
2e5c2e0: mov x0, x1
2e5c2e4: ldr x8, [x8, #0x40]
2e5c2e8: mov x1, x8
2e5c2ec: bl #0xfb1408 ; 
2e5c2f0: cbz x0, #0x2e5cf98
2e5c2f4: ldr x8, [x22]
2e5c2f8: mov x1, x8
2e5c2fc: b #0x2e5c304 ; 
2e5c300: mov x8, xzr
2e5c304: ldr w9, [x23]
2e5c308: cmp w9, #0xf
2e5c30c: b.ls #0x2e5cf94
2e5c310: adrp x22, #0x5196000
2e5c314: ldr x22, [x22, #0xde8]
2e5c318: mov x0, x21
2e5c31c: str x8, [x0, #0x98]!
2e5c320: bl #0xfb12ac ; 
2e5c324: ldr x1, [x22]
2e5c328: cbz x1, #0x2e5c350
2e5c32c: ldr x8, [x21]
2e5c330: mov x0, x1
2e5c334: ldr x8, [x8, #0x40]
2e5c338: mov x1, x8
2e5c33c: bl #0xfb1408 ; 
2e5c340: cbz x0, #0x2e5cf98
2e5c344: ldr x8, [x22]
2e5c348: mov x1, x8
2e5c34c: b #0x2e5c354 ; 
2e5c350: mov x8, xzr
2e5c354: ldr w9, [x23]
2e5c358: cmp w9, #0x10
2e5c35c: b.ls #0x2e5cf94
2e5c360: adrp x22, #0x5233000
2e5c364: ldr x22, [x22, #0x3b0]
2e5c368: mov x0, x21
2e5c36c: str x8, [x0, #0xa0]!
2e5c370: bl #0xfb12ac ; 
2e5c374: ldr x1, [x22]
2e5c378: cbz x1, #0x2e5c3a0
2e5c37c: ldr x8, [x21]
2e5c380: mov x0, x1
2e5c384: ldr x8, [x8, #0x40]
2e5c388: mov x1, x8
2e5c38c: bl #0xfb1408 ; 
2e5c390: cbz x0, #0x2e5cf98
2e5c394: ldr x8, [x22]
2e5c398: mov x1, x8
2e5c39c: b #0x2e5c3a4 ; 
2e5c3a0: mov x8, xzr
2e5c3a4: ldr w9, [x23]
2e5c3a8: cmp w9, #0x11
2e5c3ac: b.ls #0x2e5cf94
2e5c3b0: adrp x22, #0x520e000
2e5c3b4: ldr x22, [x22, #0x368]
2e5c3b8: mov x0, x21
2e5c3bc: str x8, [x0, #0xa8]!
2e5c3c0: bl #0xfb12ac ; 
2e5c3c4: ldr x1, [x22]
2e5c3c8: cbz x1, #0x2e5c3f0
2e5c3cc: ldr x8, [x21]
2e5c3d0: mov x0, x1
2e5c3d4: ldr x8, [x8, #0x40]
2e5c3d8: mov x1, x8
2e5c3dc: bl #0xfb1408 ; 
2e5c3e0: cbz x0, #0x2e5cf98
2e5c3e4: ldr x8, [x22]
2e5c3e8: mov x1, x8
2e5c3ec: b #0x2e5c3f4 ; 
2e5c3f0: mov x8, xzr
2e5c3f4: ldr w9, [x23]
2e5c3f8: cmp w9, #0x12
2e5c3fc: b.ls #0x2e5cf94
2e5c400: adrp x22, #0x51f9000
2e5c404: ldr x22, [x22, #0x290]
2e5c408: mov x0, x21
2e5c40c: str x8, [x0, #0xb0]!
2e5c410: bl #0xfb12ac ; 
2e5c414: ldr x1, [x22]
2e5c418: cbz x1, #0x2e5c440
2e5c41c: ldr x8, [x21]
2e5c420: mov x0, x1
2e5c424: ldr x8, [x8, #0x40]
2e5c428: mov x1, x8
2e5c42c: bl #0xfb1408 ; 
2e5c430: cbz x0, #0x2e5cf98
2e5c434: ldr x8, [x22]
2e5c438: mov x1, x8
2e5c43c: b #0x2e5c444 ; 
2e5c440: mov x8, xzr
2e5c444: ldr w9, [x23]
2e5c448: cmp w9, #0x13
2e5c44c: b.ls #0x2e5cf94
2e5c450: adrp x22, #0x519f000
2e5c454: ldr x22, [x22, #0x488]
2e5c458: mov x0, x21
2e5c45c: str x8, [x0, #0xb8]!
2e5c460: bl #0xfb12ac ; 
2e5c464: ldr x1, [x22]
2e5c468: cbz x1, #0x2e5c490
2e5c46c: ldr x8, [x21]
2e5c470: mov x0, x1
2e5c474: ldr x8, [x8, #0x40]
2e5c478: mov x1, x8
2e5c47c: bl #0xfb1408 ; 
2e5c480: cbz x0, #0x2e5cf98
2e5c484: ldr x8, [x22]
2e5c488: mov x1, x8
2e5c48c: b #0x2e5c494 ; 
2e5c490: mov x8, xzr
2e5c494: ldr w9, [x23]
2e5c498: cmp w9, #0x14
2e5c49c: b.ls #0x2e5cf94
2e5c4a0: adrp x22, #0x51eb000
2e5c4a4: ldr x22, [x22, #0x538]
2e5c4a8: mov x0, x21
2e5c4ac: str x8, [x0, #0xc0]!
2e5c4b0: bl #0xfb12ac ; 
2e5c4b4: ldr x1, [x22]
2e5c4b8: cbz x1, #0x2e5c4e0
2e5c4bc: ldr x8, [x21]
2e5c4c0: mov x0, x1
2e5c4c4: ldr x8, [x8, #0x40]
2e5c4c8: mov x1, x8
2e5c4cc: bl #0xfb1408 ; 
2e5c4d0: cbz x0, #0x2e5cf98
2e5c4d4: ldr x8, [x22]
2e5c4d8: mov x1, x8
2e5c4dc: b #0x2e5c4e4 ; 
2e5c4e0: mov x8, xzr
2e5c4e4: ldr w9, [x23]
2e5c4e8: cmp w9, #0x15
2e5c4ec: b.ls #0x2e5cf94
2e5c4f0: adrp x22, #0x51db000
2e5c4f4: ldr x22, [x22, #0xcc0]
2e5c4f8: mov x0, x21
2e5c4fc: str x8, [x0, #0xc8]!
2e5c500: bl #0xfb12ac ; 
2e5c504: ldr x1, [x22]
2e5c508: cbz x1, #0x2e5c530
2e5c50c: ldr x8, [x21]
2e5c510: mov x0, x1
2e5c514: ldr x8, [x8, #0x40]
2e5c518: mov x1, x8
2e5c51c: bl #0xfb1408 ; 
2e5c520: cbz x0, #0x2e5cf98
2e5c524: ldr x8, [x22]
2e5c528: mov x1, x8
2e5c52c: b #0x2e5c534 ; 
2e5c530: mov x8, xzr
2e5c534: ldr w9, [x23]
2e5c538: cmp w9, #0x16
2e5c53c: b.ls #0x2e5cf94
2e5c540: adrp x22, #0x523d000
2e5c544: ldr x22, [x22, #0xa8]
2e5c548: mov x0, x21
2e5c54c: str x8, [x0, #0xd0]!
2e5c550: bl #0xfb12ac ; 
2e5c554: ldr x1, [x22]
2e5c558: cbz x1, #0x2e5c580
2e5c55c: ldr x8, [x21]
2e5c560: mov x0, x1
2e5c564: ldr x8, [x8, #0x40]
2e5c568: mov x1, x8
2e5c56c: bl #0xfb1408 ; 
2e5c570: cbz x0, #0x2e5cf98
2e5c574: ldr x8, [x22]
2e5c578: mov x1, x8
2e5c57c: b #0x2e5c584 ; 
2e5c580: mov x8, xzr
2e5c584: ldr w9, [x23]
2e5c588: cmp w9, #0x17
2e5c58c: b.ls #0x2e5cf94
2e5c590: mov x0, x21
2e5c594: str x8, [x0, #0xd8]!
2e5c598: bl #0xfb12ac ; 
2e5c59c: mov w0, #1
2e5c5a0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5c5a4: mov x22, x0
2e5c5a8: cbz x0, #0x2e5c5c0
2e5c5ac: ldr x8, [x21]
2e5c5b0: mov x0, x22
2e5c5b4: ldr x1, [x8, #0x40]
2e5c5b8: bl #0xfb1408 ; 
2e5c5bc: cbz x0, #0x2e5cf98
2e5c5c0: ldr w8, [x23]
2e5c5c4: cmp w8, #0x18
2e5c5c8: b.ls #0x2e5cf94
2e5c5cc: adrp x24, #0x5236000
2e5c5d0: ldr x24, [x24, #0xe58]
2e5c5d4: mov x0, x21
2e5c5d8: str x22, [x0, #0xe0]!
2e5c5dc: mov x1, x22
2e5c5e0: bl #0xfb12ac ; 
2e5c5e4: ldr x1, [x24]
2e5c5e8: cbz x1, #0x2e5c610
2e5c5ec: ldr x8, [x21]
2e5c5f0: mov x0, x1
2e5c5f4: ldr x8, [x8, #0x40]
2e5c5f8: mov x1, x8
2e5c5fc: bl #0xfb1408 ; 
2e5c600: cbz x0, #0x2e5cf98
2e5c604: ldr x8, [x24]
2e5c608: mov x1, x8
2e5c60c: b #0x2e5c614 ; 
2e5c610: mov x8, xzr
2e5c614: ldr w9, [x23]
2e5c618: cmp w9, #0x19
2e5c61c: b.ls #0x2e5cf94
2e5c620: adrp x22, #0x51a1000
2e5c624: ldr x22, [x22, #0x728]
2e5c628: mov x0, x21
2e5c62c: str x8, [x0, #0xe8]!
2e5c630: bl #0xfb12ac ; 
2e5c634: ldr x1, [x22]
2e5c638: cbz x1, #0x2e5c660
2e5c63c: ldr x8, [x21]
2e5c640: mov x0, x1
2e5c644: ldr x8, [x8, #0x40]
2e5c648: mov x1, x8
2e5c64c: bl #0xfb1408 ; 
2e5c650: cbz x0, #0x2e5cf98
2e5c654: ldr x8, [x22]
2e5c658: mov x1, x8
2e5c65c: b #0x2e5c664 ; 
2e5c660: mov x8, xzr
2e5c664: ldr w9, [x23]
2e5c668: cmp w9, #0x1a
2e5c66c: b.ls #0x2e5cf94
2e5c670: adrp x22, #0x51b3000
2e5c674: ldr x22, [x22, #0x3c8]
2e5c678: mov x0, x21
2e5c67c: str x8, [x0, #0xf0]!
2e5c680: bl #0xfb12ac ; 
2e5c684: ldr x1, [x22]
2e5c688: cbz x1, #0x2e5c6b0
2e5c68c: ldr x8, [x21]
2e5c690: mov x0, x1
2e5c694: ldr x8, [x8, #0x40]
2e5c698: mov x1, x8
2e5c69c: bl #0xfb1408 ; 
2e5c6a0: cbz x0, #0x2e5cf98
2e5c6a4: ldr x8, [x22]
2e5c6a8: mov x1, x8
2e5c6ac: b #0x2e5c6b4 ; 
2e5c6b0: mov x8, xzr
2e5c6b4: ldr w9, [x23]
2e5c6b8: cmp w9, #0x1b
2e5c6bc: b.ls #0x2e5cf94
2e5c6c0: adrp x22, #0x51b7000
2e5c6c4: ldr x22, [x22, #0x850]
2e5c6c8: mov x0, x21
2e5c6cc: str x8, [x0, #0xf8]!
2e5c6d0: bl #0xfb12ac ; 
2e5c6d4: ldr x1, [x22]
2e5c6d8: cbz x1, #0x2e5c700
2e5c6dc: ldr x8, [x21]
2e5c6e0: mov x0, x1
2e5c6e4: ldr x8, [x8, #0x40]
2e5c6e8: mov x1, x8
2e5c6ec: bl #0xfb1408 ; 
2e5c6f0: cbz x0, #0x2e5cf98
2e5c6f4: ldr x8, [x22]
2e5c6f8: mov x1, x8
2e5c6fc: b #0x2e5c704 ; 
2e5c700: mov x8, xzr
2e5c704: ldr w9, [x23]
2e5c708: cmp w9, #0x1c
2e5c70c: b.ls #0x2e5cf94
2e5c710: adrp x22, #0x5197000
2e5c714: ldr x22, [x22, #0x290]
2e5c718: add x0, x21, #0x100
2e5c71c: str x8, [x21, #0x100]
2e5c720: bl #0xfb12ac ; 
2e5c724: ldr x1, [x22]
2e5c728: cbz x1, #0x2e5c750
2e5c72c: ldr x8, [x21]
2e5c730: mov x0, x1
2e5c734: ldr x8, [x8, #0x40]
2e5c738: mov x1, x8
2e5c73c: bl #0xfb1408 ; 
2e5c740: cbz x0, #0x2e5cf98
2e5c744: ldr x8, [x22]
2e5c748: mov x1, x8
2e5c74c: b #0x2e5c754 ; 
2e5c750: mov x8, xzr
2e5c754: ldr w9, [x23]
2e5c758: cmp w9, #0x1d
2e5c75c: b.ls #0x2e5cf94
2e5c760: add x0, x21, #0x108
2e5c764: str x8, [x21, #0x108]
2e5c768: bl #0xfb12ac ; 
2e5c76c: mov w0, #2
2e5c770: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5c774: mov x22, x0
2e5c778: cbz x0, #0x2e5c790
2e5c77c: ldr x8, [x21]
2e5c780: mov x0, x22
2e5c784: ldr x1, [x8, #0x40]
2e5c788: bl #0xfb1408 ; 
2e5c78c: cbz x0, #0x2e5cf98
2e5c790: ldr w8, [x23]
2e5c794: cmp w8, #0x1e
2e5c798: b.ls #0x2e5cf94
2e5c79c: adrp x24, #0x5201000
2e5c7a0: ldr x24, [x24, #0x930]
2e5c7a4: add x0, x21, #0x110
2e5c7a8: mov x1, x22
2e5c7ac: str x22, [x21, #0x110]
2e5c7b0: bl #0xfb12ac ; 
2e5c7b4: ldr x1, [x24]
2e5c7b8: cbz x1, #0x2e5c7e0
2e5c7bc: ldr x8, [x21]
2e5c7c0: mov x0, x1
2e5c7c4: ldr x8, [x8, #0x40]
2e5c7c8: mov x1, x8
2e5c7cc: bl #0xfb1408 ; 
2e5c7d0: cbz x0, #0x2e5cf98
2e5c7d4: ldr x8, [x24]
2e5c7d8: mov x1, x8
2e5c7dc: b #0x2e5c7e4 ; 
2e5c7e0: mov x8, xzr
2e5c7e4: ldr w9, [x23]
2e5c7e8: cmp w9, #0x1f
2e5c7ec: b.ls #0x2e5cf94
2e5c7f0: adrp x22, #0x51fd000
2e5c7f4: ldr x22, [x22, #0xa28]
2e5c7f8: add x0, x21, #0x118
2e5c7fc: str x8, [x21, #0x118]
2e5c800: bl #0xfb12ac ; 
2e5c804: ldr x1, [x22]
2e5c808: cbz x1, #0x2e5c830
2e5c80c: ldr x8, [x21]
2e5c810: mov x0, x1
2e5c814: ldr x8, [x8, #0x40]
2e5c818: mov x1, x8
2e5c81c: bl #0xfb1408 ; 
2e5c820: cbz x0, #0x2e5cf98
2e5c824: ldr x8, [x22]
2e5c828: mov x1, x8
2e5c82c: b #0x2e5c834 ; 
2e5c830: mov x8, xzr
2e5c834: ldr w9, [x23]
2e5c838: cmp w9, #0x20
2e5c83c: b.ls #0x2e5cf94
2e5c840: adrp x22, #0x5207000
2e5c844: ldr x22, [x22, #0xd18]
2e5c848: add x0, x21, #0x120
2e5c84c: str x8, [x21, #0x120]
2e5c850: bl #0xfb12ac ; 
2e5c854: ldr x1, [x22]
2e5c858: cbz x1, #0x2e5c880
2e5c85c: ldr x8, [x21]
2e5c860: mov x0, x1
2e5c864: ldr x8, [x8, #0x40]
2e5c868: mov x1, x8
2e5c86c: bl #0xfb1408 ; 
2e5c870: cbz x0, #0x2e5cf98
2e5c874: ldr x8, [x22]
2e5c878: mov x1, x8
2e5c87c: b #0x2e5c884 ; 
2e5c880: mov x8, xzr
2e5c884: ldr w9, [x23]
2e5c888: cmp w9, #0x21
2e5c88c: b.ls #0x2e5cf94
2e5c890: adrp x22, #0x523e000
2e5c894: ldr x22, [x22, #0x590]
2e5c898: add x0, x21, #0x128
2e5c89c: str x8, [x21, #0x128]
2e5c8a0: bl #0xfb12ac ; 
2e5c8a4: ldr x1, [x22]
2e5c8a8: cbz x1, #0x2e5c8d0
2e5c8ac: ldr x8, [x21]
2e5c8b0: mov x0, x1
2e5c8b4: ldr x8, [x8, #0x40]
2e5c8b8: mov x1, x8
2e5c8bc: bl #0xfb1408 ; 
2e5c8c0: cbz x0, #0x2e5cf98
2e5c8c4: ldr x8, [x22]
2e5c8c8: mov x1, x8
2e5c8cc: b #0x2e5c8d4 ; 
2e5c8d0: mov x8, xzr
2e5c8d4: ldr w9, [x23]
2e5c8d8: cmp w9, #0x22
2e5c8dc: b.ls #0x2e5cf94
2e5c8e0: adrp x22, #0x5202000
2e5c8e4: ldr x22, [x22, #0x7b0]
2e5c8e8: add x0, x21, #0x130
2e5c8ec: str x8, [x21, #0x130]
2e5c8f0: bl #0xfb12ac ; 
2e5c8f4: ldr x1, [x22]
2e5c8f8: cbz x1, #0x2e5c920
2e5c8fc: ldr x8, [x21]
2e5c900: mov x0, x1
2e5c904: ldr x8, [x8, #0x40]
2e5c908: mov x1, x8
2e5c90c: bl #0xfb1408 ; 
2e5c910: cbz x0, #0x2e5cf98
2e5c914: ldr x8, [x22]
2e5c918: mov x1, x8
2e5c91c: b #0x2e5c924 ; 
2e5c920: mov x8, xzr
2e5c924: ldr w9, [x23]
2e5c928: cmp w9, #0x23
2e5c92c: b.ls #0x2e5cf94
2e5c930: adrp x22, #0x5220000
2e5c934: ldr x22, [x22, #0xf68]
2e5c938: add x0, x21, #0x138
2e5c93c: str x8, [x21, #0x138]
2e5c940: bl #0xfb12ac ; 
2e5c944: ldr x1, [x22]
2e5c948: cbz x1, #0x2e5c970
2e5c94c: ldr x8, [x21]
2e5c950: mov x0, x1
2e5c954: ldr x8, [x8, #0x40]
2e5c958: mov x1, x8
2e5c95c: bl #0xfb1408 ; 
2e5c960: cbz x0, #0x2e5cf98
2e5c964: ldr x8, [x22]
2e5c968: mov x1, x8
2e5c96c: b #0x2e5c974 ; 
2e5c970: mov x8, xzr
2e5c974: ldr w9, [x23]
2e5c978: cmp w9, #0x24
2e5c97c: b.ls #0x2e5cf94
2e5c980: add x0, x21, #0x140
2e5c984: str x8, [x21, #0x140]
2e5c988: bl #0xfb12ac ; 
2e5c98c: mov w0, #3
2e5c990: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5c994: mov x22, x0
2e5c998: cbz x0, #0x2e5c9b0
2e5c99c: ldr x8, [x21]
2e5c9a0: mov x0, x22
2e5c9a4: ldr x1, [x8, #0x40]
2e5c9a8: bl #0xfb1408 ; 
2e5c9ac: cbz x0, #0x2e5cf98
2e5c9b0: ldr w8, [x23]
2e5c9b4: cmp w8, #0x25
2e5c9b8: b.ls #0x2e5cf94
2e5c9bc: add x0, x21, #0x148
2e5c9c0: mov x1, x22
2e5c9c4: str x22, [x21, #0x148]
2e5c9c8: bl #0xfb12ac ; 
2e5c9cc: mov w0, #4
2e5c9d0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5c9d4: mov x22, x0
2e5c9d8: cbz x0, #0x2e5c9f0
2e5c9dc: ldr x8, [x21]
2e5c9e0: mov x0, x22
2e5c9e4: ldr x1, [x8, #0x40]
2e5c9e8: bl #0xfb1408 ; 
2e5c9ec: cbz x0, #0x2e5cf98
2e5c9f0: ldr w8, [x23]
2e5c9f4: cmp w8, #0x26
2e5c9f8: b.ls #0x2e5cf94
2e5c9fc: add x0, x21, #0x150
2e5ca00: mov x1, x22
2e5ca04: str x22, [x21, #0x150]
2e5ca08: bl #0xfb12ac ; 
2e5ca0c: mov w0, #5
2e5ca10: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5ca14: mov x22, x0
2e5ca18: cbz x0, #0x2e5ca30
2e5ca1c: ldr x8, [x21]
2e5ca20: mov x0, x22
2e5ca24: ldr x1, [x8, #0x40]
2e5ca28: bl #0xfb1408 ; 
2e5ca2c: cbz x0, #0x2e5cf98
2e5ca30: ldr w8, [x23]
2e5ca34: cmp w8, #0x27
2e5ca38: b.ls #0x2e5cf94
2e5ca3c: adrp x24, #0x51cf000
2e5ca40: ldr x24, [x24, #0xd10]
2e5ca44: add x0, x21, #0x158
2e5ca48: mov x1, x22
2e5ca4c: str x22, [x21, #0x158]
2e5ca50: bl #0xfb12ac ; 
2e5ca54: ldr x1, [x24]
2e5ca58: cbz x1, #0x2e5ca80
2e5ca5c: ldr x8, [x21]
2e5ca60: mov x0, x1
2e5ca64: ldr x8, [x8, #0x40]
2e5ca68: mov x1, x8
2e5ca6c: bl #0xfb1408 ; 
2e5ca70: cbz x0, #0x2e5cf98
2e5ca74: ldr x8, [x24]
2e5ca78: mov x1, x8
2e5ca7c: b #0x2e5ca84 ; 
2e5ca80: mov x8, xzr
2e5ca84: ldr w9, [x23]
2e5ca88: cmp w9, #0x28
2e5ca8c: b.ls #0x2e5cf94
2e5ca90: add x0, x21, #0x160
2e5ca94: str x8, [x21, #0x160]
2e5ca98: bl #0xfb12ac ; 
2e5ca9c: mov w0, #6
2e5caa0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5caa4: mov x22, x0
2e5caa8: cbz x0, #0x2e5cac0
2e5caac: ldr x8, [x21]
2e5cab0: mov x0, x22
2e5cab4: ldr x1, [x8, #0x40]
2e5cab8: bl #0xfb1408 ; 
2e5cabc: cbz x0, #0x2e5cf98
2e5cac0: ldr w8, [x23]
2e5cac4: cmp w8, #0x29
2e5cac8: b.ls #0x2e5cf94
2e5cacc: adrp x24, #0x521f000
2e5cad0: ldr x24, [x24, #0xd90]
2e5cad4: add x0, x21, #0x168
2e5cad8: mov x1, x22
2e5cadc: str x22, [x21, #0x168]
2e5cae0: bl #0xfb12ac ; 
2e5cae4: ldr x1, [x24]
2e5cae8: cbz x1, #0x2e5cb10
2e5caec: ldr x8, [x21]
2e5caf0: mov x0, x1
2e5caf4: ldr x8, [x8, #0x40]
2e5caf8: mov x1, x8
2e5cafc: bl #0xfb1408 ; 
2e5cb00: cbz x0, #0x2e5cf98
2e5cb04: ldr x8, [x24]
2e5cb08: mov x1, x8
2e5cb0c: b #0x2e5cb14 ; 
2e5cb10: mov x8, xzr
2e5cb14: ldr w9, [x23]
2e5cb18: cmp w9, #0x2a
2e5cb1c: b.ls #0x2e5cf94
2e5cb20: add x0, x21, #0x170
2e5cb24: str x8, [x21, #0x170]
2e5cb28: bl #0xfb12ac ; 
2e5cb2c: mov w0, #7
2e5cb30: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cb34: mov x22, x0
2e5cb38: cbz x0, #0x2e5cb50
2e5cb3c: ldr x8, [x21]
2e5cb40: mov x0, x22
2e5cb44: ldr x1, [x8, #0x40]
2e5cb48: bl #0xfb1408 ; 
2e5cb4c: cbz x0, #0x2e5cf98
2e5cb50: ldr w8, [x23]
2e5cb54: cmp w8, #0x2b
2e5cb58: b.ls #0x2e5cf94
2e5cb5c: add x0, x21, #0x178
2e5cb60: mov x1, x22
2e5cb64: str x22, [x21, #0x178]
2e5cb68: bl #0xfb12ac ; 
2e5cb6c: mov w0, #0xd
2e5cb70: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cb74: mov x22, x0
2e5cb78: cbz x0, #0x2e5cb90
2e5cb7c: ldr x8, [x21]
2e5cb80: mov x0, x22
2e5cb84: ldr x1, [x8, #0x40]
2e5cb88: bl #0xfb1408 ; 
2e5cb8c: cbz x0, #0x2e5cf98
2e5cb90: ldr w8, [x23]
2e5cb94: cmp w8, #0x2c
2e5cb98: b.ls #0x2e5cf94
2e5cb9c: add x0, x21, #0x180
2e5cba0: mov x1, x22
2e5cba4: str x22, [x21, #0x180]
2e5cba8: bl #0xfb12ac ; 
2e5cbac: mov w0, #9
2e5cbb0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cbb4: mov x22, x0
2e5cbb8: cbz x0, #0x2e5cbd0
2e5cbbc: ldr x8, [x21]
2e5cbc0: mov x0, x22
2e5cbc4: ldr x1, [x8, #0x40]
2e5cbc8: bl #0xfb1408 ; 
2e5cbcc: cbz x0, #0x2e5cf98
2e5cbd0: ldr w8, [x23]
2e5cbd4: cmp w8, #0x2d
2e5cbd8: b.ls #0x2e5cf94
2e5cbdc: add x0, x21, #0x188
2e5cbe0: mov x1, x22
2e5cbe4: str x22, [x21, #0x188]
2e5cbe8: bl #0xfb12ac ; 
2e5cbec: mov w0, #0xa
2e5cbf0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cbf4: mov x22, x0
2e5cbf8: cbz x0, #0x2e5cc10
2e5cbfc: ldr x8, [x21]
2e5cc00: mov x0, x22
2e5cc04: ldr x1, [x8, #0x40]
2e5cc08: bl #0xfb1408 ; 
2e5cc0c: cbz x0, #0x2e5cf98
2e5cc10: ldr w8, [x23]
2e5cc14: cmp w8, #0x2e
2e5cc18: b.ls #0x2e5cf94
2e5cc1c: adrp x24, #0x51dd000
2e5cc20: ldr x24, [x24, #0xed8]
2e5cc24: add x0, x21, #0x190
2e5cc28: mov x1, x22
2e5cc2c: str x22, [x21, #0x190]
2e5cc30: bl #0xfb12ac ; 
2e5cc34: ldr x1, [x24]
2e5cc38: cbz x1, #0x2e5cc60
2e5cc3c: ldr x8, [x21]
2e5cc40: mov x0, x1
2e5cc44: ldr x8, [x8, #0x40]
2e5cc48: mov x1, x8
2e5cc4c: bl #0xfb1408 ; 
2e5cc50: cbz x0, #0x2e5cf98
2e5cc54: ldr x8, [x24]
2e5cc58: mov x1, x8
2e5cc5c: b #0x2e5cc64 ; 
2e5cc60: mov x8, xzr
2e5cc64: ldr w9, [x23]
2e5cc68: cmp w9, #0x2f
2e5cc6c: b.ls #0x2e5cf94
2e5cc70: add x0, x21, #0x198
2e5cc74: str x8, [x21, #0x198]
2e5cc78: bl #0xfb12ac ; 
2e5cc7c: mov w0, #0xe
2e5cc80: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cc84: mov x22, x0
2e5cc88: cbz x0, #0x2e5cca0
2e5cc8c: ldr x8, [x21]
2e5cc90: mov x0, x22
2e5cc94: ldr x1, [x8, #0x40]
2e5cc98: bl #0xfb1408 ; 
2e5cc9c: cbz x0, #0x2e5cf98
2e5cca0: ldr w8, [x23]
2e5cca4: cmp w8, #0x30
2e5cca8: b.ls #0x2e5cf94
2e5ccac: add x0, x21, #0x1a0
2e5ccb0: mov x1, x22
2e5ccb4: str x22, [x21, #0x1a0]
2e5ccb8: bl #0xfb12ac ; 
2e5ccbc: mov w0, #0xc
2e5ccc0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5ccc4: mov x22, x0
2e5ccc8: cbz x0, #0x2e5cce0
2e5cccc: ldr x8, [x21]
2e5ccd0: mov x0, x22
2e5ccd4: ldr x1, [x8, #0x40]
2e5ccd8: bl #0xfb1408 ; 
2e5ccdc: cbz x0, #0x2e5cf98
2e5cce0: ldr w8, [x23]
2e5cce4: cmp w8, #0x31
2e5cce8: b.ls #0x2e5cf94
2e5ccec: adrp x24, #0x51ad000
2e5ccf0: ldr x24, [x24, #0x6e0]
2e5ccf4: add x0, x21, #0x1a8
2e5ccf8: mov x1, x22
2e5ccfc: str x22, [x21, #0x1a8]
2e5cd00: bl #0xfb12ac ; 
2e5cd04: ldr x1, [x24]
2e5cd08: cbz x1, #0x2e5cd30
2e5cd0c: ldr x8, [x21]
2e5cd10: mov x0, x1
2e5cd14: ldr x8, [x8, #0x40]
2e5cd18: mov x1, x8
2e5cd1c: bl #0xfb1408 ; 
2e5cd20: cbz x0, #0x2e5cf98
2e5cd24: ldr x8, [x24]
2e5cd28: mov x1, x8
2e5cd2c: b #0x2e5cd34 ; 
2e5cd30: mov x8, xzr
2e5cd34: ldr w9, [x23]
2e5cd38: cmp w9, #0x32
2e5cd3c: b.ls #0x2e5cf94
2e5cd40: add x0, x21, #0x1b0
2e5cd44: str x8, [x21, #0x1b0]
2e5cd48: bl #0xfb12ac ; 
2e5cd4c: mov w0, #0xf
2e5cd50: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cd54: mov x22, x0
2e5cd58: cbz x0, #0x2e5cd70
2e5cd5c: ldr x8, [x21]
2e5cd60: mov x0, x22
2e5cd64: ldr x1, [x8, #0x40]
2e5cd68: bl #0xfb1408 ; 
2e5cd6c: cbz x0, #0x2e5cf98
2e5cd70: ldr w8, [x23]
2e5cd74: cmp w8, #0x33
2e5cd78: b.ls #0x2e5cf94
2e5cd7c: add x0, x21, #0x1b8
2e5cd80: mov x1, x22
2e5cd84: str x22, [x21, #0x1b8]
2e5cd88: bl #0xfb12ac ; 
2e5cd8c: mov w0, #0x10
2e5cd90: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cd94: mov x22, x0
2e5cd98: cbz x0, #0x2e5cdb0
2e5cd9c: ldr x8, [x21]
2e5cda0: mov x0, x22
2e5cda4: ldr x1, [x8, #0x40]
2e5cda8: bl #0xfb1408 ; 
2e5cdac: cbz x0, #0x2e5cf98
2e5cdb0: ldr w8, [x23]
2e5cdb4: cmp w8, #0x34
2e5cdb8: b.ls #0x2e5cf94
2e5cdbc: add x0, x21, #0x1c0
2e5cdc0: mov x1, x22
2e5cdc4: str x22, [x21, #0x1c0]
2e5cdc8: bl #0xfb12ac ; 
2e5cdcc: mov w0, #0x11
2e5cdd0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5cdd4: mov x22, x0
2e5cdd8: cbz x0, #0x2e5cdf0
2e5cddc: ldr x8, [x21]
2e5cde0: mov x0, x22
2e5cde4: ldr x1, [x8, #0x40]
2e5cde8: bl #0xfb1408 ; 
2e5cdec: cbz x0, #0x2e5cf98
2e5cdf0: ldr w8, [x23]
2e5cdf4: cmp w8, #0x35
2e5cdf8: b.ls #0x2e5cf94
2e5cdfc: add x0, x21, #0x1c8
2e5ce00: mov x1, x22
2e5ce04: str x22, [x21, #0x1c8]
2e5ce08: bl #0xfb12ac ; 
2e5ce0c: mov w0, #0x12
2e5ce10: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5ce14: mov x22, x0
2e5ce18: cbz x0, #0x2e5ce30
2e5ce1c: ldr x8, [x21]
2e5ce20: mov x0, x22
2e5ce24: ldr x1, [x8, #0x40]
2e5ce28: bl #0xfb1408 ; 
2e5ce2c: cbz x0, #0x2e5cf98
2e5ce30: ldr w8, [x23]
2e5ce34: cmp w8, #0x36
2e5ce38: b.ls #0x2e5cf94
2e5ce3c: add x0, x21, #0x1d0
2e5ce40: mov x1, x22
2e5ce44: str x22, [x21, #0x1d0]
2e5ce48: bl #0xfb12ac ; 
2e5ce4c: mov w0, #0x13
2e5ce50: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5ce54: mov x22, x0
2e5ce58: cbz x0, #0x2e5ce70
2e5ce5c: ldr x8, [x21]
2e5ce60: mov x0, x22
2e5ce64: ldr x1, [x8, #0x40]
2e5ce68: bl #0xfb1408 ; 
2e5ce6c: cbz x0, #0x2e5cf98
2e5ce70: ldr w8, [x23]
2e5ce74: cmp w8, #0x37
2e5ce78: b.ls #0x2e5cf94
2e5ce7c: add x0, x21, #0x1d8
2e5ce80: mov x1, x22
2e5ce84: str x22, [x21, #0x1d8]
2e5ce88: bl #0xfb12ac ; 
2e5ce8c: mov w0, #0x14
2e5ce90: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5ce94: mov x22, x0
2e5ce98: cbz x0, #0x2e5ceb0
2e5ce9c: ldr x8, [x21]
2e5cea0: mov x0, x22
2e5cea4: ldr x1, [x8, #0x40]
2e5cea8: bl #0xfb1408 ; 
2e5ceac: cbz x0, #0x2e5cf98
2e5ceb0: ldr w8, [x23]
2e5ceb4: cmp w8, #0x38
2e5ceb8: b.ls #0x2e5cf94
2e5cebc: add x0, x21, #0x1e0
2e5cec0: mov x1, x22
2e5cec4: str x22, [x21, #0x1e0]
2e5cec8: bl #0xfb12ac ; 
2e5cecc: mov w0, #0x15
2e5ced0: bl #0x2e5b8f4 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$ToSerializedString
2e5ced4: mov x22, x0
2e5ced8: cbz x0, #0x2e5cef0
2e5cedc: ldr x8, [x21]
2e5cee0: mov x0, x22
2e5cee4: ldr x1, [x8, #0x40]
2e5cee8: bl #0xfb1408 ; 
2e5ceec: cbz x0, #0x2e5cf98
2e5cef0: ldr w8, [x23]
2e5cef4: cmp w8, #0x39
2e5cef8: b.ls #0x2e5cf94
2e5cefc: adrp x23, #0x5213000
2e5cf00: ldr x23, [x23, #0x390]
2e5cf04: add x0, x21, #0x1e8
2e5cf08: mov x1, x22
2e5cf0c: str x22, [x21, #0x1e8]
2e5cf10: bl #0xfb12ac ; 
2e5cf14: mov x0, x19
2e5cf18: str x21, [x0, #0x28]!
2e5cf1c: mov x1, x21
2e5cf20: bl #0xfb12ac ; 
2e5cf24: mov x0, x19
2e5cf28: mov x1, xzr
2e5cf2c: bl #0x22735f4 ; System.Object$$.ctor
2e5cf30: mov x0, x20
2e5cf34: str wzr, [x19, #0x30]
2e5cf38: bl #0x2e5cfa8 ; Royal.Infrastructure.Services.Storage.DbFileHelper$$GetUserDbPath
2e5cf3c: ldr x8, [x23]
2e5cf40: mov x21, x0
2e5cf44: mov x0, x8
2e5cf48: bl #0xfb1418 ; 
2e5cf4c: cbz x0, #0x2e5cfa4
2e5cf50: mov x1, x21
2e5cf54: mov w2, wzr
2e5cf58: mov x3, xzr
2e5cf5c: mov x20, x0
2e5cf60: bl #0x313fee0 ; Plugins.Sqlite.SQLiteConnection$$.ctor
2e5cf64: mov x0, x19
2e5cf68: str x20, [x0, #0x10]!
2e5cf6c: mov x1, x20
2e5cf70: bl #0xfb12ac ; 
2e5cf74: mov w8, #0x3d
2e5cf78: str w8, [x19, #0x18]
2e5cf7c: mov x0, x19
2e5cf80: ldp x19, x30, [sp, #0x30]
2e5cf84: ldp x21, x20, [sp, #0x20]
2e5cf88: ldp x23, x22, [sp, #0x10]
2e5cf8c: ldr x24, [sp], #0x40
2e5cf90: b #0x2e5d07c ; Royal.Infrastructure.Services.Storage.DatabaseService$$CreateUserTables
2e5cf94: bl #0xfb1430 ; 
2e5cf98: bl #0xfb144c ; 
2e5cf9c: mov x1, xzr
2e5cfa0: bl #0xfb13f0 ; 
2e5cfa4: bl #0xfb1428 ; 
