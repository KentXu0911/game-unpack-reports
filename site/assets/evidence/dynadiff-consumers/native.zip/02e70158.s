# Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$GetLong
# Linear metadata span; not complete CFG.
2e70158: str x20, [sp, #-0x20]!
2e7015c: stp x19, x30, [sp, #0x10]
2e70160: mov x19, x1
2e70164: mov x20, x0
2e70168: bl #0x2e6ff3c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$get_DatabaseService
2e7016c: mov x2, x19
2e70170: ldp x19, x30, [sp, #0x10]
2e70174: mov x1, x20
2e70178: ldr x20, [sp], #0x20
2e7017c: b #0x2e60374 ; Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$GetLong
