# Royal.Player.Context.Data.Persistent.UserInventory$$ResetDynamicDifficulty
# Linear metadata span; not complete CFG.
2a0e940: stp x19, x30, [sp, #-0x10]!
2a0e944: mov x19, x0
2a0e948: ldr x0, [x0, #0xb0]
2a0e94c: mov w2, #0x23
2a0e950: mov w3, #0x31
2a0e954: mov w1, wzr
2a0e958: mov x4, xzr
2a0e95c: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e960: mov x1, x0
2a0e964: mov x0, x19
2a0e968: bl #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
2a0e96c: ldr x0, [x19, #0xb0]
2a0e970: mov w2, #0x12
2a0e974: mov w3, #0x22
2a0e978: mov w1, wzr
2a0e97c: mov x4, xzr
2a0e980: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e984: mov x1, x0
2a0e988: mov x0, x19
2a0e98c: bl #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
2a0e990: ldr x0, [x19, #0xb0]
2a0e994: mov w1, #0xa
2a0e998: mov w2, #0xd
2a0e99c: mov w3, #0x11
2a0e9a0: mov x4, xzr
2a0e9a4: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e9a8: mov x1, x0
2a0e9ac: mov x0, x19
2a0e9b0: bl #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
2a0e9b4: mov x0, x19
2a0e9b8: mov w1, wzr
2a0e9bc: ldp x19, x30, [sp], #0x10
2a0e9c0: b #0x2a0e5d8 ; Royal.Player.Context.Data.Persistent.UserInventory$$SetTryCount2
