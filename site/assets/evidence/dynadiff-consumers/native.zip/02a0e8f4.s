# Royal.Player.Context.Data.Persistent.UserInventory$$GetCurrentLevel
# Linear metadata span; not complete CFG.
2a0e8f4: str x30, [sp, #-0x10]!
2a0e8f8: ldr x0, [x0, #0xb0]
2a0e8fc: mov w1, #0x23
2a0e900: mov w2, #0x31
2a0e904: mov x3, xzr
2a0e908: bl #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
2a0e90c: ldr x30, [sp], #0x10
2a0e910: ret 
