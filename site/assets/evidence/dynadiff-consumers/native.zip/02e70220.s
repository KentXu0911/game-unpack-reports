# Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetSynced
# Linear metadata span; not complete CFG.
2e70220: str x20, [sp, #-0x20]!
2e70224: stp x19, x30, [sp, #0x10]
2e70228: mov w19, w1
2e7022c: mov x20, x0
2e70230: bl #0x2e6ff3c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$get_DatabaseService
2e70234: and w2, w19, #1
2e70238: ldp x19, x30, [sp, #0x10]
2e7023c: mov x1, x20
2e70240: ldr x20, [sp], #0x20
2e70244: b #0x2e64af0 ; Royal.Infrastructure.Services.Storage.Tables.KeyValueTable$$SetSynced
