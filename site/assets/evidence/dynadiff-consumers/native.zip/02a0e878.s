# Royal.Player.Context.Data.Persistent.UserInventory$$SetDeltaMove
# Linear metadata span; not complete CFG.
2a0e878: stp x19, x30, [sp, #-0x10]!
2a0e87c: mov x19, x0
2a0e880: ldr x0, [x0, #0xb0]
2a0e884: add w1, w1, #0xa
2a0e888: mov w2, #0xd
2a0e88c: mov w3, #0x11
2a0e890: mov x4, xzr
2a0e894: bl #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
2a0e898: mov x1, x0
2a0e89c: mov x0, x19
2a0e8a0: ldp x19, x30, [sp], #0x10
2a0e8a4: b #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
