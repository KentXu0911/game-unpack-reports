# Royal.Player.Context.Data.Persistent.UserInventory$$ResetKeyValues
# Linear metadata span; not complete CFG.
2a0e9c4: sub sp, sp, #0x30
2a0e9c8: stp x21, x20, [sp, #0x10]
2a0e9cc: stp x19, x30, [sp, #0x20]
2a0e9d0: adrp x21, #0x5581000
2a0e9d4: adrp x20, #0x51b3000
2a0e9d8: ldrb w8, [x21, #0xd53]
2a0e9dc: ldr x20, [x20, #0x340]
2a0e9e0: mov x19, x0
2a0e9e4: tbnz w8, #0, #0x2a0eb58
2a0e9e8: adrp x0, #0x51ee000
2a0e9ec: ldr x0, [x0, #0x160]
2a0e9f0: bl #0xfb1300 ; 
2a0e9f4: adrp x0, #0x51f4000
2a0e9f8: ldr x0, [x0, #0x640]
2a0e9fc: bl #0xfb1300 ; 
2a0ea00: adrp x0, #0x51b6000
2a0ea04: ldr x0, [x0, #0x568]
2a0ea08: bl #0xfb1300 ; 
2a0ea0c: adrp x0, #0x5196000
2a0ea10: ldr x0, [x0, #0xa08]
2a0ea14: bl #0xfb1300 ; 
2a0ea18: adrp x0, #0x5201000
2a0ea1c: ldr x0, [x0, #0x418]
2a0ea20: bl #0xfb1300 ; 
2a0ea24: adrp x0, #0x5220000
2a0ea28: ldr x0, [x0, #0x710]
2a0ea2c: bl #0xfb1300 ; 
2a0ea30: adrp x0, #0x51f1000
2a0ea34: ldr x0, [x0, #0xb20]
2a0ea38: bl #0xfb1300 ; 
2a0ea3c: adrp x0, #0x51e9000
2a0ea40: ldr x0, [x0, #0x680]
2a0ea44: bl #0xfb1300 ; 
2a0ea48: adrp x0, #0x5208000
2a0ea4c: ldr x0, [x0, #0xd20]
2a0ea50: bl #0xfb1300 ; 
2a0ea54: adrp x0, #0x5191000
2a0ea58: ldr x0, [x0, #0xf80]
2a0ea5c: bl #0xfb1300 ; 
2a0ea60: adrp x0, #0x51bb000
2a0ea64: ldr x0, [x0, #0xad8]
2a0ea68: bl #0xfb1300 ; 
2a0ea6c: adrp x0, #0x5231000
2a0ea70: ldr x0, [x0, #0x978]
2a0ea74: bl #0xfb1300 ; 
2a0ea78: adrp x0, #0x5195000
2a0ea7c: ldr x0, [x0, #0x100]
2a0ea80: bl #0xfb1300 ; 
2a0ea84: adrp x0, #0x520f000
2a0ea88: ldr x0, [x0, #0x510]
2a0ea8c: bl #0xfb1300 ; 
2a0ea90: adrp x0, #0x5222000
2a0ea94: ldr x0, [x0, #0x850]
2a0ea98: bl #0xfb1300 ; 
2a0ea9c: adrp x0, #0x51a8000
2a0eaa0: ldr x0, [x0, #0x6a0]
2a0eaa4: bl #0xfb1300 ; 
2a0eaa8: adrp x0, #0x51a2000
2a0eaac: ldr x0, [x0, #0xb68]
2a0eab0: bl #0xfb1300 ; 
2a0eab4: adrp x0, #0x51d0000
2a0eab8: ldr x0, [x0, #0xd90]
2a0eabc: bl #0xfb1300 ; 
2a0eac0: adrp x0, #0x51ec000
2a0eac4: ldr x0, [x0, #0xf28]
2a0eac8: bl #0xfb1300 ; 
2a0eacc: adrp x0, #0x51a6000
2a0ead0: ldr x0, [x0, #0x7a8]
2a0ead4: bl #0xfb1300 ; 
2a0ead8: adrp x0, #0x5227000
2a0eadc: ldr x0, [x0, #0xca0]
2a0eae0: bl #0xfb1300 ; 
2a0eae4: adrp x0, #0x51c6000
2a0eae8: ldr x0, [x0, #0x4c8]
2a0eaec: bl #0xfb1300 ; 
2a0eaf0: adrp x0, #0x51ba000
2a0eaf4: ldr x0, [x0, #0x4b8]
2a0eaf8: bl #0xfb1300 ; 
2a0eafc: adrp x0, #0x518e000
2a0eb00: ldr x0, [x0, #0x4f0]
2a0eb04: bl #0xfb1300 ; 
2a0eb08: adrp x0, #0x51d9000
2a0eb0c: ldr x0, [x0, #0x468]
2a0eb10: bl #0xfb1300 ; 
2a0eb14: adrp x0, #0x51a7000
2a0eb18: ldr x0, [x0, #0xfe8]
2a0eb1c: bl #0xfb1300 ; 
2a0eb20: adrp x0, #0x51ac000
2a0eb24: ldr x0, [x0, #0x138]
2a0eb28: bl #0xfb1300 ; 
2a0eb2c: adrp x0, #0x523e000
2a0eb30: ldr x0, [x0, #0x9d8]
2a0eb34: bl #0xfb1300 ; 
2a0eb38: adrp x0, #0x51c5000
2a0eb3c: ldr x0, [x0, #0x528]
2a0eb40: bl #0xfb1300 ; 
2a0eb44: adrp x0, #0x51b3000
2a0eb48: ldr x0, [x0, #0x340]
2a0eb4c: bl #0xfb1300 ; 
2a0eb50: mov w8, #1
2a0eb54: strb w8, [x21, #0xd53]
2a0eb58: adrp x21, #0x5222000
2a0eb5c: ldr x21, [x21, #0x850]
2a0eb60: mov x0, sp
2a0eb64: mov x1, xzr
2a0eb68: stp xzr, xzr, [sp]
2a0eb6c: bl #0x2a016a4 ; Royal.Player.Context.Data.Persistent.TeamOfferProgress$$.ctor
2a0eb70: ldp x1, x2, [sp]
2a0eb74: mov w3, #1
2a0eb78: mov x0, x19
2a0eb7c: bl #0x2a0e3dc ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateLocalTeamOfferProgress
2a0eb80: mov x0, x19
2a0eb84: bl #0x2a0e940 ; Royal.Player.Context.Data.Persistent.UserInventory$$ResetDynamicDifficulty
2a0eb88: ldr x0, [x20]
2a0eb8c: ldr w8, [x0, #0xe0]
2a0eb90: cbnz w8, #0x2a0eb98
2a0eb94: bl #0xfb1404 ; 
2a0eb98: ldr x1, [x21]
2a0eb9c: mov w0, #0x17
2a0eba0: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0eba4: cbz x0, #0x2a0f190
2a0eba8: adrp x20, #0x51a8000
2a0ebac: ldr x20, [x20, #0x6a0]
2a0ebb0: mov x1, xzr
2a0ebb4: bl #0x1db7d10 ; Royal.Player.Context.Units.KingNightmareManager$$ResetNightmareEvent
2a0ebb8: mov x0, xzr
2a0ebbc: mov x1, xzr
2a0ebc0: bl #0x21aa6a4 ; Royal.Player.Context.Data.Persistent.KeyValueAbTestIds$$UpdateData
2a0ebc4: mov x0, x19
2a0ebc8: mov x1, xzr
2a0ebcc: bl #0x2a0f194 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDialogs
2a0ebd0: ldr x1, [x20]
2a0ebd4: mov w0, #0x22
2a0ebd8: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ebdc: cbz x0, #0x2a0f190
2a0ebe0: mov x1, xzr
2a0ebe4: mov x2, xzr
2a0ebe8: bl #0x1dc6c8c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateProgress1
2a0ebec: ldr x1, [x20]
2a0ebf0: mov w0, #0x22
2a0ebf4: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ebf8: cbz x0, #0x2a0f190
2a0ebfc: adrp x19, #0x5201000
2a0ec00: ldr x19, [x19, #0x418]
2a0ec04: mov x1, xzr
2a0ec08: mov x2, xzr
2a0ec0c: bl #0x1dc6dd4 ; Royal.Player.Context.Units.LavaQuestManager$$UpdateProgress2
2a0ec10: ldr x1, [x19]
2a0ec14: mov w0, #0x39
2a0ec18: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ec1c: cbz x0, #0x2a0f190
2a0ec20: adrp x19, #0x5191000
2a0ec24: ldr x19, [x19, #0xf80]
2a0ec28: mov w2, #1
2a0ec2c: mov x1, xzr
2a0ec30: mov x3, xzr
2a0ec34: bl #0x244d7bc ; Royal.Player.Context.Units.BalloonRiseManager$$UpdateProgress
2a0ec38: ldr x1, [x19]
2a0ec3c: mov w0, #0x29
2a0ec40: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ec44: cbz x0, #0x2a0f190
2a0ec48: mov x1, xzr
2a0ec4c: mov x2, xzr
2a0ec50: bl #0x21c5e38 ; Royal.Player.Context.Units.DragonNestManager$$UpdateProgress1
2a0ec54: ldr x1, [x19]
2a0ec58: mov w0, #0x29
2a0ec5c: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ec60: cbz x0, #0x2a0f190
2a0ec64: adrp x19, #0x5231000
2a0ec68: ldr x19, [x19, #0x978]
2a0ec6c: mov x1, xzr
2a0ec70: mov x2, xzr
2a0ec74: bl #0x21c5f80 ; Royal.Player.Context.Units.DragonNestManager$$UpdateProgress2
2a0ec78: ldr x1, [x19]
2a0ec7c: mov w0, #0x23
2a0ec80: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ec84: cbz x0, #0x2a0f190
2a0ec88: mov x1, xzr
2a0ec8c: mov x2, xzr
2a0ec90: bl #0x1c6b618 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress1
2a0ec94: ldr x1, [x19]
2a0ec98: mov w0, #0x23
2a0ec9c: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0eca0: cbz x0, #0x2a0f190
2a0eca4: mov x1, xzr
2a0eca8: mov x2, xzr
2a0ecac: bl #0x1c6b760 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress2
2a0ecb0: ldr x1, [x19]
2a0ecb4: mov w0, #0x23
2a0ecb8: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ecbc: cbz x0, #0x2a0f190
2a0ecc0: adrp x19, #0x51a2000
2a0ecc4: ldr x19, [x19, #0xb68]
2a0ecc8: mov w2, #1
2a0eccc: mov x1, xzr
2a0ecd0: mov x3, xzr
2a0ecd4: bl #0x1c6b8a8 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress3
2a0ecd8: ldr x1, [x19]
2a0ecdc: mov w0, #0x26
2a0ece0: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ece4: cbz x0, #0x2a0f190
2a0ece8: adrp x19, #0x51f4000
2a0ecec: ldr x19, [x19, #0x640]
2a0ecf0: adrp x20, #0x5227000
2a0ecf4: mov w2, #1
2a0ecf8: mov x3, xzr
2a0ecfc: ldr x8, [x19]
2a0ed00: ldr x8, [x8, #0xb8]
2a0ed04: ldr x1, [x8]
2a0ed08: ldr x20, [x20, #0xca0]
2a0ed0c: bl #0x1f25370 ; Royal.Player.Context.Units.MagicCauldronManager$$UpdateProgress
2a0ed10: ldr x1, [x20]
2a0ed14: mov w0, #0x3b
2a0ed18: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ed1c: cbz x0, #0x2a0f190
2a0ed20: ldr x8, [x19]
2a0ed24: adrp x20, #0x523e000
2a0ed28: mov w2, #1
2a0ed2c: mov x3, xzr
2a0ed30: ldr x8, [x8, #0xb8]
2a0ed34: ldr x1, [x8]
2a0ed38: ldr x20, [x20, #0x9d8]
2a0ed3c: bl #0x318e65c ; Royal.Player.Context.Units.OceanOdysseyManager$$UpdateProgress
2a0ed40: ldr x1, [x20]
2a0ed44: mov w0, #0x3a
2a0ed48: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ed4c: cbz x0, #0x2a0f190
2a0ed50: ldr x8, [x19]
2a0ed54: adrp x20, #0x5196000
2a0ed58: mov x2, xzr
2a0ed5c: ldr x8, [x8, #0xb8]
2a0ed60: ldr x1, [x8]
2a0ed64: ldr x20, [x20, #0xa08]
2a0ed68: bl #0x2075770 ; Royal.Player.Context.Units.TrainJourneyManager$$UpdateProgress
2a0ed6c: ldr x1, [x20]
2a0ed70: mov w0, #0x2d
2a0ed74: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ed78: cbz x0, #0x2a0f190
2a0ed7c: adrp x20, #0x51d9000
2a0ed80: ldr x20, [x20, #0x468]
2a0ed84: mov x1, xzr
2a0ed88: mov x2, xzr
2a0ed8c: bl #0x24468b4 ; Royal.Player.Context.Units.ArcheryArenaManager$$UpdateProgress
2a0ed90: ldr x1, [x20]
2a0ed94: mov w0, #0x30
2a0ed98: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ed9c: cbz x0, #0x2a0f190
2a0eda0: ldr x8, [x19]
2a0eda4: adrp x20, #0x51ac000
2a0eda8: mov x2, xzr
2a0edac: ldr x8, [x8, #0xb8]
2a0edb0: ldr x1, [x8]
2a0edb4: ldr x20, [x20, #0x138]
2a0edb8: bl #0x1c7a074 ; Royal.Player.Context.Units.SeasonalCardCollectionManager$$UpdateProgress
2a0edbc: ldr x1, [x20]
2a0edc0: mov w0, #0x31
2a0edc4: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0edc8: cbz x0, #0x2a0f190
2a0edcc: mov x1, xzr
2a0edd0: mov x2, xzr
2a0edd4: bl #0x2066fe0 ; Royal.Player.Context.Units.TeamTournamentManager$$UpdateProgressValue1
2a0edd8: ldr x1, [x20]
2a0eddc: mov w0, #0x31
2a0ede0: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ede4: cbz x0, #0x2a0f190
2a0ede8: adrp x20, #0x51bb000
2a0edec: ldr x20, [x20, #0xad8]
2a0edf0: mov x1, xzr
2a0edf4: mov x2, xzr
2a0edf8: bl #0x2067128 ; Royal.Player.Context.Units.TeamTournamentManager$$UpdateProgressValue2
2a0edfc: ldr x1, [x20]
2a0ee00: mov w0, #0x2e
2a0ee04: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ee08: cbz x0, #0x2a0f190
2a0ee0c: mov x1, xzr
2a0ee10: mov x2, xzr
2a0ee14: bl #0x23350c4 ; Royal.Player.Context.Units.DukesFortuneManager$$UpdateProgress1
2a0ee18: ldr x1, [x20]
2a0ee1c: mov w0, #0x2e
2a0ee20: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ee24: cbz x0, #0x2a0f190
2a0ee28: adrp x20, #0x51a6000
2a0ee2c: ldr x20, [x20, #0x7a8]
2a0ee30: mov x1, xzr
2a0ee34: mov x2, xzr
2a0ee38: bl #0x233520c ; Royal.Player.Context.Units.DukesFortuneManager$$UpdateProgress2
2a0ee3c: ldr x1, [x20]
2a0ee40: mov w0, #0x35
2a0ee44: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ee48: cbz x0, #0x2a0f190
2a0ee4c: ldr x8, [x19]
2a0ee50: adrp x20, #0x51ec000
2a0ee54: mov w2, #1
2a0ee58: mov x3, xzr
2a0ee5c: ldr x8, [x8, #0xb8]
2a0ee60: ldr x1, [x8]
2a0ee64: ldr x20, [x20, #0xf28]
2a0ee68: bl #0x1f333a0 ; Royal.Player.Context.Units.MissionPursuitManager$$UpdateProgress
2a0ee6c: ldr x1, [x20]
2a0ee70: mov w0, #0x36
2a0ee74: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ee78: cbz x0, #0x2a0f190
2a0ee7c: ldr x8, [x19]
2a0ee80: adrp x20, #0x51f1000
2a0ee84: mov w2, #1
2a0ee88: mov x3, xzr
2a0ee8c: ldr x8, [x8, #0xb8]
2a0ee90: ldr x1, [x8]
2a0ee94: ldr x20, [x20, #0xb20]
2a0ee98: bl #0x1f2f04c ; Royal.Player.Context.Units.MissionControlManager$$UpdateProgress
2a0ee9c: ldr x1, [x20]
2a0eea0: mov w0, #0x3d
2a0eea4: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0eea8: cbz x0, #0x2a0f190
2a0eeac: adrp x20, #0x51e9000
2a0eeb0: ldr x20, [x20, #0x680]
2a0eeb4: mov x1, xzr
2a0eeb8: mov x2, xzr
2a0eebc: bl #0x21b9efc ; Royal.Player.Context.Units.CoinShopManager$$UpdateProgress
2a0eec0: ldr x1, [x20]
2a0eec4: mov w0, #0x3e
2a0eec8: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0eecc: cbz x0, #0x2a0f190
2a0eed0: adrp x20, #0x51c6000
2a0eed4: ldr x20, [x20, #0x4c8]
2a0eed8: mov x1, xzr
2a0eedc: mov x2, xzr
2a0eee0: bl #0x21bf008 ; Royal.Player.Context.Units.DailyLightningRushManager$$UpdateProgress
2a0eee4: ldr x1, [x20]
2a0eee8: mov w0, #0x40
2a0eeec: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0eef0: cbz x0, #0x2a0f190
2a0eef4: ldr x8, [x19]
2a0eef8: adrp x20, #0x51b6000
2a0eefc: mov w2, #1
2a0ef00: mov x3, xzr
2a0ef04: ldr x8, [x8, #0xb8]
2a0ef08: ldr x1, [x8]
2a0ef0c: ldr x20, [x20, #0x568]
2a0ef10: bl #0x32e2f38 ; Royal.Player.Context.Units.PuzzleBreakManager$$UpdateProgress
2a0ef14: ldr x1, [x20]
2a0ef18: mov w0, #0x44
2a0ef1c: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ef20: cbz x0, #0x2a0f190
2a0ef24: ldr x8, [x19]
2a0ef28: adrp x20, #0x520f000
2a0ef2c: mov w2, #1
2a0ef30: mov x3, xzr
2a0ef34: ldr x8, [x8, #0xb8]
2a0ef38: ldr x1, [x8]
2a0ef3c: ldr x20, [x20, #0x510]
2a0ef40: bl #0x2444714 ; Royal.Player.Context.Units.AncientAdventureManager$$UpdateProgress
2a0ef44: ldr x1, [x20]
2a0ef48: mov w0, #0x46
2a0ef4c: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ef50: cbz x0, #0x2a0f190
2a0ef54: adrp x20, #0x51ba000
2a0ef58: ldr x20, [x20, #0x4b8]
2a0ef5c: mov w2, #1
2a0ef60: mov x1, xzr
2a0ef64: mov x3, xzr
2a0ef68: bl #0x1c74dc4 ; Royal.Player.Context.Units.JourneyOfferManager$$UpdateProgress
2a0ef6c: ldr x1, [x20]
2a0ef70: mov w0, #0x48
2a0ef74: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ef78: cbz x0, #0x2a0f190
2a0ef7c: adrp x20, #0x51d0000
2a0ef80: ldr x20, [x20, #0xd90]
2a0ef84: mov x1, xzr
2a0ef88: mov x2, xzr
2a0ef8c: bl #0x32ebcbc ; Royal.Player.Context.Units.RobotRivalsManager$$UpdateProgress
2a0ef90: ldr x1, [x20]
2a0ef94: mov w0, #0x49
2a0ef98: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0ef9c: cbz x0, #0x2a0f190
2a0efa0: ldr x8, [x19]
2a0efa4: adrp x20, #0x5220000
2a0efa8: mov w2, #1
2a0efac: mov x3, xzr
2a0efb0: ldr x8, [x8, #0xb8]
2a0efb4: ldr x1, [x8]
2a0efb8: ldr x20, [x20, #0x710]
2a0efbc: bl #0x1f2ac94 ; Royal.Player.Context.Units.MergeSmithManager$$UpdateProgress
2a0efc0: ldr x1, [x20]
2a0efc4: mov w0, #0x4a
2a0efc8: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0efcc: cbz x0, #0x2a0f190
2a0efd0: adrp x20, #0x518e000
2a0efd4: ldr x20, [x20, #0x4f0]
2a0efd8: mov w2, #1
2a0efdc: mov x1, xzr
2a0efe0: mov x3, xzr
2a0efe4: bl #0x21b54bc ; Royal.Player.Context.Units.ClashOfChampionsManager$$UpdateProgressOnRefresh
2a0efe8: ldr x1, [x20]
2a0efec: mov w0, #0x4d
2a0eff0: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0eff4: cbz x0, #0x2a0f190
2a0eff8: ldr x8, [x19]
2a0effc: adrp x20, #0x51c5000
2a0f000: mov w2, #1
2a0f004: mov x3, xzr
2a0f008: ldr x8, [x8, #0xb8]
2a0f00c: ldr x1, [x8]
2a0f010: ldr x20, [x20, #0x528]
2a0f014: bl #0x32f8788 ; Royal.Player.Context.Units.RoyalWorldCupManager$$UpdateProgress
2a0f018: ldr x1, [x20]
2a0f01c: mov w0, #0x24
2a0f020: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0f024: cbz x0, #0x2a0f190
2a0f028: ldr x8, [x19]
2a0f02c: adrp x20, #0x51a7000
2a0f030: mov x2, xzr
2a0f034: ldr x8, [x8, #0xb8]
2a0f038: ldr x1, [x8]
2a0f03c: ldr x20, [x20, #0xfe8]
2a0f040: bl #0x1f0c67c ; Royal.Player.Context.Units.UserProfileManager$$UpdateWorldCupProfileSkinProgress
2a0f044: ldr x1, [x20]
2a0f048: mov w0, #0x50
2a0f04c: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0f050: cbz x0, #0x2a0f190
2a0f054: ldr x8, [x19]
2a0f058: adrp x20, #0x5208000
2a0f05c: mov w2, #1
2a0f060: mov x3, xzr
2a0f064: ldr x8, [x8, #0xb8]
2a0f068: ldr x1, [x8]
2a0f06c: ldr x20, [x20, #0xd20]
2a0f070: bl #0x1c86e4c ; Royal.Player.Context.Units.ShortExpeditionEventManager$$UpdateProgress
2a0f074: ldr x1, [x20]
2a0f078: mov w0, #0x52
2a0f07c: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0f080: cbz x0, #0x2a0f190
2a0f084: ldr x8, [x19]
2a0f088: adrp x20, #0x5195000
2a0f08c: mov w2, #1
2a0f090: mov x3, xzr
2a0f094: ldr x8, [x8, #0xb8]
2a0f098: ldr x1, [x8]
2a0f09c: ldr x20, [x20, #0x100]
2a0f0a0: bl #0x21c3640 ; Royal.Player.Context.Units.DailyRewardsManager$$UpdateProgress
2a0f0a4: ldr x1, [x20]
2a0f0a8: mov w0, #0x54
2a0f0ac: bl #0x2856364 ; Royal.Player.Context.UserContext$$Get<object>
2a0f0b0: cbz x0, #0x2a0f190
2a0f0b4: ldr x8, [x19]
2a0f0b8: mov w2, #1
2a0f0bc: mov x3, xzr
2a0f0c0: mov w20, #1
2a0f0c4: ldr x8, [x8, #0xb8]
2a0f0c8: ldr x1, [x8]
2a0f0cc: bl #0x1c713e0 ; Royal.Player.Context.Units.InviteFriendsManager$$UpdateProgress
2a0f0d0: mov x0, xzr
2a0f0d4: mov x1, xzr
2a0f0d8: bl #0x1265d58 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue1FromBackend
2a0f0dc: mov x0, xzr
2a0f0e0: mov x1, xzr
2a0f0e4: bl #0x1265f14 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue2FromBackend
2a0f0e8: mov x0, xzr
2a0f0ec: mov x1, xzr
2a0f0f0: bl #0x12660d0 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue3FromBackend
2a0f0f4: mov x0, xzr
2a0f0f8: mov x1, xzr
2a0f0fc: bl #0x1f1ba20 ; Royal.Player.Context.Units.LiveOpsCommonKeyValueHandler$$UpdateCommonUseDataFromBackend
2a0f100: adrp x21, #0x5576000
2a0f104: ldrb w8, [x21, #0xf2b]
2a0f108: cbnz w8, #0x2a0f11c
2a0f10c: adrp x0, #0x5208000
2a0f110: ldr x0, [x0, #0x380]
2a0f114: bl #0xfb1300 ; 
2a0f118: strb w20, [x21, #0xf2b]
2a0f11c: adrp x8, #0x5208000
2a0f120: ldr x8, [x8, #0x380]
2a0f124: ldr x8, [x8]
2a0f128: ldr x8, [x8, #0xb8]
2a0f12c: ldr x8, [x8]
2a0f130: cbz x8, #0x2a0f190
2a0f134: ldr x0, [x8, #0x20]
2a0f138: cbz x0, #0x2a0f190
2a0f13c: ldr x8, [x19]
2a0f140: adrp x20, #0x51ee000
2a0f144: ldr x8, [x8, #0xb8]
2a0f148: ldr x1, [x8]
2a0f14c: ldr x20, [x20, #0x160]
2a0f150: bl #0x2a0f304 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateUnlimitedInGameBoosterInventory
2a0f154: ldr x0, [x20]
2a0f158: ldr w8, [x0, #0xe0]
2a0f15c: cbnz w8, #0x2a0f164
2a0f160: bl #0xfb1404 ; 
2a0f164: mov x0, xzr
2a0f168: bl #0x3d52e88 ; Royal.Scenes.Start.Context.Units.Ads.AdManager$$get_Current
2a0f16c: cbz x0, #0x2a0f190
2a0f170: ldr x8, [x19]
2a0f174: ldp x19, x30, [sp, #0x20]
2a0f178: ldp x21, x20, [sp, #0x10]
2a0f17c: mov x2, xzr
2a0f180: ldr x8, [x8, #0xb8]
2a0f184: ldr x1, [x8]
2a0f188: add sp, sp, #0x30
2a0f18c: b #0x3d56a44 ; Royal.Scenes.Start.Context.Units.Ads.AdManager$$UpdateProgress
2a0f190: bl #0xfb1428 ; 
