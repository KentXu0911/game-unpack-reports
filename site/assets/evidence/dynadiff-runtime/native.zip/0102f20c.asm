0x102f20c: mov x13, x19
0x102f210: mov x21, x0
0x102f214: b #0x102f4a0
0x102f218: add x19, x19, #8
0x102f21c: cmp x23, x19
0x102f220: prfm pldl1strm, [x24]
0x102f224: b.hi #0x102f3e4
0x102f228: mov x8, x23
0x102f22c: ldr x25, [x8], #0x80
0x102f230: cmp x25, x28
0x102f234: prfm pldl1strm, [x8]
0x102f238: b.lo #0x102f2f4
0x102f23c: cmp x25, x27
0x102f240: b.hs #0x102f2f4
0x102f244: ubfx x8, x25, #0xc, #3
0x102f248: add x1, x22, x8, lsl #4
0x102f24c: prfm pldl1strm, [x25]
0x102f250: ldr x8, [x1]
0x102f254: cmp x8, x25, lsr #12
0x102f258: b.ne #0x102f304
0x102f25c: ldr x0, [x1, #8]
0x102f260: ldr x9, [x0, #0x30]
0x102f264: ubfx x8, x25, #4, #8
0x102f268: and x10, x25, #0xf
0x102f26c: ldrh w9, [x9, x8, lsl #1]
0x102f270: orr x11, x10, x9
0x102f274: cbnz x11, #0x102f324
0x102f278: mov x20, x25
0x102f27c: lsr x9, x8, #3
0x102f280: and x9, x9, #0x1ffffffffffffff8
0x102f284: add x9, x0, x9
0x102f288: ldr x10, [x9, #0x40]!
