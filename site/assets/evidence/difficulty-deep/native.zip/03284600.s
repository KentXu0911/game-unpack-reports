# Royal.Infrastructure.Utils.Math.BitwiseOperations$$ClampByBits
# Linear span to next metadata entry; not a complete CFG.
03284600: 08008012 mov      w8, #-1
03284604: 0821c11a lsl      w8, w8, w1
03284608: e903282a mvn      w9, w8
0328460c: 3f01006b cmp      w9, w0
03284610: 00a0885a csinv    w0, w0, w8, ge
03284614: c0035fd6 ret      
