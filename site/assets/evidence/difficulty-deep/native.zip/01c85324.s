# Royal.Player.Context.Units.SemiDynamicDifficulty$$SetLevelNumber
# Linear span to next metadata entry; not a complete CFG.
01c85324: c0035fd6 ret      
