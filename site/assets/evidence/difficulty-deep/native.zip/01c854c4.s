# Royal.Player.Context.Units.SemiDynamicDifficulty$$SetAdminMode
# Linear span to next metadata entry; not a complete CFG.
01c854c4: c0035fd6 ret      
