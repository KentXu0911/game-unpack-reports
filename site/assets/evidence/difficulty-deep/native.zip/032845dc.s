# Royal.Infrastructure.Utils.Math.BitwiseOperations$$GetMaxValueForIndexes
# Linear span to next metadata entry; not a complete CFG.
032845dc: 2800006b subs     w8, w1, w0
032845e0: 6a000054 b.ge     #0x32845ec
032845e4: e0031faa mov      x0, xzr
032845e8: c0035fd6 ret      
032845ec: 08050011 add      w8, w8, #1
032845f0: 09008092 mov      x9, #-1
032845f4: 2821c89a lsl      x8, x9, x8
032845f8: e00328aa mvn      x0, x8
032845fc: c0035fd6 ret      
