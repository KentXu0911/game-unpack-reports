# Royal.Player.Context.Data.User$$get_Skill
# Linear span to next metadata entry; not a complete CFG.
0268b474: fe0f1ff8 str      x30, [sp, #-0x10]!
0268b478: 001040f9 ldr      x0, [x0, #0x20]
0268b47c: 800000b4 cbz      x0, #0x268b48c
0268b480: e1031faa mov      x1, xzr
0268b484: fe0741f8 ldr      x30, [sp], #0x10
0268b488: fd090e14 b        #0x2a0dc7c ; Royal.Player.Context.Data.Persistent.UserInventory$$GetSkill
0268b48c: e797a497 bl       #0xfb1428
