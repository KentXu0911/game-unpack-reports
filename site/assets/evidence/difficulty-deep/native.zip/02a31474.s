# Royal.Scenes.Game.Levels.Units.LevelRandomManager$$DifficultyNext
# Linear span to next metadata entry; not a complete CFG.
02a31474: 01000014 b        #0x2a31478 ; Royal.Scenes.Game.Levels.Units.LevelRandomManager$$GetDifficultyNext
