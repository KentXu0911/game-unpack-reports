# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetGroupMove
# Linear span to next metadata entry; not a complete CFG.
01c854b8: e0031f2a mov      w0, wzr
01c854bc: c0035fd6 ret      
