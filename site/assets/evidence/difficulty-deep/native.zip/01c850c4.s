# Royal.Player.Context.Units.SemiDynamicDifficulty$$IncrementTryCount
# Linear span to next metadata entry; not a complete CFG.
01c850c4: f553bea9 stp      x21, x20, [sp, #-0x20]!
01c850c8: f37b01a9 stp      x19, x30, [sp, #0x10]
01c850cc: 32000094 bl       #0x1c85194 ; Royal.Player.Context.Units.SemiDynamicDifficulty$$get_NotApplicableForSkill
01c850d0: a0050037 tbnz     w0, #0, #0x1c85184
01c850d4: 94c701b0 adrp     x20, #0x5576000
01c850d8: 88ae7c39 ldrb     w8, [x20, #0xf2b]
01c850dc: c8000035 cbnz     w8, #0x1c850f4
01c850e0: 00ac01f0 adrp     x0, #0x5208000
01c850e4: 00c041f9 ldr      x0, [x0, #0x380]
01c850e8: 86b0cc97 bl       #0xfb1300
01c850ec: 28008052 mov      w8, #1
01c850f0: 88ae3c39 strb     w8, [x20, #0xf2b]
01c850f4: 15ac01f0 adrp     x21, #0x5208000
01c850f8: b5c241f9 ldr      x21, [x21, #0x380]
01c850fc: a80240f9 ldr      x8, [x21]
01c85100: 085d40f9 ldr      x8, [x8, #0xb8]
01c85104: 080140f9 ldr      x8, [x8]
01c85108: 480400b4 cbz      x8, #0x1c85190
01c8510c: 091d40f9 ldr      x9, [x8, #0x38]
01c85110: 090400b4 cbz      x9, #0x1c85190
01c85114: 290d40f9 ldr      x9, [x9, #0x18]
01c85118: c90300b4 cbz      x9, #0x1c85190
01c8511c: 291540b9 ldr      w9, [x9, #0x14]
01c85120: 3f910171 cmp      w9, #0x64
01c85124: 0c030054 b.gt     #0x1c85184
01c85128: 001140f9 ldr      x0, [x8, #0x20]
01c8512c: 200300b4 cbz      x0, #0x1c85190
01c85130: e1031faa mov      x1, xzr
01c85134: bb223694 bl       #0x2a0dc20 ; Royal.Player.Context.Data.Persistent.UserInventory$$GetTryCount
01c85138: 88ae7c39 ldrb     w8, [x20, #0xf2b]
01c8513c: f303002a mov      w19, w0
01c85140: c8000035 cbnz     w8, #0x1c85158
01c85144: 00ac01f0 adrp     x0, #0x5208000
01c85148: 00c041f9 ldr      x0, [x0, #0x380]
01c8514c: 6db0cc97 bl       #0xfb1300
01c85150: 28008052 mov      w8, #1
01c85154: 88ae3c39 strb     w8, [x20, #0xf2b]
01c85158: a80240f9 ldr      x8, [x21]
01c8515c: 085d40f9 ldr      x8, [x8, #0xb8]
01c85160: 080140f9 ldr      x8, [x8]
01c85164: 680100b4 cbz      x8, #0x1c85190
01c85168: 001140f9 ldr      x0, [x8, #0x20]
01c8516c: 200100b4 cbz      x0, #0x1c85190
01c85170: 61060011 add      w1, w19, #1
01c85174: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c85178: e2031faa mov      x2, xzr
01c8517c: f553c2a8 ldp      x21, x20, [sp], #0x20
01c85180: b0223614 b        #0x2a0dc40 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateTryCount
01c85184: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c85188: f553c2a8 ldp      x21, x20, [sp], #0x20
01c8518c: c0035fd6 ret      
01c85190: a6b0cc97 bl       #0xfb1428
