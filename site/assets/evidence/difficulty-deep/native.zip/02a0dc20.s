# Royal.Player.Context.Data.Persistent.UserInventory$$GetTryCount
# Linear span to next metadata entry; not a complete CFG.
02a0dc20: fe0f1ff8 str      x30, [sp, #-0x10]!
02a0dc24: 001840f9 ldr      x0, [x0, #0x30]
02a0dc28: c1068052 mov      w1, #0x36
02a0dc2c: 82078052 mov      w2, #0x3c
02a0dc30: e3031faa mov      x3, xzr
02a0dc34: e1d92194 bl       #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
02a0dc38: fe0741f8 ldr      x30, [sp], #0x10
02a0dc3c: c0035fd6 ret      
