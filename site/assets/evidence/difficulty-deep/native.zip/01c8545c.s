# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetTryCount
# Linear span to next metadata entry; not a complete CFG.
01c8545c: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
01c85460: 93c701b0 adrp     x19, #0x5576000
01c85464: 68ae7c39 ldrb     w8, [x19, #0xf2b]
01c85468: c8000035 cbnz     w8, #0x1c85480
01c8546c: 00ac01f0 adrp     x0, #0x5208000
01c85470: 00c041f9 ldr      x0, [x0, #0x380]
01c85474: a3afcc97 bl       #0xfb1300
01c85478: 28008052 mov      w8, #1
01c8547c: 68ae3c39 strb     w8, [x19, #0xf2b]
01c85480: 08ac01f0 adrp     x8, #0x5208000
01c85484: 08c141f9 ldr      x8, [x8, #0x380]
01c85488: 080140f9 ldr      x8, [x8]
01c8548c: 085d40f9 ldr      x8, [x8, #0xb8]
01c85490: 080140f9 ldr      x8, [x8]
01c85494: c80000b4 cbz      x8, #0x1c854ac
01c85498: 001140f9 ldr      x0, [x8, #0x20]
01c8549c: 800000b4 cbz      x0, #0x1c854ac
01c854a0: e1031faa mov      x1, xzr
01c854a4: f37bc1a8 ldp      x19, x30, [sp], #0x10
01c854a8: de213614 b        #0x2a0dc20 ; Royal.Player.Context.Data.Persistent.UserInventory$$GetTryCount
01c854ac: dfafcc97 bl       #0xfb1428
