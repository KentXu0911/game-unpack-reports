# Royal.Player.Context.Data.Persistent.UserInventory$$GetCurrentLevel
# Linear span to next metadata entry; not a complete CFG.
02a0e8f4: fe0f1ff8 str      x30, [sp, #-0x10]!
02a0e8f8: 005840f9 ldr      x0, [x0, #0xb0]
02a0e8fc: 61048052 mov      w1, #0x23
02a0e900: 22068052 mov      w2, #0x31
02a0e904: e3031faa mov      x3, xzr
02a0e908: acd62194 bl       #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
02a0e90c: fe0741f8 ldr      x30, [sp], #0x10
02a0e910: c0035fd6 ret      
