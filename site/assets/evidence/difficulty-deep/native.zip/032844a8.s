# Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
# Linear span to next metadata entry; not a complete CFG.
032844a8: f80f1cf8 str      x24, [sp, #-0x40]!
032844ac: f75b01a9 stp      x23, x22, [sp, #0x10]
032844b0: f55302a9 stp      x21, x20, [sp, #0x20]
032844b4: f37b03a9 stp      x19, x30, [sp, #0x30]
032844b8: 171801d0 adrp     x23, #0x5586000
032844bc: f8fb0090 adrp     x24, #0x5200000
032844c0: e87e4039 ldrb     w8, [x23, #0x1f]
032844c4: 188f46f9 ldr      x24, [x24, #0xd18]
032844c8: f603032a mov      w22, w3
032844cc: f303022a mov      w19, w2
032844d0: f503012a mov      w21, w1
032844d4: f40300aa mov      x20, x0
032844d8: c8000037 tbnz     w8, #0, #0x32844f0
032844dc: e0fb0090 adrp     x0, #0x5200000
032844e0: 008c46f9 ldr      x0, [x0, #0xd18]
032844e4: 87b37497 bl       #0xfb1300
032844e8: 28008052 mov      w8, #1
032844ec: e87e0039 strb     w8, [x23, #0x1f]
032844f0: 000340f9 ldr      x0, [x24]
032844f4: 08e040b9 ldr      w8, [x0, #0xe0]
032844f8: 48000035 cbnz     w8, #0x3284500
032844fc: c2b37497 bl       #0xfb1404
03284500: c1060011 add      w1, w22, #1
03284504: e0078052 mov      w0, #0x3f
03284508: e2031faa mov      x2, xzr
0328450c: 0252cc97 bl       #0x2598d14 ; System.Math$$Min
03284510: 08008092 mov      x8, #-1
03284514: 0a21d39a lsl      x10, x8, x19
03284518: 0821c09a lsl      x8, x8, x0
0328451c: a97e4093 sxtw     x9, w21
03284520: 08012aaa orn      x8, x8, x10
03284524: 2921d39a lsl      x9, x9, x19
03284528: 0801148a and      x8, x8, x20
0328452c: f37b43a9 ldp      x19, x30, [sp, #0x30]
03284530: f55342a9 ldp      x21, x20, [sp, #0x20]
03284534: f75b41a9 ldp      x23, x22, [sp, #0x10]
03284538: 000109aa orr      x0, x8, x9
0328453c: f80744f8 ldr      x24, [sp], #0x40
03284540: c0035fd6 ret      
