# Royal.Infrastructure.Utils.Math.BitwiseOperations$$IsBitSet
# Linear span to next metadata entry; not a complete CFG.
03283b3c: 28008052 mov      w8, #1
03283b40: 0821c19a lsl      x8, x8, x1
03283b44: 1f0100ea tst      x8, x0
03283b48: e0079f1a cset     w0, ne
03283b4c: c0035fd6 ret      
