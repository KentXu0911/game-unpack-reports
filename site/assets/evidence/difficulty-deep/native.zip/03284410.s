# Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateInt
# Linear span to next metadata entry; not a complete CFG.
03284410: f80f1cf8 str      x24, [sp, #-0x40]!
03284414: f75b01a9 stp      x23, x22, [sp, #0x10]
03284418: f55302a9 stp      x21, x20, [sp, #0x20]
0328441c: f37b03a9 stp      x19, x30, [sp, #0x30]
03284420: 171801d0 adrp     x23, #0x5586000
03284424: f8fb0090 adrp     x24, #0x5200000
03284428: e87a4039 ldrb     w8, [x23, #0x1e]
0328442c: 188f46f9 ldr      x24, [x24, #0xd18]
03284430: f603032a mov      w22, w3
03284434: f303022a mov      w19, w2
03284438: f503012a mov      w21, w1
0328443c: f403002a mov      w20, w0
03284440: c8000037 tbnz     w8, #0, #0x3284458
03284444: e0fb0090 adrp     x0, #0x5200000
03284448: 008c46f9 ldr      x0, [x0, #0xd18]
0328444c: adb37497 bl       #0xfb1300
03284450: 28008052 mov      w8, #1
03284454: e87a0039 strb     w8, [x23, #0x1e]
03284458: 000340f9 ldr      x0, [x24]
0328445c: 08e040b9 ldr      w8, [x0, #0xe0]
03284460: 48000035 cbnz     w8, #0x3284468
03284464: e8b37497 bl       #0xfb1404
03284468: c1060011 add      w1, w22, #1
0328446c: e0038052 mov      w0, #0x1f
03284470: e2031faa mov      x2, xzr
03284474: 2852cc97 bl       #0x2598d14 ; System.Math$$Min
03284478: 08008012 mov      w8, #-1
0328447c: 0921d31a lsl      w9, w8, w19
03284480: 0821c01a lsl      w8, w8, w0
03284484: 0801292a orn      w8, w8, w9
03284488: a922d31a lsl      w9, w21, w19
0328448c: 0801140a and      w8, w8, w20
03284490: f37b43a9 ldp      x19, x30, [sp, #0x30]
03284494: f55342a9 ldp      x21, x20, [sp, #0x20]
03284498: f75b41a9 ldp      x23, x22, [sp, #0x10]
0328449c: 0001092a orr      w0, w8, w9
032844a0: f80744f8 ldr      x24, [sp], #0x40
032844a4: c0035fd6 ret      
