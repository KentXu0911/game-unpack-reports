# Royal.Player.Context.Units.SemiDynamicDifficulty$$.ctor
# Linear span to next metadata entry; not a complete CFG.
01c854c8: e1031faa mov      x1, xzr
01c854cc: 4ab81714 b        #0x22735f4 ; System.Object$$.ctor
