# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnLevelSuccess
# Linear span to next metadata entry; not a complete CFG.
01c85328: 67ffff17 b        #0x1c850c4 ; Royal.Player.Context.Units.SemiDynamicDifficulty$$IncrementTryCount
