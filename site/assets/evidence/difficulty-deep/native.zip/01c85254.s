# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnEgoAccepted
# Linear span to next metadata entry; not a complete CFG.
01c85254: c0035fd6 ret      
