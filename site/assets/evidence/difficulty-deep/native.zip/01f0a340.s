# Royal.Player.Context.Units.UserManager$$ProcessKeyValueResponse
# Linear span to next metadata entry; not a complete CFG.
01f0a340: ff0305d1 sub      sp, sp, #0x140
01f0a344: fc6f0ea9 stp      x28, x27, [sp, #0xe0]
01f0a348: fa670fa9 stp      x26, x25, [sp, #0xf0]
01f0a34c: f85f10a9 stp      x24, x23, [sp, #0x100]
01f0a350: f65711a9 stp      x22, x21, [sp, #0x110]
01f0a354: f44f12a9 stp      x20, x19, [sp, #0x120]
01f0a358: fd7b13a9 stp      x29, x30, [sp, #0x130]
01f0a35c: 94b301d0 adrp     x20, #0x557c000
01f0a360: 88ca5c39 ldrb     w8, [x20, #0x732]
01f0a364: fa0300aa mov      x26, x0
01f0a368: e10b0da9 stp      x1, x2, [sp, #0xd0]
01f0a36c: 28100037 tbnz     w8, #0, #0x1f0a570
01f0a370: e09601f0 adrp     x0, #0x51e9000
01f0a374: 006847f9 ldr      x0, [x0, #0xed0]
01f0a378: e29bc297 bl       #0xfb1300
01f0a37c: c09501b0 adrp     x0, #0x51c3000
01f0a380: 003847f9 ldr      x0, [x0, #0xe70]
01f0a384: df9bc297 bl       #0xfb1300
01f0a388: a09701f0 adrp     x0, #0x5201000
01f0a38c: 008842f9 ldr      x0, [x0, #0x510]
01f0a390: dc9bc297 bl       #0xfb1300
01f0a394: 40970190 adrp     x0, #0x51f2000
01f0a398: 00b045f9 ldr      x0, [x0, #0xb60]
01f0a39c: d99bc297 bl       #0xfb1300
01f0a3a0: 009601f0 adrp     x0, #0x51cd000
01f0a3a4: 00e040f9 ldr      x0, [x0, #0x1c0]
01f0a3a8: d69bc297 bl       #0xfb1300
01f0a3ac: 409901b0 adrp     x0, #0x5233000
01f0a3b0: 00d841f9 ldr      x0, [x0, #0x3b0]
01f0a3b4: d39bc297 bl       #0xfb1300
01f0a3b8: 00970190 adrp     x0, #0x51ea000
01f0a3bc: 00fc44f9 ldr      x0, [x0, #0x9f8]
01f0a3c0: d09bc297 bl       #0xfb1300
01f0a3c4: 409601f0 adrp     x0, #0x51d5000
01f0a3c8: 007042f9 ldr      x0, [x0, #0x4e0]
01f0a3cc: cd9bc297 bl       #0xfb1300
01f0a3d0: a09401f0 adrp     x0, #0x51a1000
01f0a3d4: 009443f9 ldr      x0, [x0, #0x728]
01f0a3d8: ca9bc297 bl       #0xfb1300
01f0a3dc: 009501f0 adrp     x0, #0x51ad000
01f0a3e0: 007043f9 ldr      x0, [x0, #0x6e0]
01f0a3e4: c79bc297 bl       #0xfb1300
01f0a3e8: 809601f0 adrp     x0, #0x51dd000
01f0a3ec: 006c47f9 ldr      x0, [x0, #0xed8]
01f0a3f0: c49bc297 bl       #0xfb1300
01f0a3f4: e09701b0 adrp     x0, #0x5207000
01f0a3f8: 008c46f9 ldr      x0, [x0, #0xd18]
01f0a3fc: c19bc297 bl       #0xfb1300
01f0a400: 609501b0 adrp     x0, #0x51b7000
01f0a404: 002844f9 ldr      x0, [x0, #0x850]
01f0a408: be9bc297 bl       #0xfb1300
01f0a40c: 609401b0 adrp     x0, #0x5197000
01f0a410: 004841f9 ldr      x0, [x0, #0x290]
01f0a414: bb9bc297 bl       #0xfb1300
01f0a418: 20980190 adrp     x0, #0x520e000
01f0a41c: 00b441f9 ldr      x0, [x0, #0x368]
01f0a420: b89bc297 bl       #0xfb1300
01f0a424: 809601b0 adrp     x0, #0x51db000
01f0a428: 006046f9 ldr      x0, [x0, #0xcc0]
01f0a42c: b59bc297 bl       #0xfb1300
01f0a430: a09701b0 adrp     x0, #0x51ff000
01f0a434: 000440f9 ldr      x0, [x0, #8]
01f0a438: b29bc297 bl       #0xfb1300
01f0a43c: a09801b0 adrp     x0, #0x521f000
01f0a440: 00c846f9 ldr      x0, [x0, #0xd90]
01f0a444: af9bc297 bl       #0xfb1300
01f0a448: a0950190 adrp     x0, #0x51be000
01f0a44c: 00a846f9 ldr      x0, [x0, #0xd50]
01f0a450: ac9bc297 bl       #0xfb1300
01f0a454: a09401b0 adrp     x0, #0x519f000
01f0a458: 004442f9 ldr      x0, [x0, #0x488]
01f0a45c: a99bc297 bl       #0xfb1300
01f0a460: 409501b0 adrp     x0, #0x51b3000
01f0a464: 00e441f9 ldr      x0, [x0, #0x3c8]
01f0a468: a69bc297 bl       #0xfb1300
01f0a46c: 209601b0 adrp     x0, #0x51cf000
01f0a470: 008846f9 ldr      x0, [x0, #0xd10]
01f0a474: a39bc297 bl       #0xfb1300
01f0a478: c0970190 adrp     x0, #0x5202000
01f0a47c: 00d843f9 ldr      x0, [x0, #0x7b0]
01f0a480: a09bc297 bl       #0xfb1300
01f0a484: a0990190 adrp     x0, #0x523e000
01f0a488: 00c842f9 ldr      x0, [x0, #0x590]
01f0a48c: 9d9bc297 bl       #0xfb1300
01f0a490: 609901f0 adrp     x0, #0x5239000
01f0a494: 002840f9 ldr      x0, [x0, #0x50]
01f0a498: 9a9bc297 bl       #0xfb1300
01f0a49c: 609701f0 adrp     x0, #0x51f9000
01f0a4a0: 004841f9 ldr      x0, [x0, #0x290]
01f0a4a4: 979bc297 bl       #0xfb1300
01f0a4a8: e09401b0 adrp     x0, #0x51a7000
01f0a4ac: 006445f9 ldr      x0, [x0, #0xac8]
01f0a4b0: 949bc297 bl       #0xfb1300
01f0a4b4: 809501f0 adrp     x0, #0x51bd000
01f0a4b8: 008044f9 ldr      x0, [x0, #0x900]
01f0a4bc: 919bc297 bl       #0xfb1300
01f0a4c0: 60940190 adrp     x0, #0x5196000
01f0a4c4: 00f446f9 ldr      x0, [x0, #0xde8]
01f0a4c8: 8e9bc297 bl       #0xfb1300
01f0a4cc: 209801d0 adrp     x0, #0x5210000
01f0a4d0: 00c445f9 ldr      x0, [x0, #0xb88]
01f0a4d4: 8b9bc297 bl       #0xfb1300
01f0a4d8: c0960190 adrp     x0, #0x51e2000
01f0a4dc: 009c46f9 ldr      x0, [x0, #0xd38]
01f0a4e0: 889bc297 bl       #0xfb1300
01f0a4e4: 009701b0 adrp     x0, #0x51eb000
01f0a4e8: 009c42f9 ldr      x0, [x0, #0x538]
01f0a4ec: 859bc297 bl       #0xfb1300
01f0a4f0: 809701f0 adrp     x0, #0x51fd000
01f0a4f4: 001445f9 ldr      x0, [x0, #0xa28]
01f0a4f8: 829bc297 bl       #0xfb1300
01f0a4fc: a09701f0 adrp     x0, #0x5201000
01f0a500: 009844f9 ldr      x0, [x0, #0x930]
01f0a504: 7f9bc297 bl       #0xfb1300
01f0a508: 609801f0 adrp     x0, #0x5219000
01f0a50c: 006040f9 ldr      x0, [x0, #0xc0]
01f0a510: 7c9bc297 bl       #0xfb1300
01f0a514: a09801d0 adrp     x0, #0x5220000
01f0a518: 00b447f9 ldr      x0, [x0, #0xf68]
01f0a51c: 799bc297 bl       #0xfb1300
01f0a520: 60990190 adrp     x0, #0x5236000
01f0a524: 006844f9 ldr      x0, [x0, #0x8d0]
01f0a528: 769bc297 bl       #0xfb1300
01f0a52c: 60990190 adrp     x0, #0x5236000
01f0a530: 002c47f9 ldr      x0, [x0, #0xe58]
01f0a534: 739bc297 bl       #0xfb1300
01f0a538: 409601f0 adrp     x0, #0x51d5000
01f0a53c: 00e444f9 ldr      x0, [x0, #0x9c8]
01f0a540: 709bc297 bl       #0xfb1300
01f0a544: e09601d0 adrp     x0, #0x51e8000
01f0a548: 006840f9 ldr      x0, [x0, #0xd0]
01f0a54c: 6d9bc297 bl       #0xfb1300
01f0a550: 809901f0 adrp     x0, #0x523d000
01f0a554: 005440f9 ldr      x0, [x0, #0xa8]
01f0a558: 6a9bc297 bl       #0xfb1300
01f0a55c: 609501f0 adrp     x0, #0x51b9000
01f0a560: 00fc43f9 ldr      x0, [x0, #0x7f8]
01f0a564: 679bc297 bl       #0xfb1300
01f0a568: 28008052 mov      w8, #1
01f0a56c: 88ca1c39 strb     w8, [x20, #0x732]
01f0a570: e0430391 add      x0, sp, #0xd0
01f0a574: e1031faa mov      x1, xzr
01f0a578: ff7f0ca9 stp      xzr, xzr, [sp, #0xc0]
01f0a57c: ffff0aa9 stp      xzr, xzr, [sp, #0xa8]
01f0a580: ffff09a9 stp      xzr, xzr, [sp, #0x98]
01f0a584: ffff08a9 stp      xzr, xzr, [sp, #0x88]
01f0a588: ff4300f9 str      xzr, [sp, #0x80]
01f0a58c: ffff06a9 stp      xzr, xzr, [sp, #0x68]
01f0a590: ff3300f9 str      xzr, [sp, #0x60]
01f0a594: 4e2e4e94 bl       #0x3295ecc ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_KeyValueListLength
01f0a598: 1f040071 cmp      w0, #1
01f0a59c: aba60054 b.lt     #0x1f0ba70
01f0a5a0: f59601d0 adrp     x21, #0x51e8000
01f0a5a4: b39801d0 adrp     x19, #0x5220000
01f0a5a8: 9b9501f0 adrp     x27, #0x51bd000
01f0a5ac: dd970190 adrp     x29, #0x5202000
01f0a5b0: 779401b0 adrp     x23, #0x5197000
01f0a5b4: 789501b0 adrp     x24, #0x51b7000
01f0a5b8: b56a40f9 ldr      x21, [x21, #0xd0]
01f0a5bc: 73b647f9 ldr      x19, [x19, #0xf68]
01f0a5c0: 7b8344f9 ldr      x27, [x27, #0x900]
01f0a5c4: bddb43f9 ldr      x29, [x29, #0x7b0]
01f0a5c8: f74a41f9 ldr      x23, [x23, #0x290]
01f0a5cc: 182b44f9 ldr      x24, [x24, #0x850]
01f0a5d0: 79ec9452 mov      w25, #0xa763
01f0a5d4: dc229f52 mov      w28, #0xf916
01f0a5d8: f4031f2a mov      w20, wzr
01f0a5dc: 19fba972 movk     w25, #0x4fd8, lsl #16
01f0a5e0: 9c55a572 movk     w28, #0x2aac, lsl #16
01f0a5e4: e8030191 add      x8, sp, #0x40
01f0a5e8: e0430391 add      x0, sp, #0xd0
01f0a5ec: e103142a mov      w1, w20
01f0a5f0: e2031faa mov      x2, xzr
01f0a5f4: 002e4e94 bl       #0x3295df4 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$KeyValueList
01f0a5f8: c99501b0 adrp     x9, #0x51c3000
01f0a5fc: e013c03d ldr      q0, [sp, #0x40]
01f0a600: e82b40f9 ldr      x8, [sp, #0x50]
01f0a604: 293947f9 ldr      x9, [x9, #0xe70]
01f0a608: e0830291 add      x0, sp, #0xa0
01f0a60c: e02b803d str      q0, [sp, #0xa0]
01f0a610: e85b00f9 str      x8, [sp, #0xb0]
01f0a614: 210140f9 ldr      x1, [x9]
01f0a618: 5c542294 bl       #0x279f788 ; System.Nullable<KeyValue>$$get_Value
01f0a61c: e0070ca9 stp      x0, x1, [sp, #0xc0]
01f0a620: e0030391 add      x0, sp, #0xc0
01f0a624: e1031faa mov      x1, xzr
01f0a628: b8a32394 bl       #0x27f3508 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Key
01f0a62c: e1031faa mov      x1, xzr
01f0a630: f60300aa mov      x22, x0
01f0a634: 9cb20f94 bl       #0x22f70a4 ; <PrivateImplementationDetails>$$ComputeStringHash
01f0a638: 1f00196b cmp      w0, w25
01f0a63c: 48060054 b.hi     #0x1f0a704
01f0a640: 1f001c6b cmp      w0, w28
01f0a644: 480c0054 b.hi     #0x1f0a7cc
01f0a648: e8208b52 mov      w8, #0x5907
01f0a64c: 08fba272 movk     w8, #0x17d8, lsl #16
01f0a650: 1f00086b cmp      w0, w8
01f0a654: a89701f0 adrp     x8, #0x5201000
01f0a658: 089944f9 ldr      x8, [x8, #0x930]
01f0a65c: 48170054 b.hi     #0x1f0a944
01f0a660: c95a9852 mov      w9, #0xc2d6
01f0a664: 2911a172 movk     w9, #0x889, lsl #16
01f0a668: 1f00096b cmp      w0, w9
01f0a66c: 682a0054 b.hi     #0x1f0abb8
01f0a670: 69289852 mov      w9, #0xc143
01f0a674: 29f1a072 movk     w9, #0x789, lsl #16
01f0a678: 1f00096b cmp      w0, w9
01f0a67c: c04b0054 b.eq     #0x1f0aff4
01f0a680: c85a9852 mov      w8, #0xc2d6
01f0a684: 2811a172 movk     w8, #0x889, lsl #16
01f0a688: 1f00086b cmp      w0, w8
01f0a68c: 419c0054 b.ne     #0x1f0ba14
01f0a690: 889701f0 adrp     x8, #0x51fd000
01f0a694: 081545f9 ldr      x8, [x8, #0xa28]
01f0a698: e00316aa mov      x0, x22
01f0a69c: e2031faa mov      x2, xzr
01f0a6a0: 010140f9 ldr      x1, [x8]
01f0a6a4: 44eff797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0a6a8: 609b0036 tbz      w0, #0, #0x1f0ba14
01f0a6ac: e0030391 add      x0, sp, #0xc0
01f0a6b0: e1031faa mov      x1, xzr
01f0a6b4: c5a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a6b8: 889701f0 adrp     x8, #0x51fd000
01f0a6bc: 081545f9 ldr      x8, [x8, #0xa28]
01f0a6c0: e10300aa mov      x1, x0
01f0a6c4: e2031faa mov      x2, xzr
01f0a6c8: 080140f9 ldr      x8, [x8]
01f0a6cc: e00308aa mov      x0, x8
01f0a6d0: 97963d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0a6d4: 565f40f9 ldr      x22, [x26, #0xb8]
01f0a6d8: e0030391 add      x0, sp, #0xc0
01f0a6dc: e1031faa mov      x1, xzr
01f0a6e0: baa32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a6e4: d6a900b4 cbz      x22, #0x1f0bc1c
01f0a6e8: e10300aa mov      x1, x0
01f0a6ec: e00316aa mov      x0, x22
01f0a6f0: e2031faa mov      x2, xzr
01f0a6f4: 8d720594 bl       #0x2067128 ; Royal.Player.Context.Units.TeamTournamentManager$$UpdateProgressValue2
01f0a6f8: 889701f0 adrp     x8, #0x51fd000
01f0a6fc: 081545f9 ldr      x8, [x8, #0xa28]
01f0a700: c3040014 b        #0x1f0ba0c
01f0a704: 48008c52 mov      w8, #0x6002
01f0a708: a894b272 movk     w8, #0x94a5, lsl #16
01f0a70c: 1f00086b cmp      w0, w8
01f0a710: 480c0054 b.hi     #0x1f0a898
01f0a714: a8b29a52 mov      w8, #0xd595
01f0a718: c8e5b072 movk     w8, #0x872e, lsl #16
01f0a71c: 1f00086b cmp      w0, w8
01f0a720: 28160054 b.hi     #0x1f0a9e4
01f0a724: 085f9152 mov      w8, #0x8af8
01f0a728: 680caf72 movk     w8, #0x7863, lsl #16
01f0a72c: 1f00086b cmp      w0, w8
01f0a730: 28270054 b.hi     #0x1f0ac14
01f0a734: 08458052 mov      w8, #0x228
01f0a738: 2897ab72 movk     w8, #0x5cb9, lsl #16
01f0a73c: 1f00086b cmp      w0, w8
01f0a740: 004a0054 b.eq     #0x1f0b080
01f0a744: 085f9152 mov      w8, #0x8af8
01f0a748: 680caf72 movk     w8, #0x7863, lsl #16
01f0a74c: 1f00086b cmp      w0, w8
01f0a750: 21960054 b.ne     #0x1f0ba14
01f0a754: 889601f0 adrp     x8, #0x51dd000
01f0a758: 086d47f9 ldr      x8, [x8, #0xed8]
01f0a75c: e00316aa mov      x0, x22
01f0a760: e2031faa mov      x2, xzr
01f0a764: 010140f9 ldr      x1, [x8]
01f0a768: 13eff797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0a76c: 40950036 tbz      w0, #0, #0x1f0ba14
01f0a770: e0030391 add      x0, sp, #0xc0
01f0a774: e1031faa mov      x1, xzr
01f0a778: 94a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a77c: 889601f0 adrp     x8, #0x51dd000
01f0a780: 086d47f9 ldr      x8, [x8, #0xed8]
01f0a784: e10300aa mov      x1, x0
01f0a788: e2031faa mov      x2, xzr
01f0a78c: 080140f9 ldr      x8, [x8]
01f0a790: e00308aa mov      x0, x8
01f0a794: 66963d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0a798: 569740f9 ldr      x22, [x26, #0x128]
01f0a79c: e0030391 add      x0, sp, #0xc0
01f0a7a0: e1031faa mov      x1, xzr
01f0a7a4: 89a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a7a8: b6a300b4 cbz      x22, #0x1f0bc1c
01f0a7ac: e10300aa mov      x1, x0
01f0a7b0: e00316aa mov      x0, x22
01f0a7b4: e2031f2a mov      w2, wzr
01f0a7b8: e3031faa mov      x3, xzr
01f0a7bc: 82a9f597 bl       #0x1c74dc4 ; Royal.Player.Context.Units.JourneyOfferManager$$UpdateProgress
01f0a7c0: 889601f0 adrp     x8, #0x51dd000
01f0a7c4: 086d47f9 ldr      x8, [x8, #0xed8]
01f0a7c8: 91040014 b        #0x1f0ba0c
01f0a7cc: 481c9c52 mov      w8, #0xe0e2
01f0a7d0: 2819a872 movk     w8, #0x40c9, lsl #16
01f0a7d4: 1f00086b cmp      w0, w8
01f0a7d8: 68150054 b.hi     #0x1f0aa84
01f0a7dc: e8b38f52 mov      w8, #0x7d9f
01f0a7e0: e893a672 movk     w8, #0x349f, lsl #16
01f0a7e4: 1f00086b cmp      w0, w8
01f0a7e8: a8990190 adrp     x8, #0x523e000
01f0a7ec: 08c942f9 ldr      x8, [x8, #0x590]
01f0a7f0: 48260054 b.hi     #0x1f0acb8
01f0a7f4: 290b9b52 mov      w9, #0xd859
01f0a7f8: a95ba672 movk     w9, #0x32dd, lsl #16
01f0a7fc: 1f00096b cmp      w0, w9
01f0a800: c0470054 b.eq     #0x1f0b0f8
01f0a804: e8b38f52 mov      w8, #0x7d9f
01f0a808: e893a672 movk     w8, #0x349f, lsl #16
01f0a80c: 1f00086b cmp      w0, w8
01f0a810: 21900054 b.ne     #0x1f0ba14
01f0a814: 08970190 adrp     x8, #0x51ea000
01f0a818: 08fd44f9 ldr      x8, [x8, #0x9f8]
01f0a81c: e00316aa mov      x0, x22
01f0a820: e2031faa mov      x2, xzr
01f0a824: 010140f9 ldr      x1, [x8]
01f0a828: e3eef797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0a82c: 408f0036 tbz      w0, #0, #0x1f0ba14
01f0a830: e0030391 add      x0, sp, #0xc0
01f0a834: e1031faa mov      x1, xzr
01f0a838: 64a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a83c: 08970190 adrp     x8, #0x51ea000
01f0a840: 08fd44f9 ldr      x8, [x8, #0x9f8]
01f0a844: e10300aa mov      x1, x0
01f0a848: e2031faa mov      x2, xzr
01f0a84c: 080140f9 ldr      x8, [x8]
01f0a850: e00308aa mov      x0, x8
01f0a854: 36963d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0a858: 564340f9 ldr      x22, [x26, #0x80]
01f0a85c: e0030391 add      x0, sp, #0xc0
01f0a860: e1031faa mov      x1, xzr
01f0a864: 59a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a868: b69d00b4 cbz      x22, #0x1f0bc1c
01f0a86c: e10300aa mov      x1, x0
01f0a870: e00316aa mov      x0, x22
01f0a874: e2031faa mov      x2, xzr
01f0a878: 05f1fa97 bl       #0x1dc6c8c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateProgress1
01f0a87c: 404340f9 ldr      x0, [x26, #0x80]
01f0a880: e09c00b4 cbz      x0, #0x1f0bc1c
01f0a884: e1031faa mov      x1, xzr
01f0a888: a5f1fa97 bl       #0x1dc6f1c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateLocalData
01f0a88c: 08970190 adrp     x8, #0x51ea000
01f0a890: 08fd44f9 ldr      x8, [x8, #0x9f8]
01f0a894: 5e040014 b        #0x1f0ba0c
01f0a898: 88339b52 mov      w8, #0xd99c
01f0a89c: a8bebc72 movk     w8, #0xe5f5, lsl #16
01f0a8a0: 1f00086b cmp      w0, w8
01f0a8a4: 489501b0 adrp     x8, #0x51b3000
01f0a8a8: 08e541f9 ldr      x8, [x8, #0x3c8]
01f0a8ac: e8130054 b.hi     #0x1f0ab28
01f0a8b0: 497e8952 mov      w9, #0x4bf2
01f0a8b4: 8941b372 movk     w9, #0x9a0c, lsl #16
01f0a8b8: 1f00096b cmp      w0, w9
01f0a8bc: c8230054 b.hi     #0x1f0ad34
01f0a8c0: 68ba9c52 mov      w8, #0xe5d3
01f0a8c4: 68a7b272 movk     w8, #0x953b, lsl #16
01f0a8c8: 1f00086b cmp      w0, w8
01f0a8cc: a0450054 b.eq     #0x1f0b180
01f0a8d0: 487e8952 mov      w8, #0x4bf2
01f0a8d4: 8841b372 movk     w8, #0x9a0c, lsl #16
01f0a8d8: 1f00086b cmp      w0, w8
01f0a8dc: c1890054 b.ne     #0x1f0ba14
01f0a8e0: 610240f9 ldr      x1, [x19]
01f0a8e4: e00316aa mov      x0, x22
01f0a8e8: e2031faa mov      x2, xzr
01f0a8ec: b2eef797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0a8f0: 20890036 tbz      w0, #0, #0x1f0ba14
01f0a8f4: e0030391 add      x0, sp, #0xc0
01f0a8f8: e1031faa mov      x1, xzr
01f0a8fc: 33a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a900: 680240f9 ldr      x8, [x19]
01f0a904: e10300aa mov      x1, x0
01f0a908: e2031faa mov      x2, xzr
01f0a90c: e00308aa mov      x0, x8
01f0a910: 07963d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0a914: 56a340f9 ldr      x22, [x26, #0x140]
01f0a918: e0030391 add      x0, sp, #0xc0
01f0a91c: e1031faa mov      x1, xzr
01f0a920: 2aa32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a924: d69700b4 cbz      x22, #0x1f0bc1c
01f0a928: e10300aa mov      x1, x0
01f0a92c: e00316aa mov      x0, x22
01f0a930: e2031f2a mov      w2, wzr
01f0a934: e3031faa mov      x3, xzr
01f0a938: e1aa0a94 bl       #0x21b54bc ; Royal.Player.Context.Units.ClashOfChampionsManager$$UpdateProgressOnRefresh
01f0a93c: 600240f9 ldr      x0, [x19]
01f0a940: 43040014 b        #0x1f0ba4c
01f0a944: e8799352 mov      w8, #0x9bcf
01f0a948: 283aa372 movk     w8, #0x19d1, lsl #16
01f0a94c: 1f00086b cmp      w0, w8
01f0a950: 48240054 b.hi     #0x1f0add8
01f0a954: 48538b52 mov      w8, #0x5a9a
01f0a958: 081ba372 movk     w8, #0x18d8, lsl #16
01f0a95c: 1f00086b cmp      w0, w8
01f0a960: 80430054 b.eq     #0x1f0b1d0
01f0a964: e8799352 mov      w8, #0x9bcf
01f0a968: 283aa372 movk     w8, #0x19d1, lsl #16
01f0a96c: 1f00086b cmp      w0, w8
01f0a970: 21850054 b.ne     #0x1f0ba14
01f0a974: a89401b0 adrp     x8, #0x519f000
01f0a978: 084542f9 ldr      x8, [x8, #0x488]
01f0a97c: e00316aa mov      x0, x22
01f0a980: e2031faa mov      x2, xzr
01f0a984: 010140f9 ldr      x1, [x8]
01f0a988: 8beef797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0a98c: 40840036 tbz      w0, #0, #0x1f0ba14
01f0a990: e0030391 add      x0, sp, #0xc0
01f0a994: e1031faa mov      x1, xzr
01f0a998: 0ca32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a99c: a89401b0 adrp     x8, #0x519f000
01f0a9a0: 084542f9 ldr      x8, [x8, #0x488]
01f0a9a4: e10300aa mov      x1, x0
01f0a9a8: e2031faa mov      x2, xzr
01f0a9ac: 080140f9 ldr      x8, [x8]
01f0a9b0: e00308aa mov      x0, x8
01f0a9b4: de953d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0a9b8: 567740f9 ldr      x22, [x26, #0xe8]
01f0a9bc: e0030391 add      x0, sp, #0xc0
01f0a9c0: e1031faa mov      x1, xzr
01f0a9c4: 01a32394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0a9c8: b69200b4 cbz      x22, #0x1f0bc1c
01f0a9cc: e10300aa mov      x1, x0
01f0a9d0: e00316aa mov      x0, x22
01f0a9d4: dd050094 bl       #0x1f0c148 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress4
01f0a9d8: a89401b0 adrp     x8, #0x519f000
01f0a9dc: 084542f9 ldr      x8, [x8, #0x488]
01f0a9e0: 0b040014 b        #0x1f0ba0c
01f0a9e4: 28899a52 mov      w8, #0xd449
01f0a9e8: 8826b272 movk     w8, #0x9134, lsl #16
01f0a9ec: 1f00086b cmp      w0, w8
01f0a9f0: 68220054 b.hi     #0x1f0ae3c
01f0a9f4: 28e28c52 mov      w8, #0x6711
01f0a9f8: a8e3b172 movk     w8, #0x8f1d, lsl #16
01f0a9fc: 1f00086b cmp      w0, w8
01f0aa00: 60400054 b.eq     #0x1f0b20c
01f0aa04: 28899a52 mov      w8, #0xd449
01f0aa08: 8826b272 movk     w8, #0x9134, lsl #16
01f0aa0c: 1f00086b cmp      w0, w8
01f0aa10: 21800054 b.ne     #0x1f0ba14
01f0aa14: a89701b0 adrp     x8, #0x51ff000
01f0aa18: 080540f9 ldr      x8, [x8, #8]
01f0aa1c: e00316aa mov      x0, x22
01f0aa20: e2031faa mov      x2, xzr
01f0aa24: 010140f9 ldr      x1, [x8]
01f0aa28: 63eef797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0aa2c: 407f0036 tbz      w0, #0, #0x1f0ba14
01f0aa30: e0030391 add      x0, sp, #0xc0
01f0aa34: e1031faa mov      x1, xzr
01f0aa38: e4a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0aa3c: a89701b0 adrp     x8, #0x51ff000
01f0aa40: 080540f9 ldr      x8, [x8, #8]
01f0aa44: e10300aa mov      x1, x0
01f0aa48: e2031faa mov      x2, xzr
01f0aa4c: 080140f9 ldr      x8, [x8]
01f0aa50: e00308aa mov      x0, x8
01f0aa54: b6953d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0aa58: 563740f9 ldr      x22, [x26, #0x68]
01f0aa5c: e0030391 add      x0, sp, #0xc0
01f0aa60: e1031faa mov      x1, xzr
01f0aa64: d9a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0aa68: b68d00b4 cbz      x22, #0x1f0bc1c
01f0aa6c: e10300aa mov      x1, x0
01f0aa70: e00316aa mov      x0, x22
01f0aa74: 6b040094 bl       #0x1f0bc20 ; Royal.Player.Context.Units.WeeklyLeaderboardManager$$UpdateProgress
01f0aa78: a89701b0 adrp     x8, #0x51ff000
01f0aa7c: 080540f9 ldr      x8, [x8, #8]
01f0aa80: e3030014 b        #0x1f0ba0c
01f0aa84: 68359e52 mov      w8, #0xf1ab
01f0aa88: 089fa872 movk     w8, #0x44f8, lsl #16
01f0aa8c: 1f00086b cmp      w0, w8
01f0aa90: e8210054 b.hi     #0x1f0aecc
01f0aa94: 08039e52 mov      w8, #0xf018
01f0aa98: 087fa872 movk     w8, #0x43f8, lsl #16
01f0aa9c: 1f00086b cmp      w0, w8
01f0aaa0: e03e0054 b.eq     #0x1f0b27c
01f0aaa4: 68359e52 mov      w8, #0xf1ab
01f0aaa8: 089fa872 movk     w8, #0x44f8, lsl #16
01f0aaac: 1f00086b cmp      w0, w8
01f0aab0: 217b0054 b.ne     #0x1f0ba14
01f0aab4: 68940190 adrp     x8, #0x5196000
01f0aab8: 08f546f9 ldr      x8, [x8, #0xde8]
01f0aabc: e00316aa mov      x0, x22
01f0aac0: e2031faa mov      x2, xzr
01f0aac4: 010140f9 ldr      x1, [x8]
01f0aac8: 3beef797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0aacc: 407a0036 tbz      w0, #0, #0x1f0ba14
01f0aad0: e0030391 add      x0, sp, #0xc0
01f0aad4: e1031faa mov      x1, xzr
01f0aad8: bca22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0aadc: 68940190 adrp     x8, #0x5196000
01f0aae0: 08f546f9 ldr      x8, [x8, #0xde8]
01f0aae4: e10300aa mov      x1, x0
01f0aae8: e2031faa mov      x2, xzr
01f0aaec: 080140f9 ldr      x8, [x8]
01f0aaf0: e00308aa mov      x0, x8
01f0aaf4: 8e953d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0aaf8: 564740f9 ldr      x22, [x26, #0x88]
01f0aafc: e0030391 add      x0, sp, #0xc0
01f0ab00: e1031faa mov      x1, xzr
01f0ab04: b1a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ab08: b68800b4 cbz      x22, #0x1f0bc1c
01f0ab0c: e10300aa mov      x1, x0
01f0ab10: e00316aa mov      x0, x22
01f0ab14: e2031faa mov      x2, xzr
01f0ab18: 1283f597 bl       #0x1c6b760 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress2
01f0ab1c: 68940190 adrp     x8, #0x5196000
01f0ab20: 08f546f9 ldr      x8, [x8, #0xde8]
01f0ab24: ba030014 b        #0x1f0ba0c
01f0ab28: 284c9e52 mov      w8, #0xf261
01f0ab2c: 0874bd72 movk     w8, #0xeba0, lsl #16
01f0ab30: 1f00086b cmp      w0, w8
01f0ab34: 88210054 b.hi     #0x1f0af64
01f0ab38: 08f89252 mov      w8, #0x97c0
01f0ab3c: 082ebd72 movk     w8, #0xe970, lsl #16
01f0ab40: 1f00086b cmp      w0, w8
01f0ab44: 803d0054 b.eq     #0x1f0b2f4
01f0ab48: 284c9e52 mov      w8, #0xf261
01f0ab4c: 0874bd72 movk     w8, #0xeba0, lsl #16
01f0ab50: 1f00086b cmp      w0, w8
01f0ab54: 01760054 b.ne     #0x1f0ba14
01f0ab58: a10340f9 ldr      x1, [x29]
01f0ab5c: e00316aa mov      x0, x22
01f0ab60: e2031faa mov      x2, xzr
01f0ab64: 14eef797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0ab68: 60750036 tbz      w0, #0, #0x1f0ba14
01f0ab6c: e0030391 add      x0, sp, #0xc0
01f0ab70: e1031faa mov      x1, xzr
01f0ab74: 95a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ab78: a80340f9 ldr      x8, [x29]
01f0ab7c: e10300aa mov      x1, x0
01f0ab80: e2031faa mov      x2, xzr
01f0ab84: e00308aa mov      x0, x8
01f0ab88: 69953d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0ab8c: 569b40f9 ldr      x22, [x26, #0x130]
01f0ab90: e0030391 add      x0, sp, #0xc0
01f0ab94: e1031faa mov      x1, xzr
01f0ab98: 8ca22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ab9c: 168400b4 cbz      x22, #0x1f0bc1c
01f0aba0: e10300aa mov      x1, x0
01f0aba4: e00316aa mov      x0, x22
01f0aba8: e2031faa mov      x2, xzr
01f0abac: 44844f94 bl       #0x32ebcbc ; Royal.Player.Context.Units.RobotRivalsManager$$UpdateProgress
01f0abb0: a00340f9 ldr      x0, [x29]
01f0abb4: a6030014 b        #0x1f0ba4c
01f0abb8: 48c58952 mov      w8, #0x4e2a
01f0abbc: 8818a272 movk     w8, #0x10c4, lsl #16
01f0abc0: 1f00086b cmp      w0, w8
01f0abc4: 603d0054 b.eq     #0x1f0b370
01f0abc8: e8208b52 mov      w8, #0x5907
01f0abcc: 08fba272 movk     w8, #0x17d8, lsl #16
01f0abd0: 1f00086b cmp      w0, w8
01f0abd4: 01720054 b.ne     #0x1f0ba14
01f0abd8: a89801b0 adrp     x8, #0x521f000
01f0abdc: 08c946f9 ldr      x8, [x8, #0xd90]
01f0abe0: e00316aa mov      x0, x22
01f0abe4: e2031faa mov      x2, xzr
01f0abe8: 010140f9 ldr      x1, [x8]
01f0abec: f2edf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0abf0: 20710036 tbz      w0, #0, #0x1f0ba14
01f0abf4: e0030391 add      x0, sp, #0xc0
01f0abf8: e1031faa mov      x1, xzr
01f0abfc: 73a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ac00: e1031faa mov      x1, xzr
01f0ac04: d872f597 bl       #0x1c67764 ; Royal.Player.Context.Units.GameplayGenericBackendSyncHandler$$SetGameplayCommonUseData2FromBackend
01f0ac08: a89801b0 adrp     x8, #0x521f000
01f0ac0c: 08c946f9 ldr      x8, [x8, #0xd90]
01f0ac10: 7f030014 b        #0x1f0ba0c
01f0ac14: 28488e52 mov      w8, #0x7241
01f0ac18: 4859b072 movk     w8, #0x82ca, lsl #16
01f0ac1c: 1f00086b cmp      w0, w8
01f0ac20: a0580054 b.eq     #0x1f0b734
01f0ac24: a8b29a52 mov      w8, #0xd595
01f0ac28: c8e5b072 movk     w8, #0x872e, lsl #16
01f0ac2c: 1f00086b cmp      w0, w8
01f0ac30: a03e0054 b.eq     #0x1f0b404
01f0ac34: 28268052 mov      w8, #0x131
01f0ac38: 2832af72 movk     w8, #0x7991, lsl #16
01f0ac3c: 1f00086b cmp      w0, w8
01f0ac40: a16e0054 b.ne     #0x1f0ba14
01f0ac44: e89701b0 adrp     x8, #0x5207000
01f0ac48: 088d46f9 ldr      x8, [x8, #0xd18]
01f0ac4c: e00316aa mov      x0, x22
01f0ac50: e2031faa mov      x2, xzr
01f0ac54: 010140f9 ldr      x1, [x8]
01f0ac58: d7edf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0ac5c: c06d0036 tbz      w0, #0, #0x1f0ba14
01f0ac60: e0030391 add      x0, sp, #0xc0
01f0ac64: e1031faa mov      x1, xzr
01f0ac68: 58a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ac6c: e89701b0 adrp     x8, #0x5207000
01f0ac70: 088d46f9 ldr      x8, [x8, #0xd18]
01f0ac74: e10300aa mov      x1, x0
01f0ac78: e2031faa mov      x2, xzr
01f0ac7c: 080140f9 ldr      x8, [x8]
01f0ac80: e00308aa mov      x0, x8
01f0ac84: 2a953d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0ac88: 568340f9 ldr      x22, [x26, #0x100]
01f0ac8c: e0030391 add      x0, sp, #0xc0
01f0ac90: e1031faa mov      x1, xzr
01f0ac94: 4da22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ac98: 367c00b4 cbz      x22, #0x1f0bc1c
01f0ac9c: e10300aa mov      x1, x0
01f0aca0: e00316aa mov      x0, x22
01f0aca4: e2031faa mov      x2, xzr
01f0aca8: d8d00a94 bl       #0x21bf008 ; Royal.Player.Context.Units.DailyLightningRushManager$$UpdateProgress
01f0acac: e89701b0 adrp     x8, #0x5207000
01f0acb0: 088d46f9 ldr      x8, [x8, #0xd18]
01f0acb4: 56030014 b        #0x1f0ba0c
01f0acb8: 48e68f52 mov      w8, #0x7f32
01f0acbc: e8b3a672 movk     w8, #0x359f, lsl #16
01f0acc0: 1f00086b cmp      w0, w8
01f0acc4: 60550054 b.eq     #0x1f0b770
01f0acc8: a8918552 mov      w8, #0x2c8d
01f0accc: 4870a772 movk     w8, #0x3b82, lsl #16
01f0acd0: 1f00086b cmp      w0, w8
01f0acd4: 203d0054 b.eq     #0x1f0b478
01f0acd8: 481c9c52 mov      w8, #0xe0e2
01f0acdc: 2819a872 movk     w8, #0x40c9, lsl #16
01f0ace0: 1f00086b cmp      w0, w8
01f0ace4: 81690054 b.ne     #0x1f0ba14
01f0ace8: 689901f0 adrp     x8, #0x5239000
01f0acec: 082940f9 ldr      x8, [x8, #0x50]
01f0acf0: e00316aa mov      x0, x22
01f0acf4: e2031faa mov      x2, xzr
01f0acf8: 010140f9 ldr      x1, [x8]
01f0acfc: aeedf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0ad00: a0680036 tbz      w0, #0, #0x1f0ba14
01f0ad04: 565340f9 ldr      x22, [x26, #0xa0]
01f0ad08: e0030391 add      x0, sp, #0xc0
01f0ad0c: e1031faa mov      x1, xzr
01f0ad10: 2ea22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ad14: 567800b4 cbz      x22, #0x1f0bc1c
01f0ad18: e10300aa mov      x1, x0
01f0ad1c: e00316aa mov      x0, x22
01f0ad20: e2031faa mov      x2, xzr
01f0ad24: afb3fa97 bl       #0x1db7be0 ; Royal.Player.Context.Units.KingNightmareManager$$UpdateNightmareEvent
01f0ad28: 689901f0 adrp     x8, #0x5239000
01f0ad2c: 082940f9 ldr      x8, [x8, #0x50]
01f0ad30: 37030014 b        #0x1f0ba0c
01f0ad34: c9338b52 mov      w9, #0x599e
01f0ad38: c9eeb472 movk     w9, #0xa776, lsl #16
01f0ad3c: 1f00096b cmp      w0, w9
01f0ad40: a0550054 b.eq     #0x1f0b7f4
01f0ad44: e99c9552 mov      w9, #0xace7
01f0ad48: 29c1b772 movk     w9, #0xbe09, lsl #16
01f0ad4c: 1f00096b cmp      w0, w9
01f0ad50: 203d0054 b.eq     #0x1f0b4f4
01f0ad54: 88339b52 mov      w8, #0xd99c
01f0ad58: a8bebc72 movk     w8, #0xe5f5, lsl #16
01f0ad5c: 1f00086b cmp      w0, w8
01f0ad60: a1650054 b.ne     #0x1f0ba14
01f0ad64: 289601b0 adrp     x8, #0x51cf000
01f0ad68: 088946f9 ldr      x8, [x8, #0xd10]
01f0ad6c: e00316aa mov      x0, x22
01f0ad70: e2031faa mov      x2, xzr
01f0ad74: 010140f9 ldr      x1, [x8]
01f0ad78: 8fedf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0ad7c: c0640036 tbz      w0, #0, #0x1f0ba14
01f0ad80: e0030391 add      x0, sp, #0xc0
01f0ad84: e1031faa mov      x1, xzr
01f0ad88: 10a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ad8c: 289601b0 adrp     x8, #0x51cf000
01f0ad90: 088946f9 ldr      x8, [x8, #0xd10]
01f0ad94: e10300aa mov      x1, x0
01f0ad98: e2031faa mov      x2, xzr
01f0ad9c: 080140f9 ldr      x8, [x8]
01f0ada0: e00308aa mov      x0, x8
01f0ada4: e2943d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0ada8: 567f40f9 ldr      x22, [x26, #0xf8]
01f0adac: e0030391 add      x0, sp, #0xc0
01f0adb0: e1031faa mov      x1, xzr
01f0adb4: 05a22394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0adb8: 367300b4 cbz      x22, #0x1f0bc1c
01f0adbc: e10300aa mov      x1, x0
01f0adc0: e00316aa mov      x0, x22
01f0adc4: e2031faa mov      x2, xzr
01f0adc8: 4dbc0a94 bl       #0x21b9efc ; Royal.Player.Context.Units.CoinShopManager$$UpdateProgress
01f0adcc: 289601b0 adrp     x8, #0x51cf000
01f0add0: 088946f9 ldr      x8, [x8, #0xd10]
01f0add4: 0e030014 b        #0x1f0ba0c
01f0add8: 68fc8152 mov      w8, #0xfe3
01f0addc: 688ca472 movk     w8, #0x2463, lsl #16
01f0ade0: 1f00086b cmp      w0, w8
01f0ade4: c0540054 b.eq     #0x1f0b87c
01f0ade8: c82e8252 mov      w8, #0x1176
01f0adec: 68aca472 movk     w8, #0x2563, lsl #16
01f0adf0: 1f00086b cmp      w0, w8
01f0adf4: c03c0054 b.eq     #0x1f0b58c
01f0adf8: 1f001c6b cmp      w0, w28
01f0adfc: c1600054 b.ne     #0x1f0ba14
01f0ae00: 289801d0 adrp     x8, #0x5210000
01f0ae04: 08c545f9 ldr      x8, [x8, #0xb88]
01f0ae08: e00316aa mov      x0, x22
01f0ae0c: e2031faa mov      x2, xzr
01f0ae10: 010140f9 ldr      x1, [x8]
01f0ae14: 68edf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0ae18: e05f0036 tbz      w0, #0, #0x1f0ba14
01f0ae1c: e0030391 add      x0, sp, #0xc0
01f0ae20: e1031faa mov      x1, xzr
01f0ae24: e9a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ae28: e1031faa mov      x1, xzr
01f0ae2c: fd420094 bl       #0x1f1ba20 ; Royal.Player.Context.Units.LiveOpsCommonKeyValueHandler$$UpdateCommonUseDataFromBackend
01f0ae30: 289801d0 adrp     x8, #0x5210000
01f0ae34: 08c545f9 ldr      x8, [x8, #0xb88]
01f0ae38: f5020014 b        #0x1f0ba0c
01f0ae3c: 889b8b52 mov      w8, #0x5cdc
01f0ae40: a854b272 movk     w8, #0x92a5, lsl #16
01f0ae44: 1f00086b cmp      w0, w8
01f0ae48: 40550054 b.eq     #0x1f0b8f0
01f0ae4c: e8cd8b52 mov      w8, #0x5e6f
01f0ae50: a874b272 movk     w8, #0x93a5, lsl #16
01f0ae54: 1f00086b cmp      w0, w8
01f0ae58: 403d0054 b.eq     #0x1f0b600
01f0ae5c: 48008c52 mov      w8, #0x6002
01f0ae60: a894b272 movk     w8, #0x94a5, lsl #16
01f0ae64: 1f00086b cmp      w0, w8
01f0ae68: 615d0054 b.ne     #0x1f0ba14
01f0ae6c: 889601b0 adrp     x8, #0x51db000
01f0ae70: 086146f9 ldr      x8, [x8, #0xcc0]
01f0ae74: e00316aa mov      x0, x22
01f0ae78: e2031faa mov      x2, xzr
01f0ae7c: 010140f9 ldr      x1, [x8]
01f0ae80: 4dedf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0ae84: 805c0036 tbz      w0, #0, #0x1f0ba14
01f0ae88: e0030391 add      x0, sp, #0xc0
01f0ae8c: e1031faa mov      x1, xzr
01f0ae90: cea12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ae94: 889601b0 adrp     x8, #0x51db000
01f0ae98: 086146f9 ldr      x8, [x8, #0xcc0]
01f0ae9c: e10300aa mov      x1, x0
01f0aea0: e2031faa mov      x2, xzr
01f0aea4: f60308aa mov      x22, x8
01f0aea8: 080140f9 ldr      x8, [x8]
01f0aeac: e00308aa mov      x0, x8
01f0aeb0: 9f943d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0aeb4: e0030391 add      x0, sp, #0xc0
01f0aeb8: e1031faa mov      x1, xzr
01f0aebc: c3a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0aec0: e1031faa mov      x1, xzr
01f0aec4: a56bcd97 bl       #0x1265d58 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue1FromBackend
01f0aec8: a1020014 b        #0x1f0b94c
01f0aecc: 08988e52 mov      w8, #0x74c0
01f0aed0: 48b0a872 movk     w8, #0x4582, lsl #16
01f0aed4: 1f00086b cmp      w0, w8
01f0aed8: e0530054 b.eq     #0x1f0b954
01f0aedc: c8679e52 mov      w8, #0xf33e
01f0aee0: 08bfa872 movk     w8, #0x45f8, lsl #16
01f0aee4: 1f00086b cmp      w0, w8
01f0aee8: c03b0054 b.eq     #0x1f0b660
01f0aeec: 1f00196b cmp      w0, w25
01f0aef0: 21590054 b.ne     #0x1f0ba14
01f0aef4: 689701f0 adrp     x8, #0x51f9000
01f0aef8: 084941f9 ldr      x8, [x8, #0x290]
01f0aefc: e00316aa mov      x0, x22
01f0af00: e2031faa mov      x2, xzr
01f0af04: 010140f9 ldr      x1, [x8]
01f0af08: 2bedf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0af0c: 40580036 tbz      w0, #0, #0x1f0ba14
01f0af10: e0030391 add      x0, sp, #0xc0
01f0af14: e1031faa mov      x1, xzr
01f0af18: aca12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0af1c: 689701f0 adrp     x8, #0x51f9000
01f0af20: 084941f9 ldr      x8, [x8, #0x290]
01f0af24: e10300aa mov      x1, x0
01f0af28: e2031faa mov      x2, xzr
01f0af2c: 080140f9 ldr      x8, [x8]
01f0af30: e00308aa mov      x0, x8
01f0af34: 7e943d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0af38: 567740f9 ldr      x22, [x26, #0xe8]
01f0af3c: e0030391 add      x0, sp, #0xc0
01f0af40: e1031faa mov      x1, xzr
01f0af44: a1a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0af48: b66600b4 cbz      x22, #0x1f0bc1c
01f0af4c: e10300aa mov      x1, x0
01f0af50: e00316aa mov      x0, x22
01f0af54: d9030094 bl       #0x1f0beb8 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress2
01f0af58: 689701f0 adrp     x8, #0x51f9000
01f0af5c: 084941f9 ldr      x8, [x8, #0x290]
01f0af60: ab020014 b        #0x1f0ba0c
01f0af64: c8ba9652 mov      w8, #0xb5d6
01f0af68: a8efbe72 movk     w8, #0xf77d, lsl #16
01f0af6c: 1f00086b cmp      w0, w8
01f0af70: a0520054 b.eq     #0x1f0b9c4
01f0af74: 68e59852 mov      w8, #0xc72b
01f0af78: 686fbf72 movk     w8, #0xfb7b, lsl #16
01f0af7c: 1f00086b cmp      w0, w8
01f0af80: a03a0054 b.eq     #0x1f0b6d4
01f0af84: c8179952 mov      w8, #0xc8be
01f0af88: 688fbf72 movk     w8, #0xfc7b, lsl #16
01f0af8c: 1f00086b cmp      w0, w8
01f0af90: 21540054 b.ne     #0x1f0ba14
01f0af94: 010340f9 ldr      x1, [x24]
01f0af98: e00316aa mov      x0, x22
01f0af9c: e2031faa mov      x2, xzr
01f0afa0: 05edf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0afa4: 80530036 tbz      w0, #0, #0x1f0ba14
01f0afa8: e0030391 add      x0, sp, #0xc0
01f0afac: e1031faa mov      x1, xzr
01f0afb0: 86a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0afb4: 080340f9 ldr      x8, [x24]
01f0afb8: e10300aa mov      x1, x0
01f0afbc: e2031faa mov      x2, xzr
01f0afc0: e00308aa mov      x0, x8
01f0afc4: 5a943d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0afc8: 566340f9 ldr      x22, [x26, #0xc0]
01f0afcc: e0030391 add      x0, sp, #0xc0
01f0afd0: e1031faa mov      x1, xzr
01f0afd4: 7da12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0afd8: 366200b4 cbz      x22, #0x1f0bc1c
01f0afdc: e10300aa mov      x1, x0
01f0afe0: e00316aa mov      x0, x22
01f0afe4: e2031faa mov      x2, xzr
01f0afe8: 37a81094 bl       #0x23350c4 ; Royal.Player.Context.Units.DukesFortuneManager$$UpdateProgress1
01f0afec: 000340f9 ldr      x0, [x24]
01f0aff0: 97020014 b        #0x1f0ba4c
01f0aff4: 010140f9 ldr      x1, [x8]
01f0aff8: e00316aa mov      x0, x22
01f0affc: e2031faa mov      x2, xzr
01f0b000: edecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b004: 80500036 tbz      w0, #0, #0x1f0ba14
01f0b008: e0030391 add      x0, sp, #0xc0
01f0b00c: e1031faa mov      x1, xzr
01f0b010: f90318aa mov      x25, x24
01f0b014: f80317aa mov      x24, x23
01f0b018: fc031daa mov      x28, x29
01f0b01c: fd031baa mov      x29, x27
01f0b020: f6031aaa mov      x22, x26
01f0b024: 69a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b028: ba9701d0 adrp     x26, #0x5201000
01f0b02c: 5a9b44f9 ldr      x26, [x26, #0x930]
01f0b030: e10300aa mov      x1, x0
01f0b034: e2031faa mov      x2, xzr
01f0b038: 480340f9 ldr      x8, [x26]
01f0b03c: e00308aa mov      x0, x8
01f0b040: 3b943d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b044: f70316aa mov      x23, x22
01f0b048: d65e40f9 ldr      x22, [x22, #0xb8]
01f0b04c: e0030391 add      x0, sp, #0xc0
01f0b050: e1031faa mov      x1, xzr
01f0b054: 5da12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b058: 365e00b4 cbz      x22, #0x1f0bc1c
01f0b05c: e10300aa mov      x1, x0
01f0b060: e00316aa mov      x0, x22
01f0b064: e2031faa mov      x2, xzr
01f0b068: de6f0594 bl       #0x2066fe0 ; Royal.Player.Context.Units.TeamTournamentManager$$UpdateProgressValue1
01f0b06c: f59601b0 adrp     x21, #0x51e8000
01f0b070: 400340f9 ldr      x0, [x26]
01f0b074: b56a40f9 ldr      x21, [x21, #0xd0]
01f0b078: fa0317aa mov      x26, x23
01f0b07c: 3b010014 b        #0x1f0b568
01f0b080: 689501d0 adrp     x8, #0x51b9000
01f0b084: 08fd43f9 ldr      x8, [x8, #0x7f8]
01f0b088: e00316aa mov      x0, x22
01f0b08c: e2031faa mov      x2, xzr
01f0b090: 010140f9 ldr      x1, [x8]
01f0b094: c8ecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b098: e04b0036 tbz      w0, #0, #0x1f0ba14
01f0b09c: e0030391 add      x0, sp, #0xc0
01f0b0a0: e1031faa mov      x1, xzr
01f0b0a4: 49a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b0a8: 689501d0 adrp     x8, #0x51b9000
01f0b0ac: 08fd43f9 ldr      x8, [x8, #0x7f8]
01f0b0b0: e10300aa mov      x1, x0
01f0b0b4: e2031faa mov      x2, xzr
01f0b0b8: 080140f9 ldr      x8, [x8]
01f0b0bc: e00308aa mov      x0, x8
01f0b0c0: 1b943d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b0c4: 565740f9 ldr      x22, [x26, #0xa8]
01f0b0c8: e0030391 add      x0, sp, #0xc0
01f0b0cc: e1031faa mov      x1, xzr
01f0b0d0: 3ea12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b0d4: 565a00b4 cbz      x22, #0x1f0bc1c
01f0b0d8: e10300aa mov      x1, x0
01f0b0dc: e00316aa mov      x0, x22
01f0b0e0: e2031f2a mov      w2, wzr
01f0b0e4: e3031faa mov      x3, xzr
01f0b0e8: b5091594 bl       #0x244d7bc ; Royal.Player.Context.Units.BalloonRiseManager$$UpdateProgress
01f0b0ec: 689501d0 adrp     x8, #0x51b9000
01f0b0f0: 08fd43f9 ldr      x8, [x8, #0x7f8]
01f0b0f4: 46020014 b        #0x1f0ba0c
01f0b0f8: 010140f9 ldr      x1, [x8]
01f0b0fc: e00316aa mov      x0, x22
01f0b100: e2031faa mov      x2, xzr
01f0b104: acecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b108: 60480036 tbz      w0, #0, #0x1f0ba14
01f0b10c: e0030391 add      x0, sp, #0xc0
01f0b110: e1031faa mov      x1, xzr
01f0b114: f90318aa mov      x25, x24
01f0b118: f80317aa mov      x24, x23
01f0b11c: f7031daa mov      x23, x29
01f0b120: fd031baa mov      x29, x27
01f0b124: 29a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b128: 9c9901f0 adrp     x28, #0x523e000
01f0b12c: 9ccb42f9 ldr      x28, [x28, #0x590]
01f0b130: e10300aa mov      x1, x0
01f0b134: e2031faa mov      x2, xzr
01f0b138: 880340f9 ldr      x8, [x28]
01f0b13c: e00308aa mov      x0, x8
01f0b140: fb933d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b144: 568f40f9 ldr      x22, [x26, #0x118]
01f0b148: e0030391 add      x0, sp, #0xc0
01f0b14c: e1031faa mov      x1, xzr
01f0b150: 1ea12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b154: 565600b4 cbz      x22, #0x1f0bc1c
01f0b158: e10300aa mov      x1, x0
01f0b15c: e00316aa mov      x0, x22
01f0b160: e2031faa mov      x2, xzr
01f0b164: 684d4a94 bl       #0x319e704 ; Royal.Player.Context.Units.PropellerRushManager$$UpdateProgress
01f0b168: f59601b0 adrp     x21, #0x51e8000
01f0b16c: 800340f9 ldr      x0, [x28]
01f0b170: b56a40f9 ldr      x21, [x21, #0xd0]
01f0b174: fb031daa mov      x27, x29
01f0b178: fd0317aa mov      x29, x23
01f0b17c: fd000014 b        #0x1f0b570
01f0b180: a10240f9 ldr      x1, [x21]
01f0b184: e00316aa mov      x0, x22
01f0b188: e2031faa mov      x2, xzr
01f0b18c: 8aecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b190: 20440036 tbz      w0, #0, #0x1f0ba14
01f0b194: e0030391 add      x0, sp, #0xc0
01f0b198: e1031faa mov      x1, xzr
01f0b19c: 0ba12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b1a0: a80240f9 ldr      x8, [x21]
01f0b1a4: e10300aa mov      x1, x0
01f0b1a8: e2031faa mov      x2, xzr
01f0b1ac: e00308aa mov      x0, x8
01f0b1b0: df933d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b1b4: e0030391 add      x0, sp, #0xc0
01f0b1b8: e1031faa mov      x1, xzr
01f0b1bc: 03a12394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b1c0: e1031faa mov      x1, xzr
01f0b1c4: 29f24994 bl       #0x3187a68 ; Royal.Player.Context.Units.MonetizationCommonKeyValueHandler$$UpdateCommonUseDataFromBackend
01f0b1c8: a00240f9 ldr      x0, [x21]
01f0b1cc: 20020014 b        #0x1f0ba4c
01f0b1d0: 689801d0 adrp     x8, #0x5219000
01f0b1d4: 086140f9 ldr      x8, [x8, #0xc0]
01f0b1d8: e00316aa mov      x0, x22
01f0b1dc: e2031faa mov      x2, xzr
01f0b1e0: 010140f9 ldr      x1, [x8]
01f0b1e4: 74ecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b1e8: 60410036 tbz      w0, #0, #0x1f0ba14
01f0b1ec: e0030391 add      x0, sp, #0xc0
01f0b1f0: e1031faa mov      x1, xzr
01f0b1f4: f5a02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b1f8: e1031faa mov      x1, xzr
01f0b1fc: 2071f597 bl       #0x1c6767c ; Royal.Player.Context.Units.GameplayGenericBackendSyncHandler$$SetGameplayCommonUseDataFromBackend
01f0b200: 689801d0 adrp     x8, #0x5219000
01f0b204: 086140f9 ldr      x8, [x8, #0xc0]
01f0b208: 01020014 b        #0x1f0ba0c
01f0b20c: 08970190 adrp     x8, #0x51eb000
01f0b210: 089d42f9 ldr      x8, [x8, #0x538]
01f0b214: e00316aa mov      x0, x22
01f0b218: e2031faa mov      x2, xzr
01f0b21c: 010140f9 ldr      x1, [x8]
01f0b220: 65ecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b224: 803f0036 tbz      w0, #0, #0x1f0ba14
01f0b228: e0030391 add      x0, sp, #0xc0
01f0b22c: e1031faa mov      x1, xzr
01f0b230: e6a02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b234: 08970190 adrp     x8, #0x51eb000
01f0b238: 089d42f9 ldr      x8, [x8, #0x538]
01f0b23c: e10300aa mov      x1, x0
01f0b240: e2031faa mov      x2, xzr
01f0b244: 080140f9 ldr      x8, [x8]
01f0b248: e00308aa mov      x0, x8
01f0b24c: b8933d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b250: 567740f9 ldr      x22, [x26, #0xe8]
01f0b254: e0030391 add      x0, sp, #0xc0
01f0b258: e1031faa mov      x1, xzr
01f0b25c: dba02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b260: f64d00b4 cbz      x22, #0x1f0bc1c
01f0b264: e10300aa mov      x1, x0
01f0b268: e00316aa mov      x0, x22
01f0b26c: 65030094 bl       #0x1f0c000 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress3
01f0b270: 08970190 adrp     x8, #0x51eb000
01f0b274: 089d42f9 ldr      x8, [x8, #0x538]
01f0b278: e5010014 b        #0x1f0ba0c
01f0b27c: 48990190 adrp     x8, #0x5233000
01f0b280: 08d941f9 ldr      x8, [x8, #0x3b0]
01f0b284: e00316aa mov      x0, x22
01f0b288: e2031faa mov      x2, xzr
01f0b28c: 010140f9 ldr      x1, [x8]
01f0b290: 49ecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b294: 003c0036 tbz      w0, #0, #0x1f0ba14
01f0b298: e0030391 add      x0, sp, #0xc0
01f0b29c: e1031faa mov      x1, xzr
01f0b2a0: caa02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b2a4: 48990190 adrp     x8, #0x5233000
01f0b2a8: 08d941f9 ldr      x8, [x8, #0x3b0]
01f0b2ac: e10300aa mov      x1, x0
01f0b2b0: e2031faa mov      x2, xzr
01f0b2b4: 080140f9 ldr      x8, [x8]
01f0b2b8: e00308aa mov      x0, x8
01f0b2bc: 9c933d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b2c0: 564740f9 ldr      x22, [x26, #0x88]
01f0b2c4: e0030391 add      x0, sp, #0xc0
01f0b2c8: e1031faa mov      x1, xzr
01f0b2cc: bfa02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b2d0: 764a00b4 cbz      x22, #0x1f0bc1c
01f0b2d4: e10300aa mov      x1, x0
01f0b2d8: e00316aa mov      x0, x22
01f0b2dc: e2031f2a mov      w2, wzr
01f0b2e0: e3031faa mov      x3, xzr
01f0b2e4: 7181f597 bl       #0x1c6b8a8 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress3
01f0b2e8: 48990190 adrp     x8, #0x5233000
01f0b2ec: 08d941f9 ldr      x8, [x8, #0x3b0]
01f0b2f0: c7010014 b        #0x1f0ba0c
01f0b2f4: 610340f9 ldr      x1, [x27]
01f0b2f8: e00316aa mov      x0, x22
01f0b2fc: e2031faa mov      x2, xzr
01f0b300: 2decf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b304: 80380036 tbz      w0, #0, #0x1f0ba14
01f0b308: 48b301f0 adrp     x8, #0x5576000
01f0b30c: 08ad7c39 ldrb     w8, [x8, #0xf2b]
01f0b310: e8000035 cbnz     w8, #0x1f0b32c
01f0b314: e09701b0 adrp     x0, #0x5208000
01f0b318: 00c041f9 ldr      x0, [x0, #0x380]
01f0b31c: f997c297 bl       #0xfb1300
01f0b320: 48b301f0 adrp     x8, #0x5576000
01f0b324: 29008052 mov      w9, #1
01f0b328: 09ad3c39 strb     w9, [x8, #0xf2b]
01f0b32c: e89701b0 adrp     x8, #0x5208000
01f0b330: 08c141f9 ldr      x8, [x8, #0x380]
01f0b334: 080140f9 ldr      x8, [x8]
01f0b338: 085d40f9 ldr      x8, [x8, #0xb8]
01f0b33c: 080140f9 ldr      x8, [x8]
01f0b340: e84600b4 cbz      x8, #0x1f0bc1c
01f0b344: 161140f9 ldr      x22, [x8, #0x20]
01f0b348: e0030391 add      x0, sp, #0xc0
01f0b34c: e1031faa mov      x1, xzr
01f0b350: 9ea02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b354: 564600b4 cbz      x22, #0x1f0bc1c
01f0b358: e10300aa mov      x1, x0
01f0b35c: e00316aa mov      x0, x22
01f0b360: e2031faa mov      x2, xzr
01f0b364: e70c2c94 bl       #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
01f0b368: 600340f9 ldr      x0, [x27]
01f0b36c: b8010014 b        #0x1f0ba4c
01f0b370: 289701f0 adrp     x8, #0x51f2000
01f0b374: 08b145f9 ldr      x8, [x8, #0xb60]
01f0b378: e00316aa mov      x0, x22
01f0b37c: e2031faa mov      x2, xzr
01f0b380: 010140f9 ldr      x1, [x8]
01f0b384: 0cecf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b388: 60340036 tbz      w0, #0, #0x1f0ba14
01f0b38c: e0030391 add      x0, sp, #0xc0
01f0b390: e1031faa mov      x1, xzr
01f0b394: 8da02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b398: e10300aa mov      x1, x0
01f0b39c: e0430291 add      x0, sp, #0x90
01f0b3a0: e2031faa mov      x2, xzr
01f0b3a4: c0d82b94 bl       #0x2a016a4 ; Royal.Player.Context.Data.Persistent.TeamOfferProgress$$.ctor
01f0b3a8: 48b301f0 adrp     x8, #0x5576000
01f0b3ac: 08ad7c39 ldrb     w8, [x8, #0xf2b]
01f0b3b0: e8000035 cbnz     w8, #0x1f0b3cc
01f0b3b4: e09701b0 adrp     x0, #0x5208000
01f0b3b8: 00c041f9 ldr      x0, [x0, #0x380]
01f0b3bc: d197c297 bl       #0xfb1300
01f0b3c0: 48b301f0 adrp     x8, #0x5576000
01f0b3c4: 29008052 mov      w9, #1
01f0b3c8: 09ad3c39 strb     w9, [x8, #0xf2b]
01f0b3cc: e89701b0 adrp     x8, #0x5208000
01f0b3d0: 08c141f9 ldr      x8, [x8, #0x380]
01f0b3d4: 080140f9 ldr      x8, [x8]
01f0b3d8: 085d40f9 ldr      x8, [x8, #0xb8]
01f0b3dc: 080140f9 ldr      x8, [x8]
01f0b3e0: e84100b4 cbz      x8, #0x1f0bc1c
01f0b3e4: 001140f9 ldr      x0, [x8, #0x20]
01f0b3e8: a04100b4 cbz      x0, #0x1f0bc1c
01f0b3ec: e10b49a9 ldp      x1, x2, [sp, #0x90]
01f0b3f0: e3031faa mov      x3, xzr
01f0b3f4: f40b2c94 bl       #0x2a0e3c4 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateTeamOfferProgress
01f0b3f8: 289701f0 adrp     x8, #0x51f2000
01f0b3fc: 08b145f9 ldr      x8, [x8, #0xb60]
01f0b400: 83010014 b        #0x1f0ba0c
01f0b404: 489601d0 adrp     x8, #0x51d5000
01f0b408: 087142f9 ldr      x8, [x8, #0x4e0]
01f0b40c: e00316aa mov      x0, x22
01f0b410: e2031faa mov      x2, xzr
01f0b414: 010140f9 ldr      x1, [x8]
01f0b418: e7ebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b41c: c02f0036 tbz      w0, #0, #0x1f0ba14
01f0b420: e0030391 add      x0, sp, #0xc0
01f0b424: e1031faa mov      x1, xzr
01f0b428: 68a02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b42c: 489601d0 adrp     x8, #0x51d5000
01f0b430: 087142f9 ldr      x8, [x8, #0x4e0]
01f0b434: e10300aa mov      x1, x0
01f0b438: e2031faa mov      x2, xzr
01f0b43c: 080140f9 ldr      x8, [x8]
01f0b440: e00308aa mov      x0, x8
01f0b444: 3a933d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b448: 567340f9 ldr      x22, [x26, #0xe0]
01f0b44c: e0030391 add      x0, sp, #0xc0
01f0b450: e1031faa mov      x1, xzr
01f0b454: 5da02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b458: 363e00b4 cbz      x22, #0x1f0bc1c
01f0b45c: e10300aa mov      x1, x0
01f0b460: e00316aa mov      x0, x22
01f0b464: e2031faa mov      x2, xzr
01f0b468: 2fc51d94 bl       #0x267c924 ; Royal.Player.Context.Units.WelcomeBackGiftManager$$UpdateProgress
01f0b46c: 489601d0 adrp     x8, #0x51d5000
01f0b470: 087142f9 ldr      x8, [x8, #0x4e0]
01f0b474: 66010014 b        #0x1f0ba0c
01f0b478: a89601f0 adrp     x8, #0x51e2000
01f0b47c: 089d46f9 ldr      x8, [x8, #0xd38]
01f0b480: e00316aa mov      x0, x22
01f0b484: e2031faa mov      x2, xzr
01f0b488: 010140f9 ldr      x1, [x8]
01f0b48c: caebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b490: 202c0036 tbz      w0, #0, #0x1f0ba14
01f0b494: e0030391 add      x0, sp, #0xc0
01f0b498: e1031faa mov      x1, xzr
01f0b49c: 4ba02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b4a0: a89601f0 adrp     x8, #0x51e2000
01f0b4a4: 089d46f9 ldr      x8, [x8, #0xd38]
01f0b4a8: e10300aa mov      x1, x0
01f0b4ac: e2031faa mov      x2, xzr
01f0b4b0: 080140f9 ldr      x8, [x8]
01f0b4b4: e00308aa mov      x0, x8
01f0b4b8: 1d933d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b4bc: 481340f9 ldr      x8, [x26, #0x20]
01f0b4c0: e83a00b4 cbz      x8, #0x1f0bc1c
01f0b4c4: 160d40f9 ldr      x22, [x8, #0x18]
01f0b4c8: e0030391 add      x0, sp, #0xc0
01f0b4cc: e1031faa mov      x1, xzr
01f0b4d0: 3ea02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b4d4: 563a00b4 cbz      x22, #0x1f0bc1c
01f0b4d8: e10300aa mov      x1, x0
01f0b4dc: e00316aa mov      x0, x22
01f0b4e0: e2031faa mov      x2, xzr
01f0b4e4: 99024a94 bl       #0x318bf48 ; Royal.Player.Context.Units.NewUserNewUxHelper$$UpdateData
01f0b4e8: a89601f0 adrp     x8, #0x51e2000
01f0b4ec: 089d46f9 ldr      x8, [x8, #0xd38]
01f0b4f0: 47010014 b        #0x1f0ba0c
01f0b4f4: 010140f9 ldr      x1, [x8]
01f0b4f8: e00316aa mov      x0, x22
01f0b4fc: e2031faa mov      x2, xzr
01f0b500: adebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b504: 80280036 tbz      w0, #0, #0x1f0ba14
01f0b508: e0030391 add      x0, sp, #0xc0
01f0b50c: e1031faa mov      x1, xzr
01f0b510: f90318aa mov      x25, x24
01f0b514: f80317aa mov      x24, x23
01f0b518: fc031daa mov      x28, x29
01f0b51c: fd031baa mov      x29, x27
01f0b520: 2aa02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b524: 57950190 adrp     x23, #0x51b3000
01f0b528: f7e641f9 ldr      x23, [x23, #0x3c8]
01f0b52c: e10300aa mov      x1, x0
01f0b530: e2031faa mov      x2, xzr
01f0b534: e80240f9 ldr      x8, [x23]
01f0b538: e00308aa mov      x0, x8
01f0b53c: fc923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b540: 565b40f9 ldr      x22, [x26, #0xb0]
01f0b544: e0030391 add      x0, sp, #0xc0
01f0b548: e1031faa mov      x1, xzr
01f0b54c: 1fa02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b550: 763600b4 cbz      x22, #0x1f0bc1c
01f0b554: e10300aa mov      x1, x0
01f0b558: e00316aa mov      x0, x22
01f0b55c: e2031faa mov      x2, xzr
01f0b560: d5ec1494 bl       #0x24468b4 ; Royal.Player.Context.Units.ArcheryArenaManager$$UpdateProgress
01f0b564: e00240f9 ldr      x0, [x23]
01f0b568: fb031daa mov      x27, x29
01f0b56c: fd031caa mov      x29, x28
01f0b570: f70318aa mov      x23, x24
01f0b574: f80319aa mov      x24, x25
01f0b578: 79ec9452 mov      w25, #0xa763
01f0b57c: dc229f52 mov      w28, #0xf916
01f0b580: 19fba972 movk     w25, #0x4fd8, lsl #16
01f0b584: 9c55a572 movk     w28, #0x2aac, lsl #16
01f0b588: 31010014 b        #0x1f0ba4c
01f0b58c: 489901f0 adrp     x8, #0x5236000
01f0b590: 082d47f9 ldr      x8, [x8, #0xe58]
01f0b594: e00316aa mov      x0, x22
01f0b598: e2031faa mov      x2, xzr
01f0b59c: 010140f9 ldr      x1, [x8]
01f0b5a0: 85ebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b5a4: 80230036 tbz      w0, #0, #0x1f0ba14
01f0b5a8: e0030391 add      x0, sp, #0xc0
01f0b5ac: e1031faa mov      x1, xzr
01f0b5b0: 06a02394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b5b4: 489901f0 adrp     x8, #0x5236000
01f0b5b8: 082d47f9 ldr      x8, [x8, #0xe58]
01f0b5bc: e10300aa mov      x1, x0
01f0b5c0: e2031faa mov      x2, xzr
01f0b5c4: 080140f9 ldr      x8, [x8]
01f0b5c8: e00308aa mov      x0, x8
01f0b5cc: d8923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b5d0: 563b40f9 ldr      x22, [x26, #0x70]
01f0b5d4: e0030391 add      x0, sp, #0xc0
01f0b5d8: e1031faa mov      x1, xzr
01f0b5dc: fb9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b5e0: f63100b4 cbz      x22, #0x1f0bc1c
01f0b5e4: e10300aa mov      x1, x0
01f0b5e8: e00316aa mov      x0, x22
01f0b5ec: e2031faa mov      x2, xzr
01f0b5f0: 12ea0a94 bl       #0x21c5e38 ; Royal.Player.Context.Units.DragonNestManager$$UpdateProgress1
01f0b5f4: 489901f0 adrp     x8, #0x5236000
01f0b5f8: 082d47f9 ldr      x8, [x8, #0xe58]
01f0b5fc: 04010014 b        #0x1f0ba0c
01f0b600: 889901d0 adrp     x8, #0x523d000
01f0b604: 085540f9 ldr      x8, [x8, #0xa8]
01f0b608: e00316aa mov      x0, x22
01f0b60c: e2031faa mov      x2, xzr
01f0b610: 010140f9 ldr      x1, [x8]
01f0b614: 68ebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b618: e01f0036 tbz      w0, #0, #0x1f0ba14
01f0b61c: e0030391 add      x0, sp, #0xc0
01f0b620: e1031faa mov      x1, xzr
01f0b624: e99f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b628: 889901d0 adrp     x8, #0x523d000
01f0b62c: 085540f9 ldr      x8, [x8, #0xa8]
01f0b630: e10300aa mov      x1, x0
01f0b634: e2031faa mov      x2, xzr
01f0b638: f60308aa mov      x22, x8
01f0b63c: 080140f9 ldr      x8, [x8]
01f0b640: e00308aa mov      x0, x8
01f0b644: ba923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b648: e0030391 add      x0, sp, #0xc0
01f0b64c: e1031faa mov      x1, xzr
01f0b650: de9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b654: e1031faa mov      x1, xzr
01f0b658: 2f6acd97 bl       #0x1265f14 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue2FromBackend
01f0b65c: bc000014 b        #0x1f0b94c
01f0b660: 489601d0 adrp     x8, #0x51d5000
01f0b664: 08e544f9 ldr      x8, [x8, #0x9c8]
01f0b668: e00316aa mov      x0, x22
01f0b66c: e2031faa mov      x2, xzr
01f0b670: 010140f9 ldr      x1, [x8]
01f0b674: 50ebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b678: e01c0036 tbz      w0, #0, #0x1f0ba14
01f0b67c: e0030391 add      x0, sp, #0xc0
01f0b680: e1031faa mov      x1, xzr
01f0b684: d19f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b688: 489601d0 adrp     x8, #0x51d5000
01f0b68c: 08e544f9 ldr      x8, [x8, #0x9c8]
01f0b690: e10300aa mov      x1, x0
01f0b694: e2031faa mov      x2, xzr
01f0b698: 080140f9 ldr      x8, [x8]
01f0b69c: e00308aa mov      x0, x8
01f0b6a0: a3923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b6a4: 564740f9 ldr      x22, [x26, #0x88]
01f0b6a8: e0030391 add      x0, sp, #0xc0
01f0b6ac: e1031faa mov      x1, xzr
01f0b6b0: c69f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b6b4: 562b00b4 cbz      x22, #0x1f0bc1c
01f0b6b8: e10300aa mov      x1, x0
01f0b6bc: e00316aa mov      x0, x22
01f0b6c0: e2031faa mov      x2, xzr
01f0b6c4: d57ff597 bl       #0x1c6b618 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateProgress1
01f0b6c8: 489601d0 adrp     x8, #0x51d5000
01f0b6cc: 08e544f9 ldr      x8, [x8, #0x9c8]
01f0b6d0: cf000014 b        #0x1f0ba0c
01f0b6d4: e10240f9 ldr      x1, [x23]
01f0b6d8: e00316aa mov      x0, x22
01f0b6dc: e2031faa mov      x2, xzr
01f0b6e0: 35ebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b6e4: 80190036 tbz      w0, #0, #0x1f0ba14
01f0b6e8: e0030391 add      x0, sp, #0xc0
01f0b6ec: e1031faa mov      x1, xzr
01f0b6f0: b69f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b6f4: e80240f9 ldr      x8, [x23]
01f0b6f8: e10300aa mov      x1, x0
01f0b6fc: e2031faa mov      x2, xzr
01f0b700: e00308aa mov      x0, x8
01f0b704: 8a923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b708: 566340f9 ldr      x22, [x26, #0xc0]
01f0b70c: e0030391 add      x0, sp, #0xc0
01f0b710: e1031faa mov      x1, xzr
01f0b714: ad9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b718: 362800b4 cbz      x22, #0x1f0bc1c
01f0b71c: e10300aa mov      x1, x0
01f0b720: e00316aa mov      x0, x22
01f0b724: e2031faa mov      x2, xzr
01f0b728: b9a61094 bl       #0x233520c ; Royal.Player.Context.Units.DukesFortuneManager$$UpdateProgress2
01f0b72c: e00240f9 ldr      x0, [x23]
01f0b730: c7000014 b        #0x1f0ba4c
01f0b734: 089601d0 adrp     x8, #0x51cd000
01f0b738: 08e140f9 ldr      x8, [x8, #0x1c0]
01f0b73c: e00316aa mov      x0, x22
01f0b740: e2031faa mov      x2, xzr
01f0b744: 010140f9 ldr      x1, [x8]
01f0b748: 1bebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b74c: 40160036 tbz      w0, #0, #0x1f0ba14
01f0b750: e0030391 add      x0, sp, #0xc0
01f0b754: e1031faa mov      x1, xzr
01f0b758: 9c9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b75c: e1031faa mov      x1, xzr
01f0b760: d17b0a94 bl       #0x21aa6a4 ; Royal.Player.Context.Data.Persistent.KeyValueAbTestIds$$UpdateData
01f0b764: 089601d0 adrp     x8, #0x51cd000
01f0b768: 08e140f9 ldr      x8, [x8, #0x1c0]
01f0b76c: a8000014 b        #0x1f0ba0c
01f0b770: e8940190 adrp     x8, #0x51a7000
01f0b774: 086545f9 ldr      x8, [x8, #0xac8]
01f0b778: e00316aa mov      x0, x22
01f0b77c: e2031faa mov      x2, xzr
01f0b780: 010140f9 ldr      x1, [x8]
01f0b784: 0cebf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b788: 60140036 tbz      w0, #0, #0x1f0ba14
01f0b78c: e0030391 add      x0, sp, #0xc0
01f0b790: e1031faa mov      x1, xzr
01f0b794: 8d9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b798: e8940190 adrp     x8, #0x51a7000
01f0b79c: 086545f9 ldr      x8, [x8, #0xac8]
01f0b7a0: e10300aa mov      x1, x0
01f0b7a4: e2031faa mov      x2, xzr
01f0b7a8: 080140f9 ldr      x8, [x8]
01f0b7ac: e00308aa mov      x0, x8
01f0b7b0: 5f923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b7b4: 564340f9 ldr      x22, [x26, #0x80]
01f0b7b8: e0030391 add      x0, sp, #0xc0
01f0b7bc: e1031faa mov      x1, xzr
01f0b7c0: 829f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b7c4: d62200b4 cbz      x22, #0x1f0bc1c
01f0b7c8: e10300aa mov      x1, x0
01f0b7cc: e00316aa mov      x0, x22
01f0b7d0: e2031faa mov      x2, xzr
01f0b7d4: 80edfa97 bl       #0x1dc6dd4 ; Royal.Player.Context.Units.LavaQuestManager$$UpdateProgress2
01f0b7d8: 404340f9 ldr      x0, [x26, #0x80]
01f0b7dc: 002200b4 cbz      x0, #0x1f0bc1c
01f0b7e0: e1031faa mov      x1, xzr
01f0b7e4: ceedfa97 bl       #0x1dc6f1c ; Royal.Player.Context.Units.LavaQuestManager$$UpdateLocalData
01f0b7e8: e8940190 adrp     x8, #0x51a7000
01f0b7ec: 086545f9 ldr      x8, [x8, #0xac8]
01f0b7f0: 87000014 b        #0x1f0ba0c
01f0b7f4: 489901f0 adrp     x8, #0x5236000
01f0b7f8: 086944f9 ldr      x8, [x8, #0x8d0]
01f0b7fc: e00316aa mov      x0, x22
01f0b800: e2031faa mov      x2, xzr
01f0b804: 010140f9 ldr      x1, [x8]
01f0b808: ebeaf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b80c: 40100036 tbz      w0, #0, #0x1f0ba14
01f0b810: 48b301f0 adrp     x8, #0x5576000
01f0b814: 08ad7c39 ldrb     w8, [x8, #0xf2b]
01f0b818: e8000035 cbnz     w8, #0x1f0b834
01f0b81c: e09701b0 adrp     x0, #0x5208000
01f0b820: 00c041f9 ldr      x0, [x0, #0x380]
01f0b824: b796c297 bl       #0xfb1300
01f0b828: 48b301f0 adrp     x8, #0x5576000
01f0b82c: 29008052 mov      w9, #1
01f0b830: 09ad3c39 strb     w9, [x8, #0xf2b]
01f0b834: e89701b0 adrp     x8, #0x5208000
01f0b838: 08c141f9 ldr      x8, [x8, #0x380]
01f0b83c: 080140f9 ldr      x8, [x8]
01f0b840: 085d40f9 ldr      x8, [x8, #0xb8]
01f0b844: 080140f9 ldr      x8, [x8]
01f0b848: a81e00b4 cbz      x8, #0x1f0bc1c
01f0b84c: 161140f9 ldr      x22, [x8, #0x20]
01f0b850: e0030391 add      x0, sp, #0xc0
01f0b854: e1031faa mov      x1, xzr
01f0b858: 5c9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b85c: 161e00b4 cbz      x22, #0x1f0bc1c
01f0b860: e10300aa mov      x1, x0
01f0b864: e00316aa mov      x0, x22
01f0b868: e2031faa mov      x2, xzr
01f0b86c: 4a0e2c94 bl       #0x2a0f194 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDialogs
01f0b870: 489901f0 adrp     x8, #0x5236000
01f0b874: 086944f9 ldr      x8, [x8, #0x8d0]
01f0b878: 65000014 b        #0x1f0ba0c
01f0b87c: a89401d0 adrp     x8, #0x51a1000
01f0b880: 089543f9 ldr      x8, [x8, #0x728]
01f0b884: e00316aa mov      x0, x22
01f0b888: e2031faa mov      x2, xzr
01f0b88c: 010140f9 ldr      x1, [x8]
01f0b890: c9eaf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b894: 000c0036 tbz      w0, #0, #0x1f0ba14
01f0b898: e0030391 add      x0, sp, #0xc0
01f0b89c: e1031faa mov      x1, xzr
01f0b8a0: 4a9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b8a4: a89401d0 adrp     x8, #0x51a1000
01f0b8a8: 089543f9 ldr      x8, [x8, #0x728]
01f0b8ac: e10300aa mov      x1, x0
01f0b8b0: e2031faa mov      x2, xzr
01f0b8b4: 080140f9 ldr      x8, [x8]
01f0b8b8: e00308aa mov      x0, x8
01f0b8bc: 1c923d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b8c0: 563b40f9 ldr      x22, [x26, #0x70]
01f0b8c4: e0030391 add      x0, sp, #0xc0
01f0b8c8: e1031faa mov      x1, xzr
01f0b8cc: 3f9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b8d0: 761a00b4 cbz      x22, #0x1f0bc1c
01f0b8d4: e10300aa mov      x1, x0
01f0b8d8: e00316aa mov      x0, x22
01f0b8dc: e2031faa mov      x2, xzr
01f0b8e0: a8e90a94 bl       #0x21c5f80 ; Royal.Player.Context.Units.DragonNestManager$$UpdateProgress2
01f0b8e4: a89401d0 adrp     x8, #0x51a1000
01f0b8e8: 089543f9 ldr      x8, [x8, #0x728]
01f0b8ec: 48000014 b        #0x1f0ba0c
01f0b8f0: 089501d0 adrp     x8, #0x51ad000
01f0b8f4: 087143f9 ldr      x8, [x8, #0x6e0]
01f0b8f8: e00316aa mov      x0, x22
01f0b8fc: e2031faa mov      x2, xzr
01f0b900: 010140f9 ldr      x1, [x8]
01f0b904: aceaf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b908: 60080036 tbz      w0, #0, #0x1f0ba14
01f0b90c: e0030391 add      x0, sp, #0xc0
01f0b910: e1031faa mov      x1, xzr
01f0b914: 2d9f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b918: 089501d0 adrp     x8, #0x51ad000
01f0b91c: 087143f9 ldr      x8, [x8, #0x6e0]
01f0b920: e10300aa mov      x1, x0
01f0b924: e2031faa mov      x2, xzr
01f0b928: f60308aa mov      x22, x8
01f0b92c: 080140f9 ldr      x8, [x8]
01f0b930: e00308aa mov      x0, x8
01f0b934: fe913d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b938: e0030391 add      x0, sp, #0xc0
01f0b93c: e1031faa mov      x1, xzr
01f0b940: 229f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b944: e1031faa mov      x1, xzr
01f0b948: e269cd97 bl       #0x12660d0 ; Royal.Scenes.Home.Ui.Dialogs.Offer.DynamicOffers.DynamicOfferKeyValueHelper$$UpdateValue3FromBackend
01f0b94c: c00240f9 ldr      x0, [x22]
01f0b950: 3f000014 b        #0x1f0ba4c
01f0b954: 089801f0 adrp     x8, #0x520e000
01f0b958: 08b541f9 ldr      x8, [x8, #0x368]
01f0b95c: e00316aa mov      x0, x22
01f0b960: e2031faa mov      x2, xzr
01f0b964: 010140f9 ldr      x1, [x8]
01f0b968: 93eaf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b96c: 40050036 tbz      w0, #0, #0x1f0ba14
01f0b970: e0030391 add      x0, sp, #0xc0
01f0b974: e1031faa mov      x1, xzr
01f0b978: 149f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b97c: 089801f0 adrp     x8, #0x520e000
01f0b980: 08b541f9 ldr      x8, [x8, #0x368]
01f0b984: e10300aa mov      x1, x0
01f0b988: e2031faa mov      x2, xzr
01f0b98c: 080140f9 ldr      x8, [x8]
01f0b990: e00308aa mov      x0, x8
01f0b994: e6913d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0b998: 567740f9 ldr      x22, [x26, #0xe8]
01f0b99c: e0030391 add      x0, sp, #0xc0
01f0b9a0: e1031faa mov      x1, xzr
01f0b9a4: 099f2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b9a8: b61300b4 cbz      x22, #0x1f0bc1c
01f0b9ac: e10300aa mov      x1, x0
01f0b9b0: e00316aa mov      x0, x22
01f0b9b4: ef000094 bl       #0x1f0bd70 ; Royal.Player.Context.Units.UserProfileManager$$UpdateProgress1
01f0b9b8: 089801f0 adrp     x8, #0x520e000
01f0b9bc: 08b541f9 ldr      x8, [x8, #0x368]
01f0b9c0: 13000014 b        #0x1f0ba0c
01f0b9c4: 889501f0 adrp     x8, #0x51be000
01f0b9c8: 08a946f9 ldr      x8, [x8, #0xd50]
01f0b9cc: e00316aa mov      x0, x22
01f0b9d0: e2031faa mov      x2, xzr
01f0b9d4: 010140f9 ldr      x1, [x8]
01f0b9d8: 77eaf797 bl       #0x1d063b4 ; System.String$$op_Equality
01f0b9dc: c0010036 tbz      w0, #0, #0x1f0ba14
01f0b9e0: 564f40f9 ldr      x22, [x26, #0x98]
01f0b9e4: e0030391 add      x0, sp, #0xc0
01f0b9e8: e1031faa mov      x1, xzr
01f0b9ec: f79e2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0b9f0: 761100b4 cbz      x22, #0x1f0bc1c
01f0b9f4: e10300aa mov      x1, x0
01f0b9f8: e00316aa mov      x0, x22
01f0b9fc: e2031faa mov      x2, xzr
01f0ba00: 3589fa97 bl       #0x1daded4 ; Royal.Player.Context.Units.SystemMessageManager$$UpdateLastClaimedMessages
01f0ba04: 889501f0 adrp     x8, #0x51be000
01f0ba08: 08a946f9 ldr      x8, [x8, #0xd50]
01f0ba0c: 000140f9 ldr      x0, [x8]
01f0ba10: 0f000014 b        #0x1f0ba4c
01f0ba14: e0030391 add      x0, sp, #0xc0
01f0ba18: e1031faa mov      x1, xzr
01f0ba1c: bb9e2394 bl       #0x27f3508 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Key
01f0ba20: f60300aa mov      x22, x0
01f0ba24: e0030391 add      x0, sp, #0xc0
01f0ba28: e1031faa mov      x1, xzr
01f0ba2c: e79e2394 bl       #0x27f35c8 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Value
01f0ba30: e10300aa mov      x1, x0
01f0ba34: e00316aa mov      x0, x22
01f0ba38: e2031faa mov      x2, xzr
01f0ba3c: bc913d94 bl       #0x2e7012c ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetLong
01f0ba40: e0030391 add      x0, sp, #0xc0
01f0ba44: e1031faa mov      x1, xzr
01f0ba48: b09e2394 bl       #0x27f3508 ; Royal.Infrastructure.Services.Backend.Protocol.KeyValue$$get_Key
01f0ba4c: 21008052 mov      w1, #1
01f0ba50: e2031faa mov      x2, xzr
01f0ba54: f3913d94 bl       #0x2e70220 ; Royal.Infrastructure.Services.Storage.Tables.UserKeyValue$$SetSynced
01f0ba58: e0430391 add      x0, sp, #0xd0
01f0ba5c: e1031faa mov      x1, xzr
01f0ba60: 94060011 add      w20, w20, #1
01f0ba64: 1a294e94 bl       #0x3295ecc ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_KeyValueListLength
01f0ba68: 9f02006b cmp      w20, w0
01f0ba6c: cb5bff54 b.lt     #0x1f0a5e4
01f0ba70: e0430391 add      x0, sp, #0xd0
01f0ba74: e1031faa mov      x1, xzr
01f0ba78: 7f2a4e94 bl       #0x3296474 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_ByteArrayKeyValueListLength
01f0ba7c: 1f040071 cmp      w0, #1
01f0ba80: ab050054 b.lt     #0x1f0bb34
01f0ba84: b79701d0 adrp     x23, #0x5201000
01f0ba88: f89601d0 adrp     x24, #0x51e9000
01f0ba8c: f78a42f9 ldr      x23, [x23, #0x510]
01f0ba90: 186b47f9 ldr      x24, [x24, #0xed0]
01f0ba94: f4031f2a mov      w20, wzr
01f0ba98: e8030191 add      x8, sp, #0x40
01f0ba9c: e0430391 add      x0, sp, #0xd0
01f0baa0: e103142a mov      w1, w20
01f0baa4: e2031faa mov      x2, xzr
01f0baa8: 3d2a4e94 bl       #0x329639c ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$ByteArrayKeyValueList
01f0baac: e013c03d ldr      q0, [sp, #0x40]
01f0bab0: e82b40f9 ldr      x8, [sp, #0x50]
01f0bab4: e10240f9 ldr      x1, [x23]
01f0bab8: e0830191 add      x0, sp, #0x60
01f0babc: e01b803d str      q0, [sp, #0x60]
01f0bac0: e83b00f9 str      x8, [sp, #0x70]
01f0bac4: cb613c94 bl       #0x2e241f0 ; System.Nullable<ByteArrayKeyValue>$$get_Value
01f0bac8: e00708a9 stp      x0, x1, [sp, #0x80]
01f0bacc: e0030291 add      x0, sp, #0x80
01f0bad0: e1031faa mov      x1, xzr
01f0bad4: 0aa33594 bl       #0x2c746fc ; Royal.Infrastructure.Services.Backend.Protocol.ByteArrayKeyValue$$get_Key
01f0bad8: f503002a mov      w21, w0
01f0badc: e0030291 add      x0, sp, #0x80
01f0bae0: e1031faa mov      x1, xzr
01f0bae4: 4aa33594 bl       #0x2c7480c ; Royal.Infrastructure.Services.Backend.Protocol.ByteArrayKeyValue$$GetValueArray
01f0bae8: 080340f9 ldr      x8, [x24]
01f0baec: f60300aa mov      x22, x0
01f0baf0: 09e140b9 ldr      w9, [x8, #0xe0]
01f0baf4: 69000035 cbnz     w9, #0x1f0bb00
01f0baf8: e00308aa mov      x0, x8
01f0bafc: 4296c297 bl       #0xfb1404
01f0bb00: e00316aa mov      x0, x22
01f0bb04: e1031faa mov      x1, xzr
01f0bb08: f2e04d94 bl       #0x3283ed0 ; Royal.Infrastructure.Utils.Math.BitArrayOperations$$ToString
01f0bb0c: e20300aa mov      x2, x0
01f0bb10: e0031aaa mov      x0, x26
01f0bb14: e103152a mov      w1, w21
01f0bb18: de010094 bl       #0x1f0c290 ; Royal.Player.Context.Units.UserManager$$ProcessByteArrayKeyValue
01f0bb1c: e0430391 add      x0, sp, #0xd0
01f0bb20: e1031faa mov      x1, xzr
01f0bb24: 94060011 add      w20, w20, #1
01f0bb28: 532a4e94 bl       #0x3296474 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_ByteArrayKeyValueListLength
01f0bb2c: 9f02006b cmp      w20, w0
01f0bb30: 4bfbff54 b.lt     #0x1f0ba98
01f0bb34: 54b740f9 ldr      x20, [x26, #0x168]
01f0bb38: e8a30091 add      x8, sp, #0x28
01f0bb3c: e0430391 add      x0, sp, #0xd0
01f0bb40: e1031faa mov      x1, xzr
01f0bb44: 08304e94 bl       #0x3297b64 ; Royal.Infrastructure.Services.Backend.Protocol.UserProgress$$get_InviteFriendRefreshInfo
01f0bb48: e083c23c ldur     q0, [sp, #0x28]
01f0bb4c: e81f40f9 ldr      x8, [sp, #0x38]
01f0bb50: e013803d str      q0, [sp, #0x40]
01f0bb54: e82b00f9 str      x8, [sp, #0x50]
01f0bb58: 340600b4 cbz      x20, #0x1f0bc1c
01f0bb5c: e013c03d ldr      q0, [sp, #0x40]
01f0bb60: e82b40f9 ldr      x8, [sp, #0x50]
01f0bb64: e1430091 add      x1, sp, #0x10
01f0bb68: e00314aa mov      x0, x20
01f0bb6c: e2031faa mov      x2, xzr
01f0bb70: e007803d str      q0, [sp, #0x10]
01f0bb74: e81300f9 str      x8, [sp, #0x20]
01f0bb78: 0d9bf597 bl       #0x1c727ac ; Royal.Player.Context.Units.InviteFriendsManager$$UpdateRefreshInfo
01f0bb7c: 403b40f9 ldr      x0, [x26, #0x70]
01f0bb80: e00400b4 cbz      x0, #0x1f0bc1c
01f0bb84: e1031faa mov      x1, xzr
01f0bb88: 50e90a94 bl       #0x21c60c8 ; Royal.Player.Context.Units.DragonNestManager$$ProgressUpdated
01f0bb8c: 403f40f9 ldr      x0, [x26, #0x78]
01f0bb90: 600400b4 cbz      x0, #0x1f0bc1c
01f0bb94: e1031faa mov      x1, xzr
01f0bb98: 38a70594 bl       #0x2075878 ; Royal.Player.Context.Units.TrainJourneyManager$$ProgressUpdated
01f0bb9c: 404340f9 ldr      x0, [x26, #0x80]
01f0bba0: e00300b4 cbz      x0, #0x1f0bc1c
01f0bba4: e1031faa mov      x1, xzr
01f0bba8: 6be8fa97 bl       #0x1dc5d54 ; Royal.Player.Context.Units.LavaQuestManager$$TryGetEventInfo
01f0bbac: 404340f9 ldr      x0, [x26, #0x80]
01f0bbb0: 600300b4 cbz      x0, #0x1f0bc1c
01f0bbb4: e1031faa mov      x1, xzr
01f0bbb8: ebe3fa97 bl       #0x1dc4b64 ; Royal.Player.Context.Units.LavaQuestManager$$TryGetFacebookIds
01f0bbbc: 404740f9 ldr      x0, [x26, #0x88]
01f0bbc0: e00200b4 cbz      x0, #0x1f0bc1c
01f0bbc4: e1031faa mov      x1, xzr
01f0bbc8: d885f597 bl       #0x1c6d328 ; Royal.Player.Context.Units.HiddenTempleManager$$UpdateEventState
01f0bbcc: 408340f9 ldr      x0, [x26, #0x100]
01f0bbd0: 600200b4 cbz      x0, #0x1f0bc1c
01f0bbd4: e1031faa mov      x1, xzr
01f0bbd8: 05cd0a94 bl       #0x21befec ; Royal.Player.Context.Units.DailyLightningRushManager$$ProgressUpdated
01f0bbdc: 408f40f9 ldr      x0, [x26, #0x118]
01f0bbe0: e00100b4 cbz      x0, #0x1f0bc1c
01f0bbe4: e1031faa mov      x1, xzr
01f0bbe8: c04a4a94 bl       #0x319e6e8 ; Royal.Player.Context.Units.PropellerRushManager$$ProgressUpdated
01f0bbec: 409b40f9 ldr      x0, [x26, #0x130]
01f0bbf0: 600100b4 cbz      x0, #0x1f0bc1c
01f0bbf4: e1031faa mov      x1, xzr
01f0bbf8: 83804f94 bl       #0x32ebe04 ; Royal.Player.Context.Units.RobotRivalsManager$$ProgressUpdated
01f0bbfc: fd7b53a9 ldp      x29, x30, [sp, #0x130]
01f0bc00: f44f52a9 ldp      x20, x19, [sp, #0x120]
01f0bc04: f65751a9 ldp      x22, x21, [sp, #0x110]
01f0bc08: f85f50a9 ldp      x24, x23, [sp, #0x100]
01f0bc0c: fa674fa9 ldp      x26, x25, [sp, #0xf0]
01f0bc10: fc6f4ea9 ldp      x28, x27, [sp, #0xe0]
01f0bc14: ff030591 add      sp, sp, #0x140
01f0bc18: c0035fd6 ret      
01f0bc1c: 0396c297 bl       #0xfb1428
