# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetSkill
# Linear span to next metadata entry; not a complete CFG.
01c85258: f40f1ef8 str      x20, [sp, #-0x20]!
01c8525c: f37b01a9 stp      x19, x30, [sp, #0x10]
01c85260: b3c701d0 adrp     x19, #0x557b000
01c85264: 68725739 ldrb     w8, [x19, #0x5dc]
01c85268: 28010037 tbnz     w8, #0, #0x1c8528c
01c8526c: 40aa01b0 adrp     x0, #0x51ce000
01c85270: 00a443f9 ldr      x0, [x0, #0x748]
01c85274: 23b0cc97 bl       #0xfb1300
01c85278: c0ab01d0 adrp     x0, #0x51ff000
01c8527c: 009840f9 ldr      x0, [x0, #0x130]
01c85280: 20b0cc97 bl       #0xfb1300
01c85284: 28008052 mov      w8, #1
01c85288: 68721739 strb     w8, [x19, #0x5dc]
01c8528c: 93c701b0 adrp     x19, #0x5576000
01c85290: 68ae7c39 ldrb     w8, [x19, #0xf2b]
01c85294: c8000035 cbnz     w8, #0x1c852ac
01c85298: 00ac01f0 adrp     x0, #0x5208000
01c8529c: 00c041f9 ldr      x0, [x0, #0x380]
01c852a0: 18b0cc97 bl       #0xfb1300
01c852a4: 28008052 mov      w8, #1
01c852a8: 68ae3c39 strb     w8, [x19, #0xf2b]
01c852ac: 08ac01f0 adrp     x8, #0x5208000
01c852b0: 08c141f9 ldr      x8, [x8, #0x380]
01c852b4: 080140f9 ldr      x8, [x8]
01c852b8: 085d40f9 ldr      x8, [x8, #0xb8]
01c852bc: 000140f9 ldr      x0, [x8]
01c852c0: 000300b4 cbz      x0, #0x1c85320
01c852c4: d3ab01d0 adrp     x19, #0x51ff000
01c852c8: 54aa01b0 adrp     x20, #0x51ce000
01c852cc: 739a40f9 ldr      x19, [x19, #0x130]
01c852d0: 94a643f9 ldr      x20, [x20, #0x748]
01c852d4: e1031faa mov      x1, xzr
01c852d8: 67182894 bl       #0x268b474 ; Royal.Player.Context.Data.User$$get_Skill
01c852dc: 680240f9 ldr      x8, [x19]
01c852e0: e00f00b9 str      w0, [sp, #0xc]
01c852e4: e1330091 add      x1, sp, #0xc
01c852e8: e00308aa mov      x0, x8
01c852ec: 48b0cc97 bl       #0xfb140c
01c852f0: 880240f9 ldr      x8, [x20]
01c852f4: f30300aa mov      x19, x0
01c852f8: 09e140b9 ldr      w9, [x8, #0xe0]
01c852fc: 69000035 cbnz     w9, #0x1c85308
01c85300: e00308aa mov      x0, x8
01c85304: 40b0cc97 bl       #0xfb1404
01c85308: e00313aa mov      x0, x19
01c8530c: e1031faa mov      x1, xzr
01c85310: 8d2d0d94 bl       #0x1fd0944 ; System.Convert$$ToInt32
01c85314: f37b41a9 ldp      x19, x30, [sp, #0x10]
01c85318: f40742f8 ldr      x20, [sp], #0x20
01c8531c: c0035fd6 ret      
01c85320: 42b0cc97 bl       #0xfb1428
