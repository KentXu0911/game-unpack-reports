# Royal.Player.Context.Data.Persistent.UserInventory$$UpdateTryCount
# Linear span to next metadata entry; not a complete CFG.
02a0dc40: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
02a0dc44: f30300aa mov      x19, x0
02a0dc48: 001840f9 ldr      x0, [x0, #0x30]
02a0dc4c: 3ffc0171 cmp      w1, #0x7f
02a0dc50: e80f8052 mov      w8, #0x7f
02a0dc54: 28b0881a csel     w8, w1, w8, lt
02a0dc58: 017da80a bic      w1, w8, w8, asr #31
02a0dc5c: c2068052 mov      w2, #0x36
02a0dc60: 83078052 mov      w3, #0x3c
02a0dc64: e4031faa mov      x4, xzr
02a0dc68: 10da2194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0dc6c: e10300aa mov      x1, x0
02a0dc70: e00313aa mov      x0, x19
02a0dc74: f37bc1a8 ldp      x19, x30, [sp], #0x10
02a0dc78: 13f7ff17 b        #0x2a0b8c4 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdatePreLevelInventory
