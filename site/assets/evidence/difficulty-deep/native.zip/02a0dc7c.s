# Royal.Player.Context.Data.Persistent.UserInventory$$GetSkill
# Linear span to next metadata entry; not a complete CFG.
02a0dc7c: fe0f1ff8 str      x30, [sp, #-0x10]!
02a0dc80: 001840f9 ldr      x0, [x0, #0x30]
02a0dc84: 61068052 mov      w1, #0x33
02a0dc88: a2068052 mov      w2, #0x35
02a0dc8c: e3031faa mov      x3, xzr
02a0dc90: d8d92194 bl       #0x32843f0 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractByte
02a0dc94: 001c0012 and      w0, w0, #0xff
02a0dc98: fe0741f8 ldr      x30, [sp], #0x10
02a0dc9c: c0035fd6 ret      
