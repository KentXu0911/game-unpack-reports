# Royal.Infrastructure.Utils.Math.BitwiseOperations$$SetBit
# Linear span to next metadata entry; not a complete CFG.
0328439c: 28008052 mov      w8, #1
032843a0: 0821c19a lsl      x8, x8, x1
032843a4: 090100aa orr      x9, x8, x0
032843a8: 0800288a bic      x8, x0, x8
032843ac: 5f000072 tst      w2, #1
032843b0: 2011889a csel     x0, x9, x8, ne
032843b4: c0035fd6 ret      
