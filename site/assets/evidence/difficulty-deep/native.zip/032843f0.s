# Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractByte
# Linear span to next metadata entry; not a complete CFG.
032843f0: 4800014b sub      w8, w2, w1
032843f4: 09008092 mov      x9, #-1
032843f8: 08050011 add      w8, w8, #1
032843fc: 2821c89a lsl      x8, x9, x8
03284400: 081d0052 eor      w8, w8, #0xff
03284404: 0928c19a asr      x9, x0, x1
03284408: 0001090a and      w0, w8, w9
0328440c: c0035fd6 ret      
