# Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
# Linear span to next metadata entry; not a complete CFG.
032843b8: 4800014b sub      w8, w2, w1
032843bc: 09008092 mov      x9, #-1
032843c0: 08050011 add      w8, w8, #1
032843c4: 2821c89a lsl      x8, x9, x8
032843c8: 0928c19a asr      x9, x0, x1
032843cc: 2001288a bic      x0, x9, x8
032843d0: c0035fd6 ret      
