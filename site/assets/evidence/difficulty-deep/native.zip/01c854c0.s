# Royal.Player.Context.Units.SemiDynamicDifficulty$$Reset
# Linear span to next metadata entry; not a complete CFG.
01c854c0: c0035fd6 ret      
