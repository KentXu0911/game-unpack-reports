# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnLevelFail
# Linear span to next metadata entry; not a complete CFG.
01c85250: c0035fd6 ret      
