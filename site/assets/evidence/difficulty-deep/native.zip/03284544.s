# Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
# Linear span to next metadata entry; not a complete CFG.
03284544: f80f1cf8 str      x24, [sp, #-0x40]!
03284548: f75b01a9 stp      x23, x22, [sp, #0x10]
0328454c: f55302a9 stp      x21, x20, [sp, #0x20]
03284550: f37b03a9 stp      x19, x30, [sp, #0x30]
03284554: 171801d0 adrp     x23, #0x5586000
03284558: f8fb0090 adrp     x24, #0x5200000
0328455c: e8824039 ldrb     w8, [x23, #0x20]
03284560: 188f46f9 ldr      x24, [x24, #0xd18]
03284564: f603032a mov      w22, w3
03284568: f303022a mov      w19, w2
0328456c: f50301aa mov      x21, x1
03284570: f40300aa mov      x20, x0
03284574: c8000037 tbnz     w8, #0, #0x328458c
03284578: e0fb0090 adrp     x0, #0x5200000
0328457c: 008c46f9 ldr      x0, [x0, #0xd18]
03284580: 60b37497 bl       #0xfb1300
03284584: 28008052 mov      w8, #1
03284588: e8820039 strb     w8, [x23, #0x20]
0328458c: 000340f9 ldr      x0, [x24]
03284590: 08e040b9 ldr      w8, [x0, #0xe0]
03284594: 48000035 cbnz     w8, #0x328459c
03284598: 9bb37497 bl       #0xfb1404
0328459c: c1060011 add      w1, w22, #1
032845a0: e0078052 mov      w0, #0x3f
032845a4: e2031faa mov      x2, xzr
032845a8: db51cc97 bl       #0x2598d14 ; System.Math$$Min
032845ac: 08008092 mov      x8, #-1
032845b0: 0921d39a lsl      x9, x8, x19
032845b4: 0821c09a lsl      x8, x8, x0
032845b8: 080129aa orn      x8, x8, x9
032845bc: a922d39a lsl      x9, x21, x19
032845c0: 0801148a and      x8, x8, x20
032845c4: f37b43a9 ldp      x19, x30, [sp, #0x30]
032845c8: f55342a9 ldp      x21, x20, [sp, #0x20]
032845cc: f75b41a9 ldp      x23, x22, [sp, #0x10]
032845d0: 000109aa orr      x0, x8, x9
032845d4: f80744f8 ldr      x24, [sp], #0x40
032845d8: c0035fd6 ret      
