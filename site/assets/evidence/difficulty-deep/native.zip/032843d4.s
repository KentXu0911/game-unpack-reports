# Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractInt
# Linear span to next metadata entry; not a complete CFG.
032843d4: 4800014b sub      w8, w2, w1
032843d8: 09008092 mov      x9, #-1
032843dc: 08050011 add      w8, w8, #1
032843e0: 2821c89a lsl      x8, x9, x8
032843e4: 0928c19a asr      x9, x0, x1
032843e8: 2001280a bic      w0, w9, w8
032843ec: c0035fd6 ret      
