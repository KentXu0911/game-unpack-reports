# Royal.Player.Context.Units.SemiDynamicDifficulty$$OnEgoShownFirst
# Linear span to next metadata entry; not a complete CFG.
01c85454: 1cffff17 b        #0x1c850c4 ; Royal.Player.Context.Units.SemiDynamicDifficulty$$IncrementTryCount
