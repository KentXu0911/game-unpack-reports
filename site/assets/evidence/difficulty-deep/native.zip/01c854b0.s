# Royal.Player.Context.Units.SemiDynamicDifficulty$$GetSection
# Linear span to next metadata entry; not a complete CFG.
01c854b0: e0031f2a mov      w0, wzr
01c854b4: c0035fd6 ret      
