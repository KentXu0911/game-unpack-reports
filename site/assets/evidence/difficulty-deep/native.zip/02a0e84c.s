# Royal.Player.Context.Data.Persistent.UserInventory$$GetDeltaMove
# Linear span to next metadata entry; not a complete CFG.
02a0e84c: fe0f1ff8 str      x30, [sp, #-0x10]!
02a0e850: 005840f9 ldr      x0, [x0, #0xb0]
02a0e854: a1018052 mov      w1, #0xd
02a0e858: 22028052 mov      w2, #0x11
02a0e85c: e3031faa mov      x3, xzr
02a0e860: d6d62194 bl       #0x32843b8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$ExtractLong
02a0e864: 08280051 sub      w8, w0, #0xa
02a0e868: 1f000071 cmp      w0, #0
02a0e86c: e003881a csel     w0, wzr, w8, eq
02a0e870: fe0741f8 ldr      x30, [sp], #0x10
02a0e874: c0035fd6 ret      
