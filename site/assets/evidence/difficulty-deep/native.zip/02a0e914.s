# Royal.Player.Context.Data.Persistent.UserInventory$$SetCurrentLevel
# Linear span to next metadata entry; not a complete CFG.
02a0e914: f37bbfa9 stp      x19, x30, [sp, #-0x10]!
02a0e918: f30300aa mov      x19, x0
02a0e91c: 005840f9 ldr      x0, [x0, #0xb0]
02a0e920: 62048052 mov      w2, #0x23
02a0e924: 23068052 mov      w3, #0x31
02a0e928: e4031faa mov      x4, xzr
02a0e92c: dfd62194 bl       #0x32844a8 ; Royal.Infrastructure.Utils.Math.BitwiseOperations$$UpdateLong
02a0e930: e10300aa mov      x1, x0
02a0e934: e00313aa mov      x0, x19
02a0e938: f37bc1a8 ldp      x19, x30, [sp], #0x10
02a0e93c: 71ffff17 b        #0x2a0e700 ; Royal.Player.Context.Data.Persistent.UserInventory$$UpdateDynamicDifficultyInventory
