# Royal.Player.Context.Units.SemiDynamicDifficulty$$SetTryCount
# Linear span to next metadata entry; not a complete CFG.
01c85458: c0035fd6 ret      
